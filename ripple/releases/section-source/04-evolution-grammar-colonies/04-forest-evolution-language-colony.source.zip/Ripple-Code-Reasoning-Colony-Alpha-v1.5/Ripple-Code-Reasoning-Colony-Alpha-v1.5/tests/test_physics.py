import sys,unittest,json
from pathlib import Path
import numpy as np
P=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(P/'sources'))
from v14_physics_LOCKED import Setup,profile,field_superposition,count_photons
class PhysicsChecks(unittest.TestCase):
 def test_coherent_phasor_reproduces_intensity(self):
  x=np.linspace(-.006,.006,121)
  self.assertLess(np.max(abs(profile(x,Setup())-field_superposition(x,Setup()))),1e-12)
 def test_incoherent_profile_independent_of_separation(self):
  x=np.linspace(-.006,.006,121)
  a=profile(x,Setup(visibility=0,separation_m=.0003))
  b=profile(x,Setup(visibility=0,separation_m=.00045))
  self.assertTrue(np.allclose(a,b))
 def test_photon_count_conservation(self):
  p=np.array([0.2,0.3,0.5]);rng=np.random.default_rng(1)
  self.assertEqual(int(count_photons(p,1234,rng).sum()),1234)
 def test_both_bit_channels_differ(self):
  d=json.loads((P/'data/photon_cases.json').read_text())
  p0=np.array(d['p0']);p1=np.array(d['p1'])
  self.assertGreater(float(np.sum(abs(p0-p1))),0.1)
 def test_conditional_bit_information_increases_with_photons(self):
  d=json.loads((P/'data/photon_cases.json').read_text())
  p0=np.array(d['p0']);p1=np.array(d['p1'])
  kl=np.sum(p1*np.log(p1/p0));self.assertGreater(kl,0.1)
 def test_zero_evidence_non_identifiability(self):
  p=np.ones(4)/4;self.assertEqual(float(np.sum(p*np.log(p/p))),0.)
if __name__=='__main__':unittest.main()
