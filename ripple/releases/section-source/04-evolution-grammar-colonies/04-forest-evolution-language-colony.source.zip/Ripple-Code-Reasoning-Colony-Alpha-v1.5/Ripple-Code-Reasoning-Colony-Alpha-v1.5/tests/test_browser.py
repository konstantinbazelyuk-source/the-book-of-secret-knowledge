from pathlib import Path
import json
from playwright.sync_api import sync_playwright
P=Path(__file__).resolve().parents[1]
U=(P/'Ripple-Code-Reasoning-Colony-Alpha-v1.5.html').as_uri()
results=[]
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for title,w,h in [('desktop',1440,900),('phone',390,844)]:
  page=browser.new_page(viewport={'width':w,'height':h})
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto('about:blank')
  page.set_content((P/'Ripple-Code-Reasoning-Colony-Alpha-v1.5.html').read_text(),wait_until='load')
  assert page.locator('#hypothesis').inner_text().startswith('Candidate:'),page.locator('#hypothesis').inner_text()
  assert page.locator('#accuracy').inner_text()=='6/6'
  assert page.locator('#population').inner_text()=='6'
  page.locator('#next').click()
  assert 'STEP 02' in page.locator('#trace').inner_text()
  page.locator('#task').select_option('xor5_then_rotate1')
  assert 'rotate1(xor5(x))' in page.locator('#hypothesis').inner_text()
  page.locator('#photons').select_option('6')
  assert page.locator('#accuracy').inner_text().split('/')[1]=='6'
  page.locator('#all').click()
  assert page.locator('.step').count() >=5
  overflow=page.evaluate('document.documentElement.scrollWidth - window.innerWidth')
  assert overflow<=2,f'horizontal overflow {overflow}'
  assert not errors,errors
  page.screenshot(path=str(P/'data'/f'browser_{title}.png'),full_page=True)
  results.append({'viewport':title,'width':w,'errors':errors,'overflow':overflow,'traces':page.locator('.step').count()})
  page.close()
 browser.close()
(P/'data'/'browser_results.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
