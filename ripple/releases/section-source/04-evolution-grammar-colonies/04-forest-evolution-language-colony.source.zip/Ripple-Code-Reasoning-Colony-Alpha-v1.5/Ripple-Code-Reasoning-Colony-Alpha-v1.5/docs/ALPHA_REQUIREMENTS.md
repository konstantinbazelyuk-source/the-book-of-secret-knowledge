# Functional and scientific acceptance requirements

| ID | Requirement | Evidence / gate |
|---|---|---|
| RC-01 | Preserve v0.1 LIF implementation exactly | File SHA-256 check + spike/darkness tests |
| RC-02 | Preserve v0.7 four-symbol codec | File SHA-256 check; all 256 byte pack/unpack cases |
| RC-03 | Use actual v1.4 double-slit math | Locked Python source imported for 128 synthetic scenarios; phasor equality test |
| RC-04 | Keep photon sampling stochastic but reproducible | Independent seed; fixed dataset digest and NumPy generator |
| RC-05 | Decode every bit by two-slit count likelihood, not arbitrary labels | Calculated multinomial LLR with p0,p1 stored |
| RC-06 | Differentiate no-information input | All-zero likelihood must abstain |
| RC-07 | Create independent LIF worker state | Four specialists, two optional clones, own theta and spike logs |
| RC-08 | Bound clone count and code generation | Max 7 nodes; no eval, Function, remote JS or arbitrary source |
| RC-09 | Permit only finite rule grammar and validated inputs | 193 deduplicated mappings; nonfinite rejected |
| RC-10 | Track candidate scores and revision rounds | Recorded candidate shortlist and score margin per additional example |
| RC-11 | Keep held-out independent of search | Tests perturb withheld truth and sensor logs without changing hypothesis |
| RC-12 | Compare equivalent conventional solver | Exact-mapping and heldout percentage match |
| RC-13 | Keep negative ablations and unknown-code rejection | No-composition / hard-bit / out-of-grammar tests |
| RC-14 | Deliver audited human-readable traces | CLI JSON and self-contained offline browser explorer |
| RC-15 | No physical or intelligence overclaim | README, equations, negative record, explicit simulated flags |
| RC-16 | Verify packaging and integrity | Clean ZIP extraction, hash list and regression rerun |
