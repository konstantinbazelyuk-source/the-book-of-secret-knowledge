# Ripple Code-Reasoning Colony: equations, algorithms and claim boundaries

## A. Optical sender and detector (simulated)

The frozen v1.4 reference implements, for two equal slits with finite width and partial coherence,

\[ I(x)=\frac12\operatorname{sinc}^2\!\left(\frac{\pi a\sin\theta}{\lambda}\right)\left[1+V\cos\left(\frac{2\pi d\sin\theta}{\lambda}+\phi\right)\right].\]

A binary **engineering** bit is transmitted by setting visibility to `V=0.02` (bit 0) or `V=0.98` (bit 1), preserving all other idealized parameters. This does not describe a naturally occurring alphabet, and physical implementation would require an appropriate modulator and calibrated detector. The distribution across 41 screen bins is `p_b(i)=I_b(i)/sum_j I_b(j)`. For `N` independent photon positions drawn from a conditional multinomial model, the bit log-likelihood ratio is:

\[\Lambda(c)=\log\frac{P(c\mid b=1)}{P(c\mid b=0)}=\sum_i c_i\log\frac{p_1(i)}{p_0(i)}.\]

Multinomial combinatorial factors cancel. Count noise and sample randomness are simulated with NumPy using a seeded generator. There is no measured polarization, optical carrier electric field, spin or wavefunction collapse.

Two bits pack to one of four v0.7 symbolic states, and four symbols pack to a byte. The lock-checked `pack4`, `unpack4` and `QuadEncoder` source is executed. The symbols `-0` and `0` are **different labels only**.

## B. Independent original neuron gating

The byte-checked v0.1 neuron retains its exact mathematical update and original constants:

\[D=2R+1.2G-1.4B,\qquad \tau_v\dot u=-u+D,\quad \tau_v=0.5\text{ model seconds}.\]

Original pulse threshold, refractory time and bounded feedback remain unchanged. Each of four specialist nodes and each spawned compositional descendant has a unique instance. Received evidence drives normalized `R` stimulation; firing events authorize finite candidate-scoring batches. **The neuron does not compute the Bayesian score or invent rules.** Those are conventional algorithms programmed in the coordinator.

## C. Soft inference over a known finite grammar

Each training observation has four calibrated input-bit LLRs and four output-bit LLRs. Conditional log probability for a four-bit integer `x` is the sum of Bernoulli log posteriors for each bit (uniform bit prior). Given a candidate deterministic rule `f: {0..15}->{0..15}`, the evidence for a single observed pair is obtained by summing over the *unknown transmitted input*:

\[L_f(o_x,o_y)=\log\left[\frac1{16}\sum_{x=0}^{15}P(o_x\mid x)P(o_y\mid f(x))\right].\]

The implementation uses posterior-bit products and omits a model-independent additive `-ln(16)` term. It is equivalent for **ranking these deterministic hypotheses** under the stated uniform input prior (but its raw scores must not be interpreted as absolute detector log-likelihood without restoring constants). Numerically stable log-sum-exp avoids underflow. Up to ten labeled training examples are available; the other six examples are never consulted until evaluation.

A pure conventional serial solver uses **the same exact score and grammar**, so accuracy should match. Its matching performance is a critical negative control against claims that Ripple's spiking improves mathematical inference.

The grammar contains 193 **distinct 4-bit mapping functions**, deduplicated by complete truth table. Primitive features include XOR, modular addition, cyclic bit rotation, bit reversal and Gray encoding. Permitted compositions are two-operator forms `rotate(xor(x))`, `xor(add(x))`, and `xor(reverse(x))`. These are executable generated mathematical functions from a bounded hand-written grammar, not open-ended source synthesis, general-language reasoning, cryptanalysis of modern encryption or spontaneous cognition.

## D. Evidence revision, refusal and diagnostic metrics

The colony first receives three examples, scores hypotheses, and progressively requests more **training** examples if score separation is insufficient; a minimum four examples are used for approval. Hypothesis margin ≥4 is the heuristic separation criterion. The recorded trace logs each tested rule, score and when new observations are requested.

For an **absolute** code-fit check, compare the leading rule's model evidence against `Y` independent of `X`, uniform across 16 outputs. Without restoring model-independent constants, the uniform output-null score is `-n*ln(16)`. A promotion requires model evidence gain of at least 2 log units over that null. This is a chosen engineering gate; it is *not* a calibrated posterior probability that a rule is scientifically true. If neither gate passes, labels remain `PROVISIONAL_NOT_VALIDATED` or `ABSTAIN_POOR_GRAMMAR_FIT`.

`exactModelPct` in the saved score table checks the complete 16-element mapping **after the experiment**. `holdoutAccuracyPct` scores output prediction for the *received* test input against the *true transmitted* test output; corruption of either nibble can cause failure even when the inferred rule is correct. The tables count even provisional diagnostic predictions; they do not represent automatically approved actions.

## E. Reproduction, sharing and limits

When composed candidate work exceeds 40 mappings and the parent emits a v0.1 firing event after enough examples, two descendant neurons are instantiated with separate membrane/threshold states. Candidate partitions are processed per clone; only top-ranked proposals are shared with the aggregator. At the end of each task, descendants retire. Hard resource cap 7; peak observed 6. This is process scheduling **within one Node.js process**, not a cloud fungal network or new silicon neuron.

## F. Scientific references

1. EPFL, *Neuronal Dynamics*, integrate-and-fire definitions: https://neuronaldynamics.epfl.ch/online/Ch1.S3.html
2. Frozen Ripple Interference Alpha v1.4 `src/physics.py`, preserved in `sources/v14_physics_LOCKED.py`.
3. Original frozen Ripple v0.1 and v0.7 code in `sources/`.
4. General multinomial likelihood and numerical log-sum-exp follow standard probability/computational-statistics mathematics; no claim of inventing the underlying equations.
