import fs from 'node:fs';
import {performance} from 'node:perf_hooks';
import {runCase,stableHash} from './colony.mjs';
const base=new URL('../',import.meta.url);
const data=JSON.parse(fs.readFileSync(new URL('../data/photon_cases.json',import.meta.url)));
const options={soft_colony:{colony:true,composed:true,method:'soft'},soft_serial:{colony:false,composed:true,method:'soft'},
 soft_no_compose:{colony:true,composed:false,method:'soft'},hard_colony:{colony:true,composed:true,method:'hard'}};
const all=[];const measuredMs={};
for(const [name,opt] of Object.entries(options)){
 let start=performance.now(),rows=[];
 for(const c of data.cases)rows.push(runCase(c,opt));
 measuredMs[name]=+(performance.now()-start).toFixed(3);
 for(const r of rows)all.push({...r,variant:name});
}
const group=(xs,keys)=>{
 const map=new Map();for(const x of xs){let k=keys.map(c=>x[c]).join('|');if(!map.has(k))map.set(k,[]);map.get(k).push(x);}
 return [...map].map(([key,a])=>({key,n:a.length,exactModelPct:+(100*a.filter(x=>x.knownCodeRecovered).length/a.length).toFixed(2),
  holdoutAccuracyPct:+(100*a.reduce((s,x)=>s+x.holdoutCorrect,0)/a.reduce((s,x)=>s+x.holdoutTotal,0)).toFixed(2),
  ambiguousPct:+(100*a.filter(x=>x.ambiguous).length/a.length).toFixed(2),
  meanTraining:+(a.reduce((s,x)=>s+x.trainingUsed,0)/a.length).toFixed(2)}));
};
const highlights=[];
for(const kind of ['xor_7','add_5','rotate_1','gray','reverse','xor5_then_rotate1','add4_then_xor3','reverse_then_xor9']){
 const c=data.cases.find(c=>c.kind===kind&&c.seed===101&&c.photons_per_bit===80);
 highlights.push(runCase(c,{traceDetail:true}));
}
const report={schema:'ripple-code-colony-study/1',interpretation:'Mathematical inference with bounded predeclared hypothesis grammar, not cognitive intelligence',
 sourceReference:'Unmodified v0.1 LIF, v0.7 two-bit symbol codec, v1.4 scalar two-slit optics and multinomial photon sampling',
 caseCount:data.cases.length,opticalChannel:data.channel,candidateGrammar:'193 unique mappings including bounded 2-operation compositions',
 groups:{byVariant:group(all,['variant']),byVariantAndPhotons:group(all,['variant','photons']),byVariantAndKind:group(all,['variant','task'])},
 measuredHostElapsedMs:measuredMs,notes:['Host times cover different computation paths: not fair identical-work speed benchmarks.',
  'Soft serial and soft colony evaluate the same grammar; equal predictions establish no inference advantage.',
  'Heldout was never consulted during hypothesis selection. Noise may corrupt both received input and output symbols.',
  'Only predeclared grammar operations can be synthesized; novel-looking expressions do not imply open-ended algorithm invention.'],
 examples:highlights,allResults:all};
const p=new URL('../data/colony_report.json',import.meta.url);fs.writeFileSync(p,JSON.stringify(report,null,2));
console.log(JSON.stringify({cases:data.cases.length,group:report.groups.byVariant,photons:report.groups.byVariantAndPhotons,ms:measuredMs,sha256:stableHash(report)},null,2));
