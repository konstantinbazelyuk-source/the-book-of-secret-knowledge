"""Generate fixed-seed synthetic optical code transmissions using locked v1.4 physics.
No read of any real camera, detector or external network.
"""
import sys,json,hashlib
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'sources'))
from v14_physics_LOCKED import Setup,profile,count_photons

X=np.linspace(-0.006,0.006,41)
L0=profile(X,Setup(visibility=0.02))
L1=profile(X,Setup(visibility=0.98))
P0=L0/L0.sum(); P1=L1/L1.sum()
LOGR=np.log(P1/P0)
# Coherent vs almost-incoherent light is an intentionally engineered binary channel.
TRANSFORMS={
 'xor_7':lambda x:x^7,
 'add_5':lambda x:(x+5)&15,
 'rotate_1':lambda x:((x<<1)|(x>>3))&15,
 'gray':lambda x:x^(x>>1),
 'reverse':lambda x:int(f'{x:04b}'[::-1],2),
 'xor5_then_rotate1':lambda x:((((x^5)<<1)|((x^5)>>3))&15),
 'add4_then_xor3':lambda x:((x+4)&15)^3,
 'reverse_then_xor9':lambda x:int(f'{x:04b}'[::-1],2)^9,
}

def transmit_nibble(value,n,rng):
    llr=[]; bits=[]
    for shift in (3,2,1,0):
        b=(value>>shift)&1
        counts=count_photons(P1 if b else P0,n,rng)
        ratio=float(np.dot(counts,LOGR))
        llr.append(round(ratio,6));bits.append(int(ratio>0))
    got=sum(b<<(3-i) for i,b in enumerate(bits))
    return {'llr':llr,'hard':got}

def build():
    tasks=[]
    for seed in [101,202,303,404]:
      for tid,fn in TRANSFORMS.items():
        rng=np.random.default_rng(seed*7919+sum(map(ord,tid)))
        perm=list(map(int,rng.permutation(16)))
        for photons in (6,20,80,320):
          # independent RNG per code transmission condition; fixed seeded data
          r=np.random.default_rng(seed*1009+photons*31+sum(map(ord,tid)))
          examples=[]
          for i,x in enumerate(perm):
            y=fn(x)
            examples.append({'index':i,'rx':transmit_nibble(x,photons,r),'ry':transmit_nibble(y,photons,r),
                             'x_true':x,'y_true':y,'split':'train' if i<10 else 'test'})
          tasks.append({'id':f'{tid}_{seed}_n{photons}','kind':tid,'seed':seed,'photons_per_bit':photons,'examples':examples})
    a={'schema':'ripple-photon-code-cases/1','channel':'two-slit visibility 0.02 vs 0.98; multinomial photon bins; no physical instrument',
       'wavelength_m':532e-9,'screen_bins':len(X),'slit_separation_m':0.0003,'slit_width_m':0.00005,
       'p0':P0.round(12).tolist(),'p1':P1.round(12).tolist(),'cases':tasks}
    target=ROOT/'data'/'photon_cases.json'
    target.write_text(json.dumps(a,separators=(',',':')))
    print(json.dumps({'cases':len(tasks),'bytes':target.stat().st_size,
       'per_photon_kl_1_vs_0':float(np.sum(P1*LOGR)),
       'per_photon_kl_0_vs_1':float(-np.sum(P0*LOGR)),
       'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}))
if __name__=='__main__':build()
