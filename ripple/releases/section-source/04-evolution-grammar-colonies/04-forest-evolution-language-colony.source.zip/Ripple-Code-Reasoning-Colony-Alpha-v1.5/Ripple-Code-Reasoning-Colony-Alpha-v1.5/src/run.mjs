#!/usr/bin/env node
/** Offline, read-only inspectable CLI. Accepted tasks come only from saved simulated observations. */
import fs from 'node:fs';import {runCase} from './colony.mjs';
const args=process.argv.slice(2),flag=x=>{const i=args.indexOf(x);return i<0?null:args[i+1]};
const dataset=JSON.parse(fs.readFileSync(new URL('../data/photon_cases.json',import.meta.url)));
if(args.includes('--list')){console.log(dataset.cases.map(x=>x.id).join('\n'));process.exit(0)}
const id=flag('--case')||'xor5_then_rotate1_101_n80';const target=dataset.cases.find(x=>x.id===id);
if(!target){console.error('Unknown case; use --list');process.exit(2)}
const method=flag('--method')||'soft';if(!['soft','hard'].includes(method)){console.error('method must be soft or hard');process.exit(2)}
const result=runCase(target,{method,colony:!args.includes('--serial'),composed:!args.includes('--no-compose'),traceDetail:true});
console.log(JSON.stringify(result,null,2));
