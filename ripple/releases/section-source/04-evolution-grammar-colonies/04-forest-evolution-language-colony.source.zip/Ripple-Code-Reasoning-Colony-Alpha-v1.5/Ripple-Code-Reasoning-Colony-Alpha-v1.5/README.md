# Ripple Code-Reasoning Colony Alpha v1.5

**Status:** locally executed mathematical-research Alpha. **No false intelligence claims.** It runs fixed-source numerical neurons and conventional code inference over a finite grammar. It does not understand codes, possess consciousness, learn a general language model, or create unrestricted JavaScript programs.

## What's real and what's synthetic

- **Executable real software:** exact original v0.1 `RippleNeuron`, original v0.7 `QuadEncoder` / `pack4` / `unpack4`, original v1.4 double-slit optics and multinomial photon simulator, colony program, soft-likelihood rule search, separate clone instances, read-only research traces, replayable HTML.
- **Synthetic:** transmitted code examples, photon detections, neuronal time in modeled seconds, evolutionary replication, reasoning challenge labels, and all test observations.
- **Not performed:** any camera/photodiode measurements, remote compute, external app execution, physical light modulation, optical E/B measurements, general intelligence, real self-directed science.

## Quick start

Open `Ripple-Code-Reasoning-Colony-Alpha-v1.5.html` directly in a browser for the offline results explorer. To execute the actual model (Node.js >=18; Python 3 with NumPy for source-data regeneration):

```bash
node src/run.mjs --case xor5_then_rotate1_101_n80
node src/run.mjs --list
node src/run.mjs --case gray_202_n6 --method hard
node src/run.mjs --case xor5_then_rotate1_101_n80 --serial
node src/evaluate.mjs
python src/create_photon_cases.py
python src/build_lab.py
node --test tests/colony.test.mjs
python -m unittest discover -s tests -p 'test_physics.py' -v
python tests/test_browser.py  # Chromium and Playwright optional
```

No paid accounts or network service needed for execution. Regenerating data with exact package dependencies reproduces deterministic samples using fixed NumPy seeds; saved checksum verifies the distributed generated source dataset.

## Results on predeclared synthetic tasks

Eight rules × four independent seeds × four photon budgets = **128 cases**. Each task includes 10 training examples and 6 *independent-in-task* held-out input values (the 16 possible 4-bit inputs are randomly permuted). The selection routine may request training examples progressively. There are 193 unique candidate functions in the allowed grammar, including bounded two-operator compositions.

| Scoring/scheduling variant | Exact model found | Held-out output accuracy |
|---|---:|---:|
| LIF colony + soft Bayesian-style likelihood | 92.97% | 82.29% |
| Conventional serial likelihood inference | 92.97% | 82.29% |
| LIF colony, composed rules absent | 60.16% | 60.16% |
| LIF colony, hard bit decoding | 86.72% | 79.56% |

These descriptive fractions use **the same synthetic tasks and generator family** as the candidate models. They must not be generalized to human reasoning, unseen code families, cryptography, or physical optical links. The serial and colony implementations have no demonstrated difference in decoding accuracy. Their service-time / CPU overhead is not equivalent-work network performance.

By photons per transmitted bit, the soft colony achieved held-out accuracy of **40.10% (6)**, **89.06% (20)**, **100% (80)** and **100% (320)** across 32 cases each. In low-photon scenes the selected rule can still be mathematically correct while individual received input bits are erroneous. Hypothesis uncertainty is explicitly recorded; diagnostic output accuracy includes provisional choices.

## Functional colony and limits

- Four independently instantiated LIF specialists: bitwise, arithmetic, structural, compositional.
- A firing parent may add two independent descendants to partition 158+ compositional candidates, with a hard cap of seven active workers (peak six in recorded runs).
- Each descendant carries an independent neuron state and communicates a bounded candidate shortlist; replication creates **JavaScript objects**, **not OS processes or compute acceleration**.
- Previous clones are retired after the experiment and do not gain unbounded memory or hidden network access.
- Quaternary symbols `-1`, `-0`, `0`, `1` are engineered two-bit labels; they do not represent four measured electromagnetic states.
- Explicit absolute null-model likelihood gate supports `ABSTAIN_POOR_GRAMMAR_FIT` if the observed code is not represented by the finite grammar; zero-information channel supports `ABSTAIN_NO_INFORMATION`.
- No JavaScript source from a task is ever evaluated or compiled. All candidates are known bounded functions. No GitHub branch, device, cloud provider, wallet or live Ripple application was modified.

## Laboratory artifacts

- `src/create_photon_cases.py`: imports the **unchanged v1.4 physics source** and generates visibility-modulated photon observations.
- `src/colony.mjs`: reads the **unchanged v0.1 neuron and v0.7 quaternary module**; implements bounded program inference, LIF admission, confidence and model-fit checks.
- `src/evaluate.mjs`: runs all conditions and three ablation baselines, stores traceable results.
- `src/run.mjs`: offline CLI to run one saved case.
- `data/photon_cases.json`: fixed-seed optical observations. The reference and task labels are evaluator-only.
- `data/colony_report.json`: all 512 case/variant evaluations plus eight deep clone traces.
- `docs/DERIVATIONS_AND_LIMITS.md`, `docs/NEGATIVE_RESULTS.md`, `docs/ALPHA_REQUIREMENTS.md`: mathematical contract and failures.
- `SHA256SUMS.txt`: checksums for the release. Original source hashes verified separately.

## Sources

Original research lineage is preserved by byte-exact standalone copies in `sources/`:
- v0.1 neuron SHA-256 `d75d4208e92f19623b127615bd52b4002e85d2c0a59b76471764b55a24294210`
- v0.7 quaternary SHA-256 `9c1879f6bc024e564e5e25b0294ac62b34d67aafffe26f9ddfae52675d66f695`
- v1.4 physics SHA-256 `910bab2c583fd50c5250226f8bd81b9c477c5f6de921be7892a4575bacd17b51`

The v0.1 kernel and v0.7 two-bit coding are user-project source. Optical superposition and integrate-and-fire mathematics are established scientific methods. Any included third-party materials retain their existing license requirements; this release does not relicense them.
