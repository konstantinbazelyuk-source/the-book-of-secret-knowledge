import fs from 'node:fs';
import {performance} from 'node:perf_hooks';
import {FeatureNetwork} from './network.mjs';
const [input,output]=process.argv.slice(2);
if(!input||!output)throw Error('usage: node src/extract_batch.mjs input.json output.f64');
const request=JSON.parse(fs.readFileSync(input,'utf8'));
if(!Array.isArray(request.sequences)||!request.sequences.length)throw Error('nonempty sequences required');
const start=performance.now(),n=new FeatureNetwork(request.config);
let d=null,buffer=null;
for(let i=0;i<request.sequences.length;i++){
 n.reset();const f=n.run(request.sequences[i],request.mode);
 if(d===null){d=f.length;buffer=Buffer.alloc(request.sequences.length*d*8);}
 if(f.length!==d)throw Error('inconsistent feature dimensions');
 for(let j=0;j<d;j++)buffer.writeDoubleLE(f[j],8*(i*d+j));
}
fs.writeFileSync(output,buffer);
const meta={rows:request.sequences.length,columns:d,dtype:'little-endian-float64',elapsed_ms:performance.now()-start,config:request.config,mode:request.mode};
fs.writeFileSync(output+'.json',JSON.stringify(meta));console.log(JSON.stringify(meta));
