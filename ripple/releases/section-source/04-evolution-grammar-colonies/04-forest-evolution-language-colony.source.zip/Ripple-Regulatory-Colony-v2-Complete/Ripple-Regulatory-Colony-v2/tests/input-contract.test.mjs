import test from 'node:test';
import assert from 'node:assert/strict';
import {FeatureNetwork} from '../src/network.mjs';
import {CharlieNeuron} from '../src/charlie.mjs';
import {predictReadout,validateReadout} from '../web/predict.mjs';
import fs from 'node:fs';
const gold=JSON.parse(fs.readFileSync(new URL('./readout-golden.json',import.meta.url)));
test('sparse frames and sequences reject before changing internal cell state',()=>{
 for(const architecture of ['lif','delta','daughter','charlie','mix4','tanh']){
  const net=new FeatureNetwork({architecture});net.step(Array(8).fill(.3));
  const before=JSON.stringify(net),frame=Array(8).fill(.3);delete frame[3];
  assert.throws(()=>net.step(frame));assert.equal(JSON.stringify(net),before);
  const seq=[Array(8).fill(.2),,Array(8).fill(.3)];
  assert.throws(()=>net.run(seq));assert.equal(JSON.stringify(net),before);
 }
});
test('Charlie rejects sparse RGB before changing any state',()=>{
 const c=new CharlieNeuron(),before=JSON.stringify(c);
 assert.throws(()=>c.step([.2,,.3],.1));assert.equal(JSON.stringify(c),before);
});
test('readout rejects sparse saved arrays and sparse features',()=>{
 const m=structuredClone(gold.model);delete m.mean[0];
 assert.throws(()=>validateReadout(m));
 assert.throws(()=>predictReadout(m,gold.input[0]));
 const x=gold.input[0].slice();delete x[0];
 assert.throws(()=>predictReadout(gold.model,x));
});
