import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const lib=await import('../src/charlie.mjs').catch(()=>null);
test('Charlie port reproduces frozen Python state and event traces',()=>{
 assert.equal(typeof lib?.CharlieNeuron,'function');
 const n=new lib.CharlieNeuron();const rows=JSON.parse(fs.readFileSync(new URL('./charlie-golden.json',import.meta.url)));
 for(const r of rows){
  const out=n.step(r.rgb,r.dt,{excPulses:r.exc_pulses,inhPulses:r.inh_pulses});
  for(const k of ['t','membrane','exc','inh','adapt','theta','rate_hz'])assert.ok(Math.abs(out[k]-r.output[k])<1e-10,`${k}: ${out[k]} vs ${r.output[k]}`);
  assert.equal(out.count,r.output.count);assert.equal(out.events.length,r.output.events.length);
  for(let i=0;i<out.events.length;i++)assert.ok(Math.abs(out.events[i]-r.output.events[i])<1e-10);
 }
});
