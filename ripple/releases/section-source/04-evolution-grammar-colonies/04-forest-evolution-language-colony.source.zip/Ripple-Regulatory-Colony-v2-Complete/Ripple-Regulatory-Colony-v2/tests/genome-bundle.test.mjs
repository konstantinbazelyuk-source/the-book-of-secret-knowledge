import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const lib=await import('../genome/bundle.mjs').catch(()=>null);
const a=JSON.parse(fs.readFileSync(new URL('../models/temporal-mix4.json',import.meta.url)));
const x=JSON.parse(fs.readFileSync(new URL('../data/temporal-demo-examples.json',import.meta.url))).examples[0].input;
test('packed genome model runs saved weights and rejects corruption',()=>{
 assert.equal(typeof lib?.packModel,'function');
 const b=lib.packModel(a),result=lib.predictBundle(JSON.parse(JSON.stringify(b)),x);
 assert.equal(result.features,128);assert.equal(b.sha256.length,64);
 const changed=structuredClone(b);changed.artifact.readout.coef[0][0]+=.1;
 assert.throws(()=>lib.predictBundle(changed,x),/integrity/i);
 const wrong=structuredClone(b);wrong.genome.codons[4][0]=23;
 assert.throws(()=>lib.predictBundle(wrong,x));
});
