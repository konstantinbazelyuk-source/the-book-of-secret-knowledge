import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {RegulatoryColony} from '../colony/inference.mjs';
const path=new URL('../colony/artifacts/model-sealed.json',import.meta.url);
const original=new URL('../colony/artifacts/model.json',import.meta.url);
function model(){return JSON.parse(fs.readFileSync(fs.existsSync(path)?path:original,'utf8'));}
test('fitted heads, options and expressed genomes are bound together',()=>{
 const swapped=model();[swapped.members[0].head,swapped.members[1].head]=[swapped.members[1].head,swapped.members[0].head];
 assert.throws(()=>new RegulatoryColony(swapped),/binding|integrity/i);
 const changed=model();changed.members[0].options.wave=false;
 assert.throws(()=>new RegulatoryColony(changed),/binding|integrity/i);
});
test('model mutation after construction cannot alter the loaded colony',()=>{
 const m=model(),net=new RegulatoryColony(m),x=Array.from({length:24},(_,t)=>Array.from({length:8},(_,j)=>((t*13+j*7)%31)/31)),before=net.predict(x);
 m.weights[0]=-1;m.members[0].head.readout.intercept[0]+=100;
 assert.deepEqual(net.predict(x),before);
});
