import test from 'node:test';
import assert from 'node:assert/strict';
const m=await import('../colony/network.mjs').catch(()=>null);
const x=Array.from({length:24},(_,t)=>Array.from({length:8},(_,j)=>((t*13+j*7)%31)/31));
test('mandatory regulatory genome builds an executable resettable 16-cell phenotype',()=>{
 assert.equal(typeof m?.RegulatoryNetwork,'function');
 const g=m.makeAncestor(),n=new m.RegulatoryNetwork(g),f=n.run(x);
 assert.equal(f.length,80);assert.ok(f.every(Number.isFinite));assert.deepEqual(n.run(x),f);
 assert.throws(()=>new m.RegulatoryNetwork(null));
 const bad=structuredClone(g);delete bad.codons[1][1];assert.throws(()=>new m.RegulatoryNetwork(bad));
 const before=JSON.stringify(n);const sparse=Array(8).fill(.5);delete sparse[2];
 assert.throws(()=>n.run([sparse]));assert.equal(JSON.stringify(n),before);
});
test('passive optical gates conserve norm and are invertible',()=>{
 assert.ok(m);const a={re:[.2,.4,.1,.9],im:[.1,-.4,.3,.2]};
 const energy=z=>z.re.reduce((s,v,i)=>s+v*v+z.im[i]**2,0);
 const b=m.passiveGate(a,0,3,.37,.82),c=m.passiveGate(b,0,3,-.37,.82);
 assert.ok(Math.abs(energy(a)-energy(b))<1e-14);
 assert.ok(a.re.every((v,i)=>Math.abs(v-c.re[i])<1e-14));
 assert.ok(a.im.every((v,i)=>Math.abs(v-c.im[i])<1e-14));
});
test('every expressed gene field has measurable causal influence',()=>{
 assert.ok(m);const g=m.makeAncestor(),base=new m.RegulatoryNetwork(g).run(x);
 for(const field of ['type','projection','clock','normalization','phase','coupling']){
  const child=m.mutateField(g,0,field),changed=new m.RegulatoryNetwork(child).run(x);
  assert.notDeepEqual(changed,base,field+' is inert');
 }
 const noWave=new m.RegulatoryNetwork(g,{wave:false}).run(x);
 assert.notDeepEqual(noWave,base);
});
test('compiled optical layer equals its gate circuit and conserves normalized energy',()=>{
 assert.ok(m);const n=new m.RegulatoryNetwork(m.makeAncestor()),frame=x[3];
 let a={re:frame.map(Math.sqrt),im:Array(8).fill(0)};
 for(const e of n.expression)a=m.passiveGate(a,e.p,e.q,e.theta,e.phase);
 const expected=a.re.map((v,j)=>(v*v+a.im[j]**2)/8),actual=n.optical(frame);
 assert.ok(expected.every((v,j)=>Math.abs(v-actual[j])<1e-14));
 assert.ok(Math.abs(actual.reduce((a,b)=>a+b,0)-frame.reduce((a,b)=>a+b,0)/8)<1e-14);
});
