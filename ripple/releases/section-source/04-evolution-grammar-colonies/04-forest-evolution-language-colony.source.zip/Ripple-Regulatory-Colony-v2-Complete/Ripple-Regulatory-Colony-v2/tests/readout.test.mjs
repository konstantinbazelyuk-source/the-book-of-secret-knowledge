import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const lib=await import('../web/predict.mjs').catch(()=>null);
const g=JSON.parse(fs.readFileSync(new URL('./readout-golden.json',import.meta.url)));
test('browser-compatible learned readout matches Python scores and predictions',()=>{
 assert.equal(typeof lib?.predictReadout,'function');
 for(let i=0;i<g.input.length;i++){
  const r=lib.predictReadout(g.model,g.input[i]);assert.equal(r.label,g.labels[i]);
  for(let j=0;j<r.scores.length;j++)assert.ok(Math.abs(r.scores[j]-g.scores[i][j])<1e-12);
 }
});
test('readout rejects wrong dimensions and malformed saved weights',()=>{
 assert.ok(lib);assert.throws(()=>lib.predictReadout(g.model,[0]));
 assert.throws(()=>lib.predictReadout({...g.model,scale:[-1,1]},[0,0]));
 assert.throws(()=>lib.predictReadout({...g.model,coef:[[1,2]]},[0,0]));
});
test('artifact class names use the model class order for noncontiguous labels',()=>{
 assert.ok(lib);const readout={...g.model,classes:[3,9]};
 const artifact={readout,frames:1,network:{},mode:'final',class_names:['first','second']};
 const result=lib.predictArtifact(artifact,[[0]],()=>g.input[1]);
 assert.equal(result.label,9);assert.equal(result.class_name,'second');
});
