import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {extractSequence} from '../src/network.mjs';
import {predictArtifact} from '../web/predict.mjs';
const g=await import('../genome/codec.mjs').catch(()=>null);
const a=JSON.parse(fs.readFileSync(new URL('../models/temporal-mix4.json',import.meta.url)));
const x=JSON.parse(fs.readFileSync(new URL('../data/temporal-demo-examples.json',import.meta.url))).examples[0].input;
test('RGB genome compiles to exact model blueprint and identical predictions',()=>{
 assert.equal(typeof g?.encodeGenome,'function');
 const genome=g.encodeGenome(a),b=g.decodeGenome(genome);
 assert.equal(genome.codons.length,5);assert.deepEqual(b,{network:a.network,mode:a.mode,frames:a.frames});
 assert.deepEqual(g.predictGenome(genome,a,x),predictArtifact(a,x,extractSequence));
});
test('heritable genes alter actual network dynamics and require a matching readout',()=>{
 assert.ok(g);const parent=g.encodeGenome(a),before=JSON.stringify(parent);
 const child=g.mutateGenome(parent,{seed:23,architecture:'daughter'}),b=g.decodeGenome(child);
 assert.equal(JSON.stringify(parent),before);assert.equal(b.network.seed,23);
 assert.notDeepEqual(extractSequence(x,b.network,b.mode),extractSequence(x,a.network,a.mode));
 assert.throws(()=>g.predictGenome(child,a,x),/retrain|match/i);
 const crossed=g.crossGenomes(parent,child,['seed']);
 assert.equal(g.decodeGenome(crossed).network.seed,23);
 assert.equal(g.decodeGenome(crossed).network.architecture,'mix4');
});
test('schema, byte, quantization and compilation limits are explicit',()=>{
 assert.ok(g);const parent=g.encodeGenome(a);
 for(const value of [-1,256,1.5,NaN]){const bad=structuredClone(parent);bad.codons[1][0]=value;assert.throws(()=>g.decodeGenome(bad));}
 const sparse=structuredClone(parent);delete sparse.codons[2][1];assert.throws(()=>g.decodeGenome(sparse));
 const bad=structuredClone(parent);bad.codons[0][0]=0;assert.throws(()=>g.decodeGenome(bad));
 assert.throws(()=>g.mutateGenome(parent,{magic:42}));
 assert.throws(()=>g.mutateGenome(parent,{dt:.10001}));
 assert.throws(()=>g.mutateGenome(parent,{units:65}));
 assert.throws(()=>g.mutateGenome(parent,{mode:'trajectory',frames:256}));
 assert.throws(()=>g.crossGenomes(parent,parent,['unknown']));
 for(const seed of [0,1,11,4294967295])assert.equal(g.decodeGenome(g.mutateGenome(parent,{seed})).network.seed,seed);
});
