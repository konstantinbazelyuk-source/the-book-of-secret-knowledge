import unittest
import numpy as np
try:from colony.head import fit_head,predict_head
except ImportError:fit_head=predict_head=None
class ColonyHeadTests(unittest.TestCase):
 def test_associative_readout_learns_a_context_interaction(self):
  self.assertTrue(callable(fit_head));r=np.random.default_rng(37)
  x=r.choice([-1.,1.],(120,2))+r.normal(0,.05,(120,2));y=(x[:,0]*x[:,1]>0).astype(int)
  model=fit_head(x[:80],y[:80],'quadratic',1.)
  self.assertGreater(np.mean(predict_head(model,x[80:])['labels']==y[80:]),.95)
  self.assertEqual(model['readout']['fit_rows'],80)
  np.testing.assert_allclose(model['base_mean'],x[:80].mean(0))
 def test_invalid_kind_and_features_rejected(self):
  self.assertTrue(callable(fit_head));x=np.array([[0.,1.],[1.,0.]])
  with self.assertRaises(ValueError):fit_head(x,[0,1],'invented',1.)
if __name__=='__main__':unittest.main()
