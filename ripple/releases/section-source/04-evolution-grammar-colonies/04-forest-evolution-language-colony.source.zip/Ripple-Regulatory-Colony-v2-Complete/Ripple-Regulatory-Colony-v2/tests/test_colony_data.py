import unittest
import numpy as np
try:from colony.data import make_task,passive_matrix
except ImportError:make_task=passive_matrix=None
class ColonyDataTests(unittest.TestCase):
 def test_context_templates_stay_disjoint_and_keep_order_counterfactuals(self):
  self.assertTrue(callable(make_task));d=make_task()
  self.assertEqual(d['X'].shape,(1152,24,8));self.assertTrue(np.isfinite(d['X']).all())
  for a,b in [('train','val'),('val','test'),('train','test')]:
   self.assertFalse(set(d['groups'][d[a]])&set(d['groups'][d[b]]))
  for group in range(96):
   x=d['X'][d['groups']==group]
   for subset in [x[:6],x[6:]]:
    base=sorted(map(tuple,subset[0]))
    for seq in subset[1:]:self.assertEqual(base,sorted(map(tuple,seq)))
   self.assertFalse(np.array_equal(d['y'][d['groups']==group][:6],d['y'][d['groups']==group][6:]))
   absent=d['X_no_cue'][d['groups']==group]
   np.testing.assert_array_equal(absent[:6],absent[6:])
 def test_physical_mixer_is_unitary(self):
  self.assertTrue(callable(passive_matrix));u=passive_matrix()
  np.testing.assert_allclose(u.conj().T@u,np.eye(8),atol=1e-14)
if __name__=='__main__':unittest.main()
