import unittest
try:
 from src.benchmark import PROTOCOL,select_architecture
except ImportError:
 PROTOCOL=select_architecture=None
class ProtocolTests(unittest.TestCase):
 def test_search_budget_is_frozen_and_contains_all_prespecified_seeds(self):
  self.assertIsInstance(PROTOCOL,dict)
  self.assertEqual(PROTOCOL['seeds'],[11,23,47,89,131])
  self.assertEqual(PROTOCOL['alpha_grid'],[.01,1,100])
  self.assertEqual(PROTOCOL['units'],32)
 def test_selection_aggregates_all_seeds_and_ignores_test_scores(self):
  self.assertTrue(callable(select_architecture))
  rows=[]
  for s in [11,23,47,89,131]:
   rows.extend([{'architecture':'lif','seed':s,'val_accuracy':.8,'test_accuracy':0},
                {'architecture':'mix4','seed':s,'val_accuracy':.7,'test_accuracy':1}])
  self.assertEqual(select_architecture(rows)['architecture'],'lif')
 def test_incomplete_seed_comparison_is_rejected(self):
  self.assertTrue(callable(select_architecture))
  with self.assertRaises(ValueError):select_architecture([{'architecture':'lif','seed':11,'val_accuracy':1}])
if __name__=='__main__':unittest.main()
