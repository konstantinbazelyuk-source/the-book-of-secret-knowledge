import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {extractSequence} from '../src/network.mjs';
import {predictArtifact} from '../web/predict.mjs';
test('standalone saved AI executes the same learned inference as the module',()=>{
 const url=new URL('../web/Ripple-Fusion-AI.html',import.meta.url);
 assert.ok(fs.existsSync(url),'standalone trained AI HTML has not been built');
 const html=fs.readFileSync(url,'utf8');
 const script=html.match(/<script id="ripple-model">([\s\S]*?)<\/script>/)?.[1];
 assert.ok(script);const box={console,performance};box.globalThis=box;vm.runInNewContext(script,box);
 const api=box.RippleFusion;assert.equal(typeof api?.infer,'function');
 for(const task of ['digits','temporal']){
  const examples=JSON.parse(fs.readFileSync(new URL(`../data/${task}-demo-examples.json`,import.meta.url)));
  for(const e of examples.examples.slice(0,12)){
   for(const key of Object.keys(api.models).filter(k=>k.startsWith(task+'-'))){
    const a=api.models[key],standalone=api.infer(key,e.input),modular=predictArtifact(a,e.input,extractSequence);
    assert.equal(standalone.label,modular.label);
    for(let j=0;j<standalone.scores.length;j++)assert.ok(Math.abs(standalone.scores[j]-modular.scores[j])<1e-10);
   }
  }
 }
});
