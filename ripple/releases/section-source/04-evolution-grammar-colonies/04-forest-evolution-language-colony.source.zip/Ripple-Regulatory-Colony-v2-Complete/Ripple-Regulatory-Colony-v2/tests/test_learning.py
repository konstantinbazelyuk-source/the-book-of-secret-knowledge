import unittest,json
import numpy as np
try:
 from src.readout import fit_readout,predict,validate_model
 from src.datasets import make_temporal,load_digits_task
except ImportError:
 fit_readout=predict=validate_model=make_temporal=load_digits_task=None

class LearningTests(unittest.TestCase):
 def test_readout_exists_and_learns_labels_on_unseen_inputs(self):
  self.assertTrue(callable(fit_readout))
  x=np.array([[-2.],[-1.],[1.],[2.]])
  m=fit_readout(x,np.array([0,0,1,1]),alpha=.01)
  np.testing.assert_array_equal(predict(m,[[-1.5],[1.5]])['labels'],[0,1])
  self.assertLess(m['training_mse'],m['untrained_training_mse'])
  self.assertGreater(np.linalg.norm(m['coef']),0)
 def test_scaler_uses_only_fitting_rows(self):
  self.assertTrue(callable(fit_readout))
  m=fit_readout([[-2],[-1],[1],[2]],[0,0,1,1],1)
  np.testing.assert_allclose(m['mean'],[0])
  before=json.dumps(m);predict(m,[[999],[-999]])
  self.assertEqual(json.dumps(m),before)
 def test_saved_json_reproduces_model_predictions(self):
  self.assertTrue(callable(fit_readout))
  m=fit_readout([[-2],[-1],[1],[2]],[0,0,1,1],.01)
  restored=json.loads(json.dumps(m))
  np.testing.assert_allclose(predict(m,[[.5],[-.5]])['scores'],predict(restored,[[.5],[-.5]])['scores'])
 def test_nonfinite_training_and_incompatible_models_are_rejected(self):
  self.assertTrue(callable(fit_readout))
  with self.assertRaises(ValueError):fit_readout([[float('nan')],[1]],[0,1],1)
  m=fit_readout([[-1],[1]],[0,1],1);m['coef']=[[1]]
  with self.assertRaises(ValueError):validate_model(m)
 def test_constant_correlated_features_remain_finite(self):
  self.assertTrue(callable(fit_readout))
  m=fit_readout([[1,1],[1,1],[1,1],[1,1]],[0,1,0,1],1)
  self.assertTrue(np.isfinite(predict(m,[[1,1]])['scores']).all())
 def test_temporal_groups_have_same_bag_and_final_frame_with_different_labels(self):
  self.assertTrue(callable(make_temporal))
  d=make_temporal();x=d['X'];y=d['y'];g=d['groups']
  for group in np.unique(g):
   rows=x[g==group]
   self.assertEqual(set(y[g==group]),set(range(6)))
   for z in rows[1:]:
    np.testing.assert_allclose(z.mean(axis=0),rows[0].mean(axis=0),atol=1e-14)
    np.testing.assert_array_equal(z[-1],rows[0][-1])
    self.assertEqual(sorted(map(tuple,z)),sorted(map(tuple,rows[0])))
 def test_partitions_do_not_share_examples_or_temporal_templates(self):
  self.assertTrue(callable(make_temporal))
  d=make_temporal();g=d['groups'];s=d['splits']
  for a,b in [('train','val'),('train','test'),('val','test')]:
   self.assertFalse(set(s[a])&set(s[b]));self.assertFalse(set(g[s[a]])&set(g[s[b]]))
  self.assertEqual(len(set(np.concatenate(list(s.values())))),len(g))
 def test_digits_are_recorded_known_data_with_new_disjoint_split(self):
  self.assertTrue(callable(load_digits_task))
  d=load_digits_task();self.assertEqual(d['X'].shape,(1797,8,8));self.assertEqual(len(set(d['y'])),10)
  self.assertTrue(d['previously_studied']);self.assertFalse(d['writer_disjoint'])
  self.assertEqual(len(set(np.concatenate(list(d['splits'].values())))),1797)

if __name__=='__main__':unittest.main()
