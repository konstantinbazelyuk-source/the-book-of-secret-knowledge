import unittest
import numpy as np
from src.benchmark import metric

class UncertaintyTests(unittest.TestCase):
 def test_grouped_metric_resamples_templates_and_omits_binomial_interval(self):
  truth=np.zeros(18,dtype=int);pred=np.repeat([0,1,0],6)
  result=metric(pred,truth,groups=np.repeat([8,9,10],6))
  self.assertNotIn('wilson95',result)
  self.assertEqual(result['resampling_units'],3)
  self.assertEqual(result['accuracy'],2/3)
  self.assertEqual(result['cluster_bootstrap95'],[0.0,1.0])
 def test_ordinary_metric_keeps_image_interval(self):
  result=metric(np.array([0,1]),np.array([0,0]))
  self.assertIn('wilson95',result)
if __name__=='__main__':unittest.main()
