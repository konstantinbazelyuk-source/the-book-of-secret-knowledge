import test from 'node:test';
import assert from 'node:assert/strict';
const lib=await import('../src/network.mjs').catch(()=>null);
const config={architecture:'mix4',units:32,inputDim:8,seed:11,dt:.1,coupling:.12};
const sequence=Array.from({length:24},(_,t)=>Array.from({length:8},(_,c)=>(t*13+c*7)%23/23));
test('network implementation exports label-free extractSequence',()=>assert.equal(typeof lib?.extractSequence,'function'));
test('a mixed network emits declared finite state features',()=>{
 assert.ok(lib);const f=lib.extractSequence(sequence,config,'final');
 assert.equal(f.length,128);assert.ok(f.every(Number.isFinite));
});
test('independent sequence reset is reproducible and ignores prior state',()=>{
 assert.ok(lib);const n=new lib.FeatureNetwork(config);const first=n.run(sequence,'final');
 n.run(sequence.toReversed(),'final');n.reset();
 assert.deepEqual(n.run(sequence,'final'),first);
});
test('invalid input is rejected before state mutation',()=>{
 assert.ok(lib);const n=new lib.FeatureNetwork(config);n.step(sequence[0]);const before=n.snapshot();
 assert.throws(()=>n.step([NaN,...sequence[0].slice(1)]));assert.deepEqual(n.snapshot(),before);
 assert.throws(()=>n.step([1,2]));assert.deepEqual(n.snapshot(),before);
});
test('all supported architectures emit finite resettable trajectory state',()=>{
 assert.ok(lib);for(const architecture of ['lif','delta','daughter','charlie','mix3','mix4','mix4_no_links','tanh']){
 const f=lib.extractSequence(sequence.slice(0,8),{...config,architecture},'trajectory');
 assert.equal(f.length,1024);assert.ok(f.every(Number.isFinite));}
});
test('unsupported architecture and timestep are rejected',()=>{
 assert.ok(lib);assert.throws(()=>new lib.FeatureNetwork({...config,architecture:'magic'}));
 assert.throws(()=>new lib.FeatureNetwork({...config,dt:0}));
 assert.throws(()=>new lib.FeatureNetwork({...config,dt:.3}));
});
test('bounded one-step coupling is recorded and has no instantaneous update order effect',()=>{
 assert.ok(lib);const n=new lib.FeatureNetwork(config);
 assert.ok(n.recurrent.every(row=>row.reduce((s,x)=>s+Math.abs(x),0)<=.120000000001));
 const a=n.run(sequence,'final');const b=lib.extractSequence(sequence,{...config,coupling:0},'final');
 assert.notDeepEqual(a,b);
});
