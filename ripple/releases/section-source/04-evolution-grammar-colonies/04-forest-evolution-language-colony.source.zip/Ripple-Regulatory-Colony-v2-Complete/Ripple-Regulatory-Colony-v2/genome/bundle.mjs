import {createHash} from 'node:crypto';
import {encodeGenome,assertModelMatches,predictGenome} from './codec.mjs';
function digest(genome,artifact){return createHash('sha256').update(JSON.stringify({genome,artifact})).digest('hex');}
export function packModel(artifact){
 const copy=structuredClone(artifact),genome=encodeGenome(copy);assertModelMatches(genome,copy);
 return {schema:'ripple-genome-model-v1',genome,artifact:copy,sha256:digest(genome,copy),
  integrity_note:'SHA-256 detects content changes; it is not an authorship signature.'};
}
export function validateBundle(bundle){
 if(!bundle||bundle.schema!=='ripple-genome-model-v1'||bundle.sha256!==digest(bundle.genome,bundle.artifact))throw Error('genome-model integrity check failed');
 assertModelMatches(bundle.genome,bundle.artifact);return bundle;
}
export function predictBundle(bundle,sequence){validateBundle(bundle);return predictGenome(bundle.genome,bundle.artifact,sequence);}
