/** RGB is a 24-bit digital codon. This codec controls network construction,
 * independently of the three numeric channels used for neuron input.
 * No biology, chemistry, self-replication or improvement guarantee is implied.
 */
import {FeatureNetwork,extractSequence,ARCHITECTURES} from '../src/network.mjs';
import {predictArtifact,validateReadout} from '../web/predict.mjs';
const SCHEMA='ripple-rgb-genome-v1';
const networkFields=['architecture','units','inputDim','seed','dt','coupling'];
const fields=[...networkFields,'mode','frames'];
function blueprint(value){
 if(!value||typeof value!=='object')throw Error('blueprint required');
 const network=new FeatureNetwork(value.network).config;
 if(!['final','trajectory'].includes(value.mode)||!Number.isInteger(value.frames)||value.frames<1||value.frames>256)
  throw Error('valid feature mode and 1..256 frames required');
 if(network.units*4*(value.mode==='trajectory'?value.frames:1)>8192)throw Error('readout feature limit exceeded');
 return {network,mode:value.mode,frames:value.frames};
}
function tick(value,scale,min,max){
 const n=Math.round(value*scale);
 if(n<min||n>max||Math.abs(value-n/scale)>1e-12)throw Error('gene value is outside the exact quantization grid');
 return n;
}
export function encodeGenome(value){
 const b=blueprint(value),n=b.network,s=n.seed>>>0;
 return {schema:SCHEMA,codons:[[82,71,66],[1,ARCHITECTURES.indexOf(n.architecture),n.units],
  [n.inputDim,tick(n.dt,1280,1,256)-1,tick(n.coupling,1275,0,255)],
  [s>>>24,(s>>>16)&255,(s>>>8)&255],[s&255,b.mode==='final'?0:1,b.frames-1]]};
}
export function decodeGenome(g){
 if(!g||g.schema!==SCHEMA||!Array.isArray(g.codons)||g.codons.length!==5)throw Error('invalid RGB genome schema/size');
 for(const row of g.codons)if(!Array.isArray(row)||row.length!==3||Array.from(row).some(x=>!Number.isInteger(x)||x<0||x>255))throw Error('RGB codons require three unsigned bytes');
 const c=g.codons;
 if(c[0][0]!==82||c[0][1]!==71||c[0][2]!==66||c[1][0]!==1||c[1][1]>=ARCHITECTURES.length||c[4][1]>1)throw Error('invalid RGB header, version, architecture or mode');
 const seed=(c[3][0]*16777216+c[3][1]*65536+c[3][2]*256+c[4][0])>>>0;
 return blueprint({network:{architecture:ARCHITECTURES[c[1][1]],units:c[1][2],inputDim:c[2][0],
  dt:(c[2][1]+1)/1280,coupling:c[2][2]/1275,seed},mode:c[4][1]===0?'final':'trajectory',frames:c[4][2]+1});
}
export function mutateGenome(parent,changes){
 const b=decodeGenome(parent);
 if(!changes||typeof changes!=='object'||Array.isArray(changes)||Object.keys(changes).some(k=>!fields.includes(k)))throw Error('unknown gene');
 for(const [k,v] of Object.entries(changes))if(networkFields.includes(k))b.network[k]=v;else b[k]=v;
 return encodeGenome(b);
}
export function crossGenomes(parentA,parentB,inheritFromB){
 const b=decodeGenome(parentB);
 if(!Array.isArray(inheritFromB)||Array.from(inheritFromB).some(k=>!fields.includes(k)))throw Error('unknown crossover gene');
 return mutateGenome(parentA,Object.fromEntries(inheritFromB.map(k=>[k,networkFields.includes(k)?b.network[k]:b[k]])));
}
export function assertModelMatches(genome,artifact){
 decodeGenome(genome);
 if(JSON.stringify(encodeGenome(artifact))!==JSON.stringify({schema:genome.schema,codons:genome.codons}))throw Error('genome does not match fitted readout; retrain after mutation');
 const {d}=validateReadout(artifact.readout),b=decodeGenome(genome);
 if(d!==b.network.units*4*(b.mode==='trajectory'?b.frames:1))throw Error('genome/readout feature dimensions do not match');
 return b;
}
export function predictGenome(genome,artifact,sequence){
 const b=assertModelMatches(genome,artifact);
 return predictArtifact({...artifact,...b},sequence,extractSequence);
}
