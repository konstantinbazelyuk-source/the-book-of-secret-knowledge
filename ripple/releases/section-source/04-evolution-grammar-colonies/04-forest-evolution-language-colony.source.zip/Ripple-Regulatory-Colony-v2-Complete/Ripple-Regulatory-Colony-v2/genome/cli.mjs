import fs from 'node:fs';
import {encodeGenome,decodeGenome,mutateGenome} from './codec.mjs';
import {packModel,predictBundle,validateBundle} from './bundle.mjs';
const [action,input,output,extra]=process.argv.slice(2);
const read=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const write=(p,v)=>fs.writeFileSync(p,JSON.stringify(v,null,2)+'\n');
if(!input)throw Error('Usage: node genome/cli.mjs encode|inspect|pack|run|mutate INPUT [OUTPUT|INPUT_DATA] [CHANGES.json]');
if(action==='encode'){if(!output)throw Error('output required');write(output,encodeGenome(read(input)));}
else if(action==='inspect')console.log(JSON.stringify(decodeGenome(read(input)),null,2));
else if(action==='pack'){if(!output)throw Error('output required');write(output,packModel(read(input)));}
else if(action==='mutate'){if(!output||!extra)throw Error('output and gene-changes JSON required');write(output,mutateGenome(read(input),read(extra)));}
else if(action==='run'){
 if(!output)throw Error('input sequence JSON required');
 const bundle=validateBundle(read(input)),payload=read(output),rows=payload.examples||[{input:payload}];
 console.log(JSON.stringify({kind:'trained inference from RGB-compiled blueprint and fitted readout',
  predictions:rows.map(row=>predictBundle(bundle,row.input))},null,2));
}else throw Error('unknown action');
