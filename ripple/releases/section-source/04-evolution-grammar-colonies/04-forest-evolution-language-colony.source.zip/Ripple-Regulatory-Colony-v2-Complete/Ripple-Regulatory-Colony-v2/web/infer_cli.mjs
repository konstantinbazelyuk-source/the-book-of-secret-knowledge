import fs from 'node:fs';
import {extractSequence} from '../src/network.mjs';
import {predictArtifact} from './predict.mjs';
const [modelFile,inputFile]=process.argv.slice(2);
if(!modelFile||!inputFile)throw Error('Usage: node web/infer_cli.mjs models/temporal-mix4.json data/temporal-demo-examples.json');
const artifact=JSON.parse(fs.readFileSync(modelFile,'utf8')),payload=JSON.parse(fs.readFileSync(inputFile,'utf8'));
const rows=payload.examples||[{input:payload}];
const predictions=rows.map(row=>predictArtifact(artifact,row.input,extractSequence));
console.log(JSON.stringify({kind:'actual trained supervised inference',model:modelFile,predictions},null,2));
