/** Actual affine supervised readout. Scores are uncalibrated, not probabilities. */
const denseEvery=(array,predicate)=>Array.isArray(array)&&Array.from(array).every(predicate);
export function validateReadout(m){
 if(!m||m.schema!=='ripple-ridge-v1'||!denseEvery(m.classes,Number.isInteger)||m.classes.length<2||new Set(m.classes).size!==m.classes.length)throw Error('invalid readout classes/schema');
 const d=m.mean?.length,c=m.classes.length;
 if(!Number.isInteger(d)||d<1||d>8192||m.scale?.length!==d||m.coef?.length!==d||m.intercept?.length!==c)throw Error('incompatible model dimensions');
 if(!denseEvery(m.mean,Number.isFinite)||!denseEvery(m.scale,v=>Number.isFinite(v)&&v>0)||!denseEvery(m.intercept,Number.isFinite)
  ||!denseEvery(m.coef,row=>Array.isArray(row)&&row.length===c&&denseEvery(row,Number.isFinite)))throw Error('invalid saved coefficients');
 return {d,c};
}
export function predictReadout(model,features){
 const {d,c}=validateReadout(model);
 if(!denseEvery(features,Number.isFinite)||features.length!==d)throw Error('feature vector does not match trained readout');
 const scores=model.intercept.slice();
 for(let i=0;i<d;i++){const x=(features[i]-model.mean[i])/model.scale[i];for(let j=0;j<c;j++)scores[j]+=x*model.coef[i][j];}
 if(!scores.every(Number.isFinite))throw Error('nonfinite readout output');
 let best=0;for(let j=1;j<c;j++)if(scores[j]>scores[best])best=j;
 const sorted=scores.slice().sort((a,b)=>b-a);
 return {label:model.classes[best],scores,margin:sorted[0]-sorted[1],scores_are_probabilities:false};
}
export function predictArtifact(artifact,sequence,extractSequence){
 if(!artifact||!Number.isInteger(artifact.frames)||artifact.frames<1||artifact.frames>256||!Array.isArray(sequence)||sequence.length!==artifact.frames)throw Error('wrong number of frames for trained task');
 const {c}=validateReadout(artifact.readout);
 if(!denseEvery(artifact.class_names,x=>typeof x==='string'&&x.length>0)||artifact.class_names.length!==c)throw Error('class names must follow readout class order');
 const features=extractSequence(sequence,artifact.network,artifact.mode);
 const result=predictReadout(artifact.readout,features);
 return {...result,class_name:artifact.class_names[artifact.readout.classes.indexOf(result.label)],features:features.length};
}
