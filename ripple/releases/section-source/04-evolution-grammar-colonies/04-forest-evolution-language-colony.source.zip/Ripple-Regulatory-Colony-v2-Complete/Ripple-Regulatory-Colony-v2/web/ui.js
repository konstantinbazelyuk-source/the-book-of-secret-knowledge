if(typeof document!=='undefined'){
 const api=globalThis.RippleFusion,$=id=>document.getElementById(id);
 const digitCanvas=$('digit'),dc=digitCanvas.getContext('2d'),sc=$('sequence').getContext('2d');
 let image=Array.from({length:8},()=>Array(8).fill(0)),digitExample=-1,orderExample=-1,sequence=null,expected=null,drawing=false;
 const modelList=(task,el)=>{for(const key of Object.keys(api.models).filter(k=>k.startsWith(task+'-'))){const option=document.createElement('option');option.value=key;option.textContent=key.replace(task+'-','');el.append(option);}el.value=task+'-mix4';};
 modelList('digits',$('digit-model'));modelList('temporal',$('temporal-model'));
 for(const order of api.demos.temporal.class_names){const o=document.createElement('option');o.value=order;o.textContent=order;$('order').append(o);}
 function drawDigit(){dc.fillStyle='#142c38';dc.fillRect(0,0,256,256);for(let r=0;r<8;r++)for(let c=0;c<8;c++){const v=Math.round(image[r][c]*255);dc.fillStyle=`rgb(${v},${v},${v})`;dc.fillRect(c*32+1,r*32+1,30,30);}}
 function bars(id,pred,artifact){const node=$(id);node.replaceChildren();const max=Math.max(...pred.scores),min=Math.min(...pred.scores),range=Math.max(1e-9,max-min);pred.scores.forEach((s,i)=>{const row=document.createElement('div');row.className='bar';const label=document.createElement('span');label.textContent=artifact.class_names[i];const line=document.createElement('i');line.style.width=(8+130*(s-min)/range)+'px';const value=document.createElement('em');value.textContent=s.toFixed(3);row.append(label,line,value);node.append(row);});}
 function guard(fn){try{$('error').textContent='';fn();}catch(e){$('error').textContent=String(e.message||e);}}
 let shownGenome=null;
 const genomeSelect=$('genome-model');for(const key of Object.keys(api.models)){const o=document.createElement('option');o.value=key;o.textContent=key;genomeSelect.append(o);}genomeSelect.value='temporal-mix4';
 function showGenome(g){shownGenome=g;const node=$('genome-swatches');node.replaceChildren();for(const rgb of g.codons){const span=document.createElement('span');span.style.borderLeft=`24px solid rgb(${rgb.join(',')})`;span.textContent=rgb.map(v=>v.toString(16).padStart(2,'0')).join('').toUpperCase();node.append(span);}$('genome-detail').textContent=JSON.stringify(api.Genome.decodeGenome(g),null,2);}
 function parentGenome(){showGenome(api.Genome.encodeGenome(api.models[genomeSelect.value]));$('genome-status').textContent='Fitted parent blueprint. Its settings reconstruct the saved network exactly.';}
 function download(name,obj){const url=URL.createObjectURL(new Blob([JSON.stringify(obj,null,2)],{type:'application/json'})),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
 genomeSelect.onchange=()=>guard(parentGenome);
 $('genome-export').onclick=()=>guard(()=>download(genomeSelect.value+'-blueprint.rgb.json',shownGenome));
 $('model-export').onclick=()=>guard(()=>{api.Genome.predictGenome(shownGenome,api.models[genomeSelect.value],api.demos[api.models[genomeSelect.value].task].examples[0].input);download(genomeSelect.value+'.json',api.models[genomeSelect.value]);});
 $('genome-mutate').onclick=()=>guard(()=>{showGenome(api.Genome.mutateGenome(api.Genome.encodeGenome(api.models[genomeSelect.value]),{seed:Number($('gene-seed').value)}));$('genome-status').textContent='Child blueprint compiled. No trained readout is supplied for this mutation. Accuracy is unmeasured; retrain before inference.';});
 parentGenome();
 function digitInfer(){const key=$('digit-model').value,start=performance.now(),p=api.infer(key,image);$('digit-result').textContent=p.class_name;$('digit-detail').textContent=`${(performance.now()-start).toFixed(1)} ms here · ${p.features} features · margin ${p.margin.toFixed(3)}`;bars('digit-bars',p,api.models[key]);}
 function nextDigit(){const rows=api.demos.digits.examples;digitExample=(digitExample+1)%rows.length;image=rows[digitExample].input.map(r=>r.slice());drawDigit();digitInfer();$('digit-detail').textContent+=` · recorded example ${rows[digitExample].index}, label ${rows[digitExample].truth}`;}
 function paint(e){const rect=digitCanvas.getBoundingClientRect(),c=Math.floor((e.clientX-rect.left)*8/rect.width),r=Math.floor((e.clientY-rect.top)*8/rect.height);if(r>=0&&r<8&&c>=0&&c<8){image[r][c]=1;drawDigit();}}
 digitCanvas.addEventListener('pointerdown',e=>{drawing=true;digitCanvas.setPointerCapture(e.pointerId);paint(e);});digitCanvas.addEventListener('pointermove',e=>{if(drawing)paint(e);});digitCanvas.addEventListener('pointerup',()=>drawing=false);digitCanvas.addEventListener('pointercancel',()=>drawing=false);
 $('classify').onclick=()=>guard(digitInfer);$('next-digit').onclick=()=>guard(nextDigit);$('digit-model').onchange=()=>guard(digitInfer);
 $('clear-digit').onclick=()=>{image=Array.from({length:8},()=>Array(8).fill(0));drawDigit();$('digit-result').textContent='—';$('digit-detail').textContent='Draw, then classify.';$('digit-bars').replaceChildren();};
 function drawSequence(){sc.fillStyle='#142c38';sc.fillRect(0,0,480,180);const colors=['#ff8479','#72d39f','#7ab6fa'];for(let ch=0;ch<3;ch++){sc.strokeStyle=colors[ch];sc.lineWidth=2;sc.beginPath();sequence.forEach((v,i)=>{const x=15+i*450/23,y=160-v[ch]*130;i?sc.lineTo(x,y):sc.moveTo(x,y);});sc.stroke();}sc.fillStyle='#cbdde1';sc.font='12px system-ui';sc.fillText('24 frames · 0.1 model second/frame · simulated codes',15,20);}
 function authoredSequence(){const order=$('order').value;sequence=Array.from({length:24},()=>Array(8).fill(0));[3,10,17].forEach((t,i)=>sequence[t]['RGB'.indexOf(order[i])]=.8);expected=order;drawSequence();}
 function inferOrder(){if(!sequence)authoredSequence();const key=$('temporal-model').value,start=performance.now(),p=api.infer(key,sequence);$('order-result').textContent=p.class_name.split('').join(' → ');$('order-detail').textContent=`${(performance.now()-start).toFixed(1)} ms here · ${p.features} final-state features · expected ${expected??'not supplied'} · scores are not probabilities`;bars('order-bars',p,api.models[key]);}
 function nextOrder(){const rows=api.demos.temporal.examples;orderExample=(orderExample+1)%rows.length;const e=rows[orderExample];sequence=e.input.map(r=>r.slice());expected=api.demos.temporal.class_names[e.truth];$('order').value=expected;drawSequence();inferOrder();}
 $('order').onchange=()=>guard(authoredSequence);$('run-order').onclick=()=>guard(inferOrder);$('next-order').onclick=()=>guard(nextOrder);$('temporal-model').onchange=()=>guard(inferOrder);
 const tbody=$('scores').querySelector('tbody');
 for(const task of ['digits','temporal'])for(const arch of ['mix4','charlie','lif','delta','daughter','mix4_no_links','tanh','raw_ordered','raw_rbf']){
  const rows=api.evidence.results.filter(r=>r.task===task&&r.architecture===arch);if(!rows.length)continue;
  const acc=rows.reduce((s,r)=>s+r.accuracy,0)/rows.length,timing=rows.reduce((s,r)=>s+(r.feature_extraction_ms_per_example||0),0)/rows.length;
  const tr=document.createElement('tr');for(const text of [task,arch,`${(100*acc).toFixed(2)}%${rows.length>1?' · 5-seed mean':''}`,timing?`${timing.toFixed(2)} ms/sample`:'raw-input baseline']){const td=document.createElement('td');td.textContent=text;tr.append(td);}tbody.append(tr);
 }
 guard(nextDigit);guard(nextOrder);
}
