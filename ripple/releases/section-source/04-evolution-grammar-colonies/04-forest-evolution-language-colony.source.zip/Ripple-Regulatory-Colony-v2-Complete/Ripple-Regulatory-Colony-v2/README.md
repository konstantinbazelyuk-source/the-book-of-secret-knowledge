# Ripple Regulatory Colony v2

A complete runnable **trained software model** for cue-dependent sequence classification: 50 inherited variants, 16 numerical cells each, 800 cells total and 976,860 fitted readout coefficients/biases. Mandatory per-cell RGB codons control actual cell types, input projections, timescales, normalization, optical phase and delayed recurrence. All 50 fitted members and their learned arrays are included.

This is a task-specific learning system. Its scores and failures are measured on the declared synthetic dataset. It is not a general-purpose language/robot intelligence or a biological/quantum-hardware result.

## Run the trained model

Install Node.js 20 or later. From this extracted directory:

```sh
node colony/infer.mjs colony/artifacts/model-sealed.json colony/artifacts/examples.json
```

No Python, external model service, network connection or API key is needed for inference. For new input, replace the example file with a JSON array of exactly 24 rows × eight finite values in [0,1]. The fitted task is six cue-dependent code-order classes. Scores are uncalibrated and inputs outside the training distribution can be wrong; this is not a calibrated physical sensor model.

The loader validates bindings among each genome, fitted readout, execution options and inference sources. Missing/changed genomes, swapped heads and incompatible options fail loading. A private model copy prevents later caller edits from changing an active colony.

## Executed results

| Model / intervention | Correct / 192 |
|---|---:|
| Deployed 50-member colony | **191 / 192** |
| Validation-selected single member | 176 / 192 |
| Ordered raw-input RBF SVM | 190 / 192 |
| Matched-gain identity-optics colony, post-review audit | 188 / 192 |
| Early context cue removed | 92 / 192 |
| Shuffled-label single-member control | 33 / 192 |

The test has **16 independent templates**, each with 12 related cases. These are not 192 independent worlds or 50 independent datasets. The colony's 0.52-point advantage over SVM and 1.56-point advantage over the matched optical control have paired intervals including zero. No superiority claim follows. Full comparisons, negative findings, uncertainty and actual counts: **colony/RESULTS.md**.

Verification executed all 50 replicas on the full test partition: all exported labels match the frozen experiment; maximum Python/JavaScript score difference 5.33×10⁻¹⁵. All 96 tested gene-field interventions changed features. Six million photon-count variables were generated; those are simulations, not physical trials. The requested 10²³ trials were not run. Analytic invariants and declared numerical checks supplement finite experiments.

## Actual model architecture

- `colony/ARCHITECTURE.md`: complete genotype map, equations, signal path, trainable/fixed parameters, model integrity and inference scope.
- `colony/SCIENTIFIC_BASIS.md`: primary neuroscience and optical sources, with the precise limits of their use.
- `colony/network.mjs`: executable genotype compiler and regulated neuron network, importing preserved Ripple sources.
- `colony/inference.mjs`: actual linear/quadratic readouts and 50-member inference.
- `colony/artifacts/model-sealed.json`: full fitted model; `population.json` records the ancestor, 50 variants and mutation ancestry.
- `colony/artifacts/`: data, splits, every selection, test prediction, equation/gene checks, uncertainty, runtime and export verification.

RGB is a three-byte inherited program here, independent of input color sensing. The implemented optical operations use same-frequency spatial modes; R/G/B are code labels. They do not infer unknown carrier phase from detector intensities or claim coherent mixing of different optical frequencies. No nonclassical advantage is claimed.

## Reproduce fitting and evaluation

Python 3.12, Node.js 20+ and the pinned requirements are sufficient. A closed-form regularized readout is used; no GPU framework is required.

```sh
python -m pip install -r requirements.txt
node colony/extract.mjs population colony/population.json
python -m colony.experiment select
python -m colony.experiment evaluate
python -m colony.matched_control select
python -m colony.matched_control evaluate
python -m colony.physics_checks
node colony/gene_checks.mjs
node colony/seal.mjs colony/artifacts/model.json colony/artifacts/model-sealed.json
python -m colony.verify_export
python -m colony.report
```

Selection uses training/validation only and freezes hashes/choices before scoring. The matched-gain audit was added after review and is explicitly identified as such; it does not tune or replace the full model. The original wave-off comparison also changed gain eightfold and is retained with that confound labeled. Repeating this workflow is reproduction, not fresh independent test data.

The release contains the sealed model with all fitted values. `evaluate` produces the intermediate unsealed fit record `model.json`; `seal` adds bindings without refitting. The redundant unsealed copy is omitted from the downloadable archive. Keep the runtime files with the model because the loader verifies their hashes.

## Verify

```sh
node --test tests/*.test.mjs
python -m unittest discover -s tests -p "test_*.py" -v
```

Tests exercise actual learning, reset, source parity, malformed inputs, grouped counterfactuals, optical norm/inverse, functional gene interventions, readout serialization, fitted-model binding and isolation from caller mutation. Full exported-model comparison is separately recorded in `colony/artifacts/export-verification.json`.

## Preserved work and reuse

Fusion v1's source, trained models, digit/temporal data, offline inference file, evidence and initial RGB blueprint codec are preserved. Its separate instructions are in `docs/FUSION_V1_README.md`; v1 performance must not be substituted for this new v2 task. Original source kernels are unchanged. Independent review and corrections are in `colony/REVIEW.md`, `colony/REVIEW_FOLLOWUP.md` and `colony/RELEASE_NOTES.md`.

New original integration, synthetic data and outputs: **CC0-1.0**. Inherited source notices remain. The preserved recorded digit dataset retains E. Alpaydin & C. Kaynak (1998), UCI Optical Recognition of Handwritten Digits, https://doi.org/10.24432/C50P49, **CC BY 4.0** attribution. Original Ripple concept: **Constantin x**. No public posting or extra paid cloud service was performed by this task.
