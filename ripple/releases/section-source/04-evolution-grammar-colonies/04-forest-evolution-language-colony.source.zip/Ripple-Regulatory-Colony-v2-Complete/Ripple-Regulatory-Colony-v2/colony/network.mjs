/** Executable per-cell regulatory genotype; preserved Ripple neuron sources. */
import '../vendor/legacy/ripple-core.js';
import {DeltaRippleNeuron} from '../vendor/daughter/vault/delta/delta-neuron.mjs';
import {DaughterTripletNeuron} from '../vendor/daughter/src/triplet-neuron.mjs';
import {CharlieNeuron} from '../src/charlie.mjs';
const clip=x=>Math.max(0,Math.min(1,x));
const KINDS=['lif','delta','daughter','charlie'];
function random(seed){let s=seed>>>0||1;return()=>{s^=s<<13;s^=s>>>17;s^=s<<5;return(s>>>0)/4294967296;};}
export function makeAncestor(){return {schema:'ripple-regulatory-genome-v2',codons:Array.from({length:16},(_,i)=>[(i%4)*64+(i*17+9)%64,128+(i*7+3)%16,((i*5+2)%16)*16+8])};}
export function validateGenome(g){
 if(!g||g.schema!=='ripple-regulatory-genome-v2'||!Array.isArray(g.codons)||g.codons.length!==16)throw Error('mandatory 16-codon regulatory genome required');
 for(const c of g.codons)if(!Array.isArray(c)||c.length!==3||Array.from(c).some(v=>!Number.isInteger(v)||v<0||v>255))throw Error('dense RGB byte codons required');
 return g;
}
export function mutateField(parent,index,field){
 validateGenome(parent);if(!Number.isInteger(index)||index<0||index>=16)throw Error('invalid cell index');
 const g={schema:parent.schema,codons:parent.codons.map(c=>c.slice())},c=g.codons[index];
 if(field==='type')c[0]=(((c[0]>>>6)+1)%4)*64+(c[0]&63);
 else if(field==='projection')c[0]=(c[0]&192)+((c[0]+13)&63);
 else if(field==='clock')c[1]=(((c[1]>>>4)+5)%16)*16+(c[1]&15);
 else if(field==='normalization')c[1]=(c[1]&240)+((c[1]+7)&15);
 else if(field==='phase')c[2]=(((c[2]>>>4)+3)%16)*16+(c[2]&15);
 else if(field==='coupling')c[2]=(c[2]&240)+((c[2]+7)&15);
 else throw Error('unknown expressed field');
 return g;
}
/** A lossless complex two-mode rotation. Inverse: same phase, negative theta. */
export function passiveGate(a,p,q,theta,phase){
 if(!a||!Array.isArray(a.re)||!Array.isArray(a.im)||a.re.length!==a.im.length||p===q||!Number.isInteger(p)||!Number.isInteger(q)||p<0||q<0||p>=a.re.length||q>=a.re.length||!Number.isFinite(theta)||!Number.isFinite(phase)||Array.from(a.re).some(v=>!Number.isFinite(v))||Array.from(a.im).some(v=>!Number.isFinite(v)))throw Error('invalid optical amplitude/gate');
 const re=a.re.slice(),im=a.im.slice(),c=Math.cos(theta),s=Math.sin(theta),cp=Math.cos(phase),sp=Math.sin(phase),xr=re[p],xi=im[p],yr=re[q],yi=im[q];
 re[p]=c*xr-s*(cp*yr-sp*yi);im[p]=c*xi-s*(cp*yi+sp*yr);
 re[q]=s*(cp*xr+sp*xi)+c*yr;im[q]=s*(cp*xi-sp*xr)+c*yi;
 return {re,im};
}
function cell(kind){
 if(kind==='lif')return new globalThis.RippleNeuron();
 if(kind==='delta')return new DeltaRippleNeuron({feedforward:false});
 if(kind==='daughter')return new DaughterTripletNeuron();
 return new CharlieNeuron();
}
export class RegulatoryNetwork{
 constructor(genome,options={}){
  validateGenome(genome);
  if(Object.keys(options).some(k=>!['wave'].includes(k))||('wave'in options&&typeof options.wave!=='boolean'))throw Error('invalid phenotype option');
  this.genome={schema:genome.schema,codons:genome.codons.map(c=>c.slice())};this.wave=options.wave??true;
  this.expression=this.genome.codons.map(([r,g,b],i)=>{
   const route=r&63,rand=random(1+route+257*i);
   return {kind:KINDS[r>>>6],clock:.5+(g>>>4)/15,normalization:2*(g&15)/15,phase:2*Math.PI*(b>>>4)/16,
    coupling:.12*(b&15)/15,route,projection:Array.from({length:3},()=>Array.from({length:8},()=>1.2*(2*rand()-1)/Math.sqrt(8))),
    p:i%8,q:(i%8+1+route%7)%8,theta:Math.PI/8+Math.PI*route/252};
  });
  this.Ure=Array.from({length:8},()=>Array(8).fill(0));this.Uim=Array.from({length:8},()=>Array(8).fill(0));
  for(let j=0;j<8;j++){
   let a={re:Array(8).fill(0),im:Array(8).fill(0)};a.re[j]=1;
   for(const e of this.expression)a=passiveGate(a,e.p,e.q,e.theta,e.phase);
   for(let i=0;i<8;i++){this.Ure[i][j]=a.re[i];this.Uim[i][j]=a.im[i];}
  }
  this.reset();
 }
 reset(){this.cells=this.expression.map(e=>cell(e.kind));this.feedback=Array(16).fill(0);this.normalizer=Array(16).fill(0);this.steps=0;}
 optical(frame){
  if(!this.wave)return frame.slice();
  const amplitude=frame.map(Math.sqrt),real=this.Ure.map(row=>row.reduce((s,v,j)=>s+v*amplitude[j],0)),imag=this.Uim.map(row=>row.reduce((s,v,j)=>s+v*amplitude[j],0));
  // Division by 8 bounds every output intensity for any input in [0,1]^8.
  return real.map((v,j)=>clip((v*v+imag[j]**2)/8));
 }
 step(frame){
  if(!Array.isArray(frame)||frame.length!==8||Array.from(frame).some(v=>!Number.isFinite(v)||v<0||v>1))throw Error('finite dense eight-channel frame required');
  const input=this.optical(frame),old=this.feedback.slice(),next=[],f=[];
  for(let i=0;i<16;i++){
   const e=this.expression[i],dt=.1*e.clock;
   const rec=e.coupling*(old[(i+15)%16]-old[(i+3)%16])/2;
   const base=[.42,.24,.14];
   const raw=e.projection.map((w,ch)=>clip(base[ch]+w.reduce((s,v,j)=>s+v*input[j],0)+[1,.2,-1][ch]*rec));
   const decay=Math.exp(-.1/.3),drive=raw.reduce((a,b)=>a+b,0)/3;
   this.normalizer[i]=decay*this.normalizer[i]+(1-decay)*drive;
   const divisor=1+e.normalization*this.normalizer[i],rgb=raw.map(v=>v/divisor),n=this.cells[i];let z,u;
   if(e.kind==='lif'){const o=n.step(rgb,dt);u=o.u;z=[o.u,o.rate,o.theta,o.count];}
   else if(e.kind==='delta'){const o=n.step(rgb,dt);u=o.u;z=[o.u,o.adaptation,o.rate,o.theta];}
   else if(e.kind==='daughter'){const o=n.step(rgb,dt);u=o.u;z=[o.u,o.layer2.dendrite,o.adaptation,o.rate];}
   else{const o=n.step(rgb,dt);u=o.membrane;z=[o.membrane,o.exc-o.inh,o.adapt,o.rate_hz];}
   z.push(this.normalizer[i]);if(z.some(v=>!Number.isFinite(v)))throw Error('nonfinite regulated state');
   f.push(...z);next.push(Math.tanh(u));
  }
  this.feedback=next;this.steps++;return f;
 }
 run(sequence){
  if(!Array.isArray(sequence)||sequence.length<1||sequence.length>256)throw Error('1..256 frames required');
  for(const frame of sequence)if(!Array.isArray(frame)||frame.length!==8||Array.from(frame).some(v=>!Number.isFinite(v)||v<0||v>1))throw Error('invalid sequence before state mutation');
  this.reset();let f;for(const frame of sequence)f=this.step(frame);return f;
 }
}
