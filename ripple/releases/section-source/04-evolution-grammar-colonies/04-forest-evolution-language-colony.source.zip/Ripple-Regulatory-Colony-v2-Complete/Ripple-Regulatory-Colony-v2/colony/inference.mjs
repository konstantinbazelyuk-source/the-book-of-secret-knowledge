import {createHash} from 'node:crypto';
import fs from 'node:fs';
import {RegulatoryNetwork,validateGenome} from './network.mjs';
import {predictReadout,validateReadout} from '../web/predict.mjs';
const dense=(a,p)=>Array.isArray(a)&&Array.from(a).every(p);
// Matches the explicit Python sorted-key JSON used in the frozen model writer.
function canonical(v){
 if(Array.isArray(v))return '['+v.map(canonical).join(', ')+']';
 if(v&&typeof v==='object')return '{'+Object.keys(v).sort().map(k=>JSON.stringify(k)+': '+canonical(v[k])).join(', ')+'}';
 return JSON.stringify(v);
}
export function genomeHash(g){validateGenome(g);return createHash('sha256').update(canonical(g)).digest('hex');}
export function runtimeDigest(){
 const files=['colony/inference.mjs','colony/infer.mjs','colony/network.mjs','web/predict.mjs','src/charlie.mjs',
  'vendor/legacy/ripple-core.js','vendor/daughter/src/triplet-neuron.mjs',
  'vendor/daughter/vault/delta/delta-neuron.mjs','vendor/daughter/vault/delta/photometry.mjs'];
 const h=createHash('sha256');for(const p of files.sort()){h.update(p);h.update(fs.readFileSync(new URL('../'+p,import.meta.url)));}return h.digest('hex');
}
export function memberBinding(model,member){
 return createHash('sha256').update(JSON.stringify({feature_experiment_source:model.source_sha256,
  inference_source:model.inference_source_sha256,genome:member.genome,options:member.options,head:member.head})).digest('hex');
}
export function predictHead(head,features){
 if(!head||head.schema!=='ripple-associative-head-v2'||!['linear','quadratic'].includes(head.kind)||!dense(head.base_mean,Number.isFinite)||!dense(head.base_scale,x=>Number.isFinite(x)&&x>0)||head.base_mean.length!==features.length||head.base_scale.length!==features.length||!dense(features,Number.isFinite))throw Error('invalid associative head or neural state');
 const z=features.map((v,i)=>(v-head.base_mean[i])/head.base_scale[i]),lift=z.slice();
 if(head.kind==='quadratic')for(let i=0;i<z.length;i++)for(let j=i;j<z.length;j++)lift.push(z[i]*z[j]);
 return predictReadout(head.readout,lift);
}
export class RegulatoryColony{
 #model;#networks;
 constructor(model){
  if(!model||model.schema!=='ripple-regulatory-colony-v2'||model.frames!==24||model.inputDim!==8||!Array.isArray(model.members)||model.members.length!==50||!dense(model.weights,x=>Number.isFinite(x)&&x>0)||model.weights.length!==50||Math.abs(model.weights.reduce((a,b)=>a+b,0)-1)>1e-10||!dense(model.classes,x=>typeof x==='string')||model.classes.length!==6)throw Error('invalid 50-replica colony model');
  if(model.inference_source_sha256!==runtimeDigest())throw Error('inference source integrity mismatch');
  const ids=new Set();
  for(const m of model.members){
   if(!m||!Number.isInteger(m.id)||ids.has(m.id)||m.genome_sha256!==genomeHash(m.genome))throw Error('missing/modified genome or replica identity');ids.add(m.id);
   if(m.fitted_binding_sha256!==memberBinding(model,m))throw Error('fitted head/phenotype binding integrity mismatch');
   if(m.head?.base_mean?.length!==80||m.head?.base_scale?.length!==80)throw Error('80 neural states required');
   const {d,c}=validateReadout(m.head.readout);
   if(c!==6||JSON.stringify(m.head.readout.classes)!=='[0,1,2,3,4,5]'||d!==(m.head.kind==='quadratic'?3320:80))throw Error('incompatible readout');
   predictHead(m.head,Array(80).fill(0));
  }
  this.#model=structuredClone(model);this.#networks=this.#model.members.map(m=>new RegulatoryNetwork(m.genome,m.options));
 }
 predict(sequence){
  if(!Array.isArray(sequence)||sequence.length!==24)throw Error('24 frames required for this trained model');
  const scores=Array(6).fill(0),replica_labels=[];
  for(let i=0;i<50;i++){
   const features=this.#networks[i].run(sequence),out=predictHead(this.#model.members[i].head,features);
   replica_labels.push(out.label);out.scores.forEach((v,j)=>scores[j]+=this.#model.weights[i]*v);
  }
  if(!scores.every(Number.isFinite))throw Error('nonfinite aggregate scores');
  let label=0;for(let j=1;j<6;j++)if(scores[j]>scores[label])label=j;
  return {label,class_name:this.#model.classes[label],scores,scores_are_probabilities:false,
   replicas_executed:50,numerical_cells:800,replica_labels};
 }
}
