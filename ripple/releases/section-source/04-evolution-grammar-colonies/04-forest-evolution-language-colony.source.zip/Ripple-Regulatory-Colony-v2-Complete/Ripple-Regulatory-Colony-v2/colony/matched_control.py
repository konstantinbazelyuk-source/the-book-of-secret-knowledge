"""Audit extension: identity optical transform at matched gain, no full-model tuning."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import argparse,json
import numpy as np
from threadpoolctl import threadpool_limits
from .experiment import OUT,ROOT,features,jobs,choose_head,aggregate_choices,sha,digest
from .data import make_task
from .head import fit_head,predict_head
from src.benchmark import metric,bootstrap_difference
def write(p,x):Path(p).write_text(json.dumps(x,indent=2,allow_nan=False))
def control_jobs():
 return [{**j,'key':'matched-'+str(j['id']).zfill(2),'family':'matched'} for j in jobs() if j['family']=='wave_off']
def audit_digest():return sha((ROOT/'colony/matched_control.py').read_bytes()+(ROOT/'colony/MATCHED_CONTROL.md').read_bytes()+digest().encode())
def select():
 d=make_task();tr,va=d['train'],d['val'];x=d['X']/8;work=control_jobs()
 with ThreadPoolExecutor(max_workers=4) as pool:
  pending={pool.submit(features,x,j):j for j in work}
  for k,f in enumerate(as_completed(pending),1):
   f.result()
   if k%10==0:print('MATCHED FEATURES',k,flush=True)
 records=[];scores=[]
 for j in work:
  f,_=features(x,j);choice,trials,s=choose_head(f,d['y'],tr,va);scores.append(s);records.append({'key':j['key'],'choice':choice,'trials':trials})
  print('MATCHED SELECT',j['key'],choice,flush=True)
 chosen,all_choices=aggregate_choices(np.array(scores),d['y'][va])
 freeze={'kind':'post-review matched-gain audit, no changes to full model','source_sha256':audit_digest(),
  'base_choices_sha256':sha((OUT/'choices-frozen.json').read_bytes()),'input':'X/8 into wave:false; identity-U at full-model scale',
  'records':records,'aggregation':chosen,'aggregate_options':all_choices,'phase':'validation frozen before control evaluation'}
 write(OUT/'matched-choices-frozen.json',freeze)
 print('MATCHED FROZEN',chosen['accuracy'],chosen['strategy'],flush=True)
def evaluate():
 frozen=json.loads((OUT/'matched-choices-frozen.json').read_text())
 if frozen['source_sha256']!=audit_digest() or frozen['base_choices_sha256']!=sha((OUT/'choices-frozen.json').read_bytes()):raise ValueError('audit freeze changed')
 d=make_task();tr=np.r_[d['train'],d['val']];te=d['test'];truth=d['y'][te];groups=d['groups'][te];x=d['X']/8
 scores=[];rows=[];predictions=[];look={r['key']:r['choice'] for r in frozen['records']}
 for j in control_jobs():
  f,timing=features(x,j);c=look[j['key']];m=fit_head(f[tr],d['y'][tr],c['kind'],c['alpha']);s=predict_head(m,f[te])['scores'];scores.append(s);p=np.argmax(s,axis=1)
  rows.append({'key':j['key'],**metric(p,truth,groups)});predictions.append({'key':j['key'],'prediction':p.tolist()})
 aggregate={}
 for name,w in [('uniform',np.ones(50)/50),(frozen['aggregation']['strategy'],np.array(frozen['aggregation']['weights']))]:
  s=np.einsum('m,mnc->nc',w,np.array(scores));p=np.argmax(s,axis=1)
  aggregate[name]=metric(p,truth,groups);predictions.append({'key':'aggregate_'+name,'prediction':p.tolist(),'scores':s.tolist()})
 old=json.loads((OUT/'predictions.json').read_text());base_key='full_'+json.loads((OUT/'choices-frozen.json').read_text())['ensemble']['full']['strategy']
 full=np.array(next(r['labels'] for r in old['rows'] if r['key']==base_key));p=np.array(predictions[-1]['prediction'])
 out={'freeze':frozen,'replicas':rows,'aggregate':aggregate,'predictions':predictions,'truth':truth.tolist(),'test_indices':te.tolist(),
  'paired_exploratory_difference_full_minus_matched':bootstrap_difference((full==truth).astype(float),(p==truth).astype(float),groups),
  'counts':{'feature_sequences':50*len(x),'cell_updates':50*len(x)*24*16,'validation_fits':50*7,'final_fits':50},
  'limitation':'Audit control added after original evaluation; not confirmatory preregistered evidence. Full model unchanged.'}
 write(OUT/'matched-control-results.json',out);print('MATCHED RESULTS',json.dumps(aggregate),flush=True)
def main():
 p=argparse.ArgumentParser();p.add_argument('phase',choices=['select','evaluate']);a=p.parse_args()
 with threadpool_limits(limits=2):select() if a.phase=='select' else evaluate()
if __name__=='__main__':main()
