"""Run all shipped replicas on the full test set and compare Python/JS scores."""
from pathlib import Path
import tempfile,json,subprocess,platform,sys
import numpy as np,scipy,sklearn
from threadpoolctl import threadpool_info
from .experiment import ROOT,OUT,jobs,features,sha,digest
from .data import make_task
from .head import predict_head
def main():
 d=make_task();te=d['test'];model=json.loads((OUT/'model-sealed.json').read_text());scores=[]
 full=[j for j in jobs() if j['family']=='full']
 for j,m in zip(full,model['members']):
  f,_=features(d['X'],j);scores.append(predict_head(m['head'],f[te])['scores'])
 expected=np.einsum('m,mnc->nc',np.array(model['weights']),np.array(scores))
 with tempfile.TemporaryDirectory(prefix='ripple-colony-export-') as temp:
  temp=Path(temp);(temp/'input.json').write_text(json.dumps({'sequences':d['X'][te].tolist()}))
  subprocess.run(['node',str(ROOT/'colony/verify_export.mjs'),str(temp/'input.json'),str(temp/'output.json')],check=True)
  actual=json.loads((temp/'output.json').read_text())
 s=np.array([p['scores'] for p in actual['predictions']]);labels=np.array([p['label'] for p in actual['predictions']])
 error=float(np.max(np.abs(expected-s)))
 if error>1e-10 or not np.array_equal(labels,np.argmax(expected,axis=1)):raise AssertionError('export/Python mismatch')
 old=json.loads((OUT/'predictions.json').read_text());key='full_'+model['strategy'];saved=next(p for p in old['rows'] if p['key']==key)
 if not np.array_equal(labels,saved['labels']):raise AssertionError('export differs from frozen experiment predictions')
 w=np.array(model['weights']);y=(d['y'][te,None]==np.arange(6)).astype(float)
 ensemble_mse=float(np.mean((s-y)**2));weighted_mse=float(np.einsum('m,mnc->',w,(np.array(scores)-y)**2)/(len(te)*6))
 if ensemble_mse>weighted_mse+1e-12:raise AssertionError('convex squared-error inequality violated')
 pair_both=pair_changed=0
 for group in np.unique(d['groups'][te]):
  rows=np.flatnonzero(d['groups'][te]==group)
  for k in range(6):
   a,b=rows[k],rows[k+6];pair_both+=int(labels[a]==d['y'][te[a]] and labels[b]==d['y'][te[b]])
   pair_changed+=int(labels[a]!=labels[b])
 errors=[{'index':int(te[i]),'truth':int(d['y'][te[i]]),'prediction':int(labels[i])} for i in range(len(te)) if labels[i]!=d['y'][te[i]]]
 small={'kind':'executed full-test software export verification, no fitting','model_sha256':sha((OUT/'model-sealed.json').read_bytes()),
  'experiment_feature_source_sha256':digest(),'inference_source_sha256':model['inference_source_sha256'],
  'test_sequences':len(te),'replica_sequence_pairs':50*len(te),'cell_updates':50*len(te)*24*16,
  'Python_JS_max_score_delta':error,'all_labels_equal_frozen_predictions':True,'correct':int(np.sum(labels==d['y'][te])),
  'independent_test_templates':16,'paired_context_cases':96,'both_context_targets_correct_pairs':pair_both,'prediction_changed_with_context_pairs':pair_changed,
  'errors':errors,'convex_aggregation':{'ensemble_test_mse':ensemble_mse,'weighted_individual_test_mse':weighted_mse,
   'pointwise_Jensen_bound':'||sum w_i scores_i - y||² <= sum w_i ||scores_i-y||² for w>=0,sumw=1; does not guarantee better classification than the best member'},
  'runtime':{k:v for k,v in actual.items() if k!='predictions'},
  'environment':{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'sklearn':sklearn.__version__,'linear_algebra':threadpool_info()},
  'counts_are_repeated_inference_on_same_test_set':True}
 (OUT/'export-verification.json').write_text(json.dumps(small,indent=2,allow_nan=False))
 examples=[{'input':d['X'][i].tolist(),'truth':int(d['y'][i]),'dataset_index':int(i)} for i in te[:12]]
 (OUT/'examples.json').write_text(json.dumps({'kind':'held-out synthetic examples; truth is evaluator metadata ignored by inference','examples':examples},indent=2))
 # Complete scoring/export source inventory supplements the original feature freeze.
 paths=sorted(set(list((ROOT/'colony').glob('*.py'))+list((ROOT/'colony').glob('*.mjs'))+[ROOT/'src/benchmark.py',ROOT/'src/readout.py',ROOT/'web/predict.mjs']))
 (OUT/'release-source-manifest.json').write_text(json.dumps([{'path':str(p.relative_to(ROOT)),'sha256':sha(p.read_bytes())} for p in paths],indent=2))
 print('Export matches Python and frozen labels, max score error',error,'correct',small['correct'],'/',len(te))
if __name__=='__main__':main()
