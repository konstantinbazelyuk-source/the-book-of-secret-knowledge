import fs from 'node:fs';
import {RegulatoryNetwork,makeAncestor,mutateField} from './network.mjs';
const pop=JSON.parse(fs.readFileSync(new URL('./population.json',import.meta.url))),fields=['type','projection','clock','normalization','phase','coupling'];
const sequences=Array.from({length:3},(_,k)=>Array.from({length:24},(_,t)=>Array.from({length:8},(_,j)=>((t*13+j*7+k*17)%37)/37)));
const parent=makeAncestor(),base=sequences.map(x=>new RegulatoryNetwork(parent).run(x));
const effects=[];let maxError=0;
for(let cell=0;cell<16;cell++)for(const field of fields){
 const g=mutateField(parent,cell,field);let maxDelta=0;
 sequences.forEach((x,k)=>{const y=new RegulatoryNetwork(g).run(x);y.forEach((v,j)=>maxDelta=Math.max(maxDelta,Math.abs(v-base[k][j])));});
 effects.push({cell,field,max_absolute_feature_change:maxDelta,observable:maxDelta>1e-14});
}
for(const member of pop.population){
 const n=new RegulatoryNetwork(member.genome),ur=n.Ure,ui=n.Uim;
 for(let a=0;a<8;a++)for(let b=0;b<8;b++){
  let re=0,im=0;for(let k=0;k<8;k++){re+=ur[k][a]*ur[k][b]+ui[k][a]*ui[k][b];im+=ur[k][a]*ui[k][b]-ui[k][a]*ur[k][b];}
  maxError=Math.max(maxError,Math.hypot(re-(a===b?1:0),im));
 }
}
if(maxError>1e-12)throw Error('compiled optical matrix is not unitary');
const report={kind:'executed causal feature interventions, not accuracy improvement claims',
 independent_genomes:pop.population.length,distinct_genotypes:new Set(pop.population.map(x=>JSON.stringify(x.genome))).size,
 unitary_matrices_checked:50,max_matrix_unitarity_residual:maxError,field_interventions:effects,
 observable_interventions:effects.filter(x=>x.observable).length,total_interventions:effects.length,
 probe_sequences_per_intervention:3,semantics:'Stored codons drive executable cell and optical parameters. Feature influence alone does not establish usefulness.'};
fs.writeFileSync(new URL('./artifacts/gene-checks.json',import.meta.url),JSON.stringify(report,null,2));
console.log('Gene interventions observable:',report.observable_interventions,'/',effects.length,'unitarity residual',maxError);
