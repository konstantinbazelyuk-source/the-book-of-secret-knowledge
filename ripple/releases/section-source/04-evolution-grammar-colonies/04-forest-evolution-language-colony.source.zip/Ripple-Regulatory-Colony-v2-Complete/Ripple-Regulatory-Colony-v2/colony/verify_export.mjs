import fs from 'node:fs';
import {performance} from 'node:perf_hooks';
import {RegulatoryColony} from './inference.mjs';
const [input,output]=process.argv.slice(2),request=JSON.parse(fs.readFileSync(input,'utf8'));
const start=performance.now(),model=JSON.parse(fs.readFileSync(new URL('./artifacts/model-sealed.json',import.meta.url),'utf8')),net=new RegulatoryColony(model),loadMs=performance.now()-start;
const begin=performance.now(),predictions=request.sequences.map(x=>net.predict(x)),wallMs=performance.now()-begin;
fs.writeFileSync(output,JSON.stringify({predictions,load_ms:loadMs,total_prediction_ms:wallMs,
 ms_per_sequence:wallMs/predictions.length,rss_bytes_at_end:process.memoryUsage().rss,
 node_version:process.version,physical_or_target_device_test:false}));
console.log('Executed sealed 50-replica model for',predictions.length,'inputs, ms/input',wallMs/predictions.length);
