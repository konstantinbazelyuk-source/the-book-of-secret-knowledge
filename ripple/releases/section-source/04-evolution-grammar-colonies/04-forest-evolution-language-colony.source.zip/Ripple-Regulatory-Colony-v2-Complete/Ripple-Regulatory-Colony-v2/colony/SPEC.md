# Ripple regulatory colony v2: executable scope

Continuation authorized 2026-10-15. Prior v1 checkpoints, fitted weights, numerical sources and experiments stay intact. The delivered addition must contain trained executable models, not architecture descriptions alone.

## Mechanism to implement

50 inherited variants of a 16-cell network (800 numerical cells total). Each cell has a mandatory RGB byte codon. R high bits choose original LIF/Delta/Daughter/Charlie; R low bits set an input projection and optical pair/mixing angle. G high nibble sets the cell's clock scale; low nibble sets causal divisive-normalization strength. B high nibble sets a passive optical phase; low nibble sets bounded delayed recurrence. The genome is required to generate the executable phenotype. It is neither a display-only marker nor biological DNA.

Input intensity is digitally re-encoded as coherent amplitudes before a sequence of exactly defined lossless two-mode transforms. This is a simulated classical/passive-linear-optical computation; the same coherent-state transform has a quantum-optics representation. Photon-counted training signals follow the coherent-state Poisson detection model, with declared efficiency, dark count and saturation. No nonclassical advantage is inferred.

Within each sequence, a causal running intensity state divides neuron drives. Reset it and all neurons between samples. New adapter code can set typed parameters and cell clock scales; immutable original source kernels remain unmodified. Only final neural states/normalizer states reach a learned ridge readout. Labels enter fitting only.

## Frozen first experiment

Fresh generated context-dependent sequence task, data seed 20261015. 96 independent templates, each 12 cases: six RGB orders times two initial cues. Cue 0 names the observed order; cue 1 swaps R/B in the target order. Same cue/template cases contain identical unordered frame multisets and final frames. Neural input contains no labels or metadata. 24 frames, eight detector channels. Split whole templates 64/16/16, 768/192/192 sequences. This small synthetic task is not evidence of general reasoning or physical perception.

Generate 50 child genomes by bounded inheritance/mutation of a balanced four-type ancestor with fixed seed 2026101501, before fitting. Evaluate all 50, never pick a test winner. Train ridge readouts with alpha grid [0.01,1,100], train-only scaling. Choose alpha on validation, refit train+validation for test. Aggregate all replicas with nonnegative normalized weights from validation MSE; compare uniform aggregation, validation-selected single member, original-family baseline and raw ordered RBF SVM. Deployment uses the validation-selected aggregation strategy, frozen before testing.

Pre-fitting clarification: compare linear and quadratic state readouts on validation, with the same three penalties. Quadratic features are all 80 final states plus their upper-triangular pair products after train-only scaling: 3,320 features. This is an explicit polynomial associative readout, not an extra learned biological neuron claim. No raw frames bypass neural state. Clamped-genome replicas are exactly identical functions; compute their single feature/fit result once and reuse it rather than spend work on 50 identical evaluations. Preserve the equivalence in trial counts.

Paired controls: 50 genomes with all expression codons clamped to the ancestor; 50 with passive mixing disabled while retaining other genome expression. All receive identical examples/splits and equal readout capacity. They are explicitly diagnostic software controls, not alternative biological interpretations. Report neutral/negative results. No new gate is accepted as an accuracy improvement merely because it changes a feature.

Functional interventions independently alter each of six expressed field classes and check actual feature changes on deterministic legal sequences. Missing/malformed genomes, invalid inputs and incompatible readouts must fail. Exact save/reload and Python/JS predictions must agree. Record source/genome/data hashes, every validation choice, every test prediction and actual update counts.

Analytical validation: two-mode U†U=I for any real mixing angle/phase, conservation of amplitude norm by composition; Poisson mean/variance lambda; convex aggregate weights sum to one; recurrent row absolute sum <=0.12; normalization denominator >=1. These claims concern specified equations, not a whole-network stability or intelligence proof. Test finite-precision implementations. Perform 6,000,000 explicit photon draws plus randomized numerical checks; do not substitute them for the requested 10^23 trials or call repeated replicas independent test worlds.

Execution in the available hosted Python/Node runtime. Include a manual cloud batch workflow for the same source if useful; do not claim a second cloud or quantum processor ran it. Scale/correct failures using training/validation only, retain all amendments, and never retune after test scoring.
