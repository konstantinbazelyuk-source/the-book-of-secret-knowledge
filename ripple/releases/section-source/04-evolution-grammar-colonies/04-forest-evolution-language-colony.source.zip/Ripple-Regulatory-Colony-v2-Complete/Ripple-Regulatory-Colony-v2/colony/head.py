"""Train-only-scaled linear/quadratic associative readout of final neural state."""
import numpy as np
from src.readout import fit_readout,predict
def lift(x,kind,mean,scale):
 x=np.asarray(x,float);mean=np.asarray(mean);scale=np.asarray(scale)
 if x.ndim!=2 or mean.shape!=(x.shape[1],) or scale.shape!=mean.shape or not np.isfinite(x).all() or np.any(scale<=0):raise ValueError('invalid state/scaler')
 z=(x-mean)/scale
 if kind=='linear':return z
 if kind!='quadratic':raise ValueError('unknown readout kind')
 i,j=np.triu_indices(z.shape[1]);return np.concatenate([z,z[:,i]*z[:,j]],axis=1)
def fit_head(x,y,kind,alpha):
 x=np.asarray(x,float);mean=x.mean(0);scale=x.std(0);scale=np.where(scale>1e-9,scale,1.)
 z=lift(x,kind,mean,scale);readout=fit_readout(z,np.asarray(y,dtype=int),alpha)
 return {'schema':'ripple-associative-head-v2','kind':kind,'base_mean':mean.tolist(),'base_scale':scale.tolist(),'readout':readout}
def predict_head(head,x):return predict(head['readout'],lift(x,head['kind'],head['base_mean'],head['base_scale']))
