# Colony v2 review follow-up

Bounded read-only verification of the material corrections. No fitting or evaluation phases were rerun, and no production code was edited by this reviewer.

## Important findings

1. **Head/phenotype binding and caller mutation: resolved.** The sealed model now includes a per-member binding over the actual fitted head, genome, execution options, original feature-experiment source identity, and current inference-source identity. `runtimeDigest()` covers the direct JavaScript dependency graph, including the inference implementation, CLI, predictor, regulatory network, all four kernels, and transitive photometry helper. Reproductions show that changing a genome, head coefficient/scaler, wave option, inference source identity, or original experiment source identity is rejected. Swapped fitted heads are rejected. Private model/network fields and a deep copy prevent caller changes to weights or readouts after construction from changing predictions. Both new regression tests and four existing colony tests pass.

2. **Optical gain confound: correctly disclosed; matched-control implementation resolves the design issue.** The original frozen result is preserved and explicitly described in `colony/MATCHED_CONTROL.md` as removing mixing while increasing drive eightfold. The additional audit uses the unchanged `wave:false` phenotype on `X/8`, exactly the identity-U intensity output at the full model's scale. It retains all 50 genotypes, the original partitions and head/alpha choices, train-only scaling, validation-only head/weight selection, a separate source/base-choice freeze, and a separate evaluation command. There is no label or test-label fitting/selection path. The amendment explicitly identifies itself as post-review work after the original evaluation and prohibits changing the full model. That is an appropriate resolution without erasing the original evidence. Matched-control output artifacts were still pending when these code checks completed, so this review does not assert their eventual numerical results.

## Preservation checks

- Removing only the added binding and export metadata from `model-sealed.json` yields a structure exactly equal to the original `model.json`, including every fitted coefficient, choice, weight, genome, and original test record.
- The original feature source, data, and validation-record digests still exactly match the original freeze.
- Sealing adds no fitting, scoring, or model selection path. Its note appropriately describes hashes as accidental-change detection rather than an authorship signature.
- Six focused JavaScript tests passed: the two model-integrity regressions plus all four regulatory-network tests.

## Minor items

The original Python head helper's permissive saved-metadata handling remains acceptable only as a documented trusted internal fitting helper; portable public loading must use the fully validated sealed JavaScript path. Keep the original fitting source frozen. A separate scoring/export/runtime manifest remains the appropriate response to the original digest scope and package-version omissions; it must not replace the historical freeze.

## Assessment

Both important findings have been addressed in the implementation and evidence interpretation. No new important defect was found in the reviewed changes. Retain the original gain-confounded result, report the matched audit as an additional exploratory analysis, and verify its emitted artifacts and final Python/JavaScript parity before making the final delivery claim.
