"""Explicit photon draws plus analytic invariants; not an intelligence test."""
from pathlib import Path
import json,time,math
import numpy as np
from .data import passive_matrix
ROOT=Path(__file__).resolve().parents[1]
def main():
 r=np.random.default_rng(2026101504);start=time.perf_counter();rows=[];n=1_000_000
 for lam in [0.,1.,5.,20.,50.,100.]:
  x=r.poisson(lam,n);mean=float(x.mean());var=float(x.var())
  mean_z=(mean-lam)/math.sqrt(lam/n) if lam else 0.
  var_z=(var-lam)/math.sqrt((lam+2*lam*lam)/n) if lam else 0.
  if abs(mean_z)>8 or abs(var_z)>8 or (lam==0 and np.any(x)):raise AssertionError('photon moment check failed')
  rows.append({'lambda':lam,'draws':n,'observed_mean':mean,'observed_variance':var,'mean_z':mean_z,'variance_z':var_z})
 u=passive_matrix();error=float(np.max(np.abs(u.conj().T@u-np.eye(8))))
 if error>1e-13:raise AssertionError('passive input mixer is not unitary')
 report={'schema':'ripple-optical-equation-checks-v2','kind':'SIMULATED count draws and CALCULATED equation checks',
  'count_variables_generated':6*n,'stochastic_nonzero_rate_draws':5*n,'zero_rate_count_variables':n,'photon_moments':rows,
  'source_mixer_max_unitarity_error':error,
  'analytic_invariants':{'two_mode_matrix':'[[cos(theta),-sin(theta) exp(i phi)],[sin(theta) exp(-i phi),cos(theta)]]',
   'unitarity':'Each column has squared norm cos²+sin²=1 and their complex inner product is zero; products remain unitary.',
   'coherent_direct_detection':'N~Poisson(eta*photons*abs(amplitude)^2 + dark); E[N]=Var[N]=lambda',
   'input_output_bound':'For x in [0,1]^8, sum|U sqrt(x)|²=sum x<=8, so each abs(amplitude)^2/8<=1.',
   'divisive_normalization':'1+strength*nonnegative_running_mean >=1.',
   'recurrence':'abs(coupling*(feedback_left-feedback_right)/2)<=coupling<=0.12 for abs(feedback)<=1.',
   'not_proved':'global nonlinear-neuron stability, semantic correctness on all inputs, general intelligence or quantum advantage'},
  'requested_count_interpretation':str(100000000000000000*1000000),
  'requested_count_executed':False,'seconds':time.perf_counter()-start,'physical_experiments':0}
 p=ROOT/'colony/artifacts/physics-checks.json';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(report,indent=2))
 print('Generated',report['count_variables_generated'],'photon-count variables; max unitary residual',error)
if __name__=='__main__':main()
