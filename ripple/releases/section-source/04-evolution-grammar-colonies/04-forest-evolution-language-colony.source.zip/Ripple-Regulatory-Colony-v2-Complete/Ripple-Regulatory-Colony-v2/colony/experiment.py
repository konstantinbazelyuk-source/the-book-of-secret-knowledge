"""Two-phase 50-replica experiment; no test-driven model selection."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import argparse,json,hashlib,subprocess,time,platform
import numpy as np
from threadpoolctl import threadpool_limits
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from src.readout import fit_readout,predict
from src.benchmark import metric,bootstrap_difference
from .data import make_task,CLASSES
from .head import fit_head,predict_head
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'colony/artifacts'
CACHE=ROOT/'cache/colony-v2'
PROTOCOL={'schema':'ripple-colony-protocol-v2','replicas':50,'cells_per_replica':16,'features':80,
 'data_seed':20261015,'template_splits':[64,16,16],'alpha_grid':[.01,1,100],
 'heads':['linear','quadratic'],'svm_C_grid':[1,10],
 'weights':'uniform or normalized inverse validation MSE, strategy chosen by validation accuracy then MSE',
 'controls':['50 matched wave-off genotypes','one exact-equivalent 50-copy ancestral-clamp control','16 original-LIF typed cells','ordered raw SVM','raw bag ridge','raw final ridge'],
 'input':'simulated coherent-state photon counts, same-frequency modes, no recorded sensors',
 'test_policy':'freeze all validation choices before evaluate; all 50 kept; no test tuning'}
def write(p,x):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2,allow_nan=False))
def sha(x):return hashlib.sha256(x).hexdigest()
def digest():
 files=[ROOT/'colony'/n for n in ['network.mjs','extract.mjs','data.py','head.py','experiment.py','population.json','SPEC.md']]
 files+=list((ROOT/'vendor').rglob('*.mjs'))+list((ROOT/'vendor').rglob('*.js'))+[ROOT/'src/charlie.mjs',ROOT/'src/readout.py']
 return sha(b''.join(str(p.relative_to(ROOT)).encode()+p.read_bytes() for p in sorted(files)))
def population():return json.loads((ROOT/'colony/population.json').read_text())
def jobs():
 p=population();out=[]
 for family in ['full','wave_off']:
  for member in p['population']:out.append({'key':f"{family}-{member['id']:02}",'family':family,'id':member['id'],'genome':member['genome'],'options':{'wave':family=='full'}})
 out.append({'key':'clamped','family':'clamped','id':0,'genome':p['parent'],'options':{'wave':True}})
 g=json.loads(json.dumps(p['parent']))
 for c in g['codons']:c[0]&=63
 out.append({'key':'lif','family':'lif','id':0,'genome':g,'options':{'wave':True}})
 return out
def features(x,job):
 CACHE.mkdir(parents=True,exist_ok=True)
 key=sha(x.tobytes()+json.dumps(job,sort_keys=True).encode()+digest().encode())
 out=CACHE/(key+'.f64');meta=Path(str(out)+'.json')
 if not out.exists() or not meta.exists():
  request=CACHE/(key+'.input.json');request.write_text(json.dumps({'sequences':x.tolist(),'genome':job['genome'],'options':job['options']},separators=(',',':')))
  p=subprocess.run(['node',str(ROOT/'colony/extract.mjs'),'features',str(request),str(out)],capture_output=True,text=True)
  if p.returncode:raise RuntimeError(p.stderr[-2000:])
  request.unlink()
 m=json.loads(meta.read_text());f=np.fromfile(out,dtype='<f8')
 if f.size!=len(x)*80 or not np.isfinite(f).all():raise ValueError('invalid extracted features')
 return f.reshape(len(x),80),m
def scores_metric(scores,y):
 scores=np.asarray(scores);return {'accuracy':float(np.mean(np.argmax(scores,axis=1)==y)),
  'mse':float(np.mean((scores-(y[:,None]==np.arange(6)))**2))}
def choose_head(f,y,tr,va):
 trials=[]
 for kind in PROTOCOL['heads']:
  for a in PROTOCOL['alpha_grid']:
   h=fit_head(f[tr],y[tr],kind,a);s=predict_head(h,f[va])['scores'];trials.append({'kind':kind,'alpha':a,**scores_metric(s,y[va])})
 best=sorted(trials,key=lambda r:(-r['accuracy'],r['mse'],PROTOCOL['heads'].index(r['kind']),r['alpha']))[0]
 h=fit_head(f[tr],y[tr],best['kind'],best['alpha'])
 return best,trials,predict_head(h,f[va])['scores']
def aggregate_choices(scores,y):
 mses=np.array([scores_metric(s,y)['mse'] for s in scores]);inv=1/(1e-6+mses)
 weights={'uniform':np.ones(len(scores))/len(scores),'validation_loss':inv/inv.sum()}
 options=[{'strategy':name,'weights':w.tolist(),**scores_metric(np.einsum('m,mnc->nc',w,scores),y)} for name,w in weights.items()]
 return sorted(options,key=lambda r:(-r['accuracy'],r['mse'],r['strategy']!='uniform'))[0],options
def select():
 OUT.mkdir(parents=True,exist_ok=True);d=make_task();tr,va=d['train'],d['val'];records=[];vs={};timings={}
 np.savez_compressed(OUT/'data.npz',**{k:v for k,v in d.items() if k!='metadata'})
 write(OUT/'data-manifest.json',d['metadata']);write(OUT/'protocol.json',PROTOCOL)
 work=jobs();print('Extracting',len(work),'unique phenotypes; exact duplicate ancestral control evaluated once.',flush=True)
 with ThreadPoolExecutor(max_workers=4) as pool:
  pending={pool.submit(features,d['X'],j):j for j in work}
  count=0
  for future in as_completed(pending):
   job=pending[future];f,timing=future.result();timings[job['key']]=timing;count+=1
   if count%10==0:print('EXTRACTED',count,'/',len(work),flush=True)
 for job in work:
  start=time.perf_counter();f,timing=features(d['X'],job);best,trials,s=choose_head(f,d['y'],tr,va)
  records.append({'key':job['key'],'family':job['family'],'id':job['id'],'choice':best,'trials':trials,'feature_timing':timing})
  vs[job['key']]=s
  write(OUT/'validation.json',{'protocol':PROTOCOL,'records':records})
  print('SELECT',job['key'],best['kind'],best['alpha'],f"val={best['accuracy']:.4f}",f"seconds={time.perf_counter()-start:.2f}",flush=True)
 ensemble={};aggregate_records={}
 for family in ['full','wave_off']:
  scores=np.array([vs[f'{family}-{i:02}'] for i in range(50)])
  chosen,options=aggregate_choices(scores,d['y'][va]);ensemble[family]=chosen;aggregate_records[family]=options
 best_single=sorted([r for r in records if r['family']=='full'],key=lambda r:(-r['choice']['accuracy'],r['choice']['mse'],r['id']))[0]['key']
 raw=d['X'].reshape(len(d['X']),-1);svm=[]
 for c in PROTOCOL['svm_C_grid']:
  p=make_pipeline(StandardScaler(),SVC(C=c,kernel='rbf',gamma='scale'));p.fit(raw[tr],d['y'][tr]);svm.append({'C':c,'accuracy':float(np.mean(p.predict(raw[va])==d['y'][va]))})
 raw_choices={}
 for name,f in [('raw_bag',np.round(d['X'].mean(1),12)),('raw_final',d['X'][:,-1])]:
  trials=[]
  for alpha in PROTOCOL['alpha_grid']:
   m=fit_readout(f[tr],d['y'][tr],alpha);trials.append({'alpha':alpha,'accuracy':float(np.mean(predict(m,f[va])['labels']==d['y'][va]))})
  raw_choices[name]=sorted(trials,key=lambda r:(-r['accuracy'],r['alpha']))[0]
 freeze={'source_sha256':digest(),'protocol':PROTOCOL,'data_sha256':sha(d['X'].tobytes()+d['y'].tobytes()+d['groups'].tobytes()),
  'validation_sha256':sha((OUT/'validation.json').read_bytes()),'ensemble':ensemble,'aggregate_trials':aggregate_records,'best_single':best_single,
  'svm':sorted(svm,key=lambda r:(-r['accuracy'],r['C']))[0],'raw_choices':raw_choices,
  'phase':'all validation choices frozen before test scoring','replicas_kept':50}
 write(OUT/'choices-frozen.json',freeze);print('FROZEN',json.dumps({k:{x:v for x,v in a.items() if x!='weights'} for k,a in ensemble.items()}),'best single',best_single,flush=True)
def evaluate():
 freeze=json.loads((OUT/'choices-frozen.json').read_text());validation=json.loads((OUT/'validation.json').read_text());d=make_task()
 if freeze['source_sha256']!=digest() or freeze['validation_sha256']!=sha((OUT/'validation.json').read_bytes()) or freeze['data_sha256']!=sha(d['X'].tobytes()+d['y'].tobytes()+d['groups'].tobytes()):raise ValueError('frozen source/data/selection changed')
 tr=np.r_[d['train'],d['val']];te=d['test'];truth=d['y'][te];group=d['groups'][te];lookup={r['key']:r for r in validation['records']}
 rows=[];all_scores={};predictions=[];members=[]
 for job in jobs():
  f,timing=features(d['X'],job);c=lookup[job['key']]['choice'];head=fit_head(f[tr],d['y'][tr],c['kind'],c['alpha']);out=predict_head(head,f[te]);s=out['scores']
  all_scores[job['key']]=s;score=metric(out['labels'],truth,group)
  rows.append({'key':job['key'],'family':job['family'],**score,'kind':c['kind'],'alpha':c['alpha'],'trainable_parameters':head['readout']['trainable_parameters']})
  predictions.append({'key':job['key'],'labels':out['labels'].tolist(),'truth':truth.tolist(),'scores':s.tolist()})
  if job['family']=='full':members.append({'id':job['id'],'genome':job['genome'],'options':job['options'],'head':head,'genome_sha256':sha(json.dumps(job['genome'],sort_keys=True).encode())})
  print('TEST',job['key'],score['correct'],'/',score['n'],flush=True)
 aggregate={}
 for family in ['full','wave_off']:
  scores=np.array([all_scores[f'{family}-{i:02}'] for i in range(50)])
  for name,weights in [('uniform',np.ones(50)/50),(freeze['ensemble'][family]['strategy'],np.array(freeze['ensemble'][family]['weights']))]:
   key=family+'_'+name;s=np.einsum('m,mnc->nc',weights,scores);all_scores[key]=s;pred=np.argmax(s,axis=1)
   aggregate[key]=metric(pred,truth,group);predictions.append({'key':key,'labels':pred.tolist(),'truth':truth.tolist(),'scores':s.tolist()})
 raw=d['X'].reshape(len(d['X']),-1);svm=make_pipeline(StandardScaler(),SVC(C=freeze['svm']['C'],kernel='rbf',gamma='scale'))
 svm.fit(raw[tr],d['y'][tr]);raw_pred=svm.predict(raw[te]);aggregate['ordered_raw_svm']=metric(raw_pred,truth,group)
 predictions.append({'key':'ordered_raw_svm','labels':raw_pred.tolist(),'truth':truth.tolist()})
 for name,f in [('raw_bag',np.round(d['X'].mean(1),12)),('raw_final',d['X'][:,-1])]:
  m=fit_readout(f[tr],d['y'][tr],freeze['raw_choices'][name]['alpha']);p=predict(m,f[te])['labels'];aggregate[name]=metric(p,truth,group)
  predictions.append({'key':name,'labels':p.tolist(),'truth':truth.tolist()})
 full_key='full_'+freeze['ensemble']['full']['strategy'];correct=np.argmax(all_scores[full_key],axis=1)==truth;comparisons=[]
 for key in ['clamped','lif',freeze['best_single'],'wave_off_'+freeze['ensemble']['wave_off']['strategy']]:
  c=np.argmax(all_scores[key],axis=1)==truth;comparisons.append({'candidate':full_key,'baseline':key,**bootstrap_difference(correct.astype(float),c.astype(float),group)})
 comparisons.append({'candidate':full_key,'baseline':'ordered_raw_svm',**bootstrap_difference(correct.astype(float),(raw_pred==truth).astype(float),group)})
 # True-label-free ablation: remove the early cue and retain the original targets.
 cue_scores=[]
 for member in members:
  job={'key':'no_cue_'+str(member['id']),'family':'intervention','id':member['id'],'genome':member['genome'],'options':member['options']}
  f,_=features(d['X_no_cue'][te],job);cue_scores.append(predict_head(member['head'],f)['scores'])
 cue=np.einsum('m,mnc->nc',np.array(freeze['ensemble']['full']['weights']),np.array(cue_scores));aggregate['cue_removed']=metric(np.argmax(cue,axis=1),truth,group)
 predictions.append({'key':'cue_removed','labels':np.argmax(cue,axis=1).tolist(),'truth':truth.tolist(),'scores':cue.tolist()})
 # Shuffled-label control on preselected full member, no true-label fitting path.
 j=next(j for j in jobs() if j['key']==freeze['best_single']);f,_=features(d['X'],j);c=lookup[j['key']]['choice'];sh=fit_head(f[tr],np.random.default_rng(2026101502).permutation(d['y'][tr]),c['kind'],c['alpha']);p=predict_head(sh,f[te])['labels']
 aggregate['shuffled_labels_single']=metric(p,truth,group);predictions.append({'key':'shuffled_labels_single','labels':p.tolist(),'truth':truth.tolist()})
 model={'schema':'ripple-regulatory-colony-v2','frames':24,'inputDim':8,'classes':CLASSES,'members':members,
  'weights':freeze['ensemble']['full']['weights'],'strategy':freeze['ensemble']['full']['strategy'],'source_sha256':freeze['source_sha256'],
  'data_kind':d['metadata']['kind'],'fitted_after_validation_freeze':True,'test':aggregate[full_key]}
 write(OUT/'model.json',model);write(OUT/'predictions.json',{'test_indices':te.tolist(),'groups':group.tolist(),'rows':predictions})
 counts={'unique_phenotype_batches':102,'training_evaluation_sequence_pairs':102*len(d['X']),
  'main_cell_updates':102*len(d['X'])*24*16,'cue_removal_sequence_pairs':50*len(te),'cue_removal_cell_updates':50*len(te)*24*16,
  'neural_validation_fits':102*6+102,'neural_final_fits':102,'shuffled_final_fits':1,
  'independent_test_templates':16,'test_sequences':len(te),'replicas':50,'physical_trials':0}
 write(OUT/'results.json',{'protocol':PROTOCOL,'freeze':freeze,'replica_rows':rows,'aggregate':aggregate,'paired_exploratory_comparisons':comparisons,
  'counts':counts,'environment':{'python':platform.python_version(),'runtime':'hosted Python/Node CPU execution','linear_algebra_threads':2},
  'limits':['synthetic single task, 16 independent test templates','passive coherent optical simulation, no nonclassical advantage','fixed cell dynamics plus trained readout','no biological culture or physical apparatus','no 10^23 trial execution']})
 print('RESULTS',json.dumps(aggregate),flush=True)
def main():
 p=argparse.ArgumentParser();p.add_argument('phase',choices=['select','evaluate']);a=p.parse_args()
 with threadpool_limits(limits=2):select() if a.phase=='select' else evaluate()
if __name__=='__main__':main()
