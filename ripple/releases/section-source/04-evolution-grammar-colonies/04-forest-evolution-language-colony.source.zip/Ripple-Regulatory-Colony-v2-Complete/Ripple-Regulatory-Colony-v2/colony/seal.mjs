/** Bind actual fitted heads to expressed phenotypes without fitting or scoring. */
import fs from 'node:fs';
import {runtimeDigest,memberBinding,RegulatoryColony} from './inference.mjs';
const [input,output]=process.argv.slice(2);
if(!input||!output)throw Error('Usage: node colony/seal.mjs FITTED_MODEL.json SEALED_MODEL.json');
const model=JSON.parse(fs.readFileSync(input,'utf8'));
model.inference_source_sha256=runtimeDigest();
for(const m of model.members)m.fitted_binding_sha256=memberBinding(model,m);
model.export_note='Fitted parameters unchanged. Bindings cover genome, execution options, fitted head and feature/inference source identities. Hashes detect accidental changes; they are not an authorship signature.';
new RegulatoryColony(model);
fs.writeFileSync(output,JSON.stringify(model));console.log('Exported 50 sealed fitted phenotypes:',output);
