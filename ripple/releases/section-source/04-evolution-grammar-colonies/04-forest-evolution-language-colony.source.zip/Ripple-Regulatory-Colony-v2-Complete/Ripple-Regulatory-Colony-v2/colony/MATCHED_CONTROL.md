# Post-review matched-gain control amendment

Written after the original v2 evaluation, before fitting this new control. This is a transparent audit extension, not a preregistered confirmatory finding. Original full/wave-off predictions, source freeze and fitted full colony remain unchanged.

Review identified that the wave-off path in the original comparison receives x, while the mixed optical path outputs |U sqrt(x)|²/8. Therefore original wave-off simultaneously removes U and increases drive scale eightfold. Its result cannot isolate the effect of mixing.

The new identity-U control calls the unchanged wave-off network on x/8, for each of the same 50 genotypes. Thus its optical output is exactly |I sqrt(x)|²/8. All other expressed fields, data, partitions, head types, alpha grid and fitting/aggregation rules remain the same. Choose control head parameters/aggregation on validation, freeze them before its test scoring. Report all 50, uniform and validation-loss aggregates, and the original confounded result under its correct name. Do not use this extra control to alter the deployed full model.

No claim that mixing improves accuracy is authorized by an active implementation or unitary proof alone. This control tests task utility, while the gene interventions test causal activity.
