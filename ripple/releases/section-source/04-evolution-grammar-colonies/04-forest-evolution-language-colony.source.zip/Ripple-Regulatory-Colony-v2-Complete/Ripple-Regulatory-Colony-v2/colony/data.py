"""Fresh coherent-light photon-count simulation, not recorded optical data.

Logical R/G/B are code labels carried in same-frequency spatial modes.
Different optical carrier frequencies are NOT interfered as if coherent.
"""
import itertools
import numpy as np
CLASSES=[''.join(x) for x in itertools.permutations('RGB')]
SEED=20261015
PHOTONS=40.0
EFFICIENCY=.75
DARK=.05
SATURATION=EFFICIENCY*PHOTONS*1.5

def passive_matrix():
 u=np.eye(8,dtype=complex)
 for p,q,theta,phase in [(0,1,np.pi/12,.4),(1,2,np.pi/10,-.2),(2,7,np.pi/14,.6),(3,6,np.pi/16,-.3)]:
  b=np.eye(8,dtype=complex);c,s=np.cos(theta),np.sin(theta)
  b[p,p]=b[q,q]=c;b[p,q]=-s*np.exp(1j*phase);b[q,p]=s*np.exp(-1j*phase);u=b@u
 return u

def make_task():
 r=np.random.default_rng(SEED);u=passive_matrix();x=[];y=[];groups=[];contexts=[];no_cue=[];clipped=draws=0
 for group in range(96):
  background=r.uniform(0,.008,(24,8));background[-1]=0
  pulses=[]
  for ch in range(3):
   p=r.uniform(0,.006,8);p[ch]=r.uniform(.65,.95);pulses.append(p)
  cues=[]
  for cue in range(2):
   v=np.zeros(8);v[6+cue]=.85;cues.append(v)
  canonical=np.vstack([background,np.array(pulses),np.array(cues),np.zeros((1,8))])
  # All amplitudes are independently prepared with known zero source phase.
  output=np.sqrt(canonical)@u.T
  lam=EFFICIENCY*PHOTONS*np.abs(output)**2+DARK
  counts=r.poisson(lam);draws+=counts.size;clipped+=int(np.sum(counts>SATURATION))
  observed=np.clip(counts/SATURATION,0,1)
  positions=[int(r.integers(5,7)),int(r.integers(11,13)),int(r.integers(18,20))]
  for cue in range(2):
   for order in CLASSES:
    seq=observed[:24].copy();seq[:3]=observed[27+cue];seq[-1]=observed[29]
    for pos,ch in zip(positions,order):seq[pos]=observed[24+'RGB'.index(ch)]
    absent=seq.copy();absent[:3]=observed[29]
    target=order if cue==0 else order.translate(str.maketrans('RB','BR'))
    x.append(seq);no_cue.append(absent);y.append(CLASSES.index(target));groups.append(group);contexts.append(cue)
 x=np.asarray(x);y=np.asarray(y,dtype=int);groups=np.asarray(groups);contexts=np.asarray(contexts)
 ids=r.permutation(96);parts={name:np.flatnonzero(np.isin(groups,s)) for name,s in [('train',ids[:64]),('val',ids[64:80]),('test',ids[80:])]}
 return dict(X=x,y=y,groups=groups,contexts=contexts,X_no_cue=np.array(no_cue),**parts,
  metadata={'kind':'SIMULATED coherent-state direct photodetection and context-dependent code task',
   'seed':SEED,'classes':CLASSES,'independent_templates':96,'cases_per_template':12,
   'physical_modes':'eight same-frequency spatial modes; RGB are logical code names',
   'photons_per_unit_intensity_exposure':PHOTONS,'efficiency':EFFICIENCY,'dark_mean_per_mode_exposure':DARK,
   'normalization_count':SATURATION,'sampled_photon_count_variables':draws,'saturated_variables':clipped,
   'poisson_counts_reused_across_counterfactual_orders':True,'no_physical_sensor_measurements':True})
