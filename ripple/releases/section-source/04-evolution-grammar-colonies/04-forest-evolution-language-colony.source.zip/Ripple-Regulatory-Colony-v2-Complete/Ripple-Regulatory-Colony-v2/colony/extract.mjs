import fs from 'node:fs';
import {performance} from 'node:perf_hooks';
import {RegulatoryNetwork,makeAncestor,mutateField} from './network.mjs';
const [action,input,output]=process.argv.slice(2);
if(action==='population'){
 let s=2026101501;const random=()=>{s^=s<<13;s^=s>>>17;s^=s<<5;return(s>>>0)/4294967296;};
 const parent=makeAncestor(),population=[];
 const fields=['type','projection','clock','normalization','phase','coupling'];
 for(let id=0;id<50;id++){
  let g=structuredClone(parent);const ancestry=[];
  for(let k=0;k<24;k++){const cell=Math.floor(random()*16),field=fields[Math.floor(random()*6)];g=mutateField(g,cell,field);ancestry.push({cell,field});}
  population.push({id,genome:g,ancestry});
 }
 fs.writeFileSync(input,JSON.stringify({parent,population},null,2));
}else if(action==='features'){
 const p=JSON.parse(fs.readFileSync(input,'utf8')),n=new RegulatoryNetwork(p.genome,p.options),start=performance.now();
 const buffer=Buffer.alloc(p.sequences.length*80*8);
 for(let i=0;i<p.sequences.length;i++){const f=n.run(p.sequences[i]);for(let j=0;j<80;j++)buffer.writeDoubleLE(f[j],8*(i*80+j));}
 fs.writeFileSync(output,buffer);
 fs.writeFileSync(output+'.json',JSON.stringify({rows:p.sequences.length,columns:80,elapsed_ms:performance.now()-start,
  frames:p.sequences.reduce((s,x)=>s+x.length,0),cell_updates:16*p.sequences.reduce((s,x)=>s+x.length,0)}));
}else throw Error('population OUTPUT | features INPUT OUTPUT');
