import fs from 'node:fs';
import {RegulatoryColony} from './inference.mjs';
const [modelFile,inputFile]=process.argv.slice(2);
if(!modelFile||!inputFile)throw Error('Usage: node colony/infer.mjs colony/artifacts/model.json INPUT.json');
const model=JSON.parse(fs.readFileSync(modelFile,'utf8')),data=JSON.parse(fs.readFileSync(inputFile,'utf8')),net=new RegulatoryColony(model);
const rows=data.examples||[{input:data}];
console.log(JSON.stringify({kind:'actual fitted 50-replica regulatory colony inference',predictions:rows.map(x=>net.predict(x.input))},null,2));
