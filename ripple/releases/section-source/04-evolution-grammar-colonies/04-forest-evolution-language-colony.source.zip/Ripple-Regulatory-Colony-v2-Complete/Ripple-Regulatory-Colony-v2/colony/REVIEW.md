# Independent colony v2 review

Reviewed the frozen executable scope, genotype expression, optical equations, dataset construction, fitting/selection code, emitted trained model and predictions, and inference validation. This report is read-only with respect to production code. No select/evaluate phase was rerun.

## Critical

None found. I found no label, group, or test-label path into neural features, scaling fits, regularization/head choices, aggregation choices, or single-member selection. The emitted artifacts cross-check consistently.

## Important

1. **Optical ablation also changes gain by 8×.** `colony/network.mjs:61-65` returns the original frame for `wave:false`, while the enabled optical path returns `abs(U sqrt(frame))² / 8`. A matched identity-optics control would return `frame / 8`. Consequently the frozen `wave_off` comparison removes mixing and multiplies every neural input by eight. Its accuracy cannot isolate the contribution of mixing. Preserve the existing result and explicitly label the gain confound. Add a separately frozen matched-scale control using the unchanged wave-off network with inputs `X/8`, select its heads/weights on validation only, and identify that analysis as added after the original test experiment. Parent has acknowledged this and is implementing that route.

2. **Saved heads are not bound to their fitted phenotype, and validated model state remains mutable.** `colony/inference.mjs:23` checks the genome hash against the genome in the same member record, but does not bind the fitted head to that genome, the `wave` option, or the feature source. Both swapping members 0/1's trained heads and changing member 0's `options.wave` to false were accepted by `new RegulatoryColony(model)` on the actual emitted model. These are valid shapes but incompatible feature/readout combinations. Additionally `this.model=model` at line 29 keeps the caller-owned object; changing weights or heads after construction bypasses validation while the networks retain copied genomes. Add an export binding over genotype, options, fitted head, and feature-source identity, validate it at loading, and retain a private deep copy or frozen state. This can be done as an export layer without retraining or changing the frozen mathematical sources.

## Minor

1. **Frozen-source scope and runtime manifest are incomplete.** `colony/experiment.py:26-29` excludes imported scoring helpers in `src/benchmark.py`; the original digest also excludes the subsequently added inference files and `web/predict.mjs`. `results.json` records Python but not Node, NumPy, SciPy, scikit-learn, or threadpoolctl versions. Do not rewrite the original freeze: record a separate export/source manifest covering the inference and scoring dependency graph, plus runtime versions, and distinguish feature-source freeze from export verification.

2. **Python head validation is weaker than JavaScript validation.** `colony/head.py:4-15` checks dimensions and positive scales but does not require finite base means/scales or the head schema. An infinite `base_scale` and an incorrect head schema both produce finite accepted Python predictions, while JavaScript rejects them. Add finite/schema checks in a separately verified inference adapter or future version, and a malformed-head regression test. Avoid silently changing already frozen fitting sources.

## Verified evidence

- Current source, validation-record, and generated data digests exactly match the original `choices-frozen.json` values.
- The 50 generated genotypes are distinct; all six field classes actually control executable parameters. The 96 recorded cell/field interventions are all observable, with the smallest maximum feature effect approximately 0.00452. Feature influence is not evidence of an accuracy gain.
- The complex gate signs implement the stated unitary matrix, and its negative-angle inverse is correct. Composition into 8×8 matrices preserves unitarity; the 50 recorded residuals are bounded by approximately `5.6e-16`. The intensity normalization bound, nonnegative normalization denominator, and recurrent absolute row-sum bound follow from the implemented equations.
- Poisson data are explicitly simulated coherent direct-detection counts in eight same-frequency modes. RGB are logical labels. The original detector phase is not measured and is not supplied to the model; its optical adapter re-encodes observed intensities as known-phase coherent amplitudes. No quantum advantage follows.
- Whole-template splits are 64/16/16, giving 768/192/192 sequences. Counterfactual order cases within a template/cue have identical unordered frame multisets and final frames. Photon counts reused across those cases are disclosed. There are 16 independent test templates, not 50 independent test worlds.
- All 111 emitted prediction rows match the stored test indices and truth. Every stored score vector has the stated argmax label. Both weighted ensembles exactly reproduce from the 50 stored member score matrices and frozen weights; each family has 50 strictly positive weights summing to one.
- Frozen full ensemble: 191/192. Raw ordered SVM: 190/192. Gain-confounded wave-off ensemble: 192/192. Raw bag and final-frame controls: 32/192. Cue removed: 92/192. Shuffled-label selected single: 33/192. These do not establish superiority of the added optical or genetic components.
- All member genome hashes match the artifact genomes. The trained full model has 49 quadratic heads and one linear head. Fitting is supervised readout learning on frozen cell dynamics; it is not end-to-end neuron training.
- Main feature counts reconcile: `102 * 1152 * 24 * 16 = 45,121,536` cell updates; cue-removal counts reconcile to 3,686,400 more. Six-million photon draws include one million deterministic zero-rate variables, explicitly disclosed. The artifact explicitly states that `10^23` trials and physical experiments were not executed.
- Four colony JavaScript tests and four colony Python tests passed. The preserved `vendor/`, `src/`, and `web/predict.mjs` source diff against checkpoint `700df5a` was empty when checked.

## Assessment

The architecture and trained model are real executable work, and the original results are internally consistent. Resolve the two important items, retain the original evidence/freeze, and describe the experiment as a small synthetic context/order task with exploratory group uncertainty. Python/JS full-model prediction parity and final export binding verification remain with the parent implementation task.
