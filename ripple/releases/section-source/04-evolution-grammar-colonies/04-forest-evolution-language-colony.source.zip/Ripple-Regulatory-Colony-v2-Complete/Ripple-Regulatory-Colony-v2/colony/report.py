"""Generate the delivery report from actual experiment/verification records."""
from pathlib import Path
from collections import Counter
import json
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'colony/artifacts'
def main():
 e=json.loads((OUT/'results.json').read_text());m=json.loads((OUT/'matched-control-results.json').read_text())
 v=json.loads((OUT/'export-verification.json').read_text());p=json.loads((OUT/'physics-checks.json').read_text());g=json.loads((OUT/'gene-checks.json').read_text())
 model=json.loads((OUT/'model-sealed.json').read_text());by={r['key']:r for r in e['replica_rows']}
 full_key='full_'+model['strategy'];classes=model['classes']
 methods=[('Deployed 50-member colony',e['aggregate'][full_key]),('50-member uniform aggregate',e['aggregate']['full_uniform']),
  ('Validation-selected single member',by[e['freeze']['best_single']]),('Clamped ancestral genotype, exact duplicate-copy control',by['clamped']),
  ('16 original-LIF cells with same adapter/readout search',by['lif']),('Ordered raw-input SVM',e['aggregate']['ordered_raw_svm']),
  ('Matched-gain identity-U colony, post-review audit',m['aggregate'][m['freeze']['aggregation']['strategy']]),
  ('Original wave-off control, mixing + 8x gain change',e['aggregate']['wave_off_'+e['freeze']['ensemble']['wave_off']['strategy']]),
  ('Unordered input mean',e['aggregate']['raw_bag']),('Final input frame',e['aggregate']['raw_final']),
  ('Early context cue removed at inference',e['aggregate']['cue_removed']),('Shuffled-label single-member control',e['aggregate']['shuffled_labels_single'])]
 params=sum(x['head']['readout']['trainable_parameters'] for x in model['members']);kinds=Counter(x['head']['kind'] for x in model['members'])
 celltypes=Counter(['LIF','Delta','Daughter','Charlie'][c[0]>>6] for x in model['members'] for c in x['genome']['codons'])
 main_updates=e['counts']['main_cell_updates'];cue_updates=e['counts']['cue_removal_cell_updates'];matched_updates=m['counts']['cell_updates'];export_updates=v['cell_updates']
 total_updates=main_updates+cue_updates+matched_updates+export_updates
 lines=['# Ripple Regulatory Colony v2 — executed model and results','',
  'A complete runnable, trained software model for a defined cue-dependent sequence task. The delivery includes the required per-cell genomes, 50 fitted members, executable neural/optical processing, learned associative readouts, aggregation, all evaluation data and raw predictions. It is task-specific software; no general-intelligence, physical-culture or quantum-processor result is asserted.','',
  '## What actually executes','',
  f"50 distinct inherited genotypes × 16 numerical cells = 800 cells. Actual type totals: {dict(celltypes)}. Each RGB codon sets cell type, projection/routing, clock scale, normalization, optical phase and delayed recurrence. Removing or changing a required genotype cannot silently reuse an unrelated fitted head. All {g['observable_interventions']}/{g['total_interventions']} tested field interventions changed computed final features.",'',
  f"The exported model has {dict(kinds)} readouts and {params:,} fitted readout coefficients/biases, plus fitted scaling statistics. The cell equations and gene-generated input/recurrent parameters are fixed. Supervised learning fits the readouts. This is not end-to-end training of the cell equations.",'',
  'The optical operations are complex passive two-mode rotations compiled into an 8×8 matrix. Same-frequency spatial modes carry logical color codes. The data simulator uses coherent-state Poisson detection; the inference circuit deliberately re-encodes the detected values into known amplitudes. It does not reconstruct unknown carrier phase or coherently mix different RGB optical frequencies. See ARCHITECTURE.md and SCIENTIFIC_BASIS.md for exact equations and sources.','',
  '## Data and selection','',
  'Fresh synthetic data seed 20261015: 96 independent templates × 12 cue/order cases = 1,152 sequences, each 24×8. Whole-template split: 64 training, 16 validation, 16 test templates; 768/192/192 sequences. Under each cue, six order cases share the same unordered frame multiset and final frame. Removing the cue makes paired observations identical while their targets differ. Any deterministic cue-free classifier is therefore capped at 50% on these balanced pairs.','',
  'All 50 genomes were generated before fitting. Linear/quadratic readout type and alpha [0.01,1,100] were selected on validation only. Aggregation strategy and all weights were frozen before test scoring. Final heads were fitted on training+validation. No test-ranked member replaced the validation-selected model. The matched-gain control was added transparently after review; it has a separate validation freeze and is an audit extension, not preregistered confirmatory evidence.','',
  '## Measured held-out software results','',
  '| Method / intervention | Correct / 192 | Accuracy |','|---|---:|---:|']
 for label,row in methods:lines.append(f"| {label} | {row['correct']} / {row['n']} | {100*row['accuracy']:.2f}% |")
 lines+=['',
  'These 192 sequences contain **16 independent test templates**, not 192 independent worlds and not 50 independent test datasets. Replica counts do not multiply the statistical sample size. All bootstrap comparisons are exploratory, conditional on this simulator/models, with no multiple-comparison correction. Perfect empirical controls can give degenerate percentile intervals; they do not guarantee future accuracy.','',
  'The original wave-off path also changed intensity scale eightfold, so it cannot isolate optical mixing. The corrected identity-U control applies x/8 before the unchanged wave-off network. Both versions are retained and correctly labeled.','']
 delta=m['paired_exploratory_difference_full_minus_matched'];svm=next(x for x in e['paired_exploratory_comparisons'] if x['baseline']=='ordered_raw_svm')
 lines += [f"Full minus matched-gain control: {100*delta['difference']:+.2f} percentage points, paired 95% bootstrap interval {100*delta['bootstrap95'][0]:+.2f} to {100*delta['bootstrap95'][1]:+.2f}. Full minus raw SVM: {100*svm['difference']:+.2f} points, interval {100*svm['bootstrap95'][0]:+.2f} to {100*svm['bootstrap95'][1]:+.2f}. Neither comparison establishes superiority.",'',
  'The colony improves over its validation-selected single member and its identical-genotype duplicate control on this test. Those comparisons change diversity and total fitted capacity; they do not establish that RGB notation itself or biological imitation is better than all ordinary machine learning. A functional transform can lack a proven accuracy advantage.','',
  f"In matched context pairs, the exported model changed its prediction in {v['prediction_changed_with_context_pairs']}/96 pairs and got both targets right in {v['both_context_targets_correct_pairs']}/96. The cue-removal result supports contextual dependence of this learned classifier, not general reasoning.",'',
  '## Executed computation and mathematical checks','',
  f"- {p['count_variables_generated']:,} generated photon-count variables: {p['stochastic_nonzero_rate_draws']:,} at nonzero Poisson rates and {p['zero_rate_count_variables']:,} at zero rate. These are simulated count draws, not physical experiments or independent semantic tasks.",
  f"- {g['total_interventions']} per-cell field interventions × three probe sequences; 50 distinct genotypes; 50 compiled unitary matrices checked. Maximum unitarity residual: {g['max_matrix_unitarity_residual']:.3g}.",
  f"- Core experiments, matched audit and export check executed {total_updates:,} simulated cell updates: {main_updates:,} main, {cue_updates:,} cue removal, {matched_updates:,} matched control, {export_updates:,} repeated export verification. Unit-test/probe updates are additional and are not folded into this count.",
  f"- {e['counts']['neural_validation_fits']+m['counts']['validation_fits']:,} neural validation-stage ridge fits (including the selected-head repeats actually executed); {e['counts']['neural_final_fits']+m['counts']['final_fits']} final neural fits, plus one shuffled-label fit. Raw-baseline fits are separate.",
  f"- Full export verification ran {v['replica_sequence_pairs']:,} member/sequence pairs. All labels matched the frozen Python experiment; maximum score difference {v['Python_JS_max_score_delta']:.3g}.",'',
  'The requested “100000000000000000 million” is 10²³ trials. **That count was not executed.** Unitary composition, bounded normalization/feedback and the convex squared-error inequality are checked analytically/numerically instead of pretending to enumerate all histories. They do not prove every classification correct or replace independent task validation.','',
  '## Run the actual trained model','',
  'Install Node.js 20 or later. From the extracted package:',
  '```sh','node colony/infer.mjs colony/artifacts/model-sealed.json colony/artifacts/examples.json','```','',
  'For your own signal, supply a JSON array of exactly 24 rows of eight finite numbers in [0,1]. The model returns one of six class labels, uncalibrated scores and the labels computed by all 50 replicas. Truth fields in the example wrapper are evaluator metadata and are never passed to prediction. Out-of-distribution input can be wrong and polynomial readouts can extrapolate to large score values.','',
  f"Observed runtime here: {v['runtime']['ms_per_sequence']:.1f} ms/sequence for all 50 members, after {v['runtime']['load_ms']:.1f} ms loading. These are actual hosted-runtime measurements, not phone, robot, hardware-speed or energy guarantees.",'',
  'The public loader checks fitted-head/genome/options/source bindings and isolates loaded state from caller mutation. Review reproduced and corrected swapped-head acceptance and caller-state mutation. The Python head helper is for trusted internal fitting; portable external model validation is the sealed JavaScript loader.','',
  '## Evidence classes and preserved scope','',
  '- Measured software: fitting, correctness counts, all test predictions, timing, model bindings and Python/JavaScript agreement.',
  '- Simulated: neuronal states/events, optical fields/counts, all new task observations and context interventions.',
  '- Calculated: unitary identities, bounds, feature/parameter/update counts and convex aggregation property.',
  '- Proposed/unperformed: physical optical hardware, biological cultures, general-purpose reasoning, robot behavior and nonclassical quantum advantage.','',
  'Original LIF/Delta/Daughter sources and the Charlie reference/port remain unchanged by this stage. The complete v1 trained Fusion work, its results and its RGB blueprint codec are preserved. Newer Library source inspections and failed/neutral findings are retained; spin-off names are not counted as new cell types without executable mechanisms.','',
  'New integration code, synthetic data and model outputs: CC0-1.0, with inherited notices retained. The preserved v1 recorded digits retain their CC BY 4.0 attribution. Original Ripple concept: Constantin x. The package has not been posted publicly by this task.']
 (ROOT/'colony/RESULTS.md').write_text('\n'.join(lines)+'\n')
 print('Wrote executed model report; core simulated cell updates',total_updates,'readout parameters',params)
if __name__=='__main__':main()
