"""Trainable affine readout: exact ridge objective on frozen neural features.

Only fit() consumes labels. JSON prediction contains no teacher/oracle path.
"""
import numpy as np
from scipy.linalg import cho_factor,cho_solve

def _matrix(x):
 x=np.asarray(x,dtype=np.float64)
 if x.ndim!=2 or not x.shape[0] or not x.shape[1] or x.shape[1]>8192 or not np.isfinite(x).all():
  raise ValueError('nonempty finite feature matrix required')
 return x

def fit_readout(features,labels,alpha=1.0):
 x=_matrix(features);y=np.asarray(labels)
 if y.ndim!=1 or len(y)!=len(x) or not np.issubdtype(y.dtype,np.integer):raise ValueError('integer labels matching fitting rows required')
 if not np.isfinite(alpha) or alpha<=0:raise ValueError('positive finite regularization required')
 classes=np.unique(y)
 if len(classes)<2:raise ValueError('at least two fitting classes required')
 target=(y[:,None]==classes[None,:]).astype(float)
 mean=x.mean(0);scale=x.std(0);scale=np.where(scale>1e-9,scale,1.)
 z=(x-mean)/scale;intercept=target.mean(0);centered=target-intercept
 if z.shape[1]<=len(z):
  gram=z.T@z;gram.flat[::len(gram)+1]+=alpha
  coef=cho_solve(cho_factor(gram,lower=True,check_finite=False),z.T@centered,check_finite=False)
 else:
  gram=z@z.T;gram.flat[::len(gram)+1]+=alpha
  coef=z.T@cho_solve(cho_factor(gram,lower=True,check_finite=False),centered,check_finite=False)
 scores=z@coef+intercept
 model={'schema':'ripple-ridge-v1','classes':classes.astype(int).tolist(),'mean':mean.tolist(),'scale':scale.tolist(),
  'coef':coef.tolist(),'intercept':intercept.tolist(),'alpha':float(alpha),'fit_rows':len(x),
  'training_mse':float(np.mean((scores-target)**2)),
  'untrained_training_mse':float(np.mean(target**2)),
  'trainable_parameters':int(coef.size+intercept.size)}
 validate_model(model);return model

def validate_model(m):
 if not isinstance(m,dict) or m.get('schema')!='ripple-ridge-v1':raise ValueError('unsupported model schema')
 classes=np.asarray(m.get('classes',[]));mean=np.asarray(m.get('mean',[]),float);scale=np.asarray(m.get('scale',[]),float)
 coef=np.asarray(m.get('coef',[]),float);intercept=np.asarray(m.get('intercept',[]),float)
 if classes.ndim!=1 or len(classes)<2 or not np.issubdtype(classes.dtype,np.integer) or len(np.unique(classes))!=len(classes):raise ValueError('invalid classes')
 if mean.ndim!=1 or not 0<len(mean)<=8192 or scale.shape!=mean.shape or coef.shape!=(len(mean),len(classes)) or intercept.shape!=classes.shape:raise ValueError('incompatible model array shapes')
 if not all(np.isfinite(v).all() for v in [mean,scale,coef,intercept]) or np.any(scale<=0):raise ValueError('invalid model coefficients/scales')
 return mean,scale,coef,intercept,classes

def predict(model,features):
 x=_matrix(features);mean,scale,coef,intercept,classes=validate_model(model)
 if x.shape[1]!=len(mean):raise ValueError('feature dimension differs from trained readout')
 scores=((x-mean)/scale)@coef+intercept
 if not np.isfinite(scores).all():raise ValueError('nonfinite prediction')
 return {'labels':classes[np.argmax(scores,axis=1)],'scores':scores}
