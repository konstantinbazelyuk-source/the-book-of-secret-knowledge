import '../vendor/legacy/ripple-core.js';
import {DeltaRippleNeuron} from '../vendor/daughter/vault/delta/delta-neuron.mjs';
import {DaughterTripletNeuron} from '../vendor/daughter/src/triplet-neuron.mjs';
import {CharlieNeuron} from './charlie.mjs';

const clip=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
export const ARCHITECTURES=['lif','delta','daughter','charlie','mix3','mix4','mix4_no_links','tanh'];
function rng(seed){let state=seed>>>0||1;return()=>{state^=state<<13;state^=state>>>17;state^=state<<5;return(state>>>0)/4294967296;};}
function normal(r){return Math.sqrt(-2*Math.log(Math.max(r(),1e-15)))*Math.cos(2*Math.PI*r());}
function kindAt(architecture,i){
 if(architecture==='mix3')return ['lif','delta','daughter'][i%3];
 if(architecture==='mix4'||architecture==='mix4_no_links')return ['lif','delta','daughter','charlie'][i%4];
 return architecture;
}
function newCell(kind){
 if(kind==='lif')return new globalThis.RippleNeuron();
 if(kind==='delta')return new DeltaRippleNeuron({feedforward:false});
 if(kind==='daughter')return new DaughterTripletNeuron();
 if(kind==='charlie')return new CharlieNeuron();
 if(kind==='tanh')return {h:0};
 throw Error('unknown cell');
}
export class FeatureNetwork{
 constructor(config={}){
  const allowed=['architecture','units','inputDim','seed','dt','coupling'];
  if(Object.keys(config).some(k=>!allowed.includes(k)))throw Error('unknown network option');
  this.config={architecture:'mix4',units:32,inputDim:8,seed:11,dt:.1,coupling:.12,...config};
  const c=this.config;
  if(!ARCHITECTURES.includes(c.architecture)||!Number.isInteger(c.units)||c.units<4||c.units>64||!Number.isInteger(c.inputDim)||c.inputDim<1||c.inputDim>32
   ||!Number.isInteger(c.seed)||c.seed<0||c.seed>4294967295||!Number.isFinite(c.dt)||c.dt<=0||c.dt>.2
   ||!Number.isFinite(c.coupling)||c.coupling<0||c.coupling>.2)throw Error('invalid network configuration');
  const r=rng(c.seed),scale=.65/Math.sqrt(c.inputDim);
  this.projection=Array.from({length:c.units},()=>Array.from({length:3},()=>Array.from({length:c.inputDim},()=>normal(r)*scale)));
  this.bias=Array.from({length:c.units},()=>Array.from({length:3},()=>.42+.16*r()));
  const coupling=c.architecture==='mix4_no_links'?0:c.coupling;
  this.recurrent=Array.from({length:c.units},(_,i)=>Array.from({length:c.units},(_,j)=>
   j===(i+c.units-1)%c.units?coupling/2:j===(i+3)%c.units?-coupling/2:0));
  this.kinds=Array.from({length:c.units},(_,i)=>kindAt(c.architecture,i));this.reset();
 }
 reset(){this.cells=this.kinds.map(newCell);this.feedback=Array(this.config.units).fill(0);this.lastFeatures=Array(this.config.units*4).fill(0);this.steps=0;}
 validate(frame){if(!Array.isArray(frame)||frame.length!==this.config.inputDim||Array.from(frame).some(x=>!Number.isFinite(x)||x<0||x>1))throw Error('frame must match finite [0,1] input dimensions');}
 snapshot(){return {features:this.lastFeatures.slice(),feedback:this.feedback.slice(),steps:this.steps};}
 step(frame){
  this.validate(frame);const old=this.feedback.slice(),centered=frame.map(x=>2*x-1),features=[],next=[];
  for(let i=0;i<this.cells.length;i++){
   const rec=this.recurrent[i].reduce((s,w,j)=>s+w*old[j],0);
   const rgb=this.projection[i].map((row,ch)=>clip(this.bias[i][ch]+row.reduce((s,w,j)=>s+w*centered[j],0)+[.5,.1,-.5][ch]*rec));
   const cell=this.cells[i],kind=this.kinds[i];let f,u;
   if(kind==='lif'){const o=cell.step(rgb,this.config.dt);u=o.u;f=[o.u,o.rate,o.theta,o.count];}
   else if(kind==='delta'){const o=cell.step(rgb,this.config.dt);u=o.u;f=[o.u,o.adaptation,o.rate,o.theta];}
   else if(kind==='daughter'){const o=cell.step(rgb,this.config.dt);u=o.u;f=[o.u,o.layer2.dendrite,o.adaptation,o.rate];}
   else if(kind==='charlie'){const o=cell.step(rgb,this.config.dt);u=o.membrane;f=[u,o.exc-o.inh,o.adapt,o.rate_hz];}
   else{const decay=Math.exp(-this.config.dt/.5);cell.h=decay*cell.h+(1-decay)*Math.tanh(2*rgb[0]+1.2*rgb[1]-1.4*rgb[2]);u=cell.h;f=[u,u*u,u*u*u,u**4];}
   if(f.some(x=>!Number.isFinite(x)))throw Error('nonfinite neuron state');
   features.push(...f);next.push(Math.tanh(u));
  }
  this.feedback=next;this.lastFeatures=features;this.steps++;return features.slice();
 }
 run(sequence,mode='final'){
  if(!Array.isArray(sequence)||sequence.length<1||sequence.length>256||!['final','trajectory'].includes(mode))throw Error('invalid sequence or feature mode');
  for(const frame of sequence)this.validate(frame);
  const trajectory=[];for(const frame of sequence){const f=this.step(frame);if(mode==='trajectory')trajectory.push(...f);}
  return mode==='trajectory'?trajectory:this.lastFeatures.slice();
 }
}
export function extractSequence(sequence,config,mode='final'){return new FeatureNetwork(config).run(sequence,mode);}
