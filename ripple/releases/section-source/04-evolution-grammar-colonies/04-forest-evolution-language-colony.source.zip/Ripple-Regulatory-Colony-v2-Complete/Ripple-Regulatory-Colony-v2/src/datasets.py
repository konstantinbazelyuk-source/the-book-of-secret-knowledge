"""Recorded digits and explicitly synthetic counterfactual code-order tasks."""
import itertools
import numpy as np
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

DATA_SEED=20261014
def load_digits_task():
 d=load_digits();x=d.images.astype(np.float64)/16.;y=d.target.astype(np.int64)
 ids=np.arange(len(y));train,hold=train_test_split(ids,test_size=.4,random_state=DATA_SEED,stratify=y)
 val,test=train_test_split(hold,test_size=.5,random_state=DATA_SEED+1,stratify=y[hold])
 return {'X':x,'y':y,'groups':ids,'splits':{'train':train,'val':val,'test':test},'kind':'recorded_scanner_images',
  'previously_studied':True,'writer_disjoint':False,
  'source':'Alpaydin & Kaynak (1998), UCI Optical Recognition of Handwritten Digits; scikit-learn bundled 1797-image subset',
  'license':'CC BY 4.0','classes':list(map(str,range(10)))}

def make_temporal():
 r=np.random.default_rng(DATA_SEED);perms=list(itertools.permutations(range(3)));xs=[];ys=[];groups=[]
 for group in range(300):
  base=r.uniform(0,.03,(24,8));base[-1]=0
  positions=[int(r.integers(1,5)),int(r.integers(8,12)),int(r.integers(15,19))]
  pulses=r.uniform(0,.03,(3,8))
  for color in range(3):pulses[color,color]=r.uniform(.55,.95)
  for label,order in enumerate(perms):
   seq=base.copy()
   for pos,color in zip(positions,order):seq[pos]=pulses[color]
   xs.append(seq);ys.append(label);groups.append(group)
 x=np.asarray(xs);y=np.asarray(ys,dtype=np.int64);g=np.asarray(groups,dtype=np.int64)
 order=r.permutation(300);group_splits={'train':order[:160],'val':order[160:220],'test':order[220:]}
 splits={k:np.flatnonzero(np.isin(g,v)) for k,v in group_splits.items()}
 return {'X':x,'y':y,'groups':g,'splits':splits,'kind':'simulated_counterfactual_color_order',
  'previously_studied':False,'writer_disjoint':False,'source':'new seeded software generator',
  'license':'CC0-1.0','classes':[''.join('RGB'[i] for i in p) for p in perms]}
