"""Label-free Node feature extraction with a source+input keyed local cache."""
from pathlib import Path
import json,hashlib,subprocess,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
ENGINE_ROOT=ROOT

def set_feature_engine(name):
 global ENGINE_ROOT
 if name not in ['frozen','release']:raise ValueError('unknown feature engine')
 ENGINE_ROOT=ROOT/'repro/frozen-engine' if name=='frozen' else ROOT

def source_digest():
 h=hashlib.sha256()
 paths=sorted((ENGINE_ROOT/'src').glob('*.mjs'))+sorted((ENGINE_ROOT/'vendor').rglob('*.mjs'))+sorted((ENGINE_ROOT/'vendor').rglob('*.js'))
 for p in paths:h.update(str(p.relative_to(ENGINE_ROOT)).encode());h.update(p.read_bytes())
 return h.hexdigest()

def extract_features(x,config,mode,cache_dir=None):
 x=np.asarray(x,dtype=np.float64)
 if x.ndim!=3 or not len(x) or not np.isfinite(x).all() or np.any(x<0) or np.any(x>1):raise ValueError('finite [0,1] sequence batch required')
 cache=Path(cache_dir or ROOT/'cache');cache.mkdir(parents=True,exist_ok=True)
 h=hashlib.sha256(x.tobytes()+json.dumps([config,mode,source_digest()],sort_keys=True).encode()).hexdigest()
 out=cache/(h+'.f64');meta=Path(str(out)+'.json')
 if not out.exists() or not meta.exists():
  request=cache/(h+'.input.json');request.write_text(json.dumps({'sequences':x.tolist(),'config':config,'mode':mode},separators=(',',':')))
  start=time.perf_counter()
  p=subprocess.run(['node',str(ENGINE_ROOT/'src/extract_batch.mjs'),str(request),str(out)],capture_output=True,text=True,check=False)
  if p.returncode:raise RuntimeError('feature extraction failed: '+p.stderr[-1800:])
  m=json.loads(meta.read_text());m['process_wall_ms']=1000*(time.perf_counter()-start)
  m['source_sha256']=source_digest();m['input_sha256']=hashlib.sha256(x.tobytes()).hexdigest()
  meta.write_text(json.dumps(m));request.unlink()
 m=json.loads(meta.read_text());f=np.fromfile(out,dtype='<f8')
 if f.size!=m['rows']*m['columns'] or m['rows']!=len(x) or not np.isfinite(f).all():raise ValueError('invalid extracted feature file')
 return f.reshape(m['rows'],m['columns']),m
