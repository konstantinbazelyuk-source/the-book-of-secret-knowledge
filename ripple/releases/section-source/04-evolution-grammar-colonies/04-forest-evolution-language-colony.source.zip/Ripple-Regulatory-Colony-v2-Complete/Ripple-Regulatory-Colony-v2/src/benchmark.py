"""Two-phase reproducible learning experiment. No model selection uses test scores."""
from pathlib import Path
import argparse,hashlib,json,time,platform
from datetime import datetime,timezone
import numpy as np
import scipy,sklearn
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from threadpoolctl import threadpool_limits
from .datasets import load_digits_task,make_temporal
from .bridge import extract_features,source_digest,set_feature_engine
from .readout import fit_readout,predict

ROOT=Path(__file__).resolve().parents[1]
PROTOCOL={'schema':'ripple-fusion-protocol-v1','units':32,'inputDim':8,'dt':.1,'coupling':.12,
 'seeds':[11,23,47,89,131],'alpha_grid':[.01,1,100],
 'architectures':['lif','delta','daughter','charlie','mix3','mix4','mix4_no_links','tanh'],
 'svm_C_grid':[1,10],'deployment_seed':11,'data_seed':20261014,
 'split_policy':'digits stratified 60/20/20; temporal whole groups 160/60/80',
 'digit_prior_exposure':'dataset already studied in Gen Beta v2.1; not external or writer-disjoint validation',
 'head_policy':'digits complete state trajectory; temporal final state only',
 'no_raw_bypass':True,'no_end_to_end_neuron_training':True,
 'test_use':'freeze validation choices, then score all prespecified comparisons once; no test tuning'}

def write_json(path,value):
 Path(path).parent.mkdir(parents=True,exist_ok=True)
 Path(path).write_text(json.dumps(value,indent=2,allow_nan=False))
def protocol_hash():return hashlib.sha256(json.dumps(PROTOCOL,sort_keys=True).encode()).hexdigest()
def config(arch,seed):return {k:PROTOCOL[k] for k in ['units','inputDim','dt','coupling']}|{'architecture':arch,'seed':seed}
def tasks():return {'digits':load_digits_task(),'temporal':make_temporal()}
def mode(task):return 'trajectory' if task=='digits' else 'final'
def accuracy(p,y):return float(np.mean(np.asarray(p)==y))

def select_architecture(rows):
 totals=[]
 for arch in sorted({r['architecture'] for r in rows}):
  rs=[r for r in rows if r['architecture']==arch]
  if len(rs)!=len(PROTOCOL['seeds']) or {r['seed'] for r in rs}!=set(PROTOCOL['seeds']):raise ValueError('complete prespecified seeds required')
  totals.append({'architecture':arch,'mean_val_accuracy':float(np.mean([r['val_accuracy'] for r in rs]))})
 if not totals:raise ValueError('no candidate rows')
 priority=PROTOCOL['architectures']
 return sorted(totals,key=lambda r:(-r['mean_val_accuracy'],priority.index(r['architecture'])))[0]

def best_ridge(f,y,tr,va):
 trials=[]
 for a in PROTOCOL['alpha_grid']:
  m=fit_readout(f[tr],y[tr],a);score=accuracy(predict(m,f[va])['labels'],y[va])
  trials.append({'alpha':a,'val_accuracy':score,'training_mse':m['training_mse']})
 best=sorted(trials,key=lambda r:(-r['val_accuracy'],r['alpha']))[0]
 return best,trials

def raw_features(d):
 x=d['X']
 # Rounding removes floating summation-order roundoff as an order side channel.
 return {'raw_final':x[:,-1,:],'raw_bag':np.round(x.mean(1),12),'raw_ordered':x.reshape(len(x),-1)}

def prepare_data(ds):
 for task,d in ds.items():
  np.savez_compressed(ROOT/'data'/f'{task}.npz',X=d['X'],y=d['y'],groups=d['groups'],**d['splits'])
  manifest={k:v for k,v in d.items() if k not in ['X','y','groups','splits']}
  manifest.update(shape=list(d['X'].shape),split_sizes={k:len(v) for k,v in d['splits'].items()},
   X_sha256=hashlib.sha256(d['X'].tobytes()).hexdigest(),y_sha256=hashlib.sha256(d['y'].tobytes()).hexdigest(),
   splits={k:v.tolist() for k,v in d['splits'].items()})
  write_json(ROOT/'data'/f'{task}-manifest.json',manifest)

def select_phase():
 for p in ['data','models','results']:(ROOT/p).mkdir(exist_ok=True)
 write_json(ROOT/'protocol.json',PROTOCOL)
 ds=tasks();prepare_data(ds);records=[];bases=[]
 for task,d in ds.items():
  tr,va=d['splits']['train'],d['splits']['val'];y=d['y']
  for arch in PROTOCOL['architectures']:
   for seed in PROTOCOL['seeds']:
    t=time.perf_counter();f,timing=extract_features(d['X'],config(arch,seed),mode(task))
    best,trials=best_ridge(f,y,tr,va)
    record={'task':task,'architecture':arch,'seed':seed,**best,'trials':trials,'features':f.shape[1],
     'extraction':timing,'select_wall_s':time.perf_counter()-t}
    records.append(record);write_json(ROOT/'results/validation.json',{'protocol_sha256':protocol_hash(),'records':records,'baselines':bases})
    print(f"SELECT {task} {arch} seed={seed}: val={best['val_accuracy']:.4f} alpha={best['alpha']} seconds={record['select_wall_s']:.2f}",flush=True)
  raws=raw_features(d)
  for name,f in raws.items():
   best,trials=best_ridge(f,y,tr,va);bases.append({'task':task,'architecture':name,**best,'trials':trials,'features':f.shape[1]})
  trials=[]
  for c in PROTOCOL['svm_C_grid']:
   p=make_pipeline(StandardScaler(),SVC(C=c,kernel='rbf',gamma='scale'))
   p.fit(raws['raw_ordered'][tr],y[tr]);trials.append({'C':c,'val_accuracy':accuracy(p.predict(raws['raw_ordered'][va]),y[va])})
  bases.append({'task':task,'architecture':'raw_rbf',**sorted(trials,key=lambda r:(-r['val_accuracy'],r['C']))[0],'trials':trials,'features':raws['raw_ordered'].shape[1]})
 write_json(ROOT/'results/validation.json',{'protocol_sha256':protocol_hash(),'records':records,'baselines':bases})
 choices={}
 for task in ds:
  rows=[r for r in records if r['task']==task];ripple=[r for r in rows if r['architecture']!='tanh']
  choices[task]={'selected_ripple':select_architecture(ripple),'selected_neural':select_architecture(rows),
   'mix4_val_mean':float(np.mean([r['val_accuracy'] for r in rows if r['architecture']=='mix4']))}
 freeze={'protocol_sha256':protocol_hash(),'source_sha256':source_digest(),'created_utc':datetime.now(timezone.utc).isoformat(),
  'phase':'validation choices frozen before evaluate command','choices':choices,
  'records_sha256':hashlib.sha256((ROOT/'results/validation.json').read_bytes()).hexdigest()}
 write_json(ROOT/'results/choices-frozen.json',freeze)
 print('VALIDATION CHOICES FROZEN',json.dumps(choices),flush=True)

def wilson(correct,n):
 p=correct/n;z=1.959963984540054;den=1+z*z/n;center=(p+z*z/(2*n))/den
 half=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
 return [float(center-half),float(center+half)]
def metric(pred,y,groups=None):
 correct=int(np.sum(pred==y));result={'n':len(y),'correct':correct,'accuracy':correct/len(y)}
 if groups is None:return result|{'wilson95':wilson(correct,len(y))}
 groups=np.asarray(groups)
 if groups.shape!=np.asarray(y).shape:raise ValueError('group shape must match labels')
 unique=np.unique(groups);ok=np.asarray(pred)==y
 per_group=np.array([ok[groups==g].mean() for g in unique])
 r=np.random.default_rng(20261056)
 draws=per_group[r.integers(0,len(unique),(2000,len(unique)))].mean(1)
 return result|{'cluster_bootstrap95':np.quantile(draws,[.025,.975]).tolist(),'resampling_units':len(unique),
  'unit':'template groups','interval_scope':'exploratory, conditional on fitted model; percentile bootstrap, no multiplicity correction'}
def bootstrap_difference(a,b,groups):
 # a: seed-averaged correctness per example; paired baseline b same examples.
 diff=np.asarray(a)-np.asarray(b);unique=np.unique(groups)
 grouped=np.array([diff[groups==g].mean() for g in unique]);r=np.random.default_rng(20261014+42)
 draws=grouped[r.integers(0,len(grouped),(2000,len(grouped)))].mean(1)
 return {'difference':float(grouped.mean()),'bootstrap95':np.quantile(draws,[.025,.975]).tolist(),'resampling_units':len(grouped),
  'unit':'temporal template groups' if len(unique)<len(diff) else 'recorded images','repeats':2000}

def evaluate_phase():
 frozen=json.loads((ROOT/'results/choices-frozen.json').read_text())
 validation=json.loads((ROOT/'results/validation.json').read_text())
 if frozen['protocol_sha256']!=protocol_hash() or frozen['source_sha256']!=source_digest() or frozen['records_sha256']!=hashlib.sha256((ROOT/'results/validation.json').read_bytes()).hexdigest():
  raise ValueError('protocol, source or validation changed after freeze')
 ds=tasks();results=[];predictions=[];controls=[];raw_scores={};correctness={}
 for task,d in ds.items():
  tr=np.concatenate([d['splits']['train'],d['splits']['val']]);te=d['splits']['test'];y=d['y'];truth=y[te]
  score_groups=d['groups'][te] if task=='temporal' else None
  for rec in [r for r in validation['records'] if r['task']==task]:
   arch,seed=rec['architecture'],rec['seed'];f,timing=extract_features(d['X'],config(arch,seed),mode(task))
   started=time.perf_counter();model=fit_readout(f[tr],y[tr],rec['alpha']);fit_s=time.perf_counter()-started
   started=time.perf_counter();out=predict(model,f[te]);predict_ms=1000*(time.perf_counter()-started)
   pred=out['labels'];score=metric(pred,truth,score_groups)
   row={'task':task,'architecture':arch,'seed':seed,**score,'alpha':rec['alpha'],'features':f.shape[1],
    'trainable_parameters':model['trainable_parameters'],'training_mse':model['training_mse'],
    'untrained_training_mse':model['untrained_training_mse'],'fit_seconds':fit_s,
    'feature_extraction_ms_per_example':timing['elapsed_ms']/len(y),'readout_ms_per_example':predict_ms/len(te)}
   results.append(row);correctness[(task,arch,seed)]=(pred==truth).astype(float)
   predictions.append({'task':task,'architecture':arch,'seed':seed,'indices':te.tolist(),'prediction':pred.tolist(),'truth':truth.tolist()})
   if seed==PROTOCOL['deployment_seed'] and arch in {'mix3','mix4',frozen['choices'][task]['selected_ripple']['architecture']}:
    artifact={'task':task,'kind':'trained frozen-dynamics reservoir with supervised ridge readout','network':config(arch,seed),
     'mode':mode(task),'frames':d['X'].shape[1],'class_names':d['classes'],'readout':model,
     'protocol_sha256':protocol_hash(),'source_sha256':source_digest(),'new_run_test':score,
     'dataset_kind':d['kind'],'previously_studied':d.get('previously_studied',False),'writer_disjoint':False}
    write_json(ROOT/'models'/f'{task}-{arch}.json',artifact)
   # Prespecified genuine learning controls, fitted without seeing true test labels.
   if arch=='mix4':
    zero=np.full(len(te),model['classes'][0]);r=np.random.default_rng(seed+20261014)
    shuffled=fit_readout(f[tr],r.permutation(y[tr]),rec['alpha']);shpred=predict(shuffled,f[te])['labels']
    controls.append({'task':task,'architecture':arch,'seed':seed,'untrained':metric(zero,truth,score_groups),'shuffled_labels':metric(shpred,truth,score_groups)})
   print(f"TEST {task} {arch} seed={seed}: {score['correct']}/{len(te)} ({score['accuracy']:.4f})",flush=True)
  raw=raw_features(d)
  for rec in [r for r in validation['baselines'] if r['task']==task]:
   arch=rec['architecture'];started=time.perf_counter()
   if arch=='raw_rbf':
    model=make_pipeline(StandardScaler(),SVC(C=rec['C'],kernel='rbf',gamma='scale'))
    model.fit(raw['raw_ordered'][tr],y[tr]);pred=model.predict(raw['raw_ordered'][te])
    params={'C':rec['C'],'support_vectors':int(model[-1].n_support_.sum()),'classifier':'trained RBF SVM, not a Ripple neuron'}
   else:
    m=fit_readout(raw[arch][tr],y[tr],rec['alpha']);pred=predict(m,raw[arch][te])['labels'];params={'alpha':rec['alpha'],'trainable_parameters':m['trainable_parameters']}
   score=metric(pred,truth,score_groups);results.append({'task':task,'architecture':arch,'seed':None,**score,'features':rec['features'],**params,'fit_and_predict_s':time.perf_counter()-started})
   raw_scores[(task,arch)]=(pred==truth).astype(float)
   predictions.append({'task':task,'architecture':arch,'seed':None,'indices':te.tolist(),'prediction':pred.tolist(),'truth':truth.tolist()})
   print(f"TEST {task} {arch}: {score['correct']}/{len(te)} ({score['accuracy']:.4f})",flush=True)
  examples=[{'index':int(i),'input':d['X'][i].tolist(),'truth':int(y[i])} for i in te[:24]]
  write_json(ROOT/'data'/f'{task}-demo-examples.json',{'kind':d['kind'],'examples':examples,'class_names':d['classes']})
 comparisons=[]
 for task,d in ds.items():
  te=d['splits']['test'];groups=d['groups'][te]
  for arch in ['mix3','mix4',frozen['choices'][task]['selected_ripple']['architecture']]:
   if any(x.get('task')==task and x.get('candidate')==arch for x in comparisons):continue
   a=np.mean([correctness[(task,arch,s)] for s in PROTOCOL['seeds']],axis=0)
   for base in ['lif','delta','daughter','charlie','mix4_no_links','tanh','raw_ordered','raw_rbf']:
    b=raw_scores[(task,base)] if base.startswith('raw_') else np.mean([correctness[(task,base,s)] for s in PROTOCOL['seeds']],axis=0)
    comparisons.append({'task':task,'candidate':arch,'baseline':base,**bootstrap_difference(a,b,groups)})
 summary={'schema':'ripple-fusion-evidence-v1','protocol':PROTOCOL,'freeze':frozen,'results':results,'learning_controls':controls,'paired_comparisons':comparisons,
  'environment':{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'sklearn':sklearn.__version__,'linear_algebra_threads':2},
  'evidence_boundaries':{'digit_pixels':'recorded human handwriting; streamed representation is new software encoding',
   'temporal_signals':'new generated counterfactual sequences; no physical sensors',
   'timings':'actually executed local software elapsed times, not energy efficiency or target-device guarantees',
   'training':'readout fitted, intrinsic neuron kernels and recurrent/input weights frozen',
   'no_claims':['general reasoning','language model','consciousness','robotic operation','physical optical field measurement','universal architecture improvement']}}
 write_json(ROOT/'results/evidence.json',summary);write_json(ROOT/'results/test-predictions.json',predictions)
 print('EVIDENCE SAVED; NO TEST-DRIVEN TUNING',flush=True)

def main():
 p=argparse.ArgumentParser();p.add_argument('phase',choices=['select','evaluate']);p.add_argument('--engine',choices=['frozen','release'],default='frozen');args=p.parse_args()
 set_feature_engine(args.engine)
 with threadpool_limits(limits=2):
  if args.phase=='select':select_phase()
  else:evaluate_phase()
if __name__=='__main__':main()
