/** New JavaScript port of the frozen Charlie v2 step, tested against Python.
 * Fixed synaptic weights; no derivative-through-spike learning is claimed.
 */
const clip=(x,a,b)=>Math.min(b,Math.max(a,x));
export class CharlieNeuron{
 constructor(){
  this.p={capacitance:.5,leak:1,reversalExc:1.4,reversalInh:0,tauExc:.070,tauInh:.120,tauAdapt:1.8,adaptJump:.095,
   thresholdInitial:.45,thresholdLow:.15,thresholdHigh:1.1,tauRate:5,targetRate:1,thresholdEta:.018,refractoryS:.1,maxStep:.0025,
   excPulse:.28,inhPulse:.28,maxConductance:12};this.weights=[2,1.2,1.4];this.reset();
 }
 reset(){this.membrane=this.exc=this.inh=this.adapt=this.rate=this.refractory=this.time=0;this.theta=.45;this.count=0;}
 step(rgb,dt,{homeostasis=true,excPulses=0,inhPulses=0}={}){
  if(!Array.isArray(rgb)||rgb.length!==3||Array.from(rgb).some(x=>!Number.isFinite(x)||x<0||x>1)||!Number.isFinite(dt)||dt<=0||dt>.5)
   throw Error('invalid Charlie input');
  if(!Number.isInteger(excPulses)||!Number.isInteger(inhPulses)||excPulses<0||inhPulses<0||excPulses>8||inhPulses>8)throw Error('invalid pulses');
  const p=this.p;this.exc=clip(this.exc+excPulses*p.excPulse,0,p.maxConductance);
  this.inh=clip(this.inh+inhPulses*p.inhPulse,0,p.maxConductance);
  const n=Math.ceil(dt/p.maxStep),h=dt/n,events=[];
  const targetE=this.weights[0]*rgb[0]+this.weights[1]*rgb[1],targetI=this.weights[2]*rgb[2];
  for(let k=0;k<n;k++){
   const begin=this.time;
   this.exc=targetE+(this.exc-targetE)*Math.exp(-h/p.tauExc);
   this.inh=targetI+(this.inh-targetI)*Math.exp(-h/p.tauInh);
   this.adapt*=Math.exp(-h/p.tauAdapt);this.rate*=Math.exp(-h/p.tauRate);
   const resting=Math.min(h,this.refractory);this.refractory=Math.max(0,this.refractory-resting);
   if(resting>0)this.membrane=0;
   const available=h-resting;
   if(available>1e-14){
    const total=p.leak+this.exc+this.inh,eq=(p.reversalExc*this.exc+p.reversalInh*this.inh-this.adapt)/total;
    const u0=this.membrane,u1=eq+(u0-eq)*Math.exp(-available*total/p.capacitance);
    if(u1>=this.theta){
     const fraction=u1!==u0?clip((this.theta-u0)/(u1-u0),0,1):0;
     events.push(begin+resting+fraction*available);this.count++;this.rate+=1/p.tauRate;
     this.adapt+=p.adaptJump;this.membrane=0;this.refractory=p.refractoryS;
    }else this.membrane=Math.max(0,u1);
   }
   if(homeostasis)this.theta=clip(this.theta+p.thresholdEta*h*(this.rate-p.targetRate),p.thresholdLow,p.thresholdHigh);
   this.time=begin+h;
  }
  return{t:this.time,membrane:this.membrane,exc:this.exc,inh:this.inh,adapt:this.adapt,theta:this.theta,rate_hz:this.rate,
   refractory:this.refractory,events,count:events.length,total_events:this.count,weights:this.weights.slice()};
 }
}
