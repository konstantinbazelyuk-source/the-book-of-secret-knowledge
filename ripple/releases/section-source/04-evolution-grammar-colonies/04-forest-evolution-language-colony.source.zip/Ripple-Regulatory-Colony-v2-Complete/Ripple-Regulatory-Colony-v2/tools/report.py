"""Generate evidence tables and exact plots from executed experiment records."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle,FancyArrowPatch
ROOT=Path(__file__).resolve().parents[1]

def main():
 e=json.loads((ROOT/'results/evidence-corrected.json').read_text());rows=e['results']
 labels={'lif':'Original LIF','delta':'Delta','daughter':'Daughter','charlie':'Charlie conductance','mix3':'Three-type mixture','mix4':'Four-type mixture','mix4_no_links':'Four types, links off','tanh':'Tanh reservoir','raw_ordered':'Ordered-input ridge','raw_rbf':'Ordered-input RBF SVM'}
 methods=list(labels)
 summary={}
 for task in ['digits','temporal']:
  summary[task]={}
  for arch in methods:
   rs=[r for r in rows if r['task']==task and r['architecture']==arch]
   summary[task][arch]={'mean_accuracy':float(np.mean([r['accuracy'] for r in rs])),
    'each_accuracy':[r['accuracy'] for r in rs],'correct_each':[r['correct'] for r in rs],
    'n':rs[0]['n'],'features':rs[0]['features'],
    'trainable_parameters':rs[0].get('trainable_parameters'),
    'mean_feature_ms':float(np.mean([r.get('feature_extraction_ms_per_example',0) for r in rs]))}
 (ROOT/'results/summary.json').write_text(json.dumps(summary,indent=2))
 report=['# Ripple Fusion v1: measured software learning','',
 'A working supervised reservoir classifier built from selected Ripple neuron kernels. Source archives remain unchanged. The numerical neurons and input/recurrent connections are fixed; the trained readout coefficients are the learned component. No language model, consciousness, robot or physical light-field sensing has been demonstrated.','',
 '## Source selection','',
 'Found 98 Ripple filename matches and audited 25 representative archives. Four executable dynamic kernels were selected for controlled comparisons. Original LIF/Delta/Daughter files were copied byte-for-byte; Charlie was separately ported and checked against its frozen Python implementation on 140 frames containing 29 events. No archived pickles, joblib models or original installers were executed.','',
 '| Mechanism | Purpose in this experiment | Status |',
 '|---|---|---|',
 '| Original Ripple LIF v0.1 | Leaky accumulation, reset, refractory state, rate feedback | Unchanged source |',
 '| Charlie conductance v2 | Excitatory/inhibitory synaptic memory and adaptation | Tested JS port of unchanged Python source |',
 '| Delta v3 | Gated logarithmic temporal contrast and adaptation | Unchanged source; feedforward disabled |',
 '| Daughter v3.1 | Filtered photoreceptor / dendrite / soma cascade | Unchanged source defaults |','',
 'Quaternary telemetry, colony cloning/rule mutation, heuristic routing, quantum optics and orchestration were not substituted for task learning. Their negative results and scope are preserved in SOURCE_AUDIT.md. More files do not imply more distinct neuron types.','',
 '## What was genuinely learned','',
 'New coupling connects the previous-step membrane states through a sparse bounded adapter; it is new work, not inherited inter-neuron recurrence from Delta or Daughter. Digital input is projected into three bounded abstract channels. This is not optical calibration. Every independent sequence resets all state. There are 32 units and four exposed features per unit.','',
 'Fit training-only mean and standard deviation, form Z=(F-mu)/sigma, and minimize ||ZW + b - Y||² + alpha||W||² for one-hot training labels Y. The centered ridge system has a unique solution for alpha>0 and is solved by Cholesky, not by explicitly forming an inverse. Training only updates W/b and scaler statistics. Alpha and architecture selection used validation data. Intrinsic neuron equations are not trained end-to-end. Scores are uncalibrated decision values, not probabilities.','',
 'Digits use eight row-wise state snapshots, 1024 readout features and 10,250 fitted coefficients/biases. Temporal order uses only 128 final-state features and 774 fitted coefficients/biases. Counts are per model; frozen input/recurrent parameters are additional. Different feature semantics and nonlinearities remain a comparison limit despite equal unit/feature counts.','',
 '## Recorded and simulated inputs','',
 'Digits: 1,797 recorded 8x8 handwritten-digit examples supplied by scikit-learn, derived from UCI/NIST data. New split: 1,078 training, 359 validation and 360 test images. These images appeared in earlier Gen Beta studies. This is a new-run disjoint partition of previously studied data, not new writers or external validation. Pixel counts are not calibrated radiance.','',
 'Code order: new synthetic templates with six permutations of R/G/B pulses. All six cases in a template have identical unordered frame multisets and final frames. Templates are split 160/60/80: 960 training, 360 validation, 480 test sequences. The 80 test templates, rather than 480 independently authored worlds, are the resampling units. Labels and expected names are never passed to inference.','',
 '## Held-out results','',
 'Mean across seeds 11, 23, 47, 89 and 131. The same test partition is reused across seeds; these are not five independent datasets. All 80 neural validation runs and eight raw-baseline selections were completed before the choices-freeze record, followed by 88 prespecified test comparisons. No test-driven retuning occurred.','',
 '| Model | Recorded digits, 360 images | Simulated order, 480 sequences |',
 '|---|---:|---:|']
 for arch in methods:report.append(f"| {labels[arch]} | {100*summary['digits'][arch]['mean_accuracy']:.2f}% | {100*summary['temporal'][arch]['mean_accuracy']:.2f}% |")
 report+=['','Validation selected Charlie for digits and the four-type mixture for temporal order. The test ranked Daughter slightly above Charlie/mixed on digits; the frozen selection was not changed after observing that result. The standalone uses seed 11, selected in advance, and includes mixed and validation-selected models. It does not average the five seeds during prediction.','',
 '| Learning control for four-type mixture | Digits | Simulated order |','|---|---:|---:|']
 for key,title in [('untrained','Zero/untrained readout'),('shuffled_labels','Shuffled training labels')]:
  scores=[100*np.mean([r[key]['accuracy'] for r in e['learning_controls'] if r['task']==t]) for t in ['digits','temporal']]
  report.append(f'| {title} | {scores[0]:.2f}% | {scores[1]:.2f}% |')
 report+=['','These controls and lower fitted training losses establish that the decision parameters were learned from training labels. They do not establish general reasoning.','',
 '## Exploratory comparisons: favorable, neutral and negative','',
 'Paired intervals below are exploratory, unadjusted percentile bootstrap intervals. There is no multiple-comparison correction or designated confirmatory primary contrast.','',
 'The four-type mixture outperformed the original-LIF-only bank by 2.11 percentage points on digits (paired bootstrap 95% interval +1.22 to +3.06 points), and 2.75 points on simulated order (+2.12 to +3.42). Intervals condition on the fixed models/data protocol; they are not guarantees on future tasks.','',
 'It did not establish an advantage over Daughter: -0.33 points on digits, interval -1.22 to +0.56; exactly equal mean order accuracy, interval -0.17 to +0.17. Turning coupling off changed accuracy only slightly; both paired intervals included zero. A useful coupling advantage is therefore unproven in these tasks.','',
 'The strong raw-pixel SVM beat the four-type mixture on digits: 98.61% versus 95.83%. Ordered raw ridge/SVM achieved 100% on the synthetic order task by retaining the complete sequence. The mixed readout achieved 99.92% using only final neural state. This establishes bounded task memory, not a unique or universally better way to solve order. Final-frame and rounded bag-mean raw baselines scored exactly 16.67%, as designed.','',
 '## What can be run now','',
 'Open web/Ripple-Fusion-AI.html offline. It contains actual source kernels and saved fitted JSON weights. Load recorded held-out examples, draw an 8x8 digit, or classify code sequences. Custom drawings and new signals can fall outside the training distribution and can be misclassified. No expected label enters the prediction API.','',
 'Node inference needs no model service: node web/infer_cli.mjs models/temporal-mix4.json data/temporal-demo-examples.json. Python/Node benchmark commands, fitting data, fixed protocol, raw predictions, model files, source hashes and tests are included.','',
 'Measured batch feature-extraction timings include local numerical execution and binary output writing, exclude input-JSON parsing and process startup, and are not phone, hardware, energy or real-time guarantees. Browser-compatible inference was tested in Node against the modular engine. A graphical browser was unavailable here; visual UI execution is not claimed.','',
 '## Evidence classes and remaining work','',
 '- Measured software: fitting, predictions, held-out correctness, controls, source parity and local runtime.',
 '- Recorded input: public handwritten-digit data, with previously studied dataset disclosed.',
 '- Simulated: all neuron states/events and synthetic temporal color sequences.',
 '- Calculated: matrix solution, feature/parameter counts and input/coupling bounds.',
 '- Proposed: physical sensor integration, robot control, end-to-end synaptic training, unseen-domain generalization, larger networks and language tasks.','',
 'There is no global-optimum search over all possible neuron types, neuron counts or tasks. No global dynamical stability proof is supplied. Inputs are bounded, state conformance checks ran, and no nonfinite state occurred in the executed benchmarks. Crossing solvers retain their original finite-grid/microstep approximation limits.','',
 '## Sources and reuse','',
 '1. Maass, Natschlaeger & Markram (2002), liquid state computation and trained readouts: https://igi-web.tugraz.at/people/Abstracts/MaassETAL:01a/',
 '2. Diverse-timescale reservoir research (task-specific motivation, not a guarantee): https://arxiv.org/abs/2108.09446',
 '3. scikit-learn load_digits documentation: https://scikit-learn.org/stable/modules/generated/sklearn.datasets.load_digits.html',
 '4. Alpaydin & Kaynak (1998), UCI Optical Recognition of Handwritten Digits, CC BY 4.0: https://doi.org/10.24432/C50P49',
 '5. Ridge objective/reference: https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.Ridge.html','',
 'Original integration code, reports and synthetic data are released under CC0-1.0. Included recorded digit data retains CC BY 4.0 attribution; source kernels keep their original notices. Keep the dataset credit with shared model material. Original Ripple concept: Constantin x.']
 report+=['','## Resumed release: executable RGB genome','',
  'RGB now also encodes a digital inherited blueprint independently of light input. Five exact RGB byte triples compile into architecture, size, input dimension, timestep, coupling, seed, feature mode and sequence length. Matching trained weights carry learned task knowledge; a changed blueprint rejects the parent readout. Mutation and crossover are executable, bounded operations. No gain from genetic search or from representing the code as color has been established. See RGB_GENOME.md for the complete map and CLI.','',
  'Two newer archives, Genetic Weights v1.7 and ClusterNeuron v2.4 AddOn, were inspected. Four preserved parent hashes matched; 12 genetic composition tests passed. Archive-reported search/camera performance was not independently rerun or used to retune the opened Fusion tests. See NEWER_RESOURCES_AND_RESEARCH.md.','',
  'Before delivery, review corrected sparse-array validation, pinned matplotlib, and replaced naive temporal row intervals in the derived evidence with template-group bootstrap intervals. The original raw evidence remains for provenance; use results/evidence-corrected.json for uncertainty. Control intervals are omitted where individual control predictions were not saved. Perfect observed accuracy can give a degenerate bootstrap interval and does not guarantee future accuracy.','']
 verification=ROOT/'results/release-verification.json'
 if verification.exists():
  v=json.loads(verification.read_text());delta=max(r['python_JS_max_score_delta'] for r in v['models'])
  report += [f"Full release verification executed {v['tested_model_sample_pairs']:,} shipped-model/test-example pairs. Every legal-input feature matched the preserved experiment engine exactly and all labels matched recorded predictions. Maximum Python/JavaScript score difference: {delta:.3g}. The deployed engine patch changes validation only. These are repeated inference checks, not new independent test data.",'']
 report+=['The standalone uses seed 11: four-type digits 344/360 (95.56%), four-type simulated order 480/480 (100%). The five-seed means in the main table are experimental comparisons; the page does not deploy a five-model ensemble.','',
  'Source, models, exact data partitions, all raw predictions, code, tests, two independent source/evaluation audits and final review notes are included. Share under the supplied reuse terms with the recorded-data credit.']
 (ROOT/'docs/RESULTS_AND_LIMITS.md').write_text('\n'.join(report)+'\n')
 plt.rcParams.update({'font.family':'DejaVu Sans','axes.spines.top':False,'axes.spines.right':False})
 fig,axes=plt.subplots(1,2,figsize=(13.6,7.2),facecolor='#f5f6f1')
 for ax,task,title in zip(axes,['digits','temporal'],['Recorded handwritten digits','Simulated code order']):
  ax.set_facecolor('#f5f6f1')
  for i,arch in enumerate(methods):
   a=np.asarray(summary[task][arch]['each_accuracy'])*100
   color='#237552' if arch=='mix4' else '#65747e'
   ax.scatter(a,i+np.linspace(-.12,.12,len(a)),s=20,color=color,alpha=.6)
   ax.scatter([a.mean()],[i],s=64,marker='D',color=color,edgecolor='white',linewidth=.8,zorder=4)
   ax.text(100.65,i,f'{a.mean():.2f}%',va='center',fontsize=9,color=color)
  ax.set_yticks(range(len(methods)),[labels[a] for a in methods]);ax.invert_yaxis();ax.set_xlim(90,102.4)
  ax.set_xticks([90,92,94,96,98,100]);ax.set_xlabel('Held-out accuracy (%) - zoomed range');ax.grid(axis='x',color='#d9e0da',lw=.6)
  ax.set_title(title,fontsize=14,fontweight='bold',pad=16);ax.tick_params(labelsize=9)
 fig.suptitle('RIPPLE FUSION / executed learning comparisons',fontsize=20,fontweight='bold',x=.04,ha='left',color='#153341')
 fig.text(.04,.045,'Dots: individual fixed seeds. Diamonds: mean. All seeds share the same test set. Raw baselines: one fit.',fontsize=10,color='#526770')
 fig.text(.04,.015,'More neuron types did not beat every simpler model. Digits were previously studied; code sequences are synthetic.',fontsize=10,color='#526770')
 fig.tight_layout(rect=[.01,.075,.99,.94]);fig.savefig(ROOT/'results/comparison.png',dpi=170);plt.close(fig)
 fig=plt.figure(figsize=(12.4,7.2),facecolor='#f5f6f1');ax=fig.add_axes([.03,.1,.56,.78]);ax.set_xlim(-1.3,1.3);ax.set_ylim(-1.3,1.3);ax.axis('off')
 colors=['#2f79a4','#9b6c3e','#735ba3','#287c59'];names=['Original LIF','Delta','Daughter','Charlie'];n=32
 positions=[(np.cos(2*np.pi*i/n),np.sin(2*np.pi*i/n)) for i in range(n)]
 for dst in range(n):
  for src,sign in [((dst+n-1)%n,1),((dst+3)%n,-1)]:
   a=np.array(positions[src])*.92;b=np.array(positions[dst])*.92
   ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=6,connectionstyle='arc3,rad=.08',lw=.55,color='#819892' if sign==1 else '#bf8f88',alpha=.65))
 for i,(x,y) in enumerate(positions):
  ax.add_patch(Circle((x,y),.070,color=colors[i%4],zorder=3));ax.text(x,y,str(i),ha='center',va='center',color='white',fontsize=7,zorder=4)
 ax.text(0,.11,'32 numerical neurons',ha='center',fontsize=17,fontweight='bold',color='#153341')
 ax.text(0,-.11,'8 per source family',ha='center',fontsize=12,color='#526770')
 fig.text(.64,.80,'FROZEN DYNAMICS',fontsize=12,fontweight='bold',color='#153341')
 for i,(name,color) in enumerate(zip(names,colors)):fig.text(.64,.74-i*.058,'●  '+name,fontsize=13,color=color)
 fig.text(.64,.46,'NEW NETWORK ADAPTER',fontsize=12,fontweight='bold',color='#153341')
 fig.text(.64,.405,'8 digital inputs → 3 abstract channels/unit\nOne-step-delayed membrane links\nTwo incoming links/unit, weights ±0.06\nMaximum absolute row sum: 0.12',fontsize=11,color='#526770',linespacing=1.6,va='top')
 fig.text(.64,.23,'LEARNED READOUT',fontsize=12,fontweight='bold',color='#237552')
 fig.text(.64,.175,'Training-only scaling + ridge fit\nDigits: 1,024 trajectory features → 10 labels\nOrder: 128 final-state features → 6 labels',fontsize=11,color='#526770',linespacing=1.6,va='top')
 fig.text(.04,.94,'RIPPLE FUSION / four-type network actually executed',fontsize=19,fontweight='bold',color='#153341')
 fig.text(.04,.035,'Virtual neuron states. Fixed source equations. Readout weights learned from labels. No physical brain or optical apparatus.',fontsize=10,color='#526770')
 fig.savefig(ROOT/'results/architecture.png',dpi=170);plt.close(fig)
 print('generated evidence report, summary and two exact plots')
if __name__=='__main__':main()
