"""Verify every shipped model on its entire recorded test partition; no fitting."""
from pathlib import Path
import tempfile,json,subprocess,sys,hashlib
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from src.readout import predict
from src.bridge import set_feature_engine,source_digest

def main():
 predictions=json.loads((ROOT/'results/test-predictions.json').read_text())
 lookup={(p['task'],p['architecture'],p['seed']):p for p in predictions}
 request={'tasks':{},'models':[]};data={}
 for task in ['digits','temporal']:
  d=np.load(ROOT/'data'/f'{task}.npz');data[task]=d
  request['tasks'][task]={'input':d['X'][d['test']].tolist()}
 for p in sorted((ROOT/'models').glob('*.json')):request['models'].append({'key':p.stem,'file':str(p)})
 with tempfile.TemporaryDirectory(prefix='ripple-model-verify-') as tmp:
  tmp=Path(tmp);(tmp/'request.json').write_text(json.dumps(request))
  subprocess.run(['node',str(ROOT/'tools/verify_models.mjs'),str(tmp/'request.json'),str(tmp)],check=True)
  rows=json.loads((tmp/'node-results.json').read_text());summary=[]
  for r in rows:
   a=json.loads((ROOT/'models'/f"{r['key']}.json").read_text())
   f=np.fromfile(r['feature_file'],dtype='<f8').reshape(r['rows'],r['columns']);py=predict(a['readout'],f)
   scores=np.array(r['scores']);error=float(np.max(np.abs(py['scores']-scores)))
   if error>1e-10 or not np.array_equal(py['labels'],r['labels']):raise AssertionError('Python/JS readout parity')
   old=lookup[(a['task'],a['network']['architecture'],a['network']['seed'])]
   if not np.array_equal(r['labels'],old['prediction']):raise AssertionError('recorded prediction mismatch')
   r.pop('feature_file');r.pop('scores');r.pop('labels')
   r.update(python_JS_max_score_delta=error,all_labels_equal_recorded_test_predictions=True,
    correct=int(np.sum(py['labels']==np.array(old['truth']))))
   summary.append(r)
 set_feature_engine('frozen');frozen=source_digest();set_feature_engine('release');release=source_digest()
 result={'kind':'executed software verification; no fitting or test-driven selection',
  'frozen_engine_sha256':frozen,'release_engine_sha256':release,
  'release_patch':'Dense-array input validation only; original engine retained for exact experiment reproduction.',
  'tested_model_sample_pairs':sum(r['rows'] for r in summary),'models':summary,
  'genome_scope':'Exact executable configuration; altered seed affects features; mutation accuracy not evaluated.',
  'graphical_browser_tested':False}
 (ROOT/'results/release-verification.json').write_text(json.dumps(result,indent=2,allow_nan=False))
 print('Verified',result['tested_model_sample_pairs'],'model/sample pairs, all predictions unchanged; max Python/JS score delta',max(r['python_JS_max_score_delta'] for r in summary))
if __name__=='__main__':main()
