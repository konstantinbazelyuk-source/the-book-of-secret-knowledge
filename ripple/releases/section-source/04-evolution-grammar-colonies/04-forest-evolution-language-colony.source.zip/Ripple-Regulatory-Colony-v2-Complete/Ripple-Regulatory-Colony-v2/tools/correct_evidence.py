"""Derive grouped uncertainty without changing fits, labels or predictions.

The untouched original experiment records remain in results/evidence.json.
"""
from pathlib import Path
import json,sys,copy,shutil,hashlib
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from src.benchmark import metric

def main():
 original=ROOT/'results/evidence.json';e=copy.deepcopy(json.loads(original.read_text()))
 predictions=json.loads((ROOT/'results/test-predictions.json').read_text())
 lookup={(p['task'],p['architecture'],p['seed']):p for p in predictions}
 data=np.load(ROOT/'data/temporal.npz');corrections=[]
 for row in e['results']:
  if row['task']!='temporal':continue
  p=lookup[(row['task'],row['architecture'],row['seed'])]
  score=metric(np.array(p['prediction']),np.array(p['truth']),data['groups'][p['indices']])
  old=row.pop('wilson95',None);row.update(score)
  corrections.append({'architecture':row['architecture'],'seed':row['seed'],'removed_naive_row_wilson95':old})
 for c in e['learning_controls']:
  if c['task']=='temporal':
   for name in ['untrained','shuffled_labels']:
    c[name].pop('wilson95',None)
    c[name]['interval_note']='No cluster interval supplied: individual control predictions were not saved. Accuracy counts remain measured.'
 for c in e['paired_comparisons']:
  c['interval_scope']='exploratory paired percentile bootstrap conditional on fixed models/data; no multiple-comparison correction'
 e['reporting_correction']={'original_evidence_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),
  'fit_or_predictions_changed':False,'reason':'Temporal rows share 80 templates. Naive binomial intervals replaced by template bootstrap for saved test predictions; omitted for controls.',
  'corrections':corrections}
 (ROOT/'results/evidence-corrected.json').write_text(json.dumps(e,indent=2,allow_nan=False))
 backup=ROOT/'repro/original-models';backup.mkdir(parents=True,exist_ok=True)
 for f in (ROOT/'models').glob('temporal-*.json'):
  a=json.loads(f.read_text());key=('temporal',a['network']['architecture'],a['network']['seed'])
  if not (backup/f.name).exists():shutil.copyfile(f,backup/f.name)
  p=lookup[key];a['new_run_test']=metric(np.array(p['prediction']),np.array(p['truth']),data['groups'][p['indices']])
  a['reporting_note']='Grouped uncertainty corrected after review; fitted weights and prediction counts unchanged.'
  f.write_text(json.dumps(a,indent=2,allow_nan=False))
 print('Derived grouped uncertainty for',len(corrections),'temporal test rows; original experiment record retained.')
if __name__=='__main__':main()
