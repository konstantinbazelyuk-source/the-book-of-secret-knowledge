"""Build a standalone offline HTML containing actual frozen kernels and learned weights."""
from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parents[1]

def module(path,name,exports,preamble=''):
 s=(ROOT/path).read_text()
 s=re.sub(r'^import .*?;\s*$', '',s,flags=re.MULTILINE)
 s=re.sub(r'\bexport\s+(?=const |function |class )','',s)
 return f'const {name}=(()=>{{\n{preamble}\n{s}\nreturn {{{exports}}};\n}})();\n'

def build():
 models={p.stem:json.loads(p.read_text()) for p in (ROOT/'models').glob('*.json')}
 if not models:raise RuntimeError('trained model JSON files are required')
 demos={t:json.loads((ROOT/'data'/f'{t}-demo-examples.json').read_text()) for t in ['digits','temporal']}
 evidence=json.loads((ROOT/'results/evidence-corrected.json').read_text())
 script=(ROOT/'vendor/legacy/ripple-core.js').read_text()+'\n'
 script+=module('vendor/daughter/vault/delta/photometry.mjs','Photo','beerLambert,srgbDecode')
 script+=module('vendor/daughter/vault/delta/delta-neuron.mjs','Delta','DeltaRippleNeuron,deltaOpticalInput,encodeDeltaSymbol','const {beerLambert,srgbDecode}=Photo;')
 script+=module('vendor/daughter/src/triplet-neuron.mjs','Daughter','DaughterTripletNeuron','const {deltaOpticalInput,encodeDeltaSymbol}=Delta;')
 script+=module('src/charlie.mjs','Charlie','CharlieNeuron')
 script+=module('src/network.mjs','Engine','FeatureNetwork,extractSequence','const {DeltaRippleNeuron}=Delta;const {DaughterTripletNeuron}=Daughter;const {CharlieNeuron}=Charlie;')
 script+=module('web/predict.mjs','Readout','predictArtifact,predictReadout,validateReadout')
 script+=module('genome/codec.mjs','Genome','encodeGenome,decodeGenome,mutateGenome,crossGenomes,predictGenome',
  'const {FeatureNetwork,extractSequence}=Engine;const ARCHITECTURES='+json.dumps(['lif','delta','daughter','charlie','mix3','mix4','mix4_no_links','tanh'])+';const {predictArtifact,validateReadout}=Readout;')
 script+='const models='+json.dumps(models,separators=(',',':'))+';\n'
 script+='const demos='+json.dumps(demos,separators=(',',':'))+';\n'
 script+='const evidence='+json.dumps({'results':evidence['results'],'choices':evidence['freeze']['choices'],'controls':evidence['learning_controls']},separators=(',',':'))+';\n'
 script+="globalThis.RippleFusion={models,demos,evidence,infer:(key,input)=>Readout.predictArtifact(models[key],input,Engine.extractSequence),Engine,Genome};\n"
 script+=(ROOT/'web/ui.js').read_text()
 html=(ROOT/'web/template.html').read_text().replace('/* TRAINED_MODEL_BUNDLE */',script)
 output=ROOT/'web/Ripple-Fusion-AI.html';output.write_text(html);print(output,len(html.encode()))
if __name__=='__main__':build()
