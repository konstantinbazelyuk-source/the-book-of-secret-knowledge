import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {extractSequence as release} from '../src/network.mjs';
import {extractSequence as frozen} from '../repro/frozen-engine/src/network.mjs';
import {predictArtifact} from '../web/predict.mjs';
import {encodeGenome,decodeGenome,predictGenome,mutateGenome} from '../genome/codec.mjs';
import {packModel} from '../genome/bundle.mjs';
const [input,out]=process.argv.slice(2),request=JSON.parse(fs.readFileSync(input,'utf8'));
fs.mkdirSync(out,{recursive:true});const results=[],genomeDir=new URL('../genomes/',import.meta.url);
fs.mkdirSync(genomeDir,{recursive:true});
for(const item of request.models){
 const a=JSON.parse(fs.readFileSync(item.file,'utf8')),g=encodeGenome(a),bp=decodeGenome(g);
 const features=[],scores=[],labels=[];let same=true;
 for(const seq of request.tasks[a.task].input){
  const f=release(seq,bp.network,bp.mode),old=frozen(seq,a.network,a.mode);
  if(f.length!==old.length||f.some((v,j)=>v!==old[j]))same=false;
  features.push(...f);const p=predictArtifact(a,seq,release);scores.push(p.scores);labels.push(p.label);
 }
 if(!same)throw Error('legal-input feature parity failed: '+item.key);
 const bytes=Buffer.alloc(features.length*8);features.forEach((v,i)=>bytes.writeDoubleLE(v,i*8));
 const featureFile=path.join(out,item.key+'.f64');fs.writeFileSync(featureFile,bytes);
 const first=request.tasks[a.task].input[0],child=mutateGenome(g,{seed:a.network.seed+1});
 const childBp=decodeGenome(child),fa=release(first,bp.network,bp.mode),fb=release(first,childBp.network,childBp.mode);
 const effect=Math.sqrt(fa.reduce((s,v,j)=>s+(v-fb[j])**2,0));
 const pg=predictGenome(g,a,first),pr=predictArtifact(a,first,release);
 if(JSON.stringify(pg)!==JSON.stringify(pr)||!(effect>0))throw Error('genome parity or mutation influence failed');
 fs.writeFileSync(new URL(item.key+'.rgb.json',genomeDir),JSON.stringify(g,null,2)+'\n');
 fs.writeFileSync(new URL(item.key+'.ripple.json',genomeDir),JSON.stringify(packModel(a),null,2)+'\n');
 results.push({key:item.key,task:a.task,rows:labels.length,columns:a.readout.mean.length,labels,scores,
  feature_file:featureFile,features_sha256:createHash('sha256').update(bytes).digest('hex'),
  release_equals_frozen_every_feature:true,rgb_blueprint_equals_model:true,
  first_sample_mutation_feature_L2:effect,mutation:{seed:a.network.seed+1,accuracy:'not evaluated'}});
 console.log('verified exact engine parity:',item.key,labels.length,'test samples');
}
fs.writeFileSync(path.join(out,'node-results.json'),JSON.stringify(results));
