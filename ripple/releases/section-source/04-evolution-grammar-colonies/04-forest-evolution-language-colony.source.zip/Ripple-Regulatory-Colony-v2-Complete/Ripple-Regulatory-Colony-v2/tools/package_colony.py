"""Package runnable source, fitted model and evidence without redundant caches."""
from pathlib import Path
import zipfile,hashlib,json,shutil
ROOT=Path(__file__).resolve().parents[1]
OUTPUT=ROOT.parent/'output'
def main():
 OUTPUT.mkdir(exist_ok=True)
 excluded={'docs/library-source-identities.json','results/selection-log.txt','results/evaluation-console.txt','colony/artifacts/model.json'}
 def keep(p):
  rel=p.relative_to(ROOT)
  return p.is_file() and not any(part in {'.git','cache','__pycache__','.superpowers'} for part in rel.parts) and str(rel) not in excluded and p.suffix!='.pyc'
 files=sorted(p for p in ROOT.rglob('*') if keep(p));manifest=[]
 package=OUTPUT/'Ripple-Regulatory-Colony-v2-Complete.zip'
 with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in files:
   rel=p.relative_to(ROOT).as_posix();data=p.read_bytes();manifest.append(hashlib.sha256(data).hexdigest()+'  '+rel)
   z.writestr('Ripple-Regulatory-Colony-v2/'+rel,data)
  z.writestr('Ripple-Regulatory-Colony-v2/SHA256SUMS.txt','\n'.join(manifest)+'\n')
 copies={
  'colony/artifacts/model-sealed.json':'Ripple-Regulatory-Colony-v2-Model.json',
  'colony/RESULTS.md':'Ripple-Regulatory-Colony-v2-Results.md',
  'colony/ARCHITECTURE.md':'Ripple-Regulatory-Colony-v2-Architecture.md',
  'colony/SCIENTIFIC_BASIS.md':'Ripple-Regulatory-Colony-v2-Scientific-Basis.md'}
 for src,name in copies.items():shutil.copyfile(ROOT/src,OUTPUT/name)
 record={'zip':str(package),'included_files':len(files),'zip_bytes':package.stat().st_size,
  'zip_sha256':hashlib.sha256(package.read_bytes()).hexdigest(),'excluded_redundancy':'Unsealed model copy omitted; sealed artifact contains every fitted value. Caches/internal identity/partial logs omitted.'}
 (ROOT.parent/'tmp/colony-package-record.json').write_text(json.dumps(record,indent=2));print(json.dumps(record,indent=2))
if __name__=='__main__':main()
