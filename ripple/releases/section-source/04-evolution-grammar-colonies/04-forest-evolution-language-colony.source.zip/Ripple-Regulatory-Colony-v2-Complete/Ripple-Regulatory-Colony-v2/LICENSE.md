# Reuse terms

Original integration code, original explanatory text and synthetic temporal data in this package are dedicated to the public domain under CC0-1.0:
https://creativecommons.org/publicdomain/zero/1.0/

Immutable copied Ripple kernel files retain their existing source notices. The original concept credit is Constantin x.

The recorded handwritten digit data is separate: E. Alpaydin & C. Kaynak (1998), Optical Recognition of Handwritten Digits, UCI Machine Learning Repository, https://doi.org/10.24432/C50P49. UCI specifies CC BY 4.0: https://creativecommons.org/licenses/by/4.0/. Data here is the scikit-learn bundled 1,797-image subset normalized from 0..16 to 0..1 and reshaped as row sequences. Retain this attribution and transformation description with shared recorded data and associated trained model material.

NumPy, SciPy, scikit-learn and their dependencies retain their own terms and are not embedded as library source in this package. No external pretrained model weights are included.
