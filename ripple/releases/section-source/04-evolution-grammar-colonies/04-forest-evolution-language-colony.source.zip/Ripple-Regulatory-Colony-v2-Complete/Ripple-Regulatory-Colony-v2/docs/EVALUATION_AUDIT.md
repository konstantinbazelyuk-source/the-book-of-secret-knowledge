# Ripple evaluation audit — proposed protocol

This is an internal design audit, not an executed benchmark. No models were trained in this audit.

## Existing evidence and consequences

The supplied `Ripple-Gen-Beta-v2.1` already studied all 1,797 sklearn digit observations. It published a 1,078/359/360 split with seed `20311013`: pixel RBF SVC and raw-plus-Ripple each obtained 354/360, Ripple-only obtained 327/360, and 3-NN obtained 355/360. These archival numbers are not new measurements. The archive calls 3-NN “nontrainable”; it is still a supervised, label-dependent classifier because fitting stores labeled observations. Do not use it as a no-learning control.

A distinct split is appropriate for a new implementation, but call it a new within-experiment held-out partition of an already studied dataset, not independent external validation. There are no writer identifiers in the packaged sklearn data, so no writer-disjoint claim is available. Raster rows are an imposed sequence of a static image, not recorded camera time or RGB spectra.

## Freeze before fitting

1. Save dataset hash, exact indices, class counts, input mapping, reset semantics, model families, feature definitions, candidate grids, primary comparison, and complete seed list before any test prediction or test metric. Use a distinct fixed digit split seed, e.g. `20261014`, with stratified 60/20/20 partitions. Never search for a split with better results.
2. Prespecify reservoir/projection seeds `[11, 23, 47, 89, 131]`. Run all of them, report all results and mean/spread; do not select the best seed. A fixed split plus repeated initialization seeds measures initialization variation, not five independent datasets.
3. Fit normalization, clipping thresholds chosen from data, PCA/whitening, feature pruning, weights and early-stopping rules only on training data. Select every tunable choice only on validation. Fit the final readout on train plus validation only after choices are frozen. If calibration is needed, reserve separate calibration data; otherwise present scores as uncalibrated scores.
4. Freeze all models and predictions before scoring their tests. Test results may be reported as negative findings but may not trigger another architecture search on the same test.

## Models and controls

Use the same partitions, labels, loss/readout class, regularization candidates and data exposure for directly comparable models:

- Majority-class classifier; random/untrained readout control.
- Raw pixels plus a trained linear readout.
- Raw-pixel RBF SVC as a strong nonlinear comparator, with a small declared validation grid (e.g. 3 C values × 3 gamma values).
- Conventional tanh reservoir/random-feature comparator with the same total units, sequence input, final/pooled feature rule and trained readout. Report units, output dimensions, trained parameters, fixed parameters and actual costs.
- Ripple features only; raw plus Ripple; full heterogeneous Ripple; strongest homogeneous family selected on validation. Compare heterogeneous and homogeneous models at fixed total unit count so diversity is not confounded with additional capacity.
- Remove each neuron family, disable inter-neuron recurrence, disable homeostasis/adaptation only where the source permits it, and remove any added preprocessing improvement. Retrain and reselect readout regularization for each ablation. Masking inputs only after training creates a distribution shift and is not the main ablation.
- Shuffle training labels without changing test labels or split. Repeat a few declared permutations. Chance-like held-out results are a leakage check; a high training score is allowed to reflect memorization. A no-label control must not store labeled examples, unlike k-NN.

Equal readout regularization grids do not make unlimited Ripple architecture tuning fair. Record the candidate count and time for each model. A raw-plus-Ripple result alone cannot establish that neural dynamics contribute: raw pixels may carry all the prediction signal. Removal plus retraining is needed. More neuron types can add redundant/noisy dimensions, increase variance, change the geometry seen by the readout and cost more; they have no automatic advantage.

## Temporal benchmark without shortcuts

Prefer command order over simple delayed XOR. Two isolated binary bits have XOR equal to a function of their unordered sum, so an unordered pooling baseline can solve that version of XOR.

One small reproducible simulated task is: 24 frames, two distinct normalized cue triples A/B at random early/late positions, label determined by A-before-B versus B-before-A, low-amplitude label-independent blue-channel distractors, and a fixed blank final sentinel. For each latent template, create both orders with exactly the same positions, distractors, final frame and frame multiset. Use 600 training, 150 validation and 250 test templates (1,200/300/500 sequences). Split complete templates and their counterfactual twins together; generate each partition with independent declared randomness and hash-check for duplicates. Randomly interleave labels so file/index parity cannot act as a feature.

For the main temporal claim, the learned classifier receives only the final native neural/recurrent state after the sentinel. Do not concatenate time-indexed snapshots, raw sequence frames, or externally accumulated pooled features in this main model. If cumulative counters or an external filter are exposed, disclose that additional memory. Reset all membrane, adaptation, rate, threshold, recurrent trace, counters and input-adapter states at each sequence boundary.

Final-frame and permutation-invariant bag models see identical inputs for opposing-label twins, so each must achieve exactly 50% overall accuracy on a complete balanced test-pair set. Check equality of their actual extracted features, not merely equality of means. Add flattened ordered logistic and RBF baselines: those can exploit sequence order directly and expose whether the reservoir offers any benefit over ordinary supervised features. Add a final-state tanh reservoir under the same unit/feature budget. A no-recurrence model can still remember through each neuron's intrinsic dynamics; to test absence of temporal memory, reset all intrinsic states every frame and use only the final output.

Order success demonstrates a narrow simulated temporal classification ability. It is not natural-language understanding or neural reasoning. Longer delays or unseen positions can be a separately prespecified simulated distribution-shift challenge, without using its scores to tune the model.

## Metrics and uncertainty

Report train/validation/test accuracy, balanced accuracy, macro F1, confusion matrices, complete per-example predictions and hashes, unit/feature/parameter counts, feature extraction time, fitting time, inference time, peak memory or a clearly labeled estimate, model size, numerical bounds and all failures. Compare costs on the same hardware/thread settings and include feature extraction in inference cost.

Use paired comparisons on identical examples. Report paired bootstrap intervals for the primary accuracy difference; resample latent templates for the paired temporal task. On digits, repeated seeds use the same test images and must not be pooled as `five × test_size` independent observations. Separate example uncertainty from seed variation. If several superiority claims are made, predeclare them and correct their inferential comparisons; otherwise make one primary claim and label other comparisons exploratory. Ordinary image-level intervals cannot account for unknown writer clustering.

## Failure and claim gates

- Stop the experiment as invalid if partitions overlap, augmentation twins cross partitions, inference imports evaluator labels/rules, data-fitted transforms access validation/test during fitting, states cross example boundaries, or test feedback drives retuning.
- Stop the affected model for nonfinite states/weights, illegal inputs, uncontrolled numerical divergence, or accelerated-kernel mismatch against the preserved source on representative and boundary cases. Check bounded output and time-step refinement; do not claim analytic equivalence or a mathematical stability guarantee solely because one run stays finite.
- A final-frame or bag model above 50% on complete counterfactual pairs signals a construction/extraction leak. A shuffled-label control consistently beyond a prespecified chance uncertainty bound requires investigation before crediting the model.
- Claim “trained” only when saved label-dependent weights demonstrably differ from initialization and predict held-out observations. State exactly which parameters learned; a fixed Ripple kernel with learned readout is a trained supervised classifier, not end-to-end trained spiking dynamics.
- Claim “improvement” only when the prespecified held-out comparison supports the stated gain. If the model does not beat the strong baseline, report that result and still deliver the functioning trained model. Do not redefine success or hide inferior variants.
- Digit and simulated order performance do not validate perception in a camera stream, calibrated optics, autonomous reasoning, physical safety, general intelligence, or a zero-hallucination guarantee. Avoid unsupported prose generation; the predictor can return a bounded class label and the actual model score.
