# Ripple Fusion Implementation Plan

> For agentic workers: use superpowers:executing-plans for inline implementation and a fresh final review. User authorizes continuous completion without redundant approval gates.

Goal: a working trained Ripple-based classifier with reproducible evidence.

Architecture: immutable source kernels plus a new causal bounded network adapter and trained readout. Validate and compare candidates on separate partitions before opening test results.

Tech stack: Python 3, NumPy/SciPy/scikit-learn; Node 20+; offline browser JavaScript.

Spec: docs/DESIGN.md.

## Global constraints

- 32 units; dt=0.1; seeds [11,23,47,89,131]; protocol and source hashes retained.
- Source kernels remain unchanged; newly ported conductance code has numeric parity tests.
- Training-only normalization; complete grouped split; no labels in inference; test is not tuning feedback.
- No external AI providers, cloud purchases, public writes or hardware claims.

Resumed scope amendment (2026-10-15): the user additionally authorizes primary-source research and provider use. This release consulted public primary research and inspected two newer Ripple archives; no paid/model-provider calls were needed. RGB now also compiles an inherited digital blueprint, separately from the existing numeric input channels. Keep the opened benchmark unchanged; do not test-tune new genetic or geometric candidates. See RGB_GENOME.md and NEWER_RESOURCES_AND_RESEARCH.md. Completion includes an independent bounded followup review of this extension.

## Review focus

- Nonfinite inputs must fail before any state mutation.
- New input must not inherit the previous sample's state.
- Temporal twins must stay in one partition and have identical unordered inputs.
- Loading model arrays must reject incompatible shapes and nonfinite coefficients.
- Previously studied digit data must not become an external-validation claim.

## Tasks

1. Network: copy kernels with manifests; write tests for absent network, input rejection, finite features, reset, bounded causal coupling and Charlie Python parity. Implement `FeatureNetwork(config)`, `extractSequence(sequence,config,mode)` and batch CLI. Run Node suite and source parity, then commit.
2. Data/readout: write failing unittest tests for grouped data, split integrity, training-only scaler, actual fitted loss reduction, held-out inference, save/load and invalid model arrays. Implement dataset preparation and ridge training/prediction with declarative serialization. Run both suites, then commit.
3. Benchmark: freeze machine-readable protocol; extract/cached label-free features; fit alpha on training and choose by validation. Freeze choices before final fitting/testing. Export every seed/comparison and learning control with uncertainty; retain logs and errors. Verify and commit.
4. Delivery: produce a standalone live inference HTML, reproducible source ZIP, results/provenance documentation and exact plots. Test browser-compatible engine predictions against Python and inspect visual output. Request fresh whole-project review; fix material issues with tests. Verify ZIP extraction and save final artifacts.

Execution record: docs/PROGRESS.md; deviations must be stated there.
