# Ripple newer-family source audit

Read-only inspection of the seven assigned families, their exact kernel code, training code, tests, documentation and saved JSON results. No archived programs, tests, pickles or joblib models were executed or loaded. Numerical results below are the supplied release evidence, not newly reproduced measurements.

## Decisive selection

Use **original Ripple LIF + Delta Ripple (feedforward OFF) + Daughter Triplet** as a small heterogeneous dynamic bank. Retain v0.6 photoreceptor ON/OFF features as an optional preprocessing/feature ablation. Train a new readout against actual task labels or prediction targets. In these newer archives, only Delta and Daughter introduce distinct neuron equations; Beta/Hybrid/Forest/Master are predominantly wrappers around preserved neurons. The existing neuron kernels have no trained synaptic weights, no inter-neuron recurrence, and no supervised neuron learning.

If the new implementation adds random recurrent coupling, learned input projections or a learned readout, identify those as **new model mechanisms**, separately from the preserved source equations. A fixed dynamic reservoir with a label-fitted readout is genuinely trained; it is not an end-to-end-trained Ripple neuron network. No supplied comparison establishes that the heterogeneous bank will outperform simpler models.

## Exact source roots

All paths below are under `/workspace/scratch/2b46deb4cdb7/combine-source-code/`.

| Alias | Exact relative source root |
|---|---|
| B | `Ripple-Gen-Beta-v2.1-Complete/Ripple-Gen-Beta-v2.1` |
| D | `Ripple-Delta-Neuron-Mathematical-Alpha-v3.0/Ripple-Delta-Neuron-Alpha-v3.0` |
| T | `Ripple-GenBeta-Delta-Daughter-Triplet-v3.1-Complete/Ripple-Daughter-Triplet-v3.1` |
| F | `Ripple-Forest-Language-Alpha-v1.4-Complete/Ripple-Forest-Language-Alpha-v1.4` |
| H | `Ripple-Hybrid-Alpha-v1.1/Ripple-Hybrid-Alpha-v1.1` |
| A | `Ripple_Alpha_v1.3_Research/v1.3` |
| M | `Master_Ripple_Alpha_v2.0_Open_Research_Release/Master_Ripple_Alpha_v2_0` |

## Reusable neuron mechanisms and APIs

### Delta Ripple: select as contrast/adaptation bank

Exact file: `D/src/delta-neuron.mjs`, especially lines 61–87 and 88–157. API: `new DeltaRippleNeuron(options)`, `reset()`, `step([R,G,B], dt)`.

With optional optical preprocessing and static compression `C(x)=log1p(k*x)/log1p(k)` (identity when k=0), the fixed inherited weights are `w=(2,1.2,-1.4)`. `S=sum(w*C(x))`; per-channel contrast is the gated and clipped **sample-to-sample** difference `log(x+eps)-log(previous_x+eps)`; `Delta=sum(w*contrast)`; held drive is `D=S+deltaGain*Delta`.

Between spikes, `tauV*u'=-u+D-a`, `tauA*a'=-a`. The source uses the exact two-exponential solution and a finite bracket grid plus bisection to find threshold crossings. At a spike: u=0, optional a+=adaptJump, refractory rest. The exponentially decaying event rate updates theta through integrated target-rate error. This is homeostatic feedback, not task learning.

Defaults: tauV=.5, tauA=3, tauR=5, tRef=.1; theta=.45 bounded [.15,2.5]; targetHz=1, eta=.08; logFloor=.02, deltaGain=.22, deltaGate=.06, maxLogChange=.9; adaptJump=.02; feedback/deltaEnabled/spikeAdapt true; logK=0, srgb=false, attenuation=null. **Override feedforward=false**, because the source defaults enable an approximate feedforward threshold inverse which failed several saved rate comparisons. Its inverse is exact only for constant positive-drive simple LIF without adaptation or transients.

Contracts: finite RGB exactly length 3 in [0,1], 0<dt<=.2. Keep one dt across training/evaluation: contrast is a per-frame difference, not a derivative divided by dt. Options are allowlisted and bounded; targetHz must be below the refractory-limit rate. Maintain positive refractory for practical reservoir use. Unlike original LIF's voltage floor, Delta allows negative u. Useful readout fields: u, adaptation, theta, rate, count, tonic, delta, drive, contrast; quad is optional telemetry.

### Daughter Triplet: select as a separate filtered-state bank

Exact file: `T/src/triplet-neuron.mjs`, especially lines 30–91 and 93–154. API: `new DaughterTripletNeuron(options)`, `reset()`, `step([R,G,B], dt)`.

Three actual state stages: `tauP*p_k'=C(I_k)-p_k`; `tauD*d'=-d+sum(w*p)+gamma*Delta`; `tauS*u'=-u+d-a`; `tauA*a'=-a`. Same fixed w and samplewise log contrast as Delta. Spike resets soma and increments independent adaptation. Photoreceptor, dendrite and adaptation continue to decay during refractoriness; soma is held at zero. The held-input P/D/S trajectory is coupled analytically, not computed using a frozen endpoint dendrite. Equal-time-constant limits are handled explicitly or by Simpson quadrature.

Defaults: tauP=.06, tauD=.08, tauS=.5, tauA=3, tauR=5, refractory=.1, adaptJump=.008; theta/rate/contrast defaults match Delta; **feedforward=false, feedforwardGain=0**. Input contract is finite RGB [0,1], 0<dt<=.2. Time constants must be >.001 and <=120; refractory [.01,2]; threshold bounds ordered with thetaMax<=8; targetHz>0, <=8 and targetHz*refractory<1. Useful features: filtered p[3], dendrite d, soma u, adaptation a, rate, theta, count, tonic, delta. Negative soma/dendrite states are valid.

`T/src/daughter-world.mjs` replaces each Beta agent's neuron with DaughterTripletNeuron; `addAgent` also gives cloned agents a Daughter. It is an actual kernel substitution, while keeping the inherited hand-authored colony rules.

### v0.6 photoreceptor: optional contrast feature frontend, not another spiking neuron

Exact preserved file: `B/archive/Ripple-Gen-Beta-v2.0/legacy/photoreceptor-v06.js`, lines 19–38. API: `new Photoreceptor(options)`, `reset()`, `step(rgb,dt,overrides)`.

Maintains quantized per-channel log reference: `n=min(limit,floor((abs(log(x+floor)-reference)+1e-10)/threshold))`, assigns n to ON or OFF, and moves reference by sign*n*threshold. Sustained output is static log compression. `output=clip(sustained+transientGain*ON/limit,0,1)`: **OFF is returned separately and is not subtracted from output**. Include OFF explicitly if testing signed contrast features. `linear:true` actually enables sRGB decoding; use linear:false for normalized scanner counts or generic dimensionless inputs. dt must be >0 and <=.5, but log events depend on sample differences rather than elapsed-time normalization. Keep finite vetted options; this older module clamps several options rather than strictly validating them.

### v0.7 QuadEncoder: telemetry/filter only

Exact preserved file: `B/archive/Ripple-Gen-Beta-v2.0/legacy/quaternary-core.mjs`, lines 66–97. A reference-drive Schmitt/debounce classifier with estimated noise floor, four conventional two-bit codes and optional inhibitory rest. No weight learning or neuron membrane. Can be retained as auxiliary one-hot/histogram features, but do not make it the sole state representation: it discards continuous information, and Beta's policy does not use its output in the supplied final mapping comparison.

## What the other families actually add

| Family | Actual implementation | Treatment in the trained model |
|---|---|---|
| Gen Beta v2.0 inside v2.1 | `B/archive/Ripple-Gen-Beta-v2.0/src/beta-engine.mjs`: original LIF, optical frontend, Q codec; bounded synthetic diffusion, memory maps, authored condition/action lists, sharing and cloning | Reuse preserved kernels and provenance only. BetaWorld is an environment/rule controller, not a new neuron or trained planner. |
| Gen Beta v2.1 | `B/src/extract_beta_features.mjs`, `B/src/benchmark_real.py`: real digit data, 80 engineered raster-scan features, StandardScaler + supervised RBF SVC | Reusable **training/evaluation precedent**, not proof of a learned neuron. Source line 18 feeds RAW `[pixel,0,0]` to LIF; line 19 computes photoreceptor separately; line 20 Q-codes raw LIF drive. The photoreceptor output is not fed into LIF in this feature extractor. |
| Forest Language | `F/src/forest.mjs`: generated terrain and wrappers over Daughter/Beta; `F/src/language.mjs`: 4x4 heading sender/listener tables, 2x4/4x2 surface tables | Genuine tiny reward-fitted tabular communication, independent of the neuron. Do not claim natural language or planning from pixels. Training supplies the correct heading/surface; heading and surface slots are imposed by architecture. |
| Hybrid Alpha v1.1 | `H/src/hybrid_lab.mjs`: original LIF gated rule actions, bounded color/gain/route genes; `H/src/experiments.mjs`: MAP archive/quality-diversity search across mutated authored rules | Genome/configuration search, not trained synapses or a new kernel. Exclude rule-list mutation, color classes, novelty bins, cloning and fake metabolism from initial neural model. |
| Alpha v1.3 Research | `A/src/ripple_alpha.py`: parity-tested original LIF Python port + external field simulation; `A/src/hybridlineage.py`: finite crossover/Pareto selection; `A/src/provenancelab.py`: simulated monochrome attribution; `A/src/tracegate.py`: typed recorded-input validation | Reuse validation boundaries or original port if needed. No new neuron type. Field gains/diffusion/occlusion/absorption are configuration values, not task-trained synaptic weights. Monochrome transport is not emergence of a genotype. |
| Master Alpha v2.0 | `M/src/master.py`: preserved optical processing, typed per-unit sensor events, occupancy mapper, bounded task queue; `AdaptiveSensoryWeights.step` lines 162–173 is EWMA of timestamp-quality scores | Useful schema/provenance concepts. Its sensory weights and fixed salience thresholds are scheduling heuristics. `propose_weight_child` merely selects a finite candidate based on channel variance and does not fit/predict task targets. Exclude scheduler as a neuron. |

Forest's actual update is `Q += .16*(reward-Q)` using separate +/-1 heading and surface correctness rewards. This does train associations, but `language.mjs` never invokes the Daughter or Delta neuron. Its oracle scout uses shortestRoute on generated ground truth; the supplemental local scout still receives goal coordinates and exact immediate passability.

## Evidence and negative findings

| Supplied evidence | Finding | Scope |
|---|---|---|
| `B/data/results.json`, `B/RESEARCH_REPORT.md` | 360 real recorded digit holdout: raw RBF SVC 354/360 (98.33%); Ripple-only 327/360 (90.83%); raw+Ripple 354/360; raw 3-NN 355/360. Raw/combined swap 3 errors each; paired McNemar p=1. | Task-specific trained classification; no clean-data benefit established from Ripple channels. No writer-disjoint split. |
| Same Beta report | GPT visual 19/30 vs Ripple-only 27/30 and raw/combined 30/30 | Untrained one-batch visual answers versus label-trained models. Thirty are a subset of the 360, not independent evidence or a fair general intelligence comparison. |
| Same Beta results | Digital attenuation at synthetic path 4: clean raw classifier 81/360 vs augmented raw classifier 354/360; clean augmentation regressed by one | Benefit comes from supervised augmentation of conventional raw classifier against an imposed mathematical transform, not physical optics or the neuron. |
| `D/results/benchmark-summary.json`, `D/src/benchmark.mjs` | Original steady rate error 0 vs Delta default .1 Hz; FF-off steady 0. Delta default step .06667 vs original .01667. FF-off is not universal: noise .01833 vs original 0. | 600 synthetic target-tracking trials; only noise varies across the 20 seeds. Rate error is not prediction/classification competence. |
| `T/results/benchmarks.json`, `T/results/paired-audit.json` | Later 240 synthetic trials: original mean rate error .05875; Delta default .09833; Delta FF-off .04292; Daughter .05083. Original-minus-Daughter improvement .00792, 15 better/18 tied/7 worse; exploratory interval touches zero. | Daughter weaker than original on channel/noise cases. Contrast ablation almost unchanged. No universal win or causal contrast advantage. |
| Same Daughter paired audit | Daughter-minus-Beta map coverage +2.34375 cells, 15 wins/2 ties/15 losses; exploratory interval [-2.1875,+6.75] | No convincing map advantage; all generated worlds, authored policies. |
| `F/results/study.json`, `F/results/local-scout.json` | Oracle learned code 2100/2100; random legal no-message 120/2100; scrambled 0. Separate local scout 410/420. Daughter mean forest coverage 132.33 vs Beta 133.00. | Restricted learned symbols conveying a supplied direction. Shared maps/learners and explicit factor prior; no natural language/neural planning gain. |
| `H/data/factorial_summary.json` | Across full synthetic factorial, mean photo-on coverage .0304306 vs off .0456569; Q-on .0370555 vs off .0390320; density-on .0379472 vs off .0381403 | Features can hurt; wrapper rules/source environment determine these outcomes. |
| `H/data/genetic_logic_study.json` | 21/24 selected representative genomes have lower reserved-seed than training coverage; 3 improve. Clone-only test gives 9 workers and zero seen cells. | Quality-diversity/config search is not evidence of reliable useful learned intelligence. |
| `A/results/hybridlineage.json` | 18 proposed hybrids, 5 selected; all 5 have holdout_dominates_both_parents=false | External field tradeoffs; no new neuron/synaptic learning or universal improvement. |
| `M/results/gene_comparison.json` | Synthetic event-count differences across inherited fixed profiles; source explicitly says not improved intelligence or accuracy | No labels/targets/loss/heldout prediction benchmark. |

The saved solver tests compare Delta's held-drive solution and Daughter's coupled solution with independently coded RK4, test equal-tau limits and bounded events, and include a 40,000-step Daughter stress run. These support numerical implementation correctness under declared cases, not usefulness or biological identity. Both first-crossing searches use finite time grids and can miss a sufficiently brief within-bin excursion; do not claim exact universal event detection.

## Concrete integration constraints

1. Preserve kernel files and lineage; create new adapter/model code separately. Delta/Triplet input is exactly three bounded channels. If recurrent state or raw input is signed/unbounded, provide an explicit finite bounded projection into [0,1]^3; it is a new engineering representation, not a physical RGB/spectral calibration.
2. Use a fixed dt (e.g. the inherited .05) and reset **all** membrane, threshold, adaptation, rate, contrast references, photoreceptor and Q state at independent sequence/sample boundaries. Prevent training/test state carryover. Preserve state only for a deliberately continuous temporal task.
3. Train-only feature normalization is needed: event counts, rate Hz, signed u/d, p, adaptation and threshold have different units/scales. Preserve continuous state; do not rely only on spikes/Q labels. Long-term homeostatic rate can erase amplitude differences, so include transient/subthreshold states and evaluate the effect of feedback rather than assuming it helps classification.
4. Keep initial banks small. Delta uses 32 bracket evaluations and 48 bisection iterations per crossing; Triplet uses 48 and 45. Near-degenerate Triplet tau combinations add a 160-point Simpson branch. Different, well-separated time constants avoid this unnecessary branch. Report any faster discretized implementation as a **new approximation** and verify it against the source on reviewed sequences.
5. Fit task readout parameters and save the fitted state plus train/validation/test indices, normalization, random projections/coupling, kernel options, seed and source hashes. Existing adaptive theta/EWMA/genome mutation are not substitutes for fitting against task evidence.
6. Required useful comparison: raw inputs with the same learned readout, original-LIF-only, Delta-only/Triplet-only, combined dynamics, and a conventional trained reference. Select configurations on validation only. Use heldout labels once; include shuffled-label/no-learning controls if intelligence claims depend on learned performance. Source-derived heterogeneity is a hypothesis to test, not a pre-established benefit.
