# Ripple Fusion v1: trainable heterogeneous reservoir

Authorized goal: turn selected executable Ripple spin-offs into a reproducible supervised model. Success requires actual fitted parameters, new-run held-out predictions, learning controls and honest comparisons. The original archives and their equations stay unchanged.

The audit found 98 filename-matched Ripple files and examined 25 representative archives, including original LIF, Charlie conductance, Delta, Daughter, photoreceptor, quaternary, Mycelium, Beta, Forest, Hybrid, Master and integration releases. This is not a claim that every Library file or undocumented version was reviewed.

## Architecture

32 units, each using original LIF, Charlie conductance, Delta (feedforward off), or Daughter dynamics. JS LIF/Delta/Daughter source is copied byte-for-byte; a separate Charlie JavaScript port must match the original Python step numerically. New bounded input projections encode eight digital channels into three abstract [0,1] channels. They are not calibrated light or a wavelength measurement. New one-step-delayed sparse coupling connects membrane states; intrinsic equations stay unchanged.

All networks reset completely between independent sequences. Fixed timestep 0.1 model second. Neuron/synaptic/source weights are frozen. Supervised ridge readouts learn classification weights from labelled training examples; training-only z-score normalization and regularization address differently scaled states and correlated features. This is reservoir learning, not backpropagation through spike events, self-generated thinking or an LLM.

Each neuron supplies four declared features: LIF [u,rate,theta,count]; Delta [u,adaptation,rate,theta]; Daughter [u,dendrite,adaptation,rate]; Charlie [membrane,exc-inh,adaptation,rate]. Tanh control has 32 continuous units and four algebraic powers per state. Digit readout uses the complete eight-step state trajectory; the temporal readout uses only final neural state. No raw-input bypass in Ripple readouts.

## Protocol frozen before new fitting

Digits: scikit-learn's 1,797 recorded 8x8 images, ten classes, normalized by the documented maximum 16, streamed one row per step. Split seed 20261014, 60% training / 20% validation / 20% test, stratified. This dataset has already appeared in Gen Beta v2.1; new-run partitions are not new writers or an independent external dataset.

Temporal order: 300 independent synthetic templates, six permutations of three colored code pulses per template, 24 frames, eight channels. Each complete six-member group has the identical frame multiset and final frame. Partition templates 160/60/80 into train/validation/test. Last-frame and bag means cannot distinguish order. Pulse positions, amplitudes and background noise vary. Model receives only frames, never the label or template metadata. Ground truth is simulator-authored and used only by fitting/evaluation.

Seeds: [11,23,47,89,131]. Candidates: lif, delta, daughter, charlie, mix3, mix4, mix4_no_links, tanh. Each has 32 units and identical seed-derived input projections. Mix3 cycles LIF/Delta/Daughter; mix4 cycles all four. Sparse feedback max absolute row sum is 0.12; RGB clipping gives bounded inputs, not a global stability proof. Ridge alpha grid [0.01,1,100]. Choose alpha and architecture by validation only; retain all seeds. Select deployment seed 11 in advance, never the best test seed.

Baselines: untrained/zero readout; training-label shuffle evaluated against true test labels; learned raw final-frame and bag-mean ridge; learned ordered raw ridge; strong ordered raw RBF SVM (C grid [1,10], selected on validation). No k-NN is described as untrained. New causal-coupling ablation is a candidate, not assumed helpful. Source archive failures remain in the source audit.

After validation selection, freeze all selected configurations and refit on training+validation. Evaluate all prespecified comparisons once on test; no test-driven tuning. Bootstrap temporal template groups, and report digit sample-level uncertainty without pretending seed repetitions create new independent images. Record actual parameter counts, extraction+prediction time, dataset/split/source hashes, errors and failures.

## Product

Offline HTML runs the saved trained models on examples and editable digits/commands with ordinary code. Full source, trained JSON weights, raw evaluation records, provenance, protocol, tests and runnable benchmark ship in a ZIP. No remote model API, key, paid service, robot control, actual optical apparatus or public posting.

Resumed extension: five typed RGB byte triples encode the network blueprint independently of input color. Decode/compile reconstructs the existing network configuration exactly; bounded mutations and crossover produce untrained child configurations. A changed blueprint cannot inherit a fitted readout silently. This codec and its model-binding CLI are separate from the frozen experiment engine. No evolutionary accuracy improvement, chemical behavior or automatic self-replication is part of the success claim. Full byte map and verification gates: RGB_GENOME.md.

## Verification and failure gates

Source copies must retain hashes. Charlie parity tolerances: 1e-10 states, matching event counts and event times within 1e-10 on reviewed legal sequences. Reject nonfinite/out-of-range data, invalid configuration and wrong input shapes before mutating state. Repeated extraction after reset must be identical. Feature normalization must use only fitting rows. Training/test IDs and whole temporal template groups must be disjoint. Saved readout prediction must reproduce fitted prediction. Browser-compatible saved model must agree with Python inference.

The desired competence is >=90% validation accuracy on each task, with materially better new-run test accuracy than zero/shuffled controls. Passing this goal is not a guarantee of beating the strong ordinary baseline. If no candidate meets the validation goal, record the result and revise using training/validation only before opening the test. Claims of improvement require a supported held-out comparison; all other results remain negative or inconclusive.
