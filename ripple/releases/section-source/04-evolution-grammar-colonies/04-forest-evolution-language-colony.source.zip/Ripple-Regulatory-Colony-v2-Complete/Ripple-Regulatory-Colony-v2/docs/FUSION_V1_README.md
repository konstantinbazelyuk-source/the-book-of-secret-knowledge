# Ripple Fusion v1

A real fitted **supervised pattern classifier**, combining executable Ripple neuron dynamics with learned readout weights. It is an experimental software model, with task-specific competence and recorded failures. No external model API, key or paid service is required.

## Start now

Open **web/Ripple-Fusion-AI.html** in a modern browser. The standalone file contains the actual kernels and trained weights. Choose a model, try held-out digit examples, draw an 8x8 digit, or classify R/G/B code order. Predictions are computed, not replayed answers. Scores are not calibrated probabilities. Custom drawings can be misclassified.

For terminal inference with Node 20 or later:

```sh
node web/infer_cli.mjs models/digits-mix4.json data/digits-demo-examples.json
node web/infer_cli.mjs models/temporal-mix4.json data/temporal-demo-examples.json
```

To predict a new sequence, replace the example file with a JSON array: 8 frames × 8 values for digits, or 24 × 8 for temporal order. Each value must be finite in [0,1]. These are digital features, not calibrated radiance.

## What this model actually contains

- 32 dynamic units. Four-type model: 8 original LIF, 8 Delta, 8 Daughter and 8 Charlie conductance units.
- New bounded, one-step-delayed membrane coupling. Its benefit is not established by the present link ablation.
- Frozen source dynamics/input/recurrent weights; supervised readout coefficients and scaling learned from training examples.
- Two task readouts: recorded handwritten digits and synthetic temporal color order. The task is explicitly selected; there is no learned general-purpose task router.
- 80 neural architecture/seed comparisons (240 ridge-penalty fits), eight baseline selections, 88 new-run test comparisons and learning controls.
- Executable RGB configuration genome: five digital color codons compile into the network blueprint; fitted readout weights are stored separately. Mutations/crossover are bounded and a changed blueprint rejects an incompatible readout.

Four-type test means across five fixed seeds: **95.83% digits**, **99.92% synthetic order**. Strong raw-input SVM: **98.61% digits**, **100% order**. Daughter-only matched mixed mean order accuracy. The standalone deployment uses seed 11 fixed in advance: its mixed models got **344/360 digits** and **480/480 order**. Five repeated seeds are not five independent datasets.

See **docs/RESULTS_AND_LIMITS.md** for all comparisons, bootstrap intervals, rejected claims, evidence classes, prior-data exposure and exact scope. The recorded digits appeared in an earlier Ripple study, so this is not external or writer-disjoint validation.

## Reproduce fitting and evaluation

Python 3.12 was used, with versions in requirements.txt. NumPy/SciPy/scikit-learn are needed for fitting; Node is needed for exact source-kernel feature extraction. In a suitable local Python environment:

```sh
python -m pip install -r requirements.txt
python -m src.benchmark select
python -m src.benchmark evaluate
python tools/correct_evidence.py
python tools/report.py
python tools/build_app.py
```

`select` writes validation records and freezes choices before `evaluate` runs. Kernels/configuration are checked against the freeze. Feature extraction caches only input-derived arrays. The default protocol uses all five prespecified seeds. Do not change choices after seeing test results and still call the test untouched.

The benchmark defaults to `--engine frozen`, the exact archived engine used in the experiment. The deployed engine adds dense-array validation without changing valid-input arithmetic. Both engines are included; `python tools/verify_models.py` compares every feature and every prediction for all five shipped models on their full test partitions. This verification does not refit or select a model. Raw original evidence is retained; `results/evidence-corrected.json` replaces naive temporal row intervals with template-group bootstrap intervals. Paired intervals are exploratory and have no multiple-comparison correction.

The validation budget was **80 neural architecture/seed comparisons × 3 ridge penalties = 240 ridge fits**, plus 18 raw-ridge fits and four SVM fits for eight baseline selections. Final fits and controls are additional.

## RGB as a digital genome

This is separate from input color sensing. Five RGB triples encode a version, neuron-bank design, unit count, input dimension, timestep, coupling, projection seed, feature mode and sequence length. They reconstruct executable settings, not learned knowledge by themselves. The network's learned knowledge remains in its trained readout. See `docs/RGB_GENOME.md` for the complete byte map, inheritance/mutation API and limits.

```sh
node genome/cli.mjs inspect genomes/temporal-mix4.rgb.json
node genome/cli.mjs run genomes/temporal-mix4.ripple.json data/temporal-demo-examples.json
```

The `.ripple.json` package binds a matching genome and actual trained readout with a SHA-256 integrity check. It is not an authorship signature. The offline page can display/export a parent blueprint and create an untrained child seed. No genetic accuracy improvement, biological acid/base chemistry, autonomous self-replication or new physical effect is claimed. Newer v1.7/v2.4 resources were inspected and relevant preserved parent hashes checked; see `docs/NEWER_RESOURCES_AND_RESEARCH.md`.

## Verify

```sh
python -m unittest discover -s tests -p "test_*.py" -v
node --test tests/*.test.mjs
python tools/verify_models.py
```

Tests cover source-port parity, reset, finite states, input validation, causality bounds, grouped data splits, genuine readout learning, training-only scaling, JSON roundtrip, malformed models, noncontiguous class labels and standalone/model inference agreement. Browser-compatible arithmetic was exercised in Node; a graphical browser was unavailable, so visual browser UI execution is not claimed.

## Files

- `models/`: fitted portable JSON readouts, network settings and provenance.
- `genome/`, `genomes/`: executable RGB compiler, inheritance/mutation API, CLI and five matching trained genome packages.
- `src/`: actual network, Charlie port, datasets, fitting and two-phase benchmark.
- `vendor/`: immutable original kernels and original Python Charlie reference.
- `data/`: fitting/evaluation inputs, splits, attribution and held-out demo examples.
- `results/`: raw metrics, predictions including errors, validation freeze and exact plots.
- `docs/`: design, independent audits, execution ledger, source hashes and full evidence report.
- `repro/`: exact pre-validation-patch feature engine and original temporal model metadata for experiment provenance. Use the patched `src/` engine for new public-facing input.

## Reuse

Original integration code/reports/synthetic data: **CC0-1.0**, consistent with the open Ripple project. Original kernel notices are retained. Recorded digits: E. Alpaydin & C. Kaynak (1998), UCI Optical Recognition of Handwritten Digits, https://doi.org/10.24432/C50P49, **CC BY 4.0**. This package stores a normalized and reshaped copy of scikit-learn's 1,797-image subset. Retain the credit when sharing the data and trained model material. External Python libraries keep their own licenses.

Original Ripple concept: **Constantin x**. This package has not been posted to a public service.
