# RGB configuration genome v1

Requested by Constantin x: color values should also act as a digital inherited code, independently of light sensing. This release implements that interpretation. A genome is a finite digital blueprint compiled by `genome/codec.mjs`; three unsigned bytes form a 24-bit codon. This is a software representation with defined semantics. Colors are a visible rendering of stored bytes, not chemical acids, bases or biological nucleotides.

## Exact executable mapping

Five codons contain 15 bytes (120 stored bits, including headers and constrained/redundant fields). This does not mean 120 independent useful parameters or 120 bits of learned knowledge.

| Codon | R byte | G byte | B byte |
|---|---|---|---|
| 0 | 82, letter R | 71, letter G | 66, letter B |
| 1 | Schema version = 1 | Architecture index | Unit count, 4..64 |
| 2 | Input dimension, 1..32 | Timestep ticks minus 1 | Coupling ticks |
| 3 | Seed bits 31..24 | Seed bits 23..16 | Seed bits 15..8 |
| 4 | Seed bits 7..0 | Feature mode: 0 final, 1 trajectory | Frames minus 1 |

Architecture indices: 0 original LIF, 1 Delta, 2 Daughter, 3 Charlie, 4 three-type mixture, 5 four-type mixture, 6 four types with links forced off, 7 tanh control. Index 7 is a conventional comparison, not another Ripple invention. Mixture membership follows the frozen network's repeated ordering; this schema does not specify an arbitrary type for each individual unit.

Timestep = (G2 + 1)/1280 model seconds, within (0,0.2]. Coupling = B2/1275, within [0,0.2]. Encoding rejects off-grid values rather than silently rounding. Final-state readouts expose 4×units features; trajectory readouts expose 4×units×frames. Compilation rejects more than 8,192 readout features. Seed 0 and seed 1 intentionally share the inherited generator's fallback stream; the codec does not assert a one-to-one map from genomes to dynamics.

For the four-type, seed-11 temporal model, the codons are `[82,71,66]`, `[1,5,32]`, `[8,127,153]`, `[0,0,0]`, `[11,0,23]`. They compile to 32 units, eight inputs, dt=0.1, coupling=0.12, seed 11, final-state features, 24 frames.

## Genotype, execution and learning

`encodeGenome(artifact)` derives the blueprint from a saved fitted model. `decodeGenome(genome)` validates the bytes and reconstructs exact network settings. `predictGenome(genome, artifact, input)` constructs that network and runs its actual learned readout. It refuses a changed blueprint paired with the parent's weights. Equal feature dimensions alone are not permission to reuse a readout.

`mutateGenome(parent, changes)` returns a new valid genome without changing its parent. Changes can target the eight typed fields in the table. `crossGenomes(parentA, parentB, fieldsFromB)` inherits whole selected settings, then compiles/validates the result. These are bounded software inheritance operators, not a claim that biological evolution is reproduced. They do not launch processes, copy themselves or invent source code.

The numeric three-channel neuron stimulus remains a separate input representation. A displayed RGB codon is not passed to the neuron as an observed color. The code roles can therefore be used with grayscale images or other normalized digital signals as well as with color signals.

The previously frozen validation experiment searched eight bank designs, five seeds and three ridge penalties. The supplied genomes record actual tested configurations. No new genetic search was tuned on the already observed test partitions. Mutation changes were checked for their effect on network features; their task accuracy has not been evaluated. A child needs a newly fitted readout and a new fair evaluation protocol before an improvement claim.

## Files and commands

`genomes/*.rgb.json` holds blueprints. `genomes/*.ripple.json` holds a genome plus matching trained JSON readout and a SHA-256 content check. SHA-256 detects content modification; it does not prove authorship, correctness or safety. No executable code is loaded from the model JSON.

```sh
node genome/cli.mjs inspect genomes/temporal-mix4.rgb.json
node genome/cli.mjs run genomes/temporal-mix4.ripple.json data/temporal-demo-examples.json
node genome/cli.mjs encode models/digits-mix4.json digits.rgb.json
node genome/cli.mjs pack models/digits-mix4.json digits.ripple.json
```

To create an untrained child, save `{"seed":23,"architecture":"daughter"}` as `changes.json`, then run:

```sh
node genome/cli.mjs mutate genomes/temporal-mix4.rgb.json child.rgb.json changes.json
node genome/cli.mjs inspect child.rgb.json
```

The prototype does not supply an automatically trained model for this child. A fitting program can use the decoded configuration with `src.bridge.extract_features` and `src.readout.fit_readout`; labels belong only in the fitting stage. Use independent validation to select changes and reserve new evaluation data. Existing test scores cannot become a new development objective while retaining an untouched-test claim.

## Evidence and limits

Tests exercise exact encode/decode, valid byte/grid bounds, inheritance without parent mutation, actual feature changes, mismatched-readout rejection and packed-weight tamper rejection. `tools/verify_models.py` additionally checks the full test partitions of every supplied fitted model against the original engine and Python readout, then emits `results/release-verification.json`.

This establishes executable configuration inheritance and real fitted classification. It does not establish a new biological substrate, general reasoning, an accuracy benefit from color notation itself, a globally best genome, language generation, physical sensing or robot behavior.
