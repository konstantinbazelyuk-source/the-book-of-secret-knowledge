# Independent whole-project review: Ripple Fusion

Reviewed the complete new repository from the empty tree to `beb574ed6945cf723e5698451cfb3e15cc401dfe`, not merely the final commit. Read design, plan, progress ledger, source audit, evaluation audit, results/limits, all new inference/training/reporting code, source kernels and tests. The structured evidence takes precedence over the unfinished progress ledger. No production files were modified, full benchmark rerun, or archived pickle executed.

## Findings

### Important: sparse JavaScript input arrays evade validation and can mutate state to NaN

Locations: `src/network.mjs:41`, `src/charlie.mjs:13`, related validation in `web/predict.mjs:3-7`.

`Array.some`/`every` skip missing indices. `new CharlieNeuron().step([.2,,.3], .1)` is accepted and corrupts conductance to NaN. A tanh `FeatureNetwork` given an eight-element frame with an index deleted throws `nonfinite neuron state` only after changing its cell's `h` to NaN. Thus invalid input does not always fail before mutation. Dense JSON benchmark inputs are unaffected. The saved-readout validator likewise accepts holes in numeric arrays, although prediction subsequently fails.

Use indexed or dense-copy validation that checks every required element before stepping; reject holes in model arrays as well. Regression verification should compare complete cell state, because `snapshot()` currently exposes only features, feedback and steps and would miss cell-only corruption. Preserve the original evidence/source digest and explicitly identify any legal-input-equivalent validation amendment.

### Important: documented reproduction environment omits the report dependency

Locations: `requirements.txt`, `tools/report.py:5`, `README.md:34-39`.

The promised command sequence installs requirements then invokes `tools/report.py`, which imports matplotlib. Requirements include only NumPy, SciPy and scikit-learn; none requires matplotlib. A clean installation cannot complete the documented workflow. Add a compatible pinned matplotlib dependency or a clearly documented report dependency file and install step. Verify imports/build in an environment whose dependencies derive from those manifests; no model retraining is needed. This workspace currently has matplotlib 3.10.8.

### Important: temporal per-model Wilson intervals ignore template dependence

Locations: `src/benchmark.py:101-106,127,144`, temporal rows in `results/evidence.json` and temporal model `new_run_test` metadata.

`metric` attaches a binomial `wilson95` using 480 rows for temporal test accuracy, although those rows comprise 80 independent six-member templates. This conflicts with the documented group-aware uncertainty rule and can overstate precision. The separately reported paired comparisons correctly bootstrap template groups, so the main paired differences are not affected. Remove the temporal Wilson intervals, clearly label them as naive row-level diagnostics that ignore dependence, or derive group-bootstrap accuracy intervals from saved predictions. No full benchmark rerun is necessary.

### Minor: distinguish exploratory pairwise intervals from confirmatory findings

Locations: `protocol.json`, `src/benchmark.py` comparison loop, `tools/report.py` and `docs/RESULTS_AND_LIMITS.md` improvement section.

Many candidate/baseline pairwise intervals are emitted without a frozen primary contrast or multiplicity adjustment. The report should call them exploratory, unadjusted intervals, rather than letting “improvements that survived” imply controlled confirmatory inference. No headline accuracy is incorrect.

### Minor: validation fitting budget wording

Location: `README.md:24`.

“80 neural validation fits” is 80 architecture/seed/task selection runs, each fitting three ridge alphas: 240 neural fits. Use “80 selections across 240 ridge fits,” or “80 validation runs.” The full structured trial records already disclose all three alphas.

## Verified strengths and checks

- `npm test`: all 12 tests pass. `python3 -m unittest discover -s tests -p 'test_*.py'`: all 11 pass.
- All five vendor hashes match `docs/source-kernels.json`. Current source/protocol/validation-record digests match the frozen selection record.
- Regenerated data arrays, labels, groups, split indices and input hashes exactly match both packaged datasets. Temporal templates have identical unordered frame multisets and final frames, and whole templates remain in one partition.
- All 88 saved test result rows match their saved predictions, actual dataset truth and test indices.
- Actual saved models were checked across 15 inference cases: JavaScript and Python labels agree; maximum absolute score difference is approximately 1.44e-15.
- Ridge fitting correctly uses fitting-only scaling, a centered affine target and positive ridge regularization. Validation selects alpha/architecture; final train+validation refitting follows the saved choices. No label or template metadata enters inference. Independent public prediction and batch paths reset all states.
- Charlie's JS step follows the original Python step order and equations; the existing 140-frame/29-event golden trace test passes. Its port intentionally does not claim to reproduce unrelated Python training methods.
- Claims consistently identify fixed dynamics plus trained readout, already studied digits, synthetic temporal data, uncalibrated scores, no coupling benefit established, and stronger ordinary baseline performance. No AGI, physical sensing or robot competence claim found.
- UI is bundled and its actual inference executes in Node; documentation honestly states that graphical browser interaction was not tested. Digital genome additions were not present in this reviewed commit and require a bounded followup.
- Reuse terms retain kernel notices and recorded dataset credit. No third-party binary dependency or archived learned pickle was executed.

No Critical issue found. Resolve the Important findings before declaring the package fully verified and reproducible.
