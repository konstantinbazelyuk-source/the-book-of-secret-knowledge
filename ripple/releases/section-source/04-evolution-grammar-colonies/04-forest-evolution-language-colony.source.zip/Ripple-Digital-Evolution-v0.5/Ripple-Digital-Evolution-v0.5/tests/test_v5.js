'use strict';
const test=require('node:test'),assert=require('node:assert/strict');const fs=require('node:fs'),crypto=require('node:crypto');
const {BASE,encode,decode,mutate,seeded,Ledger}=require('../src/genome');const {makeWorld,observation,objMesh,arrivals}=require('../src/world');const {Colony}=require('../src/colony');
const source=fs.readFileSync(require.resolve('../src/ripple_core_reference'),'utf8'),baseline=fs.readFileSync(require.resolve('../baseline/ripple_core_reference'),'utf8');
test('original Ripple core byte-identical',()=>assert.equal(source,baseline));
test('original kernel SHA256 anchored to v0.4',()=>assert.equal(crypto.createHash('sha256').update(source).digest('hex'),'d75d4208e92f19623b127615bd52b4002e85d2c0a59b76471764b55a24294210'));
test('genome marker round trip',()=>assert.deepEqual(decode(encode({...BASE})),BASE));
test('genome marker rejects tampering',()=>{let m=encode({...BASE});m.genes.maxWorkers=7;assert.throws(()=>decode(m),/marker mismatch/);});
test('genome rejects unknown genes',()=>assert.throws(()=>encode({...BASE,stealAll:true}),/unknown/));
test('genome rejects nonfinite/infeasible fields',()=>assert.throws(()=>encode({...BASE,hopPreference:NaN}),/numeric/));
test('seeded mutation deterministic',()=>{let a=seeded(3),b=seeded(3);assert.deepEqual(Array.from({length:5},()=>mutate(BASE,a)),Array.from({length:5},()=>mutate(BASE,b)));});
test('lineage marker changes with parent',()=>assert.notEqual(encode(BASE).marker,encode(BASE,'parent').marker));
test('ledger verifies and detects edits',()=>{let l=new Ledger();l.append('start',{a:1});l.append('end',{b:2});assert.equal(l.verify(),true);l.items[0].payload.a=3;assert.equal(l.verify(),false);});
test('world 2d and 3d sizes',()=>{assert.equal(makeWorld(2,1).cells.length,100);assert.equal(makeWorld(3,1).cells.length,147);});
test('world deterministic hashes',()=>assert.equal(makeWorld(3,8).worldHash,makeWorld(3,8).worldHash));
test('world different seeds differ',()=>assert.notEqual(makeWorld(2,4).worldHash,makeWorld(2,5).worldHash));
test('synthetic optical saturation flags',()=>{let a=observation(makeWorld(2).cells[0],1,0),b=observation(makeWorld(2).cells[0],1,1);assert.equal(a.clipped,true);assert.equal(b.clipped,false);});
test('OBJ includes vertices and faces for occupied cells',()=>{let txt=objMesh(makeWorld(3));assert.match(txt,/^v /m);assert.match(txt,/^f /m);});
test('task arrivals bounded and unique',()=>{let a=arrivals(makeWorld(3),'shift');assert.equal(new Set(a.map(x=>x.id)).size,a.length);});
test('unsupported task mode rejected',()=>assert.throws(()=>new Colony(BASE,{service:'claims_AI'}),/bad experiment/));
test('original first pulse count finite',()=>{const {RippleNeuron}=require('../src/ripple_core_reference');let n=new RippleNeuron();for(let i=0;i<20;i++){let r=n.step([.35,0,0],.1);assert(Number.isFinite(r.theta));}});
for(const dim of [2,3])for(const profile of ['burst','shift','stream']){
 test(`colony integrity dim${dim}/${profile}`,()=>{let c=new Colony(BASE,{dim,profile,seed:5});let r=c.run();assert.equal(r.mapped,r.cells);assert(c.verify());assert(r.created<=BASE.maxWorkers+50);});
}
test('single worker never exceeds one worker',()=>{let c=new Colony({...BASE,growth:'single'},{dim:2});let r=c.run();assert.equal(r.created,1);assert.equal(r.remaining,1);});
test('fixed4 always runs four workers',()=>{let c=new Colony({...BASE,growth:'fixed4'},{dim:2});let r=c.run();assert.equal(r.created,4);assert.equal(r.remaining,4);});
test('scaling cap enforced',()=>{let c=new Colony({...BASE,maxWorkers:2,spawnThreshold:1,growth:'reactive'},{dim:3});let r=c.run();assert(r.created>=1);assert(c.nodes.length<=2);});
test('same run produces same mapped output checksum',()=>{let a=new Colony(BASE,{dim:3,seed:4,profile:'shift'}).run();let b=new Colony(BASE,{dim:3,seed:4,profile:'shift'}).run();assert.equal(a.hashOfOutput,b.hashOfOutput);assert.equal(a.ledgerHead,b.ledgerHead);});
test('reverse specialization assumption does not leak data',()=>{let a=new Colony({...BASE,role:'mixed'},{dim:2,service:'reverse'}).run();assert.equal(a.mapped,a.cells);});
test('short deadline yields incomplete coverage but no dropped tasks',()=>{let c=new Colony({...BASE,growth:'single'},{dim:3,horizon:10});let r=c.run();assert(r.coverage<1);assert(c.verify());});

test('genetic mutation cannot change physical network delay',()=>{let g={...BASE},rng=seeded(15);for(let i=0;i<70;i++){g=mutate(g,rng);let colony=new Colony(g,{dim:2});assert.equal(colony.config.hopDelay,.2);}});
