# Results NOT to advertise as breakthroughs

1. The genetic optimizer initially cheated by reducing environmental hop delay. This was fixed and the entire 4,320-case sweep and genetic search were rerun. No genotype can alter the fixed link delay now.
2. Task role labels by themselves are not intelligence. With equal service cost, role specialization makes no computational improvement; under a hypothetical reversed skill advantage, mixed specialists may lose to generalists.
3. Fixed four-worker baseline is often faster but consumes a steady four-worker reserve throughout the simulation. Single neuron can finish but may impose long waits. The selected fitness weighs economy more than latency; different objectives lead to different winners.
4. Mapping occupancy comes from the synthetic world's own oracle, not reconstructed from synthetic optical color bands. This is NOT 3D SLAM, computer vision, real spectral metrology, or robotic terrain scanning.
5. SHA-256 markers and a hash-linked local log catch accidental/tamper changes *under a trusted stored checkpoint*; a determined party could rewrite the whole log. No digital signatures, secret-key MAC, consensus, exchange token or cryptocurrency were built.
6. No physical sensor, Minecraft, Roblox Studio, Luanti runtime, Godot or Google application was accessed or benchmarked. Format adapters and a Luanti test-world mod are only code reviewed and syntax inspected, not engine tested.
7. The simulated LIF event budget incurs program overhead. Median host timing in one 25-trial local Node microbenchmark was ~1.88ms for direct domain tasks and ~8.99ms for serial Ripple-gated simulation. These programs do different amounts of scheduling; the comparison illustrates overhead only, not meaningful parallel throughput.
8. This model does not learn to reason, edit its own base algorithm, independently learn new facts, or gain access to tools. The digital 'genome' searches parameters in a predeclared finite space.
9. The search includes deliberately short schedule windows, but 160s horizon is still chosen by the designer. Different maps, longer times, actual message delays and complex content could materially change the ranking.
