# Ripple product decision — v0.5

## Selected product: self-contained digital voxel mapping and experimental-genetics laboratory

**Why**: the source code and performance evidence can be reproduced locally with no game account, paid cloud, online API, game license, token purchase or deployment approval. It tests an actual artifact: voxel-coordinate sampling and recomposition, worker scheduling, genotype mutation/selection, and integrity of a hash-linked audit log.

### Platform review

| Platform | Available public interface | What the package actually contains | Verified in engine? | Selected for initial execution? |
|---|---|---|---|---|
| Offline JS + browser Canvas | Node `worker_threads` and browser Canvas (standard technologies) | 2D and 3D synthetic scene generator, core Ripple event-gating, offline replay | Yes, Node and Chromium via inline-loaded HTML | **Yes** |
| Luanti (previously Minetest) | Server-side Lua mods (`core.register_chatcommand`, `core.set_node`) | Complete example mod with explicit `/ripple_import_demo`, operator privilege, synthetic voxel list | No Luanti binary was available | Next engine for manual testing |
| Minecraft Bedrock | Script API `@minecraft/server`, world dimensions and blocks | An opt-in TypeScript example function only | No Minecraft runtime installed | Later, versioned behavior pack required |
| Roblox Studio | Luau scripts and optional `HttpService` integration | An opt-in Luau example function only, no HTTP requests | No Roblox Studio available | Later, separate permissions and Studio testing |
| Godot | Official headless CLI for engine tests | Standard OBJ export only | No Godot engine installed | Optional later |
| Google/Cloud | APIs/credits/accounts depend on product and permissions | None: local experiment avoids cloud costs | Not connected to Ripple | Not justified yet |
| Bitcoin network | SHA-256, proof of work, peer-to-peer consensus | Only a deterministic SHA-256 hash-linked local experiment log | Node hash implementation tested, no network | **No cryptocurrency created** |

## Why cryptocurrency was not selected

Satoshi Nakamoto's 2008 design combined transaction signatures, a time-ordered hash chain, proof of work and a peer-to-peer majority-consensus rule. Ripple does not need distributed money issuance or energy-expensive consensus for local colony research. We reuse only hash-linked record integrity. SHA-256 collision resistance is a property of a hash algorithm, **not** proof that the source observations are true or that a writer is authorized. To authenticate external writers or prevent a fully malicious log rewrite, add a genuinely independent signed checkpoint or a keyed MAC with protected key management. **Neither is present here.**

## Sources checked

- Luanti engine/modding: https://api.luanti.org/ ; https://docs.luanti.org/for-creators/mapgen/
- Minecraft Bedrock API: https://learn.microsoft.com/en-us/minecraft/creator/documents/scripting/world-apis?view=minecraft-bedrock-stable
- Roblox HTTP API (opt in): https://create.roblox.com/docs/cloud-services/http-service
- Godot CLI headless: https://docs.godotengine.org/en/stable/tutorials/editor/command_line_tutorial.html
- Gymnasium GridWorld research convention: https://gymnasium.farama.org/v1.2.2/tutorials/gymnasium_basics/environment_creation/
- Satoshi primary paper: https://nakamotoinstitute.org/library/bitcoin/
- NIST SHA-256: https://csrc.nist.gov/pubs/fips/180-4/upd1/final
- NIST HMAC: https://csrc.nist.gov/pubs/fips/198-1/final

## Testing gates before a real online/game deployment

1. Run the adapter on a disposable world, never a live world; document engine version and exact module API.
2. Use actual world-query measurements/observations with latency and permission constraints, rather than oracle occupancy or synthetic RGB.
3. Add bounding boxes, coordinate transforms, location-dependent sampling budgets and account-scoped authorization.
4. Implement real asynchronous message passing, graceful disconnect, retries, persistence and cancellation.
5. Compare against a **standard serial scanner and standard parallel worker pool** on identical host hardware using pre-registered acceptance thresholds.
6. Include independent signed evidence checkpoints if a public tamper-evident scientific archive is required.
