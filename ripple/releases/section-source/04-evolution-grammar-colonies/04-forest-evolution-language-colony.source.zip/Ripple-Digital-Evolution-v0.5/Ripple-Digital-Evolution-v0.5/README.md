# Ripple Digital Evolution v0.5 — 2D/3D Colony & Genetic Marker Laboratory

## Status and usage

**Actual working software:** deterministic numerical voxel world generator, offline 2D/3D replay, preserved original leaky integrate-and-fire neuron gates, swarm task dispatcher, legal finite mutation/selection, SHA-256 lineage markers, local hash-linked provenance, and real arithmetic kernels.

**Not provided:** a physically calibrated light sensor, robotic mapping, spatial reasoning general intelligence, integrated Roblox or Minecraft plugin, real cryptocurrency, consensus, externally authenticated scientific dataset, or networked GPU/worker service.

### Fast start (no programming)

Open `Ripple-Digital-World-Lab-v0.5.html` in a recent desktop or mobile browser. It is self-contained and offline. The controls replay **previously executed simulation runs**; changing a displayed variant is *not* live training or a new computation.

### Reproduce from source (Node.js 22 recommended; no npm packages)

```bash
node --test tests/test_v5.js tests/test_evidence.js
node src/search.js             # 4320 architecture trials + evolutionary search + saved map replays
node src/bench_overhead.js    # 25 local host-timing trials
python src/build_products.py # rebuild HTML, synthetic OBJ and Luanti mod input
```

Outputs are in `data/` (raw observations, summaries, fully specified selection experiment, reproducible genotype ancestry and host overhead). The 2D world is 10×10 cells; 3D is 7×7×3. Obstacles, synthetic optical intensity, and resources are generated deterministically from a seed. Every observed occupancy value comes from **the simulated world's oracle**, not an optical classifier.

### Free game adapters

- `adapters/luanti`: complete but **unexecuted in Luanti** Lua mod. Install only in a disposable world, then deliberately run `/ripple_import_demo` as a user with server privileges. It places 23 synthetic obstacle blocks and may overwrite terrain.
- `adapters/minecraft/example_bedrock.ts`: example method that must be wired into a versioned Bedrock behavior pack by its operator. No live engine deployment was performed.
- `adapters/roblox/example_roblox.lua`: optional function using ordinary anchored Parts for Studio, no HTTP and no automatic execution.
- `adapters/voxel_demo.json`: portable geometry/observation schema.
- `adapters/synthetic_3d_obstacles.obj`: standard triangulated static mesh for DCC/Godot/Blender import.

The HTML replay is not a live external-engine controller, and `OBJ` is generated from synthetic ground truth.

## Detailed experiments

The exhaustive finite *selected search grid* is 6 growth × 5 routing × 3 graph × 2 role × 2 dimensions × 3 arrival profiles × 2 training seeds × 2 assumed service regimes = **4,320 numerical executions**. Some variants are equivalent under parity assumptions; all are nevertheless retained, including failed/truncated variants.

Evolution uses 15 generations and at most 16 candidates/generation, with seed-controlled single-gene mutation and elitist selection; stored ancestry markers use the parent marker in their hashed content. All genotype records are constrained to legal genes and ranges. No trained LLM weights are modified.

The selection objective is user-editable in `src/search.js`: `1200*coverage - 0.52*workerSeconds - 2.5*p95 - 0.03*hops`. This intentionally prioritizes efficient completed work but is *not* the unique best objective. Holdout seeds 41/43/47 were not used to select the genome. Commuting delays remain a fixed environment parameter, not a gene.

**Recorded holdout objective, equal per-task costs:** selected evolved 1055.1692; original baseline 1019.14; fixed4 855.7425. A larger score is better for this specific objective. The fixed4 baseline gives lower latency at higher reserved resource-seconds, and under reversed specialist efficiencies the evolved mixed-role policy gives up some advantage.

**Measured host elapsed time, 25 trials, 147 synthetic 3D samples:** sequential direct arithmetic median 1.8755 ms; serial Ripple neuron-gated simulated dispatcher median 8.9923 ms. The outputs matched. The extra bookkeeping costs time; do not infer a speedup.

## Genome cryptographic interpretation

- Versioned SHA-256 markers provide deterministic IDs and verifiable intact JSON if a trusted reference hash is retained.
- Hash-linked ledgers allow local detection of modified records, but are **not** tamperproof against rewriting the full ledger.
- Optional `src/checkpoint_auth.js` creates/verifies a real HMAC-SHA-256 over the ledger head using a user-supplied secret (never stored). This is message authentication, **not encryption**; no Bitcoin-like public consensus exists here.

Example (use your own secret, at least 32 characters):

```bash
RIPPLE_SIGNING_KEY='replace-with-your-own-long-secret-not-this' node src/checkpoint_auth.js sign data/evolution.json
# Copy the displayed MAC and then verify it with the SAME private key:
RIPPLE_SIGNING_KEY='replace-with-your-own-long-secret-not-this' node src/checkpoint_auth.js verify data/evolution.json THE_TAG
```

## Source preservation

`src/ripple_core_reference.js` is byte-identical to v0.4 and v0.3. SHA-256: `d75d4208e92f19623b127615bd52b4002e85d2c0a59b76471764b55a24294210`. Further source-level neuron modifications are out of scope until new sensor/hardware evidence justifies them.

## Evidence and limitations

- `docs/PRODUCT_DECISION.md`: external platform selection and linked vendor docs.
- `docs/MATHEMATICAL_CODEX.md`: original math, new genes, scheduling, and reasons not to claim biological intelligence.
- `docs/NEGATIVE_RESULTS.md`: failures, assumptions, and limits.
- `data/grid_search.json`, `data/grid_summary.json`: 4320 raw trials and grouped metrics.
- `data/evolution.json`: search generations and internally verifiable ancestry/audit log.
- `data/viewer_replays.json`: actual completion traces used by the HTML viewer.
- `data/host_overhead.json`: independently measured host-timing results, which are not physical test data.

No game service or user account was modified; none of the earlier v0.1–v0.4 source trees were changed. Experimental source authored for this package is offered as **CC0-1.0**. The preserved prior sources carry their original project licenses, and third-party platforms/tools retain their own terms.
