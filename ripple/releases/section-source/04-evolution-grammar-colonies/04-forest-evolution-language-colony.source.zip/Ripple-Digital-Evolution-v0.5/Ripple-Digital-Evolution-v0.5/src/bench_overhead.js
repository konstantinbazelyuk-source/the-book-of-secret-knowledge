'use strict';
// Host wall-clock instrumentation. Sequential baseline vs sequential gated simulation.
// The measurements are not apples-to-apples throughput claims; the colony performs extra bookkeeping.
const fs=require('node:fs'),path=require('node:path');
const {Colony}=require('./colony'),{BASE,sha}=require('./genome'),{makeWorld,observation}=require('./world'),{domainTask}=require('./domains');
const {performance}=require('node:perf_hooks');
function baseline(dim=3,seed=41){const world=makeWorld(dim,seed),out=[];for(const cell of world.cells){let o=observation(cell,seed,0);if(o.clipped)o=observation(cell,seed,1);o.domain=domainTask(['learning','product','study'][cell.id%3],o);out.push([cell.id,o]);}return sha(out);}
function median(vals){let x=[...vals].sort((a,b)=>a-b);return x[Math.floor(x.length/2)];}
function benchmark(){const trials=25, rows=[], expected=baseline(3,41);let ok=true;
 for(let i=0;i<trials;i++){const a=performance.now(),hash=baseline(3,41),b=performance.now();const c=new Colony(BASE,{dim:3,seed:41,profile:'burst',service:'parity'}),s=c.run(),end=performance.now();ok=ok&&hash===s.hashOfOutput&&hash===expected;
  rows.push({trial:i,direct_ms:+(b-a).toFixed(4),colony_ms:+(end-b).toFixed(4),correct:hash===s.hashOfOutput,sim_worker_seconds:s.workerSeconds});}
 const summary={type:'Host wall-clock measurements; serial direct mapping versus serialized neuron-gated simulation (includes scheduling and 160s simulated time)',trials,same_outputs:ok,median_direct_ms:median(rows.map(x=>x.direct_ms)),median_colony_ms:median(rows.map(x=>x.colony_ms)),source:'Node.js performance.now(); not multi-thread speed or biological intelligence'};
 fs.writeFileSync(path.join(__dirname,'..','data','host_overhead.json'),JSON.stringify({summary,rows},null,2));console.log(JSON.stringify(summary,null,2));if(!ok)throw Error('output mismatch');}
benchmark();
