'use strict';
// Optional authenticated research checkpoint. No secret stored in repository/artifacts.
const crypto=require('node:crypto');
const fs=require('node:fs'),path=require('node:path');
function tagHead(head,key){if(typeof head!=='string'||!/^([a-f0-9]{64})$/.test(head))throw Error('invalid ledger head');if(typeof key!=='string'||key.length<32)throw Error('key must be at least 32 characters');return crypto.createHmac('sha256',Buffer.from(key,'utf8')).update('ripple-checkpoint-v1\0'+head).digest('hex');}
function verifyHead(head,key,expected){if(!/^[a-f0-9]{64}$/.test(expected||''))return false;const actual=Buffer.from(tagHead(head,key),'hex'),claim=Buffer.from(expected,'hex');return crypto.timingSafeEqual(actual,claim);}
if(require.main===module){const [mode,filepath,tag]=process.argv.slice(2),key=process.env.RIPPLE_SIGNING_KEY;
 if(!['sign','verify'].includes(mode)||!filepath||!key){console.error('Usage: RIPPLE_SIGNING_KEY="[private >=32 chars]" node src/checkpoint_auth.js sign|verify evolution.json [MAC]');process.exit(2);}
 const data=JSON.parse(fs.readFileSync(path.resolve(filepath),'utf8'));const head=data.ledger?.at(-1)?.hash;
 if(!head)throw Error('missing ledger head');if(mode==='sign')console.log(tagHead(head,key));else {const ok=verifyHead(head,key,tag);console.log(ok?'AUTHENTICATED WITH SUPPLIED KEY':'INVALID');process.exit(ok?0:1);}
}
module.exports={tagHead,verifyHead};
