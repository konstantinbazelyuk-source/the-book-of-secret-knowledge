"""Render offline replay and game export artifacts from executed data; no platform connections."""
import json,pathlib,html
from typing import Any
R=pathlib.Path(__file__).resolve().parents[1]; DATA=R/'data';OUT=R/'adapters'
replays=json.loads((DATA/'viewer_replays.json').read_text())
evo=json.loads((DATA/'evolution.json').read_text())
summary=json.loads((DATA/'grid_summary.json').read_text())
world=replays['evolved/3']['world']
# Runtime-safe deterministic data export, not 3D engine installation.
(OUT/'voxel_demo.json').write_text(json.dumps({'schema':'ripple-voxel-observations/1','source':'synthetic world seed 41; this is not a real scanned environment', 'size':world['size'],'cells':world['cells']},indent=2))
vox=[c for c in world['cells'] if c['blocked']]
text='return {\n'+''.join(f'  {{x={c["x"]},y={c["y"]},z={c["z"]}}},\n' for c in vox)+'}\n'
(OUT/'luanti'/'voxels.lua').write_text(text)
(OUT/'luanti'/'mod.conf').write_text('name = ripple_voxels\ndescription = Ripple generated synthetic voxels - demo only\n')
(OUT/'luanti'/'init.lua').write_text('''-- EXPLICIT DEMO COMMAND ONLY. Use a disposable test world. Never auto-place blocks.
local positions = dofile(core.get_modpath("ripple_voxels") .. "/voxels.lua")
core.register_node("ripple_voxels:sample", {description="Ripple Synthetic Test Voxel",tiles={"default_stone.png"},groups={cracky=3}})
core.register_chatcommand("ripple_import_demo", {
  params="", description="Place synthetic Ripple test voxels nearby (test world only)",
  privs={server=true}, func=function(name, param)
    local player=core.get_player_by_name(name)
    if not player then return false,"Player not found" end
    local p=vector.round(player:get_pos())
    -- Offset 12 blocks from user, and 4 blocks above surface. May overwrite existing terrain.
    local n=0
    for _,v in ipairs(positions) do
      local pos={x=p.x+12+v.x,y=p.y+4+v.z,z=p.z+v.y}
      core.set_node(pos,{name="ripple_voxels:sample"});n=n+1
    end
    return true,"Placed "..n.." synthetic obstacle voxels."
  end
})
''')
# optional adapter samples; they are NOT shipped as deployable packs or tested inside games
(OUT/'minecraft'/'example_bedrock.ts').write_text('''// Concept-only Bedrock @minecraft/server adapter. Not executed in Minecraft.
// Requires user-managed behavior-pack manifest/version and a loaded test world.
import { world } from "@minecraft/server";
export function placeSyntheticVoxels(points: Array<{x:number,y:number,z:number}>, origin: {x:number,y:number,z:number}) {
  const dim=world.getDimension("overworld");
  for(const p of points) {
    const loc={x:origin.x+p.x,y:origin.y+p.z,z:origin.z+p.y};
    const block=dim.getBlock(loc);
    if (block) dim.setBlockType(loc, "minecraft:stone");
  }
}
// Deliberately no automatic execution: placeSyntheticVoxels must be called manually.
''')
(OUT/'roblox'/'example_roblox.lua').write_text('''-- Roblox Studio example: no HTTP, no account linkage, no autostart.
-- Call the function manually in a controlled test place.
local function placeSyntheticVoxels(points, origin)
  local folder=Instance.new("Folder")
  folder.Name="RippleSyntheticVoxels"
  folder.Parent=workspace
  for _, p in ipairs(points) do
    local b=Instance.new("Part")
    b.Name="RippleTestVoxel"
    b.Size=Vector3.new(3,3,3)
    b.Anchored=true
    b.Position=origin+Vector3.new(p.x*3,p.z*3,p.y*3)
    b.Parent=folder
  end
  return folder
end
return placeSyntheticVoxels
''')
# export raw world mesh from actual world code counterpart; no collision optimization
verts=[];faces=[]
C=[(0,0,0),(1,0,0),(1,1,0),(0,1,0),(0,0,1),(1,0,1),(1,1,1),(0,1,1)]
Q=[(1,2,3),(1,3,4),(5,6,7),(5,7,8),(1,2,6),(1,6,5),(2,3,7),(2,7,6),(3,4,8),(3,8,7),(4,1,5),(4,5,8)]
for v in vox:
 o=len(verts)
 for a,b,c in C:verts.append(f'v {v["x"]+a} {v["y"]+b} {v["z"]+c}')
 for a,b,c in Q:faces.append(f'f {o+a} {o+b} {o+c}')
(OUT/'synthetic_3d_obstacles.obj').write_text('# Synthetic Ripple 3D voxel obstacles, not physical scan\n'+'\n'.join(verts+faces)+'\n')
# Offline web replayer: actual simulation trace embedded, no calls to network and no live changing genotype
viz='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Ripple Digital World / Genome Laboratory v0.5</title>
<style>
:root{color-scheme:dark;--bg:#091319;--panel:#12242b;--muted:#96b0b7;--line:#31545a;--green:#83dcc1;--accent:#e4ba71;color:#e8f3f0;font-family:system-ui,Segoe UI,sans-serif}*{box-sizing:border-box}
body{margin:0;background:radial-gradient(circle at top left,#1c3c3d,var(--bg) 58%);padding:18px}main{max-width:1100px;margin:auto}h1{font-size:clamp(26px,5vw,42px);margin:5px 0}h2{font-size:20px;margin:3px 0 12px}p{color:var(--muted);line-height:1.55}
.kicker{color:var(--green);font-weight:700;letter-spacing:.11em;text-transform:uppercase;font-size:11px}.grid{display:grid;grid-template-columns:1.3fr .8fr;gap:14px}.pane{border:1px solid var(--line);border-radius:14px;background:var(--panel);padding:15px;min-width:0}.toolbar{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin:14px 0}label{font-size:12px;color:var(--muted);display:flex;flex-direction:column;gap:5px}select,input,button{accent-color:var(--green);background:#0e1c22;color:#fff;border:1px solid #43636b;border-radius:8px;padding:9px;font-size:14px}button{cursor:pointer}button:hover{background:#244047}.statgrid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.stat{background:#0a1c20;border:1px solid #25464a;border-radius:10px;padding:12px}.stat b{font-size:21px;display:block;font-variant-numeric:tabular-nums}.stat span{font-size:11px;color:var(--muted)}canvas{width:100%;height:auto;display:block;background:#0a1a1e;border-radius:10px}.small{font-size:12px}pre{overflow:auto;white-space:pre-wrap;word-break:break-word;font-size:11px;color:#bfdcd6;max-height:270px}.tablewrap{overflow:auto;max-height:300px}table{width:100%;border-collapse:collapse;font-size:11px;white-space:nowrap}td,th{padding:8px;text-align:left;border-bottom:1px solid #284348}th{position:sticky;top:0;background:#143039}td.num{text-align:right}footer{font-size:12px;color:var(--muted);padding:20px 0}@media(max-width:750px){.grid{grid-template-columns:1fr}body{padding:10px}.pane{padding:12px}}
</style></head><body><main><div class="kicker">RIPPLE / DIGITAL EVOLUTION / v0.5</div><h1>Cybernetic Mycelium World Lab</h1>
<p>Executable Ripple-gated mapping results, 2D/3D voxel replay, versioned genetic markers, and objective-based colony comparison. All environments and sensor readings are synthetic; this page replays computed data, rather than invoking Roblox, Minecraft, or AI services.</p>
<div class="toolbar"><label>Colony variant<select id="variant"><option value="single">Single original</option><option value="fixed4">Four fixed workers</option><option value="baseline">Baseline adaptive</option><option value="evolved" selected>Evolved holdout</option></select></label>
<label>Mapping dimensions<select id="dim"><option value="2">2D raster</option><option value="3">3D voxels</option></select></label>
<label>Scene time (simulation seconds)<input type="range" min="0" max="160" step="1" value="160" id="time" style="width:210px"></label><button id="play">Play replay</button></div>
<div class="grid"><section class="pane"><h2 id="worldtitle">Mapping replay</h2><canvas id="scene" width="690" height="410" aria-label="Synthetic voxel mapping replay"></canvas><p class="small" id="legend">Unknown tiles are dim; surveyed free tiles green; surveyed occupied voxels amber.</p></section>
<section class="pane"><h2>Verified simulator outcomes</h2><div class="statgrid"><div class="stat"><b id="mapped">--</b><span>Observed cells / world total</span></div><div class="stat"><b id="units">--</b><span>Simulated worker-seconds</span></div><div class="stat"><b id="latency">--</b><span>Simulation p95 latency</span></div><div class="stat"><b id="nodes">--</b><span>Workers created / retired</span></div></div><p class="small">Replays use held-out seed 41 and burst workload, with equal per-task simulated service costs. Other conditions are available in the search dataset.</p><h2>Selected marker</h2><pre id="genes"></pre></section></div>
<div class="pane" style="margin-top:14px"><h2>Architecture comparison — training seeds</h2><div class="toolbar"><label>Assumed service costs<select id="service"><option value="parity">Equal (no specialist advantage)</option><option value="advantage">Assumed specialist benefit</option></select></label><label>Sort metric<select id="sort"><option value="meanScore">Objective score</option><option value="meanWorkerSeconds">Worker-seconds (lower)</option><option value="meanP95">Latency p95 (lower)</option></select></label></div><p class="small">The score is an explicitly chosen research objective: 1200 × coverage − 0.52 × worker-seconds − 2.5 × p95 latency − 0.03 × hops. Scores are not accuracy or general intelligence ratings.</p><div class="tablewrap"><table><thead><tr><th>Growth / routing / graph / roles</th><th>Coverage</th><th>Worker-seconds</th><th>p95 (s)</th><th>Score</th></tr></thead><tbody id="scores"></tbody></table></div></div>
<footer>Source: code-executed deterministic numerical experiments. Original Ripple neuron checksum preserved. No physical mapping hardware, actual game engine, cryptographic authentication, or autonomous intelligence tested.</footer></main>
<script>
const REPLAYS=%%REPLAY%%;
const RANKINGS=%%SUMMARY%%;
const EVOLUTION=%%EVOLUTION%%;
const $=id=>document.getElementById(id);
function diamond(ctx,x,y,size,fill){ctx.beginPath();ctx.moveTo(x,y-size/2);ctx.lineTo(x+size,y);ctx.lineTo(x,y+size/2);ctx.lineTo(x-size,y);ctx.closePath();ctx.fillStyle=fill;ctx.fill();}
function cube(ctx,x,y,size){diamond(ctx,x,y-12,size,'#d2a462');ctx.fillStyle='#946b3a';ctx.beginPath();ctx.moveTo(x-size,y-12);ctx.lineTo(x,y-size/2-12);ctx.lineTo(x,y+size/2-12);ctx.lineTo(x-size,y);ctx.fill();ctx.fillStyle='#78542c';ctx.beginPath();ctx.moveTo(x,y-size/2-12);ctx.lineTo(x+size,y-12);ctx.lineTo(x+size,y);ctx.lineTo(x,y+size/2-12);ctx.fill();}
function draw(){const key=$('variant').value+'/'+$('dim').value,r=REPLAYS[key],T=Number($('time').value),W=r.world,c=$('scene'),ctx=c.getContext('2d');let completed=r.events.filter(e=>e.t<=T),seen=new Set(completed.map(e=>e.id));ctx.clearRect(0,0,c.width,c.height);ctx.fillStyle='#081b20';ctx.fillRect(0,0,c.width,c.height);
 if(W.dim===2){const n=W.size[0],sz=Math.min(37,350/n),left=(c.width-n*sz)/2,top=24;for(const p of W.cells){const x=left+p.x*sz,y=top+p.y*sz,known=seen.has(p.id);ctx.fillStyle=!known?'#23383d':p.blocked?'#c99554':'#4eab8c';ctx.fillRect(x+1,y+1,sz-2,sz-2);} }
 else {const s=21,x0=c.width/2,y0=160;const sorted=[...W.cells].sort((a,b)=>a.z-b.z||(a.x+a.y)-(b.x+b.y));for(const p of sorted){const x=x0+(p.x-p.y)*s*1.35,y=y0+(p.x+p.y)*s*.62-p.z*26,known=seen.has(p.id);if(p.blocked&&known)cube(ctx,x,y,s);else diamond(ctx,x,y,s,known?'#3e937c':'#263a40');}}
 $('worldtitle').textContent=(W.dim===2?'2D raster':'3D voxel')+' • t = '+T+' s';$('mapped').textContent=completed.length+' / '+W.cells.length;
 $('units').textContent=r.metrics.workerSeconds.toFixed(1);$('latency').textContent=r.metrics.p95+' s';$('nodes').textContent=r.metrics.created+' / '+r.metrics.retired;
 $('genes').textContent=JSON.stringify({phenotypeMarker:r.metrics.genome,lineageMarker:$('variant').value==='evolved'?EVOLUTION.finalGenome.marker:null,parentMarker:$('variant').value==='evolved'?EVOLUTION.finalGenome.parent:null,genes:r.genes},null,2);
}
function ranks(){const service=$('service').value,dim=Number($('dim').value),sort=$('sort').value;let set=RANKINGS.filter(r=>r.service===service&&r.dim===dim);set.sort((a,b)=>sort==='meanScore'?b.meanScore-a.meanScore:a[sort]-b[sort]);$('scores').replaceChildren();for(const r of set.slice(0,30)){let tr=document.createElement('tr');for(const val of [r.variant,r.meanCoverage.toFixed(3),r.meanWorkerSeconds.toFixed(1),r.meanP95.toFixed(2),r.meanScore.toFixed(1)]){let td=document.createElement('td');td.textContent=val;tr.append(td);} $('scores').append(tr);}}
let timer=null;for(const id of ['variant','dim','time'])$(id).addEventListener('input',()=>{draw();if(id==='dim')ranks();});for(const id of ['service','sort'])$(id).addEventListener('input',ranks);
$('play').onclick=()=>{if(timer!==null){clearInterval(timer);timer=null;$('play').textContent='Play replay';return;}
 $('time').value=0;draw();$('play').textContent='Pause';timer=setInterval(()=>{let t=+($('time').value);if(t>=160){clearInterval(timer);timer=null;$('play').textContent='Play replay';return;}$('time').value=Math.min(160,t+2);draw();},80);};
draw();ranks();
</script></body></html>'''
viz=viz.replace('%%REPLAY%%',json.dumps(replays,separators=(',',':'))).replace('%%SUMMARY%%',json.dumps(summary,separators=(',',':'))).replace('%%EVOLUTION%%',json.dumps({'finalGenome':evo['finalGenome'],'holdout':evo['holdout']},separators=(',',':')))
(R/'Ripple-Digital-World-Lab-v0.5.html').write_text(viz)
print('built browser',len(viz),'bytes, obstacles',len(vox))
