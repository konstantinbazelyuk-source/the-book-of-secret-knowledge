'use strict';
const fs=require('node:fs'),path=require('node:path');
const {BASE,MODES,encode,mutate,seeded,Ledger,sha}=require('./genome');
const {Colony}=require('./colony');
const OUT=path.join(__dirname,'..','data');
function run(g,dim,profile,seed,service){return new Colony(g,{dim,profile,seed,service}).run();}
function score(r){const p95=r.p95??180;return 1200*r.coverage-.52*r.workerSeconds-2.5*p95-.03*r.hops;} // user-editable objective, not universal
function sweep(){let rows=[], t=Date.now();
 for(const growth of MODES.growth)for(const routing of MODES.routing)for(const graph of MODES.graph)for(const role of MODES.role){
  const g={...BASE,growth,routing,graph,role};const marker=encode(g).marker.slice(0,16);
  for(const dim of [2,3])for(const profile of ['burst','shift','stream'])for(const seed of [11,17])for(const service of ['parity','advantage']){
   const r=run(g,dim,profile,seed,service);rows.push({...r,variant:`${growth}/${routing}/${graph}/${role}`,marker,score:+score(r).toFixed(4)});
  }
 }
 fs.writeFileSync(path.join(OUT,'grid_search.json'),JSON.stringify(rows));
 const agg={};for(const r of rows){let k=r.variant+':'+r.service+':'+r.dim;(agg[k]??=[]).push(r);}
 const summarized=Object.entries(agg).map(([k,rs])=>({variant:rs[0].variant,service:rs[0].service,dim:rs[0].dim,meanScore:rs.reduce((n,r)=>n+r.score,0)/rs.length,meanCoverage:rs.reduce((n,r)=>n+r.coverage,0)/rs.length,meanWorkerSeconds:rs.reduce((n,r)=>n+r.workerSeconds,0)/rs.length,meanP95:rs.reduce((n,r)=>n+(r.p95??160),0)/rs.length}));
 summarized.sort((a,b)=>b.meanScore-a.meanScore);fs.writeFileSync(path.join(OUT,'grid_summary.json'),JSON.stringify(summarized,null,2));
 console.log('sweep',rows.length,'trials',((Date.now()-t)/1000).toFixed(2),'s','top',summarized.slice(0,5));return rows;}
function evaluate(g,seeds=[11,17],service='parity'){let values=[];for(const dim of [2,3])for(const profile of ['burst','shift','stream'])for(const seed of seeds){values.push(score(run(g,dim,profile,seed,service)));}return +(values.reduce((a,b)=>a+b,0)/values.length).toFixed(4);}
function evolution(){const rng=seeded(7391),ledger=new Ledger();
 let candidates=[{g:{...BASE},parent:null},{g:{...BASE,growth:'economy',routing:'spatial',graph:'ring'},parent:null},{g:{...BASE,growth:'capacity',routing:'leastload',graph:'mesh'},parent:null}];let generations=[];
 for(let gen=0;gen<15;gen++){
  const pool=[...candidates];while(pool.length<16){const p=candidates[Math.floor(rng()*candidates.length)],ancestor=encode(p.g,p.parent).marker;
   const child=mutate(p.g,rng),marker=encode(child,ancestor).marker;
   pool.push({g:child,parent:ancestor});ledger.append('mutation',{generation:gen,ancestor,offspring:marker});}
  const uniq=[...new Map(pool.map(o=>[encode(o.g).marker,o])).values()];
  const ranked=uniq.map(o=>({...o,fitness:evaluate(o.g,[11,17],'parity')})).sort((a,b)=>b.fitness-a.fitness);
  candidates=ranked.slice(0,4).map(({g,parent})=>({g,parent}));const best=ranked[0];
  const event={generation:gen,fitness:best.fitness,marker:encode(best.g,best.parent).marker,genes:best.g,parent:best.parent,attempted:uniq.length};
  generations.push(event);ledger.append('generation',event);
 }
 const champ=candidates[0],control={...BASE,growth:'fixed4',routing:'leastload',graph:'tree',role:'general'};
 const holdout={seeds:[41,43,47],profiles:['burst','shift','stream'],dim:[2,3],tested:{}};
 for(const [name,g] of [['evolved',champ.g],['base',BASE],['fixed4',control]]){
  holdout.tested[name]={genes:g,parity:evaluate(g,holdout.seeds,'parity'),advantage:evaluate(g,holdout.seeds,'advantage'),reverse:evaluate(g,holdout.seeds,'reverse')};}
 const data={generations,finalGenome:encode(champ.g,champ.parent),holdout,ledger:ledger.items,ledgerValid:ledger.verify()};
 fs.writeFileSync(path.join(OUT,'evolution.json'),JSON.stringify(data,null,2));
 console.log('evolution finished',data.finalGenome.marker.slice(0,16),'holdout',holdout.tested);return data;}
function replays(evo){const models={single:{...BASE,growth:'single'},fixed4:{...BASE,growth:'fixed4'},baseline:{...BASE},evolved:evo.finalGenome.genes};const v={};
 for(const [key,g] of Object.entries(models))for(const dim of [2,3]){
  const c=new Colony(g,{dim,seed:41,profile:'burst',service:'parity'});const metrics=c.run();v[`${key}/${dim}`]={metrics,genes:g,world:{dim,size:c.world.size,cells:c.world.cells.map(o=>({id:o.id,x:o.x,y:o.y,z:o.z,blocked:o.blocked,resource:o.resource}))},events:c.completed.map(o=>({id:o.id,t:o.doneAt,worker:o.worker})).sort((a,b)=>a.t-b.t)};}
 fs.writeFileSync(path.join(OUT,'viewer_replays.json'),JSON.stringify(v));}
if(require.main===module){sweep();let e=evolution();replays(e);}
module.exports={run,sweep,evolution,replays,score,evaluate};
