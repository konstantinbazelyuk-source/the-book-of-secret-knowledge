import json,pathlib,statistics
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=pathlib.Path(__file__).resolve().parents[1]
data=json.loads((R/'data'/'grid_search.json').read_text())
policies=['single','fixed4','reactive','capacity','economy','hybrid']
subset={g:[a for a in data if a['variant'].split('/')[0]==g and a['service']=='parity'] for g in policies}
fig,ax=plt.subplots(figsize=(9,4.5))
ax.bar(policies,[statistics.mean(x['workerSeconds'] for x in subset[g]) for g in policies])
ax.set_ylabel('Simulated worker-seconds');ax.set_xlabel('Growth policy');ax.set_title('Resource occupancy under equal per-task service cost');ax.grid(axis='y',alpha=.2);fig.tight_layout();fig.savefig(R/'charts'/'simulated_worker_seconds.png',dpi=150);plt.close(fig)
fig,ax=plt.subplots(figsize=(9,4.5))
ax.bar(policies,[statistics.mean(x['p95'] or 160 for x in subset[g]) for g in policies]);ax.set_ylabel('Simulated latency p95 (s)');ax.set_xlabel('Growth policy');ax.set_title('Work completion delay under equal per-task service cost');ax.grid(axis='y',alpha=.2);fig.tight_layout();fig.savefig(R/'charts'/'simulated_latency.png',dpi=150);plt.close(fig)
h=json.loads((R/'data'/'evolution.json').read_text())['holdout']['tested']
fig,ax=plt.subplots(figsize=(8,4.3));x=list(h);ax.bar(x,[h[v]['parity'] for v in x]);ax.set_ylabel('Chosen objective score (higher is preferred)');ax.set_title('Holdout evaluation, three independent seeds');ax.grid(axis='y',alpha=.2);fig.tight_layout();fig.savefig(R/'charts'/'evolution_holdout.png',dpi=150);plt.close(fig)
print('Wrote three comparison charts')
