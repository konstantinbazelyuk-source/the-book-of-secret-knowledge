# Ripple Digital Evolution v0.5 release manifest

- Source-preservation anchor: original Ripple core SHA-256 `d75d4208e92f19623b127615bd52b4002e85d2c0a59b76471764b55a24294210`.
- `Ripple-Digital-World-Lab-v0.5.html`: self-contained precomputed numerical replay, not a live AI.
- `src/`: preserved LIF kernel, colony simulator, typed genome with lineage, finite genetic search, real logistic/inventory/evidence numeric kernels, optional HMAC authentication, export/render tools and benchmark.
- `tests/`: deterministic unit/integration and evidence/integrity checks.
- `data/grid_search.json`: **4320 executed simulations** (six growth × five routes × three graphs × two roles × two dimensions × three workload arrival schedules × two training seeds × two service assumptions).
- `data/grid_summary.json`: mean values grouped by variant, dimensionality and service assumptions.
- `data/evolution.json`: 15-gen genotype trajectory and HMAC-ready hash-linked audit, final selected genome and three held-out evaluation seeds.
- `data/viewer_replays.json`: previously executed workers' completion traces in synthetic 2D/3D world.
- `data/host_overhead.json`: 25 locally measured runs comparing direct sequential arithmetic to serial Ripple-gated simulation.
- `adapters/`: optional non-deployed Luanti Lua mod, Roblox Luau and Minecraft Bedrock TypeScript examples, portable 3D OBJ and JSON world.
- `charts/`: separately labeled numerical simulations and verified Chromium screenshots.
- `docs/`: product decision and scientific sources, equations, explicit failure/uncertainty ledger.
- `SHA256SUMS.txt`: individual checksums for files, excluding the manifest itself.

Verification executed locally:

- v0.5 tests: **40/40 passed**.
- archived v0.4 JavaScript regression: **18/18 passed**.
- archived v0.4 optical Python regression: **18/18 passed**.
- archived v0.3 regression: **24/24 passed**.
- offline browser replay: 390px mobile and 1280px desktop, **no runtime JS errors or horizontal overflow**, 2D and 3D state verified.
- game-engine adapters: **not tested in real game engines**.

No network or live apps were altered. v0.5 does not deploy any AI agent, execute crypto transactions, or use real optical, magnetic or biological signals.
