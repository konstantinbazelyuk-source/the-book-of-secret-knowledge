from pathlib import Path
import base64,re,json,hashlib
root=Path(__file__).resolve().parent
CACHE={}
pattern=re.compile(r"(?m)^(import\s+(?:(?:[^\n;]+?\s+from\s+))?)(['\"])(\.{1,2}/[^'\"]+)\2\s*;?")
def embed(path):
    path=Path(path).resolve()
    if path in CACHE:return CACHE[path]
    source=path.read_text(encoding='utf-8')
    def fix(m):
        target=(path.parent/m.group(3)).resolve()
        if not target.is_file() or root not in target.parents:raise RuntimeError(f'out-of-tree import {target}')
        return f'{m.group(1)}{m.group(2)}{embed(target)}{m.group(2)};'
    source=pattern.sub(fix,source)
    url='data:text/javascript;base64,'+base64.b64encode(source.encode()).decode()
    CACHE[path]=url
    return url
html=(root/'web/template.html').read_text()
a=embed(root/'src/forest.mjs');b=embed(root/'src/language.mjs')
src=f'import {{ForestDaughterColony,ForestBetaColony,generateForest,shortestRoute,TERRAIN,TERRAIN_NAMES}} from "{a}";\nimport {{trainLanguage,testCode,navigate,SYMBOLS}} from "{b}";'
html=html.replace('/*__MODULE_IMPORTS__*/',src)
html=html.replace('/*__STUDY_RESULT__*/',json.dumps(json.loads((root/'results/study.json').read_text()),separators=(',',':')))
html=html.replace('/*__LOCAL_RESULT__*/',json.dumps(json.loads((root/'results/local-scout.json').read_text()),separators=(',',':')))
destination=root/'Ripple-Forest-Language-Alpha-v1.4.html';destination.write_text(html)
print('built',destination,round(len(html)/1e6,2),'MB; imported files',len(CACHE))
