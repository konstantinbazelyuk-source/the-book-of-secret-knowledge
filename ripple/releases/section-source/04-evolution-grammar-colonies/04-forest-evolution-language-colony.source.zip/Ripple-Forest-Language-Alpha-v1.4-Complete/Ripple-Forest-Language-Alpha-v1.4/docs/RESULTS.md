# Executed research outcomes — forest mapping and restricted communication

**Evidence:** all synthetic; actual source code executed. No physical forest observations, recorded biological data, robot measurements, or real language.

## Communication: 5 independently trained codes × 12 unseen forest seeds × 35 routes

| Condition | Successes | Success rate | Mean route steps |
|---|---:|---:|---:|
| Learned code with full-map scout | 2100/2100 | 100.00% | 16.45 |
| No-message random legal moves | 120/2100 | 5.71% | 82.81 |
| Fixed scrambled symbols | 0/2100 | 0.00% | 85.00 |

All five independent codes decoded both held-out direction+surface combinations at **100.0%** on the fixed validation protocol. The two message slots and factor separation were imposed by design.

## Additional local-only scout stress test
One previously trained code, 12 unseen forest seeds × 35 routes: **410/420 (97.62%)**. The local scout used immediate neighbor passability and goal x/y, not shortest-route ground truth. This is a different evaluation population and must not be pooled with the main 5-model study.

## Beta versus Daughter in the same tracked forest
Daughter mean discovered cells: **132.33**; original Beta mean: **133.00** over 12 paired synthetic seed runs. No meaningful Daughter advantage is established. The earlier daughter experimental result is preserved and not generalized.

## Honest conclusion
The software sender–receiver pair learned a four-state symbol code sufficient to communicate movement instructions in seeded generated forests. A tiny discrete code, task reward shaping, privileged/limited scouts, and an explicitly factorized protocol are the constraints under which success was measured. No human language, self-originating grammar, independent planning from raw images, or general intelligence has been demonstrated. There are no measured real-world signals.

## Files
`results/study.json`: full experiment-level success records and symbol mappings. `results/local-scout.json`: supplementary partial-observation study. `results/browser_smoke.json`: browser interaction testing. `results/test-report.txt`: custom safety and functional tests. `results/beta-parent-regression.txt`: Beta 18 tests; Daughter 19 tests logged separately.
