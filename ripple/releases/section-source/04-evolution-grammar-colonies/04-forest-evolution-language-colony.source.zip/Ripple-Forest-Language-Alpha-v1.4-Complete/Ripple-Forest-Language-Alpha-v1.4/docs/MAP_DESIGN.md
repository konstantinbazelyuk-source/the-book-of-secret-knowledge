# Tracked colony mapping contract (new Alpha v1.4)

This is the first geographic coordinate-tracked forest in this family, distinct from the previous source/role seedbank network.

## Layer A: ground truth (simulation only)
A seeded generator returns a 32×22 array (x=0...31, y=0...21) with integer terrain codes: 0 meadow, 1 trail, 2 dense trees/barrier, 3 water/barrier, 4 brush, 5 beacon. A scripted creek and deliberately cut crossing corridors guarantee traversable routes between landmarks. Forest regions are named North Canopy, Creek Bank, South Clearing, Eastern Grove. These are artistically constructed world zones, not real measured ecosystems or coordinates.

## Layer B: sensory traces
The Beta-compatible field contains color-coded synthetic input; the Daughter Δ³ receives this three-channel stimulus and outputs computed spikes. A scanning action stores coordinate / wall-state / tick in per-agent knowledge. Blocked rays stop at the first obstructing tile. Diffusion is an unchanged synthetic color-field transport stage from Beta; it is not a real photon transport simulation. Drawing of ground truth uses a 'reveal' switch. Without it the viewer sees darkness except known and visited coordinates.

## Layer C: individual histories
Per-agent record: `id`, immutable genome, role, `path` as [x,y,tick], and `known` per-coordinate observations. Global discovery is the union of knowledge cells, not all traversable ground truth. The supplied archive retains Beta role settings (`explorer`, `relay`, `guardian`, `general`); the older Seedbank's eight source indexing categories are not falsely described as active ecologically trained entities.

## Layer D: signals and language
A scout sees the next optimal direction from exact graph shortest path in the main experiment (ground-truth *privilege*). The explorer sees **only** two learned 4-state messages: one direction, one path type (trail/rough), which are decoded to a move and trail decision. The 'local scout' sensitivity uses only adjacent passability and target x/y; it can make poor choices around obstacles. All fields are generated; no camera, phone, robot, GPS, location, or physical energy sensors are used.

## Safety and validation
Reject invalid seeds, out-of-range worlds, bad training budgets, and unknown communication modes. All moves must land on passable cells. No arbitrary code generation, unsafe commands, network calls, or autonomous publishing. SHA256 manifest traces the immutable parent files. Reproducible seeds logged. This is a runnable Alpha, not a claimed natural system.
