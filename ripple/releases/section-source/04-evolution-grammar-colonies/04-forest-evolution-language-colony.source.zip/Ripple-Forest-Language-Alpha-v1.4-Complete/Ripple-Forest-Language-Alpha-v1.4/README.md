# Ripple Forest Colony & Grounded Signals — Alpha v1.4

**Evidence:** Executable synthetic software. **Not** real forest scanning, language comprehension, natural-language learning, robot navigation, or intelligence validation.

## Run without installing tools
Open `Ripple-Forest-Language-Alpha-v1.4.html` in a modern desktop browser. It is a self-contained HTML with preserved source modules embedded as data-URI ES modules. Turn on **Reveal ground truth** to inspect the generated map. Click **Run 50 ticks**, then a location on the map to inspect exactly what the colony has discovered. Click **Train code**, **Oracle-scout routes**, **Local-scout routes**, **No-message control**, and **Scramble control**. Use **Export mapping JSON** for a reproducible path record.

If a browser blocks local modules, serve this folder through a local HTTP server: `python -m http.server 8000` then visit `http://localhost:8000/Ripple-Forest-Language-Alpha-v1.4.html`. The HTML does not request network data or use external APIs.

## Run research and tests
Requires Node.js 20+; no packages to install:

```
node --test tests/forest.test.mjs
node src/study.mjs
node src/local-scout-study.mjs
python build_standalone.py
node --test parents/Ripple-Daughter-Triplet-v3.1/tests/triplet.test.mjs
node --test archive/Ripple-Gen-Beta-v2.0/tests/core.test.mjs
```

The main study is a seeded deterministic exercise: 5 learner seeds, 12 withheld generated maps, 35 routes per mode for 3 communication conditions (2,100 routes per mode). The local-vision sensitivity study uses one learned code on those 12 maps × 35 routes (420 routes) and is **not** directly pooled with the main study. Training uses map seeds 91,103,127,149; evaluation uses 601,607,613,617,631,641,647,653,659,661,673,677. Training omits two combinations, north+rough and west+trail, but includes each primitive feature elsewhere. This is a narrow factorized **symbol-learning** experiment, not natural language.

## Inherited parent architecture and preservation
- `parents/Ripple-Daughter-Triplet-v3.1/` is extracted from the original approved Daughter Δ³ package. The Delta membrane equations and Beta movement/guardrail algorithms are used as imported code, not duplicated/reimplemented.
- `archive/Ripple-Gen-Beta-v2.0/` is the original Beta package retained for independent regression.
- `archive/Ripple-Forest-Alpha-v1.3.html` is a preserved historical Seedbank Forest Alpha catalog. Its previous 'forest' represented an archive and family network, not coordinate-tracked ecological terrain. This release adds that mapped terrain in a separate module.
- Existing releases have **not** been overwritten or deployed.

## World architecture
32 × 22 generated coordinate cells by default; forest ground-truth terrain comprises meadow, trail, trees, water, brush, and beacon. Trees and water block movement and line-of-sight in the BetaWorld. Agent observations are separate from ground-truth map; paths are individual coordinate sequences. The Daughter world calls the original bounded rule engine for moving, scanning, sharing, and offspring, while its existing three-layer neuron is the internal sensory actuator gate. Total population ≤ 16; ticks ≤ 1,200; quaternary messages are 2 symbols in the four-state vocabulary.

## Language experiment and strongest confound
Two independent Q-table sender/receiver pairs learn a direction code and a surface code from reward. **Two message slots are explicitly pre-separated by architecture.** The sender/"scout" has ideal shortest-path knowledge in the main experiment. A supplementary local-scout sensitivity test replaces it with an immediate-neighbor observation and a goal-coordinate heuristic. A receiver learns mappings between symbols and actions, NOT grammar, English, unrestricted thought or general semantics. Near-perfect performance is expected for this tiny four-direction problem once trained with enough examples. Scrambling messages tests whether their mapping matters; no-message controls remove the communication channel.

## Research references
See `docs/RESEARCH_METHODS.md` and `docs/RESULTS.md` for scientific background, limitations, raw data, and negative results. Source URL references are scholarly context, not copied neural networks or trained AI models. Entire system works offline after download.
