import fs from 'node:fs';import {trainLanguage,navigate} from './language.mjs';
const seeds=[601,607,613,617,631,641,647,653,659,661,673,677],model=trainLanguage({seed:511,episodes:12000});
const runs=seeds.map(seed=>{const r=navigate(model,{seed,trials:35,mode:'learned',scout:'local'});return {seed,trials:r.trials,successes:r.successes,meanSteps:r.meanSteps,blocked:r.blockedAttempts}});
const report={evidence:'SIMULATED',scout:'LOCAL_ADJACENT_PASSABILITY+GOAL_COORDINATE',trainedCodeSeed:511,trainingEpisodes:12000,totalTrials:runs.reduce((a,b)=>a+b.trials,0),successes:runs.reduce((a,b)=>a+b.successes,0),runs};report.successRate=report.successes/report.totalTrials;
fs.writeFileSync(new URL('../results/local-scout.json',import.meta.url),JSON.stringify(report,null,2));console.log(JSON.stringify({totalTrials:report.totalTrials,successes:report.successes,successRate:report.successRate},null,2));
