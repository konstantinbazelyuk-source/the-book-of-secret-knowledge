import fs from 'node:fs';
import {ForestDaughterColony,ForestBetaColony,generateForest,shortestRoute} from './forest.mjs';
import {trainLanguage,testCode,navigate} from './language.mjs';
const seeds=[601,607,613,617,631,641,647,653,659,661,673,677];
const trainSeeds=[511,557,619,631,683];const results=[];
for(const learnerSeed of trainSeeds){const model=trainLanguage({seed:learnerSeed,episodes:12000});const test=testCode(model);const navigation=[];
for(const terrainSeed of seeds)for(const mode of ['learned','no_message','scrambled']){
 const m=navigate(model,{seed:terrainSeed,trials:35,mode:mode==='local_scout'?'learned':mode,scout:mode==='local_scout'?'local':'oracle',maxSteps:85});navigation.push({seed:terrainSeed,mode,trials:m.trials,success:m.successes,accuracy:m.correctStep/(m.correctStep+m.wrongStep),blocked:m.blockedAttempts,meanSteps:m.meanSteps});
}
results.push({seed:learnerSeed,glossary:model.glossary,terrainGlossary:model.terrainGlossary,test:{total:test.totals,accuracy:test.fullAccuracy,heldout:test.heldoutAccuracy,contexts:test.score},navigation});}
const colony=[];for(const seed of seeds){const d=new ForestDaughterColony({seed}),b=new ForestBetaColony({seed});d.run(120);b.run(120);const ds=d.summary(),bs=b.summary();colony.push({seed,daughter:{coverage:ds.coverage,moves:ds.moves,scans:ds.scans,blockedRays:ds.blockedRays,population:ds.population},beta:{coverage:bs.coverage,moves:bs.moves,scans:bs.scans,blockedRays:bs.blockedRays,population:bs.population}})}
const aggregate={};for(const mode of ['learned','no_message','scrambled']){const trials=results.flatMap(r=>r.navigation.filter(x=>x.mode===mode));aggregate[mode]={episodes:trials.reduce((a,b)=>a+b.trials,0),successes:trials.reduce((a,b)=>a+b.success,0),meanSuccess:trials.reduce((a,b)=>a+b.success,0)/trials.reduce((a,b)=>a+b.trials,0),meanDecisionAccuracy:trials.reduce((a,b)=>a+b.accuracy,0)/trials.length,meanSteps:trials.reduce((a,b)=>a+b.meanSteps,0)/trials.length}};
const mean=(arr)=>arr.reduce((a,b)=>a+b,0)/arr.length;
const out={meta:{name:'Forest Language Study',evidence:'SYNTHETIC/SEEDED',routeOracle:'scout has privileged shortest-path knowledge',trainingSeeds:trainSeeds,holdoutMapSeeds:seeds,episodesPerModel:12000,terrain:['tree','water','trail','meadow','brush','beacon'],factors:['heading (4)','surface class (2)'],message:'two 4-state tokens',compositionalPrior:'explicit factorized speaker/listener channels',localScout:'knows immediate passable neighbors and goal coordinates only, no shortest-path oracle',naturalLanguageClaim:false},aggregate,learners:results,colony:{pairedSeeds:seeds,daughterMeanCoverage:mean(colony.map(r=>r.daughter.coverage)),betaMeanCoverage:mean(colony.map(r=>r.beta.coverage)),results:colony}};
fs.writeFileSync(new URL('../results/study.json',import.meta.url),JSON.stringify(out,null,2));
console.log(JSON.stringify({aggregate,daughterMeanCoverage:out.colony.daughterMeanCoverage,betaMeanCoverage:out.colony.betaMeanCoverage,heldout:results.map(x=>x.test.heldout),glossary:results[0].glossary},null,2));
