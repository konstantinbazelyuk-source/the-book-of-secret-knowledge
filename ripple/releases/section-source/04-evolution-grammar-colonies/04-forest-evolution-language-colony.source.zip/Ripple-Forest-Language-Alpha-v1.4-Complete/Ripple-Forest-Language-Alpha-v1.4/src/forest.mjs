/** Ripple Forest Language Alpha v1.4: deterministic synthetic forest and tracked-mapping adapter.
 * The v3.1 DaughterTripletNeuron and v2.0 BetaWorld are imported intact.
 * This map is generated geometry, not satellite, lidar or botanical data.
 */
import {DaughterWorld} from '../parents/Ripple-Daughter-Triplet-v3.1/src/daughter-world.mjs';
import {BetaWorld, rng, BETA_LIMITS} from '../parents/Ripple-Daughter-Triplet-v3.1/vault/beta/src/beta-engine.mjs';
export const DIRS=Object.freeze([[0,-1],[1,0],[0,1],[-1,0]]);
export const TERRAIN=Object.freeze({MEADOW:0,TRAIL:1,TREES:2,WATER:3,BRUSH:4,BEACON:5});
export const TERRAIN_NAMES=['Meadow','Trail','Tree barrier','Water barrier','Brush','Beacon'];
const id=(x,y,w)=>y*w+x;
function check(ok,msg){if(!ok)throw Error('Forest guard: '+msg)}
export function generateForest(seed=142, w=32,h=22){
 check(Number.isInteger(seed)&&seed>=0&&seed<=0xffffffff,'uint32 seed');
 check(Number.isInteger(w)&&w>=12&&w<=BETA_LIMITS.maxWidth&&Number.isInteger(h)&&h>=12&&h<=BETA_LIMITS.maxHeight,'dimensions');
 const r=rng(seed),cells=new Uint8Array(w*h);let trailNodes=[];
 // Multi-scale woodland patches, a creek, accessible crossroads and 3 corridor levels.
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){
  const density=.11+.17*(Math.sin(x*.53+seed*.003)*Math.cos(y*.47)>0?.6:0);
  const n=r();let t=n<density?TERRAIN.TREES:n<density+.13?TERRAIN.BRUSH:TERRAIN.MEADOW;
  // Stream has a traversable southern crossing. Absolute grid coordinates are synthetic.
  const creekX=Math.round(w*.70+Math.sin(y*.49+seed*.0001)*1.8);
  if(Math.abs(x-creekX)<=1&&y>=Math.floor(h*.13)&&y<=Math.floor(h*.85))t=TERRAIN.WATER;
  cells[id(x,y,w)]=t;
 }
 const corridors=[Math.floor(h*.22),Math.floor(h*.50),Math.floor(h*.78)];
 for(const y of corridors)for(let x=1;x<w-1;x++){cells[id(x,y,w)]=TERRAIN.TRAIL;trailNodes.push([x,y]);}
 for(const x of [Math.floor(w*.17),Math.floor(w*.5),Math.floor(w*.85)])for(let y=1;y<h-1;y++){cells[id(x,y,w)]=TERRAIN.TRAIL;trailNodes.push([x,y]);}
 for(let y=0;y<h;y++){cells[id(0,y,w)]=TERRAIN.TREES;cells[id(w-1,y,w)]=TERRAIN.TREES;}
 for(let x=0;x<w;x++){cells[id(x,0,w)]=TERRAIN.TREES;cells[id(x,h-1,w)]=TERRAIN.TREES;}
 const beacons=[[Math.floor(w*.17),Math.floor(h*.22)],[Math.floor(w*.5),Math.floor(h*.50)],[Math.floor(w*.85),Math.floor(h*.78)]];
 for(const [x,y] of beacons)cells[id(x,y,w)]=TERRAIN.BEACON;
 const blocked=Uint8Array.from(cells,t=>t===TERRAIN.TREES||t===TERRAIN.WATER?1:0);
 const zones=[{name:'North Canopy',x:1,y:1,w:Math.floor(w*.49),h:Math.floor(h*.44)},
 {name:'Creek Bank',x:Math.floor(w*.49),y:1,w:Math.floor(w*.29),h:Math.floor(h*.87)},
 {name:'South Clearing',x:1,y:Math.floor(h*.50),w:Math.floor(w*.49),h:Math.floor(h*.48)},
 {name:'Eastern Grove',x:Math.floor(w*.77),y:1,w:Math.floor(w*.22),h:Math.floor(h*.88)}];
 return {schema:'ripple-forest-map/1',seed,w,h,cells,blocked,beacons,zones,provenance:'GENERATED_SYNTHETIC_TERRAIN'};
}
export function neighbors(m,at){const x=at%m.w,y=Math.floor(at/m.w);return DIRS.map(([dx,dy],dir)=>({pos:id(x+dx,y+dy,m.w),x:x+dx,y:y+dy,dir})).filter(n=>n.x>=0&&n.x<m.w&&n.y>=0&&n.y<m.h&&!m.blocked[n.pos]);}
export function shortestRoute(m,start,goal){check(Number.isInteger(start)&&Number.isInteger(goal)&&start>=0&&goal>=0&&start<m.cells.length&&goal<m.cells.length&&!m.blocked[start]&&!m.blocked[goal],'route endpoints');
 const predecessor=new Int32Array(m.cells.length).fill(-1);const Q=new Int32Array(m.cells.length);let head=0,tail=0;Q[tail++]=start;predecessor[start]=start;
 while(head<tail&&predecessor[goal]<0){const cur=Q[head++];for(const n of neighbors(m,cur))if(predecessor[n.pos]<0){predecessor[n.pos]=cur;Q[tail++]=n.pos;}}
 if(predecessor[goal]<0)return null;const path=[goal];while(path.at(-1)!==start)path.push(predecessor[path.at(-1)]);path.reverse();return path;
}
export function bearing(m,a,b){const ax=a%m.w,ay=Math.floor(a/m.w),bx=b%m.w,by=Math.floor(b/m.w);return DIRS.findIndex(([dx,dy])=>dx===bx-ax&&dy===by-ay)}
export function hazardClass(m,cell){return m.cells[cell]===TERRAIN.TRAIL||m.cells[cell]===TERRAIN.BEACON?0:1;}
function maskForest(world,worldMap){
 world.forest=worldMap;
 world.mask=Float64Array.from(worldMap.blocked);
 world.sources=worldMap.beacons.map(([x,y],i)=>[x,y,i%3]);
 world.field=new Float64Array(worldMap.w*worldMap.h*3);
 for(let i=0;i<worldMap.cells.length;i++){
  const t=worldMap.cells[i],v=t===TERRAIN.BEACON?[.7,.6,.25]:t===TERRAIN.TRAIL?[.26,.38,.18]:t===TERRAIN.BRUSH?[.20,.30,.12]:t===TERRAIN.TREES?[.08,.11,.05]:t===TERRAIN.WATER?[.1,.18,.55]:[.22,.34,.17];
  for(let c=0;c<3;c++)world.field[i*3+c]=v[c];
 }
 // Beta's original agent starts are on traversable trail coordinates.
 world.agents.forEach((a,i)=>{const at=[[Math.floor(world.w*.17),Math.floor(world.h*.5)],[Math.floor(world.w*.17),Math.floor(world.h*.5)+1],[Math.floor(world.w*.17)+1,Math.floor(world.h*.5)]][i];let x=at[0],y=at[1];if(world.mask[id(x,y,world.w)]){x=Math.floor(world.w*.17);y=Math.floor(world.h*.5);}a.x=x;a.y=y;a.path=[[x,y,0]];a.known.clear();});
 world.globalDiscovered.clear();world.traces=[];world.audit.push({tick:0,type:'forest_map_applied',seed:worldMap.seed,generated:true});
}
export class ForestDaughterColony extends DaughterWorld{
 constructor({seed=142,width=32,height=22,scenario='mixed',...other}={}){super({seed,width,height,scenario,...other});maskForest(this,generateForest(seed,width,height));}
 mapping(){const paths=this.agents.map(a=>({agent:a.id,role:a.g.role,points:a.path.slice(),mapped:[...a.known.entries()].map(([pos,entry])=>({x:pos%this.w,y:Math.floor(pos/this.w),wall:entry.wall}))}));const gt=this.forest;return {schema:'ripple-forest-mapping/1',seed:gt.seed,ticks:this.tick,world:{w:this.w,h:this.h,terrain:[...gt.cells],zones:gt.zones,beacons:gt.beacons},paths,globalDiscovered:[...this.globalDiscovered],summary:this.summary(),evidence:'SIMULATED'};}
}
export class ForestBetaColony extends BetaWorld{
 constructor({seed=142,width=32,height=22,scenario='mixed',...other}={}){super({seed,width,height,scenario,...other});maskForest(this,generateForest(seed,width,height));}
}
