/** Cooperative four-state messages learned through synthetic forest movements.
 * Not human natural language. Scout has privileged ground-truth shortest route.
 * Sender and listener tables are learned from task rewards; symbols start meaningless.
 * Factorized message fields are an explicit design prior, not spontaneous grammar.
 */
import {generateForest,neighbors,shortestRoute,bearing,hazardClass} from './forest.mjs';
import {rng} from '../parents/Ripple-Daughter-Triplet-v3.1/vault/beta/src/beta-engine.mjs';
export const SYMBOLS=['−1','−0','0','1'];
const TRAIN_CONTEXTS=[0,2,3,4,5,7]; // dir*2+surface; all primitive values seen
const HOLDOUT_CONTEXTS=[1,6]; // North rough and West trail, unseen combinations
function guard(v,msg){if(!v)throw Error('Language guard: '+msg)}
function pick(q,r,epsilon){if(r()<epsilon)return Math.floor(r()*q.length);let mx=Math.max(...q),indices=q.map((x,i)=>x===mx?i:-1).filter(v=>v>=0);return indices[Math.floor(r()*indices.length)];}
const greedy=q=>q.indexOf(Math.max(...q));
export function taskPool(map,seed,count=2400){const r=rng(seed),walkable=[];for(let i=0;i<map.cells.length;i++)if(!map.blocked[i])walkable.push(i);
 const pools=Array.from({length:8},()=>[]);let attempts=0;
 while(attempts<count*8 && pools.some(p=>p.length<count/8)){
   attempts++;const from=walkable[Math.floor(r()*walkable.length)],to=walkable[Math.floor(r()*walkable.length)];if(from===to)continue;
   const route=shortestRoute(map,from,to);if(!route||route.length<2)continue;
   const dir=bearing(map,route[0],route[1]),hazard=hazardClass(map,route[1]),ctx=dir*2+hazard;
   if(pools[ctx].length<count/8)pools[ctx].push({from,to,direction:dir,hazard,context:ctx,distance:route.length-1});
 }
 return {pools,attempts,counts:pools.map(p=>p.length)};
}
function emptyModel(){return {senderDir:Array.from({length:4},()=>Array(4).fill(0)),receiverDir:Array.from({length:4},()=>Array(4).fill(0)),senderSurface:Array.from({length:2},()=>Array(4).fill(0)),receiverSurface:Array.from({length:4},()=>Array(2).fill(0))};}
export function trainLanguage({seed=511,episodes=12000,terrainSeeds=[91,103,127,149],excludeContexts=HOLDOUT_CONTEXTS}={}){
 guard(Number.isInteger(episodes)&&episodes>=1000&&episodes<=100000,'episode budget [1000,100000]');
 guard(Number.isInteger(seed)&&seed>=0&&seed<=0xffffffff,'seed');
 const r=rng(seed),model=emptyModel(),contexts=[0,1,2,3,4,5,6,7].filter(c=>!excludeContexts.includes(c));
 const all=terrainSeeds.map((s,i)=>taskPool(generateForest(s),s+915+i*77,720));
 for(const c of contexts)guard(all.some(t=>t.counts[c]>0),'missing training route class '+c);
 const log=[],rate=.16;
 for(let ep=0;ep<episodes;ep++){
  const context=contexts[Math.floor(r()*contexts.length)],directory=all[Math.floor(r()*all.length)],choices=directory.pools[context];
  if(!choices?.length)continue;
  const sample=choices[Math.floor(r()*choices.length)],d=sample.direction,h=sample.hazard,epsilon=.015+.27*Math.pow(1-ep/episodes,2);
  const tokenD=pick(model.senderDir[d],r,epsilon),tokenH=pick(model.senderSurface[h],r,epsilon);
  const action=pick(model.receiverDir[tokenD],r,epsilon),surface=pick(model.receiverSurface[tokenH],r,epsilon);
  // Both learn from the same scalar rewards, but directional and surface components
  // are trained as separate channels by architecture: a deliberate compositional prior.
  const rd=action===d?1:-1,rh=surface===h?1:-1;
  model.senderDir[d][tokenD]+=rate*(rd-model.senderDir[d][tokenD]);
  model.receiverDir[tokenD][action]+=rate*(rd-model.receiverDir[tokenD][action]);
  model.senderSurface[h][tokenH]+=rate*(rh-model.senderSurface[h][tokenH]);
  model.receiverSurface[tokenH][surface]+=rate*(rh-model.receiverSurface[tokenH][surface]);
  if((ep+1)%2000===0)log.push({episode:ep+1,directionPolicy:contexts.map(c=>{const dir=Math.floor(c/2),tk=greedy(model.senderDir[dir]);return greedy(model.receiverDir[tk])===dir?1:0;}).reduce((a,b)=>a+b,0)/contexts.length});
 }
 return {schema:'ripple-forest-language-model/1',seed,episodes,excluded:[...excludeContexts],trainedOn:terrainSeeds,model,learningLog:log,
  glossary: Array.from({length:4},(_,dir)=>({context:dir,symbol:SYMBOLS[greedy(model.senderDir[dir])],decodedDirection:greedy(model.receiverDir[greedy(model.senderDir[dir])])})),
  terrainGlossary:Array.from({length:2},(_,hazard)=>({context:hazard,symbol:SYMBOLS[greedy(model.senderSurface[hazard])],decodedSurface:greedy(model.receiverSurface[greedy(model.senderSurface[hazard])])})),
  claim:'LEARNED_RESTRICTED_SYNTHETIC_COMMUNICATION; NOT NATURAL LANGUAGE'};
}
export function encode(model,d,h){return [greedy(model.model.senderDir[d]),greedy(model.model.senderSurface[h])];}
export function decode(model,token){return [greedy(model.model.receiverDir[token[0]]),greedy(model.model.receiverSurface[token[1]])];}
export function testCode(model,{seed=9021,terrainSeeds=[601,607,613,617]}={}){
 const errors=[],score=Array.from({length:8},()=>({n:0,direction:0,surface:0,both:0}));
 for(const s of terrainSeeds){const result=taskPool(generateForest(s),seed+s,640);for(let c=0;c<8;c++)for(const task of result.pools[c]){
  const [dir,haz]=decode(model,encode(model,task.direction,task.hazard));const t=score[c];t.n++;t.direction+=dir===task.direction;t.surface+=haz===task.hazard;t.both+=dir===task.direction&&haz===task.hazard;
  if(errors.length<12&&!(dir===task.direction&&haz===task.hazard))errors.push({seed:s,context:c,prediction:[dir,haz],actual:[task.direction,task.hazard]});
 }}
 const totals=score.reduce((a,x)=>({n:a.n+x.n,direction:a.direction+x.direction,surface:a.surface+x.surface,both:a.both+x.both}),{n:0,direction:0,surface:0,both:0});
 return {score,totals,directionAccuracy:totals.direction/totals.n,fullAccuracy:totals.both/totals.n,heldoutContexts:[1,6],heldoutAccuracy:(score[1].both+score[6].both)/(score[1].n+score[6].n),errors};
}
export function navigate(model,{seed=613,trials=80,mode='learned',maxSteps=85,scout='oracle'}={}){
 guard(['oracle','local'].includes(scout),'scout information mode');
 guard(['learned','no_message','scrambled'].includes(mode),'known evaluation mode');
 const random=rng(seed*179+28),map=generateForest(seed),tasks=taskPool(map,seed+101,1300);
 const candidates=tasks.pools.flat();guard(candidates.length>=trials,'not enough route tasks');
 let successes=0,steps=0,obstructions=0,wrongSurface=0,wrongStep=0,correctStep=0,episodes=[];
 for(let k=0;k<trials;k++){
  const task=candidates[Math.floor(random()*candidates.length)];let at=task.from,spent=0,seen=new Set([at]),transcript=[],localVisit=new Map([[at,1]]);
  while(spent<maxSteps&&at!==task.to){
    const route=shortestRoute(map,at,task.to);if(!route||route.length<2)break;
    const perfectDir=bearing(map,route[0],route[1]);
    let guided=route[1];
    if(scout==='local'){
      const candidates=neighbors(map,at),tx=task.to%map.w,ty=Math.floor(task.to/map.w);
      candidates.sort((a,b)=>(Math.abs(a.x-tx)+Math.abs(a.y-ty)+.35*(localVisit.get(a.pos)||0))-(Math.abs(b.x-tx)+Math.abs(b.y-ty)+.35*(localVisit.get(b.pos)||0)) || a.dir-b.dir);
      guided=candidates[0]?.pos??route[1];
    }
    const goalDir=bearing(map,at,guided),hazard=hazardClass(map,guided);let action,surface,pair;
    if(mode==='no_message'){
      const legal=neighbors(map,at);const dir=legal[Math.floor(random()*legal.length)];action=dir.dir;surface=Math.floor(random()*2);pair=null;
    }else{
      pair=encode(model,goalDir,hazard);
      if(mode==='scrambled')pair=[(pair[0]+1)%4,(pair[1]+1)%4];
      [action,surface]=decode(model,pair);
    }
    correctStep+=action===perfectDir;wrongStep+=action!==perfectDir;
    wrongSurface+=surface!==hazard;
    const x=at%map.w+([0,1,0,-1][action]),y=Math.floor(at/map.w)+([-1,0,1,0][action]),dest=x>=0&&x<map.w&&y>=0&&y<map.h?y*map.w+x:-1;
    if(dest<0||map.blocked[dest]){obstructions++;}else{at=dest;seen.add(at);localVisit.set(at,(localVisit.get(at)||0)+1);}
    if(transcript.length<45)transcript.push({step:spent,position:at,message:pair?pair.map(x=>SYMBOLS[x]).join(' '):'none',scoutDirection:goalDir,optimalDirection:perfectDir,action,surfacePrediction:surface,actualSurface:hazard,blocked:dest<0||map.blocked[dest]===1});
    spent++;
  }
  const success=at===task.to;successes+=success;steps+=spent;
  if(k<6)episodes.push({start:task.from,goal:task.to,shortestPathLength:task.distance,success,steps:spent,visited:[...seen],trace:transcript});
 }
 return {seed,trials,mode,scout,maxSteps,successes,successRate:successes/trials,meanSteps:steps/trials,blockedAttempts:obstructions,wrongSurface,correctStep,wrongStep,episodes,evidence:'SYNTHETIC GENERATED FOREST'};
}
