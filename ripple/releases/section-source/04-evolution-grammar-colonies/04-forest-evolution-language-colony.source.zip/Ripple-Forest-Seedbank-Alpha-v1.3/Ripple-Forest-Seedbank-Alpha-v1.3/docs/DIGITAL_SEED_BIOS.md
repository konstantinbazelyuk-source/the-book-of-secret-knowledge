# Digital species bios — provenance before claims

## Forest-S01: spectral-symbolic chain

**Status:** TESTED_SYNTHETIC_ONLY. **Source parents:** Ripple Photoreceptor v0.6, Ripple Quaternary v0.7, Sensory Gene Gate v1.2. **Genetic configuration:** `[0.44, 0.35, 0.21]` RGB simplex weights; no inverted polarity; a quaternary threshold of `0.10` and dwell of `2` samples. **Actual program:** read synthetic RGB values, compute adapted photoreceptor channels using preserved source, convert those values into a scalar signed drive with original channel semantics, and pass drive into preserved four-symbol quaternary encoder. A comparison branch feeds the raw RGB drive to another encoder with the same parameters.

**Verified:** the three vendor files exactly match the corresponding original archive members by SHA-256. Five 80-sample synthetic scenarios executed. Quaternary packing roundtrips correctly, density penalizes the separate inherited birth logit, and inherited RGB components remain normalized. Outputs and markers are stored under `data/interop.json`, `data/forest.json`, `data/vendor_provenance.json` and in SQLite `specimens`.

**Negative result:** filtered and unfiltered quaternary encodings were identical for these five scenarios even where photoreceptor transient event totals changed. No conclusion of improved cognition, optical reconstruction, real sight or causal reasoning follows. The valid result is interoperable software behavior and traceable inheritance.

## Staged seeds (not live integrated)

- `signal_to_learning` — optical readings to four-symbol encoder (a tested triple exists, but this *specific* two-parent contract remains staged).
- `optical_to_spatial` — spectral observations for occupancy mapping; absent calibrated sensor coordinates and error model.
- `genetic_colony` — inherited bounded growth rules in an adaptive colony; current candidate not tested end-to-end as a cross.
- `policy_provenance` — proposal gate with audit and archive logging; an authentication layer remains missing.
- `distributed_study` — resource-aware dispatch across Kokoro mesh concepts; deployment security not assessed.
- `scan_research` — floor/voxel observation combined with original feedback; does not yet possess ground-truth calibration.
- `sensory_genome` — optical gene selection under external environmental shifts; would require real out-of-distribution measurements.
- `feedback_quaternary` — formal interface between LIF pulse events and quaternary symbol encoding; only separate unit tests and related signals currently exist.

## Acceptance requirement for any new species

A proposed species must declare exact parent SHA digests, source interfaces, expected behaviors, independent reference baselines, failure cases, held-out datasets, safety permissions, performance/bias metrics and rollback behavior. Its ledger cannot be marked `TESTED_SYNTHETIC_ONLY` without running the combined software; it cannot be called physically validated without instrument evidence; it cannot be described as intelligent without predefined independent generalization tests.
