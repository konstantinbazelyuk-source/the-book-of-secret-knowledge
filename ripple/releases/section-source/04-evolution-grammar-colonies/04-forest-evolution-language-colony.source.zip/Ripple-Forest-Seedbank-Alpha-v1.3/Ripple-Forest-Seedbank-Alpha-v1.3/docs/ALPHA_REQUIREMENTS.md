# Ripple Forest Alpha 1.3 — software requirements and acceptance matrix

| ID | Requirement | Acceptance |
|---|---|---|
| FR-01 | Index every accessible unique ZIP source in the current Ripple corpus without regenerating it | 27 distinct SHA-256 digests; DB and copied bytes verified |
| FR-02 | Preserve original sources and licenses | Source archives copied unchanged; original license files remain in archives |
| FR-03 | Make source identity unambiguous | SHA256, bytes, source name and internal count recorded; duplicate names do not override digest |
| FR-04 | Assign evidence-qualified forest roles | Role and capabilities in SQLite and standalone UI, with caveat that tags are candidate indices |
| FR-05 | Seed interoperable hybrid proposals without code execution | Two exact parent IDs and schema-bounded gene parameters; all staged and unpromoted |
| FR-06 | Execute at least one real cross-Ripple module chain | v0.6 photoreceptor → v1.2 color genes → v0.7 quaternary on five synthetic scenarios |
| FR-07 | Maintain nonnegative, conserved synthetic resources | Numerical tests enforce balance and min balance across 96 trials |
| FR-08 | Compare alternate routing and flow policies | Four distinct transport modes with identical fixed stock and paired seeds |
| FR-09 | Retain negative results | Document no universally superior variant, environment abstractions, and arithmetic tolerance correction |
| FR-10 | Persist experiment observations | SQLite `studies`, JSON results, ordered chained `events` |
| FR-11 | Reject corrupted or tampered sources | CRC source validation, source checksum and tamper unit tests |
| FR-12 | Maintain relational integrity | SQLite `foreign_keys=ON`, `foreign_key_check` test |
| FR-13 | No automatic arbitrary code execution | ZIP code never executed; explicit allowlist source trees and vendor modules only |
| FR-14 | Provide offline review UI | Self-contained HTML, archive filter, forest network, candidate hybrid selection and data tables |
| FR-15 | Supply no-cost cloud-ready workflow, without silent deployment | Manual GitHub Actions only; no scheduled or credential-bearing calls |
| FR-16 | Be honest about testing boundaries | `SKIPPED_MISSING` rather than pass when legacy trees unavailable |
| FR-17 | Standalone portable archive operation | Content address archive in package + source index + standard-library Python |
| FR-18 | Declare scope of intelligence | No claim of independent intelligence or physical sensing without new evidence |

## Proposed (not accepted or achieved) continuation

- XR-01 Permission-scoped read-only source inspection across all archived program families. Not simply keyword search: parse AST with trusted language-specific parsers and review licenses and file authenticity before any execution.
- XR-02 Repeat each integration experiment under sensor noise, saturation, message corruption, node loss, distribution shift and independent held-out physical observations.
- XR-03 Produce versioned hypothesis dossiers generated from cross-family source interfaces with explicit possible failures, confidence levels and human approval gates.
- XR-04 Add an isolated cloud worker with API authentication, activity logging, quotas, CPU/memory caps and immutable deployment artifacts; never run arbitrary external JS in the main process.
- XR-05 Measure whether model performance improves on real tasks over strong conventional non-Ripple baselines. Negative or neutral results are retained.
- XR-06 Establish explicit criteria for adaptive learning and generalization *before* declaring autonomous intelligent behavior.
