# Forest functional design — analogy and evidence

## Biological grounding

Heaton et al., *Analysis of fungal networks* (2012), DOI 10.1016/j.fbr.2012.02.001, review how real fungal networks reorganize to explore patchy resources and discuss network extraction and biophysical flow models. Fricker et al., *The Mycelium as a Network* (2017), discuss interactions among network topology, resources and connectivity: https://pmc.ncbi.nlm.nih.gov/articles/PMC11687498/ . A 2025 review, *Electrical signaling in fungi: past and present challenges*, explains that fungal electrophysiology remains methodologically difficult and does not establish the computational semantics of spikes: https://pmc.ncbi.nlm.nih.gov/articles/PMC11995700/ .

These sources motivate *analogies*, not algorithm validation. This research software is a graph of files, modules and experiments, not a reproduction of fungal physiology.

| Forest function | Software responsibility | Existing Ripple family | Evidence level |
|---|---|---|---|
| Inoculum / founding strain | Immutable LIF numerical kernel, continuity and baseline | Neuron open prototype, original repository | Original source, local regression |
| Hyphal sensory tip | RGB light transformation, optical measurements and calibration concepts | Photoreceptor, Spectrum, Heterodyne, FieldSphere, Sensor Bridge | Photoreceptor JS executed with synthetic data; other archives indexed |
| Signal transducer | Four-state signal coding and bounded transitions | Quaternary v0.7 | Original quaternary code executed on synthetic signals |
| Foraging explorers | Occupancy maps, image mosaics, scanning and robotics interface concepts | SpiderScan, Digital Evolution | Digital Evolution regression; physical scanner unbuilt |
| Mycelial network / nutrient transfer | Task redistribution, queued computational work, resource flow model | Cybernetic Mycelium, Integrated Alpha | Original suite and standalone numerical experiment |
| Growth regulator | Inheritance, mutation, restricted generated policies, clone thresholds | Hybrid Alpha, Sensory Gene Gate | Regression tests and preserved code; no external JS permission |
| Memory and spores | Hash inventory, replay, event ledger and seedbank storage | Codex Observer, Phone PWA, new Seedbank | New SQLite and exact artifact storage |
| Fruiting interface / dissemination | Operator-reviewed external API surfaces, agent requests | Kokoro Mesh, UI and phone tools | Archived; not live connected |

## Internal contracts

An archive is a *source artifact*, not an executing organism. Each table `species` row has an exact parent `artifact_sha`, a functional role, candidate capability tags, and an evidence descriptor. Hybrid rows contain two actual source IDs and bounded proposed parameter genes; all start `STAGED_RESEARCH_ONLY`.

An executable hybrid needs an explicit typed input/output adapter and tests, not just two compatible-looking filenames. For example, **photoreceptor output: `[R,G,B]` float in [0,1]** can feed the **color-gene adapter: 3-vector**, whose signed drive can feed the **quaternary encoder: scalar**, subject to timing and calibration constraints. This one triplet is implemented and tested. No equivalent executable cross-family bridge is claimed for the other staged records.

## Resource transport

A discrete graph edge exchanges an amount proportional to the difference in synthetic resource stock. For edge `(i,j)`, `Delta = k * (stock[i] - stock[j])`, transferred symmetrically. The global algorithm limits the net outflow from each node to its available balance. It enforces conservation to numerical tolerance. Since simulation uses a fixed synthetic stock, no claim about fungal cytoplasmic flow, physical nutrient mass or hardware electrical currents follows.

`uniformity = 1 / (1 + population_variance(stock))` is only a descriptive score for this synthetic model, not a metabolic fitness or general intelligence score. Faster broadcast levels can spread more resource under the chosen edge constants, but may have higher unmodeled communication costs; those are not measured here.

## Defining verified intelligence criteria for later stages

Research should explicitly test real out-of-distribution perception, causal hypothesis discrimination, independent experiment design, information exchange under message loss, calibrated uncertainty, robust policy reversion, reliable work completion and human-controlled access to external systems. The current project has not established those criteria; it is a preparation to evaluate them honestly.
