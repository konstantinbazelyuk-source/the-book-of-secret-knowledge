# Optional cloud runner — not automatically deployed

The package includes `.github/workflows/forest_manual.yml` for **manually triggered GitHub Actions**. The lab is not presently hosted or continuously operating on GitHub, Roblox, Luanti, Minecraft, a cryptocurrency network or an external agent service.

To use it, create a new **private** GitHub repository under your own account, verify you can upload this ZIP's source archives within your Git provider's size/usage limits, extract the project into repository root, commit the complete project, then open **Actions → Ripple Forest Alpha manual research → Run workflow**. The workflow checks out the repository with `contents: read`, runs the standard-library registry, Node vendor interoperability test and Python tests, and uploads `data/` and the offline viewer as a build artifact. Do not add account keys or payment information to the repository. Review GitHub Action pricing and quota first; free quotas vary by plan and may change.

The hosted run will mark legacy regression suites `SKIPPED_MISSING` unless their original trusted source trees are separately provided. It **will not** unpack and execute arbitrary archive programs to make the dashboard appear busy.

**Cloud operations are not required** for deterministic numerical seedbank experiments. The local run is safer, cost predictable and fully offline. For scalable future cross-research use quota-controlled serverless tasks and a secure object store; gate access to external APIs and permissions for each explicit task.
