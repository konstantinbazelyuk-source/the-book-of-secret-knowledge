#!/usr/bin/env python3
"""Static cross-archive code study. NO code import, eval, unzip-to-disk or execution."""
import hashlib, itertools, json, re, sqlite3, zipfile
from collections import Counter,defaultdict
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; DATA=ROOT/'data'; ARCH=ROOT/'archive'
FUNC_JS=re.compile(r'\b(?:export\s+)?(?:async\s+)?function\s+([A-Za-z_$][\w$]*)\s*\(|\b(?:export\s+)?(?:class|const)\s+([A-Za-z_$][\w$]*)\s*(?:=|\{)')
FUNC_PY=re.compile(r'^\s*(?:async\s+)?def\s+([A-Za-z_]\w*)\s*\(',re.M)
FUNC_LUA=re.compile(r'\bfunction\s+([A-Za-z_]\w*)\s*\(')
SUPPORTED={'.js','.mjs','.cjs','.ts','.tsx','.py','.lua'}

def cross():
 sources=json.loads((DATA/'source_index.json').read_text());report=[];symbols={};files_by_hash=defaultdict(list);source_by_path=defaultdict(list)
 for digest,name in sorted(sources.items()):
  archive=ARCH/(digest[:16]+'.zip');local=[];defs=set();skipped=0;codefiles=0
  with zipfile.ZipFile(archive) as z:
   for i in z.infolist():
    path=Path(i.filename)
    if path.suffix.lower() not in SUPPORTED or any(p in ('.git','node_modules','__pycache__') for p in path.parts) or i.file_size>2_000_000 or codefiles>=180:
     continue
    codefiles+=1
    try:src=z.read(i).decode('utf8')
    except UnicodeError:skipped+=1;continue
    h=hashlib.sha256(src.encode()).hexdigest()
    names=([t[0] or t[1] for t in FUNC_JS.findall(src)] if path.suffix.lower() in ('.js','.mjs','.cjs','.ts','.tsx') else FUNC_PY.findall(src) if path.suffix.lower()=='.py' else FUNC_LUA.findall(src))
    defs.update(names)
    files_by_hash[h].append((digest,i.filename));source_by_path[path.name.lower()].append((digest,h,i.filename))
    local.append({'file':i.filename,'source_sha':h,'symbols':sorted(set(names))[:150]})
  report.append({'archive':name,'sha256':digest,'codeFilesInspected':codefiles,'decodedFiles':len(local),'symbolsFound':len(defs),'symbols':sorted(defs)[:120],'files':local,'decodeSkipped':skipped})
  symbols[digest]=defs
 # Candidate pairs are evidence of possible common interfaces, not working compositions.
 pairs=[]
 for a,b in itertools.combinations(report,2):
  common=sorted(symbols[a['sha256']]&symbols[b['sha256']]);pair_hashes=sum(1 for h,m in files_by_hash.items() if {a['sha256'],b['sha256']}.issubset({x[0] for x in m}))
  if common or pair_hashes:
   pairs.append({'a':a['sha256'],'b':b['sha256'],'sourceA':a['archive'],'sourceB':b['archive'],'sharedSymbolNames':len(common),'sharedIdenticalCodeFiles':pair_hashes,'examples':common[:16],'interpretation':'static candidate; identical names do not prove compatible signatures'})
 pairs.sort(key=lambda x:(-x['sharedIdenticalCodeFiles'],-x['sharedSymbolNames'],x['sourceA'],x['sourceB']))
 out={'schema':'ripple-cross-research/1','classification':'static source evidence, NOT executable integration','archiveCount':len(report),'readableCodeFiles':sum(x['decodedFiles'] for x in report),'sourceSignatures':len(files_by_hash),'duplicateCodeDigests':sum(len(set(x[0] for x in v))>1 for v in files_by_hash.values()),'pairwiseTotal':len(report)*(len(report)-1)//2,'pairsWithStaticOverlap':len(pairs),'pairExamples':pairs[:45],'archiveIndex':[{k:v for k,v in a.items() if k!='files'} for a in report]}
 (DATA/'cross_research.json').write_text(json.dumps(out,indent=2));(DATA/'code_index.json').write_text(json.dumps(report,indent=2));
 db=sqlite3.connect(DATA/'forest.sqlite');db.execute('PRAGMA foreign_keys=ON')
 db.execute('CREATE TABLE IF NOT EXISTS code_index(archive_sha TEXT NOT NULL REFERENCES artifacts(sha), source_path TEXT NOT NULL, source_sha TEXT NOT NULL, symbol_count INTEGER NOT NULL, PRIMARY KEY(archive_sha,source_path))')
 db.execute('DELETE FROM code_index')
 for a in report:
  for f in a['files']:db.execute('INSERT INTO code_index VALUES(?,?,?,?)',(a['sha256'],f['file'],f['source_sha'],len(f['symbols'])))
 db.commit();db.close()
 print(json.dumps({k:v for k,v in out.items() if k not in ('pairExamples','archiveIndex')},indent=2));return out
if __name__=='__main__':cross()
