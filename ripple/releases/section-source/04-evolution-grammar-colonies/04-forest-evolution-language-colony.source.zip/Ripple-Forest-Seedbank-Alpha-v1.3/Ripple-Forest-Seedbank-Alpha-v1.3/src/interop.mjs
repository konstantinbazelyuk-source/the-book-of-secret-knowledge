// Research-only integration: executes verified older JS modules on SYNTHETIC signals.
// No external JS, network, file mutation, or source rewriting.
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {QuadEncoder,pack4,unpack4} from '../vendor/quaternary_v07_LOCKED.mjs';
import {driveFromColor, birthProbability, inheritGene,initGene} from '../vendor/sensory_math.mjs';
const require=createRequire(import.meta.url);
const {Photoreceptor}=require('../vendor/photoreceptor_v06_LOCKED.js');
const fixed=[.44,.35,.21];
function signal(kind,t){
 const background=[.42,.32,.22];
 if(kind==='step')return t<20?background:[.79,.39,.17];
 if(kind==='pulse')return t%12<6?[.72,.32,.21]:[.36,.27,.23];
 if(kind==='blue')return t%16<8?[.22,.22,.8]:[.37,.3,.21];
 if(kind==='saturated')return t%8<4?[1,1,1]:[.95,.95,.95];
 if(kind==='steady')return background;
 throw Error('unknown');
}
const scenarios=[];
for(const kind of ['steady','step','pulse','blue','saturated']){
 const photo=new Photoreceptor({linear:false});
 const qRaw=new QuadEncoder({threshold:.10,dwell:2,noiseMult:0});
 const qPhoto=new QuadEncoder({threshold:.10,dwell:2,noiseMult:0});
 let rawTransitions=0,photoTransitions=0,disagreements=0,photoreceptorON=0;
 const samples=[];
 for(let t=0;t<80;t++){
  const rgb=signal(kind,t);
  const p=photo.step(rgb,.05);
  const a=qRaw.step({drive:driveFromColor(rgb,fixed)});
  const b=qPhoto.step({drive:driveFromColor(p.output,fixed)});
  rawTransitions+=Number(a.code===0||a.code===3);
  photoTransitions+=Number(b.code===0||b.code===3);
  disagreements+=Number(a.code!==b.code);
  photoreceptorON+=p.on.reduce((v,x)=>v+x,0);
  samples.push({t,raw:a.label,filtered:b.label,light:rgb[0]});
 }
 scenarios.push({scenario:kind,samples:80,rawTransitions,photoTransitions,disagreements,photoreceptorON,disagreementFraction:disagreements/80,sampleTrace:samples.filter((_,i)=>i%8===0)});
}
const code=[0,1,2,3]; assert.deepEqual(unpack4(pack4(code)),code);
assert.equal(birthProbability({density:1,crowding:1,energy:.2})<birthProbability({density:0,crowding:0,energy:1}),true);
let i=0;const parent=initGene();const offspring=inheritGene(parent,()=>[.2,.9,.4,.6,.7,.3][(i++)%6]);
assert.ok(Math.abs(offspring.color.reduce((a,b)=>a+b,0)-1)<1e-10);
const result={classification:'executed JS with generated/synthetic light readings',passed:true,modules:['photoreceptor_v06_LOCKED.js','quaternary_v07_LOCKED.mjs','sensory_math.mjs'],scenarios,checks:{quaternaryPacking:'pass',densityBirthGate:'pass',inheritedWeights:'pass'},limitations:'No camera calibration, no biological intelligence, no proof of useful signal semantics. Disagreements are not accuracy improvements.'};
console.log(JSON.stringify(result));
