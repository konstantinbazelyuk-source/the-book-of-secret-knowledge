#!/usr/bin/env python3
"""Ripple Forest Alpha 1.3. Evidence-backed seedbank. Python standard library only.
Archives are immutable inputs; the program never extracts, imports or executes their code.
Trusted adapter suites run only from explicit allowlisted local paths.
"""
from __future__ import annotations
import argparse, csv, hashlib, itertools, json, math, os, random, re, shutil, sqlite3, subprocess, sys, tempfile, zipfile
from collections import Counter, defaultdict
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT/'data'; ARCHIVE=ROOT/'archive'; SOURCE = Path('/mnt/data')
H=lambda b:hashlib.sha256(b).hexdigest()
S=lambda v:json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False)

# Curated capabilities from source review; actual presence and checksums are tested separately.
# This taxonomy is biological metaphor, NOT evidence that software shares fungal physiology.
TAXONOMY = [
 ('Sensory and physical optical',[r'Photoreceptor',r'Spectrum',r'Heterodyne',r'FieldSphere',r'Optical_Agent',r'Sensor_Bridge',r'Optical-Historical'], 'hyphal_tip', ['optical','signal']),
 ('Voxel mapping and robotics',[r'SpiderScan',r'Digital-Evolution'], 'explorer', ['mapping','spatial']),
 ('Distributed and metabolic modeling',[r'Cybernetic-Mycelium',r'Alpha-Integrated'], 'transport', ['colony','routing']),
 ('Genetic and executable policies',[r'Hybrid-Alpha',r'Sensory-Gene-Gate'], 'regulator', ['genome','mutation','gate']),
 ('Memory and observation',[r'Codex-Observer',r'Neuron-Phone',r'Android-Home',r'Installable-Web'], 'memory', ['observation','interface']),
 ('Communication and cognition adapter',[r'Kokoro'], 'interface', ['mesh','orchestration']),
 ('Quaternary program engine',[r'Quaternary'], 'transducer', ['quaternary','signal']),
 ('Foundational neuron',[r'Open-Prototype',r'GitHub-Repository-All-Versions'], 'inoculum', ['neuron','feedback']),
]
FEATURE_PATTERNS={
 'optical':r'photoreceptor|optical|spectr|rgb|camera|heterodyne',
 'signal':r'quaternary|signal|photon|fft|temporal|field',
 'mapping':r'map|voxel|mosaic|occupancy|slam|scan',
 'spatial':r'3d|geometry|position|spider|path|world',
 'colony':r'colony|mycel|replica|worker|population',
 'routing':r'rout|scheduler|queue|steal',
 'genome':r'genom|gene|heredit|inherit|lineage',
 'mutation':r'mutat|crossover|evolut|color',
 'gate':r'guard|gate|review|policy|approval',
 'observation':r'observ|feedback|measure|sensor',
 'interface':r'ui|web|android|widget|phone|mesh',
 'mesh':r'mesh|multi.?model|agent',
 'orchestration':r'orchestr|queue|dispatcher|workflow',
 'quaternary':r'quaternary|four.?symbol',
 'neuron':r'neuron|integrate.and.fire|firing',
 'feedback':r'feedback|adaptive|threshold'
}
EXT={'.js','.mjs','.cjs','.py','.ts','.tsx','.lua','.ipynb'}

def taxonomy(name):
 for label,patterns,role,cap in TAXONOMY:
  if any(re.search(p,name,re.I) for p in patterns):return label,role,cap
 return 'Unclassified legacy reference','reserve',[]

def source_candidates():
 out={}
 for directory in ([ROOT/'archive'] if os.environ.get('RIPPLE_FOREST_ARCHIVES_ONLY')=='1' else [ROOT/'archive',Path('/mnt/data'),Path('/mnt/data/ripple_alpha_sources')]):
  if directory.exists():
   for p in directory.glob('*.zip'):
    if 'fresh' in p.name.lower() or 'forest-seedbank' in p.name.lower():continue
    digest=H(p.read_bytes())
    if digest not in out:out[digest]=p
    else: # Prefer meaningful names over hash-addressed archive paths.
     chosen=out[digest]
     is_hash=lambda v: bool(re.fullmatch(r'[0-9a-f]{16}\.zip',v.name))
     if (is_hash(chosen) and not is_hash(p)) or (not is_hash(p) and not is_hash(chosen) and len(p.name)<len(chosen.name)):
      out[digest]=p
 return sorted(out.items(),key=lambda x:x[1].name.casefold())

def connect(db):
 conn=sqlite3.connect(db);conn.execute('PRAGMA foreign_keys=ON');conn.execute('PRAGMA journal_mode=DELETE');
 conn.executescript('''
 CREATE TABLE IF NOT EXISTS artifacts(sha TEXT PRIMARY KEY, filename TEXT NOT NULL, bytes INTEGER NOT NULL, members INTEGER NOT NULL, valid INTEGER NOT NULL CHECK(valid in (0,1)), total_uncompressed INTEGER NOT NULL, note TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS species(id TEXT PRIMARY KEY, artifact_sha TEXT NOT NULL REFERENCES artifacts(sha), family TEXT NOT NULL, role TEXT NOT NULL, capabilities_json TEXT NOT NULL, evidence TEXT NOT NULL, status TEXT NOT NULL CHECK(status in ('archived','adapter-tested','inferred')));
 CREATE TABLE IF NOT EXISTS studies(id TEXT PRIMARY KEY, kind TEXT NOT NULL, seed INTEGER NOT NULL, inputs_json TEXT NOT NULL, results_json TEXT NOT NULL, status TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS hybrids(id TEXT PRIMARY KEY, parent_a TEXT NOT NULL REFERENCES species(id), parent_b TEXT NOT NULL REFERENCES species(id), gene_json TEXT NOT NULL, marker_sha TEXT NOT NULL UNIQUE, status TEXT NOT NULL, evidence_json TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS specimens(id TEXT PRIMARY KEY, parent_sources_json TEXT NOT NULL, gene_json TEXT NOT NULL, marker_sha TEXT NOT NULL UNIQUE, evaluation_status TEXT NOT NULL, evidence_json TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS events(seq INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, payload_json TEXT NOT NULL, previous_sha TEXT NOT NULL, sha TEXT NOT NULL UNIQUE);
 ''');return conn

def event(conn,kind,payload):
 previous=conn.execute('SELECT sha FROM events ORDER BY seq DESC LIMIT 1').fetchone()
 prev=previous[0] if previous else '0'*64
 packed=S(dict(kind=kind,payload=payload,previous=prev))
 conn.execute('INSERT INTO events(kind,payload_json,previous_sha,sha) VALUES(?,?,?,?)',(kind,S(payload),prev,H(packed.encode())))

def safe_audit(p):
 with zipfile.ZipFile(p) as z:
  infos=z.infolist();total=sum(i.file_size for i in infos)
  if len(infos)>10000 or total>400_000_000:raise ValueError('resource bound')
  if any(i.file_size>80_000_000 for i in infos):raise ValueError('large member')
  if z.testzip() is not None:raise ValueError('corrupt archive')
  return infos,total

def build_registry(conn,copy_sources=True):
 conn.execute('DELETE FROM hybrids');conn.execute('DELETE FROM species');conn.execute('DELETE FROM artifacts');
 records=[];ARCHIVE.mkdir(exist_ok=True,parents=True)
 index_path=DATA/'source_index.json'
 index=json.loads(index_path.read_text()) if index_path.exists() else {}
 for digest,p in source_candidates():
  try:infos,total=safe_audit(p);ok=1;note='zip CRC checked'
  except Exception as exc:infos=[];total=0;ok=0;note=f'quarantined: {type(exc).__name__}'
  # Stable artifact path depends on content, not untrusted filename.
  local=f'{digest[:16]}.zip'
  if copy_sources and ok and not (ARCHIVE/local).exists():shutil.copy2(p,ARCHIVE/local)
  name=index.get(digest,p.name) if re.fullmatch(r'[0-9a-f]{16}\.zip',p.name) else p.name
  conn.execute('INSERT INTO artifacts VALUES(?,?,?,?,?,?,?)',(digest,name,p.stat().st_size,len(infos),ok,total,note))
  family,role,declared=taxonomy(name)
  membernames='\n'.join(i.filename for i in infos if Path(i.filename).suffix.lower() in EXT or '/docs/' in i.filename or 'README' in i.filename)
  detected=[cap for cap,pat in FEATURE_PATTERNS.items() if re.search(pat,membernames,re.I)]
  # Advertised capabilities are candidate indexes, not verified callable behavior.
  capabilities=sorted(set(declared)|set(detected))
  sid='rpl-'+digest[:12]
  status='archived' if ok else 'inferred'
  conn.execute('INSERT INTO species VALUES(?,?,?,?,?,?,?)',(sid,digest,family,role,S(capabilities),'archive filenames and entry listing; function not necessarily tested',status))
  records.append({'id':sid,'name':name,'archive':local,'sha256':digest,'bytes':p.stat().st_size,'members':len(infos),'family':family,'role':role,'capabilities':capabilities,'integrity':bool(ok),'execution':'archived; not executed by registry'})
 index_path.write_text(json.dumps({r['sha256']:r['name'] for r in records},indent=2))
 event(conn,'inventory',{'archives':len(records),'unique_content_hashes':len(records)})
 conn.commit();return records

def ledger_verify(conn):
 old='0'*64
 for seq,kind,payload,prev,digest in conn.execute('SELECT seq,kind,payload_json,previous_sha,sha FROM events ORDER BY seq'):
  if prev!=old or digest!=H(S(dict(kind=kind,payload=json.loads(payload),previous=prev)).encode()):return False
  old=digest
 return True

def verify_assets(conn):
 for sha,filename in conn.execute('SELECT sha,filename FROM artifacts WHERE valid=1'):
  p=ARCHIVE/(sha[:16]+'.zip')
  if not p.exists() or H(p.read_bytes())!=sha:return False
 return True

def hybrid_records(conn):
 rows=conn.execute('SELECT id,capabilities_json,family,role FROM species').fetchall()
 m={sid:(set(json.loads(c)),fam,role) for sid,c,fam,role in rows}
 byfeature=defaultdict(list)
 for sid,(caps,fam,role) in m.items():
  for cap in caps:byfeature[cap].append(sid)
 rolepre={'signal_to_learning':('hyphal_tip','transducer'),'optical_to_spatial':('hyphal_tip','explorer'),'genetic_colony':('regulator','transport'),'policy_provenance':('regulator','memory'),'distributed_study':('transport','interface'),'scan_research':('explorer','inoculum'),'sensory_genome':('regulator','hyphal_tip'),'feedback_quaternary':('inoculum','transducer')}
 recipes=[
 ('signal_to_learning','optical','quaternary',{'contrast':0.55,'noise_floor':0.07,'lag':2}),
 ('optical_to_spatial','optical','mapping',{'ray_budget':3,'occlusion':0.6,'density':0.2}),
 ('genetic_colony','genome','colony',{'birth_cap':8,'mutate_prob':0.04,'cooldown':3}),
 ('policy_provenance','gate','observation',{'template_only':1,'checksum':1,'review_required':1}),
 ('distributed_study','routing','orchestration',{'queue_limit':32,'deadline':50,'trust':1}),
 ('scan_research','mapping','feedback',{'ray_budget':2,'coverage_threshold':0.6}),
 ('sensory_genome','mutation','optical',{'inherit_prob':0.8,'channel_floor':0.003}),
 ('feedback_quaternary','feedback','quaternary',{'threshold':0.08,'dwell':2}),
 ]
 hybrids=[]
 for name,a,b,genes in recipes:
  candidates=[(u,v) for u in sorted(byfeature[a]) for v in sorted(byfeature[b]) if u!=v]
  if not candidates:continue
  # Deterministic source provenance; no hidden claim of species integration.
  pref=rolepre[name]
  candidates.sort(key=lambda pair:(int(m[pair[0]][2]!=pref[0])+int(m[pair[1]][2]!=pref[1]),int(m[pair[0]][1]==m[pair[1]][1]),pair))
  u,v=candidates[0]
  rec={'schema':'ripple-forest-hybrid/1','name':name,'parents':[u,v],'genes':genes,'capabilities':[a,b]}
  marker=H(S(rec).encode());hid='hyb-'+marker[:12]
  conn.execute('INSERT INTO hybrids VALUES(?,?,?,?,?,?,?)',(hid,u,v,S(genes),marker,'STAGED_RESEARCH_ONLY',S({'support':'contract candidates from archive index','verified_executable_coupling':False})))
  hybrids.append({'id':hid,'name':name,'parents':[u,v],'parentNames':[m[u][1],m[v][1]],'genes':genes,'marker_sha':marker,'status':'STAGED_RESEARCH_ONLY','tested_link':'not established'})
 event(conn,'candidate_hybrids',{'count':len(hybrids),'promotion':'none'})
 conn.commit();return hybrids

# Shared finite resource flow: conservative graph transport, analogous in *structure*
# to a resource network, not a physical fungus or literal intelligence.
def graph_flow(n=12,steps=32,seed=17,mode='diffusion',blocked=False):
 if mode not in ('none','diffusion','adaptive','broadcast'):raise ValueError(mode)
 rng=random.Random(seed);edges=[(i,i+1) for i in range(n-1)]+[(i,(i+3)%n) for i in range(0,n,3)]
 edges=list(dict.fromkeys(tuple(sorted(e)) for e in edges if e[0]!=e[1]))
 if blocked:edges=[e for e in edges if e!=(5,6)]
 stock=[0.0]*n;stock[0]=90.0
 history=[];total=round(sum(stock),10)
 for k in range(steps):
  flux=[0.0]*n
  for a,b in edges:
   kappa={'none':0,'diffusion':.08,'adaptive':.12,'broadcast':.18}[mode]
   if mode=='adaptive' and abs(stock[a]-stock[b])<2:kappa*=.4
   exchange=kappa*(stock[a]-stock[b]);flux[a]-=exchange;flux[b]+=exchange
  # cap outflow to available resource so no agent spends more than it owns
  ratio=min(1.0,min((stock[i]/(-flux[i]) if flux[i]<0 else 1.0) for i in range(n)))
  stock=[stock[i]+ratio*flux[i] for i in range(n)]
  if min(stock)<-1e-8:raise AssertionError('negative resource')
  if abs(sum(stock)-total)>1e-7:raise AssertionError('nonconservative transport')
  history.append([round(v,7) for v in stock])
 return {'mode':mode,'n':n,'seed':seed,'steps':steps,'blocked':blocked,'totalInitial':total,'totalFinal':sum(stock),'minStock':min(stock),'uniformity':1/(1+sum((x-total/n)**2 for x in stock)/n),'covered':sum(x>.25 for x in stock),'trace':history}

def run_flow_trials(conn):
 result=[]
 for seed,mode,blocked in itertools.product(range(12),('none','diffusion','adaptive','broadcast'),(False,True)):
  result.append(graph_flow(seed=seed,mode=mode,blocked=blocked))
 summary=[]
 for mode in ('none','diffusion','adaptive','broadcast'):
  r=[x for x in result if x['mode']==mode]
  summary.append({'mode':mode,'trials':len(r),'meanCovered':sum(x['covered'] for x in r)/len(r),'meanUniformity':sum(x['uniformity'] for x in r)/len(r),'maxConservationError':max(abs(x['totalFinal']-x['totalInitial']) for x in r)})
 record={'kind':'network_transport','classification':'simulated mathematical experiment','trials':len(result),'summary':summary}
 conn.execute('INSERT OR REPLACE INTO studies VALUES(?,?,?,?,?,?)',('forest-transport-96','resource_transport',0,S({'seeds':12,'modes':4,'damage_scenarios':2}),S(record),'SIMULATED'))
 event(conn,'study',{'id':'forest-transport-96','trials':len(result)})
 conn.commit();(DATA/'transport_trials.json').write_text(json.dumps(result,indent=2));return summary

def register_tested_seed(conn,interop):
 # This is one executed three-module composition, not a new self-aware species.
 source_files={'photoreceptor_v06_LOCKED.js','quaternary_v07_LOCKED.mjs','sensory_math.mjs'}
 verified=json.loads((DATA/'vendor_provenance.json').read_text())
 if set(x['vendor'] for x in verified)!=source_files or not all(x['byte_identical'] for x in verified):raise ValueError('vendor provenance not verified')
 seed={'schema':'ripple-forest-tested-seed/1','name':'Forest-S01: spectral-symbolic chain','modules':[{k:r[k] for k in ('archive','member','vendor','original_sha256')} for r in verified], 'genes':{'rgb_weights':[.44,.35,.21],'polarity':[False,False,False],'quaternary_threshold':.10,'dwell':2}}
 marker=H(S(seed).encode())
 conn.execute('INSERT OR REPLACE INTO specimens VALUES(?,?,?,?,?,?)',('Forest-S01',S([x['archive'] for x in verified]),S(seed['genes']),marker,'TESTED_SYNTHETIC_ONLY',S({'scenarios':5,'interop_pass':interop['passed'],'no_physical_sensing':True,'no_new_intelligence':True})))
 event(conn,'tested_seed',{'id':'Forest-S01','marker_sha':marker,'scenarios':5})
 conn.commit();return {'id':'Forest-S01','name':seed['name'],'marker_sha':marker,'parents':[x['archive'] for x in verified],'genes':seed['genes'],'status':'TESTED_SYNTHETIC_ONLY'}

def run_legacy_tests(conn):
 # Explicit allowlist from the original generated source. Neither archives nor newly generated JS are run here.
 suites=[
  ('original_neuron','/mnt/data/Ripple-Cybernetic-Mycelium-v0.1','node',['test_colony.js']),
  ('colony_v02','/mnt/data/Ripple-Cybernetic-Mycelium-v0.2','node',['--test','tests/test_v2.js']),
  ('digital_v05','/mnt/data/Ripple-Digital-Evolution-v0.5','node',['--test','tests/test_v5.js','tests/test_evidence.js']),
  ('alpha_v10','/mnt/data/Ripple-Alpha-Integrated-Lab-v1.0','node',['--test','tests/alpha.test.js']),
  ('hybrid_v11','/mnt/data/Ripple-Hybrid-Alpha-v1.1','node',['--test','tests/hybrid.test.mjs']),
  ('sensory_gate_v12','/mnt/data/Ripple-Sensory-Gene-Gate-Alpha-v1.2','node',['--test','tests/alpha.test.mjs']),
 ]
 rows=[]
 for name,dir,exe,args in suites:
  wd=Path(dir)
  if os.environ.get('RIPPLE_FOREST_SKIP_LEGACY')=='1':rows.append({'suite':name,'status':'SKIPPED_MISSING','reason':'legacy source trees not part of cloud runner'});continue
  if not (wd/args[-1]).exists():rows.append({'suite':name,'status':'SKIPPED_MISSING','path':str(wd/args[-1])});continue
  try:
   p=subprocess.run([exe,*args],cwd=wd,timeout=50,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
   rows.append({'suite':name,'status':'PASS' if p.returncode==0 else 'FAIL','exit':p.returncode,'stdout_tail':p.stdout[-1000:],'stderr_tail':p.stderr[-400:]})
  except (FileNotFoundError,subprocess.TimeoutExpired) as exc:rows.append({'suite':name,'status':'NOT_EXECUTED','reason':type(exc).__name__})
 (DATA/'legacy_tests.json').write_text(json.dumps(rows,indent=2))
 conn.execute('INSERT OR REPLACE INTO studies VALUES(?,?,?,?,?,?)',('legacy-regressions','software_regression',0,S({'allowlist':True}),S(rows),'MEASURED_HOST_EXECUTION'))
 event(conn,'tests',{'suiteStatuses':{x['suite']:x['status'] for x in rows}});conn.commit();return rows

def run_interop(conn):
 # Trusted JS in the unchanged v1.2 working directory runs directly to avoid executing ZIP input.
 script=ROOT/'src'/'interop.mjs'
 p=subprocess.run(['node',str(script)],cwd=ROOT,timeout=25,capture_output=True,text=True)
 if p.returncode:raise RuntimeError(p.stderr[-1200:])
 result=json.loads(p.stdout.strip());(DATA/'interop.json').write_text(json.dumps(result,indent=2))
 conn.execute('INSERT OR REPLACE INTO studies VALUES(?,?,?,?,?,?)',('optical-quaternary-interop','software_interoperability',0,S({'script_sha256':H(script.read_bytes())}),S(result),'EXECUTED_SYNTHETIC_INPUT'))
 event(conn,'interop',{'cases':len(result['scenarios']),'passed':result['passed']})
 conn.commit();return result

def update_execution_evidence(conn,records,legacy,interop):
 passed={x['suite'] for x in legacy if x['status']=='PASS'}
 stems={
  'original_neuron':['Cybernetic-Mycelium-v0.1'],
  'colony_v02':['Cybernetic-Mycelium-v0.2'],
  'digital_v05':['Digital-Evolution-v0.5'],
  'alpha_v10':['Alpha-Integrated-Lab-v1'],
  'hybrid_v11':['Hybrid-Alpha-v1.1'],
  'sensory_gate_v12':['Sensory-Gene-Gate-Alpha-v1.2'],
 }
 for r in records:
  valid_suite=[k for k,patterns in stems.items() if k in passed and any(pattern.lower() in r['name'].lower() for pattern in patterns)]
  if valid_suite:
   r['execution']='related local source tree passed regression; archive bytes not executed directly'
   r['regressionSuites']=valid_suite
   conn.execute("UPDATE species SET status='adapter-tested',evidence=? WHERE id=?",(S({'related_suites':valid_suite,'qualification':'local source tree tested; archived bytes integrity-audited'}),r['id']))
  elif interop.get('passed') and (('Photoreceptor' in r['name']) or ('Quaternary' in r['name'])):
   r['execution']='related locked module imported by interop test; original archive itself not directly executed'
   conn.execute("UPDATE species SET status='adapter-tested',evidence=? WHERE id=?",(S({'interop':True,'qualification':'locked module tested, not raw archive run'}),r['id']))
 conn.commit()

def export(conn,records,hybrids,flow,interop,legacy,seed):
 totals=Counter(x['role'] for x in records)
 meta={'schema':'ripple-forest-alpha/1','version':'1.3.0','sourceCount':len(records),'roleCounts':totals,'hybridsStaged':len(hybrids),'transportStudies':96,'integrity':{'assets':verify_assets(conn),'ledger':ledger_verify(conn)},'interopPass':interop['passed'],'legacySuites':{s['suite']:s['status'] for s in legacy},'scope':'archived source and tested subset; not autonomous cross-reading all programs; no cloud deployment'}
 bundle={'meta':meta,'species':records,'hybrids':hybrids,'testedSeed':seed,'flow':flow,'interop':interop,'legacy':legacy,'sources':['https://pmc.ncbi.nlm.nih.gov/articles/PMC11687498/','https://pmc.ncbi.nlm.nih.gov/articles/PMC11995700/','https://snakemake.readthedocs.io/en/latest/executing/provenance.html','https://www.sqlite.org/foreignkeys.html']}
 DATA.mkdir(exist_ok=True);(DATA/'forest.json').write_text(json.dumps(bundle,indent=2));
 with (DATA/'species.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=['id','name','family','role','sha256','bytes','members','integrity']);w.writeheader();w.writerows({k:r[k] for k in w.fieldnames} for r in records)
 return bundle

def build():
 DATA.mkdir(exist_ok=True);db=DATA/'forest.sqlite'
 if db.exists():db.unlink()
 c=connect(db);records=build_registry(c);hybrids=hybrid_records(c);flow=run_flow_trials(c);interop=run_interop(c);legacy=run_legacy_tests(c);update_execution_evidence(c,records,legacy,interop);seed=register_tested_seed(c,interop);bundle=export(c,records,hybrids,flow,interop,legacy,seed)
 from cross_research import cross as cross_archive_study
 crossdata=cross_archive_study();event(c,'static_cross_review',{'archiveCount':crossdata['archiveCount'],'codeFiles':crossdata['readableCodeFiles'],'comparedPairs':crossdata['pairwiseTotal']});c.commit();bundle['meta']['integrity']['ledger']=ledger_verify(c);bundle['crossResearch']={k:v for k,v in crossdata.items() if k!='archiveIndex'};(DATA/'forest.json').write_text(json.dumps(bundle,indent=2))
 print(json.dumps({'archives':len(records),'hybrids':len(hybrids),'flow':flow,'interop':interop['passed'],'legacy':[(x['suite'],x['status']) for x in legacy],'integrity':bundle['meta']['integrity']},indent=2))
 c.close();return bundle

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('command',choices=['build','verify','flow'],nargs='?',default='build');args=p.parse_args()
 if args.command=='build':build()
 elif args.command=='flow':print(S(graph_flow()))
 elif args.command=='verify':
  c=connect(DATA/'forest.sqlite');a=verify_assets(c);b=ledger_verify(c);print('archive:',a,'ledger:',b);sys.exit(0 if a and b else 1)
