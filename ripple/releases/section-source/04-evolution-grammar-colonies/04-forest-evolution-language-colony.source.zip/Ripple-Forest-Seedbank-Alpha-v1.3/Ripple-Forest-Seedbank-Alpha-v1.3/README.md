# Ripple Forest Seedbank — Alpha 1.3

**Status: executable research software + immutable source archive. Not an intelligent organism, biological fungus, or continuously running cloud service.**

The forest is a content-addressed source seedbank covering **27 distinct ZIP archive byte sequences** recovered from this user's Ripple library and workspaces. The distinction matters: separate byte hashes do not prove 27 unique algorithms or biological species; some archives contain overlapping historical work. The package includes exact archive bytes rather than regenerating the past.

The forest places each archive in an engineering analogy to fungal resource networks: inoculum/source kernel, sensory hyphal tip, signal transducer, spatial explorer, transport/mycelium, regulator, memory, and external interface. A scientific analogy is NOT evidence that electrical fungal communication, consciousness or biological genetics were replicated.

## Run locally (no installation and no subscriptions)

With **Python 3.10+**, **Node.js 22+** for the cross-module signal experiment:

```bash
python src/forest.py build
python -m unittest discover -s tests -v
python src/forest.py verify
python src/build_dashboard.py
```

Open `Ripple-Forest-Alpha-v1.3.html` in your browser. The standalone HTML displays saved, actually computed experiments, not a cloud job or future extrapolation. Python and Node.js need not run to view the page.

On Windows use `py -3 src/forest.py build`, `py -3 -m unittest discover -s tests -v` and `py -3 src/build_dashboard.py`. To run the forest without all ancestor repositories locally, the included `archive/` ZIP corpus and `data/source_index.json` suffice. Set `RIPPLE_FOREST_ARCHIVES_ONLY=1` to use solely the bundled originals. The six additional regression runs will be marked `SKIPPED_MISSING` if separately unpacked original working trees are unavailable; this is not a test pass.

**No file outside this Alpha directory is changed by the forest.** Archive inputs are CRC-checked and SHA-256 checked. Archive member names are inspected but archives are never auto-extracted or executed. Trusted original modules used in one test are vendored *byte-identical* in `vendor/`. All active-source additions belong in `src/`; sources are not modified.

## What actually ran in the creating environment

- 27 unique archive SHA-256 values indexed into real SQLite tables with foreign keys and chained experiment records.
- 8 **staged** hybrid hypotheses with two actual parent archive identities and a SHA-256 digital marker. No hypothesis is promoted or executed just because it exists.
- 96 simulated resource-network trials (12 seeds × 4 transport policies × blocked/unblocked topology), comparing isolation, diffusion, adaptive flow and faster broadcasting. The total conserved synthetic resource is 90 units.
- A real, executable Node interoperability test importing **v0.6 photoreceptor**, **v0.7 quaternary signal encoder**, and **v1.2 inherited sensory maths**. Five synthetic lighting scenarios are sent through the same chain. Difference in encodings is *not* accuracy unless independently measured against ground truth.
- Six allowlisted older Node.js test suites executed from their original on-disk working trees, with their results and errors recorded. Other components are inventoried but not falsely marked as running.
- 25 new Python safety/integrity/transport tests, after one corrected floating-point tolerance failure.

The `forest.sqlite` database and `forest.json` mirror each other for human and programmatic inspection; archive content hashes are independent from hash-chained experiment events. **No hashes alone authenticate file origin** without a separately trusted reference or signature.

## Cloud / outsourced compute

`.github/workflows/forest_manual.yml` is a manual GitHub Actions recipe: GitHub checkout, Python/Node setup, rebuild and test, produce downloadable research artifacts. It is **not scheduled, not installed in your GitHub account, and not deployed** by this package. The local ZIP includes all archived sources; repository size and provider limits should be checked before uploading. See `docs/CLOUD_DEPLOYMENT.md`.

The workflow deliberately avoids posting to public sites, invoking connected services, interpreting untrusted downloaded code or automatically installing third-party agent models. GitHub Actions pricing/quotas are subject to your own account plan and current platform terms.

## Research classification

- **Verified source integrity:** exact file digests, ZIP CRC checks, DB references, event ledger (local host).
- **Executable integration:** tested original JS modules with **synthetic RGB signals**, not camera or fungus electrophysiology.
- **Numerical simulation:** resource diffusion/distribution and digital hybrid features; assumptions and policies are specified in source.
- **Proposed:** other cross-family hybrids, autonomous scientific research, physical senses, real cloud operation, self-updating unrestricted JavaScript.
- **Not established:** self-awareness, general intelligence, long-term autonomy, spontaneous biological emergence, a hardware efficiency advantage.

## Contents

- `src/forest.py`: archive indexing, database, mutation contract staging, transport experiments, regression runner and ledger verification.
- `src/interop.mjs`: real photoreceptor → color-weight → quaternary integration experiment.
- `vendor/`: original tested software modules, byte-identical copies from Alpha v1.2.
- `archive/`: immutable original ZIP archive bytes identified by SHA-256 prefixes.
- `data/source_index.json`: exact digest ↔ original archive name mapping.
- `data/forest.sqlite`: SQLite record of archives, species, hybrid candidates, studies and experiment ledger.
- `data/transport_trials.json`, `data/interop.json`, `data/legacy_tests.json`: executed evidence.
- `docs/`: technical requirements, source provenance, fungal biology mapping and failure ledger.

**Source research (external):** [Fricker et al., *The Mycelium as a Network*](https://pmc.ncbi.nlm.nih.gov/articles/PMC11687498/); [FEMS Review of fungal electrical signaling](https://pmc.ncbi.nlm.nih.gov/articles/PMC11995700/); [SQLite foreign keys](https://sqlite.org/foreignkeys.html); [Snakemake provenance](https://snakemake.readthedocs.io/en/latest/executing/provenance.html).

**Licensing:** New original forest indexing/experiment code is CC0-1.0. All preserved source archives retain their original respective notices/licenses. Do not assume ownership or permission to redistribute every included third-party component on another website based solely on this statement.

## Alpha 1.3 cross-study extension

The static research engine `src/cross_research.py` additionally reviewed **321 readable source files** inside the 27 archives (JavaScript, TypeScript, Python and Lua). It identified **210 unique code-content SHA-256 hashes**, **54 code-file hashes reused by different source archives**, and evaluated **all 351 archive pairs** for shared static indicators. **305 pairs** share at least one declared function/class name or byte-identical source file. These overlaps expose potential inheritance and interface candidates, *not* working algorithms or meaningful performance gains. Read `data/cross_research.json` and `data/code_index.json` for exact, reproducible evidence.

The first explicitly executed digital composite is **Forest-S01**, defined in `data/forest.json` → `testedSeed`. Its three parent files were verified byte-for-byte against source archives (`data/vendor_provenance.json`). A schema-bounded RGB weight vector and four-state threshold/dwell parameters form its reproducible digital marker. Its status is `TESTED_SYNTHETIC_ONLY`; it does not have an independent reasoning or perception subsystem. All eight additional recipe crosses remain unexecuted staged hypotheses.

The final new Python test suite contains **31 passing checks**, supplemented by six separately passing older Node test suites and mobile/desktop Chromium replay checks. Detailed results are in `data/`.
