import importlib.util, json, os, sqlite3, tempfile, unittest, zipfile
from pathlib import Path
F=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('forest',F/'src/forest.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
class ForestTest(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  if not (F/'data/forest.sqlite').exists():mod.build()
  cls.conn=mod.connect(F/'data/forest.sqlite')
 @classmethod
 def tearDownClass(cls):cls.conn.close()
 def test_asset_integrity(self):self.assertTrue(mod.verify_assets(self.conn))
 def test_ledger(self):self.assertTrue(mod.ledger_verify(self.conn))
 def test_deduplication(self):self.assertEqual(self.conn.execute('SELECT COUNT(*) FROM artifacts').fetchone()[0],len(set(x[0] for x in mod.source_candidates())))
 def test_members_valid(self):self.assertEqual(self.conn.execute('SELECT COUNT(*) FROM artifacts WHERE valid=0').fetchone()[0],0)
 def test_gene_continuity(self):
  for r in self.conn.execute('SELECT gene_json,marker_sha FROM hybrids'):
   self.assertEqual(len(r[1]),64);self.assertIsInstance(json.loads(r[0]),dict)
 def test_cross_reference(self):
  self.assertEqual(self.conn.execute('PRAGMA foreign_key_check').fetchall(),[])
 def test_no_promoted_research(self):self.assertEqual(self.conn.execute("SELECT COUNT(*) FROM hybrids WHERE status!='STAGED_RESEARCH_ONLY'").fetchone()[0],0)
 def test_asset_tamper(self):
  sha=self.conn.execute('SELECT sha FROM artifacts LIMIT 1').fetchone()[0]
  self.assertNotEqual(mod.H((mod.ARCHIVE/(sha[:16]+'.zip')).read_bytes()+b'X'),sha)
 def test_event_tamper(self):
  with tempfile.NamedTemporaryFile(suffix='.sqlite') as tmp:
   dest=mod.connect(tmp.name);self.conn.backup(dest)
   dest.execute("UPDATE events SET payload_json='{}' WHERE seq=(SELECT MIN(seq) FROM events)");dest.commit()
   self.assertFalse(mod.ledger_verify(dest));dest.close()
 def test_stock_conservation_96(self):
  data=json.loads((F/'data/transport_trials.json').read_text());self.assertEqual(len(data),96)
  for x in data:self.assertAlmostEqual(x['totalInitial'],x['totalFinal'],places=8)
 def test_no_negative_stock(self):
  for x in json.loads((F/'data/transport_trials.json').read_text()):self.assertGreaterEqual(x['minStock'],-1e-9)
 def test_no_flow_stays_local(self):
  r=mod.graph_flow(mode='none');self.assertEqual(r['covered'],1)
 def test_diffusion_spreads(self):self.assertGreater(mod.graph_flow(mode='diffusion')['covered'],1)
 def test_adaptive_flow(self):self.assertGreater(mod.graph_flow(mode='adaptive')['uniformity'],0)
 def test_blockage_changes_edge(self):
  x=mod.graph_flow(mode='diffusion',blocked=True);y=mod.graph_flow(mode='diffusion',blocked=False)
  self.assertAlmostEqual(x['totalFinal'],y['totalFinal'],places=9)
 def test_invalid_mode(self):
  with self.assertRaises(ValueError):mod.graph_flow(mode='unsafe')
 def test_provenance(self):
  v=json.loads((F/'data/forest.json').read_text());self.assertTrue(v['meta']['interopPass']);self.assertGreaterEqual(len(v['species']),20)
 def test_mutation_requires_staging(self):
  for x in json.loads((F/'data/forest.json').read_text())['hybrids']:self.assertEqual(x['status'],'STAGED_RESEARCH_ONLY')
 def test_independent_archives(self):
  rows=self.conn.execute('SELECT COUNT(*),COUNT(DISTINCT sha) FROM artifacts').fetchone();self.assertEqual(rows[0],rows[1])
 def test_untrusted_archive_no_extraction(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'malicious.zip'
   with zipfile.ZipFile(p,'w') as z:z.writestr('../danger.txt','do not extract')
   infos,total=mod.safe_audit(p)
   self.assertEqual(total,14);self.assertFalse((Path(td).parent/'danger.txt').exists())
 def test_reproducible_transport(self):self.assertEqual(mod.graph_flow(seed=7),mod.graph_flow(seed=7))
 def test_independent_seed_ablation(self):self.assertAlmostEqual(mod.graph_flow(seed=7)['totalFinal'],90)
 def test_real_js_modules_integration(self):
  d=json.loads((F/'data/interop.json').read_text());self.assertTrue(d['passed']);self.assertEqual(len(d['scenarios']),5)
 def test_cross_research_all_sources(self):
  d=json.loads((F/'data/cross_research.json').read_text());self.assertEqual(d['archiveCount'],27);self.assertGreater(d['readableCodeFiles'],100)
 def test_cross_research_static_only(self):
  d=json.loads((F/'data/cross_research.json').read_text());self.assertIn('NOT executable',d['classification'])
 def test_duplicate_content_detected(self):
  d=json.loads((F/'data/cross_research.json').read_text());self.assertGreater(d['duplicateCodeDigests'],0)
 def test_code_index_fks(self):self.assertEqual(self.conn.execute('PRAGMA foreign_key_check').fetchall(),[])
 def test_first_composite_seed(self):
  d=json.loads((F/'data/forest.json').read_text())
  self.assertEqual(d['testedSeed']['status'],'TESTED_SYNTHETIC_ONLY')
  self.assertEqual(len(d['testedSeed']['parents']),3)
 def test_first_composite_seed_integrity(self):
  count=self.conn.execute("SELECT COUNT(*) FROM specimens WHERE evaluation_status='TESTED_SYNTHETIC_ONLY'").fetchone()[0];self.assertEqual(count,1)
 def test_no_automatic_code_promotion(self):
  d=json.loads((F/'data/forest.json').read_text());self.assertFalse(any(r['status']=='DEPLOYED' for r in d['hybrids']))
 def test_ledger_sequence(self):
  rows=self.conn.execute('SELECT seq FROM events ORDER BY seq').fetchall();self.assertEqual([r[0] for r in rows],list(range(1,len(rows)+1)))
if __name__=='__main__':unittest.main()
