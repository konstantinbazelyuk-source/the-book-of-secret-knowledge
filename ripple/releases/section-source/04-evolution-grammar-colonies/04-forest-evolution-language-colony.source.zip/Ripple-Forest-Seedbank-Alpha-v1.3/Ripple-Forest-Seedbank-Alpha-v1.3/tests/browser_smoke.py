"""Actually opens the offline HTML in Chromium and exercises catalog controls."""
from pathlib import Path
import json
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
RESULTS=[]
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for name,size in [('desktop',{'width':1366,'height':850}),('mobile',{'width':390,'height':844})]:
  page=b.new_page(viewport=size,device_scale_factor=1)
  errs=[];page.on('pageerror',lambda err:errs.append(str(err)))
  # file:// navigation is blocked by this sandbox; render the identical static HTML bytes.
  page.set_content((ROOT/'Ripple-Forest-Alpha-v1.3.html').read_text(),wait_until='load')
  assert page.locator('#metrics .metric').count()==4
  assert page.locator('#entryList button').count()==27
  assert page.locator('#hybridRows tr').count()==8
  assert page.locator('#flowRows tr').count()==4
  page.locator('#entryList button').first.click()
  assert page.locator('#detail .kv').count()>=7
  page.locator('#search').fill('photoreceptor')
  assert 1<=page.locator('#entryList button').count()<27
  page.locator('#search').fill('')
  page.locator('#hybridRows button').first.click()
  assert page.locator('#hybridDetail pre').count()==1
  page.screenshot(path=str(ROOT/'data'/f'browser_{name}.png'),full_page=True)
  overflow=page.evaluate('document.documentElement.scrollWidth > innerWidth+1')
  RESULTS.append({'viewport':name,'archives':27,'hybrids':8,'consoleErrors':errs,'horizontalOverflow':overflow})
  assert not errs, errs
  assert not overflow
  page.close()
 b.close()
(ROOT/'data/browser_checks.json').write_text(json.dumps(RESULTS,indent=2));print(json.dumps(RESULTS,indent=2))
