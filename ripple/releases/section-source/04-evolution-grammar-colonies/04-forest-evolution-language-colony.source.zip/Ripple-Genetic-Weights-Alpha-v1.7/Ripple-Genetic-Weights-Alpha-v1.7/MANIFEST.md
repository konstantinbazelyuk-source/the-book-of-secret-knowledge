# Ripple Genetic Weights Alpha v1.7 — release integrity

**Exact package includes the immutable reference sources, synthetic fixtures, executable code, test records and failure study.**

## Exact validated source checksums

```json
{
  "neuron_sha256": "d75d4208e92f19623b127615bd52b4002e85d2c0a59b76471764b55a24294210",
  "locked_sensor_sha256": "9c1879f6bc024e564e5e25b0294ac62b34d67aafffe26f9ddfae52675d66f695",
  "physics_sha256": "910bab2c583fd50c5250226f8bd81b9c477c5f6de921be7892a4575bacd17b51"
}
```

## Executed counters

```json
{
  "genetic_mutation_evaluations": 256,
  "synthetic_optical_cases": 540,
  "fresh_optical_cases": 180,
  "composition_positive_controls": 108,
  "old_mapping_count": 328,
  "new_mapping_count": 1910,
  "parent_regression_tests": 24,
  "new_node_tests": 12,
  "new_python_tests": 21,
  "graphical_browser_viewports": 2
}
```

Do not treat a passing unit test as evidence of hardware perception or general intelligence. No cloud runner, device, account, or public repo was deployed. SHA256SUMS.txt lists all release members other than itself and this manifest.
