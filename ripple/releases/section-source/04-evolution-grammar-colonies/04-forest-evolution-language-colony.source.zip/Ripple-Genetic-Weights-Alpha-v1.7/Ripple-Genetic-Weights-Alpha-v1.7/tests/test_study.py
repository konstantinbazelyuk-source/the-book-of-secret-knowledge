import sys,unittest,hashlib,json
from pathlib import Path
import numpy as np
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'src'))
import study
class GeneticTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.cases,cls.scores,cls.quality=study.cache()
  cls.g=study.base_genome()
 def test_training_split(self):
  self.assertEqual(len([c for c in self.cases if c['seed'] in (111,222)]),180)
 def test_reserved_split(self):
  self.assertEqual(len([c for c in self.cases if c['seed'] in (777,888)]),180)
 def test_probability_normalized(self):
  for v in [-100,-1,0,1,100]:self.assertAlmostEqual(float(study.bit_probs([v]*4).sum()),1,10)
 def test_no_nan(self):self.assertTrue(np.isfinite(self.scores).all())
 def test_original_core_checksum(self):
  target=P/'sources/v01_ripple_core_LOCKED.cjs';self.assertEqual(hashlib.sha256(target.read_bytes()).hexdigest(),'d75d4208e92f19623b127615bd52b4002e85d2c0a59b76471764b55a24294210')
 def test_modular_code_length(self):self.assertEqual(study.OUT.shape,(328,16))
 def test_genome_bounded(self):
  g=study.mutate(self.g,__import__('random').Random(3));self.assertTrue(all(-1.5<=x<=1.5 for x in g['family']));self.assertTrue(0<=g['min_quality']<=.97)
 def test_phase_rotation_not_physical_light(self):
  x=np.array([1.,0.,0.,0.]);self.assertNotEqual(list(study.xform(x,'phase_plus')),list(study.xform(x,'fixed')))
 def test_zero_weight_ternary(self):self.assertAlmostEqual(float(study.xform([.001,0,-5,2],'ternary')[1]),0)
 def test_inference_not_read_test_labels(self):
  c=self.cases[0];p,a,info=study.infer(self.scores[0],self.quality[0],self.g)
  modified=json.loads(json.dumps(c));modified['examples'][10]['y_true']^=15
  p2,a2,info2=study.infer(self.scores[0],self.quality[0],self.g)
  self.assertEqual((p,a,info),(p2,a2,info2))
 def test_runtime_bound(self):
  g=self.g.copy();g['min_quality']=1.;_,a,_=study.infer(self.scores[0],self.quality[0],g);self.assertFalse(a)
 def test_reproducible_genome_id(self):self.assertEqual(study.sha(self.g),study.sha(json.loads(json.dumps(self.g))))
 def test_results_maintain_baseline(self):
  x=json.loads((P/'data/research.json').read_text());self.assertEqual(x['splits']['fresh'],180)
 def test_parallel_not_claimed(self):
  a=json.loads((P/'data/research.json').read_text())['results'];self.assertEqual({k:v for k,v in a['development_selected']['fresh'].items() if k!='rows'}, {k:v for k,v in a['serial_same_math']['fresh'].items() if k!='rows'})
 def test_original_data_not_overwritten(self):
  d=json.loads((P/'data/cases.json').read_text());self.assertEqual(len(d['cases']),360)
if __name__=='__main__':unittest.main()
