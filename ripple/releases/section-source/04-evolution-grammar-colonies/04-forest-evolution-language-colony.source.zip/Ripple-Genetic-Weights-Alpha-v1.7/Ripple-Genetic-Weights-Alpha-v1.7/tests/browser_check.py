from pathlib import Path
from playwright.sync_api import sync_playwright
import json
R=Path(__file__).resolve().parents[1]
errors=[];result={}
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for w,h,label in [(1280,920,'desktop'),(390,844,'mobile')]:
  page=b.new_page(viewport={'width':w,'height':h},device_scale_factor=1)
  page.on('pageerror',lambda e:errors.append(str(e)))
  html=(R/'Ripple-Genetic-Weights-Alpha-v1.7.html').read_text()
  page.goto('about:blank');page.set_content(html,wait_until='load')
  page.locator('#case').select_option('add3(rotate2(x))');page.locator('#model').select_option('composed')
  assert page.locator('#decision').inner_text()!='—'
  assert 'SHA-256' in page.locator('#marker').inner_text()
  assert page.locator('#comp').inner_text().find('Composed')>=0
  assert page.locator('#bars .bar').count()>=5
  assert page.locator('#genchart polyline').count()==1
  page.locator('#model').select_option('parent')
  assert page.locator('#program').inner_text()!=''
  overflow=page.evaluate('document.documentElement.scrollWidth>window.innerWidth+1')
  assert not overflow,(w,page.evaluate('document.documentElement.scrollWidth'))
  if label=='mobile':page.screenshot(path=str(R/'charts/mobile_verified.png'),full_page=True)
  if label=='desktop':page.screenshot(path=str(R/'charts/desktop_verified.png'),full_page=True)
  result[label]={'viewport':w,'errors':0,'overflow':overflow,'cases':page.locator('#case option').count()}
  page.close()
 b.close()
assert not errors,errors
(R/'data/browser_result.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))
