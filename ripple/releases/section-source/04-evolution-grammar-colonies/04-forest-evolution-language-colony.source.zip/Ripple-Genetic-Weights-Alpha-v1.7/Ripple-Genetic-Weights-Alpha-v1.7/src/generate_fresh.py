"""Produce independent synthetic optical cases, using unchanged Ripple v1.4 physics.
Seeds 777/888 were not used in v1.6 results. Do not regenerate after selection.
"""
from pathlib import Path
import importlib.util,sys,json,hashlib
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
# Source dependency copied, not modified. Preserve its exact formula.
MODULE=ROOT/'sources/v16_generate_cases_LOCKED.py'
sys.path.insert(0,str(ROOT/'sources'))
spec=importlib.util.spec_from_file_location('g16',MODULE)
g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
def build(seeds=(777,888)):
 cases=[]
 for kind,fn in g.TRUTHS.items():
  for seed in seeds:
   rng=np.random.default_rng(seed*83041+sum(map(ord,kind)))
   order=list(map(int,rng.permutation(16)))
   for photons in (6,20,80):
    for condition in ('matched','phase_shift','contrast_collapse'):
     rng2=np.random.default_rng(seed*7177+photons*61+sum(map(ord,kind))*3+sum(map(ord,condition)))
     ex=[]
     for i,x in enumerate(order):
      y=g.UNKNOWN[x] if fn is None else fn(x)
      ex.append({'rx':g.tx(x,photons,rng2,condition),'ry':g.tx(y,photons,rng2,condition),'split':'train' if i<10 else 'test','x_true':x,'y_true':y})
     cases.append({'id':f'{kind}_{seed}_{photons}_{condition}','kind':kind,'seed':seed,'photons_per_bit':photons,'condition':condition,'examples':ex})
 target=ROOT/'data/fresh_777_888.json'
 data={'schema':'ripple-v17-fresh/1','generation':'unchanged v1.6 optical case construction, independent new seeds','cases':cases}
 target.write_text(json.dumps(data,separators=(',',':')))
 print('FRESH',len(cases),'SHA256',hashlib.sha256(target.read_bytes()).hexdigest())
if __name__=='__main__':build()
