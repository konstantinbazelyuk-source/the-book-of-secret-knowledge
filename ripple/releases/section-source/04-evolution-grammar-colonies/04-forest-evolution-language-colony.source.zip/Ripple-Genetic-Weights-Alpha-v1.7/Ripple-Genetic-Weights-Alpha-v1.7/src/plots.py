from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[1]
a=json.loads((R/'data/research.json').read_text());b=json.loads((R/'data/composition_results.json').read_text())
names=['control_fixed','training_champion','development_selected','fixed_ternary','fixed_phase_plus','fixed_phase_minus','fixed_context']
vals=[]
for n in names:
 d=a['results'][n]['fresh'];vals.append([100*d['coverage'],100*(d['accepted_accuracy'] or 0)])
fig,ax=plt.subplots(figsize=(9.3,4.5));xx=range(len(names));ax.bar([x-.18 for x in xx],[x[0] for x in vals],width=.35,label='Task acceptance %');ax.bar([x+.18 for x in xx],[x[1] for x in vals],width=.35,label='Accepted-output accuracy %');ax.set_xticks(list(xx),[x.replace('fixed_','').replace('_','\n') for x in names],rotation=0);ax.set_ylabel('Percent');ax.set_ylim(0,105);ax.legend();ax.set_title('Ripple genetic weights: separately reported accuracy and coverage');fig.tight_layout();fig.savefig(R/'charts/genetic_weight_tradeoff.png',dpi=140);plt.close(fig)
fig,ax=plt.subplots(figsize=(8,4.5));g=b['groups'];ax.bar(['original grammar','recombined grammar'],[100*g[x]['acceptedCorrect']/g[x]['acceptedOutputs'] for x in ['parent_ripple','composed_ripple']]);ax.set_ylabel('Accuracy on accepted held-out outputs (%)');ax.set_ylim(0,103);ax.set_title('New expressions improve performance on composition-selected tasks');fig.tight_layout();fig.savefig(R/'charts/composition_positive_control.png',dpi=140);plt.close(fig)
print('Plots ready')
