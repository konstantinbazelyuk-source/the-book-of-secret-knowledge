"""Create deterministic ZIP and integrity manifest, with release files as-is."""
from pathlib import Path
import hashlib,zipfile,json
R=Path(__file__).resolve().parents[1];OUT=R.parent/(R.name+'.zip')
for x in R.rglob('__pycache__'):
 import shutil;shutil.rmtree(x)
for x in R.rglob('*.pyc'):x.unlink()
files=sorted(x for x in R.rglob('*') if x.is_file() and x.name not in ('MANIFEST.md','SHA256SUMS.txt') and '.git' not in x.parts)
checks=[(str(x.relative_to(R)).replace('\\','/'),hashlib.sha256(x.read_bytes()).hexdigest()) for x in files]
(R/'SHA256SUMS.txt').write_text(''.join(f'{digest}  {name}\n' for name,digest in checks))
verified={'neuron_sha256':'d75d4208e92f19623b127615bd52b4002e85d2c0a59b76471764b55a24294210','locked_sensor_sha256':'9c1879f6bc024e564e5e25b0294ac62b34d67aafffe26f9ddfae52675d66f695','physics_sha256':'910bab2c583fd50c5250226f8bd81b9c477c5f6de921be7892a4575bacd17b51'}
counts={'genetic_mutation_evaluations':256,'synthetic_optical_cases':540,'fresh_optical_cases':180,'composition_positive_controls':108,'old_mapping_count':328,'new_mapping_count':1910,'parent_regression_tests':24,'new_node_tests':12,'new_python_tests':21,'graphical_browser_viewports':2}
(R/'MANIFEST.md').write_text('# Ripple Genetic Weights Alpha v1.7 — release integrity\n\n**Exact package includes the immutable reference sources, synthetic fixtures, executable code, test records and failure study.**\n\n## Exact validated source checksums\n\n```json\n'+json.dumps(verified,indent=2)+'\n```\n\n## Executed counters\n\n```json\n'+json.dumps(counts,indent=2)+'\n```\n\nDo not treat a passing unit test as evidence of hardware perception or general intelligence. No cloud runner, device, account, or public repo was deployed. SHA256SUMS.txt lists all release members other than itself and this manifest.\n')
allfiles=sorted(x for x in R.rglob('*') if x.is_file() and '__pycache__' not in x.parts)
with zipfile.ZipFile(OUT,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for f in allfiles:z.write(f,str(Path(R.name)/f.relative_to(R)))
with zipfile.ZipFile(OUT) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(allfiles)
 print('ZIP',OUT,OUT.stat().st_size,'BYTES',len(allfiles),'files sha256',hashlib.sha256(OUT.read_bytes()).hexdigest())
