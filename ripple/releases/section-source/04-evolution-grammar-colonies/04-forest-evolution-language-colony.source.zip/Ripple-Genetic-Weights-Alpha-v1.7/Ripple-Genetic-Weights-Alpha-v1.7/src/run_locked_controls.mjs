/** v1.6 exact comparator. No changes to the imported program. */
import fs from 'node:fs';
import {createRequire} from 'node:module';
import {analyze} from '../sources/engine.mjs';
const input=JSON.parse(fs.readFileSync(new URL('../data/fresh_777_888.json',import.meta.url),'utf-8')).cases;
for(const withColony of [false,true]){
 let accepted=0,correct=0,proposed=0,spawns=0,counts={};
 for(const c of input){const r=analyze(c,{mode:'expanded',withColony,minReliability:.0});
  if(r.decision==='SUPPORTED'){accepted++;correct+=r.correct;} proposed+=r.correct;spawns+=r.births;counts[r.decision]=(counts[r.decision]||0)+1;
 }
 const out={kind:withColony?'v16_real_LIF_colony':'v16_serial_same_math',cases:input.length,accepted,acceptedCorrect:correct,acceptedOutputs:6*accepted,provisionalCorrect:proposed,totalOutputs:6*input.length,spawns,statuses:counts};
 console.log(JSON.stringify(out));
 fs.writeFileSync(new URL(`../data/${out.kind}.json`,import.meta.url),JSON.stringify(out,null,2));
}
