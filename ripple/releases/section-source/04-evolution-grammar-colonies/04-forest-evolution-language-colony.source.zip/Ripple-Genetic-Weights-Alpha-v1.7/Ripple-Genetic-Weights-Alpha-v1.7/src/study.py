"""Ripple Alpha v1.7: bounded genotype evolution for evidence weights and program priors.
No eval, no dynamic code execution, no hidden evaluator labels in per-task inference.
The *meta-training* dataset contains solved training tasks; validation/final seeds are never used to mutate genes.
"""
from __future__ import annotations
import argparse,hashlib,json,math,random,time
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
GENES=['fixed','cold','hot','ternary','phase_plus','phase_minus','context']
EXPRESSIONS=json.loads((ROOT/'data/grammar_locked.json').read_text())
OUT=np.asarray([x['outputs'] for x in EXPRESSIONS],dtype=np.int64)
FAMS=sorted(set(x['family'] for x in EXPRESSIONS))
FAMIDX=np.asarray([FAMS.index(x['family']) for x in EXPRESSIONS],dtype=int)
COMPLEX=np.asarray([x['complexity'] for x in EXPRESSIONS],dtype=float)
EPS=1e-12

def sha(obj):return hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def sigmoid(x):return 1/(1+np.exp(-np.clip(x,-35,35)))
def xform(llr,mode):
 a=np.array(llr,dtype=float)
 if mode=='cold':return a*.62
 if mode=='hot':return a*1.45
 if mode=='ternary':return np.sign(a)*2.1
 # Software phasor rotation of neighboring log-likelihood signals: no physical phase measurement.
 if mode in ('phase_plus','phase_minus'):
  phi=.23 if mode=='phase_plus' else -.23
  return np.cos(phi)*a - np.sin(phi)*np.roll(a,1)
 if mode=='context':
  magnitude=float(np.mean(np.abs(a)))
  gain=.65 + .65/(1+math.exp(-max(-20,min(20,magnitude-2.2))))
  return a*gain
 return a

def bit_probs(llr):
 p=sigmoid(llr)
 bit=((np.arange(16)[:,None]>>(3-np.arange(4)[None,:]))&1).astype(bool)
 return np.prod(np.where(bit,p[None,:],1-p[None,:]),axis=1)

def score_case(case):
 scores=np.zeros((len(GENES),len(EXPRESSIONS)),dtype=np.float64)
 maxconf=[]
 train=case['examples'][:10]
 for vi,mode in enumerate(GENES):
  q=0.0
  for row in train:
   rx=xform(row['rx']['llr'],mode);ry=xform(row['ry']['llr'],mode)
   xp=bit_probs(rx);yp=bit_probs(ry)
   # Each candidate is a 16-element lookup table; marginalize uncertain transmitted inputs.
   values=np.sum(xp[None,:]*yp[OUT],axis=1)
   scores[vi]+=np.log(np.maximum(values,1e-300))
   if mode=='fixed':q+=float(np.max(xp)*np.max(yp))
  if mode=='fixed':maxconf=q/len(train)
 return scores,float(maxconf)

def fixture():
 cases=[]
 for f in ['cases.json','fresh_777_888.json']:
  cases.extend(json.loads((ROOT/'data'/f).read_text())['cases'])
 return cases

def cache():
 cases=fixture()
 p=ROOT/'data/score_cache.npz'
 fp=sha({'cases_sha':hashlib.sha256((ROOT/'data/cases.json').read_bytes()).hexdigest(), 'fresh_sha':hashlib.sha256((ROOT/'data/fresh_777_888.json').read_bytes()).hexdigest(),'math_source_sha':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'modes':GENES,'grammar':sha(EXPRESSIONS)})
 if p.exists():
  a=np.load(p,allow_pickle=False)
  if str(a['fingerprint'])==fp:return cases,a['scores'],a['quality']
 scores=np.zeros((len(cases),len(GENES),len(EXPRESSIONS)),dtype=np.float64)
 quality=np.zeros(len(cases))
 t=time.monotonic()
 for i,c in enumerate(cases):
  scores[i],quality[i]=score_case(c)
  if i and i%90==0: print('SCORED',i,'/',len(cases),'elapsed',round(time.monotonic()-t,2),flush=True)
 np.savez_compressed(p,scores=scores,quality=quality,fingerprint=fp)
 return cases,scores,quality

def base_genome():
 return {'mode':0,'family':[0.0]*len(FAMS),'complexity':.12,'margin':1.5,'min_gain':4.0,'min_quality':0.0}
def normalize(g):
 return {'mode':int(g['mode'])%len(GENES),'family':[round(float(np.clip(v,-1.5,1.5)),4) for v in g['family']],
         'complexity':round(float(np.clip(g['complexity'],0,.7)),4),
         'margin':round(float(np.clip(g['margin'],.2,6)),4),
         'min_gain':round(float(np.clip(g['min_gain'],0,12)),4),
         'min_quality':round(float(np.clip(g['min_quality'],0,.97)),4)}

def infer(scores,q,g):
 rank=scores[g['mode']] - float(g['complexity'])*COMPLEX + np.asarray(g['family'])[FAMIDX]
 # Deterministic stable ties, which can occur when different expressions have same outputs.
 ix=np.argsort(-rank,kind='stable')[:2]
 winner=int(ix[0]); runner=int(ix[1]); delta=float(rank[winner]-rank[runner])
 gain=float(scores[g['mode'],winner]+10*math.log(16))
 accepted=bool(q>=g['min_quality'] and delta>=g['margin'] and gain>=g['min_gain'])
 return winner,accepted,{'margin':round(delta,4),'gain':round(gain,4),'quality':round(q,4),'runner':runner}

def benchmark(cases,scores,quality,indices,g,detail=False):
 ncorrect=0; naccepted=0; acceptedCorrect=0; eligible=0; correctcases=0
 results=[]
 for idx in indices:
  c=cases[idx]; p,accepted,info=infer(scores[idx],quality[idx],g)
  truth=c['examples'][10:]; outputs=OUT[p]
  n=int(sum(int(outputs[v['x_true']]==v['y_true']) for v in truth))
  ncorrect+=n
  if accepted:
   naccepted+=1;acceptedCorrect+=n;correctcases+=int(n==6)
  eligible+=len(truth)
  if detail:results.append({'id':c['id'],'kind':c['kind'],'condition':c['condition'],'photons':c['photons_per_bit'],'seed':c['seed'],
   'decision':'SUPPORTED' if accepted else 'ABSTAIN','correct':n,'heldout':len(truth),'program':EXPRESSIONS[p]['expr'],**info})
 utility=(acceptedCorrect - 1.5*(naccepted*6-acceptedCorrect)) / max(eligible,1)
 return {'n':len(indices),'accepted':naccepted,'correct_all_provisional':ncorrect,'total_predictions':eligible,
  'accepted_correct':acceptedCorrect,'accepted_outputs':naccepted*6,'accepted_cases_all6':correctcases,
  'accepted_accuracy':(acceptedCorrect/(naccepted*6)) if naccepted else None,
  'coverage':naccepted/len(indices) if len(indices) else 0,'utility':utility,'rows':results if detail else None}

def mutate(parent,rng):
 g={**parent,'family':list(parent['family'])};typ=rng.randrange(7)
 if typ==0:g['mode']=rng.randrange(len(GENES))
 elif typ==1:g['family'][rng.randrange(len(FAMS))]+=rng.gauss(0,.4)
 elif typ==2:g['complexity']+=rng.gauss(0,.09)
 elif typ==3:g['margin']+=rng.gauss(0,.8)
 elif typ==4:g['min_gain']+=rng.gauss(0,1.2)
 elif typ==5:g['min_quality']+=rng.gauss(0,.13)
 else:
  for i in range(len(FAMS)):
   if rng.random()<.4:g['family'][i]+=rng.gauss(0,.18)
 return normalize(g)

def fit(cases,scores,quality):
 ids=lambda seeds:np.array([i for i,c in enumerate(cases) if c['seed'] in seeds],dtype=np.int64)
 tr=ids((111,222));dev=ids((333,444)); final=ids((777,888))
 rng=random.Random(20261014)
 ancestor=normalize(base_genome());history=[]
 baseline_train=benchmark(cases,scores,quality,tr,ancestor)
 base_dev=benchmark(cases,scores,quality,dev,ancestor)
 # One objective fixed in advance: corrected answers rewarded, wrong supported answers penalized,
 # abstention neutral. Diversity uses different (mode, quality bucket) cells.
 bank={};top=ancestor;topscore=baseline_train['utility']
 for generation in range(16):
  candidates=[]
  for j in range(16):
   par=top if j<9 else (rng.choice(list(bank.values()))[1] if bank else ancestor)
   cand=mutate(par,rng);metric=benchmark(cases,scores,quality,tr,cand)
   candidates.append((metric['utility'],cand,metric))
   bucket=(cand['mode'],round(cand['min_quality']*4))
   if bucket not in bank or metric['utility']>bank[bucket][0]:bank[bucket]=(metric['utility'],cand)
  candidates.sort(key=lambda x:x[0],reverse=True)
  if candidates[0][0]>topscore:topscore,top=candidates[0][:2]
  history.append({'generation':generation+1,'champion':sha(top),'train_utility':round(topscore,5),'diverse_niches':len(bank)})
 # Select among frozen TRAIN archive candidates by DEVELOPMENT, one pass only.
 pool=[ancestor,top]+[item[1] for item in bank.values()]
 unique={sha(x):x for x in pool}; ranking=[]
 for g in unique.values():
  a=benchmark(cases,scores,quality,tr,g);b=benchmark(cases,scores,quality,dev,g)
  ranking.append({'gene':g,'marker':sha(g),'train':a['utility'],'development':b['utility'],'dev_coverage':b['coverage']})
 ranking.sort(key=lambda v:(v['development'],v['dev_coverage']),reverse=True)
 winner=ranking[0]['gene']
 control=ancestor
 # Report final once, without tuning parameters further.
 modes={}
 for name,g in [('control_fixed',control),('training_champion',top),('development_selected',winner)]:
  modes[name]={'genome':g,'sha256':sha(g),'train':benchmark(cases,scores,quality,tr,g),
   'dev':benchmark(cases,scores,quality,dev,g),
   'fresh':benchmark(cases,scores,quality,final,g,True)}
 # Frozen one-off ablations: isolate optical representation, genetic family priors and abstention.
 for mi,mode in enumerate(GENES):
  g={**ancestor,'mode':mi};modes['fixed_'+mode]={'genome':g,'sha256':sha(g),'fresh':benchmark(cases,scores,quality,final,g)}
 a={**winner,'mode':0};b={**winner,'family':[0.0]*len(FAMS)}
 modes['ablate_optics']={'genome':a,'sha256':sha(a),'fresh':benchmark(cases,scores,quality,final,a)}
 modes['ablate_family']={'genome':b,'sha256':sha(b),'fresh':benchmark(cases,scores,quality,final,b)}
 # Serial with exactly the same selection mathematics: no causal advantage from adding spikes.
 modes['serial_same_math']={'genome':winner,'sha256':sha(winner),'fresh':benchmark(cases,scores,quality,final,winner)}
 report={'schema':'ripple-genetic-weights-alpha/1','status':'measured software algorithm, simulated optics',
  'source_cases':'prior v1.6 case design + fresh seeds 777/888','source_sha256':sha([x['id'] for x in cases]),
  'genome_fields':list(ancestor.keys()),'modes':GENES,'family_vocab':FAMS,
  'families_count':len(EXPRESSIONS),'splits':{'train':len(tr),'development':len(dev),'fresh':len(final)},
  'evaluation':'all inference selects program from first 10 examples; six reserved output labels used only by meta-training on seeds 111/222 and metric calculations; new 777/888 never used for selection',
  'objective':'utility=(accepted_correct-1.5*accepted_incorrect)/(all cases * 6); choose development utility, then coverage',
  'meta_search':{'generations':16,'offspring_each':16,'evaluated_mutations':256,'niches':len(bank),'tracked_history':history,'selected_on_dev':ranking[:30]},
  'results':modes}
 (ROOT/'data/research.json').write_text(json.dumps(report,indent=2))
 (ROOT/'data/genome_seedbank.json').write_text(json.dumps({'schema':'ripple-genetic-seedbank/1','selected':winner,'selected_marker':sha(winner),'top_research_genotypes':ranking[:30],'generation_history':history},indent=2))
 print('FRESH DATA / GENETIC RESULTS:')
 for name in ['control_fixed','training_champion','development_selected','ablate_optics','ablate_family']:
  r=modes[name]['fresh'];print(name,'mode',modes[name]['genome']['mode'],'utility',round(r['utility'],4),'accepted',r['accepted'],'accurate',r['accepted_accuracy'],'provisional',r['correct_all_provisional'],'/',r['total_predictions'])
 return report

def main():
 t=time.monotonic();cases,scores,q=cache();print('CACHED',scores.shape,'seconds',round(time.monotonic()-t,2),flush=True)
 report=fit(cases,scores,q)
 print('FINISHED',round(time.monotonic()-t,2),'sec','DATA_SHA',sha(report))
if __name__=='__main__':main()
