# Portable cloud execution

Use a manually invoked GitHub Actions workflow in a repository you own, after reviewing the files and any service quotas. This package has **not** been uploaded, installed or executed on a cloud service. Workflow runs Node and Python tests and recomputes only the saved experiments. No external data collection, accounts or secrets are requested.

The workflow is deliberately not scheduled and doesn't attempt to give an agent permission to edit arbitrary JavaScript, access other repositories, run unknown code, or spend paid resources. Public research was consulted for the mathematical design; the executable system remains local until you independently initiate deployment.
