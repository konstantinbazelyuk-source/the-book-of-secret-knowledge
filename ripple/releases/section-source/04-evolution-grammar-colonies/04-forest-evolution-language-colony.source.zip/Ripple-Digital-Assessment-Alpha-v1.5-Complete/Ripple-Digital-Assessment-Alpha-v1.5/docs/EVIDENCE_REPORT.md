# Evidence report — Digital Forest Alpha v1.5

## Source-derived versus implemented
- SOURCE-VERIFIED: `parents/language-v1.4.mjs` and `parents/forest-v1.4.mjs` are byte-identical copies of the v1.4 source. v1.4 trained a **prestructured**, two-channel movement communication protocol and achieved strong success under synthetic route conditions. This does not imply general natural-language competence.
- NEW EXECUTED SOFTWARE: `src/assessment.mjs` is a document navigator and supervised feedback adapter, separately versioned from the optical Daughter core. It contains 8 recovered research documents indexed as paths through the evidence graph. The new data corpus contains real archival project text, while the 88 *question/label tasks* are authored and assigned for this benchmark rather than collected from external users.
- BENCHMARK COMPUTED: 40 train, 16 validation, 32 test; fixed shuffle seed 516; 40 epochs; user-visible model weights; final comparison 4/32 untrained, 13/32 supervised route, 23/32 conventional search. Text-search only picked as validation-selected hybrid (weight 0).
- NOT MEASURED: transfer to unseen domains, truthfulness of generated explanations, ability to understand natural language, camera or real-world forest sensors, independent online autonomy, intelligence or consciousness.

## Why this counts as narrow learning
The online classification model has **mutable parameters changed by labelled feedback**, and the test scores are computed from different test phrases that never enter the training updates. Training improved 4/32 to 13/32 in this benchmark; this is empirical skill acquisition for document routing, not proof that the neuron learned spoken language. The experiment has low power and related train/test domains. The previous forest's learned sender/receiver symbol association is also a narrow learning mechanism. Their combination is a useful research interface, not a validated generally intelligent agent.

## Why the negative result matters
BM25, a standard unsupervised lexical information retrieval baseline, reached 23/32 on these questions. An added learned router was not worth using as a rank bonus for the held-out set; validation determined a hybrid weight of zero. New feature complexity must not be mistaken for greater accuracy.

## Acceptance criteria for a stronger claim
1. Increase to hundreds of questions independently annotated by human reviewers, with source and passage-level evidence.
2. Use a genuinely unseen topic/document set, not only new paraphrases, and measure abstention precision.
3. Compare BM25, learned routing, dense embeddings, and an adapted Daughter neuron under equal latency, memory and training budgets.
4. Introduce explicit feedback streaming, identify label noise and catastrophic forgetting, and lock a new holdout before further tuning.
5. Require supervised decisions before any connector action or material mutation. No autonomous account access based on this study.

## No overwrite
No prior parent version or deployment was edited. The standalone app and this report are entirely additive.
