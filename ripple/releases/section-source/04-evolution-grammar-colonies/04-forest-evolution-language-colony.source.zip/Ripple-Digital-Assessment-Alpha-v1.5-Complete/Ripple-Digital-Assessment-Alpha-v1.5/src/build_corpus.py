from pathlib import Path
import json,re,hashlib,shutil
R=Path('/mnt/data/Ripple-Digital-Assessment-Alpha-v1.5')
S=Path('/mnt/data')
items=[
('forest_map','Forest geographic mapping','Ripple-Forest-Language-Alpha-v1.4/docs/MAP_DESIGN.md'),
('forest_signals','Forest restricted communication','Ripple-Forest-Language-Alpha-v1.4/docs/RESEARCH_METHODS.md'),
('forest_findings','Forest mapping experiment results','Ripple-Forest-Language-Alpha-v1.4/docs/RESULTS.md'),
('daughter_core','Three-layer Daughter mathematics','Ripple-Daughter-Triplet-v3.1/docs/TRIPLET_MATHEMATICS.md'),
('beta_design','Gen Beta architecture','Ripple-Gen-Beta-v2.0/docs/ARCHITECTURE_DECISIONS.md'),
('optical_evidence','Digit-image scientific evaluation','Ripple-Gen-Beta-v2.1/RESEARCH_REPORT.md'),
('beta_guardrails','Beta safety and limitations','Ripple-Gen-Beta-v2.0/docs/EVIDENCE_AND_SAFETY.md'),
('daughter_results','Daughter comparative evidence','Ripple-Daughter-Triplet-v3.1/docs/COMPARISON_AND_EVIDENCE.md'),
]
# Each doc's gold relevance has been assigned by human inspection of the sources.
# 5 distinct training queries, 2 validation, 4 held-out phrasing queries per class.
questions={
'forest_map':[
['How are coordinates represented in the forest map?','What do tree and water barriers mean for the terrain?','Where are the forest zones and beacons defined?','How does the forest map distinguish ground truth and known cells?','What size is the coordinate forest grid?'],
['Where does the generated woodland keep its tile coordinates?','What is the difference between full terrain and visited locations?'],
['Which document specifies the geographic forest tiles?','Find the definition of the blocked creek crossing on the grid.','Explain where the compass-like movement directions are tied to coordinates.','How can I inspect the mapped zones rather than a family genealogy?']],
'forest_signals':[
['How does the scout send quaternary direction messages?','What training rewards teach the sender and receiver?','Is the learned forest communication natural language?','What are the holdout direction and surface contexts?','How is the restricted communication code trained?'],
['Where is the sender-listener training design documented?','What prevents the forest signals from proving English grammar?'],
['Find the instructions for teaching four-symbol movement messages.','Where is oracle shortest-route knowledge identified as a limitation?','Which research explains that the message has two designed slots?','What does the code learn through trial and error in the woodland game?']],
'forest_findings':[
['What percent of routes succeeded using the local scout?','What were the results for scrambled messages?','How many maps were tested in the forest communication experiment?','Did Daughter outperform Beta on mapping coverage?','What is the reported oracle scout navigation success rate?'],
['What did the no-message movement comparison achieve?','What were the numerical forest language findings?'],
['Which report contains the 410 of 420 route result?','Find the exact success record for randomized legal steps.','Did either parent show a convincing forest mapping advantage?','Locate the paired comparison of learned versus scrambled symbols.']],
'daughter_core':[
['What is the daughter photoreceptor differential equation?','How are the three neuron layers coupled?','What determines the spike threshold crossing?','How is the adaptation current updated after a spike?','Where are time constants tauP and tauD specified?'],
['Which formula describes the soma voltage driven by the dendrite?','What is the numerical approach for nearly equal membrane time constants?'],
['Locate the analytical membrane solution for the three compartment cascade.','How does a time varying dendritic state influence the somatic integrator?','Where is the spike reset and refractory procedure mathematically explained?','Find the derivation of the P D S neuron equations.']],
'beta_design':[
['Why does Beta keep the original neuron unchanged?','Which modules are enabled in the Gen Beta architecture?','How does colony information sharing work?','Why is density disabled by default?','Which bounded actions can the Beta rule engine choose?'],
['Where are the worker genomes and memory capacities described?','What was the reasoning behind preserving quaternary telemetry?'],
['Locate the software architecture decision record for the agent system.','Which design explains the scan move share clone wait action grammar?','Why does the hybrid retain the old spiking kernel instead of replacing it?','Find the architectural reason to leave physical sensors disconnected.']],
'optical_evidence':[
['How many handwritten digit images were held out?','Did light augmentation improve strongly attenuated digit classification?','What are the Beer Lambert mathematical illumination tests?','Was the actual camera calibrated with photons?','What was the validation dataset and label provenance?'],
['Where are the 354 out of 360 classification results?','Which study compares Ripple features to raw pixel classification?'],
['Find the supervised scanned digit evidence and the unseen test results.','Which report evaluates simulated lighting paths with image ground truth?','Locate the NIST optical-scanner digit dataset provenance.','What were the limits of the real optical data experiment?']],
'beta_guardrails':[
['What guardrails prevent arbitrary code execution?','What evidence labels distinguish measured and simulated outputs?','What physical sensor validation is still missing?','Why should the colony not be described as intelligent?','What restrictions govern reproduction and safe actions?'],
['Where are the Beta safety acceptance gates recorded?','Which policy prevents external network control by the colony?'],
['Locate the safety conditions limiting agent autonomy and hardware claims.','Where are the evidence grading rules and bounded-action requirements?','Which source defines what cannot be called physical measurements?','Find safety requirements for unverified new sensing capabilities.']],
'daughter_results':[
['Which neuron had lowest firing rate tracking error?','How did Daughter coverage compare against Beta coverage?','Were Daughter mapping gains consistently positive?','How many daughter rate benchmark runs were performed?','What evidence limits were identified in the comparison?'],
['Where is the 0.05083 daughter error reported?','What is the daughter-versus-Delta control result?'],
['Find the statistical evidence comparing the daughter and her parents.','Which trial had equal wins and losses across colony seeds?','Was the new triplet consistently better than the tuned delta neuron?','Locate the paired synthetic experiment summary for firing accuracy.']],
}
docs=[];queries=[]
for i,(name,title,source) in enumerate(items):
 p=S/source
 assert p.is_file(),p
 data=p.read_bytes();dest=R/'data'/'sources'/f'{name}.md';dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 txt=data.decode('utf8');sha=hashlib.sha256(data).hexdigest()
 # Use unmodified source as evidence; paragraphs without markdown table syntax are retrievable.
 paras=[];header=''
 for part in re.split(r'\n\s*\n',txt):
  raw=part.strip()
  if not raw: continue
  if raw.lstrip().startswith('#') and len(raw.splitlines())<=2:
   header=raw.lstrip('# ').strip();continue
  if len(raw)<24:continue
  paras.append({'heading':header,'text':raw[:2500]})
 docs.append({'id':name,'title':title,'source':source,'sha256':sha,'text':txt,'passages':paras})
 for split,qlist in zip(('train','validation','test'),questions[name]):
  for q in qlist:queries.append({'query':q,'gold_doc':name,'split':split,'human_assigned_ground_truth':True})
(R/'data'/'corpus.json').write_text(json.dumps({'schema':'ripple-digital-evidence/1','documents':docs,'queries':queries},ensure_ascii=False,indent=2))
(R/'data'/'manifest.json').write_text(json.dumps([{'id':d['id'],'source':d['source'],'sha256':d['sha256'],'passages':len(d['passages'])} for d in docs],indent=2))
print('Documents',len(docs),'queries',len(queries),'query split', {x:sum(q['split']==x for q in queries) for x in ('train','validation','test')})
for d in docs:print(d['id'],len(d['text']),len(d['passages']))
