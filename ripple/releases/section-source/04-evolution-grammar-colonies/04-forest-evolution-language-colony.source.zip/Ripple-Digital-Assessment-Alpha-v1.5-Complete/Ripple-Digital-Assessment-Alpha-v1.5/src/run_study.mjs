import {readFileSync,writeFileSync} from 'node:fs';
import {evaluate} from './assessment.mjs';
const corpus=JSON.parse(readFileSync(new URL('../data/corpus.json',import.meta.url),'utf8'));
const {model,results}=evaluate(corpus);
writeFileSync(new URL('../results/evaluation.json',import.meta.url),JSON.stringify(results,null,2));
writeFileSync(new URL('../data/trained_policy.json',import.meta.url),JSON.stringify(model.snapshot(),null,2));
console.log(JSON.stringify({seed:results.seed,validationWeight:results.selectedAlpha,untrained:results.untrained.accuracy,results: Object.fromEntries(Object.entries(results.holdout).map(([k,v])=>[k,{correct:v.correct,n:v.n,top3:v.top3,review:v.review}]))},null,2));
