from pathlib import Path
import json,re
R=Path('/mnt/data/Ripple-Digital-Assessment-Alpha-v1.5')
html=(R/'src/template.html').read_text();code=(R/'src/assessment.mjs').read_text();app=(R/'src/app.js').read_text()
code=re.sub(r'\bexport\s+(?=(?:class|const|function)\b)','',code)
for token,value in {'__ENGINE__':code,'__APP__':app,'__CORPUS__':(R/'data/corpus.json').read_text(),'__POLICY__':(R/'data/trained_policy.json').read_text(),'__EVALUATION__':(R/'results/evaluation.json').read_text()}.items():
 value=value.replace('</script','<\\/script').replace('<!--','<\\!--')
 html=html.replace(token,value)
assert '__ENGINE__' not in html
(R/'Ripple-Digital-Assessment-Alpha-v1.5.html').write_text(html)
print('Built',R/'Ripple-Digital-Assessment-Alpha-v1.5.html',len(html))
