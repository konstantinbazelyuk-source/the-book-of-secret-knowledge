# Ripple Digital Assessment Forest — Alpha v1.5

**Research status:** runnable, locally executed document-routing and explicit-feedback demonstration. Original Ripple Forest Language v1.4 is preserved. **Not** human-language comprehension, unsupervised discovery, or general intelligence.

## Run without installs
Open `Ripple-Digital-Assessment-Alpha-v1.5.html` in any modern browser. If direct file URLs are restricted, use a local HTTP server such as `python -m http.server 8765` from this folder, then browse `http://localhost:8765/` and click the HTML.

The single-file app contains the exact JavaScript learning and retrieval engine, the source corpus, precomputed supervised routing weights, and results. It makes **no remote requests** and does not need Codex, an account, or a cloud deployment. It is not a ChatGPT plugin or an autonomous agent. No persistent device storage is used; exporting is user-initiated.

## Actual functionality
- Eight source-document branches compiled from original, hashed Ripple research documentation (see `data/manifest.json`, `data/sources/`).
- Search for source evidence; inspect the selected branch, quaternary 2-symbol address, and source excerpt.
- Compare a learned document classifier with conventional **BM25** lexical ranking and a validation-selected hybrid.
- Correct a document choice and update the online supervised router's finite numerical weights; watch later routing decisions change. Download a trace of the explicit corrections.
- See actual training/validation/test accuracy, mistakes, and immutable evidence boundaries.

The `−1, −0, 0, 1` alphabet is reused for bounded **document addresses** (two symbols represent up to 16 document IDs). These addresses are not the original forest code for heading/surface; the original sender/receiver and the Daughter triplet membrane are not changed or retrained.

## Evaluation protocol
88 human-authored query/doc labels based on real, pre-existing Ripple documentation: 40 supervised training prompts, 16 validation prompts, and **32 test prompts reserved for final evaluation**. Query phrasings are distinct but document topics and the document index overlap; this is NOT a domain-generalization evaluation and not independent third-party annotated relevance data. Document-level top-1/top-3 are measured; individual passage relevance, factual QA correctness, actual language understanding, and physical sensing are not validated.

The model is a finite-dimensional hashed-looking but actually sparse token/character-3gram **softmax linear classifier** fitted by bounded online gradient updates. BM25 is conventional document-length-normalized retrieval. No pretrained external AI, prompt injection execution, self-code modification, or open-web browsing is involved. The user chooses any supervised feedback label; it is *not* treated as inherently correct ground truth unless independently checked. Negative outcomes are retained.

Executed outcomes (`results/evaluation.json`):

| Protocol | Top-1 | Top-3 |
|---|---:|---:|
| Untrained router | 4/32 | 12/32 |
| Trained router | 13/32 | 26/32 |
| BM25 search | 23/32 | 30/32 |
| Validation-selected hybrid, alpha=0 | 23/32 | 30/32 |

The baseline beats the learned model. That is a legitimate limitation, not a failure to be concealed. The hybrid automatically selects alpha=0 when validation shows no additional benefit from the learned weighting, leaving the learned model visible as an experimental research mode.

## Scientific relevance and references
- Robertson and Zaragoza, *The Probabilistic Relevance Framework: BM25 and Beyond* (2009), DOI 10.1561/1500000019 — classical retrieval.
- Lazaridou, Peysakhovich & Baroni, *Multi-Agent Cooperation and the Emergence of (Natural) Language* (2017), https://arxiv.org/abs/1612.07182 — bounded communication games, not unrestricted language.
- Kottur et al., *Natural Language Does Not Emerge 'Naturally' in Multi-Agent Dialog* (2017), https://aclanthology.org/D17-1321/ — caution against reclassifying task protocols as natural language.

## Reproduce
```bash
python src/build_corpus.py        # regenerate unmodified corpus, requires original source files in /mnt/data
node src/run_study.mjs            # fits 40 training labels, selects validation weight, evaluates 32 test labels
node --test tests/assessment.test.mjs
python src/build_standalone.py
python tests/browser_check.py     # optional Chromium/Playwright GUI smoke test
```
The distributed `data/sources` and corpus are sufficient to run the Node tests and offline browser app without source files in /mnt/data; the build_corpus regeneration script specifically uses those original absolute paths and is not required for using the release.

## Safety and provenance
Source documents and preserved v1.4 parent source files have SHA256 manifests. User feedback changes model weights only; it does not edit source material, generate executable code or call external tools. The output is *document evidence*, not a guaranteed true answer. Queries over 500 chars and malformed quaternary instructions are rejected. A selected source may be incorrect: inspect it or label it manually.
