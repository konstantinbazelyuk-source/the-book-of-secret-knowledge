from pathlib import Path
import json
from playwright.sync_api import sync_playwright
R=Path('/mnt/data/Ripple-Digital-Assessment-Alpha-v1.5')
html=(R/'Ripple-Digital-Assessment-Alpha-v1.5.html').read_text()
results=[]
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for size in [{'width':390,'height':844},{'width':1260,'height':890}]:
  page=b.new_page(viewport=size)
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(html,wait_until='load',timeout=30000)
  page.wait_for_timeout(150)
  assert page.locator('h1').inner_text()=='Digital Assessment Forest'
  assert page.locator('#updates').inner_text()=='1600' # 40 queries x 40 epochs
  assert page.locator('#crumb').inner_text().startswith('forest-root')
  assert page.locator('.node').count()==8
  page.locator('#mode').select_option('learned')
  page.locator('#q').fill('Which report documents the light augmentation classification benchmark?')
  page.locator('#assess').click()
  before=page.locator('#crumb').inner_text()
  page.locator('#teachDoc').select_option('optical_evidence')
  page.locator('#teach').click()
  after=page.locator('#crumb').inner_text()
  assert 'Feedback accepted' in page.locator('#feedback').inner_text()
  assert page.locator('#updates').inner_text()=='1601'
  page.get_by_role('button',name='Experiment record').count() if False else None
  page.locator('[data-tab="study"]').click()
  assert '23 / 32' in page.locator('[data-panel="study"]').inner_text()
  page.locator('#rerun').click()
  assert '13/32' in page.locator('#rerunNote').inner_text()
  page.locator('[data-tab="sources"]').click()
  assert page.locator('.sourceRow').count()==8
  page.locator('[data-tab="limits"]').click()
  assert 'does not' in page.locator('[data-panel="limits"]').inner_text()
  page.locator('[data-tab="lab"]').click()
  page.screenshot(path=str(R/'results'/('browser-phone.png' if size['width']==390 else 'browser-desktop.png')),full_page=True)
  assert not errors,errors
  results.append({'viewport':size,'pageErrors':errors,'evidencePathBefore':before,'evidencePathAfter':after,'feedbackUpdates':page.locator('#updates').inner_text(),'docNodes':8})
  page.close()
 b.close()
(R/'results/browser_check.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
