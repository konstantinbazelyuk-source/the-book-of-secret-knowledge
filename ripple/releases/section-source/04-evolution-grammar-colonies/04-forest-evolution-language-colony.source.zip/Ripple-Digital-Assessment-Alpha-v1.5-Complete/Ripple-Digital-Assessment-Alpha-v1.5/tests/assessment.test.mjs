import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {DocumentForest,packDocumentId,unpackDocumentId,scoreSet,evaluate,features,SYMBOLS} from '../src/assessment.mjs';
const C=JSON.parse(readFileSync(new URL('../data/corpus.json',import.meta.url),'utf8'));
const policy=JSON.parse(readFileSync(new URL('../data/trained_policy.json',import.meta.url),'utf8'));
const E=JSON.parse(readFileSync(new URL('../results/evaluation.json',import.meta.url),'utf8'));
test('8 real Ripple sources and document hash provenance verified',()=>{
 assert.equal(C.documents.length,8);
 for(const d of C.documents){const file=readFileSync(new URL('../data/sources/'+d.id+'.md',import.meta.url));assert.equal(createHash('sha256').update(file).digest('hex'),d.sha256);assert.equal(file.toString('utf8'),d.text);}
});
test('source ground truth is independent of model features',()=>{assert.equal(C.queries.length,88);assert.deepEqual(Object.fromEntries(['train','validation','test'].map(s=>[s,C.queries.filter(q=>q.split===s).length])),{train:40,validation:16,test:32});const a=new Set(C.queries.map(q=>q.query));assert.equal(a.size,88);});
test('quaternary two-token route is reversible and bounded',()=>{assert.deepEqual(SYMBOLS,['−1','−0','0','1']);for(let i=0;i<16;i++)assert.equal(unpackDocumentId(packDocumentId(i)),i);assert.throws(()=>packDocumentId(16));assert.throws(()=>unpackDocumentId(['x','1']));});
test('train takes train-only samples and rejects invalid labels',()=>{assert.throws(()=>new DocumentForest(C).fit(C.queries.filter(q=>q.split==='test'),{epochs:3}));assert.throws(()=>new DocumentForest(C).learn('bad','made-up'));});
test('training is deterministic from fixed seed',()=>{const a=evaluate(C),b=evaluate(C);assert.deepEqual(a.results,b.results);assert.deepEqual(a.model.snapshot(),b.model.snapshot());});
test('locked holdout results match computed counts',()=>{const r=evaluate(C).results;assert.deepEqual(r.holdout.bm25.correct,E.holdout.bm25.correct);assert.deepEqual(r.holdout.learned.correct,E.holdout.learned.correct);assert.equal(r.selectedAlpha,E.selectedAlpha);assert.equal(r.untrained.correct,E.untrained.correct);});
test('explicit training from feedback updates model and changes ranking for prompted source',()=>{const m=new DocumentForest(C);const q='new unseen assessment phrase xyzdocument';const label='optical_evidence';const before=m.rank(q,'learned')[0].doc;for(let i=0;i<12;i++)m.learn(q,label);assert.notEqual(before,label);assert.equal(m.rank(q,'learned')[0].doc,label);});
test('source path identifies original file, never generates an answer',()=>{const m=new DocumentForest(C).restore(policy);const a=m.assess('What is the forest geographic map size?');assert.ok(C.documents.some(d=>d.id===a.doc));assert.match(a.source,/\.md$/);assert.ok(a.path.every(p=>p.node));assert.ok(a.passage&&a.passage.text.length>1);assert.equal(unpackDocumentId(a.symbols),C.documents.findIndex(d=>d.id===a.doc));});
test('copy of supervised policy can be restored exactly',()=>{const a=new DocumentForest(C).restore(policy),b=evaluate(C).model;for(const q of C.queries.filter(q=>q.split==='test'))assert.deepEqual(a.scores(q.query),b.scores(q.query));});
test('unsafe or invalid query and feedback inputs are rejected',()=>{const m=new DocumentForest(C);assert.throws(()=>m.rank('x'.repeat(501)));assert.throws(()=>m.rank('?', 'exec'));assert.throws(()=>m.learn('x',C.documents[0].id,Infinity));});
test('no executive permissions or external network in assessment engine',()=>{const src=readFileSync(new URL('../src/assessment.mjs',import.meta.url),'utf8');assert.doesNotMatch(src,/\beval\s*\(/);assert.doesNotMatch(src,/\bfetch\s*\(/);assert.doesNotMatch(src,/\bchild_process\b/);});
