# Ripple Sensory Gene & JavaScript Gate — Alpha v1.2

**Status:** actual offline Node.js research Alpha, with preserved original Ripple neuron code and reproducible synthetic studies. No false claims of intelligence, calibrated vision, real hardware, unbounded code execution or browser self-modification.

## Included
- Executable **restricted JavaScript compiler/gate** (`src/js_gate.mjs`) that emits genuine ES module source and verifies SHA-256, with operator approval before reviewed execution; outside arbitrary JS is quarantined.
- New **color-gene input adapter**, symbolic polarity-configuration mutations, and supervised bounded simplex weight updates (`src/sensory_math.mjs`), entirely outside the locked neuron.
- New bounded conditional-birth model reacting to discovered voxels, density, crowding and synthetic energy (`src/colony_alpha.mjs`).
- Preserved v1.1 hybrid and original LIF source under `legacy/` — no modifications to old algorithms.
- 30 sensory models, each evaluated against same-profile **reserved** generated data; 220 mapping policy trials; 24 mutated restricted JS policies evaluated 6 times each (144 runs); 2D/3D genealogy/path history.
- Failure case where a successful mutation under one synthetic light profile **fails** under a changed profile.
- Static offline HTML laboratory with actual recorded results and mutation previews; no cloud, accounts or API keys.

## Run

Requires **Node.js 22+** for experimental modules. Python 3 is optional for rebuilding the HTML. Do not run `npm install`.

```bash
node --test tests/alpha.test.mjs
node src/experiments.mjs
python src/build_explorer.py
node src/policy_cli.mjs stage policies/default_recipe.json
node src/policy_cli.mjs stage policies/default_recipe.json policies/default_generated_policy.mjs
```

For a one-time **human-reviewed local dry run**, copy the `sourceHash` shown by `stage` and issue:

```bash
node src/policy_cli.mjs approved-dry-run policies/default_recipe.json <SOURCE_HASH> --i-reviewed
```

The last command does not deploy a program or change a legacy file; it only runs the exact approved pure decision function against an explicit observation. No external script may use `process`, `require`, `fs`, networking or shell functions through the compiler.

Open `Ripple-Sensory-Gene-Gate-Alpha-v1.2.html` directly to browse saved results. Its content was tested using equivalent inlined HTML in Chromium; direct `file://` automated navigation was blocked by this environment. Browser export will work in an ordinary modern browser, subject to local file security policies.

## Experiment classification

**Calculated:** specified threshold, diffusion, logit and input-gate formulas. **Executed/simulated:** all generated voxel observations, numerical sensor-calibration studies, synthetic births, JS policy choices and phenotype histories. **Measured on this host:** source checksums, test passage, actual execution of policy modules and browser rendering. **Not performed:** physical light/depth measurements, OS sandbox escape testing, real camera/robot/game app tests and production code deployment.

See `docs/MATHEMATICAL_MODEL.md`, `docs/SOFTWARE_REQUIREMENTS.md`, `docs/SECURITY_AND_GATE.md`, `docs/SOURCE_CONTINUITY.md` and `docs/NEGATIVE_RESULTS.md`. New original files released CC0-1.0; all existing source archives and third-party materials preserve their original licenses and notices.
