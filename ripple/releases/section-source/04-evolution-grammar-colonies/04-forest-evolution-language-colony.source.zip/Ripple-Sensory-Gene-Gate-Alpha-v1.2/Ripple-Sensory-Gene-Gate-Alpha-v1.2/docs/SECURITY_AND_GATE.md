# The JavaScript gate: actual execution versus quarantined source

## Scope actually built

`src/js_gate.mjs` compiles an allowlisted numeric/Boolean JSON recipe into **real JavaScript source** exporting `decide(observation)`. Numeric constants are range-validated; all other code comes from fixed, internally owned templates. It uses dynamic module import **only** for exact source generated from that template. It has no free-form statement compiler and no `eval`. Decisions are `SCAN`, `MOVE`, `SHARE`, `CLONE`, `WAIT`; observations are a bounded fixed record.

The stages are:
1. `stagePolicy(recipe)`: validate and compile; record a SHA-256 of the generated JavaScript. Stage only, no execution.
2. `loadLabPolicy(staged)`: internal **lab-only** execution of exact-template policies, without claiming operator approval. No connectors, sensors, credentials, or external writes are exposed by this API.
3. `stagePolicy(recipe, {externalSource: code})`: external JavaScript input, including code written by a human, must **match exact template output byte-for-byte**. Any other script stays quarantined.
4. `reviewPolicy(staged, {operatorApproved:true,expectedHash})`: explicit human approval and identical hash for promotion. This mechanism permits approved pure policy execution only; it does not modify any live repository or older Ripple implementation.
5. `executePolicy(approved,observation)`: recompile, compare source and hash, verify observation shape, import only the compiled code, return an allowed decision. A lab trial and external deployment are separate permissions.

## Tested CLI example

```bash
node src/policy_cli.mjs stage policies/default_recipe.json
node src/policy_cli.mjs stage policies/default_recipe.json policies/default_generated_policy.mjs
node src/policy_cli.mjs approved-dry-run policies/default_recipe.json <SOURCE_SHA256_SHOWN_BY_STAGE> --i-reviewed
```

The CLI's explicit approval flag applies **only to a dry-run local decision**. It does not permanently authorize deployment, write to another application, or accept arbitrary uploaded JavaScript.

## Security limitations — do not overclaim

This is a small **restricted language** with program synthesis into JavaScript, not a general JS sandbox. A future unrestricted-source executor requires strong operating-system isolation, resource ceilings, network/filesystem denial, authentic human approvals and negative escape testing. Running untrusted source with Node's `vm` is NOT sufficient; Node says so explicitly. Node's `--permission` is also not a security boundary against malicious JS. SES/Endo compartments can provide object-capability confinement for eligible code, but that is not installed or claimed here.

References:
- Node.js `vm` official warning: https://nodejs.org/api/vm.html
- Node.js application security and OS boundary guidance: https://github.com/nodejs/node/blob/main/SECURITY.md
- SES: https://docs.endojs.org/modules/ses.html

A SHA-256 fingerprint alone detects changes only against independently trusted reference data; anyone controlling both code and ledger can recompute all hashes. Nothing here authenticates the publisher, guarantees code safety, or grants the colony autonomous authority.
