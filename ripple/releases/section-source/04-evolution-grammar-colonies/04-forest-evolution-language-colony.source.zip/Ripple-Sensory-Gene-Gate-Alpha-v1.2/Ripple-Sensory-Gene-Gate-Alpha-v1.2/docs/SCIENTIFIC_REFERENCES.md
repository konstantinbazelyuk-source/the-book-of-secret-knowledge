# External documented foundations used in Alpha v1.2

1. **Leaky integrate-and-fire neurons:** EPFL *Neuronal Dynamics*, Chapter 1. https://neuronaldynamics.epfl.ch/online/Ch1.S3.html . Original user Ripple v0.1 governs actual code parameters; this is an external model reference, not an independent new discovery.
2. **Exponentiated gradient on simplex:** Kivinen & Warmuth (1997), Exponentiated Gradient versus Gradient Descent for Linear Predictors; representative peer-reviewed implementation discussion: https://pmc.ncbi.nlm.nih.gov/articles/PMC4427574/ . The Alpha uses a clipping-aware, bounded EG-like **surrogate** update; not a claim of reproducing the exact paper method in the presence of all nonlinearities.
3. **Held-out evaluation/data leakage:** scikit-learn, Common Pitfalls and Data Leakage: https://scikit-learn.org/stable/common_pitfalls.html . Seeds used for training do not appear in holdout evaluation; the intentionally constructed profile family still limits generalization.
4. **Node `vm` warning:** https://nodejs.org/api/vm.html . The module is NOT a security mechanism; this Alpha does not use it for untrusted code.
5. **Node permission boundaries:** https://github.com/nodejs/node/blob/main/SECURITY.md . Node.js does not claim its permission model sandboxes actively malicious same-process code.
6. **Secure ECMAScript background:** https://docs.endojs.org/modules/ses.html . Conceptual future capability-only compartments; **not implemented in this version**.

These are third-party references, not embedded dependencies. The experimental coefficient values are proposed by this Alpha and explicitly cannot be interpreted as scientifically measured optical constants.
