# Source continuity: what was recovered and what is genuinely used

From original files, not inferred technology:

| Earlier Ripple family | Existing research ability | v1.2 status |
|---|---|---|
| Ripple Neuron v0.1 / Mycelium v0.5 | LIF threshold, refractory, feedback | **VERBATIM LOCKED and EXECUTED** |
| Ripple Hybrid Alpha v1.1 | 2D/3D rays, local maps, bounded logic/mutation, lineage, diffusion and nine traits | **VERBATIM LOCKED and EXECUTED** as regression baseline and synthetic world API |
| Ripple Neuron Photoreceptor v0.6 | Log contrast and attenuation | Unmodified source archived; v1.2 uses independent mathematical gate, not this photoreceptor as a trained sensor |
| Ripple Quaternary v0.7 | Four symbolic signal states | Unmodified source archived; imported by v1.1 but not separately extended in v1.2 |
| Ripple Digital World v0.5 / Alpha v1.0 | Voxel fields, genetic markers and diffusion | Existing methods inherited through v1.1; prior packs unmodified |
| Ripple Mycelium v0.1–v0.3 | Workload scheduling and adaptive population controls | Prior research reference, not silently claimed as multithreaded active colonies here |
| Optical mathematics v0.4 | Synthetic calibration, lock-in detection and constraint checking | Prior research reference, not fitted to camera samples |
| Ripple SpiderScan Ground | Prototype sensor adapters / known-pose mosaics | Not coupled to a real camera or moving platform |
| Kokoro Mesh and other Ripple integrations | Networked coordination / trace interfaces | Not integrated in this new code path; no claim of actual neural consciousness |

All locked v1.1 source used by the Alpha is under `legacy/`. The tests verify the LIF and v1.1 hashes, and the prior v1.1 tests were rerun externally. No live repository, physical project, project library files, or connected applications were written to. Unmodified source archives from other turns remain separate artifacts rather than being copied blindly into a new execution path. Their original ownership and licensing terms remain unchanged.
