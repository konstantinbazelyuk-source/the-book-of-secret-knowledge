# Ripple Alpha v1.2 — software requirements and acceptance record

| ID | Must do | Implemented at | Acceptance |
|---|---|---|---|
| RG-001 | Preserve locked original firing kernel | `legacy/ripple_mycelium_v05_LOCKED.js` | Exact SHA-256 regression and active pulse test |
| RG-002 | Preserve v1.1 decision/voxel model | `legacy/hybrid_lab_v11_LOCKED.mjs` | Exact checksum, independently executable |
| RG-003 | Check source-script content before execution | `src/js_gate.mjs` | Hash mismatch and altered source rejection |
| RG-004 | Compile a safe restricted recipe into real JS | `compileRecipe` | Generated import returns a legal action |
| RG-005 | Reject unsupported external JavaScript | `stagePolicy` / `reviewPolicy` | `eval`, OS-like, and unmatched outside scripts rejected |
| RG-006 | Demand human-approved content hash for reviewed external JS | `reviewPolicy` | No hash or no approval rejected |
| RG-007 | Restrict experimental execution to new lab | `loadLabPolicy` | No deployment path or legacy file edit |
| RG-008 | Preserve original signed channel coefficients | `sensory_math.mjs` | Coefficient test, LIF source checksum |
| RG-009 | Introduce bounded inherited RGB weights | `opticalGate`, `inheritGene` | Sum=1, values finite, invert flags validated |
| RG-010 | Add mathematically explicit sign/polarity phenotype | `trainPolarityFamily` | Exactly eight symbolic configurations enumerated |
| RG-011 | Correct optical clipping gradients | `updateGene` | Clipped channel derivative zero, lab scores rerun |
| RG-012 | Reserve holdout seeds for evaluation | `experiments.mjs` | Separate seed ranges, both dimensions |
| RG-013 | Record generalization failure on color reversal | `distribution_shift.json` | Regression test intentionally shows failure |
| RG-014 | Bounded sensory-conditional clone chance | `birthProbability` | Density, novelty and vision ablations |
| RG-015 | Keep cloned neurons and known-space separate | `colony_alpha.mjs` | Separate ancestry, pulse/memory test |
| RG-016 | Cap reproduction and motion safely | `runColony` | Max population, no wall penetration, bounded time |
| RG-017 | Compare varied logic and colony traits, not only speed | `mutated_js_policies.json` | 24 policy recipes, 144 trial results |
| RG-018 | Keep visual interface honest about offline data | standalone HTML explorer | Desktop/mobile Chromium tests, no external backend |
| RG-019 | Retain previous Alpha regression status | original v1.1 suite | 42/42 passed in unchanged upstream folder |
| RG-020 | Keep operators in control of external deployment | gate protocol | No automatic GitHub/game/hardware/account modification |

**Future (not implemented):** secure arbitrary-JS isolation, signed approval records tied to user identity, physical camera calibration, real 3D depth sensing, change-point adaptive rollback, Luanti runtime integration, authenticated remote RPC, measured process concurrency and fatigue/energy models. These are engineering gates, not present capabilities.
