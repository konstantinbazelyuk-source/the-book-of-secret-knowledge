# Failed traits and falsifiable boundaries

1. **Mis-specified training gradient (caught and corrected):** First implementation updated a channel's weight after its effective input had clipped at one. This does not follow the derivative of a clipped function. Corrected gradient zeroes that term in saturation and all experiments and tests were rerun. Earlier intermediate numbers must not be cited as final.
2. **Out-of-distribution sign reversal:** Polarity mutation learned on shifted-red synthetic data improved accuracy on a similarly shifted holdout but failed on ordinary red data. `data/distribution_shift.json` contains the exact seeds and outcomes; do not promote a global polarity switch.
3. **Cloning can reduce mapping:** No-early-clone policy averaged more distinct mapped cells than several eight-clone policies. The extra agents repeatedly discover old cells. Birth count is not an intelligence or coverage metric.
4. **Independent optical calibration absent:** All RGB observations are from designed synthetic fixture correlations, not a sensor datasheet transfer model or held-out camera recording.
5. **Higher computed accuracy does not imply emergence of understanding:** Logistic regression on trivially separable synthetic data is supervised calibration; it does not learn meaning, invent general reasoning or prove safe autonomy.
6. **External arbitrary JS deliberately refused:** Stage-only does not mean arbitrary code is secure. The gated compiler accepts only exact bounded decision logic. Other JS needs a real OS isolation plan and operator review.
7. **Density and occlusion coefficients hypothesized:** Mathematical coefficients provide reproducibility but are not measured physical attenuation parameters.
8. **Data leakage and overfitting remain risks:** Training and test seeds differ, but sensor-generation profiles are deliberately known and reused across synthetic worlds. A new physical-data holdout is required.
9. **No net speedup established:** This Alpha adds gating and learning work, not accelerated computation, GPU kernels or measured robotics.
