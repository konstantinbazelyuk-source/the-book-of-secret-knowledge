# Experiment and variant record

Recorded outputs are saved without pruning inferior architectures:
- `data/sensory_study.json`: 30 training/evaluation model records (5 symbolic light profiles × 2 dimensions × 3 gene strategies). Each profile/dimension has 1280 training labels and 1280 unseen-seed test labels. Every strategy uses the same test data for a given profile/dimension.
- `data/distribution_shift.json`: independent cross-profile sign-reversal failure, 450 held-out synthetic records for each environment.
- `data/colony_study.json`: 220 fully executed synthetic colony studies (11 configurations × 10 seeds × 2 dimensions) plus separate unchanged v1.1 run results for reference, not a controlled speed comparison.
- `data/mutated_js_policies.json`: 24 compiled JavaScript policy mutations × 4 development seeds plus 2 reserved seeds = 144 recorded policy runs. Generated source and pinned hash retained.
- `data/specimen_paths.json`: 16 detailed policy/dimension path and family-tree replays for seed 20.
- `data/ledger.json`: chained hashes for release event *integrity* only, not authentication, signing or consensus.
- `data/reproducibility_first.txt` / `reproducibility_second.txt`: identical SHA-256 records from two consecutive deterministic full study reruns.
- `data/browser_checks.json`: inspected desktop/mobile Chromium UI checks in `about:blank` page using exactly the built standalone HTML text (because `file://` automation is blocked in this runtime).

**Interpreting the results**: Good probability calibration on synthetic fixtures is a small mathematical achievement, not sight in the real world. Failure under a changed profile is the strongest reason not to promote the polarity gate into a real camera system yet. More births do not imply intelligent species or better mapping; unique sensed observations and generalization matter. No automated result promotes scripts to other apps.
