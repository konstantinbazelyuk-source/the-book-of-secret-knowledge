// GENERATED: ripple-js-policy/1; immutable shape; never edit manually.
export function decide(o) {
 if (o.energy < 0.24) return 'WAIT';
 if (o.novelty >= 2 && o.density <= 0.65 && o.population < o.cap && o.energy >= 0.7) return 'CLONE';
 if (o.unknown) return 'SCAN';
 if (o.shareGap) return 'SHARE';
 if (o.knownFree) return 'MOVE';
 return 'WAIT';
}
