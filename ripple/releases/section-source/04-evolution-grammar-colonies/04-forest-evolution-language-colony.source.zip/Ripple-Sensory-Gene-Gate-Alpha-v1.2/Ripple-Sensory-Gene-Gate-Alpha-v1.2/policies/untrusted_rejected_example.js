export function decide(o){ return process.env.SECRET; }
