from pathlib import Path
from playwright.sync_api import sync_playwright
import json
root=Path(__file__).resolve().parent.parent
url=(root/'Ripple-Sensory-Gene-Gate-Alpha-v1.2.html').as_uri()
result={}
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for name,size in [('desktop',(1366,900)),('mobile',(390,844))]:
  page=browser.new_page(viewport={'width':size[0],'height':size[1]},device_scale_factor=1)
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto('about:blank');page.set_content((root/'Ripple-Sensory-Gene-Gate-Alpha-v1.2.html').read_text(),wait_until='load')
  page.select_option('#profile','4');page.select_option('#dimension','3');page.select_option('#colony','2');page.select_option('#specimen','1');page.locator('#tick').fill('48');page.select_option('#policy','10')
  legend=page.locator('#geneColors').inner_text();meta=page.locator('#policyMeta').inner_text()
  overflow=page.evaluate('document.documentElement.scrollWidth>window.innerWidth')
  canvas=page.evaluate("(()=>{const c=document.getElementById('world');const a=c.getContext('2d').getImageData(0,0,c.width,c.height).data;return a.some((x,i)=>i%4===0&&x!==11)})()")
  path=root/'charts'/f'alpha_gate_{name}_verified.png';page.screenshot(path=str(path),full_page=True)
  result[name]={'errors':errors,'horizontalOverflow':overflow,'canvasNonempty':canvas,'profileText':legend[:160],'policyLabel':meta[:140],'screenshot':str(path)}
  assert not errors,errors
  assert not overflow,'horizontal overflow'
  assert canvas,'blank canvas'
  assert 'Inversion' in legend
  assert 'SHA-256' in meta
  page.close()
 browser.close()
(root/'data'/'browser_checks.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
