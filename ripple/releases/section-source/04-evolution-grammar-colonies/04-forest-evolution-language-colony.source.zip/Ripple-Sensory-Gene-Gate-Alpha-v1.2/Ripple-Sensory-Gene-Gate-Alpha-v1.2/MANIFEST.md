# Ripple Sensory Gene Gate Alpha v1.2 — manifest

Original Ripple source locked, v1.1 hybrid source locked, 51 new tests and 42 original v1.1 tests rerun.
Source code, experiment records, interface screenshots, security caveats and the integrity ledger are included.

| Metric | Verified count |
|---|---:|
| New Alpha tests | 51/51 |
| Prior v1.1 regression (original separate package) | 42/42 |
| Gene strategy records | 30 |
| Colony simulation records | 220 |
| Generated policies | 24 |
| Generated-policy trials | 144 |
| CRC ZIP verification | required after packaging |
| Files listed below | 47 |

## SHA-256 file contents (this manifest and checksum file excluded)

````
d08df4db5dc07ea55d5d8345fc6ed3296a23289dc64c312a31af5f54eb28f859  README.md  (3409 bytes)
745bacd303a745062f87212ec59f193f5a03538e0944a9a86e3f3445c118a5ef  Ripple-Sensory-Gene-Gate-Alpha-v1.2.html  (645518 bytes)
ee9a180526594fb3107aa0d83f60a2fda3e81c78aa2d8bcfc229d48743feecc2  charts/alpha_gate_desktop_verified.png  (730154 bytes)
74a8739e7937321c677228c5b3311acb0ab433f19c3d2c6cf1f735d94af2281c  charts/alpha_gate_mobile_verified.png  (516803 bytes)
612edfab184018c06fd58d31b3e1df24474480138e342535245bad925f3a059a  data/browser_checks.json  (844 bytes)
335cd189d9618062d867d586c6f922f0d8cca7bc6fd10282b47bacd55c35019b  data/browser_log.txt  (845 bytes)
749810be79624bdf0bd84e804a464d670afba7ab8d8672816d8fd949ff210c20  data/colony_study.json  (116410 bytes)
c464bd07fb4c84b5cb382cb4b63411898425fab73ffa3b5df238655ead3a5c38  data/distribution_shift.json  (948 bytes)
54b92ff57f46a50cc261cae3b7dbd88ce49652f908c9c9be1a3e0f5657ef85d7  data/execution_log.txt  (6568 bytes)
cdee844c80041c753fdd0d92420c053112ce34427473e74b41aac88f7b5132bb  data/ledger.json  (1090 bytes)
af613e7a160522e3e0778e5ca2f15b6a7fd1b97f3fe2309c624c4b88c5d55948  data/legacy_regression_log.txt  (6574 bytes)
fcd74f58c2b4a881941a0eec181381d1560745754b147411af1b1de3858e5c2a  data/mutated_js_policies.json  (67354 bytes)
9e79882cb8b2b74a8f30f1b6930d7e642884965786abebffa434a2bd707e690c  data/reproducibility_first.txt  (359 bytes)
9e79882cb8b2b74a8f30f1b6930d7e642884965786abebffa434a2bd707e690c  data/reproducibility_second.txt  (359 bytes)
d0201c9be7f419db491cfbeade32de48930aca643fc4c60834646451f28b792e  data/reviewed_dry_run.json  (330 bytes)
9d5babbf0bd8c7d549582039b02f4d2d9d7d8c36d2c08e5df4f89eccf3ee3191  data/sensory_study.json  (19517 bytes)
0ae36682331e774b5afc1d6937b2e024fa10baf2b999549c7ef3a945ffd61439  data/specimen_paths.json  (1833981 bytes)
3f6a5ea33b31d34baaaaef4c359cec5e6fb4b7fc9e7b63bce7468e1e39961840  data/staged_external_exact.json  (687 bytes)
c7a84dabcd476cb424b06ca34e2f069ccc5b92e39a12801cf208ab914019df35  data/staged_external_rejected.json  (690 bytes)
9315dbc4e5cb9b495e75963429ee3f3784734ea2541b03573f27b0b8294c6f91  data/summary.json  (8999 bytes)
dd1e0e5fbc6f34f676353430924f81416b7b69505f4687952520cc619b39c708  data/tests_log.txt  (8229 bytes)
60ad5d34fab2f7d9b539021c8a8ab3cf1e65e7642f87ffce873556debc257c14  docs/MATHEMATICAL_MODEL.md  (5680 bytes)
de480581f44121a6dd1f0941b3f55376821f741ce96190782e25ab8776e6fa39  docs/NEGATIVE_RESULTS.md  (2091 bytes)
77d2f68190f2a76d287e349281ac2864b1777285fa0d3a77866999ca3a677e88  docs/SCIENTIFIC_REFERENCES.md  (1701 bytes)
182ae58b08d1a4f2ed08f64e7a19150604c913280c32d38b788610f117eb738f  docs/SECURITY_AND_GATE.md  (3218 bytes)
d3c9f960945bad08e1499a13e25b3af280b2b9bdad6beaad8012151526ab054b  docs/SOFTWARE_REQUIREMENTS.md  (3015 bytes)
b10a01566d38d3c274ca97a40bffac5090c77be24e0043371c370e1527b19c2b  docs/SOURCE_CONTINUITY.md  (2056 bytes)
f457a1cdc645396ac155f31b11648e9df0cd16f3614223ecebfd1f7bf19e7561  docs/VARIANT_RECORD.md  (1923 bytes)
b7b4d0fdf9f5c924a5b103bdf54c058d819595f23e3678e0cea063dae3867f75  legacy/alpha_engine_v10_LOCKED.js  (12998 bytes)
8e64cf905d1120f996690da3f51746193e6f0e63a29f1a23019da0619dd43f6e  legacy/hybrid_lab_v11_LOCKED.mjs  (15037 bytes)
a55ec7ec8582504ea6257b886bc03624da92d799ea2608fba68f5c50b3828986  legacy/photoreceptor_v06_LOCKED.js  (3008 bytes)
9c1879f6bc024e564e5e25b0294ac62b34d67aafffe26f9ddfae52675d66f695  legacy/quaternary_v07_LOCKED.mjs  (13281 bytes)
d75d4208e92f19623b127615bd52b4002e85d2c0a59b76471764b55a24294210  legacy/ripple_mycelium_v05_LOCKED.js  (1940 bytes)
8c3c388b1236c9562d40048372c72ce573f8a5f92c0d92ea2ac9438ab59f0723  policies/default_generated_policy.mjs  (353 bytes)
1a24f9b53a1fac223d43122723145c6d31c86d003ab34616b0bf606829913871  policies/default_recipe.json  (150 bytes)
f71b92937cbf8c67a6e797e84748d03916b89a142bc416eaee688314f5bf7173  policies/mutant_10_generated_policy.mjs  (355 bytes)
e6fd7239aa160fade47925d0c6d1db48b7b3a0a2bcc8e0b56ce8f3e388fafb3a  policies/mutant_10_recipe.json  (152 bytes)
b41d7696f870c3a43b5489b6f04ec5f8902eed89f51ee241fd6139334b96b6e7  policies/untrusted_rejected_example.js  (56 bytes)
93350627bd97605b4ea0762a88921682f8551ba7645619b75425eb0416b737fe  src/build_explorer.py  (12284 bytes)
56d26ced661f995ff2345813c0e6ea5a3644786fb2135b8f41948e94bc902258  src/colony_alpha.mjs  (5354 bytes)
5dda2ae3ea576a61d91beef6e50924a5003068041b59347ee8cbe5b04c56ae79  src/experiments.mjs  (6889 bytes)
22332149402d042ab5349d039d9ab80685ae8cd5ad58417c7783e008dc5f2d93  src/js_gate.mjs  (5322 bytes)
3233f37d35ab42a6bd71ba0d709e6f5ff497db37444138ce738ac290ae9659d4  src/policy_cli.mjs  (1783 bytes)
8af4b17a0b85b0615339506e848648f23e5c729a0c8acf67bdf163d453745c43  src/sensory_math.mjs  (5652 bytes)
00cfc741d2c91bf2e6697e83f6dd5b7746d771a6afed8a17468b53fa3f74e2e1  src/synthetic_sensor.mjs  (1551 bytes)
4dc7ee71a9ca6b19690a744af01c09ae8d919ffa7b24ac61439003318a076007  tests/alpha.test.mjs  (11114 bytes)
e67f7051cd6a6c71c79e1afc45f025a7d5276860f4362da1d13009609d28eee5  tests/browser_check.py  (1842 bytes)
````
