// Explicit synthetic camera/ToF training fixtures, generated from 2D/3D worlds.
// Sensor labels are available ONLY to the offline experiment scorer/trainer.
import {world,rnd} from '../legacy/hybrid_lab_v11_LOCKED.mjs';
const clip=(v,a=0,b=1)=>Math.min(b,Math.max(a,v));
export const PROFILES=['red','green','blue','gray','shifted'];
export function makeSamples(seed,dim=2,profile='red',{count=160,density=true}={}){
 if(!PROFILES.includes(profile)||![2,3].includes(dim)||!Number.isInteger(count)||count<1||count>5000)throw Error('samples params');
 const w=world(seed,dim),r=rnd(seed*2707+dim*71+PROFILES.indexOf(profile)*3);
 const free=w.cells.filter(c=>!c.blocked),wall=w.cells.filter(c=>c.blocked);if(!free.length||!wall.length)throw Error('empty class');
 const arr=[];
 for(let i=0;i<count;i++){
  const blocked=i%2===1, c=(blocked?wall:free)[Math.floor(r()*(blocked?wall.length:free.length))];
  let channels=[.48,.48,.48];let active=profile==='red'?0:profile==='green'?1:profile==='blue'?2:profile==='shifted'?0:-1;
  if(active>=0){channels[active]=blocked?(active===2?.87:.13):(active===2?.13:.87);}
  if(profile==='gray')channels=channels.map(()=>blocked?.23:.75);
  // intentionally opposite red-class relationship when shifted, modeling distribution shift
  if(profile==='shifted')channels[0]=blocked?.87:.13;
  const attenuation=density?Math.exp(-.62*c.density):1;
  const rgb=channels.map(v=>clip((v+(.16*(r()-.5)))*attenuation));
  arr.push({rgb,free:blocked?0:1,source:{seed,dim,profile,densityApplied:density}});
 }
 return arr;
}
