// Ripple Alpha v1.2 — closed-language JavaScript gate. No eval and no execution of arbitrary source.
// A recipe can come from internal mutation or outside the lab; only emitted audited templates execute.
import {createHash} from 'node:crypto';
const sha=x=>createHash('sha256').update(x).digest('hex');
const own=(o,k)=>Object.prototype.hasOwnProperty.call(o,k);
export const SCHEMA='ripple-js-policy/1';
export const DEFAULT_RECIPE=Object.freeze({schema:SCHEMA,lowEnergy:0.24,cloneNovelty:2,cloneDensityMax:0.65,scanFirst:true,shareFirst:false});
export function validateRecipe(x){
 if(!x||Array.isArray(x)||typeof x!=='object'||Object.keys(x).sort().join()!==Object.keys(DEFAULT_RECIPE).sort().join())throw Error('policy schema mismatch');
 if(x.schema!==SCHEMA)throw Error('policy schema mismatch');
 for(const [k,lo,hi] of [['lowEnergy',0,1],['cloneNovelty',0,5],['cloneDensityMax',0,1]])if(!Number.isFinite(x[k])||x[k]<lo||x[k]>hi)throw Error('policy numeric bounds '+k);
 if(!Number.isInteger(x.cloneNovelty))throw Error('clone novelty integer');
 for(const k of ['scanFirst','shareFirst'])if(typeof x[k]!=='boolean')throw Error('policy boolean '+k);
 return structuredClone(x);
}
// Output consists entirely of owned, nonlooping templates and validated numeric literals.
export function compileRecipe(x){
 const p=validateRecipe(x);
 const low=p.lowEnergy.toString(), novelty=p.cloneNovelty.toString(), density=p.cloneDensityMax.toString();
 const scan=`if (o.unknown) return 'SCAN';`;
 const share=`if (o.shareGap) return 'SHARE';`;
 const probe=p.scanFirst?[scan,share]:[share,scan];
 if(!p.shareFirst)probe.splice(probe.indexOf(share),1),probe.push(share);
 const code=`// GENERATED: ripple-js-policy/1; immutable shape; never edit manually.\nexport function decide(o) {\n`+
 ` if (o.energy < ${low}) return 'WAIT';\n`+
 ` if (o.novelty >= ${novelty} && o.density <= ${density} && o.population < o.cap && o.energy >= 0.7) return 'CLONE';\n`+
 probe.map(x=>' '+x+'\n').join('')+
 ` if (o.knownFree) return 'MOVE';\n return 'WAIT';\n}\n`;
 return {recipe:p,source:code,hash:sha(code),recipeHash:sha(JSON.stringify(p))};
}
export function stagePolicy(recipe,{externalSource=null}={}){
 const o=compileRecipe(recipe);return Object.freeze({...o,external:externalSource!==null,integrity:externalSource===null||externalSource===o.source?'match':'mismatch',status:'STAGED'});
}
export function reviewPolicy(staged,{operatorApproved=false,expectedHash}={}){
 if(!staged||staged.status!=='STAGED')throw Error('unstaged');
 const validated=compileRecipe(staged.recipe);
 if(validated.source!==staged.source||validated.hash!==staged.hash)throw Error('source tampered');
 if(staged.integrity!=='match')throw Error('outside JavaScript is not compiled allowlisted policy');
 if(!operatorApproved||expectedHash!==staged.hash)throw Error('operator review and exact hash required');
 return Object.freeze({...staged,status:'APPROVED'});
}
// Only compiled, already-approved *pure policy JS* is imported. No external source is interpreted.
export async function executePolicy(approved,observation){
 if(!approved||approved.status!=='APPROVED')throw Error('unapproved code');
 const rec=compileRecipe(approved.recipe);
 if(approved.source!==rec.source||approved.hash!==rec.hash)throw Error('post-approval tampering');
 if(!observation||typeof observation!=='object')throw Error('observation');
 const allowed=['energy','novelty','density','population','cap','unknown','shareGap','knownFree'];
 if(Object.keys(observation).some(k=>!allowed.includes(k))||allowed.some(k=>!own(observation,k)))throw Error('observation schema');
 if(allowed.slice(0,5).some(k=>!Number.isFinite(observation[k])))throw Error('observation numeric');
 if(allowed.slice(5).some(k=>typeof observation[k]!=='boolean'))throw Error('observation booleans');
 const url='data:text/javascript;charset=utf-8,'+encodeURIComponent(rec.source);
 const imported=await import(url);
 const result=imported.decide(Object.freeze({...observation}));
 if(!['SCAN','MOVE','SHARE','CLONE','WAIT'].includes(result))throw Error('unsupported decision');
 return result;
}
export function ledger(previousHash,kind,payload){
 if(typeof previousHash!=='string'||(previousHash!==''&&!/^[0-9a-f]{64}$/.test(previousHash)))throw Error('ledger parent');
 return {previousHash,kind,payload,hash:sha(JSON.stringify({previousHash,kind,payload}))};
}
export function verifyLedger(rows){let previousHash='';for(const row of rows){const expected=ledger(previousHash,row.kind,row.payload);if(row.previousHash!==previousHash||row.hash!==expected.hash)return false;previousHash=row.hash;}return true;}
// Research-only: execute generated policies in a read-only local trial, never promote/deploy them.
export async function loadLabPolicy(staged){
 if(!staged||staged.status!=='STAGED'||staged.external||staged.integrity!=='match')throw Error('only internal exact-template policy in lab');
 const rec=compileRecipe(staged.recipe);if(rec.hash!==staged.hash||rec.source!==staged.source)throw Error('lab policy altered');
 const mod=await import('data:text/javascript;charset=utf-8,'+encodeURIComponent(rec.source));
 return observations=>{
  const a=mod.decide(Object.freeze({...observations}));if(!['SCAN','MOVE','SHARE','CLONE','WAIT'].includes(a))throw Error('bad lab action');return a;
 };
}
