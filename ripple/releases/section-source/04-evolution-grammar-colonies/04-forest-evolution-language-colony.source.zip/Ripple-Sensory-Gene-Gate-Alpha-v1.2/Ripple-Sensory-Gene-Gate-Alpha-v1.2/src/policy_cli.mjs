// Stages and dry-runs strictly generated JS. No arbitrary downloaded JS executes.
import fs from 'node:fs';import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {stagePolicy,reviewPolicy,executePolicy} from './js_gate.mjs';
const [cmd,recipeFile,extra,...args]=process.argv.slice(2);
function help(){console.error('node src/policy_cli.mjs stage recipe.json [optional_external_js_file]\nnode src/policy_cli.mjs approved-dry-run recipe.json EXPECTED_SOURCE_SHA256 --i-reviewed');process.exitCode=2;}
try{
 if(!['stage','approved-dry-run'].includes(cmd)||!recipeFile)help();
 else{
  const recipe=JSON.parse(fs.readFileSync(recipeFile,'utf8'));
  if(cmd==='stage'){
   const source=extra?fs.readFileSync(extra,'utf8'):null;
   const stage=stagePolicy(recipe,{externalSource:source});
   console.log(JSON.stringify({state:stage.status,sourceHash:stage.hash,recipeHash:stage.recipeHash,externalExactMatch:stage.integrity,source:stage.source,notice:'No code executed. Arbitrary external JS is not allowed by this gate.'},null,2));
  }else{
   if(!/^[a-f0-9]{64}$/.test(extra??'')||!args.includes('--i-reviewed'))throw Error('explicit reviewed flag and exact hash required');
   const staged=stagePolicy(recipe);
   const approved=reviewPolicy(staged,{operatorApproved:true,expectedHash:extra});
   // Dry-run pure policy module only, never writes to the original project.
   const observations={energy:1,novelty:3,density:.3,population:2,cap:8,unknown:true,shareGap:false,knownFree:true};
   const action=await executePolicy(approved,observations);
   console.log(JSON.stringify({policyHash:approved.hash,approvedOnlyForThisLocalDryRun:true,action,observation:observations},null,2));
  }
 }
}catch(e){console.error('Gate rejected: '+e.message);process.exitCode=1;}
