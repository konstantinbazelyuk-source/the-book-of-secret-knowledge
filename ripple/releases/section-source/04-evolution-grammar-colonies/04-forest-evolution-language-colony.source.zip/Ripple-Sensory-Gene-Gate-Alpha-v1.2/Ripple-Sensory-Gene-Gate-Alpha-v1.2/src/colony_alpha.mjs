// New Alpha colony, separate from preserved v1.1. Pulse-gated decisions plus verified emitted JS policies.
import {createRequire} from 'node:module';
import {world,ray,rnd,colorClass,marker} from '../legacy/hybrid_lab_v11_LOCKED.mjs';
import {opticalGate,birthProbability,inheritGene,initGene} from './sensory_math.mjs';
import {stagePolicy,DEFAULT_RECIPE,loadLabPolicy} from './js_gate.mjs';
const require=createRequire(import.meta.url),{RippleNeuron}=require('../legacy/ripple_mycelium_v05_LOCKED.js');
const directions=(dim)=>dim===2?[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0]]:[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]];
const key=p=>p.join(',');
const cell=(w,p)=>{if(p.some((v,i)=>v<0||v>=[w.width,w.height,w.depth][i]))return null;return w.cells[(p[2]*w.height+p[1])*w.width+p[0]];};
const clamp=(n,a,b)=>Math.min(b,Math.max(a,n));
export async function runColony({seed=1,dim=2,steps=85,vision=true,depth=true,density=true,replicate=true,rule=DEFAULT_RECIPE,mode='sensory',cap=8,originGene=initGene()}={}){
 if(![2,3].includes(dim)||!Number.isInteger(seed)||seed<=0||steps<1||steps>300||cap<1||cap>16||!['sensory','basal'].includes(mode))throw Error('sim bounds');
 const staged=stagePolicy(rule),decide=await loadLabPolicy(staged),w=world(seed,dim),r=rnd(seed*919+dim*17);
 let nextId=0,scans=0,births=0,events=0,blockedAttempts=0,transfers=0;
 const population=[],all=[],seenGlobal=new Map(),paths=[],birthTrace=[];
 function born(g,parent=null,pos=[1,1,0],t=0){const n={id:nextId++,parentId:parent?.id??null,g:{color:[...g.color],bias:g.bias,invert:[...(g.invert??[false,false,false])]},neuron:new RippleNeuron(),known:new Map(),pos:[...pos],energy:1.3,age:0,novelty:0,active:true};population.push(n);all.push(n);births++;paths.push({id:n.id,trace:[]});birthTrace.push({t,id:n.id,parentId:n.parentId,genomeHash:marker({color:n.g.color,bias:n.g.bias,invert:n.g.invert,parent:n.parentId}),color:[...g.color],invert:[...n.g.invert],colorClass:colorClass(g.color)});return n;}
 born(originGene);
 for(let t=0;t<steps;t++){
  for(const n of [...population]){
   const current=cell(w,n.pos);if(!current||current.blocked)throw Error('wall intrusion');
   const optical=current.rgb; // synthetic local sensor, no remote map lookup here
   const gated=mode==='sensory'?opticalGate(optical,n.g.color,{vision:true,density:density&&t>=Math.floor(steps/2)?current.density:0,occlusion:0,invert:n.g.invert}):optical;
   const out=n.neuron.step(gated,.25);events+=out.count;
   const dirs=directions(dim);
   const unknown=vision&&dirs.some(d=>{const q=n.pos.map((v,i)=>v+d[i]);return cell(w,q)&&!n.known.has(key(q));});
   const knownFree=dirs.some(d=>{const q=n.pos.map((v,i)=>v+d[i]);return n.known.get(key(q))===false;});
   const shareGap=population.some(other=>other!==n&&other.known.size<n.known.size&&Math.max(...other.pos.map((v,i)=>Math.abs(v-n.pos[i])))<=1);
   let novelty=n.novelty;
   const observations={energy:n.energy,novelty,density:density&&t>=Math.floor(steps/2)?current.density:0,population:population.length,cap,unknown,knownFree,shareGap};
   let action=out.count?decide(observations):'WAIT';
   if(!vision&&action==='SCAN')action='WAIT';if(!replicate&&action==='CLONE')action='WAIT';
   if(action==='SCAN'){
    scans++;let discoveries=0;
    for(const d of dirs){
     const rayResult=ray(w,n.pos,d,depth?3:1,{occlusion:true,depth,density:density&&t>=Math.floor(steps/2)});
     for(const item of rayResult.records){const p=[item.x,item.y,item.z],k=key(p);if(!n.known.has(k))discoveries++;n.known.set(k,false);seenGlobal.set(k,false);}
     if(rayResult.hit==='solid'){const p=n.pos.map((v,i)=>v+d[i]*rayResult.rangeSteps),k=key(p);if(!n.known.has(k))discoveries++;n.known.set(k,true);seenGlobal.set(k,true);}
    }
    n.novelty=clamp(discoveries,0,5);
   }
   if(action==='MOVE'){
    const candidates=dirs.map(d=>n.pos.map((v,i)=>v+d[i])).filter(p=>n.known.get(key(p))===false);
    if(candidates.length){const chosen=candidates[Math.floor(r()*candidates.length)];const c=cell(w,chosen);if(c&&!c.blocked)n.pos=chosen;else blockedAttempts++;}
   }
   if(action==='SHARE'){
    const rec=population.find(other=>other!==n&&Math.max(...other.pos.map((v,i)=>Math.abs(v-n.pos[i])))<=1);
    if(rec){for(const [k,v] of n.known){if(!rec.known.has(k)){rec.known.set(k,v);transfers++;break;}}}
   }
   if(action==='CLONE'&&replicate&&population.length<cap&&n.energy>.7&&t%3===0){
    const p=mode==='sensory'?birthProbability({bias:.3,novel:n.novelty,uncertainty:n.known.size?1/Math.sqrt(n.known.size):1,density:observations.density,crowding:(population.length-1)/cap,energy:n.energy,sensorEnabled:vision}):.3;
    if(r()<p){n.energy-=.25;born(inheritGene(n.g,r),n,n.pos,t);}
   }
   n.energy=clamp(n.energy-.01+.008*current.resource,0,2.5);
   n.novelty=clamp(n.novelty-.3,0,5);
   paths.find(p=>p.id===n.id).trace.push({t,pos:[...n.pos],action,spikes:out.count,theta:out.theta});
   n.age++;
  }
 }
 const free=w.cells.filter(c=>!c.blocked).length;
 const seen=[...seenGlobal].filter(([k,occupied])=>!occupied).length;
 const result={schema:'ripple-colony-gate-alpha/1',seed,dim,steps,mode,policyHash:staged.hash,flags:{vision,depth,density,replicate},metrics:{created:births,alive:population.length,scans,events,seenFree:seen,coverage:seen/free,transfers,blockedAttempts},birthTrace,paths};
 result.hash=marker(result);return result;
}
