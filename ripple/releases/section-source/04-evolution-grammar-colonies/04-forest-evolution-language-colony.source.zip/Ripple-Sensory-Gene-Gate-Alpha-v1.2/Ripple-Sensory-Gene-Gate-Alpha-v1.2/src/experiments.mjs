import fs from 'node:fs';
import {makeSamples,PROFILES} from './synthetic_sensor.mjs';
import {trainGene,scoreGene,trainPolarityFamily,inheritGene,initGene,birthProbability} from './sensory_math.mjs';
import {DEFAULT_RECIPE,stagePolicy,ledger,verifyLedger} from './js_gate.mjs';
import {runColony} from './colony_alpha.mjs';
import {run as oldRun,FEATURES,rnd} from '../legacy/hybrid_lab_v11_LOCKED.mjs';
const BASE=new URL('../data/',import.meta.url);const save=(name,x)=>fs.writeFileSync(new URL(name,BASE),JSON.stringify(x,null,2)+'\n');
const dt='deterministic-study-1.2';
let experiments=[];
for(const profile of PROFILES){
 for(const dim of [2,3]){
  const training=[1,2,3,4,5,6,7,8].flatMap(seed=>makeSamples(seed,dim,profile,{count:160}));
  const heldout=[61,62,63,64,65,66,67,68].flatMap(seed=>makeSamples(seed,dim,profile,{count:160}));
  const reference=trainGene(training,{epochs:4,adapt:false}),colorOnly=trainGene(training,{epochs:4,adapt:true}),family=trainPolarityFamily(training,{epochs:4});
  const models=[['locked_sign_fixed_color',reference],['learned_color_locked_sign',colorOnly],['mutated_polarity_and_color',family.selected.gene]];
  for(const [name,gene] of models)experiments.push({profile,dimension:dim,name,train:scoreGene(training,gene),heldout:scoreGene(heldout,gene),gene});
 }
}
// Explicit out-of-distribution failure: reversed-red sensor semantics versus the original red profile.
const shiftedTraining=[1,2,3,4,5].flatMap(seed=>makeSamples(seed,2,'shifted',{count:150}));
const shiftedGene=trainPolarityFamily(shiftedTraining,{epochs:4}).selected.gene;
const baseShift=trainGene(shiftedTraining,{epochs:4,adapt:false});
const redOOD=[71,72,73].flatMap(seed=>makeSamples(seed,3,'red',{count:150}));
const shiftedHold=[71,72,73].flatMap(seed=>makeSamples(seed,3,'shifted',{count:150}));
const distributionShift={trainedOn:'shifted',evaluations:[
 {test:'matched_shifted',fixed:scoreGene(shiftedHold,baseShift),mutated:scoreGene(shiftedHold,shiftedGene)},
 {test:'reversed_back_to_red',fixed:scoreGene(redOOD,baseShift),mutated:scoreGene(redOOD,shiftedGene)}],gene:shiftedGene};
const policyVariants={
 sensory_default:{...DEFAULT_RECIPE},
 conservative:{...DEFAULT_RECIPE,cloneNovelty:4,cloneDensityMax:.35},
 clone_eager:{...DEFAULT_RECIPE,cloneNovelty:0,cloneDensityMax:1},
 share_before_scan:{...DEFAULT_RECIPE,shareFirst:true,scanFirst:false},
 no_early_clone:{...DEFAULT_RECIPE,cloneNovelty:5},
 density_sensitive:{...DEFAULT_RECIPE,cloneNovelty:2,cloneDensityMax:.2},
 scan_priority:{...DEFAULT_RECIPE,cloneNovelty:5,scanFirst:true},
 low_energy_care:{...DEFAULT_RECIPE,lowEnergy:.72,cloneNovelty:3},
};
const colony=[];const baseline=[];const snapshots=[];
for(const dim of [2,3])for(const seed of [20,21,22,23,24,25,26,27,28,29]){
 const prior=oldRun({seed,dim,steps:80,maxPopulation:8});baseline.push({seed,dim,metrics:prior.metrics});
 for(const [name,recipe] of Object.entries(policyVariants)){
  const simulated=await runColony({seed,dim,steps:80,rule:recipe,cap:8,mode:'sensory'});
  colony.push({seed,dim,name,metrics:simulated.metrics,hash:simulated.hash,policyHash:simulated.policyHash});
  if(seed===20)snapshots.push({seed,dim,name,metrics:simulated.metrics,birthTrace:simulated.birthTrace,paths:simulated.paths});
 }
 const basal=await runColony({seed,dim,steps:80,mode:'basal'});
 const noVision=await runColony({seed,dim,steps:80,vision:false});
 const noClones=await runColony({seed,dim,steps:80,replicate:false});
 colony.push({seed,dim,name:'basal_fixed_birth',metrics:basal.metrics,hash:basal.hash},
 {seed,dim,name:'no_vision',metrics:noVision.metrics,hash:noVision.hash},
 {seed,dim,name:'no_replication',metrics:noClones.metrics,hash:noClones.hash});
}
// bounded, variable policy mutation; archival purpose is phenotype diversity.
const r=rnd(8082);const generated=[];for(let i=0;i<24;i++){
 const recipe={...DEFAULT_RECIPE,lowEnergy:Number((.05+.67*r()).toFixed(3)),cloneNovelty:Math.floor(6*r()),cloneDensityMax:Number((.1+.9*r()).toFixed(3)),scanFirst:r()>.5,shareFirst:r()>.5};
 const staged=stagePolicy(recipe);const trials=[];for(const seed of [7,8,9,10,71,72]){
  const run=await runColony({seed,dim:seed%2?3:2,steps:75,rule:recipe});trials.push({seed,holdout:seed>=70,metrics:run.metrics});}
 generated.push({index:i,recipe,policyHash:staged.hash,source:staged.source,train:trials.filter(x=>!x.holdout),heldout:trials.filter(x=>x.holdout)});
}
const agg=(rows,field)=>rows.reduce((v,r)=>v+r.metrics[field],0)/rows.length;
const summary=Object.keys({...policyVariants,basal_fixed_birth:1,no_vision:1,no_replication:1}).map(name=>{const runs=colony.filter(x=>x.name===name);return {name,trials:runs.length,coverage:agg(runs,'coverage'),created:agg(runs,'created'),scans:agg(runs,'scans'),transfers:agg(runs,'transfers'),events:agg(runs,'events')};}).sort((a,b)=>b.coverage-a.coverage);
let chain=[];for(const item of [{kind:'SOURCE',payload:{name:'v1.1 LIF',hash:'d75d4208e92f19623b127615bd52b4002e85d2c0a59b76471764b55a24294210'}},{kind:'CALIBRATION',payload:{examples:experiments.length}},{kind:'PHENOTYPE',payload:{trials:colony.length}},{kind:'POLICY_MUTATIONS',payload:{n:generated.length}}])chain.push(ledger(chain.at(-1)?.hash??'',item.kind,item.payload));
if(!verifyLedger(chain))throw Error('invalid ledger');
save('sensory_study.json',{schema:'ripple-alpha-sensory-study/1',buildId:dt,notes:'Synthetic labeled sensors, 8 train seeds and independent 8 holdout seeds per dimension/profile. No camera measurements.',experiments});
save('colony_study.json',{schema:'ripple-alpha-colony-study/1',buildId:dt,notes:'Same 20 world seeds across policy families. v1.1 included for continuity; action policies differ so not a controlled head-to-head speed benchmark.',baseline,colony,summary});
save('mutated_js_policies.json',{schema:'ripple-js-policy-evolution/1',generated});
save('specimen_paths.json',{snapshots});
save('ledger.json',{chain});
const summaryModel=PROFILES.map(profile=>{
 const subset=experiments.filter(e=>e.profile===profile);
 return {profile,methods:subset.filter(e=>e.dimension===3).map(e=>({name:e.name,brier:e.heldout.brier,accuracy:e.heldout.accuracy,color:e.gene.color,inversion:e.gene.invert}))};
});
save('distribution_shift.json',distributionShift);
save('summary.json',{buildId:dt,sensorTrials:experiments.length,distributionShift,calibrationTrainingExamples:PROFILES.length*2*8*160,calibrationHoldoutExamples:PROFILES.length*2*8*160,colonyTrials:colony.length,policyCandidates:generated.length,policyEvaluations:generated.length*6,summaryModel,colonySummary:summary,reference:'Original Ripple unchanged. Subjective objective not used to claim general intelligence.'});
console.log(JSON.stringify({sensorTrialModels:experiments.length,colonyTrials:colony.length,policyCandidates:generated.length,policyEvaluations:generated.length*6,model:summaryModel,top:summary.slice(0,5)},null,2));
