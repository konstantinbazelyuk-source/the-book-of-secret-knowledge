// Ripple Alpha v1.2: numeric phenotype adaptation, not modification of the locked v0.1 neuron.
export const BASE_WEIGHTS=[2,1.2,-1.4];
const clip=(x,a,b)=>Math.max(a,Math.min(b,x));
const sum=a=>a.reduce((s,v)=>s+v,0);
export function validateColor(c){if(!Array.isArray(c)||c.length!==3||c.some(v=>!Number.isFinite(v)||v<0||v>1)||Math.abs(sum(c)-1)>1e-8)throw Error('color gene invalid');return c;}
export function opticalGate(raw,color,features={}){
 validateColor(color);if(!Array.isArray(raw)||raw.length!==3||raw.some(x=>!Number.isFinite(x)||x<0||x>1))throw Error('optical reading invalid');
 const enabled=features.vision!==false;
 const invert=features.invert??[false,false,false];
 if(!Array.isArray(invert)||invert.length!==3||invert.some(x=>typeof x!=='boolean'))throw Error('invalid inversion gene');
 const reliability=features.reliability??1, density=features.density??0, occlusion=features.occlusion??0;
 if(![reliability,density,occlusion].every(x=>Number.isFinite(x)&&x>=0&&x<=1))throw Error('invalid quality flags');
 // Density / occlusion attenuate the sensor, not the original LIF core. This is a hypothesis.
 const T=enabled?clip(reliability*Math.exp(-0.7*density-1.3*occlusion),0,1):0;
 return raw.map((v,i)=>clip((invert[i]?1-v:v)*3*color[i]*T,0,1));
}
export function driveFromColor(raw,color,flags={}){const x=opticalGate(raw,color,flags);return sum(x.map((v,i)=>v*BASE_WEIGHTS[i]));}
export function logit(raw,color,bias=-.2,invert=[false,false,false]){ // same signed channels as the original, learned scalar decision head
 const x=opticalGate(raw,color,{invert});return clip(bias+sum(x.map((v,i)=>v*BASE_WEIGHTS[i])),-15,15);
}
export function sigmoid(v){return 1/(1+Math.exp(-clip(v,-30,30)));}
export function predict(raw,g){return sigmoid(logit(raw,g.color,g.bias,g.invert??[false,false,false]));}
export function initGene(color=[.44,.35,.21],bias=-.3,invert=[false,false,false]){validateColor(color);if(!Number.isFinite(bias)||bias< -10||bias>10||!Array.isArray(invert)||invert.length!==3||invert.some(x=>typeof x!=='boolean'))throw Error('bad gene');return {color:[...color],bias,invert:[...invert]};}
// Exponentiated-gradient simplex projection with drift-to-parent regularization.
// The labels are from explicit offline training examples, NEVER inferred hidden live world truth.
export function updateGene(g,raw,label,{lr=.12,biasRate=.04,regularization=.012,anchor=[.44,.35,.21]}={}){
 validateColor(g.color);validateColor(anchor);if(!(label===0||label===1)||!Number.isFinite(lr)||lr<0||lr>1||!Number.isFinite(regularization)||regularization<0||regularization>1)throw Error('update invalid');
 const p=predict(raw,g),e=p-label;
 const interpreted=raw.map((v,i)=>g.invert?.[i]?1-v:v);
 const logits=g.color.map((x,i)=>Math.log(Math.max(x,1e-8))-lr*(e*(3*x*interpreted[i]<1?3*BASE_WEIGHTS[i]*interpreted[i]:0)+regularization*Math.log(Math.max(x,1e-8)/Math.max(anchor[i],1e-8))));
 const shift=Math.max(...logits),a=logits.map(v=>Math.exp(v-shift)),s=sum(a);
 // reserve a minimum inherited channel fraction so all three channels remain usable
 const color=a.map(v=>.003+(1-.009)*v/s);
 return {...g,color,bias:clip(g.bias-biasRate*e,-6,6)};
}
export function trainGene(examples,{color=[.44,.35,.21],epochs=3,lr=.12,adapt=true,invert=[false,false,false]}={}){
 if(!Array.isArray(examples)||examples.length<1||epochs<1||epochs>30)throw Error('training');
 let g=initGene(color,-.3,invert);for(let ep=0;ep<epochs;ep++)for(const ex of examples){if(adapt)g=updateGene(g,ex.rgb,ex.free,{lr});else{const e=predict(ex.rgb,g)-ex.free;g={...g,bias:clip(g.bias-.04*e,-6,6)};}}
 return g;
}
export function scoreGene(examples,g){let brier=0,correct=0,logLoss=0;for(const ex of examples){const p=predict(ex.rgb,g);brier+=(p-ex.free)**2;correct+=Number((p>=.5)===Boolean(ex.free));logLoss+=-ex.free*Math.log(Math.max(1e-10,p))-(1-ex.free)*Math.log(Math.max(1e-10,1-p));}return {n:examples.length,accuracy:correct/examples.length,brier:brier/examples.length,logLoss:logLoss/examples.length};}
export function birthProbability({bias=.45,novel=0,uncertainty=0,density=0,crowding=0,energy=1,sensorEnabled=true}={}){
 if(![bias,novel,uncertainty,density,crowding,energy].every(Number.isFinite)||density<0||density>1||uncertainty<0||uncertainty>1||crowding<0||crowding>1||bias<=0||bias>=1)throw Error('birth state');
 // New explicit hypothesis. Logit biology-inspired resource control, not physical reproduction.
 const basal=Math.log(bias/(1-bias));
 const sensory=sensorEnabled?1.2*clip(novel,0,4)+.55*uncertainty:0;
 return sigmoid(basal + sensory - 1.6*density - 1.5*crowding - 1.8*Math.max(0,1-energy));
}
export function allowedBirth(state,draw){if(!Number.isFinite(draw)||draw<0||draw>=1)throw Error('randomness');return draw<birthProbability(state);}
export function inheritGene(parent,draw,scale=.05){validateColor(parent.color);if(typeof draw!=='function'||scale<0||scale>.5)throw Error('inherit args');const w=parent.color.map(v=>Math.max(.003,v+scale*(draw()-.5)));const s=sum(w);const invert=(parent.invert??[false,false,false]).map(v=>draw()<.025?!v:v);return {color:w.map(v=>v/s),bias:clip(parent.bias+scale*(draw()-.5),-6,6),invert};}

// Enumerated polarity "mutations", evaluated on training data only before a reserved holdout.
export function trainPolarityFamily(train,options={}){
 const candidates=[];for(let bits=0;bits<8;bits++){const invert=[0,1,2].map(i=>Boolean(bits&(1<<i)));const gene=trainGene(train,{...options,invert});candidates.push({gene,training:scoreGene(train,gene),bits});}
 candidates.sort((a,b)=>a.training.brier-b.training.brier||a.bits-b.bits);
 return {selected:candidates[0],candidates};
}
