# Ripple Open-Grammar Colony Alpha v1.6

**Status:** executed, reproducible local research software. **Not** independently intelligent software, verified cryptanalysis, physical optics, or a deployed cloud service.

## Purpose

Attempt a stronger test than v1.5: can a colony whose programs were originally limited to 193 four-bit mappings propose new expressions when unseen examples contradict its fixed grammar? Can it recognize that its photon decoder no longer represents a shifted or information-poor sensor? Does any accuracy advantage come from Ripple, or from conventional mathematical algorithms?

## Verified result and limits

- Exact archived v0.1 LIF core, v0.7 quaternary codec and v1.4 optics are copied byte-for-byte. An archived v1.5 hypothesis/decoder program is carried separately as a frozen baseline, with its original 193 rules.
- **New finite, typed grammar:** 135 semantic mappings, for 328 total. Includes bit masks, multiplication modulo 16, bit shifts, popcount, parity mask, swap-middle bits and multiplication followed by modular addition.
- **Original colony:** five independent LIF objects and at most one independent clone for a bounded expansion. All pulse events are actual calls to the original mathematical kernel. The clones do not perform parallel operating-system work.
- **Synthetic evaluation:** 10 rule families × 4 training/evaluation seeds × 3 photon budgets × 3 channel conditions = 360 cases. Four solver settings give 1,440 evaluations; test inputs comprise six previously hidden values per task. The generator maintains separate training/held-out input indices.
- **Independent reliability validation:** 10 × 2 **new** seeds × 3 photon budgets × 3 channel conditions = 180 additional cases, with three predeclared comparisons (540 decisions). The reliability gate threshold was selected after inspecting the first dataset and before generating/using the second; the latter supports only a limited in-distribution validation claim.
- **External public vectors:** Cryptopals Set 1 Challenges 1, 2 and 6, as plain arithmetic correctness tests. Neither security nor decoding skill is inferred.

## Important results

| Primary 360 cases | Exact rule | All held-out candidate outputs | Accepted results |
|---|---:|---:|---:|
| Fixed 193 functions | 7.78% | 13.33% | 47 |
| Adaptive 328 when needed | 38.33% | 31.06% | 130 |
| Always expanded 328 | 41.11% | 32.73% | 119 |
| Conventional serial expanded | 41.11% | 32.73% | 119 |

The all-case candidate outputs include **provisional predictions even on cases that abstain**: they must not be mistaken for actual approved answers. On clean matched conditions, accepted-answer accuracy is 77.95% for adaptive and 84.52% for fully expanded, each conditioned on their differing acceptance coverage.

**Independent seeds 555/666:** ungated adaptive accepted 62/180, with 69.62% accuracy on 372 corresponding held-out outputs. Reliability-gated accepted 36/180, with 92.13% accuracy on 216 corresponding held-out outputs. Serial and colony versions were identical. The additional abstention means no claim of greater overall completeness.

See `docs/EXPERIMENTAL_FINDINGS.md` for failures, non-identifiability and source evidence.

## Execute

From extracted package root (Node.js 20+, Python 3.11+, NumPy, optional Playwright + system Chromium for browser checks):

```bash
node --test tests/test_engine.mjs
python -m unittest discover -s tests -p 'test_physics.py' -v
node src/evaluate.mjs
node src/validate_holdout.mjs
python src/generate_cases.py                # Regenerates 360 primary cases
python src/generate_cases.py --holdout      # Generates 180 held-out cases
python src/build_lab.py
python tests/browser_check.py               # Optional installed Playwright + Chromium
```

**Order:** Regenerate fixed-seed cases first (if desired), then rerun the evaluations, then build the browser lab. Run the test suites against the fixed saved fixtures at any time. Saving the program results overwrites generated reports **within this extracted package only**, not previous Ripple versions. The offline HTML visualizes saved calculations and does not execute arbitrary generated JS.

Open `Ripple-Open-Grammar-Colony-Alpha-v1.6.html` in a browser. It replays numerical study records and provides selectors, not live program synthesis.

## Source lineage

- `sources/v01_ripple_core_LOCKED.cjs`: SHA256 `d75d4208e92f19623b127615bd52b4002e85d2c0a59b76471764b55a24294210`
- `sources/v07_quaternary_core_LOCKED.mjs`: SHA256 `9c1879f6bc024e564e5e25b0294ac62b34d67aafffe26f9ddfae52675d66f695`
- `sources/v14_physics_LOCKED.py`: SHA256 `910bab2c583fd50c5250226f8bd81b9c477c5f6de921be7892a4575bacd17b51`
- `src/v15_control_LOCKED.mjs`: copied exact v1.5 colony source, which implements the original 193 mappings.

The extended grammar, inference, tests, reports, and lab are new experimental files. They do not overwrite v1.5 or earlier Ripple packages.

## Security and privacy boundaries

No eval, Function, dynamic module loading of untrusted user-supplied scripts, network calls, wallets, files from outside the package or account actions occur in the experiment engine. Genome growth means adding one authorized finite specialist. The `src/grammar.mjs` constructors are human-written operation templates; the colony is not self-modifying unrestricted JavaScript or a trained AI system. No external project was published or deployed.

The `.github/workflows/manual_ripple_alpha.yml` is a **proposed, manual-only** cloud test workflow for later user-approved publication; it is not installed on GitHub. Any cloud-hosted run remains subject to the operator's own account controls, usage limits and billing.
