/** Public, static Cryptopals Set 1 byte-arithmetic examples; no claim of cryptographic security. */
export function xorBytes(a,b){
 if(!(a instanceof Uint8Array)||!(b instanceof Uint8Array)||a.length!==b.length)throw Error('equal-length byte buffers required');
 return Uint8Array.from(a,(v,i)=>v^b[i]);
}
export function hexToBase64(hex){
 if(typeof hex!=='string'||hex.length%2||!/^[0-9a-f]*$/i.test(hex))throw Error('invalid hex');
 return Buffer.from(hex,'hex').toString('base64');
}
export function hamming(a,b){
 if(!(a instanceof Uint8Array)||!(b instanceof Uint8Array)||a.length!==b.length)throw Error('equal-length byte buffers required');
 let count=0;for(let i=0;i<a.length;i++){let t=a[i]^b[i];while(t){count++;t&=t-1;}}return count;
}
