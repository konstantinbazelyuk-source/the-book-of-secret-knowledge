from pathlib import Path
import json,hashlib,zipfile
ROOT=Path(__file__).resolve().parents[1]
R=json.loads((ROOT/'data/report.json').read_text())
H=json.loads((ROOT/'data/holdout_report.json').read_text())
lines=['# Ripple Open-Grammar Colony Alpha v1.6 — Evidence Manifest','','Archive classification: independent numerical research Alpha; no real optical receiver, cloud execution or biological intelligence.','',
  f'- Primary synthetic cases: **360**, 4 solver variants = **{R["trials"]}** evaluations.',
  '- Follow-up synthetic cases: **180**, 3 solver variants = **540** additional evaluations.',
  f'- Grammar expansion: **{R["grammar"]["base"]} original + {R["grammar"]["added"]} novel relative to v1.5 = {R["grammar"]["total"]}** functions.',
  '- Source validation: **24/24 new JavaScript tests; 6/6 existing optical-physics tests**.',
  '- Browser: headless Chromium desktop 1280px / phone 390px passed interaction and overflow checks.',
  '- Legacy neuron/encoder/optics: unchanged SHA-256 in `sources/`.',
  '- Public arithmetic references: Cryptopals #1, #2, Hamming test from #6 passed.',
  '', '## Reserved-new-seed acceptance','', '| Variant | Accepted | Accuracy given acceptance | Not answered |','|---|---:|---:|---:|']
for x in H['summary']:
 lines.append(f'|{x["variant"]}|{x["accepted"]}/180|{x["acceptedHeldoutAccuracyPct"]:.2f}%|{x["abstained"]}|')
lines+=['','**Caution:** acceptance-conditioned accuracy is not total capability; both new-seed groups use the same synthetic optics generator and none are physical measurements.',
'', '## Source checksum catalog', '', 'Each hash is SHA-256 of the exact file bytes. Do not edit locked archived sources.','']
files=[]
for p in sorted(ROOT.rglob('*')):
 if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.pyc' or p.name in {'SHA256SUMS.txt','MANIFEST.md'}:continue
 files.append(p)
checksum_lines=[]
for p in files:
 rel=p.relative_to(ROOT).as_posix();checksum_lines.append(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {rel}')
(ROOT/'SHA256SUMS.txt').write_text('\n'.join(checksum_lines)+'\n')
lines+=['```text']+checksum_lines+['```']
(ROOT/'MANIFEST.md').write_text('\n'.join(lines)+'\n')
archive=ROOT.parent/(ROOT.name+'.zip')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as z:
 for p in sorted(ROOT.rglob('*')):
  if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.pyc':continue
  z.write(p,arcname=f'{ROOT.name}/{p.relative_to(ROOT).as_posix()}')
with zipfile.ZipFile(archive) as z:
 bad=z.testzip();assert bad is None,bad
print(json.dumps({'zip':str(archive),'zipBytes':archive.stat().st_size,'zipSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':len(files)+2,'archiveIntegrity':'OK'},indent=2))
