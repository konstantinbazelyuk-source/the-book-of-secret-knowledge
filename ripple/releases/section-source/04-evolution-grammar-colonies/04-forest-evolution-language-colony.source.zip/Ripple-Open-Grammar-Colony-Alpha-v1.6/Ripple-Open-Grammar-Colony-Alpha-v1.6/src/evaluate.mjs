import fs from 'node:fs';
import {performance} from 'node:perf_hooks';
import {analyze,grammarCounts,statHash} from './engine.mjs';
const path=new URL('../data/cases.json',import.meta.url);
const all=JSON.parse(fs.readFileSync(path)).cases;
const methods={fixed:{mode:'fixed',withColony:true},adaptive:{mode:'adaptive',withColony:true},expanded:{mode:'expanded',withColony:true},serial_expanded:{mode:'expanded',withColony:false}};
const rows=[],times={};
for(const [name,options] of Object.entries(methods)){
 const t=performance.now();for(const d of all)rows.push({...analyze(d,options),variant:name});
 times[name]=Number((performance.now()-t).toFixed(2));
 console.log(name,times[name]+'ms');
}
function group(keys){let map=new Map();for(const r of rows){const k=keys.map(k=>r[k]).join('|');if(!map.has(k))map.set(k,[]);map.get(k).push(r);}
 return [...map].map(([key,a])=>({key,count:a.length,exactPct:100*a.filter(x=>x.exact).length/a.length,
  heldoutPct:100*a.reduce((s,x)=>s+x.correct,0)/a.reduce((s,x)=>s+x.heldout,0),
  supportedPct:100*a.filter(x=>x.decision==='SUPPORTED').length/a.length,
  falseSupportPct:100*a.filter(x=>x.kind==='unknown_permutation'&&x.decision==='SUPPORTED').length/Math.max(1,a.filter(x=>x.kind==='unknown_permutation').length),
  expansionPct:100*a.filter(x=>x.expanded).length/a.length,
  inventedPct:100*a.filter(x=>x.newPrimitive&&x.decision==='SUPPORTED').length/a.length,
  abstentions:a.filter(x=>x.decision.startsWith('ABSTAIN')).length}));}
const e=(kind,condition='matched',photon=80,seed=111)=>all.find(x=>x.kind===kind&&x.condition===condition&&x.photons_per_bit===photon&&x.seed===seed);
const detailed=['mul3_plus1','popcount','parity_broadcast','and_0b','unknown_permutation','control_xor7'].map(kind=>analyze(e(kind),{mode:'adaptive',withColony:true,detailed:true}));
const report={schema:'ripple-open-grammar-study/1',source:'v0.1 LIF + v0.7 codec + v1.4 optical sampling + v1.5 baseline',
 grammar:grammarCounts(),trials:all.length*Object.keys(methods).length,
 interpretation:'Finitely enumerated program synthesis with optically noisy examples; no general intelligence claim',
 methods,timesMs:times,groups:{variant:group(['variant']),kindVariant:group(['kind','variant']),conditionVariant:group(['condition','variant']),photonVariant:group(['photons','variant']),kindConditionVariant:group(['kind','condition','variant'])},detailed,rows};
fs.writeFileSync(new URL('../data/report.json',import.meta.url),JSON.stringify(report,null,2));
console.log(JSON.stringify({grammar:report.grammar,trials:report.trials,variant:report.groups.variant,condition:report.groups.conditionVariant,hash:statHash(report)},null,2));
