import fs from 'node:fs';
import {analyze,statHash} from './engine.mjs';
const d=JSON.parse(fs.readFileSync(new URL('../data/holdout_cases.json',import.meta.url))).cases;
const variants={original_adaptive:{mode:'adaptive',withColony:true,minReliability:0},
 gated_adaptive:{mode:'adaptive',withColony:true,minReliability:.65},
 gated_serial:{mode:'adaptive',withColony:false,minReliability:.65}};
const all=[];
for(const [variant,params] of Object.entries(variants))for(const task of d)all.push({...analyze(task,params),variant});
const stats=(a)=>{const accepted=a.filter(x=>x.decision==='SUPPORTED');return {
 tasks:a.length,accepted:accepted.length,abstained:a.length-accepted.length,
 acceptedPct:100*accepted.length/a.length,acceptedHeldoutAccuracyPct:accepted.length?100*accepted.reduce((s,x)=>s+x.correct,0)/(6*accepted.length):null,
 acceptedExactPct:accepted.length?100*accepted.filter(x=>x.exact).length/accepted.length:null,
 falseAcceptedUnknown:accepted.filter(x=>x.kind==='unknown_permutation').length,
 rawCandidateHeldoutPct:100*a.reduce((s,x)=>s+x.correct,0)/(6*a.length)
};};
const group=(field)=>[...new Set(all.map(x=>x[field]))].flatMap(v=>Object.keys(variants).map(variant=>({[field]:v,variant,...stats(all.filter(x=>x.variant===variant&&x[field]===v))})));
const report={schema:'ripple-open-grammar-holdout/1',seeds:[555,666],guardSelection:'0.65 joint-posterior criterion selected AFTER initial 4 seeds, BEFORE these two new seeds',
 summary:group('variant').filter(x=>x.variant===x.variant), byCondition:group('condition'),byKind:group('kind'),byPhoton:group('photons'),results:all};
// summary only three variants (avoid duplicate)
report.summary=Object.keys(variants).map(v=>({variant:v,...stats(all.filter(x=>x.variant===v))}));
fs.writeFileSync(new URL('../data/holdout_report.json',import.meta.url),JSON.stringify(report,null,2));
console.log(JSON.stringify({summary:report.summary,byCondition:report.byCondition,sha256:statHash(report)},null,2));
