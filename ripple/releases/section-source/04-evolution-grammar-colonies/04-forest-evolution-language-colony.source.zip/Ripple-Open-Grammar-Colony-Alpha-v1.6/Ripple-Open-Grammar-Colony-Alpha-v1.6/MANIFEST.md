# Ripple Open-Grammar Colony Alpha v1.6 — Evidence Manifest

Archive classification: independent numerical research Alpha; no real optical receiver, cloud execution or biological intelligence.

- Primary synthetic cases: **360**, 4 solver variants = **1440** evaluations.
- Follow-up synthetic cases: **180**, 3 solver variants = **540** additional evaluations.
- Grammar expansion: **193 original + 135 novel relative to v1.5 = 328** functions.
- Source validation: **24/24 new JavaScript tests; 6/6 existing optical-physics tests**.
- Browser: headless Chromium desktop 1280px / phone 390px passed interaction and overflow checks.
- Legacy neuron/encoder/optics: unchanged SHA-256 in `sources/`.
- Public arithmetic references: Cryptopals #1, #2, Hamming test from #6 passed.

## Reserved-new-seed acceptance

| Variant | Accepted | Accuracy given acceptance | Not answered |
|---|---:|---:|---:|
|original_adaptive|62/180|69.62%|118|
|gated_adaptive|36/180|92.13%|144|
|gated_serial|36/180|92.13%|144|

**Caution:** acceptance-conditioned accuracy is not total capability; both new-seed groups use the same synthetic optics generator and none are physical measurements.

## Source checksum catalog

Each hash is SHA-256 of the exact file bytes. Do not edit locked archived sources.

```text
f51f4408a5983a9ebbfb8044fcbb1d30e11b597c896643b1038b1320dbec7903  .github/workflows/manual_ripple_alpha.yml
f83181aa9712093dda7c5c2b3b98e9ebb462a0fd3ac85bdd380edbe674c5f0f5  README.md
a7ac0d032020062550e98950974bc33c79a931feae4da672d3cce49bc50c77ee  Ripple-Open-Grammar-Colony-Alpha-v1.6.html
98720851b33d06d8c20057f3f20984d78832e22870e5f8e794f7bbe8d97615fa  charts/lab_desktop.png
eed93f753101ebff13782d471e954cc4cbeca3949424c231daf31286b9ad95c1  charts/lab_mobile.png
7a5809f0e27efb72a506f9948f58f7c96d1fc9b4f045132962701882d9842ff1  data/browser_verification.json
03b0946397c33cf54e352d2099bedfc745cde821fd3f5f0ec85ae39e67f6ad34  data/cases.json
4bc79cb53058a9c8bab74874ae8e56010c7a8f7c7b008363907fb4b5e28376f2  data/evaluation_stdout.log
157a1fedb753b96b25b4d2f38bcd61a08e7e2e559e29e6c22407bd43405c1627  data/holdout_cases.json
af7fb21cc0077ac8f420528a8309c4ce3d739a7351db6158693dcbce86e401f9  data/holdout_report.json
53c4ad732a698da5138e1d63794eda3ff9a8fcf18f6694bcb86a23f3e561c991  data/holdout_stdout.log
42ec66b1abaa420e3e769efa66625e89816c22aa9305509331762c47b687f273  data/photon_cases.json
b0484e5da574211a1662c90474715f3b9c2f356e87896f9c061b294200b5f92c  data/physics_tests.log
1afde073723a617a672eec66174d8e60e3dc82a12e5a8b99080c04e21bbd37bd  data/report.json
38cfd189a4b484911c1f8d5e7a729b54742a823e6fd07010e03b85d32a536584  data/tests_stdout.log
42ec66b1abaa420e3e769efa66625e89816c22aa9305509331762c47b687f273  data/v15_reference_photon_cases.json
42e1df19c4c89b7cd2242e4aec61c8956ea7e130a4ab7573016df3bd83ea1e3a  docs/MATH_AND_RESEARCH.md
26afb974cf2f50673a616d4bee105a7455e59cd5706b6824035d7975ccb7e560  docs/NEGATIVE_RESULTS.md
1c1e8065492d3ef1d05f8caf9b7c57382e9d186458cbba3277a641000ee3ce5f  docs/SOFTWARE_REQUIREMENTS.md
a23aaf94250a9f53031a592980142245a848e2372b6c6c3093e8260b129265b8  requirements.txt
d75d4208e92f19623b127615bd52b4002e85d2c0a59b76471764b55a24294210  sources/v01_ripple_core_LOCKED.cjs
9c1879f6bc024e564e5e25b0294ac62b34d67aafffe26f9ddfae52675d66f695  sources/v07_quaternary_core_LOCKED.mjs
910bab2c583fd50c5250226f8bd81b9c477c5f6de921be7892a4575bacd17b51  sources/v14_physics_LOCKED.py
4440cfb5b6fb47c62522419008710395ad0d57ce1398dcfb8141badfe5733a12  src/build_lab.py
205cdc8c8c1f4b72f9e4731e8141498e401bbc168e7cc83c3b40dde4cd43d92f  src/engine.mjs
805614641a9e950a3d79a2809945d7192e5500bdea141f3fce50e59f3f74a45c  src/evaluate.mjs
3602591dd8fb527e421c367c82bc117b8cae514762a5982fd8e9fcc8376536ca  src/generate_cases.py
d5324b6f099449666b527ef2fda07aac2d94de0836766281d7324b2b65472a6d  src/grammar.mjs
32c2de9b3017b291a18d4d1e8d91d5811cb072ef52edaf003005b1f9db822507  src/make_release.py
1da844cb27d98c31ff9550c90b4d8272c003c42418f84eac265bc91381471871  src/public_vectors.mjs
fff73e08ba7d4ce7e8564cc48d740791861392079a0efd54963c181d4a35221a  src/v15_control_LOCKED.mjs
e103b31f30714617e403e2c14b8bdce6d8715113e5e993992ed691eddb9aa393  src/validate_holdout.mjs
e5b9af1569c01315ef259af9783e7bb68c09f061fcef3cac75807f5a82c3dd4b  tests/browser_check.py
d3ba11fe31d76c32021ee1a49e9aa811cd7fc4707b9b21c3bca68d8d7bb5e983  tests/test_engine.mjs
55f8664e4ded39eb4802e86ed31e37d967001ee96002942063e73b181c62667a  tests/test_physics.py
```
