import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {registry} from '../src/grammar.mjs';
import {prepare,analyze,grammarCounts,statHash} from '../src/engine.mjs';
import {hypotheses,runCase} from '../src/v15_control_LOCKED.mjs';
import {RippleNeuron} from '../sources/v01_ripple_core_LOCKED.cjs';
import {QuadEncoder,pack4,unpack4} from '../sources/v07_quaternary_core_LOCKED.mjs';
import {xorBytes,hexToBase64,hamming} from '../src/public_vectors.mjs';
const data=JSON.parse(fs.readFileSync(new URL('../data/cases.json',import.meta.url))).cases;
const hold=JSON.parse(fs.readFileSync(new URL('../data/holdout_cases.json',import.meta.url))).cases;
const C=(kind,photons=80,condition='matched',seed=111,which=data)=>which.find(x=>x.kind===kind&&x.photons_per_bit===photons&&x.condition===condition&&x.seed===seed);
const h=rel=>createHash('sha256').update(fs.readFileSync(new URL(rel,import.meta.url))).digest('hex');
test('locked source hashes',()=>{
 assert.equal(h('../sources/v01_ripple_core_LOCKED.cjs'),'d75d4208e92f19623b127615bd52b4002e85d2c0a59b76471764b55a24294210');
 assert.equal(h('../sources/v07_quaternary_core_LOCKED.mjs'),'9c1879f6bc024e564e5e25b0294ac62b34d67aafffe26f9ddfae52675d66f695');
 assert.equal(h('../sources/v14_physics_LOCKED.py'),'910bab2c583fd50c5250226f8bd81b9c477c5f6de921be7892a4575bacd17b51');
});
test('locked LIF spikes bright and not dark',()=>{
 const n=new RippleNeuron({adaptive:false});let c=0;for(let i=0;i<40;i++)c+=n.step([.8,0,0],.05).count;assert.ok(c>0);
 const z=new RippleNeuron({adaptive:false});for(let i=0;i<40;i++)assert.equal(z.step([0,0,0],.05).count,0);
});
test('quaternary pack source roundtrip',()=>{for(let x=0;x<256;x++)assert.equal(pack4(unpack4(x)),x)});
test('original v1.5 grammar not rewritten',()=>assert.equal(hypotheses().length,193));
test('new grammar has 135 unique semantic additions',()=>{
 const a=registry();assert.deepEqual(grammarCounts(),{base:193,added:135,total:328});
 assert.equal(new Set(a.all.map(x=>x.outputs.join(','))).size,a.all.length);
});
test('all safe generated functions return a nibble',()=>{
 for(const p of registry().all)assert.ok(p.outputs.length===16&&p.outputs.every(y=>Number.isInteger(y)&&y>=0&&y<=15));
});
test('unseen operations absent from original grammar',()=>{
 const {base,all}=registry();for(const expr of ['add1(multiply3(x))','popcount(x)','and11(x)','shr1(x)']){
  assert.ok(all.some(p=>p.expr===expr));assert.ok(!base.some(p=>p.expr===expr));
 }
});
test('synthetic observations are fixed seed and disjoint by index',()=>{
 assert.equal(data.length,360);assert.equal(hold.length,180);
 for(const c of [...data,...hold]){
  assert.equal(c.examples.length,16);assert.equal(new Set(c.examples.map(e=>e.x_true)).size,16);
  assert.ok(c.examples.slice(0,10).every(e=>e.split==='train'));
  assert.ok(c.examples.slice(10).every(e=>e.split==='test'));
 }
});
test('inference cannot access ground truth in training',()=>{
 const c=structuredClone(C('mul3_plus1'));
 const a=analyze(c);for(const e of c.examples.slice(0,10))e.y_true=0;
 const b=analyze(c);assert.equal(a.proposed,b.proposed);assert.equal(a.decision,b.decision);
});
test('inference cannot use heldout observations or labels',()=>{
 const c=structuredClone(C('mul3_plus1'));
 const a=analyze(c);for(const e of c.examples.slice(10)){
   e.rx.llr=e.rx.llr.map(x=>-x);e.ry.llr=e.ry.llr.map(x=>-x);
   e.rx.hard^=15;e.ry.hard^=15;e.y_true=(e.y_true+9)&15;
 }
 const b=analyze(c);assert.equal(a.proposed,b.proposed);assert.equal(a.decision,b.decision);assert.equal(a.expanded,b.expanded);
});
test('search expands and recovers new multiplication-composition example',()=>{
 const c=C('mul3_plus1');const old=analyze(c,{mode:'fixed'}),fresh=analyze(c,{mode:'adaptive',detailed:true});
 assert.equal(old.decision,'ABSTAIN_UNSUPPORTED');assert.equal(fresh.proposed,'add1(multiply3(x))');
 assert.equal(fresh.correct,6);assert.equal(fresh.exact,true);assert.equal(fresh.births,1);
 assert.ok(fresh.telemetry.every(x=>x.spikes>0));
});
test('program expansion is bounded under seven Ripple nodes',()=>{
 for(const kind of ['and_0b','mul3_plus1','control_xor7','unknown_permutation']){
 const x=analyze(C(kind));assert.ok(x.peak<=7);assert.ok(x.births<=1);
 }
});
test('serial expanded and colony expanded make identical predictions on full test suite',()=>{
 const report=JSON.parse(fs.readFileSync(new URL('../data/report.json',import.meta.url)));
 let a=report.rows.filter(x=>x.variant==='expanded'),b=report.rows.filter(x=>x.variant==='serial_expanded');
 assert.equal(a.length,b.length);for(let i=0;i<a.length;i++)assert.deepEqual([a[i].proposed,a[i].decision,a[i].correct],[b[i].proposed,b[i].decision,b[i].correct]);
});
test('out-of-grammar permutation does not achieve exact mapping',()=>{
 for(const c of data.filter(x=>x.kind==='unknown_permutation'))assert.equal(analyze(c).exact,false);
});
test('low contrast requires abstention in at least one test',()=>{
 const x=analyze(C('mul3_plus1',20,'contrast_collapse'));assert.ok(x.decision.startsWith('ABSTAIN'));
});
test('reliability criterion on heldout seeds is deterministic and conservative',()=>{
 for(const c of hold.filter(x=>x.condition==='phase_shift'))assert.ok(analyze(c,{minReliability:.65}).decision.startsWith('ABSTAIN'));
});
test('no arbitrary JS evaluation in program candidate names',()=>{
 assert.ok(registry().all.every(p=>!/[;{}]|eval\(|Function\(/.test(p.expr)));
});
test('numeric code likelihood is finite for real photon fixtures',()=>{
 const x=prepare(C('mul3_plus1').examples.slice(0,10));
 assert.ok(x.every(o=>o.xp.every(Number.isFinite)&&o.yp.every(Number.isFinite)));
});
test('fresh results deterministic across runs',()=>{
 const c=C('popcount');assert.equal(statHash(analyze(c,{detailed:true})),statHash(analyze(c,{detailed:true})));
});
test('public Cryptopals #1 hex-to-base64 official vector',()=>{
 assert.equal(hexToBase64('49276d206b696c6c696e6720796f757220627261696e206c696b65206120706f69736f6e6f7573206d757368726f6f6d'),'SSdtIGtpbGxpbmcgeW91ciBicmFpbiBsaWtlIGEgcG9pc29ub3VzIG11c2hyb29t');
});
test('public Cryptopals #2 raw-byte XOR official vector',()=>{
 const a=Buffer.from('1c0111001f010100061a024b53535009181c','hex');const b=Buffer.from('686974207468652062756c6c277320657965','hex');
 assert.equal(Buffer.from(xorBytes(a,b)).toString('hex'),'746865206b696420646f6e277420706c6179');
});
test('public Cryptopals #6 Hamming-distance example',()=>{
 assert.equal(hamming(Buffer.from('this is a test'),Buffer.from('wokka wokka!!!')),37);
});
test('invalid unequal-size XOR rejected',()=>assert.throws(()=>xorBytes(new Uint8Array(1),new Uint8Array(2)),/equal-length/));
test('reference v1.5 works independently',()=>{
 const old=JSON.parse(fs.readFileSync(new URL('../data/v15_reference_photon_cases.json',import.meta.url))).cases;
 const ref=runCase(old.find(x=>x.kind==='xor_7'&&x.seed===101&&x.photons_per_bit===80));
 assert.equal(ref.knownCodeRecovered,true);
});
