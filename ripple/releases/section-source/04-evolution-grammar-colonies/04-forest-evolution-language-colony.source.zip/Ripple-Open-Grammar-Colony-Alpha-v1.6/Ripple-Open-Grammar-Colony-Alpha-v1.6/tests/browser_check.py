from pathlib import Path
import json
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
html=(ROOT/'Ripple-Open-Grammar-Colony-Alpha-v1.6.html').read_text()
results={}
with sync_playwright() as p:
 for name,w,h in [('desktop',1280,900),('mobile',390,844)]:
  browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  page=browser.new_page(viewport={'width':w,'height':h},device_scale_factor=1)
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto('about:blank');page.set_content(html,wait_until='load')
  assert page.locator('#score').inner_text()=='6 / 6 unseen outputs',page.locator('#score').inner_text()
  assert 'add1(multiply3(x))' in page.locator('#candidate').inner_text()
  page.select_option('#kind','unknown_permutation');assert page.locator('#decision').inner_text().startswith('ABSTAIN')
  page.select_option('#channel','contrast_collapse');assert page.locator('#score').inner_text()
  page.select_option('#kind','popcount');page.select_option('#channel','matched');assert page.locator('#candidate').inner_text()
  overflow=page.evaluate('document.documentElement.scrollWidth > innerWidth + 1')
  assert not errors,errors
  assert not overflow,f'horizontal overflow on {w}'
  page.screenshot(path=str(ROOT/'charts'/f'lab_{name}.png'),full_page=True)
  results[name]={'width':w,'no_page_errors':not errors,'no_overflow':not overflow,'functional_interactions':4,'screenshot':f'charts/lab_{name}.png'}
  browser.close()
(ROOT/'data/browser_verification.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
