# Acceptance requirements — Ripple Open Grammar Colony Alpha v1.6

| ID | Requirement | Verifiable acceptance |
|---|---|---|
| R-01 | Preserve v0.1 LIF source | SHA-256 constant equals original; unit test |
| R-02 | Preserve v0.7 code packing | SHA-256 + roundtrip all 256 byte values |
| R-03 | Preserve v1.4 physics | SHA-256 + six optical unit tests |
| R-04 | Preserve v1.5 search for baseline | Copied source + 193 candidate check + reference task |
| R-05 | New closed four-bit DSL | 135 unique new truth tables + type bounds + no eval |
| R-06 | Independent clone state | Separate LIF instances, cap under 7 objects; real simulated spikes |
| R-07 | Isolation of oracle | y_true and x_true used after model selection; mutation tests |
| R-08 | Split training/test | 10 training x-values, six reserved values, 16 unique inputs |
| R-09 | Optical shift testing | matched, 0.8-radian phase drift, collapsed-contrast conditions |
| R-10 | Reject no/low information | finite LLR requirements, distinct-input gate, optional reliability gate |
| R-11 | Conventional baseline | identical expanded candidate results without neuron copies |
| R-12 | Reproducibility | fixed seeds, SHA-256 inventory, deterministic report regeneration |
| R-13 | Independent threshold validation | `.65` selected after 360 primary cases, before 180 new-seed cases |
| R-14 | Public third-party vectors | exact Cryptopals #1, #2, and #6 published test values |
| R-15 | Offline lab | desktop/mobile Chromium, filters, no JS errors or horizontal overflow |
| R-16 | External execution permissions | no cloud provider, repository, account or device touched; workflow opt-in only |

Current boundary: these acceptance rules qualify a **simulation research Alpha**, not trusted cryptography, scientific optics hardware or general intelligence.
