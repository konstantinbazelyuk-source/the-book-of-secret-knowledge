# Failures and limits retained in Ripple v1.6

1. **Original grammar cannot represent the new functions:** 193 original v1.5 truth tables omit AND masks, shifts, parity and modular multiplication. This is a search-language deficiency, not a deficient neuron.
2. **The newly expanded grammar is still fixed:** 135 additional functions were pre-written as bounded templates. Novel code operations outside these templates remain unrepresentable.
3. **Unidentified random permutation:** no new function matches its full sixteen-value truth table. In the primary set, the adaptive solver nevertheless falsely supported one low-photon example. In 180 new-seed cases, no random permutation was accepted; one new-seed result cannot establish a zero false-positive rate.
4. **Distribution shift:** an optical phase shift produces inaccurate likelihood ratios, and candidate correctness collapses. A model can produce confident-seeming arithmetic calculations based on incorrect sensor assumptions.
5. **Contrast collapse:** the detector's bit distributions become indistinguishable. Hidden bits cannot be recovered by increasing the number of colony nodes. The input-diversity rule does not catch every such case.
6. **Complexity vs selection:** expanded search raises candidate function coverage but can introduce ambiguity and overfitting. Always expanded scored slightly higher than adaptive on raw candidate accuracy in the primary runs.
7. **Low photon budget:** soft decoding at six photons/bit is often ambiguous. A post-hoc confidence gate rejects many such cases, with loss of useful acceptance coverage.
8. **No neuron intelligence superiority:** serial expanded search produced byte-for-byte equivalent predictions and decisions on the same inference pipeline. No neural speedup, general reasoning advantage or OS-parallel benefit was demonstrated.
9. **Gate selected post hoc on development data:** `.65` was chosen after examining primary data. Its independent seed-555/666 evaluation is limited to two deterministic seeds from the same synthetic generator. More shifts, noise families, sources and actual cameras are required.
10. **Public vector tests are arithmetic only:** meeting Cryptopals Challenges 1/2 reference vectors and a Challenge 6 Hamming example does not constitute decryption success.
11. **Visibility is not an optical field probe:** the scalar interference model predicts relative intensity, not instantaneous electromagnetic E/B values or measured photon trajectories.
12. **No safe arbitrary program execution:** programs are generated from a closed DSL. There is no unrestricted JS self-rewriting and no evidence for independent algorithm invention beyond combinatorial program construction.
