# MUSHROOM — Ripple Spiking Superstructure Alpha v3.0

**Status: complete executable ALPHA model implementation; NOT a concept diagram, not a claim of generally intelligent language comprehension.** No live hardware was available here. Alpha signifies testing maturity, not physical deployment certification. New source MIT; preserved upstream sources retain their own licenses.

## What actually runs (no placeholder nodes)

1. **Real camera I/O:** OpenCV `VideoCapture` can decode an existing video (verified) or open device 0 on a PC with a camera (hardware not available for validation). Exposure/gain/focus can be requested, with explicit backend set-status/readback—not claimed calibration. A video/image is never silently labeled as a physical sensor recording.
2. **3D xyz spiking superstructure:** 3 × 3 × 3 = 27 genuine Charlie v2.0 conductance neurons and 108 directed nearest-neighbor synapses. `x/y` are camera regions and `z` is *Gaussian optical processing scale*, **not physical depth**. Delayed synaptic signals are delivered one frame later, independent of input frame order.
3. **Inherited updated neuron cores:** The **unchanged v2.4** implementation executes Delta v3.0, Daughter v3.1, Charlie v2.0, original v0.1 or mixed specialists on global visual features. The full grid uses untouched Charlie v2.0 cells. This is a heterogeneous two-level system; no source neuron equations are rewritten.
4. **Mycelium:** Begins at nine live neuron sites and recruits up to four neighboring sites after spikes per step, with a maximum of 27. Non-spiking auxiliary sites may retire after long inactivity while central cells remain. No actual fungal growth or biological reproduction.
5. **Effective genes and weights:** Historical Ripple genome marker enters the model; six bounded parameters control synaptic excitation, inhibition, plasticity, graph diffusion and image-density/occlusion proxies. Mutations are cloned with a parent hash. A bounded synaptic update actually changes future current transmission. Label-supervised Charlie training updates actual inherited neuron weights, with held-out selection. Checkpoint/restart preserves neuron states and weights.
6. **Light represented by the English alphabet:** Normalized camera luminance is quantized to **A–Z, 26 bins** and injected as bounded sensory conductance pulses into its corresponding live neuron site, with sensory and recurrent pulses audited separately. This is explicitly a *lossy signal alphabet, not recognition of written letters*. A separate Tesseract optical character-recognition channel recognizes actual printed English text and connects letter events to distinct 3D neuron sites (ASCII A..Z mapped to sites 0..25). OCR errors remain possible.
7. **Programming and language inputs:** Python AST structure reports functions, calls and imports *without executing the source*; JavaScript syntax checks use `node --check`, also without executing code. Text has a real lexical scanner. A copied Ripple v1.6 **finite 4-bit grammar search** executes against explicit input-output pairs, rather than calling its existing source 'general-language comprehension'. OpenCV QR detection can read photographed machine-readable payloads.
8. **Evidence-grounded question answering:** Controlled English factual questions (spike count, known core, neuron count, etc.) resolve to exact stored fields or ABSTAIN. No hidden ChatGPT connection. No autonomous code running, system privilege expansion, remote networking, or claim of general reasoning.

## Installation

Python 3.10+, Node.js 20+, and for OCR the real Tesseract command-line binary. Requirements:

```bash
python -m pip install -r requirements.txt
# Linux optional OCR: install distro package 'tesseract-ocr'; OCR only if installed.
```

From this directory run a **real video decode, full computational model, A-Z optical observations**:

```bash
python -m mushroom.cli --video vendor/v24/Master_Ripple_Camera_Alpha_v2_1/camera_fixtures/synthetic_color_target_160f.avi --frames 48 --core mixed --out results/my_run.json --save-checkpoint results/my_state.json
```

Connect an actual digital camera (user supplies camera and permissions):

```bash
python -m mushroom.cli --device 0 --frames 48 --fps 24 --core daughter --ocr --exposure -6 --out results/camera_measurements.json
```

See text from an actual photo / screenshot (with OCR confidence scores):

```bash
python -m mushroom.cli --image results/ocr_test.png --code-language python
```

Inspect source code, *without executing it*:

```bash
python -m mushroom.cli --python-file mushroom/core.py --ask "Which functions?"
python -m mushroom.cli --javascript-file mushroom/grammar_bridge.mjs
```

Run inherited v1.6 finite symbolic inference, separate from natural English:

```bash
python -m mushroom.cli --grammar-pairs results/grammar_input.json
```

Train learned conductance weights only against explicitly provided binary ground-truth labels, with final chronological 25% reserved for model selection (not unbiased final validation):

```bash
python -m mushroom.cli --video YOUR_VIDEO.avi --frames 48 --labels-json YOUR_LABELS.json --save-checkpoint trained.json --out trained_report.json
```

Resume a prior model snapshot with saved weights and internal membrane/synapse states:

```bash
python -m mushroom.cli --video ANOTHER_VIDEO.avi --frames 48 --load-checkpoint trained.json --save-checkpoint resumed.json --out subsequent.json
```

## Reproduce verification

```bash
python -m unittest discover -s tests -p 'test_*.py' -q
python -m mushroom.study
```

Parent source regressions (unchanged upstream):

```bash
cd vendor/v24/Master_Ripple_Camera_Alpha_v2_1
PYTHONPATH=. python -m unittest discover -s neuron_upgrade/tests -p test_upgrade.py -q
cd ../..
cd ..
node vendor/mycelium/Ripple-Cybernetic-Mycelium-v0.3/tests/verification.test.js
```

## Mathematical specification

**Charlie conductance core (unchanged):**

\[C \dot u=-g_Lu+g_e(E_e-u)+g_i(E_i-u)-a\]

Excitatory/inhibitory currents decay exponentially. Adaptation and refractory state are updated with Charlie's inherited bounded microsteps. The original neuron is not overwritten. The specialist pathway can invoke unchanged Delta and Daughter parent models separately.

**3D graph:** 27 vertices \(V=\{(x,y,z):x,y,z\in\{0,1,2\}\}\), 108 directed 6-neighbor edges. A presynaptic event at time \(t\) can influence a neighbor at \(t+1\), never \(t\); outgoing weighted spike sums are quantized into up to 8 bounded inherited conductance pulses.

**Effective coupling and weight plasticity:** \(p_j(t+1)=\min(8,\operatorname{round}(5\sum_i w_{ij}s_i(t)))\); per-edge bounded update \(w_{ij}\leftarrow\operatorname{clip}_{[.02,.5]}(w_{ij}+\eta[s_i(t)s_j(t+1)-0.02w_{ij}])\) with binary presynaptic/postsynaptic event indicators. These are digital heuristic update laws, **not calibrated biological synaptic plasticity**.

**Spatial variables:** image-scale layers use Gaussian blurring; `diffusion` is a convex neighbor average of 3-channel mean color; `density` is a normalized brightness-based attenuation, *not mass or atomic density*; `occlusion` is a dark-sample attenuation heuristic, *not geometrical ray occlusion*. All three have nonzero default values, are ablatable and change actual channel inputs.

**Light letter code:** If normalized mean grayscale intensity is \(L\in[0,1]\), `symbol = ABC[min(25, floor(26L))]`. This is deliberately lossy; video compression/exposure distort the bins. Actual letter text extraction requires OCR or a separate validated optical character recognition mechanism.

## Executed evidence and negative findings

- **64 Mushroom unit and integration tests passed**; 26 preserved v2.4 neuron tests, 24 preserved Mycelium tests, and 24 preserved Ripple v1.6 grammar tests also passed independently. Total 138 passing checks across these four suites.
- Two already-archived synthetically generated video scenes (48 OpenCV-decoded frames each) were run through 11 configurations: **22 controlled software executions**. See `results/ablation.csv` and `results/ablation.json`; do not interpret CPU timings as hardware sensing accuracy or inference intelligence.
- Scene A: 21 spiking events with recurrence vs 14 without, scene B: 123 vs 107; connections do change computed outputs. This says nothing yet about general task quality.
- An actual printed raster image spelling **RIPPLE CODE** returned those words through Tesseract OCR with 96% confidence on the chosen clean synthetic text image. Real environmental OCR reliability is not established.
- The finite v1.6 grammar engine selected `xor1(x)` uniquely on 16 exact training pairs, but it works on 4-bit functions, not conversational English. ChatGPT comprehension parity has not been achieved, cannot be guaranteed, and was not tested.
- In scene B a diffusion-off ablation changed input values without changing the integer count of spikes. The explicit optical-letter ablation reduced scene A from 21 to 16 spikes and scene B from 123 to 116, establishing that the 26-symbol sensory channel affects model dynamics, not linguistic understanding. No universal gain is claimed. Observed dynamics are source-specific.
- Parent extracted-source integrity: 382 files across five archived projects byte-match their original ZIP entries; all four v2.4 parent source-manifest checks match. No previous live application was changed.

## Accuracy and safety

This release is a complete software research architecture and executable Alpha, not a completed general AI. It includes working sensors for available camera I/O and text/code input. **Real webcam hardware controls, physical Z/depth, electromagnetic fields, software understanding of arbitrary programs, and 100% parent model comprehension are not verified.** No assertion of consciousness. No behavior depends on fabricated measurements. OCR from untrusted sources is treated as raw untrusted text, never as instructions.

## Scientific / technical sources

- Brian2 scientific spiking-network and delayed-synapse tutorial: https://brian2.readthedocs.io/en/2.10.1/resources/tutorials/2-intro-to-brian-synapses.html
- OpenCV optical flow and video capture tutorial: https://docs.opencv.org/4.12.0/d4/dee/tutorial_optical_flow.html
- OpenCV `QRCodeDetector`: https://docs.opencv.org/4.0.0/de/dc3/classcv_1_1QRCodeDetector.html
- Tesseract OCR API and actual command semantics: https://tesseract-ocr.github.io/tessdoc/Command-Line-Usage.html
- Python AST: https://docs.python.org/3.11/library/ast.html
- Parent source versions: v2.4 ClusterNeuron, Mycelium v0.3, Code Reasoning v1.5, Open Grammar v1.6, paired Charlie–Daughter–Delta v1.0. Each copied verbatim into vendor directories with checksum audit. Their licenses and previous research findings remain unchanged.
