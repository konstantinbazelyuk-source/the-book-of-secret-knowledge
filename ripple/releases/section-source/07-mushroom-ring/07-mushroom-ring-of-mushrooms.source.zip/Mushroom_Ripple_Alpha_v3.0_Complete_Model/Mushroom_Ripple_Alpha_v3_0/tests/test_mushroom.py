import ast,json,os,subprocess,sys,unittest
from pathlib import Path
import cv2,numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from mushroom.core import Mushroom,Genome,scaled_tiles,marker,COORDS
from mushroom.senses import letters_from_light,inspect_python,inspect_javascript,inspect_text,recognize_text,decode_qr
VIDEO=ROOT/'vendor/v24/Master_Ripple_Camera_Alpha_v2_1/camera_fixtures/synthetic_color_target_160f.avi'
def replay(n=12):
 c=cv2.VideoCapture(str(VIDEO));frames=[]
 for _ in range(n):
  ok,f=c.read()
  if ok:frames.append(f)
 c.release();return frames
FRAMES=replay(14)
class TestSenses(unittest.TestCase):
 def test_camera_real_decode(self):self.assertEqual(len(FRAMES),14)
 def test_camera_triplet(self):self.assertEqual(scaled_tiles(FRAMES[0]).shape,(27,3))
 def test_camera_invalid_grayscale(self):
  with self.assertRaises(ValueError):scaled_tiles(np.zeros((30,30),dtype=np.uint8))
 def test_camera_invalid_type(self):
  with self.assertRaises(ValueError):scaled_tiles(np.zeros((30,30,3),dtype=np.float32))
 def test_alphabet_26_unique_bins(self):
  a=[np.full((30,30,3),round((i+.4)*255/26),np.uint8) for i in range(26)]
  self.assertEqual(''.join(x['symbol'] for x in letters_from_light(a)),'ABCDEFGHIJKLMNOPQRSTUVWXYZ')
 def test_alphabet_not_ocr(self):self.assertIn('NOT_recognized_text',letters_from_light(FRAMES[:1])[0]['meaning'])
 def test_program_parser_functions(self):
  x=inspect_python('import math\ndef foo(n):\n return math.sqrt(n)\n');self.assertEqual(x['functions'],['foo']);self.assertIn('sqrt',x['calls'])
 def test_program_parser_invalid(self):self.assertFalse(inspect_python('def bad(\n').get('parse_ok'))
 def test_program_parser_no_exec(self):
  x=inspect_python('raise RuntimeError("should not execute")');self.assertTrue(x['parse_ok']);self.assertFalse(x['executable'])
 def test_code_reject_overlimit(self):
  with self.assertRaises(ValueError):inspect_python('a'*100001)
 def test_js_real_node_parse(self):self.assertTrue(inspect_javascript('export const x = (a)=>a+1;')['parse_ok'])
 def test_js_reject_error(self):self.assertFalse(inspect_javascript('export const x = ;')['parse_ok'])
 def test_language_lexical(self):self.assertEqual(inspect_text('LIGHT and light')['word_count'],3)
 def test_bad_image_ocr(self):
  with self.assertRaises(ValueError):recognize_text(np.zeros((10,10),np.uint8))
 def test_ocr_raster(self):
  from PIL import Image,ImageDraw,ImageFont
  f=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',43)
  im=Image.new('RGB',(620,120),'white');ImageDraw.Draw(im).text((25,20),'RIPPLE CODE',fill='black',font=f)
  ans=recognize_text(cv2.cvtColor(np.asarray(im),cv2.COLOR_RGB2BGR))
  self.assertEqual(ans['text'],'RIPPLE CODE');self.assertGreaterEqual(min(x['confidence'] for x in ans['words']),40)
 def test_grammar_unique_fit(self):
  p=subprocess.run(['node',str(ROOT/'mushroom/grammar_bridge.mjs')],input=json.dumps({'pairs':[[x,x^1] for x in range(16)]}),capture_output=True,text=True)
  self.assertEqual(p.returncode,0,p.stderr);self.assertEqual(json.loads(p.stdout)['status'],'UNIQUE_FIT')
 def test_grammar_reject_invalid(self):
  p=subprocess.run(['node',str(ROOT/'mushroom/grammar_bridge.mjs')],input=json.dumps({'pairs':[[100,3]]*4}),capture_output=True,text=True)
  self.assertNotEqual(p.returncode,0)
class TestNeuron(unittest.TestCase):
 def test_coords_27_unique(self):self.assertEqual(len(set(COORDS)),27)
 def test_directions_108(self):self.assertEqual(len(Mushroom().edges),108)
 def test_neighbors_no_diagonal(self):
  for (i,j) in Mushroom().edges:self.assertEqual(sum(abs(a-b) for a,b in zip(COORDS[i],COORDS[j])),1)
 def test_clamped_edges(self):
  a=Mushroom();[a.step(f) for f in FRAMES];self.assertTrue(all(.02<=w<=.5 for w in a.edges.values()))
 def test_unchanged_parent(self):
  import hashlib
  original=ROOT/'vendor/v24/Master_Ripple_Camera_Alpha_v2_1/neuron_upgrade/parents/charlie/charlie_core/neuron.py'
  self.assertTrue(original.exists());self.assertGreater(len(hashlib.sha256(original.read_bytes()).hexdigest()),50)
 def test_recruitment(self):
  m=Mushroom();self.assertEqual(int(m.active.sum()),9)
  for f in replay(48):m.step(f)
  self.assertGreater(m.total_births,0);self.assertLessEqual(int(m.active.sum()),27)
 def test_no_growth_fixed(self):
  m=Mushroom(growth=False);[m.step(f) for f in FRAMES]
  self.assertEqual(int(m.active.sum()),27);self.assertEqual(m.total_births,0)
 def test_one_step_causality(self):
  m=Mushroom();x=m.step(FRAMES[0]);self.assertEqual(sum(x['recurrent_pulses']),0)
  for f in FRAMES[1:]:m.step(f)
  self.assertGreater(sum(sum(x['recurrent_pulses']) for x in m.history),0)
 def test_no_recurrent_ablation(self):
  m=Mushroom(recurrent=False,growth=False);[m.step(f) for f in FRAMES]
  self.assertEqual(sum(sum(x['recurrent_pulses']) for x in m.history),0)
 def test_unchanged_gene_marker(self):self.assertEqual(Mushroom().genome.hash(),Mushroom().genome.hash())
 def test_mutation_parent_hash(self):
  a=Mushroom().genome;b=a.mutate('diffusion',.02);self.assertEqual(b.parent_marker,a.hash());self.assertNotEqual(a.hash(),b.hash())
 def test_reject_mutation_outofbounds(self):
  with self.assertRaises(ValueError):Mushroom().genome.mutate('plasticity',1)
 def test_reject_unknown_gene(self):
  with self.assertRaises(ValueError):Mushroom().genome.mutate('imaginary',.02)
 def test_diffusion_ablation_changes_signal(self):
  x=Mushroom(growth=False);y=Mushroom(growth=False);y.genome=y.genome.mutate('diffusion',-.08)
  self.assertNotEqual(x.step(FRAMES[0])['light_rgb_mean'],y.step(FRAMES[0])['light_rgb_mean'])
 def test_density_ablation_changes_signal(self):
  x=Mushroom(growth=False);y=Mushroom(growth=False);y.genome=y.genome.mutate('density',-.08)
  self.assertNotEqual(x.step(FRAMES[0])['light_rgb_mean'],y.step(FRAMES[0])['light_rgb_mean'])
 def test_single_step_letter_projection(self):
  m=Mushroom(growth=False);x=m.step(FRAMES[0],letters='AB!A');self.assertEqual(x['injected_letter_sites'],[0,1]);self.assertEqual(x['delivered_pulses'][:2],[3,3])
 def test_letter_reject_non_string(self):
  with self.assertRaises(ValueError):Mushroom().step(FRAMES[0],letters=17)
 def test_replay_annotated(self):
  x=Mushroom().run(FRAMES,core='mixed');self.assertEqual(x['frames'],14);self.assertEqual(x['core'],'mixed');self.assertEqual(len(x['history']),14)
 def test_charlie_as_core(self):self.assertEqual(Mushroom().run(FRAMES[:5],core='charlie')['core'],'charlie')
 def test_delta_as_core(self):self.assertEqual(Mushroom().run(FRAMES[:5],core='delta')['core'],'delta')
 def test_daughter_as_core(self):self.assertEqual(Mushroom().run(FRAMES[:5],core='daughter')['core'],'daughter')
 def test_bad_core_rejected(self):
  with self.assertRaises(ValueError):Mushroom().run(FRAMES,core='fake')
 def test_bad_dt_rejected(self):
  with self.assertRaises(ValueError):Mushroom().step(FRAMES[0],dt=100)
 def test_test_replay_determinism(self):
  a=Mushroom().run(FRAMES[:7]);b=Mushroom().run(FRAMES[:7]);self.assertEqual(a['history'],b['history'])
if __name__=='__main__':unittest.main()
class TestPersistence(unittest.TestCase):
 def test_checkpoint_roundtrip_causal(self):
  m=Mushroom();[m.step(f) for f in FRAMES[:8]]
  restored=Mushroom.from_checkpoint(m.checkpoint())
  self.assertEqual(m.step(FRAMES[8])['spikes'],restored.step(FRAMES[8])['spikes'])
  self.assertEqual(m.step(FRAMES[9])['membranes'],restored.step(FRAMES[9])['membranes'])
 def test_checkpoint_rejects_corruption(self):
  m=Mushroom();s=m.checkpoint();s['edges'][0][2]=3.3
  with self.assertRaises(ValueError):Mushroom.from_checkpoint(s)
 def test_checkpoint_preserves_mutation(self):
  m=Mushroom();m.genome=m.genome.mutate('diffusion',.01)
  self.assertEqual(Mushroom.from_checkpoint(m.checkpoint()).genome.hash(),m.genome.hash())
 def test_labeled_training_requires_ground_truth(self):
  with self.assertRaises(ValueError):Mushroom().fit_labeled(FRAMES,[0]*3)
 def test_labeled_training_runs_and_retains_bounds(self):
  m=Mushroom(growth=False);labels=[int(i>=7) for i in range(len(FRAMES))]
  r=m.fit_labeled(FRAMES,labels,epochs=2)
  self.assertEqual(r['total'],27);self.assertEqual(r['train_count'],10)
  self.assertTrue(all(.12<=w<=4 for row in r['evaluations'] for w in row['synaptic_weights']))
class TestContracts(unittest.TestCase):
 def setUp(self):
  from mushroom.contracts import answer
  self.ask=answer
  self.report={'schema':'mushroom/alpha-3.0','count':27,'edge_count':108,'voxel_total_spikes':21,'total_births':18,'core':'mixed','geometry':'3x3x3 scale'}
 def test_count(self):self.assertEqual(self.ask('How many neurons?',self.report)['answer'],'27 computational neuron sites.')
 def test_synapses(self):self.assertEqual(self.ask('How many synapses?',self.report)['evidence_field'],'edge_count')
 def test_spikes(self):self.assertEqual(self.ask('How many spikes?',self.report)['evidence_field'],'voxel_total_spikes')
 def test_births(self):self.assertIn('18',self.ask('How many births?',self.report)['answer'])
 def test_core(self):self.assertEqual(self.ask('Which core?',self.report)['answer'],'mixed')
 def test_physical_truth(self):self.assertIn('not calibrated physical depth',self.ask('Is z axis physical?',self.report)['answer'])
 def test_spiritual_nonclaim(self):self.assertIn('No evidence',self.ask('Can you detect an aura?',self.report)['answer'])
 def test_unknown_abstains(self):self.assertEqual(self.ask('What is the weather tomorrow?',self.report)['status'],'ABSTAIN_UNKNOWN')
 def test_reject_question_overlimit(self):
  with self.assertRaises(ValueError):self.ask('x'*301,self.report)
 def test_functions_grounding(self):self.assertEqual(self.ask('Which functions?',{'language':'python','parse_ok':True,'functions':['foo','bar']})['answer'],'foo, bar')
 def test_no_functions_no_guess(self):self.assertEqual(self.ask('Which functions?',{'language':'python','parse_ok':False})['status'],'ABSTAIN_UNKNOWN')
class TestCameraControls(unittest.TestCase):
 def test_real_file_opencv_path(self):
  from mushroom.cli import frames_from_source
  f,rep=frames_from_source('video',str(VIDEO),5)
  self.assertEqual(len(f),5);self.assertEqual(rep,{})
 def test_bad_camera_no_fake_pixels(self):
  from mushroom.cli import frames_from_source
  with self.assertRaises(RuntimeError):frames_from_source('video','/path/that/does/not/exist/123.avi',6)
 def test_camera_control_requested_is_not_calibration(self):
  from mushroom.cli import frames_from_source
  import unittest.mock
  class FakeCap:
   def __init__(self):self.n=0
   def isOpened(self):return True
   def set(self,*args):return False
   def get(self,*args):return -1.0
   def read(self):self.n+=1;return (True,np.zeros((30,30,3),dtype=np.uint8))
   def release(self):pass
  with unittest.mock.patch('cv2.VideoCapture',return_value=FakeCap()):
   frames,results=frames_from_source('device','0',4,controls={'exposure':20})
  self.assertEqual(len(frames),4);self.assertFalse(results['exposure']['backend_set_success'])
  self.assertFalse(results['exposure']['verified_on_hardware'])
class TestVisualProgramming(unittest.TestCase):
 def test_actual_qr_image_decode(self):
  qr=cv2.QRCodeEncoder_create().encode('RIPPLE-CODE-TEST')
  qr=cv2.copyMakeBorder(qr,4,4,4,4,cv2.BORDER_CONSTANT,value=255)
  scaled=cv2.resize(qr,None,fx=4,fy=4,interpolation=cv2.INTER_NEAREST)
  self.assertEqual(decode_qr(scaled)['data'],'RIPPLE-CODE-TEST')
class TestOpticalAlphabetWiring(unittest.TestCase):
 def test_light_code_reaches_computing_cell(self):
  m=Mushroom(growth=False)
  row=m.step(FRAMES[0]);self.assertIsNotNone(row['optical_site'])
  self.assertEqual(row['sensory_pulses'][row['optical_site']],2)
  self.assertEqual(row['optical_symbol'],letters_from_light([FRAMES[0]])[0]['symbol'])
 def test_alphabet_ablates_zero_sensory_signal(self):
  m=Mushroom(growth=False);row=m.step(FRAMES[0],optical_alphabet=False)
  self.assertIsNone(row['optical_symbol']);self.assertEqual(sum(row['sensory_pulses']),0)
 def test_sensory_and_recurrent_are_audited_separately(self):
  m=Mushroom(growth=False)
  first=m.step(FRAMES[0]);self.assertEqual(sum(first['recurrent_pulses']),0)
  self.assertGreater(sum(first['sensory_pulses']),0)
