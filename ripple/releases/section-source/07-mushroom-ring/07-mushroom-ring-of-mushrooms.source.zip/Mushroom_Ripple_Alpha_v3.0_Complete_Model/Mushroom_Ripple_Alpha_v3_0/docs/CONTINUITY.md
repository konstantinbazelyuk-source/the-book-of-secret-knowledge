# Continuity ledger

**Locked:** All 382 files extracted from 5 archives, 4 locked v2.4 parent source files, v2.4 neuron math, source taxonomy, previous field-sensor caveats. No replacements made.

**New/current:** 27-node 3D computational colony, 108 delayed edges, actual Charlie v2.0 conductance steps, mixed Delta/Daughter global readout, growth/retraction, bounded plasticity, formal source markers, checkpointing, OCR, A-Z quantization, code parsing, 4-bit existing grammar inference, explicit-provenance status answers.

**Optional and separately labeled:** physical USB webcam, Tesseract, user-labeled supervised learning, user-selected node type, prior research exploratory modules. Absence is an unavailable state rather than dummy zeros claimed as measurement.

**Out of scope / not achieved:** physical xyz calibration, magnetic component of laser light, biological fungal reproduction, intrinsic consciousness, unconditional language understanding, direct attachment to ChatGPT model weights or its hidden internals, live webcam validation.

**Research pitfall corrected:** visual/optical alphabet coding is not actual text OCR; OCR is never promoted to verified semantic understanding; code AST parses without executing untrusted programs; synthetic images remain synthetic after being decoded with OpenCV. Source-file preservation is cryptographically checked.
