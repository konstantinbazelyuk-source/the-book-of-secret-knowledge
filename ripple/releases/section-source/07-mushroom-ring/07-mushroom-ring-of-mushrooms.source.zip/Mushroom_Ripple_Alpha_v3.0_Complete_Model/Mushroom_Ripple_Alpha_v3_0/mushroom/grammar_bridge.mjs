/** Real integration with original Ripple v1.6 finite grammar registry.
  Learns among allowed 4-bit mappings only. Never interprets these mappings
  as human English semantics; no eval, no network. */
import fs from 'node:fs';
import {registry} from '../vendor/grammar/Ripple-Open-Grammar-Colony-Alpha-v1.6/src/grammar.mjs';
const input=JSON.parse(fs.readFileSync(0,'utf8'));
if(!Array.isArray(input.pairs)||input.pairs.length<4||input.pairs.length>32)throw Error('4..32 pairs required');
for(const p of input.pairs){if(!Array.isArray(p)||p.length!==2||p.some(x=>!Number.isInteger(x)||x<0||x>15))throw Error('invalid nibble');}
const functions=registry().all;
const scored=functions.map(f=>({id:f.id,expr:f.expr, mismatches:input.pairs.reduce((s,[x,y])=>s+(f.outputs[x]!==y),0)}))
  .sort((a,b)=>a.mismatches-b.mismatches||a.expr.localeCompare(b.expr));
const matches=scored.filter(x=>x.mismatches===0);
process.stdout.write(JSON.stringify({schema:'mushroom/grammar-v1.6',status:matches.length===1?'UNIQUE_FIT':matches.length>1?'AMBIGUOUS_FIT':'NO_EXACT_FIT',
  matching_programs:matches.slice(0,5),number_of_exact_matches:matches.length,number_of_candidates:functions.length,
  conclusion:'16-symbol finite operation hypothesis search; not natural-language understanding'})+'\n');
