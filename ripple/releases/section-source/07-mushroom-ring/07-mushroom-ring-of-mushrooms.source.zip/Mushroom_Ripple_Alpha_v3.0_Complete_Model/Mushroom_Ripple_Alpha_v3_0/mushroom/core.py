"""Mushroom Alpha v3.0: executed 3D (x,y,processing-scale) Charlie conductance
population with one-frame-delayed sparse synaptic propagation, bounded plasticity,
plus a v2.4 Delta/Daughter/Charlie inherited specialist readout.
All computed z coordinates are *algorithmic processing scales*, NOT physical depth.
"""
from __future__ import annotations
import hashlib,json,math,sys
from dataclasses import dataclass
from pathlib import Path
import cv2
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
V24=ROOT/'vendor/v24/Master_Ripple_Camera_Alpha_v2_1'
sys.path.insert(0,str(V24/'neuron_upgrade/parents/charlie'))
sys.path.insert(0,str(V24))
from charlie_core.neuron import CharlieNeuron,CoreParameters
from cluster_neuron.engine import cheap_features,genome_overlay
from neuron_upgrade.engine import run_variant

N=3
COORDS=[(x,y,z) for z in range(N) for y in range(N) for x in range(N)]
INDEX={p:i for i,p in enumerate(COORDS)}


def finite_rgb(frame):
    if not isinstance(frame,np.ndarray) or frame.ndim!=3 or frame.shape[2]!=3 or frame.dtype!=np.uint8 or min(frame.shape[:2])<24:
        raise ValueError('expected BGR uint8 camera frame >=24x24')
    return frame


def scaled_tiles(frame):
    """27 [R,G,B] values, 3x3 camera image blocks at 3 blur scales.
    Values retain dimensionless channel ranges. 3D Z is NOT actual scene depth.
    """
    finite_rgb(frame)
    h,w=frame.shape[:2];rgb=cv2.cvtColor(frame,cv2.COLOR_BGR2RGB)
    out=[]
    for blur in [0.,1.2,3.2]:
        im=rgb if blur==0 else cv2.GaussianBlur(rgb,(0,0),blur)
        for y in range(3):
            for x in range(3):
                tile=im[y*h//3:(y+1)*h//3,x*w//3:(x+1)*w//3]
                out.append((tile.mean(axis=(0,1))/255.).tolist())
    return np.asarray(out,dtype=np.float64)


def marker(obj):
    return hashlib.sha256(json.dumps(obj,sort_keys=True,allow_nan=False,separators=(',',':')).encode()).hexdigest()

@dataclass
class Genome:
    name:str='prism'
    exc_gain:float=0.20
    inhib_gain:float=0.07
    plasticity:float=0.012
    diffusion:float=0.08
    occlusion:float=0.08
    density:float=0.08
    source_marker:str=''
    parent_marker:str|None=None
    def __post_init__(self):
        if not (.02<=self.exc_gain<=.5 and 0<=self.inhib_gain<=.3 and 0<=self.plasticity<=.05 and 0<=self.diffusion<=.5 and 0<=self.occlusion<=.5 and 0<=self.density<=.5):
            raise ValueError('genome parameters outside allowed bounds')
    def encoded(self):
        return {'name':self.name,'exc_gain':self.exc_gain,'inhib_gain':self.inhib_gain,'plasticity':self.plasticity,'diffusion':self.diffusion,'occlusion':self.occlusion,'density':self.density,'source_marker':self.source_marker,'parent_marker':self.parent_marker}
    def hash(self):return marker(self.encoded())
    def mutate(self,parameter,delta):
        if parameter not in ('exc_gain','inhib_gain','plasticity','diffusion','occlusion','density') or not math.isfinite(delta):raise ValueError('invalid mutation')
        data=self.encoded();data[parameter]=round(data[parameter]+delta,8);data['parent_marker']=self.hash();return Genome(**data)


class Mushroom:
    """27 intact Charlie v2.0 neuron instances and 108 directed adjacency synapses.
    Incoming signals delivered on NEXT frame. No same-step feedback cycles.
    Optional global Delta/Daughter v2.4 readout via preserved run_variant.
    """
    def __init__(self, genome='prism', *, seed=11, recurrent=True, growth=True):
        inherited=genome_overlay(genome)
        self.genome=Genome(name=genome,source_marker=inherited['marker'])
        self.gains=np.asarray(inherited['gains'][:3],dtype=float)
        self.neurons=[CharlieNeuron(params=CoreParameters(recurrent_exc_pulse=.17,recurrent_inh_pulse=.17)) for _ in COORDS]
        self.edges={(i,INDEX[b]):self.genome.exc_gain for i,a in enumerate(COORDS)
                    for axis in range(3) for step in (-1,1)
                    for b in [tuple(a[j]+(step if j==axis else 0) for j in range(3))] if b in INDEX}
        self.prev_spikes=np.zeros(27,dtype=int);self.recurrent=recurrent;self.growth=growth
        self.active=np.array([p[2]==1 for p in COORDS],dtype=bool) if growth else np.ones(27,dtype=bool)
        self.idle=np.zeros(27,dtype=int);self.total_births=0;self.total_retirements=0
        self.history=[];self.seed=seed
    def step(self,frame,dt=1/24,letters="",optical_alphabet=True):
        if not math.isfinite(dt) or not 1/120<=dt<=1/5:raise ValueError('unsupported frame delta')
        if not isinstance(letters,str) or len(letters)>256:raise ValueError('letter input must be bounded text')
        letter_sites={ord(ch)-65 for ch in letters.upper() if 'A'<=ch<='Z'}
        if not isinstance(optical_alphabet,bool):raise ValueError('invalid alphabet control')
        # Physical pixels -> lossy alphabet encoding -> actual neuron input.
        luminance=float(cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY).mean())/255.0
        optical_site=min(25,int(luminance*26)) if optical_alphabet else None
        if optical_site is not None and self.growth and not self.active[optical_site]:
            self.active[optical_site]=True
            self.neurons[optical_site]=CharlieNeuron(params=CoreParameters(recurrent_exc_pulse=.17,recurrent_inh_pulse=.17))
            self.total_births+=1
        light=scaled_tiles(frame)
        if self.genome.diffusion:
            # conservative bounded Laplacian mixing: convex combination per site
            before=light.copy()
            for i in range(27):
                adj=[j for j in range(27) if (j,i) in self.edges]
                if adj:light[i]=(1-self.genome.diffusion)*before[i]+self.genome.diffusion*np.mean(before[adj],axis=0)
        # optical density = normalized local mean brightness, NOT mass density.
        bright=np.mean(light,axis=1)
        light*= (1.-self.genome.density*bright[:,None])
        # occlusion proxy = pixel darkness only, NOT 3D line-of-sight reconstruction.
        light*= (1.-self.genome.occlusion*(bright[:,None]<.20))
        spikes=[];first=[];inputs=[];recurrent_pulses=[];sensory_pulses=[]
        for i,(neuron,rgb) in enumerate(zip(self.neurons,light)):
            if not self.active[i]:
                spikes.append(0);first.append(0.);inputs.append(0);recurrent_pulses.append(0);sensory_pulses.append(0);continue
            incoming=sum(self.edges[(j,i)]*min(3,int(self.prev_spikes[j])) for j in range(27) if (j,i) in self.edges) if self.recurrent else 0.
            recurrent_part=max(0,min(8,round(incoming*5)))
            sensory_part=(3 if i in letter_sites else 0)+(2 if i==optical_site else 0)
            excit=max(0,min(8,recurrent_part+sensory_part))
            # Strong red-vs-blue suppression is independently represented, not physical inhibition.
            inhib=min(8,int(self.genome.inhib_gain*min(1.,float(rgb[2]))*10))
            encoded=[min(1,float(rgb[0])*self.gains[0]), min(1,float(rgb[1])*self.gains[1]), min(1,float(rgb[2])*self.gains[2])]
            out=neuron.step(encoded,dt,exc_pulses=excit,inh_pulses=inhib)
            spikes.append(out['count']);first.append(out['membrane']);inputs.append(excit);recurrent_pulses.append(recurrent_part);sensory_pulses.append(sensory_part)
        nxt=np.array(spikes,dtype=int)
        births=[];retirements=[]
        if self.growth:
            # Mycelium-inspired demand-controlled recruitment, four newborn neurons max per frame.
            candidates=sorted((j for i in range(27) if nxt[i]>0 for j in range(27)
                               if (i,j) in self.edges and not self.active[j]),
                              key=lambda j:(COORDS[j][2],j))
            for j in list(dict.fromkeys(candidates))[:4]:
                self.active[j]=True;self.neurons[j]=CharlieNeuron(params=CoreParameters(recurrent_exc_pulse=.17,recurrent_inh_pulse=.17))
                births.append(j);self.total_births+=1
            for j in range(27):
                if self.active[j]:self.idle[j]=self.idle[j]+1 if nxt[j]==0 else 0
                # retain at least the base central layer, and avoid quick turnover
                if COORDS[j][2]!=1 and self.active[j] and self.idle[j]>48 and int(self.active.sum())>9:
                    self.active[j]=False;self.idle[j]=0;retirements.append(j);self.total_retirements+=1
        if self.recurrent and self.genome.plasticity:
            # bounded covariance-Hebbian coactivity: anti-runaway shrink on inactive paths.
            for (a,b),w in list(self.edges.items()):
                pre=min(1,int(self.prev_spikes[a]));post=min(1,int(nxt[b]))
                self.edges[(a,b)]=max(.02,min(.5,w+self.genome.plasticity*(pre*post-.02*w)))
        self.prev_spikes=nxt
        record={'index':len(self.history),'spikes':spikes,'spike_sum':int(nxt.sum()),'xyz_active':[list(COORDS[i]) for i,k in enumerate(spikes) if k],
                'membranes':[round(x,7) for x in first],'delivered_pulses':inputs,'recurrent_pulses':recurrent_pulses,'sensory_pulses':sensory_pulses,'light_rgb_mean':np.mean(light,axis=0).round(7).tolist(),
                'mean_synapse':float(np.mean(list(self.edges.values()))),'active_count':int(self.active.sum()),'injected_letter_sites':sorted(letter_sites),'optical_symbol':chr(65+optical_site) if optical_site is not None else None,'optical_site':optical_site,'births':births,'retirements':retirements}
        self.history.append(record);return record
    def fit_labeled(self,frames,labels,*,epochs=12,learning_rate=.025):
        """Supervised stationary-response gradient from inherited Charlie v2.0.
        Time-ordered final 25% is holdout. Never interprets labels as measured by AI.
        Accepts an updated weight only if the held-out log loss improves.
        """
        if len(frames)!=len(labels) or not 8<=len(frames)<=240 or any(y not in (0,1) for y in labels):
            raise ValueError('explicit binary ground truth labels needed, >=8 frames')
        if not 1<=epochs<=50 or not .00001<=learning_rate<=.2:raise ValueError('unsafe training parameters')
        split=int(len(frames)*.75)
        lights=[scaled_tiles(f) for f in frames]
        audit=[]
        for j,neuron in enumerate(self.neurons):
            learn=[(lights[i][j].tolist(),labels[i]) for i in range(split)]
            held=[(lights[i][j].tolist(),labels[i]) for i in range(split,len(frames))]
            before=sum(neuron.loss_grad(x,y)[0] for x,y in held)/len(held)
            saved=neuron.weights[:]
            neuron.train(learn,epochs=epochs,learning_rate=learning_rate)
            after=sum(neuron.loss_grad(x,y)[0] for x,y in held)/len(held)
            improved=after+1e-9<before
            if not improved:neuron.weights=saved
            audit.append({'xyz':COORDS[j],'pre_holdout_logloss':round(before,8),
                          'candidate_holdout_logloss':round(after,8),'accepted':improved,
                          'synaptic_weights':neuron.weights[:]})
        return {'schema':'mushroom/supervised-weights-1','train_count':split,'holdout_count':len(frames)-split,
                'approved':sum(a['accepted'] for a in audit),'total':27,'evaluations':audit,
                'warning':'post-selection holdout is used for model selection; independent final evaluation still required'}

    def checkpoint(self):
        fields=('membrane','exc','inh','adapt','theta','rate','refractory','time','count','weights')
        raw={'schema':'mushroom/checkpoint-1','genome':self.genome.encoded(),'growth':self.growth,
             'recurrent':self.recurrent,'active':self.active.astype(int).tolist(),
             'idle':self.idle.tolist(),'prev_spikes':self.prev_spikes.tolist(),
             'edges':[[a,b,w] for (a,b),w in sorted(self.edges.items())],
             'neurons':[{k:getattr(n,k) for k in fields} for n in self.neurons],
             'births':self.total_births,'retirements':self.total_retirements}
        return {**raw,'integrity_sha256':marker(raw)}

    @classmethod
    def from_checkpoint(cls,checkpoint):
        if not isinstance(checkpoint,dict) or checkpoint.get('schema')!='mushroom/checkpoint-1':raise ValueError('unsupported checkpoint schema')
        raw={k:v for k,v in checkpoint.items() if k!='integrity_sha256'}
        if marker(raw)!=checkpoint.get('integrity_sha256'):raise ValueError('checkpoint integrity failure')
        gen=Genome(**raw['genome']);m=cls(gen.name,growth=raw['growth'],recurrent=raw['recurrent'])
        if m.genome.source_marker!=gen.source_marker:raise ValueError('parent version mismatch')
        m.genome=gen
        if len(raw['neurons'])!=27 or len(raw['edges'])!=108 or len(raw['prev_spikes'])!=27 or len(raw['active'])!=27:raise ValueError('invalid model size')
        expected=set(m.edges)
        edges={}
        for a,b,w in raw['edges']:
            if not isinstance(a,int) or not isinstance(b,int) or not isinstance(w,(int,float)) or not math.isfinite(w) or not .02<=w<=.5:raise ValueError('invalid synapse')
            edges[(a,b)]=w
        if set(edges)!=expected:raise ValueError('invalid sparse graph')
        m.edges=edges
        m.prev_spikes=np.array(raw['prev_spikes'],dtype=int)
        m.active=np.array(raw['active'],dtype=bool)
        m.idle=np.array(raw['idle'],dtype=int)
        m.total_births=int(raw['births']);m.total_retirements=int(raw['retirements'])
        fields=('membrane','exc','inh','adapt','theta','rate','refractory','time','count','weights')
        for n,d in zip(m.neurons,raw['neurons']):
            if set(d)!=set(fields):raise ValueError('invalid neuron schema')
            for k in fields:
                if k!='weights' and (not isinstance(d[k],(int,float)) or not math.isfinite(d[k])):raise ValueError('invalid neuron state')
                setattr(n,k,d[k])
            if len(n.weights)!=3 or any(not .12<=v<=4. for v in n.weights):raise ValueError('invalid learned weights')
        return m

    def run(self,frames,*,fps=24,core='mixed',letters='',optical_alphabet=True):
        if not 3<=len(frames)<=240:raise ValueError('need 3..240 frames')
        if not 5<=fps<=120:raise ValueError('fps outside range')
        if core not in ('mixed','charlie','daughter','delta','original'):raise ValueError('unknown specialist core')
        samples,_=cheap_features(frames,fps)
        specialist=run_variant(samples,variant=core,gains=genome_overlay(self.genome.name)['gains'])
        for i,frame in enumerate(frames):self.step(frame,dt=1/fps,letters=letters if i==0 else "",optical_alphabet=optical_alphabet)
        out={'schema':'mushroom/alpha-3.0','geometry':'3x3x3, z=Gaussian image scale; NOT measured physical depth',
             'coords':COORDS,'count':len(COORDS),'edge_count':len(self.edges),'core':core,
             'core_parent':'v2.4 unchanged','genome':self.genome.encoded(),'genome_hash':self.genome.hash(),
             'specialist_counts':specialist['spikes_per_node'],'voxel_total_spikes':sum(s['spike_sum'] for s in self.history),
             'synapse_range':[min(self.edges.values()),max(self.edges.values())],'total_births':self.total_births,'total_retirements':self.total_retirements,'end_active':int(self.active.sum()),
             'frames':len(frames),'history':self.history,'sensor_origin':'decoded frames: user must label physical or synthetic'}
        return out
