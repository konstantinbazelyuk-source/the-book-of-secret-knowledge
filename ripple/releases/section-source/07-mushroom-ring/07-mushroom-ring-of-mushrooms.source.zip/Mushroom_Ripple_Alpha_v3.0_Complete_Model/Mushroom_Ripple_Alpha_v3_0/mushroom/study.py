"""Reproducible multi-scene ablations. Timings include actual numerical processing;
video content itself was generated synthetically by earlier Ripple experiments."""
from __future__ import annotations
import csv,hashlib,json,time,sys,cv2,numpy as np
from pathlib import Path
from .core import Mushroom,ROOT

SOURCES=[ROOT/'vendor/v24/Master_Ripple_Camera_Alpha_v2_1/camera_fixtures/synthetic_color_target_160f.avi',
         ROOT/'vendor/v24/Master_Ripple_Camera_Alpha_v2_1/cluster_results/holdout_geometry.avi']

def sample(path,n=48):
    cap=cv2.VideoCapture(str(path))
    if not cap.isOpened():raise RuntimeError('unavailable video file '+str(path))
    frames=[]
    try:
        for i in range(n):
            ok,frame=cap.read()
            if not ok:break
            frames.append(frame)
    finally:cap.release()
    if len(frames)<10:raise ValueError('insufficient decoded frames')
    return frames

def run_all():
    out=[]
    for scene,path in enumerate(SOURCES):
        frames=sample(path)
        scenarios=[('normal','mixed',True,True,None),('without_recursion','mixed',False,True,None),
          ('fixed27','mixed',True,False,None),('no_diffusion','mixed',True,True,('diffusion',-.08)),
          ('no_density','mixed',True,True,('density',-.08)),('no_occlusion','mixed',True,True,('occlusion',-.08)),
          ('delta','delta',True,True,None),('daughter','daughter',True,True,None),
          ('charlie','charlie',True,True,None),('original','original',True,True,None),('no_alphabet','mixed',True,True,None)]
        for label,core,recurrent,growth,mutation in scenarios:
            m=Mushroom(recurrent=recurrent,growth=growth)
            if mutation:m.genome=m.genome.mutate(*mutation)
            start=time.perf_counter();r=m.run(frames,core=core,optical_alphabet=(label!='no_alphabet'))
            elapsed=(time.perf_counter()-start)*1000
            out.append({'scene':scene,'scenario':label,'core':core,'frames':len(frames),'voxel_spikes':r['voxel_total_spikes'],
                        'specialist_events':sum(r['specialist_counts']),'recruited':r['total_births'],
                        'active_end':r['end_active'],'mean_synapse':round(float(np.mean([x['mean_synapse'] for x in r['history']])),6),
                        'delivered_pulses':sum(sum(x['delivered_pulses']) for x in r['history']),
                        'recurrent_pulses':sum(sum(x['recurrent_pulses']) for x in r['history']),
                        'sensory_pulses':sum(sum(x['sensory_pulses']) for x in r['history']),
                        'CPU_wall_ms':round(elapsed,3),'source':'synthetic_video_decoded_OpenCV',
                        'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    return out

if __name__=='__main__':
    out=run_all();dest=ROOT/'results';dest.mkdir(exist_ok=True)
    with (dest/'ablation.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=out[0].keys());w.writeheader();w.writerows(out)
    (dest/'ablation.json').write_text(json.dumps(out,indent=2))
    print(json.dumps(out,indent=2))
