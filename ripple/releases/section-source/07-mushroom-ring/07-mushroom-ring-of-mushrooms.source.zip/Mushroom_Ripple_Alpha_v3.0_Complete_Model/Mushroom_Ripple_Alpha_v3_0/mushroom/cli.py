"""CLI connected to real video files, USB cameras, images, code and English text."""
import argparse,json,sys,subprocess,cv2,numpy as np
from pathlib import Path
from .core import Mushroom,ROOT
from .senses import letters_from_light,recognize_text,inspect_python,inspect_javascript,inspect_text,decode_qr
from .contracts import answer

def frames_from_source(kind,source,count,*,controls=None):
    cap=cv2.VideoCapture(int(source) if kind=='device' else source)
    if not cap.isOpened():raise RuntimeError(f'{kind} input unavailable: {source}')
    frames=[];control_report={}
    try:
        if controls and kind=='device':
            for name,value in controls.items():
                prop={'exposure':cv2.CAP_PROP_EXPOSURE,'gain':cv2.CAP_PROP_GAIN,'focus':cv2.CAP_PROP_FOCUS}[name]
                ok=bool(cap.set(prop,float(value)))
                back=float(cap.get(prop))
                control_report[name]={'requested':float(value),'backend_set_success':ok,'readback':back if np.isfinite(back) else None,
                                      'verified_on_hardware':False,'note':'backend readback, not calibrated pixel effect'}
        for _ in range(count):
            ok,frame=cap.read()
            if not ok:break
            frames.append(frame)
    finally:cap.release()
    if len(frames)<3:raise RuntimeError('fewer than 3 valid frames')
    return frames,control_report

def main(argv=None):
    p=argparse.ArgumentParser(description='Mushroom Alpha: real/recorded camera sensing and 3D computational spikes')
    g=p.add_mutually_exclusive_group(required=True)
    for flag in ('video','device','image','python-file','javascript-file','english','grammar-pairs'):g.add_argument('--'+flag)
    p.add_argument('--frames',type=int,default=24);p.add_argument('--fps',type=float,default=24.0)
    p.add_argument('--core',default='mixed',choices=('mixed','delta','daughter','charlie','original'))
    p.add_argument('--genome',default='prism');p.add_argument('--ocr',action='store_true');p.add_argument('--out')
    p.add_argument('--labels-json');p.add_argument('--save-checkpoint');p.add_argument('--load-checkpoint')
    p.add_argument('--code-language',choices=('none','python','javascript'),default='none')
    p.add_argument('--exposure',type=float);p.add_argument('--gain',type=float);p.add_argument('--focus',type=float)
    p.add_argument('--ask');p.add_argument('--no-optical-alphabet',action='store_true')
    args=p.parse_args(argv)
    if not 3<=args.frames<=240:raise ValueError('3..240 frames')
    if args.video or args.device:
        controls={k:getattr(args,k) for k in ('exposure','gain','focus') if getattr(args,k) is not None}
        if any(not np.isfinite(v) or abs(v)>100000 for v in controls.values()):raise ValueError('invalid camera control value')
        data,control_report=frames_from_source('device' if args.device else 'video',args.device or args.video,args.frames,controls=controls)
        ocr_first=recognize_text(data[0]) if args.ocr else None
        model=Mushroom.from_checkpoint(json.loads(Path(args.load_checkpoint).read_text())) if args.load_checkpoint else Mushroom(args.genome)
        training=model.fit_labeled(data,json.loads(Path(args.labels_json).read_text())) if args.labels_json else None
        result=model.run(data,fps=args.fps,core=args.core,letters=ocr_first['text'] if ocr_first else '',optical_alphabet=not args.no_optical_alphabet)
        if training:result['training']=training
        if args.save_checkpoint:Path(args.save_checkpoint).write_text(json.dumps(model.checkpoint(),indent=2))
        result['alphabet_stream']=letters_from_light(data)
        result['source']={'kind':'device_live_unverified_without_hardware' if args.device else 'decoded_video_file','path':args.device or args.video, 'controls':control_report}
        if args.ocr:result['ocr_first_frame']=ocr_first
        if ocr_first and args.code_language!='none':
            src=ocr_first['text'];result['code_from_ocr']=inspect_python(src) if args.code_language=='python' else inspect_javascript(src)
    elif args.image:
        f=cv2.imread(args.image)
        if f is None:raise ValueError('could not decode image')
        result={'schema':'mushroom/vision-input','ocr':recognize_text(f),'qr':decode_qr(f),'alphabet':letters_from_light([f])}
        if args.code_language!='none':
            src=result['ocr']['text'];result['code_from_ocr']=inspect_python(src) if args.code_language=='python' else inspect_javascript(src)
    elif args.python_file:result=inspect_python(Path(args.python_file).read_text())
    elif args.javascript_file:result=inspect_javascript(Path(args.javascript_file).read_text())
    elif args.english:result=inspect_text(args.english)
    else:
        proc=subprocess.run(['node',str(ROOT/'mushroom/grammar_bridge.mjs')],input=Path(args.grammar_pairs).read_text(),text=True,capture_output=True,timeout=8)
        if proc.returncode:raise RuntimeError(proc.stderr[-800:])
        result=json.loads(proc.stdout)
    if args.ask:result['question_answer']=answer(args.ask,result)
    payload=json.dumps(result,indent=2,allow_nan=False)
    if args.out:Path(args.out).write_text(payload)
    else:print(payload)
    return result
if __name__=='__main__': main()
