"""Finite, evidence-grounded natural-language status interface. NOT an LLM.
It deliberately abstains on any request it cannot substantiate, including
attempts to equate 3D computer nodes with external EM-field measurements.
"""
import re

def answer(question:str,report:dict)->dict:
    if not isinstance(question,str) or not 1<=len(question)<=300:raise ValueError('bounded question required')
    if not isinstance(report,dict):raise ValueError('report required')
    q=' '.join(re.findall(r'[a-z0-9]+',question.lower()))
    def proved(statement,key):return {'status':'SUPPORTED_FROM_REPORT','answer':statement,'evidence_field':key}
    if any(t in q for t in ('conscious','sentient','soul','spirit','aura','mind reading')):
        return proved('No evidence for consciousness, spiritual auras, or thought detection is produced by this instrument.','schema')
    if ('physical' in q or 'real world' in q or 'depth' in q or 'z axis' in q):
        return proved('Z indexes processing scales, not calibrated physical depth or an external magnetic field.','geometry')
    if 'how many' in q and ('neuron' in q or 'cell' in q or 'voxel' in q) and 'count' in report:
        return proved(str(report['count'])+' computational neuron sites.','count')
    if ('spike' in q or 'firing' in q) and 'voxel_total_spikes' in report:
        return proved(str(report['voxel_total_spikes'])+' simulated conductance-neuron spike events.','voxel_total_spikes')
    if ('synapse' in q or 'connection' in q) and 'edge_count' in report:
        return proved(str(report['edge_count'])+' directed nearest-neighbor synapses.','edge_count')
    if ('recruit' in q or 'birth' in q or 'growth' in q) and 'total_births' in report:
        return proved(str(report['total_births'])+' software neuron recruitments.','total_births')
    if ('which core' in q or 'neuron type' in q) and 'core' in report:return proved(report['core'],'core')
    if ('alphabet' in q or 'letter' in q) and 'alphabet_stream' in report:
        return proved(''.join(row['symbol'] for row in report['alphabet_stream']), 'alphabet_stream')
    if ('function' in q or 'import' in q) and report.get('language')=='python' and report.get('parse_ok'):
        key='functions' if 'function' in q else 'imports'
        return proved(', '.join(report[key]),key)
    if ('what text' in q or 'can you read' in q) and 'ocr' in report:
        return proved(report['ocr'].get('text','') or 'No reliable recognized text.','ocr')
    return {'status':'ABSTAIN_UNKNOWN','answer':None,'evidence_field':None,'reason':'No supported exact answer in model report. No generative guess.'}
