"""Real optical input and A-Z observations. Explicit separation:
- optical *symbol code* A-Z is quantized intensity, not linguistic OCR;
- optical *text* uses installed Tesseract OCR, with confidence and no guarantee;
- program source uses parsers, not generative speculation or execution.
"""
from __future__ import annotations
import ast,collections,hashlib,io,json,keyword,math,re,subprocess,tokenize,shutil
from pathlib import Path
import cv2,numpy as np

ABC='ABCDEFGHIJKLMNOPQRSTUVWXYZ'

def letters_from_light(frames):
    """Deterministic 26-level luminance quantizer; LOSSY and exposure-sensitive."""
    rows=[]
    for i,frame in enumerate(frames):
        if not isinstance(frame,np.ndarray) or frame.ndim!=3 or frame.shape[2]!=3 or frame.dtype!=np.uint8:raise ValueError('BGR uint8 image required')
        x=float(cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY).mean())/255
        index=min(25,int(x*26))
        rows.append({'frame':i,'luminance_normalized':round(x,7),'symbol':ABC[index],'symbol_index':index,'meaning':'optical_intensity_quantization_NOT_recognized_text'})
    return rows

def recognize_text(image,*,minimum_confidence=40):
    if not isinstance(image,np.ndarray) or image.dtype!=np.uint8 or image.ndim not in (2,3):raise ValueError('requires image array')
    if shutil.which('tesseract') is None:return {'status':'UNAVAILABLE','reason':'Tesseract binary not installed','text':'','words':[]}
    import pytesseract
    from pytesseract import Output
    if image.ndim==3 and image.shape[2]!=3:raise ValueError('BGR image must have 3 channels')
    gray=cv2.cvtColor(image,cv2.COLOR_BGR2GRAY) if image.ndim==3 else image
    if gray.shape[0]<20 or gray.shape[1]<20:raise ValueError('image too small')
    d=pytesseract.image_to_data(gray,config='--psm 6 -l eng',output_type=Output.DICT,timeout=15)
    words=[]
    for i,raw in enumerate(d['text']):
        txt=raw.strip()
        try:confidence=float(d['conf'][i])
        except (ValueError,TypeError):continue
        if txt and confidence>=minimum_confidence:words.append({'text':txt,'confidence':confidence,'bbox':[int(d[k][i]) for k in ('left','top','width','height')]})
    return {'status':'OBSERVED_OCR' if words else 'NO_RELIABLE_TEXT','text':' '.join(w['text'] for w in words),
            'words':words,'letters_A_to_Z':[c for c in ''.join(w['text'] for w in words).upper() if c in ABC],
            'interpretation':'OCR hypothesis, not proven transcription or semantic comprehension'}

def inspect_python(src):
    if not isinstance(src,str) or len(src)>100000:raise ValueError('source text limit')
    try:tree=ast.parse(src)
    except SyntaxError as e:return {'language':'python','parse_ok':False,'syntax_error':{'line':e.lineno,'message':e.msg},'executable':False}
    calls=[];names=[];imports=[];funcs=[];classes=[]
    for n in ast.walk(tree):
        if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):funcs.append(n.name)
        if isinstance(n,ast.ClassDef):classes.append(n.name)
        if isinstance(n,ast.Import):imports.extend(a.name for a in n.names)
        if isinstance(n,ast.ImportFrom):imports.append(n.module or '')
        if isinstance(n,ast.Call):
            if isinstance(n.func,ast.Name):calls.append(n.func.id)
            elif isinstance(n.func,ast.Attribute):calls.append(n.func.attr)
        if isinstance(n,ast.Name):names.append(n.id)
    return {'language':'python','parse_ok':True,'functions':sorted(set(funcs)), 'classes':sorted(set(classes)),
            'imports':sorted(set(imports)),'calls':dict(collections.Counter(calls).most_common(30)),
            'identifiers':sorted(set(names))[:60], 'node_count':sum(1 for _ in ast.walk(tree)),
            'source_sha256':hashlib.sha256(src.encode()).hexdigest(),'executable':False,
            'scope':'syntax structure, NOT formal verification or general program comprehension'}

def inspect_javascript(src):
    if not isinstance(src,str) or len(src)>100000:raise ValueError('source text limit')
    if not shutil.which('node'):return {'language':'javascript','parse_ok':None,'status':'UNAVAILABLE_NODE'}
    # --check stdin parses but does not execute source.
    p=subprocess.run(['node','--check','--input-type=module'],input=src,text=True,capture_output=True,timeout=8)
    return {'language':'javascript','parse_ok':p.returncode==0,'errors':p.stderr[-600:] if p.returncode else None,
            'source_sha256':hashlib.sha256(src.encode()).hexdigest(),'executable':False,
            'scope':'JavaScript syntax validation; no execution or semantic comprehension'}

def inspect_text(text):
    if not isinstance(text,str) or len(text)>100000:raise ValueError('text limit')
    words=re.findall(r"[A-Za-z]+(?:'[A-Za-z]+)?",text)
    return {'alphabet_letters':[s for s in text.upper() if s in ABC],'word_count':len(words),
            'common_words':dict(collections.Counter(w.lower() for w in words).most_common(12)),
            'sha256':hashlib.sha256(text.encode()).hexdigest(),'scope':'lexical extraction, NOT ChatGPT-equivalent language comprehension'}

def decode_qr(frame):
    if not isinstance(frame,np.ndarray) or frame.dtype!=np.uint8:raise ValueError('invalid image')
    val,points,_=cv2.QRCodeDetector().detectAndDecode(frame)
    return {'status':'QR_DECODED' if val else 'NO_QR_FOUND','data':val,'corners':points.tolist() if points is not None else []}
