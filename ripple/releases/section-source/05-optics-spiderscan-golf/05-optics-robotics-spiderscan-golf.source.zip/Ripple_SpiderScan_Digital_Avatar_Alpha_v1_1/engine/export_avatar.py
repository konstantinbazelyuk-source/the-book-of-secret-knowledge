"""Export a single exact kinematic POSE of executed motor trace as glTF binary.
Static scene; Godot project and browser use time series for animated motion.
"""
import numpy as np
import trimesh,json,math
from pathlib import Path

def run(root:Path):
    sim=json.loads((root/'sim_results/replay.json').read_text())
    f=sim['timeline'][30]
    body=np.array(f['body'])
    scene=trimesh.Scene()
    def add_mesh(mesh,name,color):
        mesh.visual.face_colors=color
        scene.add_geometry(mesh,node_name=name)
    def leg_segment(a,b,radius_mm,name,color):
        p=np.array(a,dtype=float)+body;q=np.array(b,dtype=float)+body
        d=(q-p)/1000
        mesh=trimesh.creation.cylinder(radius=radius_mm/1000,height=float(np.linalg.norm(d)),sections=12)
        mat=trimesh.geometry.align_vectors([0,0,1],d)
        mesh.apply_transform(mat)
        mesh.apply_translation((p+q)/2000)
        add_mesh(mesh,name,color)
    disk=trimesh.creation.cylinder(radius=.075,height=.012,sections=8)
    disk.apply_translation(body/1000)
    add_mesh(disk,'body_hull',[30,117,145,255])
    scan=trimesh.creation.box(extents=[.055,.05,.010])
    scan.apply_translation(body/1000+np.array([0,0,-.018]))
    add_mesh(scan,'scanner_head',[50,196,224,255])
    for leg in f['legs']:
        i=leg['id']
        pts=[leg[x] for x in ('hip','coxa','knee','toe')]
        for j in range(3):
            leg_segment(pts[j],pts[j+1],4.0,f'leg_{i}_link_{j}',[100,220,180,255] if leg['stance_command'] else [245,174,101,255])
    out=root/'avatar/SpiderScan_24DOF_POSED_REFERENCE.glb'
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_bytes(scene.export(file_type='glb'))
    loaded=trimesh.load(str(out),force='scene')
    return {'glb':str(out),'geometry_parts':len(loaded.geometry),'bytes':out.stat().st_size,
            'evidence':'mesh_created_from_executed_simulation_pose_not_physical_scan'}

if __name__=='__main__':
    root=Path(__file__).resolve().parents[1]
    print(json.dumps(run(root),indent=2))
