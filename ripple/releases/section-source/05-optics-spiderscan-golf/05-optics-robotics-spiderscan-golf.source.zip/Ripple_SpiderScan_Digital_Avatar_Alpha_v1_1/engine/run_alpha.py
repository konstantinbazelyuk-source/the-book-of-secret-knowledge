"""Run reproducible digital motor and optical trials. writes replay frames for live browser/Godot avatar."""
from pathlib import Path
import json,hashlib,argparse,time,cv2
from engine.digital_motor import SpiderMotorTwin
from engine.alpha_lab import visual_observer,compare_image_workers
from engine.synthetic_map import produce_map

def run(root:Path, duration:float=12.0, dt:float=.02):
    root.mkdir(parents=True,exist_ok=True)
    motors=SpiderMotorTwin()
    slow=SpiderMotorTwin(motor_tau_s=.30,motor_max_speed=1.0)
    ideal=SpiderMotorTwin(motor_tau_s=.001,motor_max_speed=1e5)
    frames=[]
    steps=round(duration/dt)
    if steps<10 or steps>10000:raise ValueError('steps out of bounds')
    for i in range(steps):
        a=motors.tick(dt);slow.tick(dt);ideal.tick(dt)
        if i%5==0:frames.append(a)
    src=Path(__file__).resolve().parents[1]
    neuron=src/'legacy/ripple_optical_agent_LOCKED.py'
    image=src/'assets/archived_photo_NOT_HARDWARE.png'
    photo=cv2.imread(str(image))
    if photo is None:raise RuntimeError('cannot open source image')
    obs=visual_observer(photo,frames=60)
    concurrency=compare_image_workers(cv2.resize(photo,(256,256)),workers=2)
    synthetic_map=produce_map(root,frames)
    result={'schema':'ripple-spider-alpha-sim/1.1','origin':'DIGITAL_SIMULATION_NOT_PHYSICAL_SENSOR',
            'model':'bounded-rate_first_order_joint_response_AND_forward_kinematics_NO_FORCE_PHYSICS',
            'dt_s':dt,'geometry_mm':{'coxa':32,'femur':72,'tibia':95,'hip_radius':70,
                                  'body_reference_height':105,'not_octobot_measured':True},
            'neuron_sha256':hashlib.sha256(neuron.read_bytes()).hexdigest(),
            'photo_sha256':hashlib.sha256(image.read_bytes()).hexdigest(),
            'modelled':{'nominal':motors.metrics(),'slow_motor':slow.metrics(),'nearly_ideal':ideal.metrics()},
            'optical_colony':{k:v for k,v in obs.items() if k!='observation_log'},
            'local_worker_comparison':concurrency,
            'virtual_map':synthetic_map['map_stats'],
            'motor_trace_file':'replay.json','no_autonomous_intelligence':True,
            'no_real_motor_actuation':True}
    replay={'metadata':{k:result[k] for k in ('schema','origin','dt_s','geometry_mm')},
            'timeline':frames,'optical':obs['observation_log'],
            'map_data':synthetic_map['sample_window'],
            'map_evidence':'FINAL_SIMULATED_MAP_NOT_LIVE_OR_PHYSICAL'}
    (root/'replay.json').write_text(json.dumps(replay,separators=(',',':')))
    (root/'verification.json').write_text(json.dumps(result,indent=2))
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,default=Path('sim_results'));p.add_argument('--seconds',type=float,default=12);x=p.parse_args()
    print(json.dumps(run(x.out,x.seconds),indent=2))
