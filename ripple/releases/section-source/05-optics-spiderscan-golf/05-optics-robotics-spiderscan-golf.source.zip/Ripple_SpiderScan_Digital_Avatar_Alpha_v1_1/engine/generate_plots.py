from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np,json

def generate(root):
    data=json.loads((root/'sim_results/replay.json').read_text())
    fr=data['timeline'][25];body=np.array(fr['body'])
    fig=plt.figure(figsize=(10,7),dpi=155)
    ax=fig.add_subplot(111,projection='3d')
    a=np.linspace(0,2*np.pi,9)
    ax.plot(body[0]+72*np.cos(a),body[1]+72*np.sin(a),body[2]*np.ones_like(a),linewidth=4,label='Chassis (model)')
    colors=['#2e877e','#ce9352']
    for leg in fr['legs']:
        xyz=np.array([leg[x] for x in ('hip','coxa','knee','toe')])+body
        ax.plot(xyz[:,0],xyz[:,1],xyz[:,2],lw=2.5,color=colors[0 if leg['stance_command'] else 1]);ax.scatter(xyz[-1,0],xyz[-1,1],xyz[-1,2],s=10,color=colors[0 if leg['stance_command'] else 1]);
    gx=np.linspace(-90,540,10);gy=np.linspace(-230,230,9)
    for x in gx:ax.plot([x,x],[gy[0],gy[-1]],[0,0],color='#d5dbdf',lw=.6)
    for y in gy:ax.plot([gx[0],gx[-1]],[y,y],[0,0],color='#d5dbdf',lw=.6)
    ax.set_xlim(-80,540);ax.set_ylim(-230,230);ax.set_zlim(0,235);ax.set_xlabel('X / mm');ax.set_ylabel('Y / mm');ax.set_zlabel('Height / mm');ax.set_title('SpiderScan digital avatar: 8 legs / 24 joints / simulated motor state')
    ax.view_init(elev=27,azim=-62)
    fig.text(.5,.01,'Calculated kinematic pose — geometry and motor constants assumed, not physically measured.',ha='center',fontsize=9)
    fig.savefig(root/'sim_results/digital_avatar_3d_pose.png',bbox_inches='tight');plt.close(fig)
    scores=json.loads((root/'sim_results/verification.json').read_text())['modelled']
    fig,ax=plt.subplots(figsize=(9,5),dpi=155)
    labels=['Near-ideal','Nominal','Slow'];rmse=[scores['nearly_ideal']['rms_toe_error_mm'],scores['nominal']['rms_toe_error_mm'],scores['slow_motor']['rms_toe_error_mm']]
    b=ax.bar(labels,rmse,color=['#8dcfb9','#3f9394','#d7a16b']);ax.set_ylabel('Digital toe-position RMS error (mm)');ax.set_title('Same command trajectory, different simulated motor response')
    for p,v in zip(b,rmse):ax.text(p.get_x()+p.get_width()/2,v+.1,f'{v:.2f} mm',ha='center')
    ax.set_ylim(0,max(rmse)*1.2);fig.tight_layout();fig.savefig(root/'sim_results/digital_motor_comparison.png');plt.close(fig)
if __name__=='__main__':generate(Path(__file__).resolve().parents[1])
