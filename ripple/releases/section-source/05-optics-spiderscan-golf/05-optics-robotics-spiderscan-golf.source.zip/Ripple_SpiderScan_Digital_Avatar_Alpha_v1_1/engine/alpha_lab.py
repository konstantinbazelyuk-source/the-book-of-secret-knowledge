"""Research-only colony optical workload and external grid mapping; no machine motion commands."""
import sys, hashlib, json, math, time
from pathlib import Path
import numpy as np
import cv2
from legacy.ripple_optical_agent_LOCKED import RippleNeuron
from legacy.ground_colony_v06_LOCKED import GroundColony

def visual_observer(image,frames=60,dt=0.05,occlusion_fraction=0.08,diffuse_sigma=1.2):
    """Fixture experiment using actual source pixels + programmatically modified copies.
    Occlusion and diffusion are SYNTHETIC; color coefficients are not learned weights.
    """
    base=cv2.resize(image,(128,128),interpolation=cv2.INTER_AREA)
    colony=GroundColony(rows=4,cols=4,capacity=16,min_nodes=2,texture_threshold=18.0)
    results=[];total_spikes=0
    for frame in range(frames):
        warped=np.roll(base,shift=frame%13,axis=1)
        if diffuse_sigma>0: warped=cv2.GaussianBlur(warped,(0,0),diffuse_sigma)
        warped=warped.copy()
        if occlusion_fraction>0:
            width=int(warped.shape[1]*occlusion_fraction)
            warped[27:87,32:32+width]=(0,0,0)
        r=colony.process(warped,dt)
        total_spikes+=r['events']
        results.append({'frame':frame,'nodes':r['nodes'],'spikes':r['events'],
                        'theta_mean':round(sum(x['theta'] for x in r['tiles'])/len(r['tiles']),5),
                        'rgb_slot_mean':[round(float(x),5) for x in cv2.cvtColor(warped,cv2.COLOR_BGR2RGB).mean((0,1))/255]})
    return {'observation_log':results,'events':total_spikes,'max_nodes':max(x['nodes'] for x in results),
            'lifecycle':colony.lifecycle,'evidence':'archived_photo_pixels_with_synthetic_occlusion_and_diffusion',
            'occlusion_fraction':occlusion_fraction,'gaussian_sigma_pixels':diffuse_sigma}

def feature_tile(tile):
    if tile is None or tile.ndim!=3 or tile.shape[2]!=3:raise ValueError('expected BGR image')
    return tuple(float(v) for v in cv2.mean(tile)[:3])

def compare_image_workers(img,rows=8,cols=8,workers=2):
    """Local CPU process pool vs serial; identical calculations, not cloud execution."""
    from concurrent.futures import ProcessPoolExecutor
    import multiprocessing
    h,w=img.shape[:2]
    tiles=[np.ascontiguousarray(img[y*h//rows:(y+1)*h//rows,x*w//cols:(x+1)*w//cols])
           for y in range(rows) for x in range(cols)]
    s0=time.perf_counter();serial=list(map(feature_tile,tiles));s_ms=(time.perf_counter()-s0)*1000
    p0=time.perf_counter()
    with ProcessPoolExecutor(max_workers=workers,mp_context=multiprocessing.get_context('spawn')) as pool: parallel=list(pool.map(feature_tile,tiles))
    p_ms=(time.perf_counter()-p0)*1000
    if serial!=parallel:raise AssertionError('parallel mismatch')
    return {'tiles':len(tiles),'workers':workers,'serial_ms':round(s_ms,3),'multiprocess_ms':round(p_ms,3),
            'identical':True,'evidence':'measured_local_machine_not_cloud_and_process_startup_included'}
