"""Rebuild offline viewer and Godot replay from last executed JSON trace."""
from pathlib import Path

def bundle(root:Path):
    source=(root/'web/index.html').read_text()
    data=(root/'sim_results/replay.json').read_text()
    (root/'web/standalone.html').write_text(source.replace('<script>','<script type="application/json" id="embedded-trace">'+data.replace('</','<\\/')+'</script><script>',1))
    (root/'godot/data/replay.json').write_text(data)
    return len(data)
if __name__=='__main__':print('embedded bytes:',bundle(Path(__file__).resolve().parents[1]))
