"""Use preserved 16x16 chunk store in a simulation-only namespace.
This NEVER qualifies a simulated position as a physically measured pose.
"""
from pathlib import Path
import json,math
from legacy.chunkmap_v06_LOCKED import ChunkMap

def produce_map(root:Path,frames:list):
    root.mkdir(parents=True,exist_ok=True)
    db=root/'SIMULATED_ONLY_chunkmap.sqlite'
    if db.exists():db.unlink()
    m=ChunkMap(db,cell_mm=50)
    for idx,f in enumerate(frames):
        if idx%5:continue
        # A synthetic virtual range target in the generated world.
        m.update_ray(f['body'][0],f['body'][1],yaw_deg=7*math.sin(idx/12),
                     distance_mm=600+40*math.cos(idx/9),detected=True)
    result={'evidence':'SIMULATED_ONLY_POSE_AND_RANGE','source':'procedural virtual obstacle',
            'no_hardware_pose':True,'not_safe_for_real_navigation':True,
            'map_stats':m.stats(),'chunks':[{'cx':x['cx'],'cy':x['cy'],'revision':x['revision']} for x in m.chunks()],
            'sample_window':m.ros_like_export(-4,-8,24,20)}
    (root/'synthetic_map.json').write_text(json.dumps(result,indent=2))
    m.close();return result
