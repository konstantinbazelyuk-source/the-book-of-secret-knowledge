"""Non-generative, deterministic animation from executed joint trace."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import numpy as np,json,math

def render(root):
    data=json.loads((root/'sim_results/replay.json').read_text())
    frames=[];W=660;H=450
    az=.52;el=.72;dist=690;cam=np.array([math.cos(az)*math.cos(el),math.sin(az)*math.cos(el),math.sin(el)])
    rt=np.array([-math.sin(az),math.cos(az),0]);up=np.array([-math.cos(az)*math.sin(el),-math.sin(az)*math.sin(el),math.cos(el)])
    def proj(p,c):
        p=np.array(p);dv=p-c;depth=dist-np.dot(dv,cam);fac=880/depth
        return (int(W/2+np.dot(dv,rt)*fac),int(H/2-np.dot(dv,up)*fac))
    for frame in data['timeline'][::8]:
        body=np.array(frame['body']);center=np.array([body[0],body[1],54])
        im=Image.new('RGB',(W,H),'#0b202b');d=ImageDraw.Draw(im)
        for x in np.arange(round(body[0]/100)*100-440,body[0]+500,80):d.line([proj([x,-320,0],center),proj([x,320,0],center)],fill='#20404b',width=1)
        for y in range(-320,321,80):d.line([proj([body[0]-500,y,0],center),proj([body[0]+500,y,0],center)],fill='#20404b',width=1)
        ring=[proj([body[0]+72*math.cos(i*math.pi/4),body[1]+72*math.sin(i*math.pi/4),body[2]],center) for i in range(8)]
        d.polygon(ring,fill='#155263');d.line(ring+[ring[0]],fill='#69e6e0',width=4)
        pts=np.array([[body[0]+v,body[1]+w,body[2]-7] for v,w in [(-26,-22),(26,-22),(26,22),(-26,22)]])
        d.polygon([proj(p,center) for p in pts],fill='#258ca6')
        for leg in frame['legs']:
            color='#67edb5' if leg['stance_command'] else '#f5c270'
            pp=[proj(np.array(leg[k])+body,center) for k in ('hip','coxa','knee','toe')]
            d.line(pp,fill=color,width=5,joint='curve')
            x,y=pp[-1];d.ellipse((x-4,y-4,x+4,y+4),fill='#ebf6ef')
        d.text((17,16),'RIPPLE / SPIDERSCAN / DIGITAL MOTOR ALPHA',fill='#bdebe7')
        d.text((17,H-32),f"SIMULATED time {frame['t_s']:.1f}s · {frame['commanded_supports']} stance legs · NOT PHYSICAL",fill='#9cebd6')
        frames.append(im)
    out=root/'sim_results/digital_avatar_replay.gif'
    frames[0].save(out,save_all=True,append_images=frames[1:],duration=170,loop=0,optimize=False)
    return out
if __name__=='__main__':print(render(Path(__file__).resolve().parents[1]))
