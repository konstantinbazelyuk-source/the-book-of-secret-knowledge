# Ripple SpiderScan — Digital Avatar Alpha 1.1

**Eight-legged ground-only digital motor and optical-colony laboratory. No rotors, flight code, real actuation or claims of sentience/intelligence.**

## What is delivered

- **Runs on this machine:** independently computed 24-motor rate-limited tracking simulator, original v0.6 3-DOF leg solver, scripted eight-leg gait, preserved v0.1 RGB Ripple neuron, preserved v0.6 optical region scheduler, explicit synthetic 16×16 chunk-map storage, reproducible CLI, optical blur/occlusion experiment, worker overhead measurement, 19 Python tests, 1 Node.js viewer-logic/canvas stub test, 3D GLB static pose, deterministic animated GIF, and an *offline standalone interactive perspective 3D avatar viewer*.
- **Ready to open in third-party engine:** Godot 4 project with procedural meshes and 24 articulated link segments driven by the same executed Python joint-state trace. The Godot project is **not run-tested here**; local Godot binary unavailable. The standalone HTML is a self-contained JavaScript 3D perspective renderer and not a full collision physics engine.
- **Preserved source:** approved neuron SHA-256 `7f2f611cd8f1717c3d3dcae745dbd41efc37e24315d93878231db52eaf614f77`, original Octobot-independent v0.6 kinematics and v0.6 ground-colony observer. The full prior v0.6 archive is included under `legacy/v0_6_original_release_UNMODIFIED.zip` for transmitter, read-only hardware acquisition adapters, and its original SQLite map.
- **Not produced/verified:** real ground scans, camera/ToF electrical measurements, motor torque/stall, actuator force, real terrain contact, collision physics, battery dynamics, true odometry, intelligent planning, self-learning weights, or mobile/physical robot motion. No online cloud worker or external AI model was run.

## Open now

**Easiest:** open `web/standalone.html` locally. It embeds 120 motor frames and synthetic map data; it should work without internet. Play/pause, scrub 12 s of calculated motion, drag orbit view, scroll zoom, read neuron event and scan inputs. Its JavaScript passed Node syntax and DOM/canvas stub tests, **not** a full Chromium rendering test (environment denied both file and localhost access).

**Godot:** install Godot 4.4+; open `godot/project.godot`. It renders 8 moving three-link legs, scanning head and ground plane using `godot/data/replay.json`. This is a game-engine kinematic playback, no rigid-body contact. Godot's joint/physics simulation would be a further step once inertias, motor torques, friction and collision geometry are measured or formally assumed.

**CAD/game engines:** `avatar/SpiderScan_24DOF_POSED_REFERENCE.glb` is an independently generated glTF binary mesh from simulation frame 30, with 26 individual mesh components, not the Octobot CAD/STEP. Units: meters, original trace geometry uses Z-up. Import rotation and units into any engine may need adjustment. The GLB was exported and reopened successfully by trimesh.

## Reproduce all core experiments

Python 3.11+ with `numpy`, `opencv-python`, `pytest`, `trimesh`, `matplotlib` and `Pillow`; Node 20+ only for viewer JavaScript verification:

```bash
python -m pip install -r requirements.txt
PYTHONPATH=. python -m engine.run_alpha --out sim_results
PYTHONPATH=. python -m pytest -q tests
node tests/avatar_smoke.js
python -m engine.export_avatar
python -m engine.generate_plots
python -m engine.animate_gif
```

`web/standalone.html` is made by embedding the latest `sim_results/replay.json` into `web/index.html`. A new run will not automatically rewrite the portable standalone file; use `python engine/bundle_viewer.py` to regenerate it. The script also updates the Godot replay copy. Run `python web/serve.py` to use the non-embedded viewer at `http://127.0.0.1:8099/web/index.html` on your own machine.

## Geometry, motors, and motion formulas

The source geometry remains **assumed**: coxa=32 mm, femur=72 mm, tibia=95 mm, hip mount radius=70 mm, body reference height=105 mm; joint limits as in v0.6. These are **not** measurements from the real Octobot CAD. Eight radial 3-DOF legs provide 24 joint coordinates. Test gait period=1.6 s, stride=38 mm, duty=70%, swing height=22 mm. A body trajectory is *commanded* as speed `stride/(period*duty) = 33.93 mm/s`. It is not generated through ground-contact dynamics.

Each modeled actuator follows:

```
proposal = (q_target - q_actual) × [1 - exp(-dt/τ)]
q_next = q_actual + clamp(proposal, -v_max × dt, +v_max × dt)
```

Nominal ASSUMED constants: `τ=0.075 s`, `v_max=3 rad/s`. Slower comparison: `τ=0.30 s`, `v_max=1 rad/s`. Near-ideal mathematical control: `τ=0.001 s`, `v_max=100000 rad/s`. Trial: 600 updates, dt=0.02 s. Foot endpoints are recovered from actual motor angles by forward kinematics; RMS position error and stance threshold proxy are computed from the command/actual difference. **A toe within 7 mm of a target is not proof of weight-bearing ground contact.**

Important separation: `minimum_commanded_support_legs` is simply how many commanded feet are in stance. It is not computed as a stable support polygon, contact force, or center-of-mass feasibility certificate. No physical navigation or servo PWM is generated.

## Ripple Colony and archived Alpha integrations

- `legacy/ripple_optical_agent_LOCKED.py` is a byte-for-byte copy of approved Ripple v0.1 core. The fixed red(+2), green(+1.2), and blue(-1.4) weights, refractory and adaptive threshold remain intact.
- Optical region processing is a byte-for-byte copy of the v0.6 ground-colony adapter; it assigns persistent neuron state to 4×4 image regions, expanding nodes with textured workload. Those are **logical neuron computations**, not CPU threads or new learned models.
- The fixture contains real-world *archived photo pixels*, but shifted images, Gaussian blur (σ=1.2 px), 8%-wide artificial occlusion, and range/pose values are simulated. Digital blur is not a real photon diffusion experiment. RGB is a sensor-feature slot, not a quantum measurement.
- Minecraft-like storage uses the unmodified v0.6 SQLite 16×16 compressed occupancy chunks in the `SIMULATED_ONLY_chunkmap.sqlite` file. The final map is labeled simulated in the JSON and viewer. Empty/occupied hypotheses are **not** qualified for navigation.
- Earlier Ripple Alpha experiments on color-coded gene species, density, 2D/3D maps, and monochrome emergence remain separate research; this motor experiment does not claim to integrate their independent artificial genetic algorithms or establish learned motor skills.

## Capacity and cloud-farm result

64 BGR tiles produced **identical serial and two-process output**. On this execution, sequential processing took ~0.15 ms and fresh-process processing ~889 ms, including safe `spawn` startup. Multiprocessing on tiny jobs was far slower. These are local observed timings, not Raspberry Pi or cloud measurements; benchmark varies each run.

**Recommended research architecture for future larger jobs:** independent read-only visual chunks -> bounded queue -> local workers -> optional Ray actors -> checked event hash -> SQLite map commit. Ray actor workers require explicit checkpointing for durable state after restart; CPU workers may not alter motor or safety commands. Ray was not deployed or timed. Existing v0.6 TLS transmitter is retained unchanged in the nested original release, with physical sensor reports never conflated with simulation data.

## Technologies compared / sourced

1. [Octobot repository, MIT license](https://github.com/Deivid-Negoita/octobot): functioning reference browser Three.js rig, joint IK, 24-servo architecture and mechanical STEP. Their actual GLB/STEP was **not** downloaded or included; our avatar is parametric, not reverse-engineered to that exact chassis.
2. [Godot Skeleton3D documentation](https://docs.godotengine.org/en/stable/classes/class_skeleton3d.html): legitimate game engine mechanism. This handoff uses procedural mesh links, not a fitted imported skeleton.
3. [MuJoCo modeling documentation](https://mujoco.readthedocs.io/en/stable/modeling.html): MJCF rigid-body/contact and actuator dynamics for later calibrated physics. MuJoCo was not installed or run in this environment.
4. [NVIDIA Isaac Sim robotics control](https://docs.isaacsim.omniverse.nvidia.com/latest/ros2_tutorials/robot_control/tutorial_ros2_control.html): future hardware abstraction once physical servo parameters become available, not executed here.
5. [Ray actors and checkpointing](https://docs.ray.io/en/latest/ray-core/fault_tolerance/actors.html): optional distributed farm for heavy read-only imaging; not run.
6. [Minecraft chunk documentation](https://minecraft.wiki/w/Chunk_format): conceptual chunk addressing only; no game code or proprietary assets copied.
7. Prior Ripple v0.6 closed loop: `legacy/v0_6_original_release_UNMODIFIED.zip` includes scanner bridge and secure transmitter original; original archive is unchanged.

## Limits and next scientific gate

This is a **working alpha for simulated digital motor operations and visualization**, not a commissioned full-physics digital twin or real walking robot. Before claims about physical stability or sim-to-real performance: fit parametric links against measured Octobot STEP assemblies; determine mass distribution, actuator torque/speed curves, servo PWM/zero maps, collision geometry, friction and ground profile; then run a real physics engine and separately compare instrumented physical captures. Avoid granting authority to any model to control unsupervised motors.

No Grok, Gemini, Meta AI, cloud provider, external manufacturer or real robot was connected or queried for private computation here. Published software engineering sources were researched. No purchase, drone flight, camera laser, or robot actuation occurred.
