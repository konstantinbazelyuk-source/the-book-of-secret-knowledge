// Executable DOM/canvas stub validation: NOT equivalent to a real browser smoke test.
const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const ROOT=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(ROOT,'web','standalone.html'),'utf8');
const match=html.match(/<script>([\s\S]*?)<\/script>/);
assert(match,'inline JS missing');
const data=JSON.parse(html.match(/<script type="application\/json" id="embedded-trace">([\s\S]*?)<\/script>/)[1]);
assert.strictEqual(data.metadata.origin,'DIGITAL_SIMULATION_NOT_PHYSICAL_SENSOR');
let drawCalls=0;
const ctx={setTransform(){},clearRect(){drawCalls++},beginPath(){},moveTo(){},lineTo(){},closePath(){},stroke(){drawCalls++},fill(){drawCalls++},arc(){},fillRect(){drawCalls++},strokeRect(){drawCalls++}};
const el={};
for(const id of ['stage','map','play','reset','timeline','speed','evidence','supports','contacts','colonynodes','spikes','distance','error','time','rgb','theta','origin']){
 el[id]={id,textContent:'',value:'1',style:{},innerText:'',clientWidth:960,clientHeight:540,width:360,height:192,
  getContext:()=>ctx,getBoundingClientRect:()=>({width:960,height:540}),
  addEventListener(){},setPointerCapture(){}};
}
el.play.textContent='Pause';el.speed.value='1';el['embedded-trace']={textContent:JSON.stringify(data)};
const document={getElementById:(id)=>el[id]??null};
const window={addEventListener(){}};
const frameCalls=[];
const box={document,window,console,Math,JSON,devicePixelRatio:1,requestAnimationFrame:(cb)=>{frameCalls.push(cb)},performance:{now:()=>0}};
vm.runInNewContext(match[1],box,{timeout:4000});
setTimeout(()=>{
 assert(el.evidence.textContent.includes('SIMULATION'),'evidence boundary');
 assert(/\/8/.test(el.supports.textContent),'support metric shown');
 assert(drawCalls>100,'3D projection path drew less than 100 operations');
 assert.strictEqual(Number(el.timeline.max),data.timeline.length-1);
 el.play.onclick();assert.strictEqual(el.play.textContent,'Play');
 el.timeline.value='48';el.timeline.oninput();
 assert.strictEqual(el.time.textContent, data.timeline[48].t_s.toFixed(2)+'s');
 assert.strictEqual(data.map_evidence,'FINAL_SIMULATED_MAP_NOT_LIVE_OR_PHYSICAL');
 console.log(JSON.stringify({status:'PASS',camera_draw_calls:drawCalls,frames:data.timeline.length,
   simulated_map_cells:data.map_data.data.length,simulated_motion_control:true,
   caveat:'DOM canvas stub only; not Chromium/Godot runtime'}));
},20);
