from pathlib import Path
from math import pi,sin,cos
import hashlib,math,json,tempfile
import numpy as np
import cv2
import pytest
from engine.digital_motor import DigitalMotor,SpiderMotorTwin
from engine.alpha_lab import visual_observer,feature_tile
from engine.synthetic_map import produce_map
from engine.run_alpha import run
from legacy.approved_kinematics_v06 import solve_leg, forward_leg, Unreachable

ROOT=Path(__file__).resolve().parents[1]
SOURCE=Path('/mnt/data/Ripple_SpiderScan_Colony_v0_6')

def test_locked_core_hash_unchanged():
    assert hashlib.sha256((ROOT/'legacy/ripple_optical_agent_LOCKED.py').read_bytes()).hexdigest()=='7f2f611cd8f1717c3d3dcae745dbd41efc37e24315d93878231db52eaf614f77'

def test_locked_ik_source_preserved():
    if SOURCE.exists(): assert (ROOT/'legacy/approved_kinematics_v06.py').read_bytes()==(SOURCE/'spidercolony/kinematics.py').read_bytes()

def test_no_kinematic_ik_violations():
    twin=SpiderMotorTwin()
    for leg in range(8):
        for k in range(100):
            xyz,_=twin.target(leg,k*.03)
            angles=solve_leg(*xyz)
            abc=forward_leg(angles)
            assert max(abs(a-b) for a,b in zip(xyz,abc))<1e-8

def test_motor_rate_bound():
    mot=DigitalMotor(angle=0,max_speed_rad_s=1,time_constant_s=.01)
    prev=mot.angle
    for _ in range(100):
        mot.step(10,.01)
        assert abs(mot.angle-prev)<=.0100000000001
        prev=mot.angle
    assert mot.clip_hits>0

def test_motor_sign_follows_target():
    mot=DigitalMotor(0)
    x=mot.step(-.5,.02);assert x<0

def test_motor_reject_bad_dt():
    with pytest.raises(ValueError):DigitalMotor(0).step(.3,0)
    with pytest.raises(ValueError):DigitalMotor(0).step(.3,1)
    with pytest.raises(ValueError):DigitalMotor(0).step(float('nan'),.05)

def test_stance_count_4_or_more():
    m=SpiderMotorTwin()
    for k in range(150):
        f=m.tick(.02)
        assert f['commanded_supports']>=4
        assert len(f['legs'])==8
        assert all(len(x['joint_angles_rad'])==3 for x in f['legs'])

def test_ik_success_over_trial():
    m=SpiderMotorTwin()
    for k in range(280):m.tick(.02)
    assert m.metrics()['ik_failures']==0

def test_nominal_less_error_than_slow():
    a=SpiderMotorTwin();b=SpiderMotorTwin(motor_tau_s=.3,motor_max_speed=1)
    for _ in range(240):a.tick(.02);b.tick(.02)
    assert a.metrics()['rms_toe_error_mm']<b.metrics()['rms_toe_error_mm']
    assert a.metrics()['contact_proxy_pct']>b.metrics()['contact_proxy_pct']

def test_near_ideal_not_real():
    a=SpiderMotorTwin(motor_tau_s=.001,motor_max_speed=1e5)
    for _ in range(30):a.tick(.02)
    assert a.metrics()['rms_toe_error_mm']<.001

def test_texture_colony_preserves_base_equation():
    from legacy.ripple_optical_agent_LOCKED import RippleNeuron
    r=RippleNeuron().step((.3,.4,.2),.05)
    assert r['drive']==pytest.approx(2*.3+1.2*.4-1.4*.2)

def test_observer_does_not_require_hardware():
    img=np.zeros((64,64,3),np.uint8)
    cv2.rectangle(img,(0,0),(30,30),(0,230,120),-1)
    d=visual_observer(img,frames=5,dt=.05)
    assert d['observation_log'][0]['nodes']>=2
    assert 'synthetic' in d['evidence']

def test_feature_tile_bgr_label():
    tile=np.zeros((12,12,3),np.uint8);tile[:]=(10,20,30)
    assert feature_tile(tile)==(10,20,30)

def test_virtual_map_never_claims_hardware(tmp_path):
    m=SpiderMotorTwin();fr=[m.tick(.02) for _ in range(20)]
    x=produce_map(tmp_path,fr)
    assert x['no_hardware_pose'] and x['not_safe_for_real_navigation']
    assert x['map_stats']['chunks']>0
    assert x['map_stats']['known_cells']>0

def test_virtual_map_persists(tmp_path):
    from legacy.chunkmap_v06_LOCKED import ChunkMap
    m=ChunkMap(tmp_path/'one.sqlite');m.put(-1,-2,100);m.close()
    m=ChunkMap(tmp_path/'one.sqlite');assert m.get(-1,-2)==100;m.close()

def test_replay_has_twenty_four_states(tmp_path):
    d=run(tmp_path,2.0)
    x=json.loads((tmp_path/'replay.json').read_text())
    assert len(x['timeline'])==20
    assert len(x['timeline'][0]['legs'])==8
    assert sum(len(z['joint_angles_rad']) for z in x['timeline'][0]['legs'])==24
    assert d['no_real_motor_actuation']

def test_replay_origin_not_misleading():
    p=ROOT/'sim_results/replay.json'
    x=json.loads(p.read_text())
    assert x['metadata']['origin']=='DIGITAL_SIMULATION_NOT_PHYSICAL_SENSOR'

def test_standalone_viewer_evidence():
    viewer=(ROOT/'web/standalone.html').read_text()
    assert 'embedded-trace' in viewer and 'DIGITAL_SIMULATION_NOT_PHYSICAL_SENSOR' in viewer
    assert 'flight' in viewer.lower()

def test_godot_engine_handoff_exists():
    assert (ROOT/'godot/project.godot').is_file()
    assert 'MeshInstance3D' in (ROOT/'godot/main.gd').read_text()
    assert len(json.loads((ROOT/'godot/data/replay.json').read_text())['timeline'])>0
