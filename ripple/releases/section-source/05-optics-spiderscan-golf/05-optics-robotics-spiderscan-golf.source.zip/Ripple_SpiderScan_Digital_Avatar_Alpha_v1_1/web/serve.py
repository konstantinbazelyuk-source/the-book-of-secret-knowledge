from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
import os
from functools import partial
ROOT=Path(__file__).resolve().parents[1]
if __name__=='__main__':
    print('SpiderScan Digital Avatar http://127.0.0.1:8099/web/index.html')
    ThreadingHTTPServer(('127.0.0.1',8099),partial(SimpleHTTPRequestHandler,directory=str(ROOT))).serve_forever()
