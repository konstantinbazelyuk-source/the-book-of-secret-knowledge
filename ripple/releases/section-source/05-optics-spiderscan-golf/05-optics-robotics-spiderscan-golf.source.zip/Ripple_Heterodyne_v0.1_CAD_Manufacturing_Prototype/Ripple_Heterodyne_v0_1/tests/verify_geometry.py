"""Digital manufacturing audit: no hardware measurements.
Run: python tests/verify_geometry.py
"""
from pathlib import Path
import sys,json,datetime
import numpy as np
import trimesh
import ezdxf
ROOT=Path(__file__).resolve().parents[1]
stl=list((ROOT/'cad'/'stl').glob('*.stl'))
assert len(stl)==11,(len(stl),stl)
solids={}
for file in sorted(stl):
    obj=trimesh.load_mesh(file,process=True)
    assert obj.is_watertight, f'Open mesh: {file.name}'
    assert obj.is_volume and obj.volume>0, f'Invalid volume: {file.name}'
    assert (obj.bounds[1]>obj.bounds[0]).all()
    solids[file.stem]={'watertight':obj.is_watertight,
        'is_volume':obj.is_volume,'bounds_mm':np.round(obj.bounds,3).tolist(),
        'volume_mm3':round(float(obj.volume),1),'facets':int(len(obj.faces))}
base=solids['base_plate']['bounds_mm']
assert np.allclose(base[0],[0,0,0]),base
assert np.allclose(base[1],[210,210,6]),base
# Physical fit envelope verifies nominal geometry, not actual hardware.
assert np.allclose(solids['slider_carriage']['bounds_mm'][0],[-17,-29,0])
assert np.allclose(solids['slider_carriage']['bounds_mm'][1],[14,29,42])
dxf=ezdxf.readfile(ROOT/'cad'/'base_drill_plan.dxf')
counts={}
for ent in dxf.modelspace():
    name=ent.dxf.layer
    counts[name]=counts.get(name,0)+1
assert counts['DRILL_3p4']==14,counts
assert counts['DRILL_4p5']==4,counts
assert counts['SLOT_3p4x13p4']==2,counts
assert counts['CUT_OUTER']==1,counts
assert counts['REF_NONCUT']==2,counts
checks={
 'base_bounds_mm':[210,210,6],
 'nominal_beam_height_mm':30,
 'optical_center_local_height_mm':24,
 'moving_mirror_optical_plane_x_at_nominal_mm':147,
 'reference_mirror_plane_y_at_nominal_mm':158,
 'cube_center_xy_mm':[92,100],
 'nominal_arm_length_difference_mm':abs((147-92)-(158-100)),
 'guide_rail_y_mm':[82,118],
 'rail_support_x_mm':[139,193],
 'bearings_in_carriage':'2x LM6UU nominal 6mm ID, 12mm OD, 19mm L - NOT physically tested',
 'digital_geometry_check':'PASS',
 'dxflayer_counts':counts,
 'stl_solid_count':len(solids),
 'stls':solids,
 'no_real_hardware_claim':True,
 'physical_optical_interference_measured':False,
 'hardware_fit_tested':False,
 'full_assembly_collision_check_performed':False,
 'note':'Watertight meshes validate geometry only; do not imply parts will print or fit without adjustment'
}
assert checks['nominal_arm_length_difference_mm']==3
out=ROOT/'results'/'geometry_verification.json'
out.write_text(json.dumps(checks,indent=2))
print('PASS: geometry meshes:',len(solids),'DXF layers:',counts,'nominal arm difference mm:',checks['nominal_arm_length_difference_mm'])
