import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parents[1]/'software'))
from heterodyne import predict_frequency,synthesize,analyze,save_wav,load_wav
from tempfile import TemporaryDirectory
class TestRippleHeterodyne(unittest.TestCase):
    def test_doppler_1_mm_per_s(self):
        self.assertAlmostEqual(predict_frequency(1),3076.9230769,places=3)
    def test_frequency_doubles_with_velocity(self):
        self.assertAlmostEqual(predict_frequency(2),2*predict_frequency(1))
    def test_negative_velocity_lacks_direction(self):
        self.assertEqual(predict_frequency(-1),predict_frequency(1))
    def test_detect_at_1_mm_s(self):
        fs,x=synthesize(1,1,motion_jitter_fraction=0)
        r,_,_=analyze(fs,x)
        self.assertTrue(r['beat_detected'],r)
        self.assertLess(abs(r['peak_hz']-predict_frequency(1)),3)
    def test_detect_at_slow_speed(self):
        fs,x=synthesize(.25,1,motion_jitter_fraction=0)
        r,_,_=analyze(fs,x)
        self.assertTrue(r['beat_detected'],r)
        self.assertLess(abs(r['estimated_abs_velocity_mm_s']-.25),.002)
    def test_block_reference_aborts_detection(self):
        fs,x=synthesize(1,1,both_arms=False)
        r,_,_=analyze(fs,x)
        self.assertFalse(r['beat_detected'],r)
    def test_wav_roundtrip(self):
        fs,x=synthesize(1,1,motion_jitter_fraction=0)
        with TemporaryDirectory() as d:
            path=Path(d)/'capture.wav'
            save_wav(path,fs,x)
            sr,y=load_wav(path)
            self.assertEqual(fs,sr)
            self.assertEqual(len(x),len(y))
            r,_,_=analyze(sr,y)
            self.assertTrue(r['beat_detected'],r)
            self.assertLess(abs(r['peak_hz']-predict_frequency(1)),3)
    def test_detector_max_power_nominal_attenuator(self):
        laser_power_w=0.001
        optical_density=3
        max_detector_power_w=laser_power_w*10**(-optical_density)
        responsivity_a_w=0.45
        feedback_ohm=1_000_000
        v=max_detector_power_w*responsivity_a_w*feedback_ohm
        self.assertAlmostEqual(v,0.45)
        self.assertLess(v,5)
    def test_nyquist_rejected(self):
        with self.assertRaises(ValueError):synthesize(1,1,fs=4000)
    def test_receiver_bandwidth_rejected(self):
        with self.assertRaises(ValueError):synthesize(5,1)
    def test_signal_short_rejected(self):
        with self.assertRaises(ValueError):analyze(48000,[0]*100)
    def test_zero_wavelength_rejected(self):
        with self.assertRaises(ValueError):predict_frequency(1,0)

if __name__=='__main__':unittest.main()
