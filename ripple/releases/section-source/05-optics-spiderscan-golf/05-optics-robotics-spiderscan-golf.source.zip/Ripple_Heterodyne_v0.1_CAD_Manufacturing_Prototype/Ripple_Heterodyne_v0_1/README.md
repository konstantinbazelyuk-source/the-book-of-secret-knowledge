# Ripple Heterodyne Optical Bench v0.1 — buildable engineering demonstrator

**Purpose:** A 3D-manufacturable, manually scanned Michelson interferometer with a **Doppler optical heterodyne** readout. It is a separate optical **observation experiment**; nothing in prior Ripple Neuron equations, control architecture, or the separate Ripple Spectrum v0.1 prototype has been changed.

**Scientific premise:** One red laser is split into fixed-reference and hand-translated mirror paths. Motion gives reflected light a frequency shift. At 650 nm, 1 mm/s nominal mirror speed produces **3,076.92 Hz** beat frequency at a photoelectric detector: `f_beat = 2 |v| / lambda`. The optical carrier is ~461 THz. The photodiode only follows the kHz *difference* signal; it does not sense instantaneous optical electric/magnetic field oscillations.

**Tested now:** CAD exported through OpenSCAD to watertight STL solids, CNC DXF cut/drill plan, software simulation and analyzer, simulated blocked-arm controls, Python unit tests. **No physical hardware has been assembled, no actual coherent interference or physical EM signal has been measured.** Verification reports in `results` describe actual software/geometry testing.

## Visuals

- `docs/CAD_assembly_preview.png` — actual OpenSCAD preview of printed CAD parts and simulated optics lines (NOT a photograph).
- `docs/layout_dimensioned.png` — top-view plan, 210mm × 210mm.
- `docs/receiver_circuit.png` — correct nominal OPT101 and audio line-in signal-chain connections; not physically validated.
- `results/simulated_beat/spectrogram.png` — **SYNTHETIC** Doppler signal, not real measurements.
- `results/simulated_control/spectrogram.png` — **SYNTHETIC** blocked-reference control.

## Files

| Folder | Function |
|---|---|
| `cad/ripple_heterodyne_bench.scad` | Editable mechanical parametric source |
| `cad/stl/` | 11 triangulated printable pieces, print rail_support twice |
| `cad/base_drill_plan.dxf` | CNC/laser-cut base outline and hole/slot patterns; noncut annotation layers |
| `cad/create_drawings.py` | Regenerate machining drawing and top-view layout |
| `software/heterodyne.py` | Simulate, analyze WAV, make plots, report beat frequency/absolute velocity |
| `software/record_linein.py` | Optional actual 48kHz USB line-in recorder (requires sounddevice and hardware) |
| `tests/test_heterodyne.py` | Mathematics, signal detection, blocked controls, negative cases |
| `docs/BUILD_GUIDE.md` | Full mechanical assembly, optics, electrical wiring, alignment, safety |
| `docs/BOM.csv` | Procurable BOM keyed to real component dimensions; no fabricated prices |
| `docs/TEST_PLAN.md` | Laboratory acceptance tests and physical verification gaps |
| `docs/SOURCES.md` | Linkable datasheet and university/supplier references |
| `results/` | Synthetic data and audit information, clearly identified |

## Run software without hardware

Install Python 3.10+ and `numpy`, `scipy`, `matplotlib`. From the project root:

```bash
python -m pip install -r software/requirements.txt
python -m unittest discover -s tests -v
python software/heterodyne.py --simulate --output-dir results/my_sim
python software/heterodyne.py --simulate --blocked-reference --output-dir results/my_control
```

## Build hardware

Read `docs/BUILD_GUIDE.md` **before purchasing**. Required components include low-power verified 650nm laser with 12mm mechanical housing, 10mm 50:50 non-polarizing cube, two 20x20 front-surface mirrors, 2× LM6UU and matching hardened 6mm rods, M6x1 threaded rod, OD3 optical attenuator, TI OPT101, USB soundcard line input, miscellaneous bolts and regulated supplies. There is no high-frequency oscilloscope or AOM in the baseline build. A properly specified optical filter is essential: unattenuated recombined laser light can saturate OPT101.

Do **not** aim lasers at eyes or people, use reflective paths without shielding, or assert that the apparatus measures an aura. Put the finished apparatus behind opaque optical shielding and verify laser label/power and all driver/electrical requirements.

## Next step

Physically fabricate one set of parts, print fit coupons, assemble and align with appropriate laser controls, then record four WAV runs: laser off, reference arm blocked, static mirror, moving mirror at independently measured speed. Report beat frequency and uncertainty, not presumed human energy fields. If successful, extend to stabilized motorized displacement and later coherent optical or multispectral sensor research.

## Openness

The included code/CAD/materials are available under the included permissive MIT license. Hardware manufacturing and electrical/laser compliance remain the responsibility of the builder. This does not assert that any patent rights have been granted by third parties. Attribution appreciated but not required by the MIT terms beyond preserving copyright/license notices.
