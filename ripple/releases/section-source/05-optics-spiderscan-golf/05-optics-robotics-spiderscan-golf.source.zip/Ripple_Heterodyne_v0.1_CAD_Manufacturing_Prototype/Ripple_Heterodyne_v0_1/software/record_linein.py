"""OPTIONAL real input acquisition. Requires USB line-in audio interface + sounddevice.
NO claim that an actual optical signal has been recorded.
Usage: python record_linein.py --list-devices
       python record_linein.py --device 2 --seconds 3 --output raw_linein.wav
Use 48 kHz LINE INPUT (not powered microphone or phantom power).
"""
import argparse
import numpy as np
from scipy.io import wavfile
try:
    import sounddevice as sd
except ImportError:
    raise SystemExit('Install with: pip install sounddevice; must have a supported audio input device')
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--list-devices',action='store_true')
p.add_argument('--device',type=int)
p.add_argument('--seconds',type=float,default=3.)
p.add_argument('--fs',type=int,default=48000)
p.add_argument('--output',default='capture.wav')
a=p.parse_args()
if a.list_devices:
    print(sd.query_devices());quit()
if a.device is None:
    raise SystemExit('Pass --device NUMBER explicitly; use --list-devices first')
if a.seconds<=0 or a.seconds>60: raise SystemExit('Choose duration 0-60s')
print('Recording from selected external input -- do not enable if optics unsafe')
y=sd.rec(int(a.fs*a.seconds),samplerate=a.fs,channels=1,dtype='float32',device=a.device)
sd.wait()
peak=np.max(np.abs(y))
print('Recorded peak amplitude:',float(peak))
if peak>=.99:print('WARNING: CLIPPING -- reduce input gain / optical illumination')
wavfile.write(a.output,a.fs,np.int16(np.clip(y.reshape(-1),-1,1)*32767))
print('Saved',a.output)
