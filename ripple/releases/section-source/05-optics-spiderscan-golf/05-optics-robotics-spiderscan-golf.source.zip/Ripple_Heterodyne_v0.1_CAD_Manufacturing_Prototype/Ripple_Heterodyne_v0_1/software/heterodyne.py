#!/usr/bin/env python3
"""Ripple: physically dimensioned MOVING-MIRROR optical heterodyne test bench.

The simulation synthesizes a laser Doppler beat, OPT101 low-pass roll-off,
AC coupled line-in, and noise. It does NOT model coherent-mode properties,
actual mechanical jitter, or optical alignment. No sensor is connected here.
"""
import argparse
import json
from pathlib import Path
import numpy as np
from scipy import signal
from scipy.io import wavfile

WAVELENGTH_M = 650e-9
OPT101_BW_HZ = 14_000
FS_DEFAULT = 48_000

def predict_frequency(velocity_mm_s: float, wavelength_nm: float = 650.) -> float:
    if wavelength_nm <= 0 or not np.isfinite(wavelength_nm):
        raise ValueError('Positive finite wavelength required')
    if not np.isfinite(velocity_mm_s):
        raise ValueError('Finite velocity required')
    return abs(2 * (velocity_mm_s * 1e-3) / (wavelength_nm * 1e-9))


def synthesize(velocity_mm_s=1., duration_s=1.0, fs=FS_DEFAULT,
               both_arms=True, random_seed=12, wavelength_nm=650.,
               motion_jitter_fraction=0.002, noise_rms=0.006):
    if duration_s <= 0 or fs < 2_000 or motion_jitter_fraction < 0:
        raise ValueError('Invalid sampling/motion settings')
    n = int(np.rint(duration_s * fs))
    if n < 128:
        raise ValueError('Capture too short')
    rng = np.random.default_rng(random_seed)
    t = np.arange(n) / fs
    f0 = predict_frequency(velocity_mm_s, wavelength_nm)
    if f0 >= fs/2 or f0 >= OPT101_BW_HZ:
        raise ValueError('Predicted frequency exceeds sampling Nyquist or photodiode bandwidth')
    # coherent phase is integrated instantaneous Doppler f = 2v/lambda
    freq_inst = f0 * (1 + motion_jitter_fraction * np.sin(2*np.pi*7*t))
    phase = 2*np.pi*np.cumsum(freq_inst) / fs + 0.7
    # Normalized signal, NOT calibrated volts or power.
    # Both paths -> observable interference. Block one path -> no beat.
    raw = (0.32*np.cos(phase) if both_arms else np.zeros(n))
    raw += 0.015*np.sin(2*np.pi*60*t) + rng.normal(0, noise_rms, n)
    # First-order 14k Hz electrical LP (simplified component response).
    sos = signal.butter(1, OPT101_BW_HZ, 'low', fs=fs, output='sos')
    raw = signal.sosfilt(sos, raw)
    raw -= np.mean(raw)
    return fs, raw


def analyze(fs: int, x: np.ndarray, wavelength_nm=650, min_hz=200, max_hz=7000):
    x = np.asarray(x, dtype=float)
    if x.ndim > 1: x = np.mean(x, axis=1)
    if x.size < 512 or not np.all(np.isfinite(x)):
        raise ValueError('At least 512 finite samples needed')
    if fs <= 2*max_hz:
        raise ValueError('Sampling frequency too low for selected max_hz')
    x = x - x.mean()
    # Interference beat appears as a narrow spectral tone with a moving mirror.
    frequencies, power = signal.welch(x, fs=fs,
        window='hann', nperseg=min(x.size, 16384), noverlap=None)
    selection = (frequencies >= min_hz) & (frequencies <= max_hz)
    freqs = frequencies[selection]
    pwr = power[selection]
    if len(pwr) < 12:
        raise ValueError('Insufficient spectral bins')
    ix = np.argmax(pwr)
    peak = float(freqs[ix]); height=float(pwr[ix])
    # Local-bin separation from baseline guards against harmonic, not spurious
    # global jitter. Report only narrowband detection, not proof of optics.
    background = float(np.median(pwr)) + 1e-20
    snr_db = 10*np.log10(max(height, 1e-20) / background)
    found = bool(snr_db >= 18 and np.sqrt(np.mean(x*x)) > 0.0005)
    return {
        'beat_detected': found,
        'peak_hz': round(peak,2) if found else None,
        'estimated_abs_velocity_mm_s': round(peak*wavelength_nm*1e-6/2,5) if found else None,
        'spectral_prominence_db': round(float(snr_db),2),
        'rms_normalized': round(float(np.sqrt(np.mean(x*x))),6),
        'laser_wavelength_nm_assumed': wavelength_nm,
        'sample_rate_hz': fs,
        'sample_count': int(x.size),
        'sensor_units': 'arbitrary; uncalibrated',
        'cannot_measure_motion_direction': True,
        'warning': 'A narrowband peak alone is not proof of optical interference. Perform arm-block and light-off controls.'
    }, frequencies, power


def load_wav(path):
    sr, sig = wavfile.read(path)
    if sig.dtype == np.int16: sig = sig.astype(np.float64)/32768.0
    elif sig.dtype == np.int32: sig = sig.astype(np.float64)/2147483648.0
    else: sig = sig.astype(np.float64)
    return sr, sig


def save_wav(path, fs, sig):
    x = np.clip(sig,-0.999,0.999)
    wavfile.write(path, fs, np.int16(np.round(x*32767)))


def plot_analysis(out, fs, x, frequencies, power, detected, title):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, (a,b)=plt.subplots(2,1,figsize=(10,7))
    n=min(int(fs*0.008),len(x))
    a.plot(np.arange(n)/fs*1000,x[:n],lw=0.85)
    a.set(xlabel='Time (ms)',ylabel='Normalized line-in signal',title='Example short time capture')
    a.grid(alpha=.2)
    selected=(frequencies>100)&(frequencies<7500)
    b.plot(frequencies[selected],10*np.log10(np.maximum(power[selected],1e-14)),lw=0.9)
    b.set(xlabel='Electrical beat frequency (Hz)',ylabel='Power spectral density (dB, relative)',title='Measured-in-simulation Doppler beat' if detected else 'Control: no detected Doppler beat')
    b.grid(alpha=.2)
    fig.suptitle(title)
    fig.tight_layout()
    fig.savefig(out,dpi=170)
    plt.close(fig)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--simulate',action='store_true',help='Generate SYNTHETIC beat wave')
    parser.add_argument('--blocked-reference',action='store_true',help='Simulate optical arm blocked')
    parser.add_argument('--velocity-mm-s',type=float,default=1.0)
    parser.add_argument('--wav',type=str,help='Read REAL (or synthetic) mono/stereo WAV')
    parser.add_argument('--output-dir',default='results')
    parser.add_argument('--wavelength-nm',type=float,default=650)
    args=parser.parse_args()
    if not args.simulate and not args.wav:
        parser.error('Use --simulate or --wav FILE')
    out=Path(args.output_dir);out.mkdir(parents=True,exist_ok=True)
    if args.wav:
        fs,x=load_wav(args.wav);origin=f'WAV file: {args.wav}, provenance not independently verified'
    else:
        fs,x=synthesize(velocity_mm_s=args.velocity_mm_s,
                        both_arms=not args.blocked_reference,
                        wavelength_nm=args.wavelength_nm)
        save_wav(out/'SYNTHETIC_capture.wav',fs,x)
        origin='SYNTHETIC simulation; not a physical measurement'
    result,f,p=analyze(fs,x,args.wavelength_nm)
    result['provenance']=origin
    with open(out/'analysis.json','w') as h:json.dump(result,h,indent=2)
    plot_analysis(out/'spectrogram.png',fs,x,f,p,result['beat_detected'],origin)
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
