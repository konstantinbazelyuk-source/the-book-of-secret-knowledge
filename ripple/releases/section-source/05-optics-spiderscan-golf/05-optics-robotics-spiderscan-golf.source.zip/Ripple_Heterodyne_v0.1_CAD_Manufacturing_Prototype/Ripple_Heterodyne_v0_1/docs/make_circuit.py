from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle
P=Path(__file__).parent
fig, ax=plt.subplots(figsize=(12,6))
ax.set(xlim=(0,12),ylim=(-.5,5.5))
ax.axis('off')
# supplied module simplified wiring diagram
ax.add_patch(Rectangle((.6,1.45),2.6,2.45,fc='#f1f5f9',edgecolor='#334155',lw=2))
ax.text(1.9,3.35,'OPT101\nDIP-8',ha='center',va='center',fontsize=14,weight='bold')
ax.text(1.9,2.25,'Internal 1 MΩ feedback\n14 kHz nominal bandwidth',ha='center',fontsize=8)
# supply & ground
ax.plot([1.25,1.25],[3.9,4.8],color='#d97706',lw=2)
ax.text(1.25,5.05,'Pin 1 VS: regulated +5 V',ha='center',fontsize=9)
ax.plot([2.55,2.55],[1.45,.8],color='#334155',lw=2)
ax.text(2.55,.4,'Pins 3, 8: GND',ha='center',fontsize=9)
ax.plot([3.2,4.0],[3.1,3.1],color='#0f766e',lw=2)
ax.text(3.27,3.3,'Pin 5 OUT',ha='left',fontsize=9)
ax.text(3.3,2.7,'Pin 4 short to Pin 5\nPins 2, 6, 7 open',ha='left',fontsize=8)
# bypass cap visual
ax.plot([.45,.45],[4.0,4.8],color='#d97706',lw=1.7)
ax.plot([.45,1.25],[4.8,4.8],color='#d97706',lw=1.7)
ax.plot([.28,.62],[4.0,4.0],color='#d97706',lw=1.6)
ax.plot([.28,.62],[3.9,3.9],color='#d97706',lw=1.6)
ax.plot([.45,.45],[3.9,.8],color='#334155',lw=1.7)
ax.plot([.45,10.2],[.8,.8],color='#334155',lw=1.5)
ax.plot([8,8],[1.15,.8],color='#334155',lw=1.7)
ax.text(.55,4.3,'100nF bypass',ha='left',fontsize=8)
# cap line
ax.plot([4.0,4.7],[3.1,3.1],color='#0f766e',lw=2)
ax.plot([4.7,4.7],[2.85,3.35],color='#0f766e',lw=2)
ax.plot([4.85,4.85],[2.85,3.35],color='#0f766e',lw=2)
ax.plot([4.85,5.45],[3.1,3.1],color='#0f766e',lw=2)
ax.text(4.78,3.6,'C1: 1µF\nnonpolar',ha='center',fontsize=8)
# 47k resistor
ax.add_patch(Rectangle((5.45,2.92),.8,.36,fc='white',edgecolor='#0f766e',lw=2))
ax.text(5.85,3.6,'R1: 47kΩ',ha='center',fontsize=8)
ax.plot([6.25,8.0],[3.1,3.1],color='#0f766e',lw=2)
ax.add_patch(Circle((8,3.1),.07,color='#0f766e'))
# down resistor 10k
ax.plot([8,8],[3.1,2.4],color='#0f766e',lw=2)
ax.add_patch(Rectangle((7.82,1.75),.36,.65,fc='white',edgecolor='#0f766e',lw=2))
ax.plot([8,8],[1.75,1.15],color='#0f766e',lw=2)
ax.text(8.25,2,'R2: 10kΩ',ha='left',fontsize=8)
ax.plot([8,10.2],[1.15,1.15],color='#334155',lw=1.8)
ax.plot([8,8],[1.15,.8],color='#334155',lw=1.8)
ax.text(9.3,1.35,'Line-in SLEEVE = GND',fontsize=8,ha='center')
ax.plot([8,10.0],[3.1,3.1],color='#0f766e',lw=2)
ax.add_patch(Rectangle((10,2.75),1.5,.85,fc='#dbeafe',edgecolor='#2563eb',lw=1.7))
ax.text(10.75,3.15,'USB audio\nLINE INPUT',ha='center',va='center',fontsize=9,weight='bold')
ax.text(9,3.4,'TIP',fontsize=9)
ax.text(6.7,4.75,'NO DIRECT 5V INTO AUDIO INPUT · NO PHANTOM POWER',ha='center',fontsize=12,weight='bold',color='#991b1b')
ax.text(6.7,.15,'Diagram depicts connections, not an electrically certified wiring product. Verify package pin 1 orientation.',ha='center',fontsize=8)
fig.tight_layout()
fig.savefig(P/'receiver_circuit.png',dpi=180)
plt.close(fig)
