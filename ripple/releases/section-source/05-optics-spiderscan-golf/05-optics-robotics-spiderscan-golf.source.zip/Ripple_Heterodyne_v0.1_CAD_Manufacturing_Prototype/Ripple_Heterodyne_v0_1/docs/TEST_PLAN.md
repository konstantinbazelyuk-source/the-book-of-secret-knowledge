# Verification and acceptance matrix

| Item | Verification method | Status (Oct 2026) |
|---|---|---|
| Michelson beam routing | Compare with university/optics reference | Engineering design based on established topology |
| Optical Doppler frequency | f=2v/λ; 1mm/s at 650nm => 3076.923Hz | Verified mathematical calculation |
| 3D parts | OpenSCAD STL export and watertight mesh test | Checked digitally; not printed |
| Footprint & mount placement | CAD coordinates; DXF independent drawing | Digitally checked |
| LM6UU bore | Nominal 12.15mm, 19mm long; test-assemble real bearings | **Not physically checked** |
| Mirror adjustment | Manual 3-point spring/bolts with M3 hardware | Designed, NOT realigned/bench-tested |
| Recombined coherent beams | Use laser, cube, mirror, optical stop and safe alignment card | **Not assembled** |
| OPT101 response | TI datasheet: 0.45 A/W at 650nm, 14kHz bandwidth, 1MΩ | Source-verified component specs; not wired |
| ND attenuation | OD3 theoretical attenuation 1000x if specified at 650nm | Calculated; actual filter not checked |
| Beat signal at 1 mm/s | Synthesize 48kHz WAV; Welch peak analysis | Verified simulated ~3076.17 Hz |
| Blocked-arm control | Simulated reference blocked; same noise, no interference | Verified synthetic control rejected |
| Physical beat measurement | Bench capture + reference blocked + laser off + independent speed | **Not performed** |
| Electrical compliance/safety | Confirm supply, driver, grounding and optical enclosure | **Not assessed by professional** |

## Open laboratory record to fill after fabrication

Date/location: ______

Laser manufacturer/model/output power/wavelength: ______

Beamsplitter manufacturer/model/coating orientation: ______

Mirrors and cube separation: ______

Filter measured/specified OD at wavelength: ______

Photodiode measured output with laser off / single arm / both arms: ______

Audio interface model/input gain/sample rate: ______

Independent stage speed: ______

Predicted f(Hz): ______

Observed spectral peak f(Hz): ______

Laser off peak: ______

Reference blocked peak: ______

Uncertainty / environmental notes: ______

Decision: PASS / FAIL / INCONCLUSIVE ______
