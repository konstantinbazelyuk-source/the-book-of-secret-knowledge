# Ripple Heterodyne v0.1 — fabrication and assembly

## Engineering status and dimensional limits

- **Digital-only verified**: OpenSCAD 3D solid generation, 3D mesh checks, DXF generation, analytical Doppler relation, software detection/rejection tests, synthetic WAV.
- **Not verified**: 3D-print physical fit, bearing performance, availability of appropriately certified laser, optical coherence, beam recombination, photodiode interface in a real device, USB soundcard performance, and actual optical beat measurement.
- This is an **engineering prototype design to fabricate**, not an assertion a physical device already works.
- All drawing dimensions are nominal in **mm**. Base footprint **210 × 210 × 6**. Optical beam center **Z=30 from underside**. Equipment must be kept enclosed when energized.

## 1. Print/manufacture

- `cad/ripple_heterodyne_bench.scad`: fully parameterized CAD (millimetres, OpenSCAD).
- `cad/stl/base_plate.stl`: print 1, optional. A **6 mm thick dimensionally stable flat base** cut using `cad/base_drill_plan.dxf` is the practical alternative. In the DXF, only the CUT/DRILL/SLOT layers are machinable; **REF_NONCUT**/**TEXT_NONCUT** must not be machined.
- Print one each: laser_cradle, cube_cradle, detector_rail, nd_filter_holder, fixed_mirror_back, mirror_carrier, slider_carriage, nut_cover, crank_knob; print `rail_support.stl` **twice**.
- First fit-test short parts (especially **LM6UU seats 12.15 mm nominal**, 6 mm rod support bores 6.3 mm nominal, laser cradle 12.4 mm nominal, filter pocket 13.1 mm), because FDM hole size varies by printer, slicer, filament, orientation.
- PETG or dimensionally stable PLA+ recommended; 0.2 mm layers, >=4 perimeters for load-bearing stage, 30–40% infill, supports for horizontal bearing/rail holes as needed. Prefer a flat CNC/plywood base to a warped large FDM plate. Do not infer machine accuracy from CAD alone.

## 2. Coordinates / construction

Beam center Z = 6 mm base + 24 mm local mount height = **30 mm**.

| Component | Anchor X,Y (mm) | Fixture/hardware |
|---|---|---|
| laser cradle | 33, 100 | 12.0 mm body; aim +X to cube |
| cube | 92, 100 | 10 mm NPBS 50:50 cube, for red laser |
| reference mirror | 92, 163 | 20×20 mm mirror facing -Y, backer + adjustable carrier; base has Y adjustment slots |
| moving mirror | 164, 100 | 20×20 mm mirror facing -X; carriage center changes X |
| detector | 92, 30 | OPT101 oriented along +Y toward cube |
| ND filter | 92, 53 | 12.7 mm round OD3 filter on returning beam to OPT101 |
| rail supports | 139, 100 and 193, 100 | Two hardened 6 mm rods at Y=82/118, Z=18 |
| hand crank | near 219, 100 | M6x1 threaded rod, one revolution → 1mm ideal stage translation |

A 10 mm NPBS cube **must be oriented according to its manufacturer's coating/arrow markings** so the incoming laser divides into +X (moving mirror) and +Y (fixed mirror), and the recombined signal exits toward -Y, into the detector. Verify by alignment card at low power before installing the detector. Some beam power returns toward laser; it is **not** a free output port. Don't place eyes in any path.

## 3. Mechanical stage

1. Mount both rail supports to base using M3 screws/nuts, center coordinates listed above.
2. Mount two **LM6UU (6 mm ID × 12 mm OD × 19 mm long)** linear bearings in slider's two 12.15 mm nominal bores. Confirm real bearing fit; avoid over-pressing plastic/outer bearing races; if necessary adjust bore CAD and reprint. Do not permit glue to wick into the bearing.
3. Pass two **6 mm hardened smooth rods approximately 66 mm long** along X, through supports and LM6UU. Secure rods to supports at top pilot holes with appropriately fitted M3 screws or printed clamps (pilot holes require tapping/heat-set adaptation). Ensure zero binding across ~±3 mm from nominal center.
4. Put an **M6x1 standard nut** in the center carriage top-access pocket. Fit its printed `nut_cover` using two small M3 self-tapping screws. Note the nut width is 10 mm across flats, typical ISO 4032 height ~5 mm. If nut won't seat, check orientation and pocket sizing before forcing.
5. Insert **M6x1 threaded rod ~100 mm long** from right across rail supports and captured nut. Retain shaft axially at **right support** using pairs of washers and jam nuts, but keep clearance so it can rotate without binding. The moving carriage is NOT allowed to rotate with the lead screw. Fasten crank using jam nuts or a mechanically locked hub.
6. Attach first-surface mirror to moving-carriage's **-X facing** 20.4 mm nominal recess, at Z=30. Use minimum compatible adhesive, avoiding reflective region. No tilt adjust provided on this first-stage moving mirror: use mounts to align mechanically, and reference mirror tilt for interference.
7. Spin crank gently through the usable **central ~6 mm travel** before optical energization. Do not force end stops. No motor is fitted in v0.1.

## 4. Reference mirror tilt adjustment

- Use three M3 × 25 mm bolts from the **rear** plate, each with a light compression spring between rear and front plate; secure in three captive nuts accessible on the carrier's front (outside 20×20 mirror square).
- 3 screws contact front carrier at points X/Z=(-15,11),(+15,11),(0,41) relative to bracket, providing approximate tip/tilt/alignment. Use small adjustments, no overtightening. This printed mechanism is **coarse**; interferometric interference requires much finer stability than FDM dimensions alone guarantee.
- The two slots under the reference mount allow about ±5 mm Y motion to reduce arm-length mismatch. Secure after checking overlap.
- The mirror surfaces must be **first surface** or optical-grade front-surface mirrors, not ordinary household mirrors (which produce multiple reflected images).

## 5. Optical sequence

1. Laser OFF. Mount Class 2 compliant 650 nm red laser module with verified <=1mW output in 12 mm body. Mount laser saddle and secure with appropriate non-marring zip ties. Use a driver designed for the module; do not drive a laser diode directly from a 5V supply without its rated current-regulation electronics.
2. Mount 10 mm red-band **nonpolarizing** 50:50 beam-splitter cube, plus two aligned 20×20 front-surface mirrors. Install beam stops and an opaque protective cover.
3. Keep laser energized only with protective access restrictions. Use cards to align beam paths **without eye-level exposure**. Confirm reflected spots reach the detector port and overlap. Fit *properly specified* OD3 filter before the OPT101; start attenuated.
4. Adjust reference mirror with small screw movements so detector sees slowly changing interference while the carriage is gently moved. Actual interference is delicate: vibrations, laser mode hopping, mismatched arm lengths, and angular wander can destroy it.
5. Once optical beat is present, rotate the screw smoothly at ~1 rev/sec: M6x1 → ~1mm/sec → **~3076.92 Hz** predicted for 650nm.
6. Photograph alignment/setup from a safe angle while instrument is off. Log optical power, wavelength, reference-arm offset, sample rate, environmental light and voltage.

## 6. Receiver & circuit (OPT101 DIP-8 example only)

Based on Texas Instruments OPT101 datasheet; physically verify pin-1 indicator / footprint:

| OPT101 pin | Connect |
|---|---|
| 1 VS | clean regulated +5V |
| 2 -In | NOT CONNECTED (internal feedback mode) |
| 3 -V | ground |
| 4 feedback | short directly to pin 5 output |
| 5 OUT | 1 µF **non-polarized** capacitor to 47 kΩ series resistor to USB soundcard line input TIP |
| 6/7 NC | NOT CONNECTED |
| 8 Common | ground |

Add 100 nF ceramic bypass capacitor from pins 1 to 3 close to OPT101. Tie line-input SLEEVE to circuit ground. Put 10 kΩ from TIP to SLEEVE at the jack. Do not connect the laser's optical power to the unattenuated OPT101: its nominal responsivity is **0.45 A/W at 650nm**, internal feedback **1 MΩ**; even **10 µW** continuous incident light would nominally imply a ~4.5V signal (near +5V supply saturation). Start with optical density OD3 (1/1000 transmission) at the detector, and measure DC OUT with a multimeter before connecting to line-in. Since beamsplitter/surface efficiencies vary, no physical detector amplitude is promised.

**USB audio interface**: must have standard **line input** (48kHz supported), not powered microphone input or 48V phantom. Interface LINE and OPT101 grounds are interconnected; choose isolated, properly powered electronics and verify no hazardous potentials. The capacitor blocks DC and 47k/10k network provides nominal attenuation; actual voltage depends on interface input impedance and gain. Adjust so audio peak remains below full scale; never connect the OPT101 5V output straight to unprotected audio or microcontroller input.

## 7. Software

From the project folder:

```bash
python -m pip install -r software/requirements.txt
python -m unittest discover -s tests -v
python software/heterodyne.py --simulate --output-dir results/my_sim
python -m pip install sounddevice  # only for live input
python software/record_linein.py --list-devices
python software/record_linein.py --device 2 --seconds 3 --output my_capture.wav
python software/heterodyne.py --wav my_capture.wav --output-dir results/my_capture
```

Use your actual device index instead of `2`. Synthetic WAV in `results/simulated_beat` is labeled SYNTHETIC. WAV files loaded by the analyzer are **not verified as optical measurements** until accompanied by apparatus evidence and controls.

## 8. Required physical controls

- Control A: **laser off** and record. No Doppler beat should appear.
- Control B: **fixed reference arm blocked** while laser + moving arm remain active; interference beat should disappear. Motion-related stray intensity may persist.
- Control C: move mirror at two speeds; frequency should scale with velocity. The prototype reports only **absolute** mirror speed (single-intensity channel cannot determine direction).
- Control D: change laser wavelength (with optics and software updated): predicted frequency scales **inversely** with wavelength at fixed speed.
- Control E: mechanical no-motion baseline, ordinary lighting background, beam cover closed. Reject ambient 60Hz interference and drift.
- Calibrate actual stage motion using dial indicator or controlled translation, not merely how fast the knob seems to turn.

**Acceptance threshold is physics and controls, not an attractive waveform**: the detected beat frequency must agree with independently measured mirror velocity within a tolerance established by actual velocity accuracy, and disappear in blocked-arm controls.

## Known limitations / non-goals

- Not direct measurement of optical magnetic-field oscillations or arbitrary free-space EM fields.
- Not a true optical-spectrum analyzer. A stable reference laser + moving mirror measures an imposed Doppler offset; direct optical carrier is hundreds of THz and inaccessible to a kHz OPT101.
- Not a biological aura detector, EEG, beta-radiation detector, gamma-ray detector or theta-oscillation scanner.
- Printed 3D parts are uncalibrated and may require modification. Pure simulation cannot guarantee optical coherence.
- Manual crank allows frequency variation. A future motor stage can improve repeatability but has **not** been designed or tested in this version.
- No claim of actual fabrication, hardware measurement, certified laser assembly, or compliance testing.
