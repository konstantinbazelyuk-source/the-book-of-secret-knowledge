# Primary specifications and learning references, checked 2026-10-13

1. Texas Instruments, OPT101 datasheet / product: https://www.ti.com/product/OPT101 and https://www.ti.com/lit/ds/symlink/opt101.pdf . Used for 2.7–36V supply, 0.45A/W at 650nm, 1MΩ transimpedance, 14kHz nominal bandwidth, 8-pin wiring.
2. University of Colorado, Michelson interferometer optics: https://physicslabs.colorado.edu/courses/phys-4430/lab-guides/michelson-interferometer/week-1/ . Used for beam splitter/two reflecting arms/detector model.
3. Friedrich Schiller University Jena, Michelson interferometer XRTL: https://www.asp.uni-jena.de/9042/michelson-interferometer-xrtl-online-version . Used for recombination at fourth port.
4. Edmund Optics, Michelson alignment: https://www.edmundoptics.com/knowledge-center/application-notes/optics/michelson-interferometer-lab-setup/ . Used for physical alignment notes, not for claim of successful assembly.
5. Thorlabs, non-polarizing 50:50 cubes 400–700nm: https://www.thorlabs.us/NewGroupPage9.cfm?ObjectGroup_ID=754 . Cube BS010 is 10mm side. The CAD is dimensioned around a generic **10mm** cube, not a promise of identical fixture compatibility or supplier pricing.
6. FDA, laser safety FAQ: https://www.fda.gov/radiation-emitting-products/laser-products-and-instruments/frequently-asked-questions-about-lasers . Class labeling, avoid direct viewing.
7. Example LM6UU dimensions (check actual manufacturer parts): https://www.hta3d.com/en/lm6uu-linear-bearing-for-6-mm-smooth-shaft . 6mm ID, 12mm OD, 19mm L.
8. M6 standard coarse threaded nut dimensions (verify actual hardware): https://www.aspenfasteners.com/m6-1-0-din-934-iso-4032-metric-hex-finished-nuts-class-8-steel-zinc-plated/ . Pitch 1mm, 10mm AF.
9. Thorlabs, filter attenuation context: https://www.thorlabs.us/newgrouppage9.cfm?objectgroup_id=689 . Buy by **actual OD at 650nm**, diameter, substrate, thickness. CAD slot is nominal, may require edit.

The equation f = 2v/λ follows from classical round-trip Doppler shift of a reflected beam in the nonrelativistic limit. A 650nm laser oscillates at approximately c/λ = 461THz; the 3kHz beat is an electronic difference-frequency readout, not 3kHz carrier light.
