"""Generates DXF CNC drilling plan and PNG dimensioned assembly layout.
Units mm; CAD layout coordinates match OpenSCAD.
Requires ezdxf + matplotlib.
"""
from pathlib import Path
import ezdxf
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle, FancyArrowPatch
OUT=Path(__file__).parent
DOC=OUT.parent/'docs'
DOC.mkdir(exist_ok=True)
W=H=210
mounts=([(33,90),(33,110)]
  +[(92+i,100+j) for i in (-9,9) for j in(-9,9)]
  +[(92+i,163) for i in(-14,14)]
  +[(92+i,30) for i in(-12,12)]
  +[(92+i,53) for i in(-9,9)]
  +[(x,100+j) for x in (139,193) for j in(-24,24)])
slots=[(78,163),(106,163)]
corner=[(7,7),(203,7),(7,203),(203,203)]
# Only CUT_OUTER, DRILL, SLOT are machining layers. Guides/notes are reference!
doc=ezdxf.new('R2010'); doc.units=4
for name,col in [('CUT_OUTER',7),('DRILL_3p4',2),('DRILL_4p5',3),('SLOT_3p4x13p4',1),('REF_NONCUT',5),('TEXT_NONCUT',6)]:
    doc.layers.new(name,dxfattribs={'color':col})
m=doc.modelspace()
m.add_lwpolyline([(0,0),(210,0),(210,210),(0,210),(0,0)],dxfattribs={'layer':'CUT_OUTER'})
for x,y in mounts:
    if (x,y) in slots:
        r=1.7
        # stadium, long direction Y, cut line around capsule perimeter
        # included in one closed polyline approximation, 24 points per cap
        import numpy as np
        points=[]
        # top cap center y+5, 0 -> pi
        for t in np.linspace(0,np.pi,25):points.append((x+r*np.cos(t),y+5+r*np.sin(t)))
        # bottom cap center y-5, pi -> 2pi
        for t in np.linspace(np.pi,2*np.pi,25):points.append((x+r*np.cos(t),y-5+r*np.sin(t)))
        m.add_lwpolyline(points,close=True,dxfattribs={'layer':'SLOT_3p4x13p4'})
    else:m.add_circle((x,y),1.7,dxfattribs={'layer':'DRILL_3p4'})
for x,y in corner:m.add_circle((x,y),2.25,dxfattribs={'layer':'DRILL_4p5'})
m.add_line((20,100),(200,100),dxfattribs={'layer':'REF_NONCUT'})
m.add_line((92,20),(92,196),dxfattribs={'layer':'REF_NONCUT'})
m.add_text('RIPPLE HETERODYNE 0.1 (mm) - GUIDE LAYERS NOT TO CUT',dxfattribs={'height':3,'layer':'TEXT_NONCUT','insert':(5,5)})
doc.saveas(OUT/'base_drill_plan.dxf')

fig,ax=plt.subplots(figsize=(11,11))
ax.add_patch(Rectangle((0,0),W,H,edgecolor='black',facecolor='#f8fafc',lw=2))
for name,x,y,w,h,color in [
    ('12 mm laser\nClass 2 ≤1 mW',33,100,32,28,'#93c5fd'),
    ('10 mm NPBS',92,100,24,24,'#fcd34d'),
    ('Reference mirror\n3-screw adjustment',92,163,42,30,'#bbf7d0'),
    ('OPT101 sensor',92,30,34,20,'#93c5fd'),
    ('OD3 filter',92,53,30,16,'#f5d0fe'),
    ('LM6UU carriage\nM6x1 drive',164,100,28,58,'#86efac'),
    ('Rail support',139,100,12,56,'#cbd5e1'),
    ('Rail support',193,100,12,56,'#cbd5e1'),
]:
    ax.add_patch(Rectangle((x-w/2,y-h/2),w,h,facecolor=color,edgecolor='#475569',lw=1.5,alpha=.9))
    ax.annotate(name,(x,y),xytext=(x,y+(11 if name=='OPT101 sensor' else 0)),ha='center',va='center',fontsize=7.6,weight='bold')
for yy in (82,118):ax.plot([133,199],[yy,yy],color='#64748b',lw=3)
ax.plot([128,219],[100,100],color='#94a3b8',lw=3,ls='--')
ax.add_patch(Circle((219,100),6,color='#fbbf24'))
for (x,y) in mounts:
    ax.add_patch(Circle((x,y),1.7,fill=False,edgecolor='#334155',lw=0.8))
for(x,y) in corner:ax.add_patch(Circle((x,y),2.25,fill=False,edgecolor='black',lw=0.8))
# incoming outgoing beams with separate segments to show splitter geometry
for p1,p2 in [((49,100),(92,100)),((92,100),(149,100)),((149,100),(92,100)),((92,100),(92,158)),((92,158),(92,100)),((92,100),(92,42))]:
    ax.add_patch(FancyArrowPatch(p1,p2,arrowstyle='-|>',mutation_scale=11,lw=1.7,color='#e11d48',alpha=.85))
ax.annotate('50:50 split\n& recombine',(100,112),fontsize=8,ha='left',color='#881337')
ax.annotate('Crank',(205,111),fontsize=8,ha='center')
ax.annotate('Optical center Z = 30 mm above base underside',(105,186),fontsize=10,ha='center')
ax.annotate('Base 210 × 210 × 6 mm',(105,196),fontsize=11,ha='center',weight='bold')
ax.annotate('X',(201,10),fontsize=9);ax.annotate('Y',(9,202),fontsize=9)
ax.set(xlim=(-8,230),ylim=(-8,220),xlabel='X (mm)',ylabel='Y (mm)',title='RIPPLE • Optical Doppler Heterodyne Bench v0.1 — Top view')
ax.set_aspect('equal');ax.grid(alpha=.1)
fig.tight_layout()
fig.savefig(DOC/'layout_dimensioned.png',dpi=180)
plt.close(fig)
print('Created',OUT/'base_drill_plan.dxf', DOC/'layout_dimensioned.png')
