#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 scripts/verify_parent.py
node --test --test-concurrency=1 tests/*.test.mjs
python3 -m unittest discover -s tests -p 'test_metrology.py'
echo 'Golf v0.3 source verification and new tests passed.'
