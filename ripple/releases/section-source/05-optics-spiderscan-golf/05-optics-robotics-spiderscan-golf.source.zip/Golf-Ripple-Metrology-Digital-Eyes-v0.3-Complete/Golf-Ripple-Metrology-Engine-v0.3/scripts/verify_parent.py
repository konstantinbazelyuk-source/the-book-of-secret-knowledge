"""Validate the 182 byte-preserved v0.2 parent files against source ZIP hashes.
Run from any working directory. Does not need the source ZIP.
"""
import json,hashlib
from pathlib import Path
root=Path(__file__).resolve().parents[1]
manifest=json.loads((root/'PARENT_FILES_SHA256.json').read_text())
missing=[];bad=[]
for name,digest in manifest['files'].items():
    path=root/'parents'/name
    if not path.is_file():missing.append(name)
    elif hashlib.sha256(path.read_bytes()).hexdigest()!=digest:bad.append(name)
print(json.dumps({'checked':len(manifest['files']),'missing':missing,'modified':bad,'valid':not (missing or bad)}))
if missing or bad:raise SystemExit(1)
