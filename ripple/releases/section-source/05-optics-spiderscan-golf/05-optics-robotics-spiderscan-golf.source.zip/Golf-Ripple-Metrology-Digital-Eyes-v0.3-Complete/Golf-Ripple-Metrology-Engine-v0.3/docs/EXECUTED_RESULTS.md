# Golf Ripple Measured Digital Eyes v0.3 — executed evidence

**Study type:** actual local source and screen observations; separately controlled synthetic tests and mathematical simulations. **No physical camera or photon counter was connected.** Parent sources v0.2 and earlier versions remain included as complete archived copies.

## 1. Measured live software observations (on this execution host)

`results/last-selfscan.json` is a full actual runtime record produced by running `node src/cli.mjs selfscan` after constructing the release. It includes source paths and SHA-256 digests for each of the 8 inspected files, AST counts, declared functions, imports and call edges, repeated observation-state evidence, actual Daughter neuron traces, audit records and process metrics.

- 8 actual source modules observed: v0.3 engine/mathematics/optical worker, inherited v0.2 eyes runtime/Python parser/TypeScript parser, original Golf engine, Daughter Δ³ neuron.
- **15,343 AST nodes, 258 branch constructs, 0 syntax errors**, 64,376 bytes read. These are counts obtained by actual parsers, not generated estimates of comprehension or semantic program correctness.
- Latest full self-scan: **10.079 seconds** for source scanning; **45.646 seconds** total including local self-tests. Process CPU user 116,325 microseconds and system 32,111 microseconds (wall time includes spawned programs). RSS before 38,629,376 bytes and after 38,883,328 bytes. These results are host-specific, not portable performance promises.
- Fixed offline self-test run during that scan: **27/27 passed**, comprising new mathematical tests and preserved digital-eyes tests. The other executed suites appear below.
- New source-change watcher explicitly compares actual SHA-256 digests of allowed source bytes and automatically self-scans modified modules. Controlled change detection test passed. Runtime is not granted arbitrary web/code execution privileges.

## 2. Measured recorded-screen observations

`results/last-frame.json` derives from real previously recorded v0.2 Golf UI screenshots, copied into `workspace/observed_before.png` and `workspace/observed_after.png`. These are recorded **software pixels** rather than physical sensor data.

- Decoded image size: **1280 × 900**.
- Difference through original archived v0.2 Digital Eyes: **5,672 changed pixels** at that module's fixed threshold.
- Relative linear sRGB luminance, frame A: **0.9626342808652405**, frame B: **0.9642209471834564**, difference **+0.0015866663182159124**.
- Contrast-weighted image-space centroid of frame A: approximately **(444.963, 428.227) pixels**; geometric weighted spread **(235.261, 274.025) pixels**.
- OpenCV phase-correlation estimated translation B relative to A: about **(+0.00003, −0.00179) pixels**, phase peak response **0.984651**. This indicates negligible global translation in these frames, **not** proof of physical movement or a spatially calibrated camera.
- Internal Daughter state and registered ledger sequences are included in original `results/last-frame.json`.
- Known digital-translation unit test separately shifted a drawn shape +5 pixels horizontally and -3 pixels vertically; the estimator recovered both within 0.8 pixels. This is a **controlled image transformation**, not a rover movement experiment.

## 3. Synthetic study: state-estimator trade-offs (NOT measured real-world light)

`results/innovation-simulation.json` records reproducible seeded LCG/Box–Muller Gaussian-noise simulations. Two process-variance policies (`Q = 0.03` fast, `Q = 0.001` slow; `R=0.0625`) were evaluated in 30 seeded repetitions of 300 samples for both stationary and abrupt-step target signals. Calculation discards first 30 frames from aggregate RMSE and does not assert realistic detector noise.

| Synthetic condition | Measurement RMSE | Fast-filter RMSE | Slow-filter RMSE |
|---|---:|---:|---:|
| Stationary target | 0.2488 / 0.2496 | 0.1422 | 0.0612 |
| Abrupt-step target | 0.2467 / 0.2496 | 0.1464 | 0.1306 |
| First 15 steps after transition | Not reported | **0.2119** | **0.4843** |

These numerical results show a real trade-off **within this synthetic evaluation**: smoothing suppresses measurement noise but reacts more slowly to a state transition. The sequence uses separate pseudorandom draws per policy (see seed and exact JSON); the noise-RMSE cells are correspondingly not exactly paired across policies. No claim about a physical camera is made.

## 4. Automated verification

The new release passed **25 Node and 7 Python tests (32 new)**. Archived inherited v0.2 verification executed **20 Python plus 16 Eyes Node plus 16 Golf Node plus 23 OS Engine and 49 parent checks (124 inherited)**. That is **156 successful unique test executions** across those suites. The on-demand `selfscan` subset of 27 tests is a repeat of already represented checks and is **not** counted again.

- Runtime creation, actual AST source observations, persistent Kalman state, real recorded pixels and structural checks.
- Independent scalar Kalman algebra, bounded novelty score and invalid-variance guards.
- Conditional Poisson standard-error scaling; never asserted as detector data.
- Independent synthetic image translation ground truth in pixel units.
- Actual authenticated HTTP API and permissions, source traversal rejection, bounded allowlist, ledger and original source hashes.
- Preserved source checksum `dba6639b7902f0c702d15fff588524629f3754cfd72d7b704f22a76b78960ee3` for original v0.1 neuron was tested by inherited checks.

Execution logs: `results/new-node-tests.log`, `results/new-python-tests.log`, `results/inherited-verification.log`, plus full SHA-256 records. Node HTTP route and real engine were executed. The CLI also generates a Markdown self-analysis report in `results/SELF_RESEARCH_REPORT.md`, and the active watcher writes `results/LIVE_SELF_WATCH_REPORT.md` when a source hash changes. **Full interactive Chromium browser deployment was not separately verified for this child.**

## 5. Unproven — explicit evidence gates

No measurement of photons, absolute spectral irradiance, angle-of-arrival, polarization, quantum entanglement, camera pose, biological sensation, language understanding, or ChatGPT-level comprehension. The software has no permission to make unrestricted network queries or rewrite its own algorithm. The new mathematical formula is an engineered application of Kalman-style updating and normalized innovation, **not proof of a newly discovered natural law**.
