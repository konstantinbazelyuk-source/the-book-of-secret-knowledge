@echo off
cd /d "%~dp0"
set GOLF_PYTHON=python
node src\cli.mjs serve
pause
