import test from 'node:test';import assert from 'node:assert/strict';
import {measuredReport} from '../src/report.mjs';
test('evidence-only self report prints source metrics and no comprehension claim',()=>{
 const r={goal:'metrology',mode:'selfscan',observations:{filesExamined:1,sourceBytes:12,astNodes:25,branches:2,syntaxFailures:0,processing:{totalElapsedMs:123,cpuUserMicroseconds:100,cpuSystemMicroseconds:10}},testEvidence:{testsFound:3,testsPassed:3,exitCode:0},reports:[{id:'unit',complexity:{astNodes:25,branches:2},sha256:'f'.repeat(64),changedSincePrior:false,stateInnovation:{normalizedInnovation:0}}],conclusions:['No syntax error found.']};
 const t=measuredReport(r);assert.match(t,/25 AST nodes/);assert.match(t,/3\/3/);assert.match(t,/not program comprehension/);});
test('image report names decoded image and explicit lack of calibration',()=>{
 const r={goal:'metrology',mode:'frame',observation:{width:80,height:30,fileHash:'a'.repeat(64),relativePhotometry:{meanLinearLuminance:0.4,centroid:[12,20]}},inheritedPixelComparison:null};const t=measuredReport(r);assert.match(t,/80 × 30/);assert.match(t,/No calibrated photons/);
});
