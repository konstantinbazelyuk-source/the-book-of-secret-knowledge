import unittest,importlib.util,json,sys,tempfile
from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('golf_metrology',ROOT/'src/metrology.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class OpticalTests(unittest.TestCase):
    def setUp(self):
        self.ctx=tempfile.TemporaryDirectory();self.p=Path(self.ctx.name)
        im=Image.new('RGB',(128,96),'white');dr=ImageDraw.Draw(im);dr.rectangle((20,20,42,44),fill='black');im.save(self.p/'a.png')
    def tearDown(self):self.ctx.cleanup()
    def test_identical_own_image(self):
        r=m.execute({'file':'a.png','second':'a.png'},self.p)
        self.assertEqual(r['width'],128);self.assertEqual(r['height'],96)
        self.assertAlmostEqual(r['pair']['meanLuminanceDelta'],0,places=12)
        self.assertGreater(r['pair']['phaseCorrelationResponse'],.8)
    def test_detect_actual_pixel_centroid(self):
        r=m.execute({'file':'a.png'},self.p)
        self.assertAlmostEqual(r['relativePhotometry']['centroid'][0],31,places=1)
        self.assertAlmostEqual(r['relativePhotometry']['centroid'][1],32,places=1)
        self.assertFalse(r['relativePhotometry']['calibratedPhysical'])
    def test_srgb_linear_breakpoint(self):
        x=np.array([[[0,128,255]]],dtype=np.uint8)
        vals=m.linear_srgb(x)[0,0].tolist()
        self.assertAlmostEqual(vals[0],1)
        self.assertAlmostEqual(vals[1],0.2158605,places=6)
        self.assertEqual(vals[2],0)
    def test_poisson_conditional_scaling(self):
        a=m.execute({'file':'a.png','assumedPhotoelectrons':100},self.p)['conditionalPhotonModel']
        b=m.execute({'file':'a.png','assumedPhotoelectrons':400},self.p)['conditionalPhotonModel']
        self.assertAlmostEqual(a['relativeShotNoiseStd']/b['relativeShotNoiseStd'],2)
        self.assertAlmostEqual(a['centroidStdPixelsIfIID'][0]/b['centroidStdPixelsIfIID'][0],2)
    def test_reject_path_traversal(self):
        with self.assertRaises(ValueError):m.execute({'file':'../outside.png'},self.p)
    def test_reject_negative_photon_counts(self):
        with self.assertRaises(ValueError):m.execute({'file':'a.png','assumedPhotoelectrons':-4},self.p)
    def test_response_to_translation(self):
        # Controlled digital translation test, NOT physical movement.
        src=np.asarray(Image.open(self.p/'a.png'))
        transform=np.array([[1,0,5],[0,1,-3]],dtype=np.float32)
        import cv2
        dst=cv2.warpAffine(src,transform,(128,96),borderMode=cv2.BORDER_CONSTANT,borderValue=(255,255,255))
        Image.fromarray(dst).save(self.p/'b.png')
        r=m.execute({'file':'a.png','second':'b.png'},self.p)
        self.assertAlmostEqual(r['pair']['estimatedTranslationPixels'][0],5,delta=0.8)
        self.assertAlmostEqual(r['pair']['estimatedTranslationPixels'][1],-3,delta=0.8)
if __name__=='__main__':unittest.main()
