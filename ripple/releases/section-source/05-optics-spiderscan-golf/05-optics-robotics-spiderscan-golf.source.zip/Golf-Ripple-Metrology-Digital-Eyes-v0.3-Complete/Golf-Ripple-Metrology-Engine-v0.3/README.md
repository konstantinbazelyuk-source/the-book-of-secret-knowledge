# Golf Ripple — Measured Digital Eyes v0.3 (executable)

A new child of **Golf Digital Eyes v0.2**, which is fully included and byte-preserved under `parents/Golf-Ripple-Digital-Eyes-v0.2/`. The parent keeps the original Golf, OS Engine, assessment router, Daughter triplet neuron, optical compiler and libraries. This child performs actual self-source measurement, repeated state estimation and real decoded image metrology. It is not a consciousness or general-language model, physically calibrated optical sensor, NASA navigation system, or quantum computer.

## Install / run (Node.js 20+, Python 3.10+)

Install `numpy` and `opencv-python-headless` if absent: `python -m pip install -r requirements.txt`. `npm install` is **not** required. The original v0.2 TypeScript AST parser is bundled under the preserved upstream license.

- Windows: `START-GOLF-METROLOGY-WINDOWS.bat`
- Linux/macOS: `sh START-GOLF-METROLOGY-UNIX.sh`
- `npm run selfscan` **actually parses** eight live, allowlisted Golf modules, checks source hash / snapshots, records counts, applies Kalman innovation updates through actual inherited Daughter Δ³ and executes fixed regression tests. Outputs full JSON to `results/last-selfscan.json`, prints it, and writes an evidence-only text report to `results/SELF_RESEARCH_REPORT.md`.
- `npm run frame` measures the two included **real saved interface screenshots**, compares their recorded digital pixel differences and estimates image-space features. Outputs `results/last-frame.json`.
- `npm run watch-self` starts a bounded 2-second SHA check of the allowlisted current source modules, re-inspecting changed files and emitting immediate JSON change reports, until Ctrl-C or 64 updates. No parent file is modified. Writes `results/LIVE_SELF_WATCH_REPORT.md` when an observed internal file changes.
- `npm run serve` provides a **real Node API** and two working observation controls at `http://127.0.0.1:8894/`; use the terminal's token. Localhost only.
- `node src/cli.mjs goal '{"kind":"metrology","mode":"frame","file":"observed_before.png","second":"observed_after.png","assumedPhotoelectrons":10000}'` provides **conditional** photon-noise mathematics separately from actual pixel observations.
- `npm test` executes the new Node suite; `python -m unittest discover -s tests -p 'test_metrology.py'` executes the new independent Python metrology suite; `(cd parents/Golf-Ripple-Digital-Eyes-v0.2 && sh VERIFY-ALL-UNIX.sh)` repeats archived integration checks.

## Actual features (not placeholders)

1. **Internal code sight:** AST extraction of the actual v0.3 model, observer, original Golf engine, and mathematical Daughter neuron, with SHA-256 verification and function/call/import structure metrics. Fixed source path list, no arbitrary code execution.
2. **Internal state:** persistent independent measurement histories, explicit process and measurement variance assumptions, normalized prediction error, bounded attention score and subsequent simulated Daughter neuron firing and soma states.
3. **Digital light measurement:** image decoding, IEC-standard sRGB linearization, relative luminance/contrast centroid/covariance and before/after image-space translation via OpenCV phase correlation; unchanged legacy image-difference and ORB algorithms are also run.
4. **Own-program research:** on-request selfscan with genuine parser operation and local tests, processing time and CPU/RSS measurements. Active self-watch triggers when one of eight known files changes, without assuming the change is an improvement.
5. **Numerically constrained quantum-related theory:** conditional Poisson/IID shot-noise estimates only if `assumedPhotoelectrons` is declared; **not a claim of measured photons**.
6. **Evidence ledger:** every new observation and all inherited operations use the locked Golf append-only hashed ledger.

## Evidence definitions

- **MEASURED:** values observed directly from actual source bytes, recorded pixels and running software process.
- **CALCULATED:** optical transfer, Kalman updates, source hashes and CPU delta from these observations.
- **SIMULATED:** tests with generated translations and Gaussian sensor noise; Daughter Δ³ mathematical spikes.
- **PROPOSED/UNVALIDATED:** real camera calibration, physical photon counts, neural comprehension, semantic code understanding, hardware quantum augmentation and NASA spacecraft navigation.

The new attention formula and complete distinction between normalized measurements and physical quantities are documented in `docs/MATHEMATICS_AND_METHODS.md`. Research evidence and the exact dataset files are in `docs/EXECUTED_RESULTS.md`. The entire v0.2 tree is preserved and self-source files are never edited during inspection.
