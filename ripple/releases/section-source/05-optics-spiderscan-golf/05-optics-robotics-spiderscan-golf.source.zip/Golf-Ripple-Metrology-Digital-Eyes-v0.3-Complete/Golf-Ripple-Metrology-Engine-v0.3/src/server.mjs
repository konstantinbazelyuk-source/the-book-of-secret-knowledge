// Reuse the previously tested bearer-token server, replacing only the static HTML with
// the v0.3 true measurement controls in the child release. Does not expose filesystem URLs.
import fs from 'node:fs';import http from 'node:http';import path from 'node:path';import {fileURLToPath} from 'node:url';import {randomBytes} from 'node:crypto';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
export async function serve(runtime,{port=8894,token=randomBytes(24).toString('base64url')}={}){
 const html=fs.readFileSync(path.join(ROOT,'web/index.html'));
 const server=http.createServer(async(req,res)=>{
  const json=(code,data)=>{res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(data))};
  if(req.method==='GET'&&req.url==='/'){res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Content-Security-Policy':"default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; base-uri 'none'",'X-Content-Type-Options':'nosniff'});return res.end(html);}
  if(req.method!=='POST'||req.url!=='/api/goal')return json(404,{error:'not found'});
  if(req.headers.authorization!==`Bearer ${token}`)return json(401,{error:'bearer token required'});
  if(!(req.headers['content-type']||'').startsWith('application/json'))return json(415,{error:'JSON content required'});
  try{let raw='',bytes=0;for await(const chunk of req){bytes+=chunk.length;if(bytes>20000){req.destroy();return;}raw+=chunk;}const item=JSON.parse(raw);
    if(!item||typeof item!=='object'||Array.isArray(item)||Object.keys(item).some(k=>k!=='goal'))throw Error('goal only');
    return json(200,await runtime.run(item.goal,'owner'));
  }catch(e){return json(400,{error:String(e.message||e).slice(0,200)});}
 });
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve)});
 return{server,token,address:server.address(),close:()=>new Promise(resolve=>server.close(resolve))};
}
