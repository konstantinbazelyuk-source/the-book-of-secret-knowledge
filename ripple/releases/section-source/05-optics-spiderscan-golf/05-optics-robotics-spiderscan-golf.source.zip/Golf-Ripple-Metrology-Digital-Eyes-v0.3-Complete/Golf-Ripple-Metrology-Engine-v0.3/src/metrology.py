#!/usr/bin/env python3
"""Bounded real-image measurement. No photon/radiance claims from PNG/JPEG values."""
import json,sys,math,hashlib
from pathlib import Path
import numpy as np
import cv2
cv2.setNumThreads(1)

MAX_BYTES=8_000_000
ALLOWED={'.png','.jpg','.jpeg','.bmp','.webp'}

def resolve(workspace, relative):
    if not isinstance(relative,str) or not relative or len(relative)>250 or '\x00' in relative:
        raise ValueError('invalid relative image')
    root=Path(workspace).resolve(strict=True)
    if Path(relative).is_absolute() or '..' in Path(relative).parts: raise ValueError('image must reside in authorized workspace')
    p=(root/relative).resolve(strict=True)
    if not p.is_relative_to(root) or p==root or not p.is_file() or p.suffix.lower() not in ALLOWED:
        raise ValueError('image must reside in authorized workspace')
    if p.stat().st_size>MAX_BYTES: raise ValueError('image too large')
    return p

def linear_srgb(img):
    # IEC 61966-2-1 transfer function, values RGB ordered after BGR OpenCV decoding.
    rgb=img[:,:,::-1].astype(np.float64)/255.
    return np.where(rgb<=0.04045,rgb/12.92,((rgb+0.055)/1.055)**2.4)

def photometry(p):
    data=p.read_bytes()
    img=cv2.imdecode(np.frombuffer(data,np.uint8),cv2.IMREAD_COLOR)
    if img is None:raise ValueError('image decode failed')
    h,w=img.shape[:2]
    if w*h>12_000_000:raise ValueError('pixel budget exceeded')
    L=linear_srgb(img)
    luma=0.2126*L[:,:,0]+0.7152*L[:,:,1]+0.0722*L[:,:,2]
    bg=float(np.quantile(luma,0.5));weight=np.abs(luma-bg);tot=float(weight.sum())
    centroid=None;spread=None;cov=None
    if tot>1e-8:
        yy,xx=np.indices(luma.shape,dtype=float)
        cx=float(np.sum(weight*xx)/tot);cy=float(np.sum(weight*yy)/tot)
        dx=xx-cx;dy=yy-cy
        xxv=float(np.sum(weight*dx*dx)/tot);yyv=float(np.sum(weight*dy*dy)/tot);xy=float(np.sum(weight*dx*dy)/tot)
        centroid=[cx,cy];spread=[math.sqrt(xxv),math.sqrt(yyv)];cov=[[xxv,xy],[xy,yyv]]
    return {'width':w,'height':h,'fileHash':hashlib.sha256(data).hexdigest(),'relativePhotometry':{
        'meanLinearLuminance':float(luma.mean()),'meanLinearRGB':[float(x) for x in L.mean((0,1))],
        'backgroundMedian':bg,'centroidMethod':'absolute contrast relative to image luminance median','centroid':centroid,'spread':spread,'spatialCovariancePixels2':cov,
        'measurement':'decoded image samples (IEC linearized sRGB), not sensor photons or absolute light',
        'calibratedPhysical':False}}

def execute(req,workspace):
    if not isinstance(req,dict) or set(req)-{'file','second','assumedPhotoelectrons'} or 'file' not in req:raise ValueError('schema')
    a=photometry(resolve(workspace,req['file']))
    if req.get('second'):
        b=photometry(resolve(workspace,req['second']))
        if (a['width'],a['height'])!=(b['width'],b['height']):raise ValueError('image dimensions differ')
        # Phase correlation is meaningful only for approximately translated, feature-rich views.
        pa=resolve(workspace,req['file']);pb=resolve(workspace,req['second'])
        def g(p):
            d=cv2.imread(str(p),cv2.IMREAD_GRAYSCALE)
            return d.astype(np.float32)
        ar=g(pa);br=g(pb);wnd=cv2.createHanningWindow((a['width'],a['height']),cv2.CV_32F)
        shift,response=cv2.phaseCorrelate(ar,br,wnd)
        # Always return estimator and confidence, not ground-truth shift/pose.
        a['pair']={'secondHash':b['fileHash'],'secondMeanLinearLuminance':b['relativePhotometry']['meanLinearLuminance'],
                   'meanLuminanceDelta':b['relativePhotometry']['meanLinearLuminance']-a['relativePhotometry']['meanLinearLuminance'],
                   'estimatedTranslationPixels':[float(shift[0]),float(shift[1])],
                   'phaseCorrelationResponse':float(response),'registrationQuality':('supported_by_peak' if response >= 0.2 else 'LOW_PEAK_REVIEW'),
                   'spatialClaim':'2D image-space estimate only; NOT rover 6-DOF odometry or camera pose'}
    N=req.get('assumedPhotoelectrons')
    if N is not None:
        if isinstance(N,bool) or not isinstance(N,(int,float)) or not math.isfinite(N) or not 1<=N<=1e12:raise ValueError('assumedPhotoelectrons out of range')
        cov=a['relativePhotometry']['spatialCovariancePixels2']
        a['conditionalPhotonModel']={'assumedPhotoelectrons':N,'relativeShotNoiseStd':1/math.sqrt(N),
            'centroidStdPixelsIfIID':[math.sqrt(cov[0][0]/N),math.sqrt(cov[1][1]/N)] if cov else None,
            'evidence':'conditional classical Poisson/IID thought model, not measured quantum sensor data or camera calibration'}
    return a

if __name__=='__main__':
    try:
        if len(sys.argv)!=2:raise ValueError('workspace argument required')
        raw=sys.stdin.buffer.read(4096)
        if len(raw)>=4096:raise ValueError('request too long')
        print(json.dumps({'ok':True,'result':execute(json.loads(raw),sys.argv[1])},allow_nan=False))
    except Exception as e:
        print(json.dumps({'ok':False,'error':type(e).__name__+': '+str(e)[:230]}));sys.exit(2)
