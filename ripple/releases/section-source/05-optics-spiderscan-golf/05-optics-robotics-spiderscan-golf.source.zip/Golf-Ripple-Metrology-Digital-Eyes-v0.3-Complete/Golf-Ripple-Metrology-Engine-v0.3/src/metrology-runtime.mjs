/** Golf v0.3: operational, bounded self-observation and relative image metrology.
 * Inherits the actual v0.2 Golf Eyes model, locked parent code unchanged.
 */
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawn} from 'node:child_process';
import {createHash} from 'node:crypto';
import {GolfEyesRuntime} from '../parents/Golf-Ripple-Digital-Eyes-v0.2/src/eyes-runtime.mjs';
import {innovationStep,codeVector,imageVector,bounded} from './innovation.mjs';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const SHA=data=>createHash('sha256').update(data).digest('hex');
const ROOT_PARENT=path.join(ROOT,'parents/Golf-Ripple-Digital-Eyes-v0.2');
export const SELF_TARGETS=Object.freeze({
  'metrology-runtime':path.join(ROOT,'src/metrology-runtime.mjs'),
  'innovation-math':path.join(ROOT,'src/innovation.mjs'),
  'metrology-worker':path.join(ROOT,'src/metrology.py'),
  'eyes-parent-runtime':path.join(ROOT_PARENT,'src/eyes-runtime.mjs'),
  'eyes-parent-observer':path.join(ROOT_PARENT,'src/eyes.py'),
  'eyes-ast-parser':path.join(ROOT_PARENT,'src/js_parse.cjs'),
  'golf-parent-engine':path.join(ROOT_PARENT,'parents/Ripple-Golf-Alpha-v0.1/src/golf/engine.mjs'),
  'daughter-triplet':path.join(ROOT_PARENT,'parents/Ripple-Golf-Alpha-v0.1/parents/Ripple-OS-Engine-Beta-v0.1/parents/Ripple-Daughter-Triplet-v3.1/src/triplet-neuron.mjs')
});
function runtimeSafeObject(o,keys){if(!o||Array.isArray(o)||typeof o!=='object'||Object.keys(o).some(k=>!keys.includes(k)))throw Error('METROLOGY_SCHEMA');}
function atomic(name,obj){const tmp=name+'.tmp';fs.writeFileSync(tmp,JSON.stringify(obj,null,2));fs.renameSync(tmp,name);}
function safeSnapshot(workspace,filename,bytes){const loc=path.join(workspace,filename);if(fs.existsSync(loc)&&fs.lstatSync(loc).isSymbolicLink())throw Error('METROLOGY_SYMLINK');fs.writeFileSync(loc,bytes);if(SHA(fs.readFileSync(loc))!==SHA(bytes))throw Error('METROLOGY_SNAPSHOT_HASH');return filename;}
async function fixedWorker(cmd,args,payload,{timeout=45000,maxBytes=300000}={}){
 return await new Promise((resolve,reject)=>{
  const proc=spawn(cmd,args,{cwd:ROOT,windowsHide:true,stdio:['pipe','pipe','pipe']});let buffer='',stderr='',n=0,done=false;
  const timer=setTimeout(()=>{proc.kill('SIGKILL');if(!done){done=true;reject(Error('METROLOGY_TIMEOUT'));}},timeout);
  proc.stdout.on('data',d=>{n+=d.length;if(n>maxBytes)proc.kill('SIGKILL');else buffer+=d.toString();});
  proc.stderr.on('data',d=>{stderr+=d.toString().slice(0,300)});
  proc.on('error',e=>{clearTimeout(timer);if(!done){done=true;reject(e);}});
  proc.on('close',code=>{clearTimeout(timer);if(done)return;done=true;if(n>maxBytes){reject(Error('METROLOGY_OUTPUT_LIMIT'));return;}if(code!==0){try{reject(Error(JSON.parse(buffer).error||stderr));}catch(e){reject(e);}return;}try{resolve(JSON.parse(buffer));}catch(e){reject(e);}});
  proc.stdin.on('error',()=>{});proc.stdin.end(JSON.stringify(payload));
 });
}
export class GolfMetrologyRuntime extends GolfEyesRuntime{
 constructor({dataDir=path.join(ROOT,'local-data'),workspace=path.join(ROOT,'workspace'),python=process.env.GOLF_PYTHON||'python3'}={}){
  fs.mkdirSync(workspace,{recursive:true});super({dataDir,workspace,python});
  this.measurePath=path.join(dataDir,'metrology-state.json');
  this.measureState=fs.existsSync(this.measurePath)?JSON.parse(fs.readFileSync(this.measurePath,'utf8')):{version:1,models:{}};
  if(this.measureState?.version!==1||typeof this.measureState.models!=='object'||Array.isArray(this.measureState.models))throw Error('METROLOGY_STATE_SCHEMA');
  this.measureQueue=Promise.resolve();
 }
 status(){return {...super.status(),metrology:{release:'0.3.0',methods:['actual-source AST self-scan','relative sRGB image photometry','image-space phase correlation','diagonal Kalman innovation','conditional Poisson shot noise'],selfTargets:Object.keys(SELF_TARGETS),calibration:'No calibrated photon, radiance or quantum-sensor measurements; actual files and pixels are measured'}};}
 run(goal,role='observer'){
  if(goal?.kind!=='metrology')return super.run(goal,role);
  const work=async()=>{
   if(!['researcher','owner'].includes(role))throw Error('METROLOGY_DENIED: observer role');
   runtimeSafeObject(goal,['kind','mode','targets','file','second','assumedPhotoelectrons','runTests']);
   if(!['selfscan','frame'].includes(goal.mode))throw Error('METROLOGY_MODE');
   if(goal.mode==='selfscan')return this.selfscan(goal,role);
   return this.frame(goal,role);
  };
  const pending=this.measureQueue.then(work);this.measureQueue=pending.then(()=>{},()=>{});return pending;
 }
 async updateModel(key,z,{category,weight=1}={}){
  const earlier=this.measureState.models[key]??null;
  const step=innovationStep(earlier?.state??null,z);
  const model={state:{mean:step.mean,variance:step.variance},observations:(earlier?.observations??0)+1};
  this.measureState.models[key]=model;atomic(this.measurePath,this.measureState);
  const rgb=[bounded(step.novelty),bounded(step.normalizedInnovation/5),bounded(category==='frame'?.25:.1)];
  // The original Daughter core processes the derived synthetic vector; this is NOT an optical photon signal.
  const daughter=(await this.os.submit({service:'sensor.ingest',payload:{sourceId:'golf:metrology:innovation',kind:'synthetic',samples:Array.from({length:12},()=>({rgb,dt:.05}))}},'researcher')).result;
  return {firstObservation:step.firstObservation,observations:model.observations,normalizedInnovation:step.normalizedInnovation,novelty:step.novelty,innovationResidual:step.residual,posterior:step.mean,posteriorVariance:step.variance,assumptions:step.assumptions,neuron:{core:'locked Daughter Δ³',syntheticFeatureVector:rgb,spikes:daughter.spikes,latestSoma:daughter.latestLayers.soma.soma,interpretation:'simulated diagnostic neuron, not subjective feeling'}};
 }
 async selfscan(goal,role){
  if(goal.targets!==undefined&&(!Array.isArray(goal.targets)||goal.targets.length<1||goal.targets.length>8||goal.targets.some(t=>!Object.hasOwn(SELF_TARGETS,t))||new Set(goal.targets).size!==goal.targets.length))throw Error('METROLOGY_TARGET_ALLOWLIST');
  if(goal.runTests!==undefined&&typeof goal.runTests!=='boolean')throw Error('METROLOGY_RUN_TESTS_FLAG');
  const start=performance.now(),cpuStart=process.cpuUsage(),memoryBefore=process.memoryUsage().rss;
  const targets=goal.targets??Object.keys(SELF_TARGETS);
  const reports=[];
  for(const target of targets){
   const src=SELF_TARGETS[target],raw=fs.readFileSync(src);if(raw.length>100000)throw Error('METROLOGY_SOURCE_SIZE_LIMIT');
   const extension=path.extname(src),snapshot='internal_'+target+extension;
   safeSnapshot(this.workspace,snapshot,raw);
   const observed=await super.run({kind:'eyes',mode:'code',file:snapshot},role);
   const ast=observed.observation.observation;
   const z=codeVector(ast);
   const fused=await this.updateModel('source:'+target,z.values,{category:'source'});
   const previous=this.measureState.models['sourcehash:'+target]?.sha256||null;
   const sourceHash=SHA(raw),changedSincePrior=previous!==null&&previous!==sourceHash;
   this.measureState.models['sourcehash:'+target]={sha256:sourceHash};atomic(this.measurePath,this.measureState);
   reports.push({id:target,file:path.relative(ROOT,src),sha256:sourceHash,previousSha256:previous,changedSincePrior,
      originalMatchesSnapshot:SHA(fs.readFileSync(path.join(this.workspace,snapshot)))===sourceHash,
      syntaxValid:ast.syntaxValid,functions:ast.symbols.filter(s=>s.kind==='function'||s.kind==='class').slice(0,20),
      imports:ast.imports,callEdges:ast.edges.length,complexity:ast.complexity,features:z.features,measurementUnits:z.units,
      stateInnovation:fused,sourceObservationRecord:observed.record.sequence});
  }
  const scanDurationMs=performance.now()-start;
  const alert=reports.filter(r=>!r.syntaxValid||r.changedSincePrior);
  const observations={filesExamined:reports.length,sourceBytes:reports.reduce((n,r)=>n+fs.statSync(path.join(ROOT,r.file)).size,0),syntaxFailures:reports.filter(r=>!r.syntaxValid).length,sourceChangedCount:reports.filter(r=>r.changedSincePrior).length,
    astNodes:reports.reduce((n,r)=>n+r.complexity.astNodes,0),branches:reports.reduce((n,r)=>n+r.complexity.branches,0),
    functionOrClasses:reports.reduce((n,r)=>n+r.complexity.functions||0,0),
    processing:{scanElapsedMs:+scanDurationMs.toFixed(3),totalElapsedMs:null,cpuUserMicroseconds:null,cpuSystemMicroseconds:null,rssBeforeBytes:memoryBefore,rssAfterBytes:null},
    sourceScope:'actual source AST, function/call/import edges; static structure cannot prove meaning or execution coverage'};
  let testEvidence=null;
  if(goal.runTests){testEvidence=await this.checkTests();}
  const conclusions=[...reports.filter(x=>x.changedSincePrior).map(x=>'Source bytes changed since prior inspection: '+x.id),
      ...reports.filter(x=>!x.syntaxValid).map(x=>'Source syntax invalid: '+x.id)];
  if(testEvidence&&!testEvidence.passed)conclusions.push('One or more executable checks failed. See test evidence.');
  if(!conclusions.length)conclusions.push('No source-change or syntax-failure trigger; this is NOT evidence that the source is correct or bug-free.');
  const durationMs=performance.now()-start,cpu=process.cpuUsage(cpuStart),memoryAfter=process.memoryUsage().rss;
  observations.processing.totalElapsedMs=+durationMs.toFixed(3);observations.processing.cpuUserMicroseconds=cpu.user;observations.processing.cpuSystemMicroseconds=cpu.system;observations.processing.rssAfterBytes=memoryAfter;
  const record=this.ledger.append({kind:'metrology',mode:'selfscan',role,requestDigest:SHA(Buffer.from(JSON.stringify(targets))),evidenceClass:'REAL_SOURCE_AST_AND_PROCESS_CPU_TIME',acceptance:observations.syntaxFailures?'REVIEW_SYNTAX':'STATIC_SCAN_COMPLETE',durationMs:+durationMs.toFixed(3)});
  this.executions++;
  return {goal:'metrology',mode:'selfscan',evidenceClass:'MEASURED_LOCAL_FILES_AND_PROCESS',observations,reports,testEvidence,conclusions,
    acceptance:{state:observations.syntaxFailures?'REVIEW_SYNTAX':'STATIC_SCAN_COMPLETE',promotion:'NO_AUTOMATIC_PROMOTION'},record};
 }
 async checkTests(){
  const {spawnSync}=await import('node:child_process');
  const files=['tests/innovation.test.mjs','parents/Golf-Ripple-Digital-Eyes-v0.2/tests/eyes.test.mjs'];
  const started=performance.now();
  const p=spawnSync(process.execPath,['--test',...files],{cwd:ROOT,timeout:60000,maxBuffer:3000000,encoding:'utf8'});
  const match=(p.stdout||'').match(/# tests (\d+)[\s\S]*?# pass (\d+)[\s\S]*?# fail (\d+)/);
  return {passed:p.status===0&&!p.error,exitCode:p.status,error:p.error?.message||null,testFiles:files,testsFound:match?Number(match[1]):null,testsPassed:match?Number(match[2]):null,testsFailed:match?Number(match[3]):null,elapsedMs:+(performance.now()-started).toFixed(3),evidence:'actual local Node --test process; not proof of comprehensive correctness',logTail:(p.stdout||p.stderr||'').slice(-1200)};
 }
 async frame(goal,role){
  if(typeof goal.file!=='string')throw Error('METROLOGY_FILE');
  if(goal.second!==undefined&&typeof goal.second!=='string')throw Error('METROLOGY_SECOND');
  const payload={file:goal.file,...(goal.second?{second:goal.second}:{}),...(goal.assumedPhotoelectrons!==undefined?{assumedPhotoelectrons:goal.assumedPhotoelectrons}:{})};
  const start=performance.now();
  // First run the actual locked Digital Eyes pixel interpreter and Daughter diagnostic.
  const pixel=await super.run({kind:'eyes',mode:'image',file:goal.file,...(goal.second?{second:goal.second}:{})},role);
  const observation=await fixedWorker(this.python,[path.join(ROOT,'src/metrology.py'),this.workspace],payload);
  if(!observation.ok)throw Error('METROLOGY_WORKER:'+observation.error);
  const values=imageVector(observation.result);
  const fused=await this.updateModel('frame:'+goal.file,values.values,{category:'frame'});
  const durationMs=performance.now()-start;
  const record=this.ledger.append({kind:'metrology',mode:'frame',role,requestDigest:SHA(Buffer.from(JSON.stringify(payload))),evidenceClass:'MEASURED_DECODED_IMAGE_PIXELS',acceptance:'IMAGE_SPACE_ONLY',durationMs:+durationMs.toFixed(3)});
  this.executions++;
  return {goal:'metrology',mode:'frame',evidenceClass:'MEASURED_DIGITAL_IMAGE_VALUES',observation:observation.result,
     inheritedPixelComparison:pixel.observation.observation.comparison||null,
     stateInnovation:fused,parentDaughterRecord:pixel.record.sequence,
     acceptance:{state:'IMAGE_SPACE_ONLY',physicalCalibration:'NOT_PRESENT',quantumMeasurement:'NOT_PERFORMED',promotion:'NO_AUTOMATIC_PROMOTION'},record};
 }
}
