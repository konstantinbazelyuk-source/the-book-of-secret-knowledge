/** Deterministic evidence-only human-readable reports; never generates semantic claims. */
const n=x=>typeof x==='number'&&Number.isFinite(x)?x.toLocaleString('en-US',{maximumFractionDigits:5}):String(x);
export function measuredReport(r){
 if(r?.goal!=='metrology'||!['selfscan','frame'].includes(r.mode))throw Error('REPORT_INPUT');
 if(r.mode==='selfscan'){
  const o=r.observations,t=r.testEvidence;
  const lines=['# Golf Digital Eyes — Executed self-inspection','',
   'Evidence: actual local source bytes, parser output, and process counters; **not program comprehension**.','',
   `Source files inspected: **${o.filesExamined}**; total source bytes: **${n(o.sourceBytes)}**.`,
   `AST nodes: **${n(o.astNodes)}**; branch constructs: **${n(o.branches)}**; parser failures: **${o.syntaxFailures}**.`,
   `Processing: **${n(o.processing.totalElapsedMs)} ms** wall time; CPU user **${n(o.processing.cpuUserMicroseconds)} µs**, CPU system **${n(o.processing.cpuSystemMicroseconds)} µs**.`,
   t?`Executable self-tests: **${t.testsPassed}/${t.testsFound}** passed; exit code ${t.exitCode}.`:'Executable self-tests were not requested.',
   '', '## Actually observed modules'];
  for(const x of r.reports)lines.push(`- ${x.id}: ${n(x.complexity.astNodes)} AST nodes, ${n(x.complexity.branches)} branches; SHA-256 ${x.sha256}; changed since last scan: **${x.changedSincePrior}**; normalized innovation ${n(x.stateInnovation.normalizedInnovation)}.`);
  lines.push('','## Findings',...r.conclusions.map(x=>'- '+x),'','**Boundary:** Changes and deviations are measurements, not proof of defects, comprehension, security, or an improvement.');
  return lines.join('\n')+'\n';
 }
 const x=r.observation,y=x.relativePhotometry,z=x.pair;
 return ['# Golf Digital Eyes — Executed recorded-image report','',
  `Decoded image: ${x.width} × ${x.height} pixels; original SHA-256 ${x.fileHash}.`,
  `Measured relative mean linear sRGB luminance: ${n(y.meanLinearLuminance)}.`,
  `Measured contrast centroid (pixels): ${y.centroid?y.centroid.map(n).join(', '):'not determined'}.`,
  z?`Measured second-frame relative luma difference: ${n(z.meanLuminanceDelta)}; estimated **image-space** shift (px): ${z.estimatedTranslationPixels.map(n).join(', ')}; correlation response ${n(z.phaseCorrelationResponse)}.`:'No second frame supplied.',
  `Inherited Digital Eyes changed-pixel count: ${r.inheritedPixelComparison?.changedPixels??'no comparison'}.`,
  '', '**Boundary:** These are decoded image values. No calibrated photons, absolute radiance, physical camera pose, subjective sight, or quantum sensor reading is established.'].join('\n')+'\n';
}
