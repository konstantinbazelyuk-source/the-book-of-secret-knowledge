/** Separately labeled simulated noise sensitivity study; never counts as physical observation. */
import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import {innovationStep} from './innovation.mjs';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
let seed=0x2a415cc1;const random=()=>((seed=(Math.imul(seed,1664525)+1013904223)>>>0)+.5)/4294967296;
const normal=()=>Math.sqrt(-2*Math.log(random()))*Math.cos(2*Math.PI*random());
function simulate(policy,step=false){let sumRaw=0,sumFiltered=0,postStep=0,events=0,recover=[];
 for(let replicate=0;replicate<30;replicate++){
  let state=null;let s=0;
  for(let i=0;i<300;i++){
   const truth=step&&i>=150?1:0,measurement=truth+.25*normal();
   const out=innovationStep(state,[measurement],policy);
   state={mean:out.mean,variance:out.variance};
   if(i>=30){sumRaw+=(measurement-truth)**2;sumFiltered+=(out.mean[0]-truth)**2;events++;}
   if(step&&i>=150&&i<165)postStep+=(out.mean[0]-1)**2;
   if(step&&i>=150&&i<170)recover.push(out.novelty);
  }
 }
 return {events,rmseRaw:Math.sqrt(sumRaw/events),rmseFiltered:Math.sqrt(sumFiltered/events),improvementPercent:100*(1-Math.sqrt(sumFiltered/sumRaw)),
   earlyStepRMSE:step?Math.sqrt(postStep/(30*15)):null,meanNoveltyNearStep:step?recover.reduce((a,b)=>a+b,0)/recover.length:null};
}
const policies={fast:{processVariance:.03,measurementVariance:.0625},slow:{processVariance:.001,measurementVariance:.0625}};
const result={method:'controlled pseudorandom Gaussian noise; NOT image, sensor or human data',generator:'LCG 0x2a415cc1 then Box-Muller',replicates:30,stepsPerReplicate:300,
  target:['stationary 0','step 0 to 1 at t=150'],settings:policies,stationary:{},step:{}};
for(const [name,p] of Object.entries(policies))result.stationary[name]=simulate(p,false);
for(const [name,p] of Object.entries(policies))result.step[name]=simulate(p,true);
fs.mkdirSync(path.join(ROOT,'results'),{recursive:true});fs.writeFileSync(path.join(ROOT,'results','innovation-simulation.json'),JSON.stringify(result,null,2));
console.log(JSON.stringify(result,null,2));
