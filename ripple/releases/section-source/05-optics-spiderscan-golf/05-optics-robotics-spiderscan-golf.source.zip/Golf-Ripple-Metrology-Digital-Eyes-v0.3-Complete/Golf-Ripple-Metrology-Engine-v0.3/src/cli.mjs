import {GolfMetrologyRuntime} from './metrology-runtime.mjs';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const run=new GolfMetrologyRuntime({dataDir:process.env.GOLF_METROLOGY_DATA||path.join(ROOT,'local-data')});
const command=process.argv[2]||'status';
const {measuredReport}=await import('./report.mjs');
try{
 if(command==='status')console.log(JSON.stringify(run.status(),null,2));
 else if(command==='watch-self'){const {watchSelf}=await import('./self-watch.mjs');watchSelf({runtime:run,onReport:x=>{if(x.report?.goal==='metrology'){fs.mkdirSync(path.join(ROOT,'results'),{recursive:true});fs.writeFileSync(path.join(ROOT,'results','LIVE_SELF_WATCH_REPORT.md'),measuredReport(x.report));}console.log(JSON.stringify(x));}});console.log('Watching fixed Golf source modules for checksum changes; Ctrl-C to stop.');}
 else if(command==='selfscan'||command==='frame'||command==='goal'){
  const goal=command==='selfscan'?{kind:'metrology',mode:'selfscan',runTests:true}:command==='frame'?{kind:'metrology',mode:'frame',file:process.argv[3]||'observed_before.png',second:process.argv[4]||'observed_after.png'}:JSON.parse(process.argv[3]);
  const r=await run.run(goal,'owner');
  const resultFile=path.join(ROOT,'results','last-'+(r.mode||r.goal)+'.json');fs.mkdirSync(path.dirname(resultFile),{recursive:true});fs.writeFileSync(resultFile,JSON.stringify(r,null,2));
  if(r.goal==='metrology')fs.writeFileSync(path.join(ROOT,'results',r.mode==='selfscan'?'SELF_RESEARCH_REPORT.md':'RECORDED_IMAGE_REPORT.md'),measuredReport(r));
  console.log(JSON.stringify(r,null,2));
 }else if(command==='serve'){
  const {serve}=await import('./server.mjs');const h=await serve(run,{port:Number(process.env.GOLF_METROLOGY_PORT||8894)});
  console.log(`Golf Measured Digital Eyes: http://127.0.0.1:${h.address.port}\nAccess token: ${h.token}\nCtrl-C to stop`);
 }else throw Error('commands: status | selfscan | frame [file] [second] | goal JSON | serve | watch-self');
}catch(e){console.error(e);process.exitCode=1;}
