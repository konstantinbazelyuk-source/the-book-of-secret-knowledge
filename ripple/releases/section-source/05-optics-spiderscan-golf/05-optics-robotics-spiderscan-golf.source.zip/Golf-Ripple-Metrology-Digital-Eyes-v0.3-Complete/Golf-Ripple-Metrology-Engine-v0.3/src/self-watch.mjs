/** Bounded active observation of fixed approved Golf source targets. */
import fs from 'node:fs';import {createHash} from 'node:crypto';
import {SELF_TARGETS} from './metrology-runtime.mjs';
const hash=name=>createHash('sha256').update(fs.readFileSync(name)).digest('hex');
export function sourceTransitions(files,previous){
 const now={},changes=[];
 for(const [id,p] of Object.entries(files)){
  const value=hash(p);now[id]=value;
  if(previous&&previous[id]&&previous[id]!==value)changes.push({id,previous:previous[id],current:value});
 }
 return {hashes:now,changes};
}
export function watchSelf({runtime,intervalMs=2000,maxEvents=64,onReport=()=>{}}){
 if(!runtime||typeof runtime.run!=='function')throw Error('WATCH_RUNTIME');
 if(!Number.isInteger(intervalMs)||intervalMs<300||intervalMs>60000||!Number.isInteger(maxEvents)||maxEvents<1||maxEvents>128)throw Error('WATCH_BOUNDS');
 let last=sourceTransitions(SELF_TARGETS,null).hashes,busy=false,events=0,active=true;
 const timer=setInterval(async()=>{
  if(!active||busy)return;busy=true;
  try{const sample=sourceTransitions(SELF_TARGETS,last);last=sample.hashes;
   for(const item of sample.changes){if(!active)return;
    const report=await runtime.run({kind:'metrology',mode:'selfscan',targets:[item.id]},'owner');events++;
    onReport({kind:'MEASURED_SOURCE_CHANGED',target:item.id,oldHash:item.previous,newHash:item.current,record:report.record.sequence,report});
    if(events>=maxEvents){stop();return;}
   }
  }catch(e){onReport({kind:'WATCH_ERROR',error:String(e.message||e)});}finally{busy=false;}
 },intervalMs);
 function stop(){active=false;clearInterval(timer);}
 return {stop,get events(){return events;}};
}
