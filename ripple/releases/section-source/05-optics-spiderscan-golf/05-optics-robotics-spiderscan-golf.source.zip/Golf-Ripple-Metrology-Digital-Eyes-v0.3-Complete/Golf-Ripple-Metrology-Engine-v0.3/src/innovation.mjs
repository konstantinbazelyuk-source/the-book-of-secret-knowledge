/** Golf measurement-innovation layer (v0.3): an engineered fusion of scalar Kalman updates and NIS.
 * Not a newly discovered natural law. Measurement noise q/r are explicit model settings.
 */
const finite=(x,name)=>{if(typeof x!=='number'||!Number.isFinite(x))throw Error(`METROLOGY_NONFINITE:${name}`);return x;};
export const bounded=(x,a=0,b=1)=>Math.min(b,Math.max(a,x));
export function innovationStep(prior,measurement,{processVariance=0.008,measurementVariance=0.035,weights}={}){
 if(!Array.isArray(measurement)||!measurement.length||measurement.length>16)throw Error('METROLOGY_DIMENSIONS');
 const z=measurement.map((v,i)=>finite(v,'z'+i));
 if(z.some(v=>Math.abs(v)>1e8))throw Error('METROLOGY_RANGE');
 const q=finite(processVariance,'q'),r=finite(measurementVariance,'r');
 if(q<0||r<=0||q>10||r>10)throw Error('METROLOGY_VARIANCE');
 const w=weights??z.map(()=>1);
 if(!Array.isArray(w)||w.length!==z.length||w.some(v=>!Number.isFinite(v)||v<0)||w.every(v=>v===0))throw Error('METROLOGY_WEIGHTS');
 if(prior!==null&&prior!==undefined&&(!Array.isArray(prior.mean)||!Array.isArray(prior.variance)||prior.mean.length!==z.length||prior.variance.length!==z.length))throw Error('METROLOGY_PRIOR');
 if(prior==null)return {firstObservation:true,mean:z,variance:z.map(()=>Math.max(r,0.01)),residual:z.map(()=>0),normalizedInnovation:0,gain:z.map(()=>1),novelty:0,assumptions:{processVariance:q,measurementVariance:r,independentDiagonal:true}};
 let sum=0,weight=0;
 const next=[],variance=[],residual=[],gain=[];
 for(let i=0;i<z.length;i++){
  const mu=finite(prior.mean[i],'mu'+i),p=finite(prior.variance[i],'p'+i);
  if(p<0||p>1e8)throw Error('METROLOGY_PRIOR_VARIANCE');
  const predicted=p+q,den=predicted+r,err=z[i]-mu,k=predicted/den;
  next.push(mu+k*err);variance.push((1-k)*predicted);residual.push(err);gain.push(k);
  sum+=w[i]*(err*err/den);weight+=w[i];
 }
 const score=sum/weight;
 return {firstObservation:false,mean:next,variance,residual,gain,normalizedInnovation:score,novelty:bounded(1-Math.exp(-score/2)),assumptions:{processVariance:q,measurementVariance:r,independentDiagonal:true}};
}
export function codeVector(observation){
 const c=observation?.complexity;
 if(!c||!observation.syntaxValid)throw Error('METROLOGY_CODE_AST_INVALID');
 const features=['astNodes','branches','functions','lines'];
 const z=features.map(k=>Math.log1p(finite(c[k],k)));
 z.push(Math.log1p((observation.imports||[]).length),Math.log1p((observation.edges||[]).length));
 return {features:[...features,'imports','callEdges'],values:z,units:'natural logarithm of 1 + AST counts; not execution behavior'};
}
export function imageVector(photo){
 if(!photo||!Number.isInteger(photo.width)||!Number.isInteger(photo.height)||photo.width<1||photo.height<1)throw Error('METROLOGY_BAD_FRAME');
 const data=photo.relativePhotometry;
 if(!data||!Number.isFinite(data.meanLinearLuminance))throw Error('METROLOGY_BAD_LUMA');
 return {features:['meanLinearLuminance','centroidXNorm','centroidYNorm','spreadXNorm','spreadYNorm'],values:[data.meanLinearLuminance,data.centroid?data.centroid[0]/photo.width:0,data.centroid?data.centroid[1]/photo.height:0,data.spread?data.spread[0]/photo.width:0,data.spread?data.spread[1]/photo.height:0],units:'relative linear sRGB and normalized image coordinates; NOT calibrated radiance'};
}
