from pathlib import Path
from math import sqrt, pi, sin, cos, radians
import csv,json,hashlib,subprocess
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter,landscape
from reportlab.lib.colors import HexColor,Color
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from source.engineering_math import motor_model,MOTOR_TEST,camera_geometry,geometry
import trimesh
P=Path(__file__).parent
for p in [P/'results',P/'design'] :p.mkdir(exist_ok=True)
# Mesh analysis - assume solid polymer density 1.27 g/cc only hypothetical FDM upper bound
meshes={}
for f in (P/'cad').glob('*.stl'):
 m=trimesh.load(f,force='mesh');assert m.is_watertight and len(m.split())==1,(f,m.is_watertight)
 meshes[f.name]={'watertight':bool(m.is_watertight),'one_connected_piece':len(m.split())==1,
                 'bbox_mm':np.round(m.bounds,3).tolist(),'solid_volume_cm3':round(m.volume/1000,3),
                 'hypothetical_solid_PETG_mass_g_at_1_27_g_cm3':round(m.volume/1000*1.27,3),
                 'NOT_measured':'actual print mass or mechanical tolerance'}
(P/'results/mesh_validation.json').write_text(json.dumps(meshes,indent=2)+'\n')
# Thrust chart
fig,ax=plt.subplots(figsize=(8,4.2),layout='constrained')
X=np.array([r[0] for r in MOTOR_TEST]);Y=np.array([r[1]*4 for r in MOTOR_TEST]);
ax.plot(X,Y,'o-',label='4 × manufacturer measured motor thrust (16 V bench)')
case_lines=[]
for m in (1600,1800,2000,2200,2400):
 q=motor_model(m)
 ax.plot(q['hover_throttle_interpolation_pct'],m,'x',markersize=7)
 case_lines.append(f"{m/1000:.1f} kg  -> {q['hover_throttle_interpolation_pct']:.1f}%")
ax.text(.72,.62,'Mass / interpolated command\n'+'\n'.join(case_lines),
    transform=ax.transAxes,fontsize=8,ha='left',va='top',
    bbox=dict(boxstyle='round',facecolor='white',alpha=.94,edgecolor='#c9d3da'))
ax.set_xlabel('ESC command / manufacturer test percent');ax.set_ylabel('Static total thrust (gram-force)');ax.set_title('Ripple SpiderScan v0.4 | Static benchmark, NOT predicted flight performance');ax.grid(alpha=.25);ax.legend(fontsize=8)
fig.savefig(P/'design/static_thrust_interpolation.png',dpi=170);plt.close(fig)
# colony timing chart based on same still image
s=json.loads((P/'results/colony_verified.json').read_text())
fig,axs=plt.subplots(2,1,figsize=(8,5),sharex=True,layout='constrained')
axs[0].step([t['tick'] for t in s['trace']],[t['active_nodes'] for t in s['trace']],where='post');axs[0].set_ylabel('Active neurons');axs[0].set_ylim(0,17);axs[0].grid(alpha=.2)
axs[1].plot([t['tick'] for t in s['trace']],[t['processing_ms'] for t in s['trace']],'o-');axs[1].set_ylabel('CPU process ms/frame');axs[1].set_xlabel('Replayed still-image tick (20Hz model-time)');axs[1].grid(alpha=.2)
fig.suptitle('Colony v0.4 | Actual software processing / NOT real sensor throughput')
fig.savefig(P/'design/colony_profile.png',dpi=165);plt.close(fig)
# dimensioned 2D mechanical projection, no OEM CAD claim
fig,ax=plt.subplots(figsize=(9,8),layout='constrained')
a=500/(2*sqrt(2))
for x in (-a,a):
 for y in (-a,a):
  ax.add_patch(plt.Circle((x,y),127,facecolor='lightsteelblue',edgecolor='steelblue',alpha=.18,lw=2))
  ax.add_patch(plt.Circle((x,y),15,facecolor='gray',edgecolor='black'))
  ax.plot([0,x],[0,y],color='dimgray',linewidth=8,solid_capstyle='round')
ax.add_patch(plt.Rectangle((-72,-72),144,144,fc='whitesmoke',ec='black',lw=1.6))
for k in range(8):
 theta=radians(22.5+45*k)
 r0,r1,r2=65,142,218
 xx=[r0*cos(theta),r1*cos(theta),r2*cos(theta)]
 yy=[r0*sin(theta),r1*sin(theta),r2*sin(theta)]
 ax.plot(xx,yy,ls='-',color='peru',linewidth=2,alpha=.9)
 ax.plot(xx[1],yy[1],'o',color='peru',ms=4)
 ax.plot(xx[2],yy[2],'.',color='saddlebrown',ms=7)
ax.annotate('',xy=(a,-a),xytext=(-a,a),arrowprops=dict(arrowstyle='<->',lw=1.5))
ax.text(0,16,'500mm motor diagonal',rotation=-45,ha='center',fontsize=11,fontweight='bold')
ax.annotate('',xy=(a+127,a),xytext=(a-127,a),arrowprops=dict(arrowstyle='<->',lw=1.2))
ax.text(a,a+18,'254mm prop disc',ha='center',fontsize=10)
ax.text(-345,338,'X500 V2 manufacturer wheelbase and props',fontsize=11,weight='bold')
ax.text(-345,316,'Spider limbs: non-load-bearing conceptual positions, below prop plane',fontsize=9)
ax.set(xlim=(-400,400),ylim=(-395,380));ax.set_aspect('equal');ax.axis('off')
fig.savefig(P/'design/top_view_dimensioned.png',dpi=170);plt.close(fig)
# ready to print manufacturing pdf, 3 pages letter
pdf=P/'docs/engineering_sheets.pdf';c=canvas.Canvas(str(pdf),pagesize=letter)
W,H=letter
ink=HexColor('#132b3d');muted=HexColor('#577082');orange=HexColor('#d68135')
def head(n,title,sub):
 c.setFillColor(ink);c.rect(0,H-86,W,86,fill=1,stroke=0)
 c.setFillColor(HexColor('#ffffff'));c.setFont('Helvetica-Bold',20);c.drawString(40,H-43,title)
 c.setFont('Helvetica',10);c.drawString(40,H-64,sub)
 c.setFillColor(ink);c.setFont('Helvetica',9);c.drawRightString(W-40,26,f'SpiderScan v0.4 | {n}/3 | research prototype, not flight qualified')
def line(y,s,size=10,bold=False):
 c.setFillColor(ink);c.setFont('Helvetica-Bold' if bold else 'Helvetica',size);c.drawString(45,y,s)
head(1,'SPIDERSCAN / BUILD BASIS','Commercial X500 V2 airframe + optical scanner + Ripple Colony read-only processing')
line(680,'Confirmed manufacturer reference inputs',13,True)
for i,(a1,a2) in enumerate([
 ('Platform','Holybro X500 V2 / Pixhawk 6C; 500 mm motor diagonal'),
 ('Motors','4 x 2216 KV920, 4 x 20A ESC, 254mm diameter propellers'),
 ('Rail','2 x 10mm OD, 250mm nominal length'),
 ('Scanner','Raspberry Pi IMX296 1456x1088; 3.45um pitch; PCB 38x38mm'),
 ('Companion','Pi 4 / independent fused 5V power regulator'),
 ('DJI','O4 optional recording ONLY, separate <=13.2V input supply'),
 ]):line(649-24*i,f'{a1}:  {a2}',10)
line(486,'PRINT / MANUFACTURE: FIT-CHECK PARTS ONLY',13,True)
for i,t in enumerate([
 '8 x 10mm rail base clamps | 8 x mating clamp caps | 16 x M3 bolts + locknuts',
 '8 x angled cosmetic elbows | 16 x OD 4mm light rods (CUT AFTER FIT)',
 '1 x 75 x 65 x 4mm camera tray | 36.5mm aperture | 45mm M3 pitch',
 'MATERIAL: PETG or PA12 for fit checks; DO NOT REMOVE STOCK LANDING GEAR',
 'NO PURCHASE PLACED. Request first article and verify holes on real frame.'
]):line(462-i*23,t,10)
line(316,'POWER / TELEMETRY BOUNDARY',13,True)
for i,t in enumerate([
 '4S battery -> OEM PDB and FC power module (follow PX4 guide).',
 '4S battery -> fused independent 5V buck -> Raspberry Pi USB-C (check current).',
 'Optional O4 -> own regulated supply; NEVER connect directly to 4S.',
 'Pixhawk 6C TELEM2 TX pin2 (3.3V) -> Pi RXD pin10; common GND pin6.',
 'NO Raspberry Pi TX and NO TELEM2 +5V connection. Verify physical keyed pin1.'
]):line(290-i*20,t,9)
line(154,'SOURCE: Holybro manuals H1-H6; Raspberry Pi R1-R4; DJI D1-D2; see source register',8)
line(134,'EVIDENCE: bench thrust charts are published data; performance unverified in flight.',8)
c.showPage()
head(2,'PLAN VIEW / CLEARANCE','Scaled diagram of nominal motor and propeller envelope; custom spider legs shown for layout only')
c.drawImage(str(P/'design/top_view_dimensioned.png'),45,125,width=W-90,height=560,preserveAspectRatio=True)
line(105,'Adjacent rotor center: 353.55mm | Disk gap: 99.55mm (nominal, static only)',9)
line(88,'No rotor flex/wash/leg interference certification; official STEP assembly not imported.',9)
c.showPage()
head(3,'BENCH THRUST / VALIDATION','Published Holybro 16V static motor points with arithmetic interpolation, not flight predictions')
c.drawImage(str(P/'design/static_thrust_interpolation.png'),38,310,width=536,height=330,preserveAspectRatio=True)
line(292,'Camera pinhole estimate with ASSUMED 6mm CS lens at 1.0m nadir:',11,True)
q=camera_geometry(1,6)
line(270,f"Sensor coverage ~{q['ideal_coverage_w_m']}m x {q['ideal_coverage_h_m']}m; sample pitch ~{q['ideal_pinhole_ground_sample_distance_mm_per_px']}mm/px",10)
line(242,'REQUIRED BEFORE USE:',12,True)
for i,t in enumerate([
 '1. Fit-check one 10mm clamp pair and vendor depth-mount hole spacing.',
 '2. Measure full takeoff mass, center of gravity, cable and vibration paths.',
 '3. Test Pi buck voltage/load and O4 independent voltage if installed.',
 '4. Calibrate global shutter camera against physical printed reference.',
 '5. OEM aircraft checkout + FAA registration/Remote ID + manual pilot.',
 '6. Prop clearance and attachment load qualification before fitting spider legs.'
]):line(222-i*21,t,9.5)
c.save()
print('Saved',pdf,'and meshes',json.dumps(meshes,indent=2))
