# Ripple SpiderScan v0.4 — published-engineering-source upgrade

**Status: Tested software + manufacturable FIT-CHECK accessory geometry; NO physical fabrication, aircraft purchase, qualified flight or optical-field measurement.**

## Hardware choice
Holybro X500 V2 Dev Kit/Pixhawk 6C, Raspberry Pi Global Shutter Camera, Raspberry Pi 4, optional DJI O4 recorded video, 8 decorative non-load-bearing legs. Keep OEM structural arms and landing gear. All power connections and autopilot controls must stay outside the Ripple agent's write capabilities.

## Use code (offline)
```bash
pip install -r requirements.txt
python -m pytest tests -q
python -m source.colony_v04 --image reference/archived_photo_NOT_HARDWARE.png --out results/new_colony.json
python -m source.engineering_math
```
The actual archived image has real pixels but is NOT a scanner/drone capture. A still image repeated over synthetic 20Hz is not a real camera frame-rate measurement.

## On hardware later
Camera recording path, ONLY on a Pi connected to the actual IMX296 (not tested here):
```bash
python -m source.pi_capture_UNTESTED_HARDWARE captures/001.jpg
python -m source.colony_v04 --image captures/001.jpg --out results/physical_capture_001.json
```
Optional receive-only FC metadata via physically wired UART (not tested here):
```
python -m source.telemetry_readonly_UNTESTED_HARDWARE --device /dev/serial0 --baud 57600 --seconds 10
```
UART/CSI connectivity, shutter settings, spatial/optical calibration, LiPo power and interference are gates, not assumed successes.

## Printing
`cad/SpiderScan_v04_accessories.scad` has four selected `PART` targets and four `.stl` exports. Verify vendor units mm. Two-part split clamp fits nominal 10mm accessory rods *in geometry only*. The 75×65 camera tray uses 45mm optional depth-camera interface (manufacturer diagram). No flight structural parts made here. Start one pair as gauge; measurement before production batch.

See `docs/BUILD_AND_GATES.md`, `docs/SOURCE_REGISTER.md`, `docs/PURCHASE_MATRIX.csv`, `docs/MANUFACTURER_RFQ.txt`, and `docs/engineering_sheets.pdf`.

## Scope and evidence
- ORIGINAL NEURON: byte-identical preserved from v0.3; own integration adapter only.
- COLONY: trained weights, multi-core speedup, consciousness, quantum computation, and agent task generality are NOT demonstrated.
- OUTPUT: meaningful image measurement and independent state machine events; can read image bytes and emit inspectable numeric files.
- MANUFACTURING: models are preliminary fit-check STL not validated structural aircraft parts; fit OEM X500 V2 hardware first.
- PROCUREMENT: supplier URLs and some listed USD prices researched, no cart, sale, order, or payment executed.
