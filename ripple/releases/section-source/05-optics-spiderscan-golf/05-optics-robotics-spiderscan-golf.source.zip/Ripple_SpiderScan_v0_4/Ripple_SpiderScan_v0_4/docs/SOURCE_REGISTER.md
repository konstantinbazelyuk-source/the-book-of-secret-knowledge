# Source register — 13 October 2026

Always use manufacturer documents; preserve original terms/licensing. This design is original accessory work, NOT a redistribution of Holybro STEP or Raspberry Pi copyrighted drawings.

|ID|Official page / drawing|Used for|
|---|---|---|
|H1|https://holybro.com/products/x500-v2-kits|500mm wheelbase, 10mm × 250mm accessory rods, prop 1045, motor type, included parts, vendor kit pricing|
|H2|https://cdn.shopifycdn.net/s/files/1/0604/5905/7341/files/X500_V2_Assembly_Guide_en.pdf?v=1720853913|Mounting suggestions, 45mm M3 optional depth-camera interface, Pi holes 49x58 mm. Holes must still be field checked.|
|H3|https://cdn.shopify.com/s/files/1/0604/5905/7341/files/X500MotorSpec.png?v=1678791632|Static 16V 2216 920KV + 1045 motor test table (30–100%); do not extrapolate flight performance|
|H4|https://docs.px4.io/main/en/frames_multicopter/holybro_x500v2_pixhawk6c|Validated baseline PX4 airframe and assembly/calibration procedure|
|H5|https://holybro.com/products/px4-development-kit-x500-v2|Dev kit variant: Pixhawk 6C / M10 / 915MHz ($579 listing). Contains PM02 V3 analog for 6C, not PM02D.|
|H6|https://docs.holybro.com/autopilot/pixhawk-6c/pixhawk-6c-ports|TELEM2 pin2 TX 3.3V and pin6 GND: receive-only connection option|
|R1|https://www.raspberrypi.com/products/raspberry-pi-global-shutter-camera/|IMX296 1456x1088, pixel 3.45um, 38x38 board, 34g, 150mm ribbon|
|R2|https://datasheets.raspberrypi.com/gs-camera/gs-camera-product-brief.pdf|Mount mechanical reference, unverified chosen lens |
|R3|https://www.raspberrypi.com/news/price-increases-for-2gb-raspberry-pi-4-and-raspberry-pi-5/|Oct 2026 $67.50 announced Pi 4 2GB price (availability not checked)|
|R4|https://www.raspberrypi.com/news/new-raspberry-pi-global-shutter-camera/|2023 $50 global shutter *historic launch* price only|
|P1|https://www.pololu.com/product/4091|Regulated 5V 5.5A supply, 5.5–50V input, currently displayed $39.95, subject to thermal loads|
|D1|https://www.dji.com/o4-air-unit/specs|O4 standard 3.7–13.2V input; do NOT connect direct to 4S 16.8V full battery; goggles and remote extra|
|D2|https://www.dji.com/o4-air-unit|$109 *from* (not full quote, excludes goggles). Independent video only.|
|F1|https://www.faa.gov/uas/getting_started/register_drone|Registration and Remote ID (verify before flight)|
|M1|https://jlc3dp.com/3d-printing-quote|STL upload for quote; no manufacturer contacted yet|
|M2|https://www.xometry.com/capabilities/3d-printing-service/|STL service alternative; no manufacturer contacted yet|

Reference H1 points to full official CAD STEP but CDN fetch was blocked; hence existing OEM rod-to-camera interface is explicitly a FIT-CHECK drawing until stock parts are physically gauged. Do not claim assembly-level CAD interference analysis or manufacturing purchase.
