# SpiderScan v0.4 — real manufacturing and build sequence

## Configuration
- Baseline airframe: Holybro X500 V2 PX4 Dev Kit, Pixhawk 6C/M10/915MHz, use manufacturer supplied flight frame, 4 ESCs/motors, OEM landing gear. 4S LiPo, RC link, appropriate charger, Remote ID and other legal requirements are separate, not included in the base kit.
- Camera: Raspberry Pi IMX296 global shutter + correctly sized CS lens (6mm focal length is an *assumed design selection*), Pi 4 model B 2GB. Dedicated 5V regulator, fuse and protected wiring.
- DJI O4 standard is OPTIONAL, independently recorded video only, NEVER feed 4S LiPo directly to the 3.7–13.2V transmitter. For 4S use dedicated regulated voltage with adequate verified current and noise performance, 9V is a candidate. The O4's goggles and remote are separately priced. Pixel input to Ripple comes from IMX296, NOT from a real-time O4 API.
- Spider silhouette: 8 passive removable articulated appendages using 8× printed 10mm rail clamps + 8× 4mm rod/elbow assemblies; **do not remove stock landing gear**. Never attach to motor supports, never put hardware in swept disk/clearance area. Ground mockup only until flight qualification.

## Source based mechanical dimensions
- X500 500mm diagonal wheelbase; center positions (±176.78,±176.78) mm (assuming ideal symmetrical X layout); horizontal adjacent motors 353.55mm; 254mm prop diameter; static circle gap 99.55mm. Note that this ignores deformation, rotor wake, flexure, aircraft motion and OEM accessory variations.
- Holes in printed 45mm tray are *optional* interface to Holybro depth camera bracket (45mm M3). Measure physical interface before machining/ordering metal parts.
- Rails nominally 10mm, 250mm long; prototype FDM clamp bore is 10.3mm, physically ream or scale after gauge measurement and torque assessment.
- Board tray has central 36.5mm aperture for lens barrel, 75x65x4mm outer footprint and slotted strap guides. Camera is 38x38mm PCB with separate optical barrel. Confirm ribbon bend radius and board contact isolation.

## Manufacturing BOM quantities (FIT CHECK FIRST)
- 2 sets each rail_clamp_base + rail_clamp_cap first to test caliper dimensions. Full cosmetic build: 8 bases, 8 caps, 8 knees, 1 scanner tray.
- 8 pairs of M3 hardware to clamp rods (16 bolts plus 16 locknuts and washers), 16 sections of OD4mm carbon tube (length determined after real fit; suggested start ~80mm+70mm, NOT factory cut spec), 8 low-mass foot tips; optional vibration isolating pads and fasteners.
- PETG or MJF PA12 for ground fit-test; 0.2mm layers, >=3 perimeters, mechanical washer interface, no unqualified flight use. Print orientation, holes/clearances and supports need slicer review. Rod ends must be secured and retained, cannot be allowed to enter prop disks on failure.
- X500 is NOT 3D printed: buying complete ARF/dev kit prevents flight-grade structural-print claims.

## Wiring partition and test gates
1. Assemble stock kit following PX4 manufacturer guides, bench without props, flight-controller calibration and power measurement via QGroundControl. Flight operation subject to manufacturer and FAA compliance.
2. Independently power Pi through 5V >=3A regulator (Pololu D36V50F5 candidate), fused lead appropriately designed by electrician. Validate 5V at Pi UNDER LOAD, regulator thermal margin and wiring strain relief. Never source Pi current from Pixhawk TELEM voltage.
3. Connect IMX296 over CSI; capture a test chart from Pi and compare pixel coordinates. Keep optics rigid, lock exposure and white balance for color comparisons.
4. Optionally UART read-only: FC Pixhawk 6C TELEM2 pin2 TX to Pi GPIO15 pin10; FC TELEM2 pin6 GND to Pi GND. VCC unconnected, Pi TX unconnected. Verify pin order physically by keyed housing diagrams and multimeter. Set PX4 MAVLink port parameters externally; no motor-control wire from Ripple.
5. DJI O4, if used: separate regulator supplies within 3.7–13.2V and properly sized ground wiring; independent video system, never flight control assumption. Test radio coexistence, RF and thermal.
6. Camera exposure/noise: measure printed chart dimensional pitch with ruler/calipers. Ground scan 10 captures, track optical feature stability against known translation. Gate = report median pixel reprojection error AND uncertainty, no unmeasured nanometer claims.
7. Measure total takeoff mass on scale, check center of gravity, motor current, lift margin, rail clamp security, vibration. Select flight equipment ratings from actual loaded tests. Print legs restricted to ground-use until fatigue/failure/prop-clearance tests.
8. No pilotless flight; only after OEM aircraft is individually flight-tested, separate from spider accessories, move to qualified manned RC inspection and possible tether test under applicable regulations.

## Source of truth locks
- `source/ripple_optical_agent_LOCKED.py` exact copy from v0.3; SHA256 available in manifest. Core constants: [2.0,1.2,-1.4], tau_v .5s, tau_r 5s, refractory .1s, adaptive target 1Hz etc.
- `source/colony_v04.py` new independently testable layer. Neuron scales are logical allocations; concurrency and cognition NOT demonstrated.
- Scanner image pixel brightness is not an optical electric/magnetic field waveform. Laser phase sensing is separate future hardware and not claimed here.
