// Ripple SpiderScan v0.4 accessory manufacturing models. CC0-1.0.
// ONLY non-load-bearing mounting accessories, NOT flight-critical structures.
// Rail OD=10 mm from official Holybro X500 V2 specs; confirm fit with calipers.
// Hole pattern 45mm M3 from official X500 V2 Assembly Guide depth-mount drawing.
// Camera housing 38x38mm from Raspberry Pi Global Shutter camera official specs.
// Printing: PETG initial fit-check; no claim of structural certification.
PART="rail_clamp_base"; // rail_clamp_base, rail_clamp_cap, leg_elbow, camera_tray, assembly
$fn=64;
rail_d=10.0;fit_clearance=0.3;bolt_d=3.5;rod_d=4.0;
// Rail along Y axis. Cap and base are clamped via M3 nuts or captive locknuts.
// Approx 30L x 30W x 13H per half (base and cap).
module rail_clamp_base(){
 difference(){
   union(){cube([30,26,9],center=true);translate([0,0,-5.5])cube([16,26,4],center=true);}
   translate([0,0,4.5])rotate([90,0,0])cylinder(h=28,d=rail_d+fit_clearance,center=true); // circular saddle
   for(x=[-11,11]) translate([x,0,0]) cylinder(h=30,d=bolt_d,center=true);
   // Cosmetic-leg 4.1 mm rod side socket, tilted 25deg downward, centered x axis
   translate([0,0,-7])rotate([0,65,0])cylinder(h=16,d=rod_d+0.25,center=true);
 }
}
module rail_clamp_cap(){
 difference(){
  cube([30,26,9],center=true);
  translate([0,0,-4.5])rotate([90,0,0])cylinder(h=28,d=rail_d+fit_clearance,center=true);
  for(x=[-11,11])translate([x,0,0])cylinder(h=30,d=bolt_d,center=true);
 }
}
// A two-piece cosmetic knee socket: 4mm tubes inserted 11mm into each end.
module leg_elbow(){
 difference(){
   hull(){sphere(d=11);translate([21,0,-13])sphere(d=11);}
   translate([-1,0,0])rotate([0,90,0])cylinder(h=16,d=rod_d+0.25);
   translate([22,0,-13])rotate([0,-120,0])cylinder(h=18,d=rod_d+0.25);
 }
}
// Camera tray: 75x65x4mm, 36mm through-lens bore, 45mm M3 pitch along X
// The 45mm interface is an OPTION for the Holybro universal depth camera mount;
// ensure clearance by trial-fit, do not assume this suits every bracket configuration.
module camera_tray(){
 difference(){
    cube([75,65,4],center=true);
    cylinder(h=9,d=36.5,center=true);
    for(x=[-22.5,22.5]) translate([x,0,0])cylinder(h=9,d=3.4,center=true);
    for(x=[-28,28],y=[-19,19])translate([x,y,0]) cube([3,12,9],center=true);
 }
}
module assembly(){
 color("goldenrod")rail_clamp_base();
 translate([0,0,9])color("steelblue")rail_clamp_cap();
 translate([65,0,0])color("#b1b8bf")leg_elbow();
 translate([0,82,0])color("#cc7744")camera_tray();
}
if(PART=="rail_clamp_base")rail_clamp_base();
else if(PART=="rail_clamp_cap")rail_clamp_cap();
else if(PART=="leg_elbow")leg_elbow();
else if(PART=="camera_tray")camera_tray();
else if(PART=="assembly")assembly();
else assert(false,"invalid part");
