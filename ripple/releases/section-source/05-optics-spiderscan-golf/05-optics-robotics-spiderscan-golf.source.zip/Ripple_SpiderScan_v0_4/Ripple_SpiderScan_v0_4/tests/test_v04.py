import hashlib
from pathlib import Path
import numpy as np,cv2,pytest
from source.colony_v04 import Colony,run_image
from source.engineering_math import motor_model,geometry,camera_geometry
from source.ripple_optical_agent_LOCKED import RippleNeuron
P=Path(__file__).resolve().parents[1]
def test_core_sha_is_unchanged():
    assert hashlib.sha256((P/'source/ripple_optical_agent_LOCKED.py').read_bytes()).digest()==bytes.fromhex('7f2f611cd8f1717c3d3dcae745dbd41efc37e24315d93878231db52eaf614f77')
def test_legacy_weights():
    n=RippleNeuron();r=n.step((.5,1.,.2),.05);assert r['drive']==pytest.approx(1.92)
def test_single_step_bound():
    with pytest.raises(ValueError): RippleNeuron().step((0,0,0),1.)
def test_geometry_real_dimensions():
    assert geometry()['calculated_gap_adjacent_prop_envelopes_mm']==pytest.approx(99.5534,abs=1e-4)
def test_hardware_thrust_lookup():
    assert motor_model(4*628)['hover_throttle_interpolation_pct']==60
    assert motor_model(4*447)['hover_throttle_interpolation_pct']==50
    with pytest.raises(ValueError):motor_model(8000)
def test_pinhole_coverage():
    assert camera_geometry(1.,6.)['ideal_pinhole_ground_sample_distance_mm_per_px']==.575
def test_constant_smooth_stays_min():
    c=Colony();f=np.zeros((160,160,3),np.uint8)
    for _ in range(9):s=c.step(f,.05)
    assert s['active_nodes']==2
    assert s['events']==0
    assert len([x for x in c.lifecycle if x['kind']=='birth'])==2
def test_growth_and_retirement_same_id_maintains_state():
    c=Colony()
    flat=np.full((160,160,3),120,np.uint8)
    noisy=np.random.default_rng(1).integers(0,256,(160,160,3),dtype=np.uint8)
    c.step(flat,.05)
    hold_ids=list(c.active)
    hold_ref={i:id(c.active[i]) for i in hold_ids}
    c.step(noisy,.05);high=c.step(noisy,.05)
    assert high['active_nodes']==16
    assert all(id(c.active[i])==hold_ref[i] for i in hold_ids)
    for _ in range(4):low=c.step(flat,.05)
    assert low['active_nodes']==2
    # earlier nodes may be retired when outside top load; no hidden reassignment
    assert all(x['tile'] in range(16) for x in c.lifecycle)
def test_image_metadata_nonhardware(tmp_path):
    img=P/'reference/archived_photo_NOT_HARDWARE.png'
    s=run_image(img,tmp_path/'s.json')
    assert s['nodes_peak']>=2
    assert s['source_sha256']==hashlib.sha256(img.read_bytes()).hexdigest()
    assert s['no_controls'].startswith('no motors')
def test_invalid_image_and_dt():
    c=Colony()
    with pytest.raises(ValueError):c.step(np.zeros((4,4,3),np.uint8),.05)
    with pytest.raises(ValueError):c.step(np.zeros((80,80,3),np.uint8),1)
def test_stable_ids_ordering():
    c=Colony();f=np.random.default_rng(8).integers(0,256,(160,160,3),dtype=np.uint8)
    a=c.step(f,.05);b=c.step(f,.05)
    assert len(b['tile_ids'])==len(set(b['tile_ids']))
    assert all(0<=x<16 for x in b['tile_ids'])
