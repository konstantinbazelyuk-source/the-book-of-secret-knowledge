#!/usr/bin/env python3
"""Receive-only MAVLink logging from FC UART TX. No MAVLink writes.
Physical wiring: Pixhawk 6C TELEM2 pin2 UART5_TX -> Pi GPIO15 RXD pin10,
TELEM2 pin6 GND -> Pi GND. DO NOT CONNECT TELEM2 VCC pin1 or Pi TX.
Enable telemetry stream on PX4 externally. Configure Pi UART and voltage first.
Hardware UNTESTED. This script cannot arm or move aircraft.
"""
import sys,json,argparse,time
from pathlib import Path

def listen(device:str,baud:int,seconds:float,out:Path):
    try:import serial
    except ImportError as e:raise SystemExit('pyserial required') from e
    try:from pymavlink.dialects.v20 import common as mavlink2
    except ImportError as e:raise SystemExit('pymavlink required') from e
    parser=mavlink2.MAVLink(None) # only decode bytes, no sending
    received=[];end=time.monotonic()+seconds
    with serial.Serial(device,baudrate=baud,timeout=.25) as ser:
        while time.monotonic()<end:
            b=ser.read(8192)
            if not b:continue
            for c in b:
                try:msg=parser.parse_char(bytes([c]))
                except Exception:continue
                if msg is None:continue
                received.append({'time_monotonic_s':round(time.monotonic(),6),
                                 'message':msg.get_type(), 'source_sysid':msg.get_srcSystem()})
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps({'device':device,'baud':baud,'messages':received,
              'output_only_receives':'True; program never sends command frames'},indent=2)+'\n')
    return len(received)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--device',default='/dev/serial0');p.add_argument('--baud',type=int,default=57600)
    p.add_argument('--seconds',type=float,default=10);p.add_argument('--out',type=Path,default=Path('results/mavlink_readonly.json'))
    a=p.parse_args();print('received',listen(a.device,a.baud,a.seconds,a.out),'messages')
