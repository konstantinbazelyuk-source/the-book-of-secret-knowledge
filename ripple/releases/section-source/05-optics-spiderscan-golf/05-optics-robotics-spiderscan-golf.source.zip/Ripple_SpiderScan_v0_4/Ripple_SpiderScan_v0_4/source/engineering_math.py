"""Manufacturer bench data from Holybro X500 2216 KV920 / T1045I chart (16V).
This is NOT flight performance or a wind/aerodynamic structural prediction.
SPDX-License-Identifier: CC0-1.0
"""
import json, math
from pathlib import Path
import numpy as np
MOTOR_TEST=[
 # bench PWM percent, single-motor thrust gram-force, single motor current A
 (30,210,1.44),(35,259,1.87),(40,309,2.29),(45,373,2.86),
 (50,447,3.60),(55,536,4.53),(60,628,5.61),(65,729,6.78),
 (70,814,7.92),(75,906,9.20),(80,993,10.59),(85,1087,12.11),
 (90,1191,13.81),(95,1289,15.68),(100,1332,16.37)]

def motor_model(total_mass_g):
    """linear interpolation ONLY between published points; no extrapolation"""
    t=total_mass_g/4
    thrust=np.array([r[1] for r in MOTOR_TEST])
    if not thrust[0]<=t<=thrust[-1]:raise ValueError('mass outside chart tested thrust range')
    pct=float(np.interp(t,thrust,[r[0] for r in MOTOR_TEST]))
    current=float(np.interp(t,thrust,[r[2] for r in MOTOR_TEST]))
    return {'all_up_mass_g':total_mass_g,'hover_throttle_interpolation_pct':round(pct,2),
            'per_motor_static_thrust_gf':round(t,1), 'estimated_4motor_current_A':round(current*4,2),
            'static_100pct_total_thrust_gf':5328,
            'static_100pct_thrust_to_weight':round(5328/total_mass_g,3),
            'limitations':'16V manufacturer static bench chart; NOT airborne performance prediction'}

def camera_geometry(height_m, lens_focal_mm=6.0):
    # sensor physical pixel pitch 3.45 micrometers, product max 1456 x 1088
    if height_m<=0 or lens_focal_mm<=0:raise ValueError('positive distance and focal length needed')
    gsd_mm=height_m*1000*.00345/lens_focal_mm
    return {'height_m':height_m,'assumed_focal_mm':lens_focal_mm,
            'ideal_pinhole_ground_sample_distance_mm_per_px':round(gsd_mm,6),
            'ideal_coverage_w_m':round(1456*gsd_mm/1000,4),
            'ideal_coverage_h_m':round(1088*gsd_mm/1000,4),
            'limitations':'Lens not calibrated. Coverage assumed nadir over plane, no perspective distortion, focus or resolution guarantee.'}

def geometry():
    motor_coordinate=500/(2*math.sqrt(2))
    adjacent=500/math.sqrt(2)
    gap=adjacent-254
    return {'wheelbase_diagonal_motor_mm':500,
        'motor_xy_absolute_mm':round(motor_coordinate,4),
        'adjacent_motor_mm':round(adjacent,4),
        'prop_diameter_mm':254,'calculated_gap_adjacent_prop_envelopes_mm':round(gap,4),
        'height_stock_landing_gear_mm':215,
        'accessory_rail_outer_diameter_mm':10,
        'source':'Holybro manufacturer mechanical specification, not full-airframe CAD collision analysis'}

if __name__=='__main__':
    out={'geometry':geometry(),'cases':[motor_model(x) for x in [1600,1800,2000,2200,2400]],
         'camera':camera_geometry(1.0)}
    Path('results').mkdir(exist_ok=True)
    Path('results/calculated_hardware_budgets.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))
