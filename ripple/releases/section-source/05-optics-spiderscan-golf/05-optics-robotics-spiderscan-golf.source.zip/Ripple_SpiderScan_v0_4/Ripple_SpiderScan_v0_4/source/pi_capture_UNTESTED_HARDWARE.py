#!/usr/bin/env python3
"""Real input acquisition path for Raspberry Pi GS camera via Picamera2.
Hardware execution is UNTESTED here. Saves photo+SHA256+source metadata.
No control of drone, servo, or printer. Run on Raspberry Pi OS with camera attached.
"""
from pathlib import Path
import hashlib,json,time,argparse

def capture(destination:Path):
    try:from picamera2 import Picamera2
    except ImportError as e:raise SystemExit('Install Raspberry Pi OS Picamera2 system package; no hardware test performed here') from e
    destination.parent.mkdir(parents=True,exist_ok=True)
    camera=Picamera2()
    camera.configure(camera.create_still_configuration(main={'size':(1456,1088)}))
    try:
        camera.start();time.sleep(2.0)
        captured=time.time()
        camera.capture_file(str(destination))
    finally:camera.stop();camera.close()
    meta={'source_type':'PHYSICAL_CAMERA_CAPTURE - verify manufacturer and lens/capture setup',
          'file':str(destination),'capture_unix_timestamp':captured,
          'sha256':hashlib.sha256(destination.read_bytes()).hexdigest(),
          'warning':'No lens calibration, exposure locking, timestamp-to-pose sync, or radiometry established.'}
    destination.with_suffix('.json').write_text(json.dumps(meta,indent=2)+'\n')
    return meta

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('output',type=Path)
    a=p.parse_args();print(json.dumps(capture(a.output),indent=2))
