from reportlab.pdfgen import canvas
from pathlib import Path
from reportlab.lib.units import mm
B=Path(__file__).resolve().parent
p=B/'docs/CALIBRATION_MARKS_100mm_ACTUAL_SIZE.pdf'
c=canvas.Canvas(str(p),pagesize=(210*mm,297*mm));c.setTitle('Ripple GroundScan 100mm optical calibration marks')
c.setFont('Helvetica-Bold',15);c.drawCentredString(105*mm,272*mm,'RIPPLE SCAN GROUND / 100mm MARK CALIBRATION')
c.setFont('Helvetica',9);c.drawCentredString(105*mm,264*mm,'PRINT AT 100% / NO FIT-TO-PAGE. PHYSICALLY MEASURE THE DISTANCE.')
x0,y=55*mm,150*mm;x1=155*mm
c.setFillColorRGB(.03,.06,.07)
for x in (x0,x1):c.circle(x,y,3*mm,stroke=0,fill=1)
c.setStrokeColorRGB(.25,.35,.38);c.setDash(2,3);c.line(x0,y+6*mm,x1,y+6*mm);c.setDash()
c.setFont('Helvetica-Bold',11);c.drawCentredString(105*mm,y+11*mm,'100 mm nominal between circle centers')
c.setFont('Helvetica',9);c.drawCentredString(105*mm,y-15*mm,'Input your independently measured center spacing; do not assume printer scale.')
# 50-mm additional check gauge
c.line(65*mm,95*mm,115*mm,95*mm)
for x in (65*mm,115*mm):c.line(x,92*mm,x,98*mm)
c.setFont('Helvetica-Bold',9);c.drawCentredString(90*mm,101*mm,'50 mm print-size verification bar')
c.setFont('Helvetica',9);c.drawString(23*mm,75*mm,'Ground scan requires a flat stationary reference plane and lens calibration.')
c.drawString(23*mm,69*mm,'FBI photo practice: include scale; controlled angled illumination can improve detail.')
c.drawString(23*mm,63*mm,'This test chart is NOT a forensic-certified reference or a true 3D depth calibration.')
c.save();print(p)
