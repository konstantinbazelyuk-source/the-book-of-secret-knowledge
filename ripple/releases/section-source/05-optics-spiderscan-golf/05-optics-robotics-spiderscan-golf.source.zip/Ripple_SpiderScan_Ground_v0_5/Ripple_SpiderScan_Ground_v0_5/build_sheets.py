from pathlib import Path
import json,math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Circle,Polygon,FancyArrowPatch,Arc
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,Image,PageBreak,KeepTogether
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.units import mm
B=Path(__file__).resolve().parent
b=json.loads((B/'results/benchmark.json').read_text())
# Schematic, not scaled Octobot CAD.
fig,ax=plt.subplots(figsize=(11.7,6.1));ax.set_xlim(-6,18);ax.set_ylim(-2,11);ax.axis('off')
def box(x,y,w,h,t,fc='#eaf2f3',fontsize=10):
 ax.add_patch(Rectangle((x,y),w,h,linewidth=1.6,edgecolor='#1b4151',facecolor=fc,zorder=2))
 ax.text(x+w/2,y+h/2,t,ha='center',va='center',fontsize=fontsize,zorder=3)
def arrow(a,b):
 ax.annotate('',xy=b,xytext=a,arrowprops={'arrowstyle':'-|>','lw':1.8,'color':'#2e6476'},zorder=1)
box(-5,8,5.2,1.9,'Raspberry Pi 4 / 5\nRecorder + Ripple Colony')
box(2.0,8,5.2,1.9,'CSI: Pi Global Shutter\nCamera + fixed lens')
box(9,8,7.8,1.9,'Ground scan: RGB + image texture\nExposure advisor / spatial tile neurons')
arrow((.2,8.95),(2,8.95));arrow((7.2,8.95),(9,8.95))
box(2.0,4.6,5.2,2.1,'I2C mux TCA9548A\n0x70, 3.3 V logic',fc='#fff4de')
box(9,5.7,7.8,1.2,'VL53L1X #1: forward range [mux 0]')
box(9,3.8,7.8,1.2,'VL53L1X #2: down range [mux 1]')
arrow((.1,8.0),(2.3,6.7));arrow((7.2,5.4),(9,6.3));arrow((7.2,5.2),(9,4.4))
box(-5,4.6,5.2,2.1,'Independent safety evaluator\nNO motor permission outputs',fc='#ffe9e7')
arrow((9,4.1),(-.0,5.5));arrow((9,6.0),(-.0,5.8))
box(-5,.8,5.2,2.2,'Octobot separate MCU\n24 actuated joints: 8 x 3DOF',fc='#ecf4e9')
box(2,.8,5.2,2.2,'Split servo supply / fuses\nReal hardware E-stop',fc='#ecf4e9')
box(9,.8,7.8,2.2,'Authoritative locomotion\nfirmware & kinematics\nNOT implemented by Ripple',fc='#ecf4e9')
arrow((7.2,1.9),(9,1.9));arrow((2,1.9),(.2,1.9))
ax.text(-5,10.7,'Ripple GroundScan v0.5 — measured data path vs independent actuator control',fontweight='bold',fontsize=14)
fig.tight_layout();fig.savefig(B/'design/electronic_sensor_system.png',dpi=170);plt.close(fig)

# Top schematic over unverified octobot leg joints; sensor plate exact dimensions from generated model.
fig,(ax1,ax2)=plt.subplots(1,2,figsize=(12,6.3))
for ax in (ax1,ax2):ax.set_aspect('equal');ax.axis('off')
ax1.set_xlim(-260,260);ax1.set_ylim(-230,260)
ax1.add_patch(Rectangle((-80,-60),160,120,color='#d5e7ed',ec='#183c4b',lw=1.5))
for i in range(8):
 a=2*math.pi*i/8+math.pi/8
 p=(65*math.cos(a),49*math.sin(a));q=(120*math.cos(a),100*math.sin(a))
 r=(185*math.cos(a+.08),165*math.sin(a+.08))
 ax1.plot([p[0],q[0],r[0]],[p[1],q[1],r[1]],lw=7,color='#4e8292',solid_capstyle='round')
 for z in (p,q):ax1.add_patch(Circle(z,8,fc='#f6be73',ec='black',lw=1))
 ax1.text(208*math.cos(a),192*math.sin(a),f'L{i+1}',ha='center',fontsize=9)
ax1.add_patch(Rectangle((-56,-43),112,86,fc='#fff9e7',ec='#95672d',lw=1.5))
ax1.add_patch(Circle((0,0),20.5,fc='white',ec='#ae6c0b',lw=1.4))
ax1.text(0,-15,'optics',ha='center',va='center',fontsize=9)
ax1.annotate('',xy=(-56,70),xytext=(56,70),arrowprops=dict(arrowstyle='<->'))
ax1.text(0,76,'112 mm tray - actual generated geometry',ha='center',fontsize=9)
ax1.set_title('Eight-actuator-leg topology: schematic ONLY\nOuter footprint NOT dimensioned to upstream Octobot CAD')
ax2.set_xlim(-85,220);ax2.set_ylim(-180,110)
ax2.add_patch(Rectangle((-56,0),112,4,fc='#fff9e7',ec='#95672d'))
ax2.add_patch(Rectangle((-19,-22),38,22,fc='#8fc1cf',ec='#183c4b'))
ax2.text(0,-31,'38 x 38 mm GS camera board, nominal',ha='center',fontsize=8)
ax2.plot([0,-50],[0,-120],ls='--',color='#2a8d72');ax2.plot([0,50],[0,-120],ls='--',color='#2a8d72')
ax2.plot([-55,55],[-120,-120],color='#5f6c62',lw=3);ax2.text(0,-140,'GROUND  |  standoff 120 mm assumed',ha='center')
ax2.plot([0,0],[-30,-120],ls=':',color='#8c6c21')
ax2.annotate('',xy=(90,-120),xytext=(90,0),arrowprops=dict(arrowstyle='<->'))
ax2.text(97,-65,'120 mm assumption',rotation=90,va='center',fontsize=9)
ax2.text(0,61,'ToF 27° full FoV at 120 mm:\nfootprint ≈ 57.6 mm\n(camera FoV depends on purchased lens)',ha='center',fontsize=10)
ax2.set_title('Optical measurement geometry — assumptions, not physical calibration')
fig.tight_layout();fig.savefig(B/'design/top_and_optical_assembly.png',dpi=165);plt.close(fig)

# Report PDF 3 pages
sty=getSampleStyleSheet();sty.add(ParagraphStyle(name='Hdr',fontName='Helvetica-Bold',fontSize=20,textColor=colors.HexColor('#163c4a'),spaceAfter=13))
sty.add(ParagraphStyle(name='Minor',fontName='Helvetica-Bold',fontSize=11.5,textColor=colors.HexColor('#175b73'),spaceAfter=7))
sty.add(ParagraphStyle(name='Body2',fontSize=9.3,leading=14,spaceAfter=7))
sty.add(ParagraphStyle(name='Tiny',fontSize=7.6,leading=10))
doc=SimpleDocTemplate(str(B/'docs/Ripple_Ground_Engineering_Sheets.pdf'),pagesize=(210*mm,297*mm),leftMargin=17*mm,rightMargin=17*mm,topMargin=18*mm,bottomMargin=16*mm)
def P(t,style='Body2'):return Paragraph(t,sty[style])
def img(path,w=170*mm):
 from PIL import Image as PIL
 im=PIL.open(path);return Image(str(path),width=w,height=w*im.height/im.width)
story=[P('RIPPLE SPIDERSCAN / GROUND v0.5','Hdr'),P('Open engineering - real sensor interfaces, original neuron preserved, no robot fabricated','Minor'),P('This report distinguishes manufacturer-published specifications, calculated geometry, executed software tests, synthetic fixtures, and proposed hardware assembly. The source code does not command robot motors.')]
story.append(img(B/'design/electronic_sensor_system.png',174*mm));story.extend([Spacer(1,6*mm),P('Physical architecture','Minor')])
for txt in ['Locomotion: eight legs and 24 servos from independent open-source Octobot published STEP / KiCad / IK files. No claim that a drone frame with passive legs can walk.',
'Optics: Raspberry Pi Global Shutter Camera (1456x1088, Sony IMX296). Its manufactured lens mount is C/CS; the proposed tray uses only 112 x 86 mm removable fit-check geometry.',
'Ranging: two VL53L1X time-of-flight modules behind one TCA9548A multiplexer; distinct channels 0 and 1 prevent same-address I2C conflict. Forward module observes obstructions; down module checks chassis clearance.',
'Safety: independent hardware E-stop is required before any powered movement. The delivered Python range gate returns suggestions and NEVER has authority over servo outputs.']:
 story.append(P('&#8226; '+txt))
story.append(PageBreak())
story.extend([P('DIMENSIONS & LIMITS','Hdr'),img(B/'design/top_and_optical_assembly.png',173*mm),Spacer(1,3*mm)])
rows=[['Variable / formula','Value / evidence'],['Tray envelope, CAD','112 x 86 mm, 4 mm plate; FIT-CHECK only'],['Global-shutter camera PCB','38 x 38 mm, manufacturer published'],['ToF maximum design range','up to 4000 mm, manufacturer claim (conditions apply)'],['Typical ToF full angle','27 degrees, ST VL53L1X'],['Footprint at z=120 mm','2 * 120 * tan(13.5 deg) = 57.6 mm CALCULATED'],['4 stance legs and M=2.5 kg','F per support ~ M*g/4 = 6.13 N ASSUMED'],['Lever r=80 mm','T ~ 0.490 Nm = 5.0 kgf-cm ASSUMED'],['Design torque margin x3','~15 kgf-cm initial estimate, NOT servo selection']]
t=Table(rows,colWidths=[75*mm,98*mm],repeatRows=1);t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e3eff0')),('FONTSIZE',(0,0),(-1,-1),8),('BOTTOMPADDING',(0,0),(-1,-1),6),('LINEBELOW',(0,0),(-1,-1),.3,colors.HexColor('#cbd7dc')),('VALIGN',(0,0),(-1,-1),'TOP')]))
story.append(t);story.append(Spacer(1,3*mm));story.append(P('Torque is not qualified because joint geometry, gait dynamics, worst-case gravity moments, motor current and assembled mass have not been measured. No servo order should be derived solely from this estimate.','Tiny'))
story.append(PageBreak());story.extend([P('TEST RESULTS & SKILL PERCENTAGES','Hdr'),img(B/'design/empirical_skill_percentages.png',173*mm)])
for lab,key in [('Find two circular calibration marks','ground_fixture_detection'),('Reject incomplete calibration charts','invalid_fixture_rejection'),('Distance-gate fixture classification','range_gate_fixture_policy')]:
 val=b[key];story.append(P(f"<b>{lab}</b>: {val['passes']} / {val['attempts']} trials = {val['success_pct']:.1f}% (Wilson 95% interval {val['wilson_95_pct'][0]:.1f} - {val['wilson_95_pct'][1]:.1f}%)."))
story.append(P('All fixtures in this performance graph were created by software. This is an executed algorithmic accuracy score, NOT a measured robot success rate, learned skill, or universal accuracy guarantee.','Tiny'))
story.append(img(B/'design/software_and_colony_benchmark.png',170*mm))
story.append(P('Median processing times were measured in this execution environment using 512x512 real-world photo pixels replayed as test input. They are not Raspberry Pi hardware measurements, do not include camera capture, and do not show parallel speedup.','Tiny'))
story.append(PageBreak())
story.extend([P('GROUND ROUTE & ASSEMBLY GATES','Hdr'),img(B/'design/scan_route_and_digital_mosaic.png',173*mm)])
story.append(P('The route at left is calculated for a 300 x 200 mm target at an assumed 100 x 75 mm camera footprint with 30% overlap: 16 capture positions. The image at right is a reconstruction from crops of an archived photograph placed at known software-defined poses. It is NOT evidence that an octopod has travelled or scanned the ground.'))
story.append(P('Computing capacity and physical validation','Minor'))
for txt in ['Sensor output: the manufacturer reports a 1456 x 1088 24-bit image, equal to 4,752,384 byte (~4.53 MiB) per frame in a contiguous 3-channel array. Processing may require multiple copies.',
'Current 2 million pixel mosaic guard requires at least 62 MB for accumulation + counts + output buffers (28+3 bytes/pixel), apart from input images, allocations and operating system. Actual device peak RAM must be benchmarked.',
'External pose (odometry, fiducials or motion capture) and lens calibration are mandatory for accurate spatial maps. Eight walking legs and a 2-point laser ranging setup do not supply room-scale localization.',
'Motor commands and servo rail are deliberately isolated from Ripple. Real walker power, emergency-stop wiring, contact forces, total weight and stair/edge safety require independent testing.',
'Roomba comparison: Ripple has no motorized vacuum, brush or mop and has NOT been shown superior at cleaning. Compare imaging/traversability later on controlled courses under equal conditions.']:
 story.append(P('&#8226; '+txt))
story.append(P('All real sensor and actuator validation gates remain UNTESTED until instrumented hardware becomes available.','Tiny'))
doc.build(story)
print('created PDF',B/'docs/Ripple_Ground_Engineering_Sheets.pdf')
