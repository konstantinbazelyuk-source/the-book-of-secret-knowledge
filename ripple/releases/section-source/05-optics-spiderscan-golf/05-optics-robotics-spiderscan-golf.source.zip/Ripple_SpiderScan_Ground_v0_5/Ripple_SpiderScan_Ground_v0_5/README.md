# RIPPLE SPIDERSCAN GROUND v0.5

**Ground inspection octopod + Raspberry Pi GS camera + 2 ToF ranging sensors + Ripple Neuron Colony.**

**Evidence state: 23 passing tests, 3 watertight STL fit-check exports, 40+10 synthetic marker fixtures, 12 synthetic ToF scenarios, physical sensor trials: ZERO, locomotion trials: ZERO.** This is executable software and a manufacturable accessory *prototype*, not a finished ground robot or a Roomba-beating vacuum.

## What's changed since the approved v0.4 aircraft
- Aircraft stays untouched; original Ripple neuron source copied byte-for-byte in `legacy/`.
- Functional legs are based on the **published independent Octobot eight-legged 24-servo mechanism** (a real open-source third-party design). Not a retrofitted flying frame and **not** copied into this distribution.
- Camera/sensor stack is new: read-only `src/hardware_pi_READONLY.py` (CSI + two VL53L1X sensors over TCA9548A), `src/physical_capture_UNTESTED.py` (PNG + JSON one shot), `src/scan_quality.py`, `src/adaptive_capture.py`, `src/safety.py` and `src/ground_colony.py`.
- Colonies have stable image tile IDs; 2/4/8/16 logical instances tested, **not CPU parallelization** or trained cognition.
- `src/ground_mosaic.py`: stop-and-scan serpentine path and mosaic reconstruction when input frames have independently measured positions. A software-crop mosaic passed exactly; NO real localization, walking scan, or floor travel.
- Print `docs/CALIBRATION_MARKS_100mm_ACTUAL_SIZE.pdf` without scaling and physically measure center distance before using mm/pixel.

## Quick start (any computer with Python)
```
python -m pip install -r requirements.txt
python -m pytest -q tests
python benchmark.py
python demo_route.py
python -m src.groundscan_cli \
  --image fixtures/archived_photo_NOT_HARDWARE.png \
  --out results/user_software_scan.json
```
The archived photograph contains real pixels from a historical photograph, but **was not captured by this device**.

## Physical camera capture (only with Pi and hardware, not yet tested)
```
# install actual compatible Pi camera and sensor libraries first:
python -m src.physical_capture_UNTESTED --out-dir captures/bench001
```
See [`docs/ENGINEERING_ACCEPTANCE.md`](docs/ENGINEERING_ACCEPTANCE.md) for wiring, readiness gates and hazards.

## Materials and fabrication
- `docs/BOM_SOURCING.csv`: hardware references, required quantities, unverified items and purchase hold points; no manufacturer has received an order.
- `cad/scanner_head_FITCHECK.scad`: editable source and three watertight STL parts; print one to check fit before production.
- `docs/MANUFACTURER_RFQ.txt`: ready for an actual supplier quotation; omit unmeasured geometry from final fabrication order.
- `docs/Ripple_Ground_Engineering_Sheets.pdf`: schematics, dimensions, torque bounds, empirical software test results.
- `docs/SOURCES.md`: official primary specifications, Github robotics projects and FBI forensic imaging guidance (no unverified 'fbi.com' material).

## Disclosure
All original adapter code and drawings in this package may be freely reused (CC0-1.0), except incorporated prior code and assets retain their original respective attribution and licensing obligations. No Octobot mechanical design, firmware, or manufacturer files are represented as this project's original work; obtain upstream files from their MIT licensed project and check current revision.
