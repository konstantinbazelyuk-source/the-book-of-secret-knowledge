"""Bench measurements with fixed seeded synthetic targets; not hardware validation."""
from __future__ import annotations
import json, random, math, time, tracemalloc, csv, hashlib
from pathlib import Path
import cv2,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from src.scan_quality import marker_calibrate,image_quality
from src.skill_metrics import SkillMeter
from src.safety import GroundGate,Ranges
from src.ground_colony import GroundColony
B=Path(__file__).resolve().parent
D=B/'results';D.mkdir(exist_ok=True)
rng=random.Random(71249)
# Ground truth is INTENTIONALLY generated in software; independent of detector output.
cal=SkillMeter();reject=SkillMeter();cal_rows=[]
for i in range(40):
    sep=rng.randrange(250,521)
    y=150+rng.randint(-15,15)
    xx=140+rng.randint(-20,20)
    image=np.full((320,800,3),235,np.uint8)
    cv2.circle(image,(xx,y),13,(15,15,15),-1,cv2.LINE_AA)
    cv2.circle(image,(xx+sep,y),13,(15,15,15),-1,cv2.LINE_AA)
    noise=rng.randrange(0,4)
    if noise:
        gaussian=np.random.default_rng(i).normal(0,noise,image.shape)
        image=np.clip(image.astype(np.float32)+gaussian,0,255).astype(np.uint8)
    c=marker_calibrate(image,100.)
    err=abs(c.pixels_between_marks-sep)
    ok=(err<=1.0)
    cal.observe(ok)
    cal_rows.append({'case':i,'true_spacing_px_generated':sep,'detected_spacing_px':round(c.pixels_between_marks,5),'error_px':round(err,6),'passes_1px':ok})
for i in range(10):
    a=np.full((320,800,3),235,np.uint8)
    if i%2==0:cv2.circle(a,(240,160),13,(15,15,15),-1)
    try:marker_calibrate(a,100);ok=False
    except ValueError:ok=True
    reject.observe(ok)
# Assessed policy decisions against declared fixture expectations, *not measured physical obstacle events*.
conditions=[(700,110,'OBSERVE_ONLY'),(350,110,'OBSERVE_ONLY'),(349,110,'STOP'),(700,49,'STOP'),
 (700,221,'STOP'),(700,float('nan'),'STOP'),(None,110,'STOP'),(700,None,'STOP'),
 (700,100,'OBSERVE_ONLY'),(700,130,'OBSERVE_ONLY'),(200,100,'STOP'),(700,200,'OBSERVE_ONLY')]
safety=SkillMeter();safety_cases=[]
for i,(f,g,expected) in enumerate(conditions):
    actual=GroundGate().evaluate(Ranges(f,g,20.,'fixture'),20.)['motion_recommendation']
    safety.observe(actual==expected)
    safety_cases.append({'case':i,'forward_mm_fixture':f,'ground_mm_fixture':g if g is None or math.isfinite(g) else 'NaN_INVALID_FIXTURE','expected':expected,'actual':actual})
# Separate stateful drop test
sg=GroundGate(ground_max_mm=300);sg.evaluate(Ranges(800,100,0.,'fixture'),0.)
stateful=sg.evaluate(Ranges(800,185,.1,'fixture'),.1)
# Actual pixels of third-party archived photography, replayed with synthetic timing.
source=B/'fixtures/archived_photo_NOT_HARDWARE.png'
frame=cv2.imread(str(source))
counts={};perf={}
for k in (2,4,8,16):
    c=GroundColony(capacity=k)
    for _ in range(2):c.process(frame,.05)
    tracemalloc.start();ts=[]
    for _ in range(30):
        t=time.perf_counter_ns();z=c.process(frame,.05);ts.append((time.perf_counter_ns()-t)/1e6)
    mem=tracemalloc.get_traced_memory()[1];tracemalloc.stop()
    perf[k]={'median_ms':round(float(np.median(ts)),3), 'p95_ms':round(float(np.percentile(ts,95)),3),
             'peak_tracemalloc_bytes':int(mem),'events_in_30_replays':sum(v['count'] for v in z['tiles'])}
# Chart 1 scan geometry and spatial tiles
fig,axs=plt.subplots(1,2,figsize=(11,4.7))
rgb=cv2.cvtColor(frame,cv2.COLOR_BGR2RGB)
axs[0].imshow(rgb);axs[0].set_title('Archived real-world photograph (not sensor capture)')
h,w=frame.shape[:2]
for x in range(1,4):axs[0].axvline(x*w/4,linewidth=.8)
for y in range(1,4):axs[0].axhline(y*h/4,linewidth=.8)
axs[0].axis('off')
xs=list(perf);ys=[perf[x]['median_ms'] for x in xs]
axs[1].plot(xs,ys,marker='o');axs[1].set_xticks(xs)
axs[1].set_xlabel('logical Ripple neuron instances');axs[1].set_ylabel('median CPU execution time (ms)')
axs[1].set_title('Software benchmark, this execution environment');axs[1].grid(alpha=.25)
fig.tight_layout();fig.savefig(B/'design/software_and_colony_benchmark.png',dpi=160);plt.close(fig)
# Chart 2 adaptive score with uncertainty
fig,ax=plt.subplots(figsize=(8.5,4.1))
labels=['Mark recognition','Reject invalid target','Safety fixture decisions']
meters=[cal,reject,safety]
results=[m.result() for m in meters]
for i,r in enumerate(results):
    ax.errorbar(i,r['success_pct'],yerr=[[max(0,r['success_pct']-r['wilson_95_pct'][0])],[max(0,r['wilson_95_pct'][1]-r['success_pct'])]],fmt='o',capsize=5)
    ax.annotate(f"{r['passes']}/{r['attempts']}",(i,r['success_pct']),xytext=(0,8),textcoords='offset points',ha='center')
ax.set_xticks(range(len(labels)),labels);ax.set_ylim(0,110);ax.set_ylabel('Observed success rate (%)');ax.grid(axis='y',alpha=.3)
ax.set_title('Synthetic-fixture test percentages and Wilson 95% intervals')
fig.tight_layout();fig.savefig(B/'design/empirical_skill_percentages.png',dpi=170);plt.close(fig)
# data sources and study limits
out={'status':'EXECUTED SOFTWARE BENCHMARK; fabricated input target geometry; no real robot/sensors',
     'ground_fixture_detection':cal.result(), 'invalid_fixture_rejection':reject.result(),
     'range_gate_fixture_policy':safety.result(),'stateful_drop_test':stateful,
     'benchmark_colony_by_capacity':perf,
     'archived_image_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
     'mean_detection_error_px':sum(r['error_px'] for r in cal_rows)/len(cal_rows),
     'image_dimensions_px':[w,h],
     'actual_ground_sensor_samples':0, 'actual_robot_motion_tests':0,
     'limitations':'Target positions and ToF values generated in code. No independent hardware accuracy claims. Performance on this host not Raspberry Pi.'}
(D/'benchmark.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
with (D/'synthetic_target_cases.csv').open('w',newline='') as fh:
  wr=csv.DictWriter(fh,fieldnames=list(cal_rows[0]));wr.writeheader();wr.writerows(cal_rows)
(D/'safety_fixture_cases.json').write_text(json.dumps(safety_cases,indent=2,allow_nan=False)+'\n')
print(json.dumps(out,indent=2,allow_nan=False))
