"""Route and mosaic demo on known digital pixel crops; absolutely NOT actual robot measurements."""
import json, math
from pathlib import Path
import numpy as np
import cv2
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from src.ground_mosaic import ScanPose,compose_known_pose,serpentine_plan
B=Path(__file__).resolve().parent
# Pixel crop ground truth; photo is an archived portrait not a ground scan!
p=cv2.imread(str(B/'fixtures/archived_photo_NOT_HARDWARE.png'))
h,w=p.shape[:2]
patch=256
coords=[(0,0),(128,0),(256,0),(256,128),(128,128),(0,128),(0,256),(128,256),(256,256)]
mm_per_px=.2 # software-generated known-pose FIxture, not measured calibration
frames=[]
for i,(x,y) in enumerate(coords):
    frames.append((p[y:y+patch,x:x+patch],ScanPose(x*mm_per_px,y*mm_per_px,f'fixture_{i}')))
mos,cover=compose_known_pose(frames,mm_per_px,w*mm_per_px,h*mm_per_px)
assert cover.all()
max_err=int(np.max(np.abs(mos.astype(np.int16)-p.astype(np.int16))))
mae=float(np.mean(np.abs(mos.astype(np.int16)-p.astype(np.int16))))
route=serpentine_plan(300,200,100,75,.30)
plt.rcParams.update({'font.size':9})
fig,axs=plt.subplots(1,2,figsize=(11.8,5.2))
axs[0].set_xlim(-10,315);axs[0].set_ylim(210,-10);axs[0].set_aspect('equal');axs[0].grid(alpha=.2)
for i,step in enumerate(route.waypoints):
    from matplotlib.patches import Rectangle
    axs[0].add_patch(Rectangle((step.x_mm,step.y_mm),100,75,fill=False,edgecolor='#4b9a8e',alpha=.35,linewidth=1))
    axs[0].plot(step.x_mm+50,step.y_mm+37.5,'.',color='#bd6b42',markersize=3)
xs=[s.x_mm+50 for s in route.waypoints]
ys=[s.y_mm+37.5 for s in route.waypoints]
axs[0].plot(xs,ys,'--',linewidth=1,color='#926340')
axs[0].set_title('PROPOSED ground route: 300 x 200 mm, 30% overlap')
axs[0].set_xlabel('x (mm, planned)');axs[0].set_ylabel('y (mm, planned)')
axs[1].imshow(cv2.cvtColor(mos,cv2.COLOR_BGR2RGB))
axs[1].set_title(f'DIGITAL CROP RECONSTRUCTION: MAE={mae:.5f} / 255')
axs[1].axis('off')
fig.tight_layout();fig.savefig(B/'design/scan_route_and_digital_mosaic.png',dpi=165);plt.close(fig)
summary={'classification':'CALCULATED route and DIGITAL CROP experiment; zero physical robot scanning',
         'route_target_mm':[300,200],'assumed_camera_footprint_mm':[100,75],
         'overlap_fraction':route.overlap_fraction,'planned_stops':len(route.waypoints),
         'planned_waypoints':[vars(x) for x in route.waypoints],
         'mosaic_input':'archived unrelated real photograph, digitally cropped in software',
         'mosaic_coverage_fraction':float(cover.mean()),
         'mosaic_max_error_8bit':max_err,'mosaic_mean_absolute_error_8bit':mae,
         'pose_origin':'software generated from known integer pixel cropping; NOT SLAM or measured robot pose'}
(B/'results/route_and_mosaic.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='planned_waypoints'},indent=2))
