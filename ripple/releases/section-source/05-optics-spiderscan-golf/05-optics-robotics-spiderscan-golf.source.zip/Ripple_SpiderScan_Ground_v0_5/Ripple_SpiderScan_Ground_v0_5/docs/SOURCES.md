# Source register / verified published, not independently reproduced
- Eight-legged true robotic mechanism, 24 servo drivers, STEP, KiCad, BOM: https://github.com/Deivid-Negoita/octobot (MIT licensed upstream; this project refers to, does not claim authorship or fabricate its assembly).
- Established 4-legged alternative (12 servos, ArduPilot Rover; not octopod-compatible out of the box): https://en.ardupilot.org/rover/docs/walking-robots.html
- Global shutter IMX296 camera product and mechanics: https://www.raspberrypi.com/products/raspberry-pi-global-shutter-camera/ and https://pip-assets.raspberrypi.com/categories/810-raspberry-pi-global-shutter-camera/documents/RP-008195-DS-1-gs-camera-mechanical-drawing.pdf
- Raspberry Pi Picamera2 and external shutter triggers: https://www.raspberrypi.com/documentation/accessories/camera.html
- VL53L1X official spec: https://www.st.com/en/imaging-and-photonics-solutions/time-of-flight-sensors/vl53l1x.html
- Pi-supported VL53L1X code: https://learn.adafruit.com/adafruit-vl53l1x/python-circuitpython
- Same-address I2C mux on Pi: https://learn.adafruit.com/adafruit-tca9548a-1-to-8-i2c-multiplexer-breakout/circuitpython-python
- Nav2 collision monitor fail-safe inspiration, NOT certification: https://github.com/ros-navigation/navigation2/blob/main/nav2_collision_monitor/README.md
- FBI Laboratory 2019 Handbook of Forensic Services (footwear imaging; control scaling, illumination, lossless imaging): https://www.fbi.gov/file-repository/handbook-of-forensic-services-pdf.pdf
- FBI 1984 footprint photography oblique multiple angle lighting + ruler: https://leb.fbi.gov/file-repository/archives/july-1984.pdf
- Roomba Combo j9+ abilities used only as comparison baseline: https://www.irobot.com/en_US/roomba-combo-j9plus-robot-plus-autoempty-dock/C955020.html

`fbi.com` was not treated as a trustworthy engineering source; official `fbi.gov` documents are for *imaging practice*, not robotic actuation or AI algorithms.
