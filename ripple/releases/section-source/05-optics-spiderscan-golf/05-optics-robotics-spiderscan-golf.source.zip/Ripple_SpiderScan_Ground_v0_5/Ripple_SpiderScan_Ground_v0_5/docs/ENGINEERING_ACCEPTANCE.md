# Ripple SpiderScan Ground v0.5 — build and acceptance gates

## Classification and current baseline
- **Preserved**: Ripple Neuron v0.1/v0.4 original constants and neuron implementation; byte-identical file in `legacy/ripple_optical_agent_LOCKED.py`.
- **New software**: known-pose floor mosaic and calculated coverage waypoints, physical camera / ToF read adapter, persistent per-tile colony, image quality, circular-marker plane calibration, optional exposure advisor, read-only stop gate, empirical skill-meter (Wilson interval), CLI, tests.
- **Published** (not built here): actual eight-legged Octobot mechanism, 24 servo system, KiCad hardware, STEP CAD, third-party gait IK playground. Separate X500 aerial v0.4 remains intact.
- **Validated in container**: pytest, digital image pixel operations, synthetic fixtures, OpenSCAD STL manifold checks.
- **Still unvalidated**: all real sensor buses, actual Pi camera, real motor driver, leg structure, foot placement, actuated locomotion, surface measurement quality, power endurance, safety under motion, Roomba superiority.

## Compatibility and geometry rules
- Original X500 aircraft v0.4 has decorative nonload-bearing spider legs. This ground branch does NOT make that airframe walk; *independent* eight-legged mechanism is used.
- Octobot chassis STEP is the authority for leg geometry. **Do not cut/drill Octobot body using the schematic drawing in this package**; obtain current STEP, measure exact mounts, then replace the slotted fit-check plate and verify knee sweep/no collision.
- The generated tray is **112 × 86 × 4 mm** (with local rails extending +6 mm). `head_FITCHECK.stl` is the geometry of the removable plate, not a structurally tested component.
- Raspberry Pi GS camera nominal 38×38 mm board; lens mount clearance and actual mass/height must be measured with selected lens. Printed optical aperture is 41 mm and may need resizing.
- Camera scans a roughly planar, lit region beneath a robot paused on legs; no field mapping or cliff-proof autonomous navigation is inferred from *one* downward ToF.

## Wiring / sensor data
```
Pi CSI camera socket ---------- Raspberry Pi Global Shutter Camera (IMX296)
Pi 3V3 / GND / SDA / SCL ------- TCA9548A board (I2C 0x70)
MUX 0 SDA/SCL/3V3/GND --------- forward VL53L1X breakout (I2C 0x29)
MUX 1 SDA/SCL/3V3/GND --------- downward VL53L1X breakout (I2C 0x29)

Dedicated regulated power ------ Raspberry Pi logic/computation
Battery --> FUSE -> E-STOP -> servo distribution/controller --> 24 servos
     servo power supply current, fuse selection and cabling NOT determined
```
The Pi must **not power the servo rails**. Use a hardware E-stop that physically disconnects actuator supply and a supported chassis/harness while first testing; servo de-energization may cause a walking robot to collapse. Keep power grounds, protection, and logic-level interfacing consistent with selected controller and qualified technician review. No direct electrical attachment of Pi to Octobot control board is assumed here.

## Validated published data and calculated parameters
- Global Shutter Camera: 1456x1088, 38x38 mm, approx. 34 g *without selected lens* (Raspberry Pi). Actual lens FOV and focus require bench verification.
- VL53L1X: 940nm Class 1 emitter, 27 degree **typical** full FoV, up to 4m manufacturer nominal range; short-range behavior strongly depends on orientation/cover/reflectance.
- At sensor-to-ground z=120mm **assumed**, circular beam footprint width approx `2*z*tan(27/2 degrees) = 57.6mm` **calculated**, not measurement precision.
- At M=2.5kg *assumed*, 4 stance contacts each support M*g/4=6.13N; at lever arm 0.08m *assumed* the simple **static lever torque** T=0.49Nm, approx 5.0 kgf-cm; 3x nominal margin suggests >=15 kgf-cm only as an **initial** rough selection target. Inverse kinematics, multiple servo joints, moving load, drops and shocks can greatly change this number. Do **not** purchase servo solely from this number.
- Worst-case servo bus current `I_stall_total=sum(I_stall_i)` cannot be calculated numerically until the 24 exact servo models, supply voltages, and duty scenarios have been selected. Do not connect 24 servos to a small Raspberry Pi power adapter.

## Ground scan with real sensor
0. Obtain actual eight-legged mechanical frame as documented by Octobot authors; check license (MIT upstream) and firmware location/availability. Do not assume the PCB fabrication package by itself includes tested firmware or servos.
1. Start with a **stationary sensor head on a tripod** (before any robot legs) to validate camera focus and ToF range.
2. Install Raspberry Pi OS and camera support according to manufacturer docs; `rpicam-hello` and `rpicam-still` can verify compatible imaging before installing Python adapters.
3. Enable Pi I2C; verify TCA on `0x70` and one sensor `0x29` per channel. Record dark/light sensor results over 30–400mm and compare against caliper/ruler distances; actual close-range ToF performance must be established.
4. Print `CALIBRATION_MARKS_100mm_ACTUAL_SIZE.pdf` at **100% scaling**, measure **center-to-center physical distance** with a ruler/caliper and pass actual distance into CLI.
5. Photograph/scanner-capture reference plane fixed at planned body height and lens focus; run marker calibration *at the same plane* and inspect pixel pitch uniformity across field. This method alone cannot remove lens distortion or perspective; rectify if needed.
6. On Pi, install `picamera2` from Raspberry Pi OS repositories, `adafruit-blinka`, `adafruit-circuitpython-tca9548a`, `adafruit-circuitpython-vl53l1x`, and project requirements. Sensor adapter only imports hardware drivers on device.
7. Command `python -m src.physical_capture_UNTESTED --out-dir captures/test001` to capture one PNG and read both ToF values; inspect `ground_capture.json`. The CLI issues **no servo command**.
8. Verify sensor timestamp and log source, latency, repeatability, focus gates, floor material transitions, IR reflectivity, ambient light and sensor occlusion. Do not mark skill percentages as physical before using actual sensor-origin data.
9. Manufacture one `head_FITCHECK.stl` and two `tof_FITCHECK.stl`; physically measure mount slots, head center, wiring bend, foot sweep and total added mass. Revise CAD from measured fit.
10. Power up servo controller and leg hardware separately on bench, with E-stop and body supported. Verify vendor firmware and actuator servo ID/motion limits; no autonomous locomotion or cleaning until independently tested.

## Autonomy barrier and cleaning comparison
- The v0.5 software is intentionally READ-ONLY with a `STOP` or `OBSERVE_ONLY` **recommendation**. A recommendation is not an electrically certified stop.
- No actual vacuum fan, brush, filters, dustbin, mop, stair sensor suite, certified obstacle avoidance or cleaning score exists here.
- Roomba Combo j9+ includes vacuum brushes/mopping, object recognition, autonomous floor-cleaning features according to iRobot. Ripple cannot be called superior at cleaning; the comparison will be **ground inspection detail, movable clearance and recorded imaging**, measured later using identical floor obstacles, objects and test courses.
- For independent room-scale navigation consider additional LDS-02 360-degree lidar and ROS2 Nav2 collision monitoring; the 2 ToF beam layout is insufficient for full collision sensing or stair safety.

## Acceptance tests with explicit go/no-go
- A0: Version continuity (original SHA-256 unchanged) — PASSED SOFTWARE.
- A1: sensor source drivers import and run on actual Pi — NOT DONE.
- A2: sample rate, raw timestamps, calibration distances versus physical ruler, near/far rejects — NOT DONE.
- A3: image geometric reprojection corrected for lens distortion and focus — NOT DONE.
- A3B: external pose and known-lens-calibration stitched floor scan error vs measured ruler — NOT DONE.
- A4: 24 servos assembled on verified Octobot geometry, weighed and electrically characterised — NOT DONE.
- A5: emergency cut-off, mechanical support, manual walking control and fail-stop — NOT DONE.
- A6: repeatable before/after quality and traversability comparison with controlled Roomba — NOT DONE.

## Adaptive skills (%) definition
`skill_percent = count_of_trials_meeting_predeclared_criterion / number_of_valid_trials * 100`. Every percentage in `results/benchmark.json` has attempts and a Wilson interval. This is **observed algorithmic benchmark rate**, not IQ, learning ability, motor performance or hardware accuracy. The feedback-controlled Ripple threshold is separate from the newly added exposure recommendation module; neither implies a trained AI model.
