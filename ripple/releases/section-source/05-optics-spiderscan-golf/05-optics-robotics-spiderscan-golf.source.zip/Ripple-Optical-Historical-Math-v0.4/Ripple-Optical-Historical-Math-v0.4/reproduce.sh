#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python src/optical_study.py > data/optical_run.log
python src/fusion_validation.py > data/fusion_run.log
python src/uncertainty_audit.py > data/uncertainty_run.log
python src/constraint_study.py > data/constraint_run.log
node src/neuron_integration.js > data/neuron_integration.log
python src/chart_results.py
python src/build_explorer.py
python -m unittest discover -s tests -p 'test_science.py' -v > data/science_tests.log 2>&1
node --test tests/test_neuron.js > data/neuron_tests.log 2>&1
node --test tests/test_browser.js > data/browser_static_tests.log 2>&1
python src/verify_results.py
