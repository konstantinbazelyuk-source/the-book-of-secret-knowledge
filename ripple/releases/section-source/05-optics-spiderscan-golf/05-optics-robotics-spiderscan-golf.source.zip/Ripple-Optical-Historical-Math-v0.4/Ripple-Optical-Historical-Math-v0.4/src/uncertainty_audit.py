"""Audit whether an ideal white-noise-only error model gives calibrated intervals."""
import json,math,pathlib,collections
import numpy as np
from optical_study import A,DEPTH,N
ROOT=pathlib.Path(__file__).resolve().parents[1]
rows=json.loads((ROOT/'data/optical_trials.json').read_text())
# Known synthetic per-regime noise std from source generator; NOT an estimate on physical data.
SIGMA={'clean':.025,'ambient_flicker':.06,'weak_light':.07,'phase_shift':.05,'saturation':.04,'interference':.065,'calibration_drift':.05,'dark':.055}
W=np.array([2,1.2,-1.4]);projected_var={c:sum((W[j]*sigma*math.sqrt(2/N)/(DEPTH*np.linalg.norm(A[:,j])))**2 for j in range(3)) for c,sigma in SIGMA.items()}
report={}
for group in sorted(SIGMA):
    selected=[r for r in rows if r['scenario']==group]
    sig=math.sqrt(projected_var[group]);limit=1.96*sig
    errors=[r['lockin_drive_error'] for r in selected]
    report[group]={'white_noise_sigma_drive':sig,'white_noise_95_half_width':limit,
                   'observed_coverage':sum(e<=limit for e in errors)/len(errors),'observed_drive_mae':float(np.mean(errors)),
                   'calibration_validity':'white noise approximation excludes spectral drift, interference, clipping and amplitude-boundary bias'}
(ROOT/'data/uncertainty_audit.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
