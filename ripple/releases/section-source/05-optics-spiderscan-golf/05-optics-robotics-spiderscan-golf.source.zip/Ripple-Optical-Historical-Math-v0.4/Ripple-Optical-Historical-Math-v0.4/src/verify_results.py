import hashlib,json,pathlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
expected='d75d4208e92f19623b127615bd52b4002e85d2c0a59b76471764b55a24294210'
orig=ROOT/'src/ripple_core_reference.js'
assert hashlib.sha256(orig.read_bytes()).hexdigest()==expected
assert orig.read_bytes()==(ROOT/'baseline/ripple_core_reference.js').read_bytes()
trials=json.loads((ROOT/'data/optical_trials.json').read_text())
assert len(trials)==720
fused=json.loads((ROOT/'data/fusion_validation.json').read_text())
assert fused['held_out']['accepted']==210
assert fused['held_out']['rejected']==30
assert fused['held_out']['mae']<fused['held_out']['comparator']['lockin']
results=json.loads((ROOT/'data/neuron_integration.json').read_text())
assert len(results)==10
assert next(x for x in results if x['method']=='fused' and x['controller']=='original')['missingFrames']==150
hyp=json.loads((ROOT/'data/constraint_results.json').read_text())
assert len(hyp['rows'])==640
assert hyp['summary']['low_noise']['all_correct_unique_fraction']==1
assert hyp['summary']['high_noise']['ambiguous']==158
print('VERIFIED core SHA, 720 trials, 240 heldout, 640 hypotheses, 1200 frame neuron integration')
