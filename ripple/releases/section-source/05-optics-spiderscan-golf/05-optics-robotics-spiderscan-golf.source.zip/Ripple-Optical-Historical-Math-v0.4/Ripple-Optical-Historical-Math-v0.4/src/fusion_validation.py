"""Hold-out selection of optical input methods. Synthetic calibration exercise, not sensor validation."""
import json,itertools,pathlib,statistics
import numpy as np
ROOT=pathlib.Path(__file__).resolve().parents[1]
rows=json.loads((ROOT/'data/optical_trials.json').read_text())

def select(r,low=.025,high=.14):
    if r['saturation']>.005: return 'invalid'
    if r['residual']<low or r['residual']>high:return 'calibrated_dc'
    return 'lockin'

def stats(records,low,high):
    methods=[select(r,low,high) for r in records]
    valid=[(r,m) for r,m in zip(records,methods) if m!='invalid']
    errors=[r[m+'_mae'] for r,m in valid]
    return dict(n=len(records),accepted=len(valid),rejected=len(records)-len(valid),
                mae=float(np.mean(errors)) if errors else None,p90=float(np.quantile(errors,.9)) if errors else None,
                methods={m:methods.count(m) for m in ('invalid','calibrated_dc','lockin')},
                comparator={k:float(np.mean([r[k+'_mae'] for r,_ in valid])) if valid else None for k in ('raw','calibrated_dc','lockin')})
train=[r for r in rows if r['index']%3 !=2]
test=[r for r in rows if r['index']%3 ==2]
choices=[]
for low,high in itertools.product([.018,.022,.026,.030,.034,.040],[.10,.12,.14,.16,.18,.20]):
    s=stats(train,low,high)
    choices.append((s['mae'],low,high,s))
choices.sort()
score,low,high,train_stats=choices[0]
report={'method':'thresholds fixed on training subset; test subset never used for threshold fitting',
        'thresholds':{'residual_low':low,'residual_high':high,'saturation_max_fraction':.005},
        'train':train_stats,'held_out':stats(test,low,high),
        'held_out_by_regime':{c:stats([r for r in test if r['scenario']==c],low,high) for c in sorted({r['scenario'] for r in rows})},
        'limitations':'Synthetic response matrix; calibration and hardware noise not measured; threshold tuning uses labeled simulated truth; rejection can reduce coverage.'}
(ROOT/'data/fusion_validation.json').write_text(json.dumps(report,indent=2))
sequence=json.loads((ROOT/'data/neuron_sequence.json').read_text())
for r in sequence:
    m=select(r,low,high)
    r['fused_method']=m
    r['fused']=[0.,0.,0.] if m=='invalid' else r[m]
(ROOT/'data/neuron_sequence.json').write_text(json.dumps(sequence))
print(json.dumps(report,indent=2))
