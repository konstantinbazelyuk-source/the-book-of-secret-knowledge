from __future__ import annotations
import json,pathlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=pathlib.Path(__file__).resolve().parents[1]
summary=json.loads((ROOT/'data/optical_summary.json').read_text())
fusion=json.loads((ROOT/'data/fusion_validation.json').read_text())
scenarios=[c for c in summary if c!='ALL']
methods=['raw','calibrated_dc','lockin']
x=np.arange(len(scenarios)); fig,ax=plt.subplots(figsize=(11,5.5))
for i,k in enumerate(methods):ax.bar(x+(i-1)*.26,[summary[c][k]['mae'] for c in scenarios],width=.25,label=k)
ax.set_xticks(x,scenarios,rotation=27,ha='right');ax.set_ylabel('Mean absolute decoded-channel error (synthetic)');ax.set_title('720 simulated sensor observations — reconstruction is not universally better');ax.legend();fig.tight_layout();fig.savefig(ROOT/'charts/synthetic_optical_error.png',dpi=150);plt.close(fig)
results=json.loads((ROOT/'data/neuron_integration.json').read_text())
fig,ax=plt.subplots(figsize=(10,5))
labels=['raw','calibrated_dc','lockin','fused']; xx=np.arange(len(labels))
for j,c in enumerate(['original','hybrid-fast']):
 rows={r['method']:r for r in results if r['controller']==c}
 ax.bar(xx+(j-.5)*.32,[rows[k]['windowCountMAE'] for k in labels],width=.3,label=c)
ax.set_xticks(xx,labels);ax.set_ylabel('Mean absolute 2-model-s bin spike-count error');ax.set_title('Original neuron vs optional hybrid: cleaner optical measurements ≠ identical spikes');ax.legend();fig.tight_layout();fig.savefig(ROOT/'charts/neuron_spike_count_errors.png',dpi=150);plt.close(fig)
fig,ax=plt.subplots(figsize=(7,5))
held=fusion['held_out'];nums=[held['comparator']['raw'],held['comparator']['calibrated_dc'],held['comparator']['lockin'],held['mae']]
ax.bar(['raw','calibrated DC','lock-in','fused'],nums);ax.set_ylabel('Mean absolute channel error');ax.set_title(f"Reserved holdout: {held['accepted']} valid / {held['n']} total (30 rejected)")
fig.tight_layout();fig.savefig(ROOT/'charts/heldout_fused_optical_accuracy.png',dpi=150);plt.close(fig)
print('CHARTS 3')
