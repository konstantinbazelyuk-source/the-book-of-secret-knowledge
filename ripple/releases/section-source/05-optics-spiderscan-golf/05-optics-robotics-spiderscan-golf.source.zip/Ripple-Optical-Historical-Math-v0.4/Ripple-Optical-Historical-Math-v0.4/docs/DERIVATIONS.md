# Mathematical derivations and algorithm audit — v0.4

## 0. Original program — locked control

Original reference: `baseline/Ripple-Neuron-Simulator-v0.1-original.html`. Its first-principle model is `tau_v*du/dt=-u+D`, with `D=2R+1.2G-1.4B`, `tau_v=.5 model seconds`. Under constant `D`, the exact solution is `u(t+h)=D+(u(t)-D)exp(-h/tau_v)` until it reaches `theta`. Then emit a spike, reset `u=0`, and hold for `t_ref=.1` model seconds. A five-second exponential spike filter drives threshold adaptation, clipped to `[.15,2.5]`.

For constant D>theta, `f=1/[t_ref+tau_v*ln(D/(D-theta))]`. The optional v0.3 hybrid inverts this expression at feasible targets, adds error feedback, and does not change the original kernel. Event clocks in v0.3 experiments may be accelerated relative to physical seconds.

The source implements an event-driven leaky integrate-and-fire numerical model. It **does not** directly measure the electric or magnetic field of light, integrate optical photons as a hardware circuit, or learn a sensor response by itself.

## 1. Forward optical observation model

A synthetic four-channel photodetector array observes source intensities `s_j in [0,1]`:

`y_i(t) = b_i(t) + sum_j A_ij*s_j*(1+m*sin(2*pi*f_j*t+phi_j)) + epsilon_i(t)`.

`A` is a dimensionless **synthetic** spectral response matrix, `m=.48`, `f=(7,11,17) Hz`. Ambient terms include DC, 50-Hz flicker and optional drift. Other stressors include incorrect A calibration, near-carrier interference, clipping and Gaussian independent channel noise. This is a light-*intensity* model, not a model of the instantaneous optical E/B waves. The assumed N=512 samples at 256 Hz describes hypothetical data acquisition; it has not been established for the AS7341 multiband sensor in the original bench proposal.

## 2. Calibrated DC nonnegative reconstruction

With an available reference estimate of the background `b`, solve

`argmin_{s>=0} || A*s - (mean_t(y)-b) ||_2^2`.

Code uses SciPy's `optimize.nnls`, an established Lawson-Hanson family solver. It preserves the physical nonnegativity of intensity but **cannot** recover spectral components uniquely when sensor signatures are indistinguishable or if background calibration fails. It also clips displayed values to [0,1] after solving. Strict physical real-time implementation would need actual calibration, time stamping, and checks for nonlinearity.

## 3. Lock-in quadrature demodulation

For each frequency `f_j`, compute for each sensor i:

`I_ij=(2/N)sum_n y_i[n]*sin(2*pi*f_j*n/Fs)`

`Q_ij=(2/N)sum_n y_i[n]*cos(2*pi*f_j*n/Fs)`.

Project onto spectral column `a_j=A[:,j]`:

`p_j=(a_j^T I_j)/(a_j^T a_j), q_j=(a_j^T Q_j)/(a_j^T a_j)`

`estimated_s_j=sqrt(p_j^2+q_j^2)/m`.

Integer modulation cycles over the window permit near-orthogonal bins for the ideal rectangular acquisition. Quadrature makes source phase unknown but recoverable. Off-bin narrowband interference, window drift, clipping, nonlinear sensor response, and near-zero-amplitude magnitude bias break the ideal recovery. Duplicated frequency carriers cannot be distinguished by temporal demodulation alone. This is synchronous demodulation of amplitude-modulated LEDs, **not** optical heterodyne detection of the physical electromagnetic field.

## 4. Evidence selector

The signal-consistency residual is a sum of norms between measured demodulation vectors and the expected response signature after projection. Candidate rules are chosen *only on a synthetic training set*. For residual below `.018` (steady low-noise cases) or above `.18` (off-frequency interference), select calibrated DC; otherwise lock-in. With clipped sample fraction >0.005, **reject**. This heuristic may misclassify new conditions; no Bayes-optimality or physical sensor calibration is claimed. Held-out test members have never been used to select these boundaries.

The `invalid` state is an abstention. The optional downstream reference consumes `[0,0,0]` as a **fallback policy** but suppresses feedback adaptation during that interval and logs every missing frame. This is not equivalent to observing darkness; it is merely a transparent, testable fail-safe policy.

## 5. Variance propagation and calibration failure

For ideal uncorrelated white channel noise of standard deviation `sigma`, a quadrature projection has approximately

`Var(estimated_s_j) ~ (2*sigma^2)/(N*m^2*||a_j||^2)`

away from zero-amplitude boundaries. With `w=(2,1.2,-1.4)`, model driving-current uncertainty is

`Var(D) ~= w^T Sigma_s w`.

A nominal 95% interval is `Dhat +/- 1.96 sigma_D`. Its **actual** simulated coverage is far below nominal under clipped and interference conditions; see `data/uncertainty_audit.json`. It must not be portrayed as verified calibrated uncertainty.

## 6. Public historical electromechanical codebreaking principle, not decryption

The Turing–Welchman Bombe eliminated Enigma settings contradicting a structured plaintext/ciphertext crib; Colossus used electronic counting/testing to narrow Lorenz wheel-setting possibilities. There is no secure claim that these algorithms can recover optical E-fields or that this package reconstructs those machines. The new educational experiment is finite hypothesis elimination:

Candidates are 64 triples from `S={0, .3, .6, .9}^3`. Given observation y and *assumed known* b, A, Gaussian noise sigma, score candidate `x` with `Q(x)=sum_i((y_i-b_i-[Ax]_i)/sigma)^2`.

Reject if the minimum Q exceeds `chi2(0.99, 4)=13.2767`; return uniquely accepted candidate only if exactly one candidate passes; otherwise signal ambiguity. This is an established least-squares/chi-square test and brute-force finite enumeration. If covariance is incorrect, signals clip, or response shifts, its statistical guarantee fails. Cryptographic security and arbitrary ciphertext decryption are **not** provided.

## 7. Different objective functions must not be conflated

Optimizing optical channel MAE or drive error does not guarantee minimal neuron spike-timing deviation because LIF threshold crossings are discontinuous functionals of small voltage variations near threshold. Side-by-side tests compare the original and optional v0.3 hybrid; each has its own control with ideal-color input. `data/neuron_integration.json` gives complete spike-count errors and dropout counts.

## 8. Reporting-layer bug isolated

`baseline/feedback_sweep.js` v0.3 `ControlledNeuron.step` calls `n.step` to produce an output object with `out.theta`, then updates `n.theta` in place before returning the unmodified output object. `out.theta` is therefore from *before* the hybrid update. The isolated `src/hybrid_output_adapter.js` returns a new object with `thetaBefore`, correct `thetaAfter` and correct current `theta`. The adapter changes **reporting only**, not the neuron equations or behavior. Tested in Node.js.
