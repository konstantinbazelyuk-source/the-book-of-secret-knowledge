# Historical/public-domain-inspiration source register

These links were checked during design review. Availability of a historical description or museum reconstruction does not mean complete original fabrication blueprints or runnable historical source code are available or included in this package.

| Source | Publicly verifiable content | Legitimate relevance to Ripple |
|---|---|---|
| EPFL *Neuronal Dynamics*, 1.3 and 1.6 | https://neuronaldynamics.epfl.ch/online/Ch1.S3.html ; https://neuronaldynamics.epfl.ch/online/Ch1.S6.html | Lapicque-era integrate-and-fire dynamics; exact threshold crossing is established mathematics. |
| ams OSRAM AS7341 product and calibration documents | https://ams-osram.com/products/sensor-solutions/ambient-light-color-spectral-proximity-sensors/ams-as7341-11-channel-spectral-color-sensor | Provides multiband photodetection but requires wavelength/sensor response calibration; **do not assume** v0.4's 256 Hz synchronized multiband sampling is supported. |
| NIST Detector Metrology | https://www.nist.gov/programs-projects/detector-metrology | Detector responsivity and traceable calibration; explains why raw color readings cannot be equated to optical field measurements. |
| NIST *Uncertainty calculation for spectral-responsivity measurements* | https://www.nist.gov/publications/uncertainty-calculation-spectral-responsivity-measurements | Propagating and validating spectroradiometric uncertainty. |
| Zurich Instruments *Principles of Lock-in Detection* | https://blogs.zhinst.com/en/resources/principles-of-lock-in-detection/ | Phase-sensitive modulation/demodulation and limitations. |
| SciPy `nnls` | https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.nnls.html | Proven algorithm for constrained nonnegative spectral unmixing. |
| National Museum of Computing, *Turing–Welchman Bombe* | https://www.tnmoc.org/bombe | Historical structured crib tests used to reject invalid Enigma rotor settings. |
| TNMOC, *Bombe Description* | https://www.tnmoc.org/bh-10-bombe-description | Public description of drum banks, wiring, and contradiction/open-circuit testing in the reconstructed Bombe. |
| TNMOC, *Enter Turing and Welchman* | https://www.tnmoc.org/bh-6-enter-turing-and-welchman | Primary museum account of Polish groundwork, crib-based search and diagonal-board improvement. |
| TNMOC, *Colossus* | https://www.tnmoc.org/colossus | Codebreaking computer for Lorenz chi-wheel settings, electronic statistical search—not a generic decryptor. |
| TNMOC, *Rebuilding Colossus* | https://www.tnmoc.org/rebuilding-colossus | Describes reconstructed electronics from photographs and surviving diagram fragments; many original engineering drawings were destroyed. |
| C. E. Shannon, *Communication Theory of Secrecy Systems*, BSTJ (1949) | https://onlinelibrary.wiley.com/doi/10.1002/j.1538-7305.1949.tb00928.x | Foundational separation of cryptographic key search, inference, and information theory; not an optical-signal theory or a direct Ripple performance contribution. |

This prototype does not incorporate third-party historical machine code or claim rights in museum materials. The historical link is to *methodology*: known constraints, candidate elimination, and testing, not a direct implementation of Bombe wiring, Enigma cryptography, or Colossus logic.
