# Ripple Optical Historical Mathematics v0.4 — integrity manifest

- Preserved Ripple neuron source SHA-256: `d75d4208e92f19623b127615bd52b4002e85d2c0a59b76471764b55a24294210`.
- Synthetic optical trials: **720**; reserved fusion test: **240** (210 accepted and 30 rejected).
- Discrete code-hypothesis examples: **640**.
- Neuron comparison: **1,200 synthetic frames** per decoder/controller.
- Tests: **18 Python + 16 Node integration + 2 static browser JS = 36/36 passed**; original v0.3 regression suite **24/24 passed**.
- Python SciPy dependency used for spectral nonnegative least squares and chi-square.
- Optical decoding and neuron results are **simulated**, not hardware-measured; no performance advantage for end-to-end neuron established.
- Browser tests executed through Node VM; full Chromium navigation was blocked by environment, so **no graphical browser pass claimed**.
- Tracked entries in SHA256SUMS.txt: **46**.
