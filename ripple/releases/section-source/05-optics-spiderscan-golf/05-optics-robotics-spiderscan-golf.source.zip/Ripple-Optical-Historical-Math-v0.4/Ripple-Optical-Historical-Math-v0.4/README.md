# Ripple v0.4 — Optical decoding, historical mathematics and evidence gating

**Status:** Executable numerical research prototype. Original Ripple v0.1 math and the optional v0.3 hybrid controller are left unchanged. **Not** a physical photonic neuron, historical decryption device, detector of electric/magnetic light fields, or general intelligence.

## First run

```bash
python -m pip install numpy scipy matplotlib
python src/optical_study.py
python src/fusion_validation.py
python src/uncertainty_audit.py
python src/constraint_study.py
node src/neuron_integration.js
python src/chart_results.py
python -m unittest discover -s tests -p 'test_science.py' -v
node --test tests/test_neuron.js
```

Open `Ripple-Optical-Mathematics-v0.4.html` directly in a browser to explore recorded synthetic inputs. Python 3.11+ and Node.js 18+ recommended. The HTML needs no server/network. The Python study depends on SciPy for nonnegative least squares and the chi-square threshold. The v0.1 source snapshot and the v0.3 math specification are under `baseline/`.

## What was really studied

The original mathematical program is the JavaScript `RippleNeuron` inside `baseline/Ripple-Neuron-Simulator-v0.1-original.html`. Its core is mirrored in `src/ripple_core_reference.js` with SHA-256 `d75d4208e92f19623b127615bd52b4002e85d2c0a59b76471764b55a24294210`, also checked against `baseline/ripple_core_reference.js`. The original used leaky integration, exact constant-input crossing, refractory holding, exponential pulse-rate filtering, and bounded feedback. It is a defined numerical model, not an optical EM field meter.

**Original fixed software-defined optical weights:** `D = 2*R + 1.2*G - 1.4*B`. The new contribution is an optional signal decoder **before** these weights are applied. No claims are made that colors inherently excite/inhibit a biological system.

## Core results (all synthetic, not measured physical sensing)

- **720 optical simulations**, 8 challenge regimes × 90 draws, 4 synthetic photodetector channels, 512 time samples over a 2-second hypothetical acquisition at 256 Hz. Carrier frequencies 7, 11 and 17 Hz; a *synthetic* spectral mixing matrix, explicitly not actual AS7341 response measurements.
- All-regime component MAE: uncalibrated `0.32220`, calibrated dark-reference + nonnegative least squares `0.04806`, quadrature synchronous detection `0.08106`. Optical lock-in **fails severely under clipping**, and no one decoder wins universally.
- A decision filter was fitted on 480 training cases (2/3 stratified by regime), using clipped-sample and spectral-consistency checks, then independently evaluated on 240 held-out cases. On the **210 accepted** held-out examples (30 clipped examples rejected), fusion component MAE `0.0091869`, compared on **exactly the same accepted subset** with `0.340351` (raw), `0.0289413` (calibrated DC), `0.0126792` (lock-in). Trained thresholds: residual `<0.018` or `>0.18` -> calibrated DC, otherwise lock-in; clipping fraction `>0.005` -> reject. These settings are not proven valid outside synthetic data.
- **640 finite optical-symbol hypothesis examples:** 4 strength levels across 3 optical components (`4^3 = 64` candidate triples), 160 per regime. Under low calibrated noise, 160/160 uniquely correct; with high noise only 2/160 uniquely accepted and 158 ambiguous; unmodeled drift causes 160/160 rejection; clipped inputs cause erroneous high-confidence decisions in some trials. Thus this historical *analogy* must fail closed and not be advertised as a cryptographic decoder.
- **1,200 synthetic frames** evaluated through original and optional v0.3 hybrid neuron. Cleaner optical-input MAE does **not** guarantee smaller neuron spike-count error. For original Ripple, mean absolute 2-model-second spike-count differences versus an ideal-input control: raw `0.633`, calibrated DC `0.500`, lock-in `0.800`, fused-with-abstention `0.800`. For the v0.3 hybrid: raw `0.800`, calibrated DC `0.200`, lock-in `0.067`, fused-with-abstention `0.300`. Fused configuration has 150 missing sensor frames, which are leaked under zero input with feedback temporarily disabled. **This is a negative result, not a neuron win.** Optical acquisition time and neuron model time differ and have not been hardware synchronized.
- A white-noise-only theoretical 95% drive interval covers the synthetic truth 90% in the clean case, 21% with near-carrier interference, and 1.1% under saturation. This simple uncertainty model is therefore **not calibrated** to real-world interference/clipping.
- Automated tests: 18 Python, 16 Node (run scripts and read their logs). Separate optional adapter `src/hybrid_output_adapter.js` corrects **only** a v0.3 output-reporting mismatch where the wrapper returned pre-update `theta` despite changing its internal threshold. **No original or v0.3 equation was edited.**

## What improves the original

1. **Spectral calibration / nonnegative reconstruction**: instead of treating contaminated sensor channels as pure `R,G,B`, solve for physically nonnegative light components using a measured-response matrix (future hardware requirement).
2. **Synchronous, quadrature optical demodulation**: encode individual light-source *intensity* channels at known electronic modulation frequencies, then distinguish those from ambient light. This is electronic amplitude modulation of light intensity, not the optical field's ~10^14-Hz carrier itself.
3. **Quality gates before firing**: detect clipping, inconsistency, sensor drift, and underconstrained hypotheses. Abstain from trusting invalid frames; an abstention is not zero light.
4. **Propagate uncertainty**: estimate `Var(D)=w^T Sigma_x w` where the color coefficient vector is `w=[2,1.2,-1.4]`, but audit coverage under violated assumptions.
5. **Falsification first**: unchanged Ripple and ordinary calibrated DC reconstructions stay as controls. Only add the optical extension where measured performance clears both task and cost baselines.

## Evidence and limits

No calibrated detector response matrix, photodiode time series, noise covariance or electronic bench has been provided. `A` is invented for testing; signal values are synthetic; no claim of electromagnetic waveform detection, optical quantum sensor, recovered secret keys, historical machine replication, or consciousness. The v0.3 collector/colony and other project branches are untouched. Historical sources are documented in `docs/HISTORY_AND_SCIENCE.md`; derivations in `docs/DERIVATIONS.md`; negative results in `docs/NEGATIVE_RESULTS.md`.

## Safe reproduction policy

The original program, v0.3 comparator, and all data/logs remain locally packaged. No GitHub publication, cloud deployment, modification of live Ripple, or external action was performed. The new original study materials can be reused under the included CC0-1.0 terms, but third-party references retain their own licenses and hardware/patent freedom-to-operate is not established.
