'use strict';
const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),assert=require('node:assert/strict'),test=require('node:test');
const html=fs.readFileSync(path.resolve(__dirname,'../Ripple-Optical-Mathematics-v0.4.html'),'utf8');
const m=html.match(/<script>([\s\S]*?)<\/script>/);assert.ok(m);
test('offline HTML JavaScript parses',()=>assert.doesNotThrow(()=>new vm.Script(m[1])));
test('results explorer switches from normal to clipped with no runtime errors',()=>{
 const nodes=new Map();const doc={getElementById:(id)=>{
  if(!nodes.has(id))nodes.set(id,{value:id==='regime'?'clean':id==='case'?'0':'',innerHTML:'',textContent:'',className:'',appendChild(x){return x},addEventListener(type,callback){this.events=this.events||{};this.events[type]=callback}});
  return nodes.get(id);},createElement:()=>({value:'',textContent:''})};
 vm.runInNewContext(m[1],{document:doc,console},{timeout:2000});
 assert.equal(nodes.get('decision').textContent,'calibrated dc');
 nodes.get('regime').value='saturation';nodes.get('regime').events.change();
 assert.equal(nodes.get('decision').textContent,'rejected');
 assert.ok(nodes.get('status').className.includes('bad'));
 assert.ok(nodes.get('chart').innerHTML.includes('Red'));
});
