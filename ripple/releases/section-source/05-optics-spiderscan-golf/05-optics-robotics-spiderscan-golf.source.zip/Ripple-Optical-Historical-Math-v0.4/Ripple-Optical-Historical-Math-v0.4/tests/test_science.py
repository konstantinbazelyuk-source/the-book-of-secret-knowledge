import json,math,pathlib,sys,unittest
import numpy as np
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from optical_study import A,synthetic_case,decode,FS,N,FREQ,DEPTH
from constraint_study import infer,CHI2_CUTOFF,CANDIDATES

class ScienceTests(unittest.TestCase):
    def test_optical_sampling_nyquist(self):self.assertLess(max(FREQ),FS/2)
    def test_integer_carrier_cycles(self):self.assertTrue(np.all(FREQ*N/FS==np.round(FREQ*N/FS)))
    def test_model_nonnegative(self):self.assertTrue(np.all(A>=0))
    def test_clean_sample_recovers(self):
        x=synthetic_case(121,'clean');d=decode(x)
        self.assertLess(np.max(abs(d['calibrated_dc']-x['truth'])),.015)
        self.assertLess(np.max(abs(d['lockin']-x['truth'])),.015)
    def test_phase_shift_quadrature(self):
        x=synthetic_case(233,'phase_shift');d=decode(x)
        self.assertLess(np.max(abs(d['lockin']-x['truth'])),.025)
    def test_dark_lockin_rejection(self):
        x=synthetic_case(831,'dark');d=decode(x)
        self.assertLess(np.max(d['lockin']),.04)
    def test_background_dc_fails(self):
        x=synthetic_case(432,'ambient_flicker');d=decode(x)
        self.assertLess(np.mean(abs(d['lockin']-x['truth'])),np.mean(abs(d['raw']-x['truth'])))
    def test_saturation_flag(self):
        x=synthetic_case(180,'saturation')
        self.assertGreater(x['over'],.005)
    def test_nonnegativity(self):
        for s in ['dark','weak_light','phase_shift','interference','saturation']:
            o=decode(synthetic_case(33,s));self.assertTrue(np.all(o['calibrated_dc']>=0));self.assertTrue(np.all(o['lockin']>=0))
    def test_hypotheses_64(self):self.assertEqual(len(CANDIDATES),64)
    def test_constraints_no_noise(self):
        idx=21; res=infer(A@CANDIDATES[idx],.01)
        self.assertEqual(res['candidate'],idx);self.assertEqual(res['status'],'accept')
    def test_constraints_reject_inconsistent(self):self.assertEqual(infer(np.full(4,5.),.05)['status'],'reject')
    def test_constraints_ambiguous_high_noise(self):self.assertEqual(infer(A@CANDIDATES[12],1.)['status'],'ambiguous')
    def test_invalid_sigma(self):
        with self.assertRaises(ValueError):infer(np.zeros(4),0)
    def test_threshold_probability(self):self.assertLess(abs(CHI2_CUTOFF-13.2767),.002)
    def test_holdout_no_overlap(self):
        rows=json.loads((ROOT/'data/optical_trials.json').read_text())
        self.assertEqual(len(rows),720)
        train={r['seed'] for r in rows if r['index']%3!=2};test={r['seed'] for r in rows if r['index']%3==2}
        self.assertFalse(train&test);self.assertEqual(len(test),240)
    def test_not_hide_rejections(self):
        report=json.loads((ROOT/'data/fusion_validation.json').read_text())
        self.assertEqual(report['held_out']['rejected'],30)
        self.assertEqual(report['held_out_by_regime']['saturation']['mae'],None)
    def test_fusion_p90_less_than_dc_accepted(self):
        report=json.loads((ROOT/'data/fusion_validation.json').read_text())['held_out']
        self.assertLess(report['mae'],report['comparator']['calibrated_dc'])

if __name__=='__main__':unittest.main()
