import math
import tempfile
import unittest
from pathlib import Path

import numpy as np
from ripple_spectrum import analyze_site, simulate_csv, load_csv, run

class SpectrumTests(unittest.TestCase):
    def test_known_magnetic_frequency_and_amplitude(self):
        rows=[]
        for t in np.arange(400)/200:
            rows.append(dict(t_s=float(t),mag_x_uT=float(40+0.75*np.sin(2*np.pi*12*t))))
        result=analyze_site(rows,12,'mag_x_uT')
        self.assertAlmostEqual(result['nearest_bin_Hz'],12.0,places=6)
        self.assertAlmostEqual(result['amplitude'],0.75,delta=0.008)

    def test_known_light_modulation(self):
        rows=[dict(t_s=float(t),photo_V=float(1+.15*np.sin(2*np.pi*40*t))) for t in np.arange(400)/200]
        result=analyze_site(rows,40,'photo_V')
        self.assertAlmostEqual(result['amplitude'],0.15,delta=0.004)

    def test_nyquist_rejects(self):
        rows=[dict(t_s=i/20,photo_V=1.) for i in range(60)]
        with self.assertRaisesRegex(ValueError,'Nyquist'):
            analyze_site(rows,12,'photo_V')

    def test_bad_clock_rejects(self):
        times=[i*.005 for i in range(100)]
        times[30]+=.003
        rows=[dict(t_s=t,photo_V=1.) for t in times]
        with self.assertRaisesRegex(ValueError,'Uneven timing'):
            analyze_site(rows,12,'photo_V')

    def test_simulation_end_to_end(self):
        with tempfile.TemporaryDirectory() as td:
            td=Path(td)
            csv_path=simulate_csv(td/'demo.csv')
            self.assertEqual(len(load_csv(csv_path)),48)
            result=run(csv_path,td/'output',12,40,'SIMULATED DATA')
            self.assertEqual(result['measurement_sites'],48)
            self.assertTrue(0.5 < result['magnetic_peak_bin_amplitude_uT'] < 0.9)
            self.assertTrue(0.15 < result['optical_modulation_peak_bin_amplitude_V'] < 0.30)
            for filename in ('analysis.json','magnetic_frequency_map.png','optical_modulation_map.png','magnetic_spectrum.png','optical_spectrum.png'):
                self.assertTrue((td/'output'/filename).is_file())

if __name__=='__main__':unittest.main()
