# Ripple Spectrum — read-only field observer v0.1

**Scope:** Standalone, non-invasive instrument-side signal analysis. This package does **not** edit Ripple's neuron equations, behavioral logic, or approved modules. No cloud service, camera login, or external calls.

## Two fundamentally different frequencies

- 12 Hz in these magnetic scans means a **time-varying magnetic field measured by a magnetometer**.
- 40 Hz in these optical scans means **the rate at which a light intensity signal varies**, not a 40 Hz photon and not an optical-frequency electric/magnetic waveform. Light's visible optical carrier is ~400–750 *terahertz*.
- A 40 Hz magnetometer/photodiode recording is **not evidence of a gamma brainwave**. EEG rhythms require an appropriate brain-specific modality and controls.

## What it produces

Each measurement site has a time series. The program computes a Hann-windowed Fourier amplitude at each requested temporal frequency and builds a map of sampled positions (missing sites remain blank, not interpolated). It produces individual PNG maps and spectra plus JSON metadata. Results are always marked **SIMULATED DATA** or **IMPORTED CSV — SENSOR ORIGIN UNVERIFIED**. Users must independently establish physical source, units, calibration, and attribution.

## Execute now — without equipment

```bash
python3 -m pip install -r requirements.txt
python3 -m unittest discover -v
python3 ripple_spectrum.py --demo --out output
```

The demo simulates a 6x8 grid, 200 samples/s, 2 s per site, a 12 Hz magnetic disturbance, and a 40 Hz optical intensity modulation. A separate 60 Hz magnetic interferer and sensor noise are included. Nothing in the demo was physically measured.

## Analyze measurements

```bash
python3 ripple_spectrum.py --csv real_scan.csv --out real_output --mag-hz 10 --photo-hz 8
```

Required CSV columns: `x_mm,y_mm,t_s,mag_x_uT,mag_y_uT,mag_z_uT,photo_V`.

At each spatial `(x_mm,y_mm)` site, `t_s` starts near zero and monotonically increases. Do not repeat the same coordinate in multiple capture segments unless concatenating their times correctly; each site must be one contiguous segment of at least 32 samples. Spatial units are millimeters and **must be recorded**, not estimated from a body photograph. Do not move the probe while collecting a site's waveform. Sampling jitter above 10% triggers an error. For 25 Hz acquisition select frequencies **below 12.5 Hz**, and much lower if the sensor sample rate or noise warrants it. For frequency resolution Δf ≈ 1 / duration, use longer captures.

## Optional physical prototype — NOT yet hardware validated

### Components / purposes

1. Raspberry Pi with I2C and Python / Blinka support — acquisition and storage.
2. Adafruit LIS3MDL breakout — **three-component low-frequency magnetic field**, **not the magnetic carrier of light**. Max rate depends on performance mode; 155 Hz high precision, 1 kHz lower-precision advertised mode. Its baseline includes Earth's field (~tens of µT), nearby motors, cables, and ambient interference.
3. Texas Instruments OPT101 photodiode + amplifier — **light intensity modulation** output in volts; 14 kHz amplifier bandwidth for the default 1 MΩ configuration (does not measure optical carrier frequency).
4. Adafruit ADS1115 16-bit I2C ADC — samples OPT101 analog output. Configurable conversion rates up to 860 samples/s; sequential I2C/Python polling may be much slower. OPT101 supply and ADC input range must be compatible and share a common ground; ensure the ADC input stays in safe range.
5. Optional AS7341 color spectral sensor — visible channels plus near infrared, a **separate slow spectral modality** requiring its own calibrated adapter; this package does not pretend the photodiode voltage is wavelength resolved.
6. Optional MLX90640 32×24 thermal camera — separate thermal map (radiative temperature), not magnetic or brain activity.

### Wiring, logical, low-voltage only

- Pi 3.3 V and GND to compatible breakout VCC/VIN and GND; Pi SDA/SCL (GPIO2/3) to both LIS3MDL and ADS1115 I2C SDA/SCL. Check each board's logic-level and wiring documentation first.
- OPT101 power per its **datasheet reference design**; common ground with ADS1115, OPT101 voltage output to ADS1115 A0. If amplifier supply/output can exceed ADC powered-rail or configured full-scale range, **do not connect** until level-shifted/limited appropriately.
- No high voltage, ionizing radiation sources, or lasers are involved in the base prototype.

### Example acquisition script (untested on hardware)

```bash
python3 -m pip install -r requirements_pi.txt
# enable I2C on Pi, check detected devices, verify stable output against controls
python3 capture_pi.py --out real_scan.csv --x-mm 0 --y-mm 0 --seconds 8 --rate 25
python3 capture_pi.py --out real_scan.csv --x-mm 10 --y-mm 0 --seconds 8 --rate 25
python3 ripple_spectrum.py --csv real_scan.csv --out real_output --mag-hz 10 --photo-hz 8
```

At this host-polled rate, use low frequency targets; make sure the requested modulation is present and that time jitter passes validation. The capture script preserves timestamps after sequential sensor reads; it does not guarantee simultaneous acquisition. True synchronized or high-bandwidth tests require dedicated ADC hardware and clocking.

### Minimal experimental controls / acceptance gates

1. Darken/cover the photodiode; light-modulation signal should drop while the magnetic channel remains independently testable.
2. Flash an LED using a **known, measured** 8 Hz electronic driver; verify optical peak near 8 Hz without falsely inferring its wavelength from modulation.
3. Place a safe small battery-powered current coil at a measured distance and use a function generator to create a known low-frequency alternating field; compare with no-current baseline. Quantitative B estimates require coil geometry and calibration. Do not apply mains power to an experimental coil.
4. Move electronics/cables away, rotate the sensor and repeat; identify orientation dependence and interference. Make blank scans before every scan of an object/person.
5. Hold constant exposure, detector gain, probe distance, ambient lighting, sensor temperature and fixed positions; measure repeatability and null signals.
6. If mapping near humans, do not interpret a 10 Hz or 40 Hz peak as brain activity without a suitable validated EEG/MEG measurement setup and interference rejection.

### What IS NOT implemented

- Direct imaging of a visible light wave's magnetic carrier field; magnetic camera for visible light; aura or supernatural phenomenon detector.
- Gamma-ray detector, beta-particle detector, EEG, radio-frequency receiver, UV spectrometer, thermal imager, or magneto-optic Kerr microscope. These are separate possible instrument modules, not functions this software already performs.
- Reliable identification of people, mental state, health state or biology from magnetic/optical maps.
- Any modification of the original Ripple neuron or feedback equations.

## Design extensions

Stage A: calibrate magnetic and optical channels with references, synchronized timestamps, and spatial scan registration. Stage B: connect AS7341 and calibrated thermal / RF modules with explicit spectral units and quality flags. Stage C: investigate gradiometers, optically pumped magnetometers, electro-optic sampling, optical heterodyne spectroscopy, and distributed detector arrays using appropriate labs and budgets. The visualization can combine layers but each must retain separate provenance and resolution. Only compare a physically measured observable to a hypothesis after controls.

## References (manufacturer / laboratory)

- https://www.nist.gov/publications/femtotesla-atomic-magnetometry-microfabricated-vapor-cell
- https://www.nist.gov/publications/coherent-linear-optical-sampling-over-15-bits-resolution
- https://www.nist.gov/programs-projects/waveform-metrology-project
- https://www.ti.com/product/OPT101
- https://learn.adafruit.com/lis3mdl-triple-axis-magnetometer/overview
- https://docs.circuitpython.org/projects/lis3mdl/en/stable/api.html
- https://docs.circuitpython.org/projects/ads1x15/en/stable/api.html
- https://learn.adafruit.com/adafruit-as7341-10-channel-light-color-sensor-breakout/python-circuitpython
- https://learn.adafruit.com/adafruit-mlx90640-ir-thermal-camera/overview
- https://science.nasa.gov/mission/webb/science-overview/science-explainers/spectroscopy-101-light-and-matter/

## License / contribution

The v0.1 example code is released under the **MIT License** to encourage public testing and extension. It is intentionally independent of existing Ripple source code.
