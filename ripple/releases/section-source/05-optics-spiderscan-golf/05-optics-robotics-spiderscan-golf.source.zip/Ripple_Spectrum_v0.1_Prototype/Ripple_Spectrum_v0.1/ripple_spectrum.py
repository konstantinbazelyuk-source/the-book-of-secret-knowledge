#!/usr/bin/env python3
"""Ripple Spectrum v0.1 -- spatial frequency maps from time-series measurements.

Run --demo for wholly synthetic signals, or --csv for external measurements.
No optical carrier-field, brain-wave, or 'aura' inference is implemented.
"""
import argparse
import csv
import json
import math
from collections import defaultdict
from pathlib import Path

import numpy as np

COLUMNS = ["x_mm", "y_mm", "t_s", "mag_x_uT", "mag_y_uT", "mag_z_uT", "photo_V"]


def simulate_csv(path, fs=200.0, seconds=2.0, seed=41):
    """Synthetic 12 Hz AC Bx and 40 Hz light INTENSITY modulation.
    These are not magnetic components of optical carrier waves.
    """
    rng = np.random.default_rng(seed)
    times = np.arange(round(fs * seconds), dtype=float) / fs
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=COLUMNS)
        writer.writeheader()
        for yi, y in enumerate(np.linspace(-35.0, 35.0, 6)):
            for xi, x in enumerate(np.linspace(-45.0, 45.0, 8)):
                b_spatial = math.exp(-((x - 8.0)**2 + (y + 2.0)**2) / (2 * 19.0**2))
                p_spatial = math.exp(-((x + 11.0)**2 + (y - 12.0)**2) / (2 * 23.0**2))
                bx = (43.0 + 0.80 * b_spatial * np.sin(2*np.pi*12.0*times)
                      + 0.06*np.sin(2*np.pi*60.0*times) + rng.normal(0,0.014,len(times)))
                by = 7.0 + rng.normal(0, 0.01, len(times))
                bz = -13.0 + rng.normal(0, 0.01, len(times))
                light = (1.0 + 0.25 * p_spatial * np.sin(2*np.pi*40.0*times)
                         + rng.normal(0, 0.006, len(times)))
                for t, a, b, c, v in zip(times, bx, by, bz, light):
                    writer.writerow({"x_mm": round(float(x), 5), "y_mm": round(float(y),5),
                                     "t_s": round(float(t),7), "mag_x_uT": float(a),
                                     "mag_y_uT": float(b), "mag_z_uT": float(c), "photo_V":float(v)})
    return path


def load_csv(path):
    groups = defaultdict(list)
    with path.open(newline="", encoding="utf-8") as f:
        r = csv.DictReader(f)
        if not set(COLUMNS).issubset(r.fieldnames or []):
            raise ValueError(f"Input CSV requires columns: {', '.join(COLUMNS)}")
        for lineno, row in enumerate(r, 2):
            try:
                d = {k: float(row[k]) for k in COLUMNS}
            except (TypeError, ValueError) as exc:
                raise ValueError(f"Non-numeric data on line {lineno}") from exc
            if not all(np.isfinite(v) for v in d.values()):
                raise ValueError(f"Nonfinite data on line {lineno}")
            groups[(d['x_mm'],d['y_mm'])].append(d)
    if not groups:
        raise ValueError("Empty CSV")
    return groups


def analyze_site(rows, target_hz, field):
    ts = np.array([r['t_s'] for r in rows], dtype=float)
    values = np.array([r[field] for r in rows], dtype=float)
    if len(ts) < 32:
        raise ValueError("At least 32 samples per site required")
    dt = np.diff(ts)
    if np.any(dt <= 0):
        raise ValueError("Timestamps must be increasing within each site")
    avg_dt = float(np.mean(dt))
    sample_rate = 1.0 / avg_dt
    jitter_ratio = float(np.max(np.abs(dt-avg_dt)) / avg_dt)
    if jitter_ratio > .10:
        raise ValueError(f"Uneven timing (>10%): {jitter_ratio:.1%}. Use a clocked ADC or resample with characterized uncertainty.")
    if not 0 < target_hz < sample_rate / 2:
        raise ValueError(f"Target {target_hz:g} Hz exceeds sampled Nyquist range (<{sample_rate/2:g} Hz)")
    window = np.hanning(len(values))
    spectrum = np.fft.rfft((values - np.mean(values)) * window)
    freq = np.fft.rfftfreq(len(values), d=avg_dt)
    amplitude = 2.0 * np.abs(spectrum) / np.sum(window)
    nearest = int(np.argmin(abs(freq - target_hz)))
    if abs(freq[nearest]-target_hz) > (freq[1]-freq[0]) / 2 + 1e-8:
        raise ValueError("Frequency bin lookup failed")
    return {"amplitude": float(amplitude[nearest]), "sample_rate_Hz":sample_rate,
            "jitter_ratio":jitter_ratio, "frequency_resolution_Hz":float(freq[1]-freq[0]),
            "nearest_bin_Hz":float(freq[nearest]), "frequencies":freq,
            "amplitudes":amplitude}


def make_grid(groups, target, column):
    xs = sorted(set(k[0] for k in groups))
    ys = sorted(set(k[1] for k in groups))
    grid = np.full((len(ys),len(xs)), np.nan)
    site_results = {}
    for (x,y),rows in groups.items():
        d = analyze_site(rows,target,column)
        grid[ys.index(y),xs.index(x)] = d['amplitude']
        site_results[(x,y)] = d
    return xs, ys, grid, site_results


def plot_map(xs, ys, grid, out_file, title, provenance, unit):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(8,5))
    im = ax.imshow(np.ma.masked_invalid(grid), origin="lower", interpolation="nearest",
                   extent=[min(xs)-5,max(xs)+5,min(ys)-5,max(ys)+5],aspect="auto")
    fig.colorbar(im, ax=ax, label=f"Measured-bin amplitude ({unit})")
    ax.set_xlabel("Measurement position x (mm)")
    ax.set_ylabel("Measurement position y (mm)")
    ax.set_title(f"{title}\n{provenance} — grid cells are measurement sites")
    fig.tight_layout()
    fig.savefig(out_file,dpi=160)
    plt.close(fig)


def plot_spectrum(mag_site, photo_site, out_mag, out_photo, provenance):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    for analysis, out, label, unit in [(mag_site,out_mag,"Magnetic Bx","µT"),
                                        (photo_site,out_photo,"Photodiode voltage","V")]:
        fig,ax=plt.subplots(figsize=(8,4))
        ax.plot(analysis['frequencies'],analysis['amplitudes'],linewidth=1.4)
        ax.set_xlim(0,min(100.0,float(analysis['sample_rate_Hz'])/2))
        ax.set_xlabel("Temporal modulation frequency (Hz)")
        ax.set_ylabel(f"Fourier amplitude ({unit})")
        ax.set_title(f"{label} at strongest measurement site — {provenance}")
        ax.grid(True,alpha=.25)
        fig.tight_layout()
        fig.savefig(out,dpi=160)
        plt.close(fig)


def run(input_csv, out_dir, mag_hz, photo_hz, provenance):
    out_dir.mkdir(parents=True,exist_ok=True)
    groups = load_csv(input_csv)
    mx,my,mg,mr = make_grid(groups,mag_hz,"mag_x_uT")
    px,py,pg,pr = make_grid(groups,photo_hz,"photo_V")
    plot_map(mx,my,mg,out_dir/'magnetic_frequency_map.png',f"Magnetic Bx oscillation at {mag_hz:g} Hz",provenance,'µT')
    plot_map(px,py,pg,out_dir/'optical_modulation_map.png',f"Optical intensity modulation at {photo_hz:g} Hz",provenance,'V')
    bestm=max(mr, key=lambda k:mr[k]['amplitude'])
    bestp=max(pr, key=lambda k:pr[k]['amplitude'])
    plot_spectrum(mr[bestm],pr[bestp],out_dir/'magnetic_spectrum.png',out_dir/'optical_spectrum.png',provenance)
    summary={"provenance":provenance,"input":str(input_csv.name),"measurement_sites":len(groups),
             "magnetic_target_Hz":mag_hz,"magnetic_peak_bin_amplitude_uT":mr[bestm]['amplitude'],
             "magnetic_peak_location_mm":list(bestm),"magnetic_sample_rate_Hz":mr[bestm]['sample_rate_Hz'],
             "magnetic_frequency_resolution_Hz":mr[bestm]['frequency_resolution_Hz'],
             "optical_modulation_target_Hz":photo_hz,"optical_modulation_peak_bin_amplitude_V":pr[bestp]['amplitude'],
             "optical_peak_location_mm":list(bestp),"optical_sample_rate_Hz":pr[bestp]['sample_rate_Hz'],
             "optical_frequency_resolution_Hz":pr[bestp]['frequency_resolution_Hz'],
             "notes":["Frequency labels refer to temporal sensor-output oscillations, not optical carrier frequency.",
                      "Magnetic images represent a spatial scan of low-frequency magnetometer measurements, not light's magnetic field.",
                      "CSV sources must be independently calibrated and authenticated before claiming measured fields.",
                      "Maps contain only actual (or simulated) measurement sites; no inferred aura layer is present."]}
    (out_dir/'analysis.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    return summary


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    source=parser.add_mutually_exclusive_group(required=True)
    source.add_argument('--demo',action='store_true',help='Generate and analyze SIMULATED signals')
    source.add_argument('--csv',type=Path,help='Analyze data in the documented CSV format (source unverified)')
    parser.add_argument('--out',type=Path,default=Path('output'))
    parser.add_argument('--mag-hz',type=float,default=12.0)
    parser.add_argument('--photo-hz',type=float,default=40.0)
    args=parser.parse_args()
    csv_path=simulate_csv(args.out/'simulated_scan.csv') if args.demo else args.csv
    summary=run(csv_path,args.out,args.mag_hz,args.photo_hz,
                'SIMULATED DATA' if args.demo else 'IMPORTED CSV — SENSOR ORIGIN UNVERIFIED')
    print(json.dumps(summary,indent=2))

if __name__ == '__main__':
    main()
