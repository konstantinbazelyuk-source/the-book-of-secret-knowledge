#!/usr/bin/env python3
"""Optional real-hardware capture: Raspberry Pi + LIS3MDL + ADS1115 + OPT101.

Not hardware-tested. The conversion schedule uses host timestamps, so jitter and
sensor polling limitations apply. This is NOT an optical carrier frequency probe.
"""
import argparse
import csv
import time
from pathlib import Path

from ripple_spectrum import COLUMNS


def capture(path, x, y, duration, target_rate):
    import board
    import adafruit_lis3mdl
    import adafruit_ads1x15.ads1115 as ADS
    from adafruit_ads1x15.analog_in import AnalogIn

    i2c=board.I2C()
    mag=adafruit_lis3mdl.LIS3MDL(i2c)
    mag.data_rate=adafruit_lis3mdl.Rate.RATE_155_HZ
    adc=ADS.ADS1115(i2c, data_rate=860)
    photo=AnalogIn(adc, ADS.Pin.A0)
    path.parent.mkdir(parents=True,exist_ok=True)
    write_header=not path.exists() or path.stat().st_size == 0
    start=time.perf_counter()
    samples=0
    with path.open('a',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=COLUMNS)
        if write_header: w.writeheader()
        while True:
            planned=start+samples/target_rate
            sleep=planned-time.perf_counter()
            if sleep>0:time.sleep(sleep)
            mx,my,mz=mag.magnetic
            v=photo.voltage
            timestamp=time.perf_counter()-start
            if timestamp>=duration:break
            w.writerow({'x_mm':x,'y_mm':y,'t_s':format(timestamp,'.7f'),
                        'mag_x_uT':mx,'mag_y_uT':my,'mag_z_uT':mz,'photo_V':v})
            samples+=1
    print(f"Captured {samples} records at ({x},{y}) mm; timestamps reflect completion of sequential I2C reads.")

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out',type=Path,default=Path('real_scan.csv'))
    p.add_argument('--x-mm',type=float,required=True)
    p.add_argument('--y-mm',type=float,required=True)
    p.add_argument('--seconds',type=float,default=4.)
    p.add_argument('--rate',type=float,default=25.)
    a=p.parse_args()
    if a.seconds<=1 or a.rate<=5 or a.rate>50:
        p.error('Require --seconds >1 and 5 < --rate <=50 Hz; verify actual timing before analyzing.')
    capture(a.out,a.x_mm,a.y_mm,a.seconds,a.rate)
