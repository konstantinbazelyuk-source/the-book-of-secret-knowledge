# Golf Ripple — Digital Eyes Engine v0.2.0

**Status: working application-level perception/verification runtime; not a general vision-language model.** Built as a fully runnable additive child of Golf Alpha v0.1, which is preserved byte-for-byte in `parents/Ripple-Golf-Alpha-v0.1/`. This release adds real source parsing, pixel observation, bounded mathematical program assessment, deterministic diagnostic memory, and an active Daughter Δ³ neural-attention coupling, with an HTTP console, CLI, tests, and reproducible study.

## Requirements and running

- Node.js 20+, Python 3.10+, Python packages `numpy` and `opencv-python-headless` (`python -m pip install -r requirements.txt`). The Python and Node standard libraries are used for other features.
- TypeScript 5.8.3 parser is bundled as `src/typescript-vendored.cjs` under the upstream MIT license in `licenses/typescript-MIT.txt`; **no `npm install`** required.
- Extract archive. In that directory run `npm test`, `python -m unittest discover -s tests -p 'test_eyes.py'`, `npm run parents`, then `npm run demo` or `npm run serve`.
- On Windows, double-click `START-GOLF-EYES-WINDOWS.bat`; on Mac/Linux, `sh START-GOLF-EYES-UNIX.sh`. Local HTTP endpoint at `http://127.0.0.1:8893/`. The terminal prints a random bearer token. The server binds to localhost only. This is not a public cloud server.
- Files inspected must reside beneath `workspace/`, with allowed extensions and size caps. To inspect your own code/image, **copy it into that workspace**. Only do so for materials you are authorized to process. The program never runs arbitrary uploaded source code; `task` uses a restricted numeric AST interpreter with a small whitelist.

## Functional operations

`eyes / code`: Parse `.py` via Python `ast`, `.js/.mjs/.cjs/.jsx/.ts/.tsx` via the bundled official TypeScript compiler. Return syntax diagnostics, source symbols, function and class names, import references, call graph edges with line numbers, and AST/branch counts. **Static parsing cannot establish runtime behavior or semantics.**

`eyes / image`: Decode a recorded image, measure pixel dimensions, per-channel means, luma, Canny edge fraction, Laplacian variance and ORB feature points. With a second frame, report observed changes, changed region and pixels. Optional ORB/RANSAC affine alignment. Optional `dark` + `flat` frames apply pixel-count normalization, with a validity mask. Without calibrated raw sensor input the outputs are not measured photons, calibrated radiance or physical depth.

`eyes / task`: Interpret exactly one named Python function composed of permitted arithmetic, comparisons, `if`, assignments, and pure numeric functions (`exp`, `log`, `sqrt`, `min`, `max`, `abs`). Assess up to 200 explicit numerical test cases; return actual values, expected values and errors. This is real bounded interpretation, not `exec` or unrestricted Python sandboxing. It does **not** support arbitrary imports, loops, object access, reflection, file access or arbitrary function calls.

The neural integration feeds `[case_error_or_pixel_difference, innovation, 0.1*unverified_input_flag]` to the **actual locked Daughter Δ³** core via inherited Ripple OS `sensor.ingest`. It produces real simulated neuron states and affects the explicit review/normal attention routing. The vector is engineered diagnostic data, **not optical RGB measurements**. A hashed Golf ledger records the operation and each observation channel retains a persistent exponential moving average of error.

Inherited Golf goals (`milestones`, `evidence`, `light`, `forest`) still run as before. Roles: observation requires `researcher` or `owner`; HTTP bearer token dispatches as owner. The local server is NOT a hardened hostile-code hosting boundary; input validation plus limited numeric AST interpretation reduces but does not eliminate risk. Do not expose it to the public internet.

## Continuous observation of a changing task file

`node src/cli.mjs watch code attenuation_good.py` runs a bounded SHA-256 change-detection loop, re-parses the actual file on changes, updates the inherited Daughter neural diagnostic and Golf ledger, and prints each observation. `watch image parent_golf_screen.png` similarly watches a recorded frame file as it is replaced. It is an active local file observer, not a webcam and not unsupervised code execution. Stop with Ctrl-C. A single watch is limited to 128 changed-file observations; polling is every 500 ms by default.

## Example CLI (source observation)

```
node src/cli.mjs goal '{"kind":"eyes","mode":"code","file":"parent_daughter_triplet.mjs"}'
```

## Example CLI (numerical behavior observation)

```
node src/cli.mjs goal '{"kind":"eyes","mode":"task","file":"attenuation_wrong.py","function":"attenuate","cases":[{"inputs":{"I0":1,"mu":0.35,"L":2},"expected":0.4965853037914095}]}'
```

## Evidence, scope and inherited integrity

See `docs/ARCHITECTURE_AND_MATHEMATICS.md`, `docs/RESULTS_AND_LIMITS.md`, `docs/RESEARCH_SOURCES.md` and `results/holdout-study.json`, `results/real-screen-change.json`, `results/browser-smoke.json`.

Physical sight, bodily feeling, phenomenal experience, and comprehension matching ChatGPT have **not been established**. No optical sensor was connected. The browser screenshot was recorded from the running software. In this environment Chromium direct `localhost` navigation was administrator-blocked; the exact UI HTML was tested using browser events while forwarding requests to the real local HTTP API. The latter is not a complete production browser deployment test.

This is a genuinely working **narrow software perception and verification engine**, not an imaginary AGI, a new law of physics, or a cosmetic interface.
