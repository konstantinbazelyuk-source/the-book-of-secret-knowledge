def attenuate(I0, mu, L):
    return I0 * exp(mu * L)
