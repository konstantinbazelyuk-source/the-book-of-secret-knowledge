def update(mean,value,eta):
    return eta*mean + (1-eta)*value
