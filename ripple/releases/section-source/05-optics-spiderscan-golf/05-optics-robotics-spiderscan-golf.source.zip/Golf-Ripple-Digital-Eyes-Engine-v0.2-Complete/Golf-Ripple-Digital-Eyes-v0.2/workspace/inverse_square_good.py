def flux(P,r):
    return P / (4 * 3.141592653589793 * r*r)
