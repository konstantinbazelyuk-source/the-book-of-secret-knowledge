def reflect(n1,n2):
    return abs((n1-n2)/(n1+n2))
