/** Golf Ripple: Goal-oriented Functional Orchestration & Lineage Framework.
 * Child of Ripple OS v0.1. Parent files are read-only and SHA-locked.
 * All science claims carry explicit evidence classes.
 */
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {RippleOS} from '../../parents/Ripple-OS-Engine-Beta-v0.1/src/engine/runtime.mjs';
import {RippleNeuron} from './original-reference.mjs';
import {GolfLedger,digest} from './ledger.mjs';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../..');
const MILESTONES=JSON.parse(fs.readFileSync(path.join(ROOT,'docs/MILESTONES.json'),'utf8'));
const LOCKS=JSON.parse(fs.readFileSync(path.join(ROOT,'docs/COMPONENT_LOCKS.json'),'utf8'));
const PARENT_FILES=JSON.parse(fs.readFileSync(path.join(ROOT,'docs/PARENT_FILES.json'),'utf8'));
const {createHash}=await import('node:crypto');
const hashFile=filename=>createHash('sha256').update(fs.readFileSync(filename)).digest('hex');
export function verifySourceLocks(){const errors=[];for(const x of [...LOCKS,...PARENT_FILES]){const p=path.resolve(ROOT,x.path);if(!p.startsWith(ROOT+path.sep)||!fs.existsSync(p)||hashFile(p)!==x.sha256)errors.push(x.key||x.path);}return{ok:errors.length===0,verified:LOCKS.length+PARENT_FILES.length,activeComponents:LOCKS.length,archivedFiles:PARENT_FILES.length,failures:errors};}
const validNumber=(v,lo,hi,key)=>{if(typeof v!=='number'||!Number.isFinite(v)||v<lo||v>hi)throw Error(`GOLF_INPUT: ${key} outside [${lo},${hi}]`);return v;};
function exact(o,allowed){if(!o||typeof o!=='object'||Array.isArray(o)||Object.getPrototypeOf(o)!==Object.prototype||Object.keys(o).some(k=>!allowed.includes(k)))throw Error('GOLF_SCHEMA: unsupported or missing input object');}
const RGB=rgb=>{if(!Array.isArray(rgb)||rgb.length!==3)throw Error('GOLF_INPUT: three RGB channels required');return rgb.map((v,i)=>validNumber(v,0,1,'RGB '+i));};
const boundedQuery=q=>{if(typeof q!=='string'||q.length<2||q.length>500)throw Error('GOLF_INPUT: query must be 2..500 characters');return q;};
const roles={observer:['milestones','evidence'],researcher:['milestones','evidence','light','forest'],owner:['milestones','evidence','light','forest']};
export class GolfRuntime{
 constructor({dataDir=path.join(process.cwd(),'golf-data'),maxSteps=1200}={}){if(!Number.isInteger(maxSteps)||maxSteps<1||maxSteps>2000)throw Error('maxSteps out of bounds');this.os=new RippleOS({dataDir:path.join(dataDir,'os')});this.ledger=new GolfLedger(path.join(dataDir,'golf'));this.maxSteps=maxSteps;this.chain=Promise.resolve();this.executions=0;}
 status(){return{release:'Golf Ripple 0.1.0-alpha.1',scope:'bounded application-level orchestrator; no general intelligence',parent:this.os.status().version,milestones:MILESTONES.length,sourceLocks:verifySourceLocks(),goals:this.executions,ledger:{records:this.ledger.sequence,head:this.ledger.head},evidence:'simulation or document-derived only, no verified hardware measurements'};}
 run(goal,role='observer'){
  const op=async()=>{exact(goal,['kind','query','phases','coefficient','path','dt','sourceKind','seed','width','height','ticks']);if(!['observer','researcher','owner'].includes(role))throw Error('GOLF_DENIED: unknown role');if(typeof goal.kind!=='string'||!(roles[role]||[]).includes(goal.kind))throw Error('GOLF_DENIED: role cannot run goal');
   let result;let classification;const started=performance.now();
   switch(goal.kind){
    case 'milestones':exact(goal,['kind']);result={milestones:MILESTONES,lockedComponents:LOCKS.map(x=>({key:x.key,sha256:x.sha256})),sourceLocks:verifySourceLocks()};classification='SOURCE_DERIVED';break;
    case 'evidence':exact(goal,['kind','query']);result=await this.evidence(boundedQuery(goal.query));classification='RETRIEVED_SOURCE_NOT_ANSWER';break;
    case 'light':exact(goal,['kind','phases','coefficient','path','dt','sourceKind']);result=await this.light(goal);classification=goal.sourceKind==='recorded-unverified'?'EXTERNAL_UNVERIFIED_SIGNALS':'SYNTHETIC_NUMERICAL';break;
    case 'forest':exact(goal,['kind','seed','width','height','ticks']);result=await this.forest(goal);classification='SYNTHETIC_COLONY';break;
    default:throw Error('GOLF_SCHEMA: unknown goal');
   }
   const gate=this.gate(goal.kind,result,classification);
   const record=this.ledger.append({kind:goal.kind,role,requestDigest:digest(goal),evidenceClass:classification,acceptance:gate.state,durationMs:+(performance.now()-started).toFixed(3)});
   this.executions++;
   return {goal:goal.kind,evidenceClass:classification,acceptance:gate,record,result};
  };
  const pending=this.chain.then(op);this.chain=pending.then(()=>{},()=>{});return pending;
 }
 gate(kind,result,evidenceClass){
  if(kind==='milestones')return{state:result.sourceLocks.ok?'VERIFIED_SOURCE_HASHES':'REJECTED_SOURCE_TAMPER',promotion:'NO_AUTOMATIC_PROMOTION',reason:'All milestone sources present and checksummed; historical numeric claims are reported from inherited research.'};
  if(kind==='evidence')return{state:result.review?'REVIEW_REQUIRED':'SOURCE_ROUTE_ONLY',promotion:'NO_AUTOMATIC_PROMOTION',reason:result.review?'No usable or unambiguous lexical evidence':'Retrieved source location; factual conclusions still require review'};
  if(kind==='light')return{state:evidenceClass==='SYNTHETIC_NUMERICAL'?'PASSED_NUMERICAL_EXECUTION':'PHYSICAL_VALIDATION_REQUIRED',promotion:'NO_AUTOMATIC_PROMOTION',reason:'Original and Daughter share exactly the same bounded optical input; no recorded-physical claims are inferred.'};
  if(kind==='forest')return{state:'PASSED_SYNTHETIC_EXECUTION',promotion:'NO_AUTOMATIC_PROMOTION',reason:'Seeded synthetic map; coverage is not a real navigation performance measure.'};
 }
 async evidence(query){const output=(await this.os.submit({service:'evidence.assess',payload:{query,mode:'bm25'}},'observer')).result;
  const review=output.evidenceState!=='1';return{source:output.source,documentId:output.doc,sourceHash:output.sha256,passage:output.passage,path:output.path,symbols:output.symbols,alternatives:output.alternatives,review,note:review?'No reliable match: review rather than claim an answer':'Retrieved source passage, not a generated answer',model:'Locked assessment BM25 default; trained route underperforms (13/32 vs 23/32)'};}
 async light(goal){const phases=goal.phases;if(!Array.isArray(phases)||phases.length<1||phases.length>12)throw Error('GOLF_BUDGET: 1..12 phases required');
  const steps=phases.map(p=>{exact(p,['rgb','steps']);const rgb=RGB(p.rgb);if(!Number.isInteger(p.steps)||p.steps<1||p.steps>this.maxSteps)throw Error('GOLF_BUDGET: invalid phase steps');return{rgb,steps:p.steps};});const total=steps.reduce((s,p)=>s+p.steps,0);if(total>this.maxSteps)throw Error('GOLF_BUDGET: total model steps exceeded');
  const mu=validNumber(goal.coefficient??0,0,10,'coefficient'),L=validNumber(goal.path??0,0,10,'path'),dt=validNumber(goal.dt??.05,.005,.1,'dt');
  if(!['synthetic','recorded-unverified'].includes(goal.sourceKind))throw Error('GOLF_INPUT: declared sourceKind required');
  await this.os.submit({service:'neuron.reset',payload:{}},'researcher');const original=new RippleNeuron(),records=[];
  for(let k=0;k<steps.length;k++){
   const phase=steps[k],attenuated=[];for(let channel=0;channel<3;channel++){
    const r=(await this.os.submit({service:'optics.attenuate',payload:{incident:phase.rgb[channel],coefficient:mu,path:L}},'researcher')).result;attenuated.push(r.intensity);
   }
   let refEvents=0,daughterEvents=0,last=null;
   for(let i=0;i<phase.steps;i+=32){const n=Math.min(32,phase.steps-i);for(let j=0;j<n;j++)refEvents+=original.step(attenuated,dt).count;
    last=(await this.os.submit({service:'sensor.ingest',payload:{sourceId:'golf:light',kind:goal.sourceKind,samples:Array.from({length:n},()=>({rgb:attenuated,dt}))}},'researcher')).result;daughterEvents+=last.spikes;
   }
   const seconds=phase.steps*dt;
   records.push({phase:k+1,rawRGB:phase.rgb,attenuatedRGB:attenuated,seconds,referenceV01:{events:refEvents,eventsPerSecond:refEvents/seconds},daughterTriplet:{events:daughterEvents,eventsPerSecond:daughterEvents/seconds,latestLayers:last.latestLayers}});
  }
  const errRef=records.reduce((v,x)=>v+Math.abs(x.referenceV01.eventsPerSecond-1),0)/records.length,errDaughter=records.reduce((v,x)=>v+Math.abs(x.daughterTriplet.eventsPerSecond-1),0)/records.length;
  return{lightModel:'Beer–Lambert, same attenuation applied to both original Ripple and Daughter triplet',coefficient:mu,path:L,dt,steps:total,sourceKind:goal.sourceKind,phases:records,meanAbsoluteRateError:{original:errRef,daughter:errDaughter,target:1},comparison:errDaughter<errRef?'daughter smaller error on these phases':errRef<errDaughter?'original smaller error on these phases':'tied on these phases',confidence:'CASE-SPECIFIC; no statistical generalization',noAutomaticLearning:true};
 }
 async forest(goal){const seed=goal.seed??1731,width=goal.width??20,height=goal.height??14,ticks=goal.ticks??12;
  if(!Number.isInteger(seed)||seed<0||seed>4294967295)throw Error('GOLF_INPUT seed invalid');
  for(const [v,name] of [[width,'width'],[height,'height']])if(!Number.isInteger(v)||v<8||v>56)throw Error('GOLF_INPUT '+name+' invalid');
  if(!Number.isInteger(ticks)||ticks<1||ticks>256)throw Error('GOLF_BUDGET ticks 1..256');
  const before=(await this.os.submit({service:'colony.create',payload:{seed,width,height,policy:'hybrid-beta'}},'researcher')).result;
  let after=before;for(let left=ticks;left>0;left-=16){after=(await this.os.submit({service:'colony.step',payload:{ticks:Math.min(16,left)}},'researcher')).result;}
  const trace=(await this.os.submit({service:'colony.record',payload:{}},'researcher')).result;
  return{seed,width,height,ticks,beforeCoverage:before.coverage,afterCoverage:after.coverage,trace:trace.paths,summary:trace.summary,lineage:trace.lineage,coreHash:trace.coreHash,evidence:'SEEDED SOFTWARE WORLD, not surveyed physical forest'};
 }
}
