def update(mean,value,eta):
    return (1-eta)*mean + eta*value
