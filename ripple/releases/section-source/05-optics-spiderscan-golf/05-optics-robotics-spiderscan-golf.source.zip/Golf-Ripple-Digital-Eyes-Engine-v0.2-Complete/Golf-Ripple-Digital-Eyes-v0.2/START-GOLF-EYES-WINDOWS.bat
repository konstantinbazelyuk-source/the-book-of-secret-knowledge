@echo off
cd /d "%~dp0"
where node >NUL 2>&1 || (echo Node.js 20+ required & pause & exit /b 1)
where python >NUL 2>&1 || (echo Python 3.10+ required & pause & exit /b 1)
set GOLF_PYTHON=python
node src/cli.mjs serve
pause
