#!/usr/bin/env python3
import json,subprocess,time,os,re,requests
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
p=subprocess.Popen(['node','src/cli.mjs','serve'],cwd=ROOT,env={**os.environ,'GOLF_EYES_PORT':'8899','GOLF_EYES_DATA':str(ROOT/'results'/'browser-state')},stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
report={'browser': 'chromium', 'status':'not-tested'}
try:
    first=p.stdout.readline().strip(); second=p.stdout.readline().strip()
    if '8899' not in first or 'Access token:' not in second:raise RuntimeError('server startup unexpected '+first+' '+second)
    token=second.split('Access token:')[-1].strip()
    with sync_playwright() as pw:
        browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
        for tag,w,h in [('desktop',1280,900),('phone',400,840)]:
            page=browser.new_page(viewport={'width':w,'height':h})
            errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
            # The execution environment blocks Chromium navigation to loopback. Load the
            # exact saved UI content while proxying fetch to the LIVE Node HTTP service.
            # API results are real; this test makes no claim about navigation.
            def live_post(auth, raw):
                r=requests.post('http://127.0.0.1:8899/api/goal',data=raw,headers={'Authorization':auth,'Content-Type':'application/json'},timeout=12)
                return {'status':r.status_code,'json':r.json()}
            page.expose_function('livePost',live_post)
            page.set_content((ROOT/'web'/'index.html').read_text(),wait_until='load')
            page.evaluate('''() => { window.fetch = async (url,opts) => { const response = await window.livePost(opts.headers.Authorization,opts.body); return {ok:response.status>=200&&response.status<300,json:async()=>response.json}; }; }''')
            page.fill('#token',token)
            page.select_option('#mode','task')
            page.fill('#file','attenuation_wrong.py')
            page.fill('#cases','[{"inputs":{"I0":1,"mu":0.35,"L":2},"expected":0.4965853037914095}]')
            if tag=='desktop':page.screenshot(path=str(ROOT/'workspace'/'golf_eyes_before.png'),full_page=False)
            page.click('#execute')
            page.locator('#state').get_by_text('Response returned').wait_for(timeout=12000)
            response=page.locator('#result').inner_text()
            assert 'TASK_FAILED_EVIDENCE' in response and 'neuronTriggered' in response and not errors, (tag,response[:150],errors)
            if tag=='desktop':page.screenshot(path=str(ROOT/'workspace'/'golf_eyes_after.png'),full_page=False)
            report[tag]={'ran':True,'exactSavedHTML':True,'realNodeAPI':True,'directBrowserNavigationBlocked':True,'incorrectPhysicsDetected':True,'jsErrors':errors,'resultLength':len(response)}
            page.close()
        browser.close()
    report['status']='passed'
except Exception as e:
    report['status']='blocked-or-failed';report['error']=str(e)[:400]
finally:
    p.terminate()
    try:p.wait(timeout=3)
    except: p.kill()
    (ROOT/'results'/'browser-smoke.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))
    if report['status']!='passed':raise SystemExit(1)
