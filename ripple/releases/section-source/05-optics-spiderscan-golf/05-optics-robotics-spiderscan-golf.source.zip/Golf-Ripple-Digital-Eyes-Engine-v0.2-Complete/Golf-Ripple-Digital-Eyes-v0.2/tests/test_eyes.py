import importlib.util
import math
import os
from pathlib import Path
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('eyes',ROOT/'src'/'eyes.py');eyes=importlib.util.module_from_spec(spec);spec.loader.exec_module(eyes)

class EyeTests(unittest.TestCase):
    def test_good_ast(self):
        r=eyes.python_observe('def f(x):\n    return x+1\n')
        self.assertTrue(r['syntaxValid']);self.assertEqual(r['symbols'][0]['name'],'f')
    def test_reject_syntax(self):
        self.assertFalse(eyes.python_observe('def ??')['syntaxValid'])
    def test_js_ast_parent(self):
        r=eyes.js_observe(ROOT/'workspace'/'parent_daughter_triplet.mjs')
        self.assertTrue(r['syntaxValid']);self.assertGreater(r['complexity']['astNodes'],2000)
    def test_js_ast_error(self):
        with tempfile.NamedTemporaryFile(suffix='.js',mode='w') as f:
            f.write('function () {');f.flush()
            self.assertFalse(eyes.js_observe(Path(f.name))['syntaxValid'])
    def test_ast_correct(self):
        self.assertAlmostEqual(eyes.restricted_function('def attenuation(i,m,l):\n return i * exp(-m*l)','attenuation',{'i':1,'m':.35,'l':2}),math.exp(-.7))
    def test_ast_wrong(self):
        r=eyes.assess_task('def f(I0,mu,L):return I0*exp(mu*L)','f',[{'inputs':{'I0':1,'mu':.35,'L':2},'expected':math.exp(-.7)}])
        self.assertEqual(r['failed'],1)
    def test_ast_branch(self):
        r=eyes.restricted_function('def f(x):\n if x>0:\n  return x\n return -x','f',{'x':-2})
        self.assertEqual(r,2)
    def test_refuse_import(self):
        with self.assertRaises(ValueError):eyes.restricted_function('def f(x):\n import os\n return x','f',{'x':1})
    def test_refuse_injected_call(self):
        with self.assertRaises(ValueError):eyes.restricted_function('def f(x):return __import__("os")','f',{'x':1})
    def test_refuse_unsafe_attribute(self):
        with self.assertRaises(ValueError):eyes.restricted_function('def f(x):return x.__class__','f',{'x':1})
    def test_refuse_loops(self):
        with self.assertRaises(ValueError):eyes.restricted_function('def f(x):\n for i in range(100): pass\n return x','f',{'x':1})
    def test_refuse_power_explosion(self):
        with self.assertRaises(ValueError):eyes.restricted_function('def f(x):return 10**100','f',{'x':1})
    def test_path_traversal(self):
        with self.assertRaises(ValueError):eyes.check_workspace(ROOT/'workspace','../src/eyes.py',{'.py'})
    def test_path_symlink_escape(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp);(p/'link.py').symlink_to(ROOT/'src'/'eyes.py')
            with self.assertRaises(ValueError):eyes.check_workspace(p,'link.py',{'.py'})
    def test_measured_image(self):
        r=eyes.vision(ROOT/'workspace'/'parent_golf_screen.png')
        self.assertGreater(r['width'],400);self.assertGreater(r['edgeFraction'],0.001)
    def test_synthetic_changed_region(self):
        import cv2,numpy as np
        with tempfile.TemporaryDirectory() as t:
            a=np.zeros((120,120,3),dtype='uint8');b=a.copy();b[20:45,30:60]=255
            p=Path(t);cv2.imwrite(str(p/'a.png'),a);cv2.imwrite(str(p/'b.png'),b)
            r=eyes.vision(p/'a.png',p/'b.png')
            self.assertEqual(r['comparison']['changedPixels'],25*30)
            self.assertEqual(r['comparison']['boundsXYXY'],[30,20,60,45])
    def test_orb_ransac_translation(self):
        import cv2,numpy as np
        with tempfile.TemporaryDirectory() as t:
            p=Path(t);rng=np.random.default_rng(88319)
            a=rng.integers(0,256,size=(240,320,3),dtype='uint8')
            M=np.float32([[1,0,9],[0,1,-7]])
            b=cv2.warpAffine(a,M,(320,240))
            cv2.imwrite(str(p/'a.png'),a);cv2.imwrite(str(p/'b.png'),b)
            no=eyes.vision(p/'a.png',p/'b.png')
            yes=eyes.vision(p/'a.png',p/'b.png',align=True)
            self.assertGreaterEqual(yes['comparison']['inliers'],5)
            self.assertLess(yes['comparison']['changedFraction'],no['comparison']['changedFraction']*.25)
            self.assertAlmostEqual(yes['comparison']['transform'][0][2],-9,delta=2)
            self.assertAlmostEqual(yes['comparison']['transform'][1][2],7,delta=2)
    def test_dark_flat_arithmetic(self):
        import cv2,numpy as np
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)
            for v,n in [(40,'dark'),(200,'flat'),(120,'sample')]:
                cv2.imwrite(str(p/(n+'.png')),np.full((16,16,3),v,'uint8'))
            r=eyes.vision(p/'sample.png',dark=p/'dark.png',flat=p/'flat.png')
            self.assertAlmostEqual(r['darkFlatCorrection']['meanRelativeSignalRGB'][0],.5)
    def test_flat_rejects_zero_range(self):
        import cv2,numpy as np
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)
            for n in ['dark','flat','sample']:cv2.imwrite(str(p/(n+'.png')),np.full((16,16,3),40,'uint8'))
            with self.assertRaises(ValueError):eyes.vision(p/'sample.png',dark=p/'dark.png',flat=p/'flat.png')
    def test_syntax_vs_semantics(self):
        self.assertTrue(eyes.python_observe('def f(x): return x*x')['syntaxValid'])
        self.assertEqual(eyes.assess_task('def f(x): return x*x','f',[{'inputs':{'x':3},'expected':6}])['failed'],1)

if __name__=='__main__': unittest.main()
