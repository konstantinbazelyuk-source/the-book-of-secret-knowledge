import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';import {createHash} from 'node:crypto';
import {GolfEyesRuntime} from '../src/eyes-runtime.mjs';import {serve} from '../src/server.mjs';
import {verifySourceLocks} from '../parents/Ripple-Golf-Alpha-v0.1/src/golf/engine.mjs';
const root=new URL('../',import.meta.url);
const tmp=()=>fs.mkdtempSync(path.join(os.tmpdir(),'golf-eyes-test-'));
const make=(dir=tmp())=>new GolfEyesRuntime({dataDir:dir});
const task=file=>({kind:'eyes',mode:'task',file,function:'attenuate',cases:[{inputs:{I0:1,mu:.35,L:2},expected:Math.exp(-.7)}]});
const code=file=>({kind:'eyes',mode:'code',file});
test('untouched parent Golf has intact lock hashes',()=>{assert.equal(verifySourceLocks().ok,true);assert.equal(verifySourceLocks().verified,115)});
test('original v0.1 fixed sha untouched',()=>{const p=new URL('../parents/Ripple-Golf-Alpha-v0.1/parents/Ripple-OS-Engine-Beta-v0.1/parents/Ripple-Daughter-Triplet-v3.1/vault/parent-ripple-v0.1.js',import.meta.url);assert.equal(createHash('sha256').update(fs.readFileSync(p)).digest('hex'),'dba6639b7902f0c702d15fff588524629f3754cfd72d7b704f22a76b78960ee3')});
test('actual daughter JS source inspected with AST',async()=>{const r=await make().run(code('parent_daughter_triplet.mjs'),'owner');assert.equal(r.observation.observation.syntaxValid,true);assert(r.observation.observation.symbols.some(s=>s.name==='DaughterTripletNeuron'));assert(r.observation.observation.complexity.astNodes>2000);assert.equal(r.acceptance.state,'STRUCTURE_OBSERVED');});
test('measured input screenshot has nonzero visual edges',async()=>{const r=await make().run({kind:'eyes',mode:'image',file:'parent_golf_screen.png'},'researcher');assert(r.observation.observation.edgeFraction>0);assert.equal(r.acceptance.state,'PIXEL_OBSERVED_NO_SEMANTIC_GROUND_TRUTH');});
test('good function has measured numerical success',async()=>{const r=await make().run(task('attenuation_good.py'),'researcher');assert.equal(r.observation.observation.passed,1);assert.equal(r.acceptance.state,'TASK_CASES_PASSED');});
test('sign-error formula detected and excites actual Daughter neuron',async()=>{const r=await make().run(task('attenuation_wrong.py'),'researcher');assert.equal(r.observation.observation.failed,1);assert.equal(r.neuron.core,'locked Daughter Δ³ via Ripple OS sensor.ingest');assert(r.neuron.spikes>0);assert.equal(r.acceptance.state,'TASK_FAILED_EVIDENCE');});
test('observer cannot read local source files',async()=>{await assert.rejects(make().run(code('parent_daughter_triplet.mjs'),'observer'),/DENIED/)});
test('path traversal is refused by child',async()=>{await assert.rejects(make().run(code('../src/eyes.py'),'owner'),/access denied/)});
test('unsupported file type refused',async()=>{await assert.rejects(make().run(code('parent_golf_screen.png'),'owner'),/access denied/)});
test('no arbitrary goal or input fields',async()=>{await assert.rejects(make().run({kind:'eyes',mode:'code',file:'attenuation_good.py',eval:'evil'},'owner'),/EYES_SCHEMA/)});
test('feedback state persists restart with prior mean error',async()=>{const dir=tmp(),one=make(dir);const a=await one.run(task('attenuation_wrong.py'),'owner');assert.equal(a.predictive.updatedMeanError,.6);const two=make(dir),b=await two.run(task('attenuation_good.py'),'owner');assert.equal(b.predictive.priorMeanError,.6);assert.equal(b.predictive.updatedMeanError,.48);});
test('ledger chains evidence records',async()=>{const g=make();await g.run(code('attenuation_good.py'),'owner');await g.run(task('attenuation_wrong.py'),'owner');assert.equal(g.ledger.verify(),2)});
test('legacy milestone goal still works',async()=>{const r=await make().run({kind:'milestones'},'observer');assert.equal(r.result.milestones.length,12);assert.equal(r.acceptance.state,'VERIFIED_SOURCE_HASHES');});
test('HTTP local token and actual program goal',async()=>{const g=make(),h=await serve(g,{port:0,token:'test-only-token'});try{const root='http://127.0.0.1:'+h.address.port;assert.equal((await fetch(root+'/')).status,200);const req=token=>fetch(root+'/api/goal',{method:'POST',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},body:JSON.stringify({goal:task('attenuation_good.py')})});assert.equal((await req('wrong')).status,401);const r=await req('test-only-token');assert.equal(r.status,200);assert.equal((await r.json()).acceptance.state,'TASK_CASES_PASSED')}finally{await h.close()}});
test('work queue accepts concurrent observations serially',async()=>{const g=make(),results=await Promise.all([g.run(code('attenuation_good.py'),'owner'),g.run(task('attenuation_good.py'),'owner'),g.run(code('parent_golf_engine.mjs'),'owner')]);assert.deepEqual(results.map(r=>r.record.sequence),[1,2,3]);});
import {startEyesWatch} from '../src/watch.mjs';
test('active watcher responds to a real changed source file and records observation',async()=>{
 const workspace=tmp(),dataDir=tmp(),file='watched.py';fs.writeFileSync(path.join(workspace,file),'def f(x): return x+1\n');
 const runtime=new GolfEyesRuntime({workspace,dataDir});
 let seen=[];let watcher;
 try{
  watcher=startEyesWatch({runtime,file,intervalMs:200,maxEvents:2,onObservation:x=>seen.push(x)});
  const wait=async n=>{for(let i=0;i<80&&seen.filter(x=>x.sourceHash).length<n;i++)await new Promise(r=>setTimeout(r,50));assert.equal(seen.filter(x=>x.sourceHash).length,n)};
  await wait(1);fs.writeFileSync(path.join(workspace,file),'def f(x): return x+2\n');await wait(2);
  assert.equal(runtime.ledger.verify(),2);assert.equal(seen[1].changedSincePrevious,true);
 }finally{watcher?.stop();}
});
