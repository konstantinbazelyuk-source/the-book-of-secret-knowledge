import http from 'node:http';
import fs from 'node:fs';
import {randomBytes} from 'node:crypto';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
export async function serve(golf,{port=8893,token=randomBytes(24).toString('base64url')}={}){
 if(!Number.isInteger(port)||port<0||port>65535)throw Error('bad port');
 const html=fs.readFileSync(path.join(ROOT,'web/index.html'));
 const server=http.createServer(async(req,res)=>{
  const json=(status,o)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(o));};
  if(req.method==='GET'&&req.url==='/'){res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Content-Security-Policy':"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'",'X-Content-Type-Options':'nosniff'});return res.end(html);}
  if(req.method!=='POST'||req.url!=='/api/goal')return json(404,{error:'not found'});
  if(req.headers.authorization!==`Bearer ${token}`)return json(401,{error:'token required'});
  if(!(req.headers['content-type']||'').startsWith('application/json'))return json(415,{error:'application/json required'});
  try{
   let raw='',len=0;for await(const chunk of req){len+=chunk.length;if(len>25000){req.destroy();return;}raw+=chunk;}
   const input=JSON.parse(raw);if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(k=>k!=='goal'))throw Error('only goal allowed');
   const result=await golf.run(input.goal,'owner');return json(200,result);
  }catch(e){return json(400,{error:String(e.message||e).slice(0,500)});}
 });
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve)});
 return {server,token,address:server.address(),close:()=>new Promise(resolve=>server.close(resolve))};
}
