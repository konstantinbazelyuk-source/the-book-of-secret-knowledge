'use strict';
// Bundled official TypeScript AST parser, MIT licensed: structural observation only.
const ts = require('./typescript-vendored.cjs');
const fs = require('node:fs');
const name=process.argv[2];
if(!name)process.exit(2);
const text=fs.readFileSync(name,'utf8');
const ext=name.split('.').pop().toLowerCase();
const kind=ext==='tsx'?ts.ScriptKind.TSX:ext==='ts'?ts.ScriptKind.TS:ext==='jsx'?ts.ScriptKind.JSX:ts.ScriptKind.JS;
const tree=ts.createSourceFile(name,text,ts.ScriptTarget.ES2022,true,kind);
const diagnostics=(tree.parseDiagnostics||[]).slice(0,30).map(d=>({line:tree.getLineAndCharacterOfPosition(d.start||0).line+1,column:tree.getLineAndCharacterOfPosition(d.start||0).character+1,message:ts.flattenDiagnosticMessageText(d.messageText,' ')}));
const symbols=[],calls=[],imports=[],edges=[];let branches=0, count=0, stack=[];
function visit(node){
 count++;if(count>80000)throw Error('AST node budget exceeded');
 const loc=tree.getLineAndCharacterOfPosition(node.getStart(tree)).line+1;
 let push=null;
 if(ts.isFunctionDeclaration(node)||ts.isMethodDeclaration(node)||ts.isClassDeclaration(node)||ts.isArrowFunction(node)&&ts.isVariableDeclaration(node.parent)){
   const label=node.name?.getText(tree)|| (ts.isArrowFunction(node)?node.parent.name?.getText(tree):null)||'<anonymous>';
   push=label;symbols.push({kind:ts.isClassDeclaration(node)?'class':'function',name:[...stack,label].join('.'),line:loc,end:tree.getLineAndCharacterOfPosition(node.getEnd()).line+1});
 }
 if(ts.isImportDeclaration(node)||ts.isExportDeclaration(node)&&node.moduleSpecifier){if(node.moduleSpecifier)imports.push(node.moduleSpecifier.getText(tree));}
 if(ts.isCallExpression(node)){
  const n=node.expression.getText(tree).slice(0,100);calls.push({name:n,line:loc});if(stack.length)edges.push({from:stack.join('.'),to:n,line:loc});
 }
 if(ts.isIfStatement(node)||ts.isForStatement(node)||ts.isWhileStatement(node)||ts.isConditionalExpression(node)||ts.isCaseClause(node))branches++;
 if(push)stack.push(push);ts.forEachChild(node,visit);if(push)stack.pop();
}
visit(tree);
process.stdout.write(JSON.stringify({syntaxValid:diagnostics.length===0,diagnostics,symbols:symbols.slice(0,400),calls:calls.slice(0,400),imports:imports.slice(0,100),edges:edges.slice(0,400),complexity:{astNodes:count,branches,functions:symbols.filter(s=>s.kind==='function').length,lines:text.split(/\r?\n/).length}}));
