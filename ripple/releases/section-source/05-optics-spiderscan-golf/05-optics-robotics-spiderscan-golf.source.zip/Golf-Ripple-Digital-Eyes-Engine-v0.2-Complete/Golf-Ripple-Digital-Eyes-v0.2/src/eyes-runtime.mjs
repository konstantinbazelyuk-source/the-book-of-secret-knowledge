/** Real Golf Digital Eyes v0.2 child runtime. Original Golf code resides unchanged in parents/. */
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {GolfRuntime,verifySourceLocks} from '../parents/Ripple-Golf-Alpha-v0.1/src/golf/engine.mjs';
import {digest} from '../parents/Ripple-Golf-Alpha-v0.1/src/golf/ledger.mjs';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const clamp=v=>Math.min(1,Math.max(0,v));
const exact=(obj,keys)=>{if(!obj||typeof obj!=='object'||Array.isArray(obj)||Object.keys(obj).some(x=>!keys.includes(x)))throw Error('EYES_SCHEMA: unrecognized input field');};
function finite01(x){return typeof x==='number'&&Number.isFinite(x)?clamp(x):0;}
function atomic(file,obj){const tmp=file+'.tmp';fs.writeFileSync(tmp,JSON.stringify(obj,null,2));fs.renameSync(tmp,file);}
function perceptionNumbers(result){
 const o=result.observation;
 if(result.mode==='task')return {error:1-o.accuracy,novelty:0,uncertainty:0,knownTask:true};
 if(result.mode==='code')return {error:o.syntaxValid?0:1,novelty:finite01((o.complexity?.branches??0)/60),uncertainty:1,knownTask:false};
 if(result.mode==='image')return {error:finite01(o.comparison?.changedFraction??0),novelty:finite01((o.orbKeypoints??0)/400),uncertainty:1,knownTask:false};
 throw Error('unsupported perception output');
}
export class GolfEyesRuntime extends GolfRuntime{
 constructor({dataDir=path.join(process.cwd(),'golf-eyes-data'),workspace=path.join(ROOT,'workspace'),python=process.env.GOLF_PYTHON||'python3'}={}){
  super({dataDir});this.workspace=path.resolve(workspace);this.python=python;
  if(!fs.existsSync(this.workspace)||!fs.statSync(this.workspace).isDirectory())throw Error('workspace must exist');
  this.statePath=path.join(dataDir,'eyes-adaptation.json');this.state=fs.existsSync(this.statePath)?JSON.parse(fs.readFileSync(this.statePath,'utf8')):{version:1,channels:{}};
  for(const [key,val] of Object.entries(this.state.channels||{}))if(!['code','image','task'].includes(key)||typeof val.meanError!=='number'||!Number.isFinite(val.meanError)||!Number.isInteger(val.n))throw Error('EYES_STATE: invalid state');
 }
 status(){return {...super.status(),perception:{version:'Golf Digital Eyes 0.2.0',codeLanguages:['Python','JavaScript','TypeScript'],imageInput:'recorded PNG/JPEG/WebP/BMP frames',taskExecution:'bounded Python AST interpreter',workspace:this.workspace,channels:this.state.channels,capability:'observes source syntax, pixels and checked numeric outcomes; DOES NOT establish experience or general comprehension'}};}
 run(goal,role='observer'){
  if(goal?.kind!=='eyes')return super.run(goal,role);
  // serialize with base Golf's goal chain and audit ledger. Input goes to stdin, never shell.
  const work=async()=>{
    if(!['researcher','owner'].includes(role))throw Error('EYES_DENIED: only researcher or owner');
    exact(goal,['kind','mode','file','second','function','cases','align','dark','flat']);
    if(!['code','image','task'].includes(goal.mode))throw Error('EYES_SCHEMA: mode');
    const payload={mode:goal.mode,file:goal.file,...(goal.second!==undefined?{second:goal.second}:{}),...(goal.align!==undefined?{align:goal.align}:{}),...(goal.dark!==undefined?{dark:goal.dark}:{}),...(goal.flat!==undefined?{flat:goal.flat}:{}),...(goal.function!==undefined?{function:goal.function}:{}),...(goal.cases!==undefined?{cases:goal.cases}:{})};
    const serialized=JSON.stringify(payload);
    if(Buffer.byteLength(serialized)>24000)throw Error('EYES_BUDGET: 24000B maximum');
    const started=performance.now();
    const vision=await new Promise((resolve,reject)=>{
      const child=import('node:child_process').then(({spawn})=>{
        const p=spawn(this.python,[path.join(ROOT,'src','eyes.py'),this.workspace],{cwd:ROOT,stdio:['pipe','pipe','pipe'],windowsHide:true});
        let out='',err='',size=0,finished=false;
        const timer=setTimeout(()=>{p.kill('SIGKILL');if(!finished){finished=true;reject(Error('EYES_TIMEOUT: worker exceeded 12 seconds'));}},12000);
        p.stdout.on('data',b=>{size+=b.length;if(size>1_000_000){p.kill('SIGKILL');return;}out+=b.toString('utf8');});
        p.stderr.on('data',b=>{err+=b.toString('utf8').slice(0,300)});
        p.on('error',e=>{clearTimeout(timer);if(!finished){finished=true;reject(e);}});
        p.on('close',code=>{clearTimeout(timer);if(finished)return;finished=true;try{const value=JSON.parse(out);if(code!==0||!value.ok)reject(Error('EYES_OBSERVATION: '+(value.error||err||'worker failed')));else resolve(value.result);}catch(e){reject(e);}});
        p.stdin.on('error',()=>{});p.stdin.end(serialized);
      });child.catch(reject);
    });
    const metrics=perceptionNumbers(vision);
    const previous=this.state.channels[goal.mode]??{n:0,meanError:.5};
    const delta=Math.abs(metrics.error-previous.meanError);
    const input=[finite01(metrics.error),finite01(delta),finite01(0.1*metrics.uncertainty)];
    // Actual locked Daughter Δ³ mathematical core, through the locked Ripple OS sensor service.
    // This is a synthetic semantic-to-RGB feature vector, NOT photon measurement.
    const daughter=(await this.os.submit({service:'sensor.ingest',payload:{sourceId:'golf:eyes:diagnostics',kind:'synthetic',samples:Array.from({length:12},()=>({rgb:input,dt:.05}))}},'researcher')).result;
    const soma=daughter.latestLayers.soma;
    let acceptance;
    if(goal.mode==='task')acceptance=vision.observation.failed?'TASK_FAILED_EVIDENCE':'TASK_CASES_PASSED';
    else if(goal.mode==='code')acceptance=vision.observation.syntaxValid?'STRUCTURE_OBSERVED':'SYNTAX_ERRORS_FOUND';
    else acceptance='PIXEL_OBSERVED_NO_SEMANTIC_GROUND_TRUTH';
    // Neuron-derived attention: if the triplet is excited AND there is novelty, flag for detailed review.
    const neuronTriggered=daughter.spikes>0||soma.soma>=.2;
    const attention=metrics.error>=.01||delta>=.3||neuronTriggered?'REVIEW':'NORMAL';
    const next={n:previous.n+1,meanError:previous.meanError+.2*(metrics.error-previous.meanError)};
    this.state.channels[goal.mode]=next;atomic(this.statePath,this.state);
    const record=this.ledger.append({kind:'eyes',mode:goal.mode,role,requestDigest:digest(payload),evidenceClass:goal.mode==='task'?'EXECUTED_BOUNDED_CASES':goal.mode==='image'?'RECORDED_PIXEL_OBSERVATION':'SOURCE_AST_OBSERVATION',acceptance,durationMs:+(performance.now()-started).toFixed(3)});
    this.executions++;
    return {goal:'eyes',mode:goal.mode,observation:vision,neuron:{core:'locked Daughter Δ³ via Ripple OS sensor.ingest',featureVectorNotOptical:input,spikes:daughter.spikes,soma:soma.soma,threshold:soma.threshold,neuronTriggered,attention},predictive:{error:metrics.error,priorMeanError:previous.meanError,innovation:delta,updatedMeanError:next.meanError,update:'EMA, eta=0.2 (engineered diagnostic state)'},acceptance:{state:acceptance,attention,promotion:'NO_AUTOMATIC_PROMOTION'},record};
  };
  const result=this.chain.then(work);this.chain=result.then(()=>{},()=>{});return result;
 }
}
