/** Independently seeded holdout numerical/task assessment for Golf Digital Eyes */
import {GolfEyesRuntime} from './eyes-runtime.mjs';
import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
let seed=0xA04CEB19;const rng=()=>((seed=(Math.imul(seed,1664525)+1013904223)>>>0)/4294967296);
const cases={
 attenuation:Array.from({length:128},()=>{const I0=.1+.9*rng(),mu=.08+1.42*rng(),L=.2+4.8*rng();return{inputs:{I0,mu,L},expected:I0*Math.exp(-mu*L)};}),
 inverse_square:Array.from({length:128},()=>{const P=1+99*rng(),r=2+10*rng();return{inputs:{P,r},expected:P/(4*Math.PI*r*r)};}),
 fresnel:Array.from({length:128},()=>{const n1=1+(.1*rng()),n2=1.35+1.2*rng();return{inputs:{n1,n2},expected:((n1-n2)/(n1+n2))**2};}),
 ema:Array.from({length:128},()=>{const mean=rng(),value=rng(),eta=.04+.38*rng();return{inputs:{mean,value,eta},expected:(1-eta)*mean+eta*value};})};
const defs={attenuation:{fn:'attenuate'},inverse_square:{fn:'flux'},fresnel:{fn:'reflect'},ema:{fn:'update'}};
const dir=path.join(ROOT,'results','study-state');fs.mkdirSync(dir,{recursive:true});
const golf=new GolfEyesRuntime({dataDir:dir});
const r=[];for(const [name,entry] of Object.entries(defs))for(const variant of ['good','wrong']){
 const filename=name+'_'+variant+'.py';const q={kind:'eyes',mode:'task',file:filename,function:entry.fn,cases:cases[name]};
 const out=await golf.run(q,'owner');r.push({task:name,variant,cases:out.observation.observation.cases,passed:out.observation.observation.passed,failed:out.observation.observation.failed,accuracy:out.observation.observation.accuracy,
 status:out.acceptance.state,neuronSpikes:out.neuron.spikes,neuronalAttention:out.neuron.neuronTriggered,semanticClaim:false,sourceHash:out.observation.sha256});
}
fs.writeFileSync(path.join(ROOT,'results','holdout-study.json'),JSON.stringify({seed:'LCG=0xA04CEB19',casePolicy:'128 independent deterministic floating-point tuples per formula; ground-truth oracle specified by math laws',levels:r,totals:{cases:r.reduce((x,y)=>x+y.cases,0),correctVariants:r.filter(x=>x.variant==='good'&&x.failed===0).length,wrongVariants:r.filter(x=>x.variant==='wrong'&&x.failed>0).length},noNovelReasoningClaim:true},null,2));
console.log(JSON.stringify(r.map(x=>({task:x.task,variant:x.variant,passed:x.passed,failed:x.failed,status:x.status})),null,2));
