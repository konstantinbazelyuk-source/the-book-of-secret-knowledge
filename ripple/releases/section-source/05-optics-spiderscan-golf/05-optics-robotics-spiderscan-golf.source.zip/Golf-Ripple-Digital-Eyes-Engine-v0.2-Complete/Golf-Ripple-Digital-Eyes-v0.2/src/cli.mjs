import {GolfEyesRuntime} from './eyes-runtime.mjs';
import {serve} from './server.mjs';
import {startEyesWatch} from './watch.mjs';
import path from 'node:path';
import fs from 'node:fs';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const dataDir=process.env.GOLF_EYES_DATA||path.join(root,'local-data');
const eyes=new GolfEyesRuntime({dataDir});
const command=process.argv[2]||'status';
try{
 if(command==='serve'){
  const h=await serve(eyes,{port:Number(process.env.GOLF_EYES_PORT||8893)});
  console.log('Golf Digital Eyes at http://127.0.0.1:'+h.address.port+'\nAccess token: '+h.token+'\nCtrl-C to stop');
 }else if(command==='watch'){
  const mode=process.argv[3]||'code',file=process.argv[4];if(!file)throw Error('usage: node src/cli.mjs watch code|image filename');
  const watcher=startEyesWatch({runtime:eyes,mode,file,onObservation:report=>console.log(JSON.stringify(report))});
  console.log('Watching '+file+' inside workspace; Ctrl-C to stop.');
  process.on('SIGINT',()=>{watcher.stop();process.exit(0)});
 }else if(command==='status')console.log(JSON.stringify(eyes.status(),null,2));
 else if(command==='demo'){
  const examples=[{kind:'eyes',mode:'code',file:'parent_daughter_triplet.mjs'},
    {kind:'eyes',mode:'image',file:'parent_golf_screen.png'},
    {kind:'eyes',mode:'task',file:'attenuation_good.py',function:'attenuate',cases:[{inputs:{I0:1,mu:.35,L:2},expected:Math.exp(-.7)},{inputs:{I0:.5,mu:.2,L:4},expected:.5*Math.exp(-.8)}]}];
  const outputs=[];for(const example of examples)outputs.push(await eyes.run(example,'owner'));
  const old=await eyes.run({kind:'milestones'},'observer');
  fs.mkdirSync(path.join(root,'results'),{recursive:true});fs.writeFileSync(path.join(root,'results','demo.json'),JSON.stringify({checks:outputs,milestones:old.result.milestones.length},null,2));
  console.log(JSON.stringify({observations:outputs.map(o=>({mode:o.mode,acceptance:o.acceptance,neuron:o.neuron,summary:o.observation.observation.complexity||o.observation.observation.cases||o.observation.observation.width})),milestones:old.result.milestones.length},null,2));
 }else if(command==='goal'){
  if(!process.argv[3])throw Error('specify goal JSON');const goal=JSON.parse(process.argv[3]);console.log(JSON.stringify(await eyes.run(goal,'owner'),null,2));
 }else throw Error('Commands: serve | status | demo | goal | watch mode filename');
}catch(e){console.error(e);process.exitCode=1;}
