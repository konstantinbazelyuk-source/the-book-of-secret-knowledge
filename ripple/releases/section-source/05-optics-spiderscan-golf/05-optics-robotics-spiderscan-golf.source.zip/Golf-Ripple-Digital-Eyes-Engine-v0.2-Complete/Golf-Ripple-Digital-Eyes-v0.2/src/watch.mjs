/** Bounded, real input-file observation loop. All watched files stay inside the workspace. */
import fs from 'node:fs';import path from 'node:path';import {createHash} from 'node:crypto';
const allowed={code:['.py','.js','.mjs','.cjs','.ts','.tsx','.jsx'],image:['.png','.jpg','.jpeg','.bmp','.webp']};
function verifyPath(root,file,mode){
 if(!['code','image'].includes(mode)||typeof file!=='string'||file.length>250)throw Error('watch mode/file invalid');
 const base=fs.realpathSync(root);const target=fs.realpathSync(path.resolve(base,file));
 if(!target.startsWith(base+path.sep)||!allowed[mode].includes(path.extname(target).toLowerCase())||!fs.statSync(target).isFile())throw Error('watch denied');
 return target;
}
export function startEyesWatch({runtime,file,mode='code',intervalMs=500,maxEvents=128,onObservation=()=>{}}){
 if(!runtime||!Number.isInteger(intervalMs)||intervalMs<200||intervalMs>5000||!Number.isInteger(maxEvents)||maxEvents<1||maxEvents>256||typeof onObservation!=='function')throw Error('watch config invalid');
 const target=verifyPath(runtime.workspace,file,mode),normalized=path.relative(runtime.workspace,target);
 let stopped=false,busy=false,count=0,prior=null;
 const poll=async()=>{
  if(stopped||busy)return;
  busy=true;
  try{
   const stats=fs.statSync(target);if(stats.size>8_000_000)throw Error('watched file budget exceeded');
   const hash=createHash('sha256').update(fs.readFileSync(target)).digest('hex');
   if(hash!==prior){
    const prev=prior;prior=hash;
    // For image, observe the CURRENT frame; a before/after pair can be requested explicitly.
    const response=await runtime.run({kind:'eyes',mode,file:normalized},'owner');
    count++;onObservation({ordinal:count,changedSincePrevious:prev!==null,sourceHash:hash,acceptance:response.acceptance.state,neuron:response.neuron});
    if(count>=maxEvents)stop();
   }
  }catch(e){onObservation({error:String(e.message||e).slice(0,250)});stop();}
  finally{busy=false;}
 };
 const timer=setInterval(poll,intervalMs);const stop=()=>{if(!stopped){stopped=true;clearInterval(timer)}};
 void poll();return{stop,get count(){return count}};
}
