#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 -m unittest discover -s tests -p 'test_eyes.py'
npm test
npm run parents
(cd parents/Ripple-Golf-Alpha-v0.1 && npm run parents)
node src/cli.mjs demo
