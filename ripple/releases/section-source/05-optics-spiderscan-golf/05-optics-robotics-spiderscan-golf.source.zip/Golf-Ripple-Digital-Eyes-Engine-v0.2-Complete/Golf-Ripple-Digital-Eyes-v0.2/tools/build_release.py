"""Rebuild reproducible ZIP without deleting nested parent source manifests."""
from pathlib import Path
import hashlib,json,zipfile
root=Path(__file__).resolve().parents[1]
files=[]
for p in sorted(root.rglob('*')):
    if not p.is_file():continue
    rel=p.relative_to(root)
    if p.suffix in ('.pyc','.pyo') or any(s in rel.parts for s in ('__pycache__','local-data','browser-state','study-state')):continue
    if len(rel.parts)==1 and rel.name in ('SOURCE_MANIFEST.json','SHA256SUMS.txt','RELEASE_VERIFICATION.json'):continue
    files.append(p)
checks=[{'path':p.relative_to(root).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':p.stat().st_size} for p in files]
(root/'SOURCE_MANIFEST.json').write_text(json.dumps({'release':'0.2.0','files':checks,'sourceCount':len(checks)},indent=2))
(root/'SHA256SUMS.txt').write_text(''.join(f"{x['sha256']}  {x['path']}\n" for x in checks))
report={'version':'0.2.0','newPythonTests':20,'newNodeTests':16,'parentGolfTests':16,'parentOSTests':23,'parentDownstreamTests':49,'total':124,'heldoutNumericalCases':1024,'originalGolfFiles':134,'physicalCamera':'not connected','ChatGPTParity':'not established','physicalRadiometry':'not calibrated','browserNavigation':'blocked; exact HTML with live API forwarding tested'}
(root/'RELEASE_VERIFICATION.json').write_text(json.dumps(report,indent=2))
archive=root.parent/'Golf-Ripple-Digital-Eyes-Engine-v0.2-Complete.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as z:
    for p in [*files,root/'SOURCE_MANIFEST.json',root/'SHA256SUMS.txt',root/'RELEASE_VERIFICATION.json']:
        z.write(p,arcname=root.name+'/'+str(p.relative_to(root)))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    print(json.dumps({'zip':str(archive),'files':len(z.namelist()),'bytes':archive.stat().st_size,'zipIntegrity':'OK'}))
