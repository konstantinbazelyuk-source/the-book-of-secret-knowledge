# Executed findings — Golf Digital Eyes 0.2

**Tested** in a local container; details and raw logs under `results/`.

| Category | Outcome | Evidence classification |
|---|---|---|
| Python engine unit tests | 20/20 passed | EXECUTED SOFTWARE TESTS |
| New Node integration tests | 16/16 passed | EXECUTED SOFTWARE TESTS |
| Inherited Golf regression suite | 16/16 passed | EXECUTED SOFTWARE TESTS |
| Inherited OS engine regression | 23/23 passed | EXECUTED SOFTWARE TESTS |
| Inherited downstream parent tests | 49/49 passed | EXECUTED SOFTWARE TESTS |
| Four optical/math program families × good/bad variants, 128 held-out numeric cases each | 1,024 executions. All four correct examples 128/128; all four deliberately defective examples 0/128 | COMPUTED, NARROW NUMERIC ORACLE |
| Actual preserved Daughter source AST | 2,491 AST nodes, 15 functions, 37 branches | SOURCE-DERIVED OBSERVATION |
| Previous Golf screenshot | decoded/processed image with real pixel statistics | RECORDED SOFTWARE IMAGE |
| New Golf UI browser before/after screenshots | 5,672 pixels changed out of 1,152,000 (0.49236%); 1280×900 frame, threshold 25/255 | RECORDED SOFTWARE OBSERVATION |
| Known-shift feature registration | ORB/RANSAC synthetic alignment test passed; no real-world 3D geometry inferred | SYNTHETIC FIXTURE |
| Dark/flat pixel correction | math test passes with synthetic 8-bit counts; nonpositive flat-dark rejected | SYNTHETIC CALIBRATION TEST |
| Continuous source-file observation watcher | Two file versions parsed, SHA change detected, two audited records, test passed | EXECUTED FILE MONITORING |
| Full browser loopback navigation | blocked by browser admin policy | NOT VERIFIED |
| Chromium UI with exact HTML and real API forwarded through host test bridge | desktop and phone controls executed, no JS errors, correctly displayed failed physical-math task | PARTIAL UI INTEGRATION TEST |
| ChatGPT parity, comprehensive language understanding or phenomenal experience | not assessed; no supporting proof | NOT ESTABLISHED |
| Camera, NASA real sensor dataset, robotics, cloud deployment | not connected/deployed | NOT ESTABLISHED |

### What the 100% narrow case result means

Eight **known-formula** implementations (correct and deliberately erroneous versions of Beer–Lambert attenuation, inverse square flux, normal-incidence Fresnel power reflectance and EMA update) were checked against 128 independently seeded numeric tuples each, generated with a fixed numerical oracle. All four correct and all four defective versions were distinguished on this designed task family. This is not a language-understanding or software-repair accuracy estimate on independent programs, nor a measure of performance relative to ChatGPT.

### Parent source and original identity

The unmodified Golf v0.1 source archive is in `parents/Ripple-Golf-Alpha-v0.1`. Its inherited source-lock suite passes. The exact original v0.1 neuron remains SHA-256 `dba6639b7902f0c702d15fff588524629f3754cfd72d7b704f22a76b78960ee3`. The new release imports, rather than recreates, the locked Daughter and existing OS Engine.

### What is not being claimed

Neither computation of prediction residuals nor simulator spikes constitute felt sensations, personal consciousness, meaningful comprehension of all tasks, or a validated photoreceptor. AST parsing cannot infer all runtime effects; 2-D pixel change lacks semantic object recognition and camera depth. No functionality was upgraded simply because it looks more sophisticated.
