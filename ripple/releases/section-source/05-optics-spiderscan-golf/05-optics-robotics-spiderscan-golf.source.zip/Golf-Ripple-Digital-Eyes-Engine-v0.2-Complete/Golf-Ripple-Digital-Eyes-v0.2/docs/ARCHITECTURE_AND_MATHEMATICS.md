# Golf Digital Eyes — implemented architecture and equations

## Parent-preservation contract

The child operates by importing unmodified modules from the exact archived Golf v0.1 tree. Golf imports the unchanged OS Engine, Daughter Δ³ neuron and math compiler, which in turn preserve Gen Beta and original Ripple. Parent bytes are verified against the supplied Golf archive and the inherited source hashes. There are no edits to the prior releases.

## Actual dataflow

```
Files strictly under workspace/
  +-- SHA watcher --------> repeated source/image observations on file changes
  +-- Code (.py/.js/.ts) --> Python AST / TypeScript AST --> symbol and call graph evidence
  +-- Recorded image(s) -> OpenCV metrics, optional ORB/RANSAC registration,
  |                        optional dark/flat pixel normalization
  +-- Numeric task ------> restricted AST interpreter -> true/expected test outcomes
          |                           |                         |
          +---------------------------+-------------------------+
                                      v
                Normalized task error / observed change / uncertainty
                                      v
              Innovation comparator + persisted per-channel EMA state
                                      v
           actual inherited Ripple OS sensor.ingest -> Daughter Δ³ P/D/S
                                      v
                evidence gate / attention / append-only hashed ledger
                                      v
                local HTTP API + CLI + human-readable observation
```

## Functional mathematical coupling (new *engineering* model)

For each type of observation `c` separately, compute an error proxy `e_t`:

- Numeric task: `e_t = failures / number_of_cases`; exact case outcomes and tolerances are reported separately.
- Source parsing: `e_t = 1` on parser error, else `0` (this **does not** mean valid code is correct).
- Registered image pair: `e_t = changed_pixels / valid_aligned_pixels`; a single frame has error proxy 0 because no reference exists, **not** because the image is correct.

The historical prediction is the per-channel exponential moving average

`m_(t+1) = m_t + 0.2 (e_t - m_t)`.

The unsigned innovation against prior expectation is

`delta_t = |e_t - m_t|`.

The normalized feature triplet is

`r_t = [clamp(e_t,0,1), clamp(delta_t,0,1), clamp(0.1*u_t,0,1)]`

where `u_t=0` for numeric cases with explicit oracle and `1` for unverified semantic labels in source/image. The feature triplet is ingested by the inherited **DaughterTripletNeuron** through Ripple OS, 12 increments of 0.05 model seconds. The resulting soma potential and spike count contribute to **attention**: `REVIEW` if `e>=0.01 OR delta>=0.3 OR spike_count>0 OR soma>=0.2`; otherwise `NORMAL`. Execution never promotes a scientific conclusion automatically.

The Daughter model supplies coupled photoreceptor, dendrite and soma dynamics. This numerical sensor mapping is a new *application-derived engineering composition* of existing standard mechanisms; it is **not** a newly discovered physical law or biological model. The explicit error gate dominates strong observed failures, preventing sensitivity to parameter choice from hiding hard numerical mismatches. The neural state provides an additional genuine trigger. The state remains observational, not subjective.

## Optical signal mathematics

Brightness counts `y(x)`, dark reference `d(x)`, flat response `f(x)`:

`relative(x) = clamp((y(x)-d(x))/(f(x)-d(x)),0,10)` where all channels have `f(x)-d(x)>5` (8-bit image units); invalid pixels masked. This shares the algebraic intent of dark/flat correction used in astronomical instrumentation but the supplied sample images are normal 8-bit image files, **not** verified linearly calibrated instrument raw data.

Temporal frame difference after alignment `T`:

`change(x) = 1[max_channel |A(x) - B(T(x))| > 25]`.

Changed fraction is normalized over valid overlap. Alignment uses ORB feature descriptors, Lowe ratio filtering, RANSAC partial-affine estimation, a minimum of 5 inliers, and translation bounds; insufficient registration abstains instead of inventing geometry. This does **not** reproduce Mars rover SLAM, 3-D stereo reconstruction or NASA optical calibration.

## Code semantics boundaries

- Python and JavaScript syntax trees report actual token spans, symbol declarations, call edges and imports. No natural-language understanding is inferred.
- Arithmetic tasks are interpreted through a whitelist with finite-number/magnitude, loop and recursion limits. Stored source is NOT executed in unrestricted Python or JavaScript runtime.
- Ground truth must come from supplied, independently justified expected numeric values, not from the assessed candidate program alone.

## Security/limitations

The local API uses a bearer token, request byte limit, localhost binding, path resolving/allowlist, source-byte cap, image cap, worker timeouts and bounded AST interpretation. The offline TypeScript grammar library is vendored with MIT license. This is not a multi-tenant hardened OS or full system sandbox. The original Golf parent service and OS scheduler, event bus and journal remain in use.
