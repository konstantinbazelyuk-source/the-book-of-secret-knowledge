@echo off
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (echo Node.js 20 or newer is required. & pause & exit /b 1)
echo Starting Golf Ripple local engine...
echo Open http://127.0.0.1:8877/ and paste the token printed below.
node src\cli.mjs serve
pause
