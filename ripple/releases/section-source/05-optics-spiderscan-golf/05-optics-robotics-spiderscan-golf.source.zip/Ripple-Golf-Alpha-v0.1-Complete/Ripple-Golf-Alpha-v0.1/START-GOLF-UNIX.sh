#!/bin/sh
set -e
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "Node.js >=20 required";exit 1;}
exec node src/cli.mjs serve
