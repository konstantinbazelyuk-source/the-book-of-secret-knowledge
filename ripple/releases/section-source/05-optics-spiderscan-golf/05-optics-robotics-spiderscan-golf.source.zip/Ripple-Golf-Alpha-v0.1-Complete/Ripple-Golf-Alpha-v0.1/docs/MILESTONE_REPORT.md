# Golf Ripple — collective milestone record and genealogy

**Release:** Golf Ripple Alpha `0.1.0-alpha.1`.
**Method:** Review and reuse the actual archived source tree within `parents/Ripple-OS-Engine-Beta-v0.1/`, and reconcile inherited validation records with current regression tests. The order below is a *feature lineage*, not verified timestamps of invention. No histories or earlier projects are overwritten.

## Milestone path: which capability unlocked the next

| Stage | Inherited feature | How we reached it | What remained incomplete |
|---|---|---|---|
| 01 · v0.1 | Original Ripple neuron | A bounded RGB-weighted leaky integrate-and-fire neuron with adaptive threshold, exact event-crossing calculation | Direct neuronal model, not measured biophysics |
| 02 · v0.5–0.6 | Optical and photoreceptor layers | Added camera RGB statistics, reference opacity proxies, linear-light conversion, logarithmic brightness and ON/OFF frame changes | RGB camera outputs are not physical wavelength-resolved spectra |
| 03 · v0.7 | Quaternary signaling | Four symbols (-1, -0, 0, 1) encoded in two bits; bounded program instructions | Four states are not quantum qubits |
| 04 · Alpha Labs/Gen Beta v2.0 | Spatial fields and synthetic colonies | Conservative diffusion, occlusion, spatial memory, shared maps and reproducible seeded agent routing | Exploration metrics did not improve from every feature |
| 05 · Gen Beta v2.1 | Recorded-data evidence test | Compared digit-scanner data labels and synthetic optical attenuation | Not calibrated camera light or general vision |
| 06 · v3.0 | Delta Ripple neuron | Added transient contrast, optical math and spike adaptation to the reference neuron | Not a proven superior universal controller |
| 07 · v3.1 | Daughter triplet core | Coupled photoreceptor, dendritic, and adaptive soma dynamics with independently testable states | Not a living neuron or proof of intelligence |
| 08 · Forest v1.4 | Forest movement communication | Tracked map cells and agent paths; sender/receiver trained restricted two-symbol movement codes | Not natural language, requires task-factored protocol |
| 09 · Assessment v1.5 | Digital evidence assessment | Document-forest routing, retrieval, user feedback and limited learned weights | Retrieval is default; incorrect sources remain possible |
| 10 · v2.1.1 | Ripple Mathematics Compiler | Guarded Beer–Lambert forward/inverse mathematical recipe registry | Calculated light intensity is not an instrument measurement |
| 11 · OS v0.1 beta | Ripple OS Engine | Capability-checked bounded scheduler, typed events, persistent supervised policy, append-only hash journal | Application runtime, not kernel OS; pending tasks not durable |
| 12 · v0.1 alpha | Golf Ripple | Milestone-grounded workflow composition, paired baseline experiments, goal ledger, evidence acceptance gates | No claim of general learning or improved intelligence |

## Lessons from previous negative and mixed results

- **Camera RGB is not spectrometry.** The optical model uses dimensionless RGB unless supported by calibrated independent sensor metadata; Beer–Lambert attenuation is applied as calculated signal processing.
- **More mathematical layers do not prove more intelligence.** Delta and Daughter exhibited conditions where another original/variant performed better. Crossed target rates are computed and should not be generalized beyond the stated protocols.
- **Four-state encoding is a useful interface but not a proven mapping optimizer.** Earlier Beta ablations showed a quaternary removal had no impact on coverage in the measured synthetic task.
- **Forest communication was deliberately constrained.** Two-symbol route codes were learned for structured goals, not natural-language grammar.
- **BM25 was better than the inherited trained document model.** Previous source-routing holdout: 23/32 BM25 versus 13/32 trained policy. Golf's default always uses BM25 and requests review when lexical evidence is absent/ambiguous.
- **An OS-like application has no driver/OS privilege.** Ripple OS v0.1 supplies a process-local allowlisted scheduler, journal, bus and source modules; Golf extends it by safely composing fixed services and binding results to evidence gates.

## What Golf adds, versus renaming an earlier Alpha

1. A **typed, bounded goal dispatcher** with four explicit workflows: milestones, evidence lookup, optical-neuron comparison, and colony mapping.
2. **Paired mathematical verification:** the unmodified original Ripple v0.1 neuron and Daughter Δ³ are fed the *same* Beer–Lambert-processed inputs through the preserved formula compiler. The reference is a derived ESM export adapter; its mathematical body is identical to the original, which is checksum-locked separately.
3. A **fail-closed evidence acceptance gate**: synthetic runs are labeled synthetic; recorded-but-unverified data cannot be called physically validated; retrieved passages are not asserted to be factual answers; no result automatically replaces an approved baseline.
4. An **append-only, SHA-256 chained goal ledger**, independent of the inherited OS audit journal, with restart and tamper checks and no raw user question contents.
5. A local authenticated browser console and runnable CLI. No dynamic executable plugins, external network access, or arbitrary code evaluation.

## What Golf does NOT add

It is not a new hardware OS, a physically measured sensor, an autonomous general-purpose AI, a durable job queue, or evidence that the Daughter neuron is universally superior. It has no cloud deployment. Simulated optical and mapping inputs are explicit. Only policy updates explicitly made through the inherited OS feedback service persist; Golf does not automatically retrain anything.

## Provenance methodology

`docs/COMPONENT_LOCKS.json` binds ten active parent source modules to SHA-256 digests. `docs/PARENT_FILES.json` locks all archived parent files. Existing source trees are stored intact in `parents/`. The only original-neuron export adapter lives separately in `src/golf/original-reference.mjs` and is tested against the preserved source. The full OS and three parent suites are rerun using `npm run parents`.
