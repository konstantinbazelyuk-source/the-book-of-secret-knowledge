# Operating boundaries

Golf is a child application **orchestrator** of Ripple OS and not a privileged OS, secure interpreter of untrusted code, cloud daemon or source of verified medical/quantum/metaphysical measurements.

- The local server binds only to `127.0.0.1`. Each goal request requires a randomly generated bearer token (printed in the local terminal only); treat tokens as passwords. The current prototype has owner access at that endpoint. Network perimeter authentication and TLS for nonlocal deployments are NOT provided.
- The accepted goal schema is a strict allowlist. No arbitrary plugin execution, file writing by caller, shell execution, or dynamic code is accepted.
- Parent `RippleOS` capability checks remain in force. Golf also rejects simulation goals to observer subjects. Golf's local HTTP token acts as the owner credential.
- `light` inputs are bounded to 1–12 phases, at most 1200 steps overall, coefficient/path 0–10, dt 0.005–0.1 seconds. `recorded-unverified` is a provenance declaration, not a verifier.
- `forest` inputs are bounded to a 56 × 56 maximum seeded grid and 256 ticks. No physical map or actual GPS is used.
- Goal events are serialized. The inherited OS scheduler is cooperative, not a preemptive real-time kernel.
- Both the inherited hash journal and the new Golf hash chain detect accidental or malicious offline alterations in their log records, but a hash chain without an external signature does not protect against an attacker who rewrites the entire journal and recomputes every hash.
- Only source and explicit policy files persist. No crash-recoverable queue or persistent simulated colony/neuron state is promised.
- Golf does not automatically update the original model, external accounts, public deployments, or any other Ripple release.
