# Executed comparison and evidence quality — Golf Alpha v0.1

This study is **SIMULATED**, not a new real-world hardware observation. Golf runs original v0.1 and Daughter Δ³ under identical phase inputs, and the inputs are transformed by the actual inherited Beer–Lambert compiler. Rate tracking uses the absolute deviation of each phase's counted events per simulated second from 1 Hz. The study includes phase-transition effects; it is NOT a long-run stationarity comparison, parameter fit or controlled inference of natural intelligence.

## Study protocol

36 paired runs = 3 input protocols × 12 repeats; each repeat has three 200-step segments (600 steps total), model `dt=0.05 s`. A deterministic 32-bit seeded pseudo-random sequence adds limited channel jitter and selects a modeled optical path from 0–3. The absorption coefficient is 0.35 in reciprocal path units. The protocol is fixed in `src/study.mjs` and full cases are saved in `results/comparison-trials.json`.

| Protocol | Runs | Original mean abs error (Hz) | Daughter mean abs error (Hz) | Daughter wins | Original wins | Ties |
|---|---:|---:|---:|---:|---:|---:|
| steady | 12 | 0.2833 | 0.2556 | 5 | 0 | 7 |
| brightness-step | 12 | 0.7111 | 0.6917 | 7 | 2 | 3 |
| color-change | 12 | 0.3889 | 0.3639 | 6 | 0 | 6 |

These modest advantages cannot be interpreted as universal performance benefits, especially because earlier Delta configurations sometimes exceeded Daughter. The test conditions remain synthetic, and the user did not supply any measured sensor traces.

## Evidence labels

- `SOURCE_DERIVED`: Milestone provenance from locked archived sources, historical test records, and current checksums.
- `RETRIEVED_SOURCE_NOT_ANSWER`: BM25 document rank and passage, never automatically elevated to a verified factual answer.
- `SYNTHETIC_NUMERICAL`: computed attenuation, exact parent neuron states, and seeded synthetic comparisons.
- `EXTERNAL_UNVERIFIED_SIGNALS`: supplied normalized RGB arrays without instrument calibration; must be flagged `PHYSICAL_VALIDATION_REQUIRED`.
- `SYNTHETIC_COLONY`: seeded generated map and paths, not physical navigation.

## Acceptance gates

Golf never auto-promotes a new mathematical design. It allows an explicitly runnable study if the request is authorized and bounded; outputs are classified by evidence tier. Physical validation needs fixed exposure/white balance, independent calibration/reference standards and a real labeled dataset. General competence would need independent held-out task families with rigorously matched baseline budgets.

## Interface testing limit

- 16 new Golf tests passed with real parent invocation, HTTP authentication and tamper/restart checks.
- The 72 inherited parent tests passed when rerun from the copied tree.
- Chromium `page.goto(http://127.0.0.1:...)` returned `net::ERR_BLOCKED_BY_ADMINISTRATOR`; actual local HTTP behavior was independently exercised by the Node test suite.
- Standalone HTML/DOM clicks passed on desktop and phone viewport **with mocked API responses**; that does **not** qualify as end-to-end browser/network testing.
