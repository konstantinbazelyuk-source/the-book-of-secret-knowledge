# Golf Ripple — Goal-oriented Functional Orchestration & Lineage Framework

**Golf Alpha v0.1.0-alpha.1** is a real runnable child of Ripple OS v0.1. It uses locked parent source modules: original v0.1 LIF reference, Daughter Δ³ three-layer neuron, guarded Beer–Lambert formula compiler, Gen Beta synthetic colony, and Digital Assessment v1.5 BM25 evidence router.

**How to run (Node.js 20 or newer):** Extract the ZIP, then in this directory use `npm test`, `npm run parents`, `npm run demo`, and `npm run serve`. No `npm install` or third-party dependencies are necessary. On Windows, run `START-GOLF-WINDOWS.bat`; on macOS/Linux, run `sh START-GOLF-UNIX.sh`. Golf is not a browser-only file: the Node process is required to run the inherited cores.

The local console defaults to `http://127.0.0.1:8877/`. Enter the token printed in the terminal; the token is held only in that page's memory. All workflows run in the local Node process.

## Four executable goal workflows

`milestones` — returns version genealogy and selected verified parent hashes.

`evidence` — routes a 2–500 character research question to a source passage with BM25, a two-symbol forest address, and a review/abstain gate. **Does not generate source-independent factual answers.**

`light` — sends 1–12 RGB input phases through the real compiler's Beer–Lambert calculation, to the actual parent Daughter via Ripple OS's `sensor.ingest`, and to the original Ripple v0.1 mathematical reference. Produces counts and case-specific rate-error comparisons. All inputs must declare `synthetic` or `recorded-unverified`.

`forest` — starts an actual seeded DaughterWorld inside Ripple OS and outputs bounded geographic path, lineage, and coverage summaries. It is a simulated mapping world.

## Evidence and integrity

The full parent tree is copied read-only as a source archive and is unchanged from Ripple OS Engine Beta v0.1. The source file checksum inventory and a separate Golf SHA-256 goal ledger are included. `npm run verify` checks selected working-core source files. See `docs/MILESTONE_REPORT.md`, `docs/EXECUTED_RESULTS.md`, `docs/OPERATING_BOUNDARIES.md`, and `results/` for validation.

**No extra intelligence claim:** Golf implements governed software composition and observable numerical experiments. It is not a foundation model, a neuromorphic chip, or physical light-sensor validation. It does not supersede earlier versions.
