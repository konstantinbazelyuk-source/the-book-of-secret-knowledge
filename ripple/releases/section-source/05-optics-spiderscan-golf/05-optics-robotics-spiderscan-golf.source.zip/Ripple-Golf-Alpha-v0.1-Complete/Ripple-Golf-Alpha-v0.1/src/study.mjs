import {GolfRuntime} from './golf/engine.mjs';import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
let s=49321;const rnd=()=>((s=(Math.imul(1664525,s)+1013904223)>>>0)/4294967296);
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'golf-study-'));const golf=new GolfRuntime({dataDir:tmp});
const protocols=[{id:'steady',base:[.35,.05,.03],bright:[.35,.05,.03]},{id:'brightness-step',base:[.35,.08,.02],bright:[.75,.08,.02]},{id:'color-change',base:[.45,.05,.08],bright:[.15,.5,.08]}];
const trials=[];const start=performance.now();
for(const p of protocols){for(let k=0;k<12;k++){
  const jitter=()=>((rnd()-.5)*.12);const a=p.base.map(v=>Math.max(0,Math.min(1,v+jitter()))),b=p.bright.map(v=>Math.max(0,Math.min(1,v+jitter())));
  const input={kind:'light',sourceKind:'synthetic',phases:[{rgb:a,steps:200},{rgb:b,steps:200},{rgb:a,steps:200}],coefficient:.35,path:Math.round(rnd()*3*10)/10,dt:.05};
  const result=(await golf.run(input,'researcher')).result;
  trials.push({protocol:p.id,replicate:k,originalError:result.meanAbsoluteRateError.original,daughterError:result.meanAbsoluteRateError.daughter,comparison:result.comparison,attenuationPath:input.path});
}}
const means=arr=>arr.reduce((a,b)=>a+b,0)/arr.length;
const summary={kind:'SYNTHETIC_NUMERICAL',purpose:'Paired, matched-input original v0.1 versus Daughter Δ³, not evidence of universal performance gain',runs:trials.length,modelSteps:trials.length*600,elapsedMs:performance.now()-start,byProtocol:protocols.map(p=>{const sub=trials.filter(r=>r.protocol===p.id);return{protocol:p.id,n:sub.length,meanOriginalError:means(sub.map(r=>r.originalError)),meanDaughterError:means(sub.map(r=>r.daughterError)),daughterBetter:sub.filter(r=>r.daughterError<r.originalError).length,originalBetter:sub.filter(r=>r.originalError<r.daughterError).length,ties:sub.filter(r=>r.originalError===r.daughterError).length};}),sourceLocks:golf.status().sourceLocks,ledger:golf.ledger.verify()};
fs.writeFileSync(new URL('../results/comparison-trials.json',import.meta.url),JSON.stringify({summary,trials},null,2));
console.log(JSON.stringify(summary,null,2));
