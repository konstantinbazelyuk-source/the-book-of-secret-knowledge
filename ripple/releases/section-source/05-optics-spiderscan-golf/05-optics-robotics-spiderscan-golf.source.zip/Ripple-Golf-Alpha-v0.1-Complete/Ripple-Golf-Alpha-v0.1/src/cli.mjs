import {GolfRuntime,verifySourceLocks} from './golf/engine.mjs';
import {startGolfServer} from './golf/server.mjs';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
const cmd=process.argv[2]??'help';
const DATA=process.env.GOLF_DATA_DIR||path.join(process.cwd(),'golf-data');
if(cmd==='help'){console.log('Golf Ripple commands: demo | milestones | light | forest | evidence <query> | serve | verify | help');process.exit(0);}
if(cmd==='verify'){console.log(JSON.stringify(verifySourceLocks(),null,2));process.exit(verifySourceLocks().ok?0:1);}
const golf=new GolfRuntime({dataDir:cmd==='serve'?DATA:fs.mkdtempSync(path.join(os.tmpdir(),'golf-run-'))});
let result;
switch(cmd){
 case 'demo':{
  const milestones=await golf.run({kind:'milestones'},'observer');
  const evidence=await golf.run({kind:'evidence',query:'Which method worked better for source routing, learned weights or BM25?'},'observer');
  const light=await golf.run({kind:'light',phases:[{rgb:[.35,.10,.08],steps:80},{rgb:[.72,.1,.08],steps:80},{rgb:[.35,.1,.08],steps:80}],sourceKind:'synthetic',coefficient:.35,path:2,dt:.05},'researcher');
  const forest=await golf.run({kind:'forest',seed:1731,ticks:20},'researcher');
  result={release:golf.status().release,milestoneCount:milestones.result.milestones.length,evidence:{document:evidence.result.documentId,review:evidence.result.review},light:{comparison:light.result.comparison,errors:light.result.meanAbsoluteRateError,records:light.result.phases.length},forest:{coverage:forest.result.afterCoverage,paths:forest.result.trace?.length},ledger:golf.ledger.verify(),parentServices:golf.os.status().services.length};break;}
 case 'milestones':result=(await golf.run({kind:'milestones'},'observer')).result;break;
 case 'evidence':result=await golf.run({kind:'evidence',query:process.argv.slice(3).join(' ')||'Which method was stronger, BM25 or trained policy?'},'observer');break;
 case 'light':result=await golf.run({kind:'light',phases:[{rgb:[.35,0,0],steps:100},{rgb:[.70,0,0],steps:100},{rgb:[.35,0,0],steps:100}],coefficient:.35,path:2,dt:.05,sourceKind:'synthetic'},'researcher');break;
 case 'forest':result=await golf.run({kind:'forest',seed:1731,width:24,height:16,ticks:20},'researcher');break;
 case 'serve':{
  const port=Number(process.env.GOLF_PORT||8877);const r=await startGolfServer({golf,port,token:process.env.GOLF_TOKEN});
  console.log('Golf Ripple local console: http://127.0.0.1:'+r.address.port+'/');console.log('Local token (do not share): '+r.token);
  console.log('No public interface; Ctrl+C stops server.');break;
 }
 default:throw Error('unknown command '+cmd);
}
if(result!==undefined)console.log(JSON.stringify(result,null,2));
