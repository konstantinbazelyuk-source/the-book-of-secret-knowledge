import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
const sha=x=>createHash('sha256').update(x).digest('hex');
export class GolfLedger{
 constructor(dir){this.dir=dir;fs.mkdirSync(dir,{recursive:true});this.file=path.join(dir,'goals.jsonl');if(!fs.existsSync(this.file))fs.writeFileSync(this.file,'');this.records=this.verify();}
 verify(){const content=fs.readFileSync(this.file,'utf8');if(content && !content.endsWith('\n'))throw Error('GOAL_LEDGER_PARTIAL');let prev='0'.repeat(64),count=0;for(const line of content.trim().split('\n').filter(Boolean)){const r=JSON.parse(line);const {sha256,...body}=r;if(r.sequence!==count+1||r.previous!==prev||sha(JSON.stringify(body))!==sha256)throw Error('GOAL_LEDGER_TAMPER');prev=sha256;count++;}this.head=prev;this.sequence=count;return count;}
 append(event){if(typeof event!=='object'||!event||Array.isArray(event))throw Error('bad ledger event');const body={sequence:this.sequence+1,previous:this.head,time:new Date().toISOString(),...event};const row={...body,sha256:sha(JSON.stringify(body))};fs.appendFileSync(this.file,JSON.stringify(row)+'\n');this.sequence++;this.head=row.sha256;return{sequence:row.sequence,sha256:row.sha256};}
 recent(limit=20){if(!Number.isInteger(limit)||limit<1||limit>50)throw Error('bad limit');return fs.readFileSync(this.file,'utf8').trim().split('\n').filter(Boolean).slice(-limit).map(JSON.parse);}
}
export const digest=data=>sha(JSON.stringify(data));
