import {createServer as createHTTP} from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import {randomBytes} from 'node:crypto';
import {fileURLToPath} from 'node:url';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../..');
const gui=fs.readFileSync(path.join(ROOT,'web/index.html'));
const json=(res,status,data)=>{const body=Buffer.from(JSON.stringify(data));res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Content-Length':body.length,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(body);};
export async function startGolfServer({golf,port=8877,token=randomBytes(24).toString('base64url')}={}){
 if(!golf||!Number.isInteger(port)||port<0||port>65535)throw Error('server config invalid');
 const server=createHTTP(async(req,res)=>{
  try{
   if(req.method==='GET'&&req.url==='/'){res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','X-Content-Type-Options':'nosniff','Cache-Control':'no-store'});res.end(gui);return;}
   if(req.method!=='POST'||req.url!=='/api/goal'){json(res,404,{error:'not found'});return;}
   if(req.headers.authorization!==`Bearer ${token}`){json(res,401,{error:'local access token required'});return;}
   if(!(req.headers['content-type']||'').startsWith('application/json')){json(res,415,{error:'application/json required'});return;}
   let bytes=0,raw='';for await(const chunk of req){bytes+=chunk.length;if(bytes>8192){json(res,413,{error:'input over 8192 bytes'});req.destroy();return;}raw+=chunk.toString('utf8');}
   const item=JSON.parse(raw);if(!item||typeof item!=='object'||Array.isArray(item)||Object.keys(item).some(x=>!['goal'].includes(x)))throw Error('invalid request object');
   const output=await golf.run(item.goal,'owner');json(res,200,output);
  }catch(e){if(!res.headersSent)json(res,400,{error:e.message||'request failed'});}
 });
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve);});
 return {address:server.address(),token,close:()=>new Promise(resolve=>server.close(resolve))};
}
