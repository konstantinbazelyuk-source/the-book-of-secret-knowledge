#!/usr/bin/env python3
"""Ripple Sensor Bridge v0.2: REAL FILE INPUT; NO CLAIM OF UNCONNECTED HARDWARE.
SPDX-License-Identifier: CC0-1.0
The verified Ripple v0.1 source is unchanged in legacy/ripple_optical_agent.py.
This application DOES NOT fly aircraft, operate printer motors, or measure light's
instantaneous EM field. It reads images/video from disk, measures digital pixels,
adds a read-only routing layer, and writes traceable files.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import sys
from typing import Any
import cv2
import numpy as np
from legacy.ripple_optical_agent import RippleNeuron

MODEL = 'Ripple Neuron v0.1 locked'
ADAPTER = 'Ripple Sensor Bridge v0.2 experimental'

def sha(path: Path)->str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1<<20),b''):h.update(block)
    return h.hexdigest()

def dump(path: Path, obj: Any):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n',encoding='utf-8')

def require_image(path: Path)->np.ndarray:
    image=cv2.imread(str(path),cv2.IMREAD_COLOR)
    if image is None: raise ValueError(f'Cannot open image file: {path}')
    return image

def bgr_float(frame: np.ndarray)->np.ndarray:
    return cv2.cvtColor(frame,cv2.COLOR_BGR2RGB).astype(np.float64)/255.0

class RipplePool:
    """Independent neurons for separate spatial jobs; logical workers, not threads.
    Thresholds NOT copied between newly spawned nodes. No trainable links added.
    """
    def __init__(self,min_nodes:int=2,max_nodes:int=8,work_unit:int=40):
        if not (1<=min_nodes<=max_nodes<=64 and work_unit>=1):raise ValueError('invalid node pool limits')
        self.min,self.max,self.work_unit=min_nodes,max_nodes,work_unit
        self.nodes=[RippleNeuron() for _ in range(min_nodes)]
        self.low_count=0;self.high_count=0;self.changes=[]
        self.step_index=0
    @property
    def size(self):return len(self.nodes)
    def adjust(self,work_items:int):
        desired=max(self.min,min(self.max,math.ceil(max(0,work_items)/self.work_unit)))
        if desired>self.size:self.high_count+=1;self.low_count=0
        elif desired<self.size:self.low_count+=1;self.high_count=0
        else:self.high_count=self.low_count=0
        if self.high_count>=3:
            old=self.size;self.nodes.extend(RippleNeuron() for _ in range(desired-self.size))
            self.changes.append({'step':self.step_index,'old':old,'new':self.size,'reason':'three high-load intervals'})
            self.high_count=0
        if self.low_count>=6:
            old=self.size;self.nodes=self.nodes[:desired]
            self.changes.append({'step':self.step_index,'old':old,'new':self.size,'reason':'six low-load intervals'})
            self.low_count=0
    def feed(self,features:list[tuple[float,float,float]],dt:float)->list[dict]:
        if len(features)!=self.size:raise ValueError('one distinct task feature per logical node required')
        self.step_index+=1
        return [node.step(x,dt) for node,x in zip(self.nodes,features)]

# The 4-channel phase reconstruction from previous version remains available
# from legacy/ripple_optical_agent.py; scanner and drone cameras do not emit IQ.

def scanner_measure(reference_path:Path, scanned_path:Path, output:Path, rows:int=32,
                    alignment:bool=True, max_side:int=1100)->dict:
    """Digital comparisons are conditional on chart/reference alignment.
    Resampling defeats direct estimation of hardware optical DPI; use ruler command.
    The printed chart is uncalibrated until user physically checks its dimensions.
    """
    output.mkdir(parents=True,exist_ok=True)
    ref_full=require_image(reference_path);scan_full=require_image(scanned_path)
    orig={'reference_shape_px':list(ref_full.shape[:2]),'scan_shape_px':list(scan_full.shape[:2])}
    h,w=ref_full.shape[:2]
    factor=min(1.0,max_side/max(h,w))
    target=(max(2,round(w*factor)),max(2,round(h*factor)))
    ref=cv2.resize(ref_full,target,interpolation=cv2.INTER_AREA)
    scan=cv2.resize(scan_full,target,interpolation=cv2.INTER_AREA)
    # Resampling here supports error analysis; native resolution remains logged.
    correction=np.eye(2,3,dtype=np.float32)
    corr_score=None;align_status='off'
    if alignment:
        base=cv2.cvtColor(ref,cv2.COLOR_BGR2GRAY).astype(np.float32)/255.
        newer=cv2.cvtColor(scan,cv2.COLOR_BGR2GRAY).astype(np.float32)/255.
        try:
            corr_score, correction=cv2.findTransformECC(base,newer,correction,cv2.MOTION_AFFINE,
                (cv2.TERM_CRITERIA_COUNT|cv2.TERM_CRITERIA_EPS,120,1e-6),None,5)
            scan=cv2.warpAffine(scan,correction,target,flags=cv2.INTER_LINEAR|cv2.WARP_INVERSE_MAP,
                                borderMode=cv2.BORDER_CONSTANT,borderValue=(255,255,255))
            align_status='ecc_aligned_not_verified'
        except cv2.error:
            align_status='failed_unaligned'
    ref_rgb=bgr_float(ref);scan_rgb=bgr_float(scan)
    err=scan_rgb-ref_rgb
    base_means=ref_rgb.mean(axis=(0,1)); meas_means=scan_rgb.mean(axis=(0,1))
    signed=err.mean(axis=(0,1)); mad=np.abs(err).mean(axis=(0,1))
    diff=np.mean(np.abs(err),axis=2)
    cv2.imwrite(str(output/'reference_resized.png'),ref)
    cv2.imwrite(str(output/'scanned_aligned.png'),scan)
    cv2.imwrite(str(output/'absolute_difference_grayscale.png'),np.clip(diff*255*3,0,255).astype(np.uint8))
    # Study scanline fluctuations in the algorithmic loop; no physical scan timing assumed.
    pool=RipplePool(min_nodes=2,max_nodes=2,work_unit=100000)
    log=[];events=[]
    for step in range(rows):
        y0=round(step*target[1]/rows);y1=max(y0+1,round((step+1)*target[1]/rows))
        # 2 independent spatial regions (left/right); existing RGB weights unchanged.
        features=[]
        for k in range(2):
            x0=round(k*target[0]/2);x1=round((k+1)*target[0]/2)
            f=scan_rgb[y0:y1,x0:x1,:].mean(axis=(0,1))
            features.append(tuple(map(float,f)))
        outputs=pool.feed(features,0.05)
        for k,(rgb,r) in enumerate(zip(features,outputs)):
            line={'algorithmic_step':step,'node':k,'input_R':rgb[0],'input_G':rgb[1],
                  'input_B':rgb[2],'drive':r['drive'],'threshold':r['theta'],
                  'estimated_rate_per_algorithmic_second':r['rate_hz'],'spikes':r['count']}
            log.append(line)
            if r['count']:events.append({'step':step,'node':k,'event':'LOG_SCANNER_CHANNEL_ACTIVITY',
                                         'count':r['count']})
    with (output/'neuron_trace.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=log[0].keys());writer.writeheader();writer.writerows(log)
    summary={'adapter':ADAPTER,'core':MODEL,
             'provenance':'FILE PIXEL MEASUREMENT: data from paths named below; not an independently calibrated physical measurement',
             'reference_file':str(reference_path),'reference_sha256':sha(reference_path),
             'observed_file':str(scanned_path),'observed_sha256':sha(scanned_path),
             **orig,'analysis_size_px':[target[1],target[0]],
             'alignment_status':align_status,'ecc_correlation_unvalidated':corr_score,
             'mean_rgb_reference_0to1':base_means.tolist(),
             'mean_rgb_observed_0to1':meas_means.tolist(),
             'mean_signed_rgb_difference_0to1':signed.tolist(),
             'mean_absolute_rgb_error_0to1':mad.tolist(),
             'mean_absolute_pixel_error_8bit':float(np.mean(np.abs(err))*255),
             'pct_pixels_channel_clipped_0_or_255':float(np.mean((scan_rgb<=0)|(scan_rgb>=1))*100),
             'neuron_spike_events':sum(e['count'] for e in events),
             'comparison_limitations':'No ICC/colorimetric calibration. Geometric alignment may fail. Prints require 100% scale. '
                 'Normalized scanline-processing time is NOT real physical elapsed time. Reference rescaled for pixel comparison.'}
    dump(output/'summary.json',summary);dump(output/'events.json',events)
    return summary

def ruler_distance(p1:tuple[float,float],p2:tuple[float,float],length_mm:float)->dict:
    if length_mm<=0 or not math.isfinite(length_mm):raise ValueError('length must be positive')
    px=math.dist(p1,p2)
    if px<=0:raise ValueError('points must differ')
    return {'source':'USER PROVIDED PIXEL ENDPOINTS AND PHYSICALLY VERIFIED LENGTH',
            'separation_px':px,'physical_separation_mm':length_mm,
            'pixels_per_mm':px/length_mm,'effective_dpi':px/length_mm*25.4,
            'mm_per_pixel':length_mm/px,
            'uncertainty':'not provided; mark measurement and endpoint placement error must be evaluated'}

def tracking_pair(previous:np.ndarray,current:np.ndarray,max_corners:int=350)->tuple[np.ndarray,np.ndarray,np.ndarray,int]:
    a=cv2.cvtColor(previous,cv2.COLOR_BGR2GRAY)
    b=cv2.cvtColor(current,cv2.COLOR_BGR2GRAY)
    p0=cv2.goodFeaturesToTrack(a,maxCorners=max_corners,qualityLevel=0.012,minDistance=8,blockSize=7)
    if p0 is None:return np.empty((0,2)),np.empty((0,2)),np.empty((0,2)),0
    p1,st,_=cv2.calcOpticalFlowPyrLK(a,b,p0,None,winSize=(21,21),maxLevel=3,
        criteria=(cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_COUNT,35,0.01))
    if p1 is None:return np.empty((0,2)),np.empty((0,2)),np.empty((0,2)),len(p0)
    reverse,st_back,_=cv2.calcOpticalFlowPyrLK(b,a,p1,None,winSize=(21,21),maxLevel=3,
        criteria=(cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_COUNT,35,0.01))
    if reverse is None:return np.empty((0,2)),np.empty((0,2)),np.empty((0,2)),len(p0)
    fb=np.linalg.norm(p0.reshape(-1,2)-reverse.reshape(-1,2),axis=1)
    valid=(st.reshape(-1)>0)&(st_back.reshape(-1)>0)&(fb<=1.5)
    pp0=p0.reshape(-1,2)[valid];pp1=p1.reshape(-1,2)[valid]
    return pp0,pp1,pp1-pp0,len(p0)

def drone_frames(frames:list[np.ndarray],fps:float,output:Path,source_paths:list[str]|None=None,
                 work_unit:int=35)->dict:
    """Caller-supplied decoded video frames; read only; image flow not drone velocity.
    Frames must be same size and sequential, with known time base.
    """
    if fps<=0 or not math.isfinite(fps):raise ValueError('Need independently known or video-file frame rate')
    if len(frames)<2:raise ValueError('Need at least two decoded frames')
    sizes={frame.shape[:2] for frame in frames}
    if len(sizes)!=1:raise ValueError('Frames must be same pixel shape')
    output.mkdir(parents=True,exist_ok=True)
    pool=RipplePool(min_nodes=2,max_nodes=8,work_unit=work_unit)
    trace=[];events=[];pair_data=[];photo_stats=[]
    for idx in range(1,len(frames)):
        old,now=frames[idx-1],frames[idx]
        p0,p1,flow,detected=tracking_pair(old,now)
        count=len(flow)
        pool.adjust(count)
        n=pool.size
        brightness_diff=float(cv2.absdiff(cv2.cvtColor(now,cv2.COLOR_BGR2GRAY),
                    cv2.cvtColor(old,cv2.COLOR_BGR2GRAY)).mean()/255.0)
        features=[];columns=[]
        for node in range(n):
            lo=node*now.shape[1]/n;hi=(node+1)*now.shape[1]/n
            mask=(p0[:,0]>=lo)&(p0[:,0]<hi) if count else np.array([],dtype=bool)
            v=flow[mask]
            quality=min(1.0,round(len(v)/8,6))
            # Valid optical flow components -> bounded *virtual* inputs.
            # px/frame normalized against explicit 8px/frame reference, not RGB wavelengths.
            # green is regional brightness-difference fraction, blue is sparse-data inhibition.
            if len(v):
                med=np.median(v,axis=0)
                magnitude=float(np.linalg.norm(med))
            else:med=np.array([0.,0.]);magnitude=0.
            red=min(1.,magnitude/8.) if len(v)>=4 else 0.
            green=min(1.,brightness_diff) if len(v)>=4 else 0.
            blue=1.-quality
            features.append((red,green,blue));columns.append((lo,hi,med,len(v),quality))
        states=pool.feed(features,1/fps)
        for k,(f,state,(lo,hi,med,npts,quality)) in enumerate(zip(features,states,columns)):
            entry={'frame_pair':idx,'time_s':idx/fps,'node':k,'roi_x0_px':lo,'roi_x1_px':hi,
                   'features_used':npts,'quality_proxy':quality,'flow_dx_px_per_frame':float(med[0]),
                   'flow_dy_px_per_frame':float(med[1]),'flow_speed_px_per_second':float(np.linalg.norm(med)*fps),
                   'virtual_R':f[0],'virtual_G':f[1],'virtual_B':f[2],
                   'drive':state['drive'],'threshold':state['theta'],'spikes':state['count']}
            trace.append(entry)
            if state['count']:
                events.append({'frame_pair':idx,'node':k,'action':'LOG_APPARENT_IMAGE_MOTION',
                              'spikes':state['count'],'no_vehicle_action':True})
        medflow=np.median(flow,axis=0) if count else [0,0]
        pair_data.append({'pair':idx,'detected_features':detected,'valid_tracks':count,
                          'valid_fraction':count/max(1,detected),'median_dx_px_per_frame':float(medflow[0]),
                          'median_dy_px_per_frame':float(medflow[1]),
                          'median_image_speed_px_per_second':float(np.linalg.norm(medflow)*fps)})
        if idx==1:
            overlay=now.copy()
            for a,b in zip(p0[:150],p1[:150]):
                cv2.arrowedLine(overlay,tuple(map(int,a)),tuple(map(int,b)),(0,255,255),1,tipLength=.35)
            cv2.imwrite(str(output/'tracked_frame.png'),overlay)
    with (output/'neuron_trace.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=trace[0].keys());writer.writeheader();writer.writerows(trace)
    with (output/'flow_per_pair.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=pair_data[0].keys());writer.writeheader();writer.writerows(pair_data)
    summary={'adapter':ADAPTER,'core':MODEL,
             'provenance':'DIGITAL FILE PIXEL TRACKING, not independently calibrated ground-speed or flight telemetry',
             'source_paths':source_paths,'number_of_frames':len(frames),
             'frame_size_px':list(frames[0].shape[:2]),
             'fps_used':fps,'fps_basis':'caller input or video metadata; check timing for variable frame rate',
             'frame_pairs':pair_data,'total_events':sum(e['spikes'] for e in events),
             'node_pool_changes':pool.changes,'ending_nodes':pool.size,
             'limitations':'Optical flow measures image feature displacement, not 3D vehicle motion. '
                 'Scene depth, camera intrinsics, distortion, gimbal and rotation unresolved. '
                 'No flight commands. No optical-phase measurement. Virtual RGB inputs are engineered features.'}
    dump(output/'summary.json',summary);dump(output/'events.json',events)
    return summary

def video_measure(video_path:Path,output:Path,max_frames:int=121,step:int=1,fps_override:float|None=None):
    cap=cv2.VideoCapture(str(video_path))
    if not cap.isOpened():raise ValueError('Could not decode video')
    reported_fps=float(cap.get(cv2.CAP_PROP_FPS))
    fps=fps_override if fps_override is not None else reported_fps
    if not np.isfinite(fps) or fps<=0:raise ValueError('Video has no usable FPS; supply --fps')
    if max_frames<2 or step<1:raise ValueError('Need at least 2 frames and step>=1')
    frames=[];idx=0
    while len(frames)<max_frames:
        ok,frame=cap.read()
        if not ok:break
        if idx%step==0:frames.append(frame)
        idx+=1
    cap.release()
    return drone_frames(frames,fps/step,output,[str(video_path)+'#sha256='+sha(video_path)])

def main():
    p=argparse.ArgumentParser(description='Read-only scanner/drone optical measurements into locked Ripple neurons')
    sub=p.add_subparsers(dest='command',required=True)
    sp=sub.add_parser('scanner',help='measure reference/scan RGB digital differences')
    sp.add_argument('--reference',type=Path,required=True);sp.add_argument('--scan',type=Path,required=True)
    sp.add_argument('--output',type=Path,required=True);sp.add_argument('--no-alignment',action='store_true')
    vp=sub.add_parser('drone',help='measure optical flow from a RECORDED video (not flight control)')
    vp.add_argument('--video',type=Path,required=True);vp.add_argument('--output',type=Path,required=True)
    vp.add_argument('--fps',type=float);vp.add_argument('--step',type=int,default=1)
    vp.add_argument('--max-frames',type=int,default=121)
    rp=sub.add_parser('ruler',help='physical calibration based on manually located centers of two marks')
    rp.add_argument('--x1',type=float,required=True);rp.add_argument('--y1',type=float,required=True)
    rp.add_argument('--x2',type=float,required=True);rp.add_argument('--y2',type=float,required=True)
    rp.add_argument('--mm',type=float,required=True)
    args=p.parse_args()
    if args.command=='scanner': result=scanner_measure(args.reference,args.scan,args.output,alignment=not args.no_alignment)
    elif args.command=='drone':result=video_measure(args.video,args.output,args.max_frames,args.step,args.fps)
    else:result=ruler_distance((args.x1,args.y1),(args.x2,args.y2),args.mm)
    print(json.dumps(result,indent=2,allow_nan=False))
if __name__=='__main__':
    try:main()
    except (ValueError,FileNotFoundError) as ex:print(f'ERROR: {ex}',file=sys.stderr);sys.exit(2)
