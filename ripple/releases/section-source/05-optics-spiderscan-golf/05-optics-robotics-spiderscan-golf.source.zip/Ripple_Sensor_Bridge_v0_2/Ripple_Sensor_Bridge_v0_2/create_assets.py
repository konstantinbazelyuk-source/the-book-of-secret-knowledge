#!/usr/bin/env python3
"""Printable chart and vector engineering diagrams. Programmatic, dimensioned."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
from reportlab.pdfgen import canvas
from reportlab.lib.units import mm
from reportlab.lib.colors import HexColor
import matplotlib.pyplot as plt
import numpy as np
P=Path(__file__).resolve().parent
A=P/'assets';D=P/'design';A.mkdir(exist_ok=True);D.mkdir(exist_ok=True)
DPI=300;W,H=2550,3300
px=lambda mm_:int(round(mm_/25.4*DPI))
img=Image.new('RGB',(W,H),'white');d=ImageDraw.Draw(img)
try:
 f1=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',70)
 f2=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',32)
 f3=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',25)
except OSError:f1=f2=f3=None
d.text((px(19),px(18)),'RIPPLE / OPTICAL TEST CHART',font=f1,fill=(20,43,55))
d.text((px(19),px(30)),'PRINT 100% SCALE  |  NO FIT TO PAGE  |  VERSION 0.2',font=f2,fill=(30,92,86))
d.line((px(20),px(39),px(196),px(39)),fill=(25,90,70),width=6)
# exact design spacing: 100 mm center-to-center physically IF printed accurately
axis_y=px(57);left=px(45);right=px(145)
d.line((left,axis_y,right,axis_y),fill=(10,10,10),width=7)
for x in (left,right):
 d.rectangle((x-7,axis_y-23,x+7,axis_y+23),fill='black')
d.text((left-px(6),axis_y+px(4)),'0 mm',font=f2,fill=(0,0,0))
d.text((right-px(9),axis_y+px(4)),'100 mm',font=f2,fill=(0,0,0))
d.text((px(20),px(79)),'MEASURE RULER ON PAPER: verify with a physical ruler.',font=f2,fill=(20,20,20))
colors=[('R255',(255,0,0)),('G255',(0,255,0)),('B255',(0,0,255)),('White',(255,255,255)),
 ('Black',(0,0,0)),('Gray25',(64,64,64)),('Gray50',(128,128,128)),('Gray75',(192,192,192)),
 ('Orange',(255,128,0)),('Cyan',(0,255,255)),('Magenta',(255,0,255)),('Yellow',(255,255,0)),
 ('R64',(64,0,0)),('G64',(0,64,0)),('B64',(0,0,64)),('Neutral',(230,230,230))]
start_x=px(19);start_y=px(98);tile_w=px(41);tile_h=px(29);gap=px(4)
for i,(name,c) in enumerate(colors):
 row,col=divmod(i,4);x0=start_x+col*(tile_w+gap);y0=start_y+row*(tile_h+gap)
 d.rectangle((x0,y0,x0+tile_w,y0+tile_h),fill=c,outline=(45,45,45),width=4)
 d.text((x0+7,y0+tile_h+4),name,font=f3,fill=(20,20,20))
d.text((px(19),px(243)),'GRAYSCALE / EDGE TEST: 2-10 pixel bands',font=f2,fill=(10,10,10))
for j,stripe in enumerate((2,3,4,6,8,10)):
 y0=px(251)+j*20;x0=px(19)
 for k in range(0,px(175)//stripe):
  if k%2==0:d.rectangle((x0+k*stripe,y0,x0+(k+1)*stripe,y0+14),fill='black')
d.text((px(19),px(269)),'Not an absolute colorimetric standard. Printer + paper alter RGB.',font=f3,fill=(75,75,75))
img.save(A/'ripple_chart_reference_300dpi.png',dpi=(DPI,DPI),optimize=True)
c=canvas.Canvas(str(A/'PRINT_Ripple_Calibration_Chart_Actual_Size.pdf'),pagesize=(8.5*72,11*72))
c.drawImage(str(A/'ripple_chart_reference_300dpi.png'),0,0,width=8.5*72,height=11*72)
c.showPage();c.save()

def block(ax,x,y,w,h,title,sub,face='#f7faf9',edge='#426e66'):
 from matplotlib.patches import FancyBboxPatch
 p=FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.012,rounding_size=.018',facecolor=face,edgecolor=edge,linewidth=1.4)
 ax.add_patch(p);ax.text(x+w/2,y+h*.68,title,ha='center',va='center',fontsize=10,weight='bold',color='#193c49')
 ax.text(x+w/2,y+h*.31,sub,ha='center',va='center',fontsize=8,color='#31525d',linespacing=1.3)
def arrow(ax,xy,xy2,label=''):
 ax.annotate('',xy=xy2,xytext=xy,arrowprops=dict(arrowstyle='-|>',color='#386a74',lw=1.8))
 if label:ax.text((xy[0]+xy2[0])/2,(xy[1]+xy2[1])/2+.018,label,ha='center',fontsize=8,color='#506d77')
fig,axs=plt.subplots(2,1,figsize=(13,9),dpi=170)
for ax in axs:ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis('off')
ax=axs[0];ax.text(.02,.96,'A / SCANNER : COLOR + SPATIAL ERROR',fontsize=17,weight='bold')
block(ax,.02,.56,.20,.26,'Printed target','100 mm ruler · RGB patches\nphysical size must be verified')
block(ax,.29,.56,.20,.26,'Flatbed scanner','300 dpi requested ≠ guaranteed\nscan image file')
block(ax,.57,.56,.20,.26,'Digital calibration','align image · 8-bit RGB error\nmean / signed differences')
block(ax,.82,.56,.16,.26,'Ripple ×2','left & right tiles\nseparate neuron states')
arrow(ax,(.22,.69),(.29,.69));arrow(ax,(.49,.69),(.57,.69));arrow(ax,(.77,.69),(.82,.69))
ax.text(.04,.37,'Nominal pixel pitch = 25.4 / DPI = 0.08467 mm at 300 dpi',fontsize=11)
ax.text(.04,.24,'Measured effective DPI = (pixel distance / physically measured mm) × 25.4',fontsize=11)
ax.text(.04,.12,'Limits: scanner transfer function / ICC profile / gamma unknown; no phase, force or magnetic-field readout.',fontsize=9,color='#7a3831')
ax=axs[1];ax.text(.02,.96,'B / DRONE : CAMERA OPTICAL FLOW (READ-ONLY)',fontsize=17,weight='bold')
block(ax,.02,.56,.20,.26,'DJI video file','camera frames · FPS metadata\nno SDK or flight commands')
block(ax,.29,.56,.20,.26,'Feature tracking','Lucas–Kanade optical flow\nforward-backward filter')
block(ax,.57,.56,.20,.26,'Spatial partitions','node count follows load\n2–8 logical workers')
block(ax,.82,.56,.16,.26,'Ripple ×N','threshold / spike\nreport-only event logs')
arrow(ax,(.22,.69),(.29,.69));arrow(ax,(.49,.69),(.57,.69));arrow(ax,(.77,.69),(.82,.69))
ax.text(.04,.37,'Image flow: Δu = u[t+1] − u[t],   image speed = √(Δu²+Δv²) / Δt  [pixels/s]',fontsize=11)
ax.text(.04,.24,'Optical flow is not airspeed or ground speed; camera calibration + depth + pose needed for meters/s.',fontsize=10)
ax.text(.04,.12,'Locked Ripple drive D = 2.0R + 1.2G − 1.4B; drone RGB slots contain labelled VIRTUAL features.',fontsize=9,color='#7a3831')
fig.tight_layout(pad=1.6)
fig.savefig(D/'sensor_bridge_engineering_design.png',bbox_inches='tight')
plt.close(fig)

fig,ax=plt.subplots(figsize=(12,5),dpi=160)
ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis('off')
ax.text(.02,.92,'RIPPLE NODES — LOAD-REGULATED DUPLICATION',weight='bold',fontsize=16)
block(ax,.02,.52,.22,.25,'Measured features','Valid image tracks (N)\nscanner scanline chunks')
block(ax,.31,.52,.28,.25,'Pool coordinator','desired = clip(ceil(N/40), 2, 8)\n3 up / 6 down intervals')
block(ax,.68,.52,.28,.25,'Independent Ripple nodes','one spatial tile per node\nthresholds never shared')
arrow(ax,(.24,.64),(.31,.64));arrow(ax,(.59,.64),(.68,.64))
ax.text(.06,.29,'State update per node:  τᵥ du/dt = −u + D; spike when u ≥ θ, then u ← 0; refractory 0.1 s.',fontsize=11)
ax.text(.06,.17,'θ adapts to estimated event rate: dθ/dt = η(r̂ − r_target), bounded to [0.15, 2.5].',fontsize=11)
ax.text(.06,.07,'Scaling means more software instances, not added reasoning or physical CPUs.',fontsize=9,color='#7a3831')
fig.savefig(D/'ripple_node_pool_design.png',bbox_inches='tight');plt.close(fig)
print('Assets created')
