import hashlib, math, sys
from pathlib import Path
import cv2, numpy as np, pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from ripple_sensor_bridge import RipplePool,scanner_measure,ruler_distance,tracking_pair,drone_frames
from legacy.ripple_optical_agent import RippleNeuron,decode_phase,phase_step_intensities
BASE=Path(__file__).resolve().parents[1]

def test_core_locked_identical_to_v01_archive():
    expected='7f2f611cd8f1717c3d3dcae745dbd41efc37e24315d93878231db52eaf614f77'
    assert hashlib.sha256((BASE/'legacy/ripple_optical_agent.py').read_bytes()).hexdigest()==expected

def test_approved_rgb_coefficients_untouched():
    n=RippleNeuron()
    r=n.step((.4,.2,.1),.05)
    assert math.isclose(r['drive'],2*.4+1.2*.2-1.4*.1,abs_tol=1e-12)
    assert n.tau_v==.5 and n.refractory==.1 and n.eta==.08

def test_user_ruler_300dpi():
    v=ruler_distance((0,0),(300/25.4*100,0),100)
    assert abs(v['effective_dpi']-300)<1e-9
    assert abs(v['mm_per_pixel']-25.4/300)<1e-9

def test_same_scanner_image_zero_error(tmp_path):
    p=BASE/'fixtures/scanner_REFERENCE_digitally_rendered.png'
    s=scanner_measure(p,p,tmp_path,alignment=False)
    assert s['mean_absolute_pixel_error_8bit']==0
    assert s['alignment_status']=='off'
    assert s['mean_signed_rgb_difference_0to1']==[0,0,0]

def test_software_altered_scan_has_positive_error(tmp_path):
    s=scanner_measure(BASE/'fixtures/scanner_REFERENCE_digitally_rendered.png',
             BASE/'fixtures/scanner_OBSERVED_NOT_PHYSICAL_SCAN.png',tmp_path)
    assert 0<s['mean_absolute_pixel_error_8bit']<25
    assert s['alignment_status']=='ecc_aligned_not_verified'

def test_tracking_known_digitally_shifted_photo():
    p=cv2.imread(str(BASE/'fixtures/test_image_NOT_DRONE.png'))
    M=np.array([[1,0,3],[0,1,-2]],np.float32)
    shifted=cv2.warpAffine(p,M,(p.shape[1],p.shape[0]),borderMode=cv2.BORDER_REFLECT101)
    a,b,flow,detected=tracking_pair(p,shifted)
    assert len(flow)>=50
    med=np.median(flow,axis=0)
    assert abs(med[0]-3)<.3 and abs(med[1]+2)<.3

def test_file_video_runs_and_autoscales(tmp_path):
    path=BASE/'fixtures/fixture_motion_NOT_DRONE.mp4'
    cap=cv2.VideoCapture(str(path));frames=[]
    for _ in range(9):
        ok,frame=cap.read();assert ok;frames.append(frame)
    cap.release()
    summary=drone_frames(frames,20,tmp_path,source_paths=['SOFTWARE FIXTURE'])
    assert summary['ending_nodes']>=3
    assert summary['total_events']>=0
    assert len(summary['frame_pairs'])==8
    assert abs(summary['frame_pairs'][-1]['median_dx_px_per_frame']-1.5)<.30
    assert abs(summary['frame_pairs'][-1]['median_dy_px_per_frame']+.8)<.30

def test_node_pool_scales_up_and_down_with_hysteresis():
    pool=RipplePool(min_nodes=2,max_nodes=8,work_unit=20)
    for i in range(3):pool.adjust(100)
    assert pool.size==5
    for i in range(6):pool.adjust(0)
    assert pool.size==2 and len(pool.changes)==2
    assert pool.nodes[0].theta==.45

def test_strict_invalid_inputs():
    with pytest.raises(ValueError):ruler_distance((1,1),(1,1),100)
    with pytest.raises(ValueError):ruler_distance((1,1),(3,4),-1)
    with pytest.raises(ValueError):RipplePool(8,2)

def test_earlier_interferometer_decodes_phases_but_is_separate():
    import random
    raw=phase_step_intensities(0,random.Random(12),noise_sigma=0)
    angle,_,_=decode_phase(raw)
    assert abs(angle)<1e-10
