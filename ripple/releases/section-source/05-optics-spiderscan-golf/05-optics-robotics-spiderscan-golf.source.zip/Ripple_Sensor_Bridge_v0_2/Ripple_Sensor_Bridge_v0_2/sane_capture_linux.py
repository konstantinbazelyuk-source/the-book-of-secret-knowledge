#!/usr/bin/env python3
"""Linux SANE file acquisition helper; requires real compatible scanner and sane-utils.
Acquires one scan at user invocation; no hardware testing was possible here.
SPDX-License-Identifier: CC0-1.0
"""
from __future__ import annotations
import argparse,shutil,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser(description='Capture a real image file from a SANE scanner on Linux')
p.add_argument('--list',action='store_true',help='show currently detected devices and exit')
p.add_argument('--device',help='exact ID obtained from --list, otherwise default device')
p.add_argument('--dpi',type=int,default=300,choices=[75,150,300,600])
p.add_argument('--out',type=Path,help='target PNG path')
a=p.parse_args()
if not shutil.which('scanimage'):sys.exit('scanimage not installed; install sane-utils on Linux')
if a.list:
 result=subprocess.run(['scanimage','--list-devices'],text=True,check=False)
 sys.exit(result.returncode)
if a.out is None:p.error('--out is required unless --list')
if a.out.suffix.lower()!='.png':p.error('--out must be PNG')
if a.out.exists():p.error('output exists; refuse overwrite')
a.out.parent.mkdir(parents=True,exist_ok=True)
cmd=['scanimage','--format=png',f'--resolution={a.dpi}']
if a.device:cmd.extend(['--device-name',a.device])
cmd.extend(['--output-file',str(a.out)])
print('Requesting scanner acquisition:',cmd)
r=subprocess.run(cmd,check=False)
if r.returncode:sys.exit(f'SANE scan failed with return code {r.returncode}; inspect scanimage --help for device-specific resolution support')
if not a.out.exists() or a.out.stat().st_size==0:sys.exit('scanner returned no image file')
print(f'Saved {a.out} ({a.out.stat().st_size} bytes). Image has not been independently calibrated.')
