# Ripple Sensor Bridge v0.2 — scanner / DJI-camera research prototype

**Status: RUNNING, TESTED FILE-INPUT SOFTWARE. NO CONNECTED HARDWARE WAS MEASURED.**

This is an additive experimental bridge built beside the **approved Ripple Neuron v0.1**. The original neuron class and its equations have not been edited. The source file is preserved, byte-for-byte, in `legacy/ripple_optical_agent.py`, SHA-256:

`7f2f611cd8f1717c3d3dcae745dbd41efc37e24315d93878231db52eaf614f77`

It turns **actual incoming scanner image files** or **recorded DJI video files** into digital measurements and feeds those measurements into independent Ripple neuron instances. The prototype does not modify printer firmware, command flight, navigate, learn a language, understand a scene, perform quantum computation, or directly detect light's electric/magnetic-field waveform.

## Inventory / engineering output

- `ripple_sensor_bridge.py`: runnable scanner comparator, video optical-flow measurement and dynamic logical-neuron pool, manual physical ruler calibration.
- `sane_capture_linux.py`: optional **real scanner image acquisition** via the installed Linux SANE command-line tool (not testable here without a physical scanner). Users invoke it explicitly; it refuses overwrites.
- `assets/PRINT_Ripple_Calibration_Chart_Actual_Size.pdf`: **US Letter, 300-DPI PDF** print target. Print **Actual Size / 100%**; verify the 100-mm printed mark with a real ruler before claiming a calibration.
- `assets/ripple_chart_reference_300dpi.png`: raster source, **2550 × 3300 pixels** for an 8.5 × 11 inch sheet at **300 pixels per inch**; digitally specified size is not physical printed accuracy.
- `design/sensor_bridge_engineering_design.png`: both device signal and calculation pipelines.
- `design/ripple_node_pool_design.png`: adaptive logical allocation and locked core laws.
- `fixtures/`: explicitly named **software-created fixtures**, including a digitally altered chart and a digitally shifted public-domain real-world photograph. **NOT real scanner/drone captures.**
- `results/`: measurements extracted from those **digital fixtures**, plus pixel-level measurements from the archived real-world photograph.
- `tests/test_bridge.py`: ten executed automated tests.
- `legacy/ripple_optical_agent.py`: the unchanged previous **simulated interferometer + neuron** model. Running it still generates *only* simulated laser measurement signals.

## Installation

Python 3.10 or newer is recommended.

```bash
python -m pip install -r requirements.txt
python -m pip install pytest   # tests only
python -m pytest tests -q
```

OpenCV + NumPy run locally, without online inference APIs. The included fixtures don't require a DJI app, scanner driver, or internet connection. To regenerate demonstration assets (`make_demonstration_data.py`, `create_assets.py`), also install Pillow, reportlab, matplotlib and scikit-image; **these extra packages are not needed to run or inspect the finished prototype**.

## REAL scanner experiment — user hardware required

1. Print `assets/PRINT_Ripple_Calibration_Chart_Actual_Size.pdf` at **Actual Size**, **no page fit**. Place a ruler on the printed 100-mm mark and record the real physical separation. Mark true printed values as a **measured physical fact**, *not* 100 mm just because software requested it.
2. Scan the printed target in **color** at the device's available native resolution (ideally 300 DPI, without software sharpening, rescaling, automatic enhancement or scan-to-PDF conversion). Save **PNG**. Different printer profiles/paper can change RGB substantially. An ICC-managed chart is needed to quantify absolute color accuracy.
3. On Linux, if supported, acquire directly with:

```bash
python sane_capture_linux.py --list
python sane_capture_linux.py --out /path/to/real_scan.png --dpi 300
```

   On Windows/macOS, scan using manufacturer software, export PNG, and process the file below. SANE resolution options are device-specific: consult `scanimage --help`.

4. Measure the scan file:

```bash
python ripple_sensor_bridge.py scanner \
  --reference assets/ripple_chart_reference_300dpi.png \
  --scan /path/to/real_scan.png \
  --output results/my_first_PHYSICAL_scan
```

5. Record pixel coordinates of the two centerlines of the **physically measured** ruler marks on the original unresized scan. Example command (numbers are an *illustration*, not observed positions):

```bash
python ripple_sensor_bridge.py ruler --x1 400 --y1 500 --x2 1581 --y2 500 --mm 100
```

   This would imply 300-ish effective DPI, **but only if the measured physical mark is truly 100 mm and the endpoints come from the original scan**. The tool does not automatically find or verify endpoints. If the physical mark was actually 99.5 mm, enter 99.5, not 100.

Outputs: source hashes, original image sizes, ECC image-registration attempt, mean measured RGB channel values, signed/absolute digital channel differences, 8-bit pixel error, clipped-channel fraction, 2-neuron sample trace, and read-only events. RGB differences compare digitally encoded scan values, **not absolute light intensity, radiance, spectral phase, atomic spin, or magnetic flux**.

**Scanner quality limitations:** auto white balance and nonlinear gamma can bias the RGB readings. A failed image alignment, paper skew, crop or margins invalidate naive pixel comparisons. The comparator internally resizes to a common analysis grid for computational consistency; **never infer scanner DPI from this resized analysis**. Use the original scan plus ruler for effective DPI. The neuron time steps correspond to sampled spatial strips, not the scanner's real physical scan motor timing.

## REAL DJI video experiment — user footage required

Remove the microSD card or export an unedited drone video recording. No DJI SDK integration or flight control is necessary to analyze footage. Run:

```bash
python ripple_sensor_bridge.py drone \
  --video /path/to/DJI_0001.MP4 \
  --output results/my_first_drone_recording \
  --max-frames 300
```

If frame-rate metadata is missing/incorrect, supply `--fps 29.97` from an independently verified source. `--step 2` samples every second frame (effective sample rate is halved); video with variable frame timing requires timestamp-aware preprocessing not implemented here. Any video OpenCV decodes can be used; **compatibility of a DJI SDK with a given aircraft is irrelevant to file processing**, but future direct SDK acquisition depends on the model.

Measures **pyramidal Lucas–Kanade optical flow** using detected corners and a 1.5-pixel forward/backward consistency check; reports median horizontal/vertical **image displacement in pixels/frame** and **image speed pixels/second**. It does *not* claim ground speed, distance to objects, object semantics or machine intelligence. Camera/gimbal rotation and parallax can generate apparent motion even when the aircraft position is constant. No ground-speed conversion without measured intrinsics, distortion, depth and camera pose.

The software splits valid tracking points by **image-space vertical regions**, each assigned to one independent Ripple neuron. Node count follows measured valid track load: `desired = clamp(ceil(valid_tracks / 35), 2, 8)`, with **three consecutive high-load intervals** to expand and **six consecutive low-load intervals** to contract. These are **logical node instances in a single process**; extra nodes DO NOT automatically speed up CPU processing. Each newborn node begins with the original initial state; it does not inherit another neuron's history. Every node computes its own adaptive threshold, pulses and normalized three-feature input; the drone feature adapter is **not a literal red/green/blue spectrum measurement**.

## Core math: preserved vs proposed

### LOCKED Ripple v0.1 neuron (untouched)

- `D = 2.0 R + 1.2 G − 1.4 B`
- `tau_v * du/dt = −u + D`, with `tau_v = 0.5 s`
- On crossing `u >= theta`: emit event, reset `u = 0`, refractory `0.1 s`.
- Estimated event rate decays with `tau_r = 5.0 s`.
- `dtheta/dt = 0.08 * (estimated_rate − target_rate)`; target `1 event/s`; bounds `0.15 <= theta <= 2.5`.
- The code uses the archived exact-crossing solution instead of integrating naively.

### PROPOSED scanner optical adapter

- Normalized observed red, green, blue = image's mean encoded 8-bit red/green/blue values divided by 255 over a spatial strip.
- The RGB channels are NOT calibrated optical wavelength power. Gamma-coded image numbers are not linear photon flux.
- Raw signed digital error: `mean((scan − digital_reference)/255)`; mean absolute 8-bit pixel difference: `mean(abs(scan − reference))`.
- Pixel pitch *if sampling is true to specified DPI*: `25.4 / DPI mm/px`.
- Physical measurement from ruler: `effective_DPI = pixel_separation / physically_verified_mm * 25.4`.

### PROPOSED drone image-motion adapter

- Track features between two frames with `p1 − p0`; median flow over each spatial region.
- Input R (virtual) = `min(1, norm(median_flow)/8)` for **at least four valid tracks**; otherwise 0.
- Input G (virtual) = mean absolute **grayscale image frame difference / 255**, if ≥4 tracks; otherwise 0.
- Input B (virtual) = `1 − min(1, valid_region_tracks/8)` as a simple sparse-data inhibitor. This is a **heuristic confidence proxy**, not a statistically calibrated probability.
- No trainable weights, inverse optics inference, holography, quantum bit, unsupervised intelligence or LLM has been added.

### Previous laser experiment stays separate

The old `legacy/ripple_optical_agent.py` simulates four-phase interferometry:

`I(delta) = Is + Ir + 2*sqrt(Is*Ir)*cos(phi + delta)`, `phi = 4*pi*z/lambda` for reflection geometry.

That is a valid measurement *model*, but no physical laser, beamsplitter, phase shifter, balanced photodiode, ADC or calibrated sensor produced its previous numerical result. Commodity scanners and DJI cameras do not provide those four IQ measurements directly. **Do not mistake the separate laser simulation for a realized optical sensor**.

## Automated evaluation (2026-10-13 session)

`python -m pytest tests -q`: **10 passed**, including locked-source integrity, original coefficients, mathematical ruler calibration, exact-identical-scan comparison, altered digital chart image, Lucas–Kanade known digital translation, recorded-fixture video ingestion, pool growth/contraction, invalid input validation and the earlier analytic interferometer decoding.

**Measured values from DIGITAL data, not measured physical devices:**

- Digitally altered scanner chart: **7.459 8-bit intensity counts** mean absolute channel error **after ECC registration and resizing**. The error is from deliberately altered image files, *not a printer or scanner calibration measurement*.
- Translated real-world photo texture (40 image pairs; 20 fps): median measured **+1.5003 px/frame horizontally** and **−0.8095 px/frame vertically**, against the software-specified nominal fixture translation **+1.5 and −0.8**. More significant vertical errors appear at individual frames due to interpolation and MPEG-4 compression.
- The video demo generated **16 logged Ripple neuron events**, ending with **8 logical node instances**; these event quantities are algorithm parameters, not evidence of a cognitive capability.
- **A real-world photograph** from `scikit-image.data.astronaut()` (not taken or scanned for this project) was read from its pixel array: average R/G/B encoded values **141.56 / 105.76 / 96.48**, center pixel **[19,14,7]**. This is an authentic *archived image-file numerical measurement*, but provides **no calibrated physical illumination measurement**.
- Real physical scanner acquisitions executed **0**. Real DJI video acquisitions executed **0**. Quantum experiments executed **0**.

## Acceptance test for the future physical build (PROPOSED, NOT YET PASSED)

1. Print the target at 100% and verify actual 100-mm ruler separation with a measuring device. Save dimensions, paper, printer settings, driver and scanner settings.
2. Acquire at least 5 independent scans with the same exposure/scan settings; calculate mean signed channel variation and standard deviations. Evaluate alignment manually against the chart.
3. Under documented stationary lighting, acquire a known unedited DJI video. Record actual resolution and frame rate, run the optical-flow pipeline, inspect tracked frame/false correspondences and check for gimbal rotation.
4. For quantitative motion validation, use a physically measured translational checkerboard target with surveyed movement in the image plane; report pixel-position uncertainty. Do not infer drone ground-speed accuracy from target tests alone.
5. Confirm neuron outputs reproduce earlier single-core tests and that node scaling does not change the approved model. Evaluate false alarms and program CPU/memory/throughput before making any autonomous decision claim.

## Scientific references

- SANE `scanimage` manual: https://www.sane-project.org/man/scanimage.1.html
- OpenCV sparse pyramidal LK and ECC registration: https://docs.opencv.org/doc/doxygen/html/dc/d6b/group__video__track.html
- OpenCV physical calibration patterns: https://docs.opencv.org/5.0/tutorials/calib3d/camera_calibration_pattern/camera_calibration_pattern.html
- DJI mobile SDK supported hardware (for **future live capture only**): https://developer.dji.com/doc/mobile-sdk-tutorial/en/index.html
- scikit-image archived test-image provenance: https://scikit-image.org/docs/stable/api/skimage.data.html

## Evidence / scope boundaries

**Programmatically calculated**: precise PDF target dimensions, pixel pitch formulas, accepted geometry, neuron integration, image-file statistics.

**Measured from archived image pixels**: RGB values of a real-world photograph. This is *not a local hardware measurement*.

**Measured from synthetic fixtures**: scanner-chart RGB differences and video optical flow, real code operating on generated digital observations. Their visual texture partly derives from a real public-domain image, but the motion is synthetic.

**Proposed hardware**: actual physical scanner and DJI recordings. No device make/model was supplied. No apparatus physically assembled or evaluated.

**Not demonstrated**: electromagnetic push/pull sensing, light's instantaneous phase from a scanner or drone camera, quantum coherence/entanglement, self-directed reasoning, learning, LLM behavior, autonomous flight or printing.

Project code, diagrams and newly created artifacts are released CC0-1.0. The public-domain archived photo is credited to `scikit-image`/NASA in its provenance file. Preserve credits when redistributing source data. Do not present examples as empirical device tests.
