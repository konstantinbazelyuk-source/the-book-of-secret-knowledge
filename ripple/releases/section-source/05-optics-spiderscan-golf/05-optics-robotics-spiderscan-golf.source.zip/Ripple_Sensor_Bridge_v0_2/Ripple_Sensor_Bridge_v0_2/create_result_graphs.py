#!/usr/bin/env python3
import json,csv,hashlib
from pathlib import Path
import numpy as np,cv2,matplotlib.pyplot as plt
P=Path(__file__).resolve().parent
R=P/'results'
scan=json.loads((R/'scanner_digital_fixture/summary.json').read_text())
labels=['Red','Green','Blue'];vals=scan['mean_absolute_rgb_error_0to1']
fig,ax=plt.subplots(figsize=(7.8,3.8),dpi=170)
ax.bar(labels,vals)
ax.set_ylabel('Mean absolute digital color difference (0–1)')
ax.set_title('Scanner-path software fixture — not a physical scan')
ax.grid(axis='y',alpha=.18)
fig.tight_layout();fig.savefig(R/'scanner_RGB_error_fixture.png');plt.close(fig)
drone=json.loads((R/'drone_digital_fixture/summary.json').read_text())
rows=drone['frame_pairs'];idx=np.array([r['pair'] for r in rows]);dx=np.array([r['median_dx_px_per_frame'] for r in rows]);dy=np.array([r['median_dy_px_per_frame'] for r in rows]);
fig,ax=plt.subplots(figsize=(8.5,3.8),dpi=170)
ax.plot(idx,dx,label='Measured horizontal image shift (digital frames)')
ax.plot(idx,dy,label='Measured vertical image shift (digital frames)')
ax.axhline(1.5,linestyle='--',label='Fixture horizontal truth: +1.5 px/frame')
ax.axhline(-.8,linestyle=':',label='Fixture vertical truth: −0.8 px/frame')
ax.set(xlabel='Frame pair',ylabel='Image displacement (px/frame)',title='Drone-analysis pipeline / digitally moved public-domain photograph')
ax.legend(loc='upper right',fontsize=7);ax.grid(alpha=.17)
fig.tight_layout();fig.savefig(R/'drone_flow_fixture.png');plt.close(fig)
# Unmodified image captured by an actual camera in an archived public-domain photo;
# measurements are digital pixel statistics, NOT a new physical scanner capture.
p=P/'fixtures/test_image_NOT_DRONE.png';a=cv2.cvtColor(cv2.imread(str(p)),cv2.COLOR_BGR2RGB)
hist={k:dict(mean_8bit=float(a[:,:,i].mean()),min_8bit=int(a[:,:,i].min()),
             max_8bit=int(a[:,:,i].max()),stddev_8bit=float(a[:,:,i].std()))
      for i,k in enumerate('RGB')}
pixels={'description':'FILE MEASUREMENTS OF A REAL-WORLD HISTORICAL PHOTOGRAPH; image source scikit-image astronaut() / NASA; NOT scanner/drone hardware.',
        'file_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'shape_px':list(a.shape),
        'rgb_8bit_channel_statistics':hist,'center_pixel_rgb8':a[256,256].tolist(),
        'colorspace':'8-bit sRGB-like encoded image; ICC profile not calibrated','source':'https://scikit-image.org/docs/stable/api/skimage.data.html#skimage.data.astronaut'}
(R/'archived_real_photo_pixel_measurements.json').write_text(json.dumps(pixels,indent=2)+'\n')
print(json.dumps({'digital_fixture_flow_med_dx':float(np.median(dx)),
                  'digital_fixture_flow_med_dy':float(np.median(dy)),
                  'mean_abs_dx_error':float(np.mean(np.abs(dx-1.5))),
                  'mean_abs_dy_error':float(np.mean(np.abs(dy+.8))),
                  'archived_camera_photo_center_RGB8':pixels['center_pixel_rgb8'],
                  'archived_camera_image_rgb_means':{k:round(v['mean_8bit'],2) for k,v in hist.items()}},indent=2))
