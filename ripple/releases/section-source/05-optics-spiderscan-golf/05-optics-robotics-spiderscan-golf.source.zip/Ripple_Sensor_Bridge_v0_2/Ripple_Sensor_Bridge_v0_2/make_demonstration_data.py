#!/usr/bin/env python3
"""Reproducible fixture. WARN: no scanner/drone connected; movement is SYNTHETIC."""
import cv2, numpy as np, json
from pathlib import Path
P=Path(__file__).resolve().parent;F=P/'fixtures';F.mkdir(exist_ok=True)
rng=np.random.default_rng(20815)
reference=cv2.imread(str(P/'assets/ripple_chart_reference_300dpi.png'))
# Downscaled chart fixture is a software-generated resampling, NOT a physical scan.
ref=cv2.resize(reference,(850,1100),interpolation=cv2.INTER_AREA)
# Construct a digitally altered image with rotation, translation and per-channel response.
M=cv2.getRotationMatrix2D((425,550),.32,1.003);M[:,2]+=np.array([2.5,-1.7])
warped=cv2.warpAffine(ref,M,(850,1100),borderValue=(255,255,255))
observed=(warped.astype(np.float32)*np.array([.97,1.025,.93],dtype=np.float32).reshape(1,1,3)+4)
observed+=rng.normal(0,1.6,observed.shape)
observed=np.uint8(np.clip(np.round(observed),0,255))
cv2.imwrite(str(F/'scanner_REFERENCE_digitally_rendered.png'),ref)
cv2.imwrite(str(F/'scanner_OBSERVED_NOT_PHYSICAL_SCAN.png'),observed)
# Real photographed pixel TEXTURE from scikit-image astronaut image. All motion digital.
try:
 from skimage.data import astronaut
 photo=cv2.cvtColor(astronaut(),cv2.COLOR_RGB2BGR)
 origin='scikit-image astronaut example (real-world photograph); its spatial translation is software-generated'
except ImportError:
 photo=rng.integers(0,256,(512,512,3),dtype=np.uint8)
 origin='synthetic pixel image'
cv2.imwrite(str(F/'test_image_NOT_DRONE.png'),photo)
path=F/'fixture_motion_NOT_DRONE.mp4';fourcc=cv2.VideoWriter_fourcc(*'mp4v')
writer=cv2.VideoWriter(str(path),fourcc,20.0,(512,512))
if not writer.isOpened():raise RuntimeError('Video writer not available')
for k in range(41):
 M=np.float32([[1,0,1.5*k],[0,1,-0.8*k]])
 out=cv2.warpAffine(photo,M,(512,512),borderMode=cv2.BORDER_REFLECT101)
 writer.write(out)
writer.release()
(F/'ORIGIN.json').write_text(json.dumps({
 'physical_measurement':False,'scanner_reference':'software rasterized chart','scanner_observed':'digitally altered chart; synthetic noise and geometry',
 'drone_video':origin,'video_translation_truth_px_per_frame':[1.5,-0.8],
 'video_type':'video codec mp4v lossily compressed','no_DJI_hardware_used':True,
 'no_scanner_hardware_used':True
},indent=2)+'\n')
print(F, list(x.name for x in F.iterdir()))
