#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
python3 scripts_verify.py
python3 -m unittest discover -s tests -v
python3 -m src.cli run --request '{"op":"golf_status"}'
echo 'New laptop engine verified; archived parent regression suites are separately documented.'
