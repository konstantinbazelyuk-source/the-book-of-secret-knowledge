"""Golf Laptop Runtime: bounded native OS jobs, persistent SQLite, multiprocessing, real parent invocation."""
from __future__ import annotations
import concurrent.futures as futures
from contextlib import contextmanager
import hashlib
import json
import math
import multiprocessing as mp
import os
from pathlib import Path
import queue
import sqlite3
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request
import wave
from .hardware import discover,telemetry

ROOT=Path(__file__).resolve().parent.parent
PARENT=ROOT/'parents'/'Golf-Ripple-Metrology-Engine-v0.3'
MAX_OUT=2_000_000


def hash_work(loops,seed):
    """CPU-bound deterministic physical computation in a separate OS process."""
    d=hashlib.sha256(str(seed).encode()).digest()
    for _ in range(loops):d=hashlib.sha256(d).digest()
    return {'sha256':d.hex(),'loops':loops,'seed':seed,'pid':os.getpid()}


def _jsonable(value):
    s=json.dumps(value,allow_nan=False)
    if len(s)>MAX_OUT:raise ValueError('result exceeds bounded output size')
    return s


def _safe_path(root, rel, existing=False):
    if not isinstance(rel,str) or not rel or len(rel)>240 or '\x00' in rel:raise ValueError('invalid path')
    raw=Path(rel)
    if raw.is_absolute() or '..' in raw.parts or rel.startswith('\\') or ':' in rel:raise ValueError('workspace-relative paths only')
    candidate=root / raw
    resolved=candidate.resolve(strict=False)
    if not resolved.is_relative_to(root.resolve()):raise ValueError('path escaped workspace')
    if existing and (not resolved.is_file() or resolved.is_symlink()):raise ValueError('regular file not found')
    return resolved


def _file_task(workspace,payload):
    op=payload['op'];rel=payload.get('path','')
    if op=='file_list':
        base=workspace if not rel else _safe_path(workspace,rel)
        if not base.is_dir():raise ValueError('directory absent')
        return {'entries':[{'path':p.relative_to(workspace).as_posix(),'size':p.stat().st_size,'directory':p.is_dir()} for p in sorted(base.iterdir()) if not p.is_symlink()][:200]}
    target=_safe_path(workspace,rel,existing=op in {'file_read','file_digest','file_remove','text_analyze','audio_wav'})
    if op=='file_write':
        content=payload.get('content')
        if not isinstance(content,str) or len(content.encode())>1_000_000 or target.suffix.lower() not in {'.txt','.md','.json','.csv'}:raise ValueError('invalid text payload or extension')
        target.parent.mkdir(parents=True,exist_ok=True)
        if target.exists():raise ValueError('file already exists; no overwrite allowed')
        target.write_text(content,encoding='utf-8')
        return {'path':rel,'bytes':len(content.encode()),'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}
    if target.stat().st_size>20_000_000:raise ValueError('file size limit 20 MB')
    if op=='file_remove':
        if target.suffix.lower() not in {'.txt','.md','.json','.csv'}:raise ValueError('remove type disallowed')
        target.unlink();return {'removed':rel}
    if op=='file_digest':
        h=hashlib.sha256();n=0
        with target.open('rb') as f:
            for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk);n+=len(chunk)
        return {'sha256':h.hexdigest(),'bytes':n}
    if op=='file_read':
        if target.suffix.lower() not in {'.txt','.md','.json','.csv','.py','.mjs','.js','.ts'} or target.stat().st_size>200_000:raise ValueError('text read only <= 200 KB')
        return {'text':target.read_text(encoding='utf-8'),'path':rel}
    if op=='text_analyze':
        if target.suffix.lower() not in {'.txt','.md','.csv','.json'}:raise ValueError('text file required')
        import re
        s=target.read_text(encoding='utf-8');words=re.findall(r"\b\w+\b",s.lower())
        freqs={w:words.count(w) for w in set(words)}
        return {'characters':len(s),'words':len(words),'unique_words':len(freqs),'top_terms':sorted(freqs.items(),key=lambda x:(-x[1],x[0]))[:12],'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'claim':'lexical counts only; no language comprehension claimed'}
    raise ValueError('unsupported file operation')


def _wav_analyze(root,payload):
    target=_safe_path(root,payload['path'],existing=True)
    if target.stat().st_size>20_000_000 or target.suffix.lower()!='.wav':raise ValueError('WAV <=20 MB required')
    import struct
    with wave.open(str(target),'rb') as wf:
        n=wf.getnframes();rate=wf.getframerate();width=wf.getsampwidth();channels=wf.getnchannels()
        if channels not in (1,2) or width not in (1,2,4) or n>rate*120 or rate<4000:raise ValueError('unsupported WAV format')
        samples=wf.readframes(n)
    fmt={1:'B',2:'h',4:'i'}[width]
    count=len(samples)//width
    if not count:raise ValueError('empty WAV')
    values=struct.iter_unpack('<'+fmt,samples)
    bias=128 if width==1 else 0;scale=128. if width==1 else float(1<<(width*8-1))
    power=sum(((x[0]-bias)/scale)**2 for x in values)/count
    return {'duration_seconds':n/rate,'rms_normalized':math.sqrt(power),'sample_rate_hz':rate,'channels':channels,'sample_count':count,'calibration':'decoded digital PCM, not calibrated acoustic pressure'}


def _node_goal(payload,envdir,timeout=50):
    cmd=payload['op'];allowed={'golf_status':'status','golf_selfscan':'selfscan','golf_frame':'frame','golf_goal':'goal'}
    if cmd not in allowed:raise ValueError('parent operation disallowed')
    argv=['node',str(ROOT/'src'/'golf_bridge.mjs'),allowed[cmd]]
    if cmd=='golf_goal':
        g=payload.get('goal');
        if not isinstance(g,dict) or g.get('kind') not in {'metrology','eyes','golf'}:raise ValueError('unapproved parent goal')
        argv.append(_jsonable(g))
    if cmd=='golf_frame':
        argv.extend([payload.get('file','observed_before.png'),payload.get('second','observed_after.png')])
    env={**os.environ,'GOLF_LAPTOP_RUNTIME':str(envdir.parent),'GOLF_PYTHON':sys.executable}
    cp=subprocess.run(argv,cwd=str(PARENT),env=env,capture_output=True,text=True,timeout=timeout,shell=False)
    if cp.returncode!=0:raise RuntimeError('parent returned '+str(cp.returncode)+': '+cp.stderr[-600:])
    if len(cp.stdout)>MAX_OUT:raise ValueError('parent output too large')
    return json.loads(cp.stdout)


def _net_probe(payload,hosts):
    url=payload.get('url','')
    parsed=urllib.parse.urlsplit(url)
    if parsed.scheme!='https' or parsed.username or parsed.password or parsed.port not in (None,443) or parsed.hostname not in hosts:raise ValueError('HTTPS host not explicitly allowlisted')
    if not parsed.hostname or len(url)>1000:raise ValueError('invalid URL')
    req=urllib.request.Request(url,headers={'User-Agent':'GolfRippleLaptop/0.4'},method='HEAD')
    # No following redirects: avoid crossing the allowlist boundary.
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self,*args,**kwargs):return None
    opener=urllib.request.build_opener(NoRedirect())
    try:
        with opener.open(req,timeout=6) as resp:return {'http_status':resp.status,'url':url,'headers':{'content-type':resp.headers.get('Content-Type')},'network':'actual HTTPS HEAD; no content downloaded'}
    except urllib.error.HTTPError as e:return {'http_status':e.code,'url':url,'network':'actual HTTPS HEAD, response error'}


def _gpu_compute(payload,reported_backend=None):
    import torch
    dev=reported_backend
    if dev not in {'cuda','mps'}:raise ValueError('GPU backend did not pass readiness test')
    n=payload.get('matrix_size',256)
    if type(n)!=int or not 32<=n<=2048:raise ValueError('matrix size out of range')
    a=torch.ones((n,n),device=dev,dtype=torch.float32)
    t=time.perf_counter();c=a@a
    if dev=='cuda':torch.cuda.synchronize()
    value=float(c[0,0].item());elapsed=time.perf_counter()-t
    if value!=n:raise RuntimeError('GPU output verification failed')
    return {'backend':dev,'size':n,'observed_cell':value,'elapsed_seconds':elapsed,'check':'actual verified tensor operation'}


class Engine:
    def __init__(self,base_dir=None,workers=None,config=None):
        self.root=Path(base_dir or ROOT/'runtime').resolve();self.root.mkdir(parents=True,exist_ok=True)
        self.workspace=self.root/'workspace';self.workspace.mkdir(exist_ok=True)
        self.parent_data=self.root/'parent-data';self.parent_data.mkdir(exist_ok=True)
        self.db_path=self.root/'golf.sqlite3'
        self.config=config or {}
        self.hardware=discover(self.root,gpu_probe=bool(self.config.get('gpu_probe',False)))
        self.cores=self.hardware['cpu']['effective'];self.max_workers=min(self.cores,61 if os.name=='nt' else self.cores)
        if workers is not None:self.max_workers=min(self.max_workers,max(1,int(workers)))
        memory=self.hardware['memory']['available_bytes']
        if memory:self.max_workers=min(self.max_workers,max(1,int(memory//(384*1024*1024))))
        self.max_workers=max(1,self.max_workers)
        if self.config.get('autoscale_from_benchmark',True):
            performance=self.root/'performance.json'
            try:
                bench=json.loads(performance.read_text())
                if bench.get('cpu_model')==self.hardware['cpu']['model'] and bench.get('effective_cores')==self.cores and time.time()-bench.get('timestamp',0)<7*24*3600:
                    self.max_workers=min(self.max_workers,max(1,int(bench['recommended_workers'])))
            except (OSError,ValueError,KeyError,TypeError):pass
        self.threads=futures.ThreadPoolExecutor(max_workers=min(8,max(2,self.max_workers)),thread_name_prefix='golf-io')
        self.processes=futures.ProcessPoolExecutor(max_workers=self.max_workers,mp_context=mp.get_context("spawn"))
        self.stop=threading.Event();self.pending=queue.Queue(maxsize=int(self.config.get('queue_size',128)))
        self.active=0;self.lock=threading.Lock();self.last_monitor=telemetry();self.bus_callbacks=[]
        self._initialize()
        self.dispatcher=threading.Thread(target=self._dispatch,name='golf-scheduler',daemon=True);self.dispatcher.start()
        self.monitor=threading.Thread(target=self._monitor,name='golf-monitor',daemon=True);self.monitor.start()

    @contextmanager
    def _conn(self):
        c=sqlite3.connect(self.db_path,timeout=10)
        try:
            c.row_factory=sqlite3.Row;c.execute('PRAGMA journal_mode=WAL');c.execute('PRAGMA busy_timeout=10000')
            yield c
            c.commit()
        except BaseException:
            c.rollback()
            raise
        finally:
            c.close()
    def _initialize(self):
        with self._conn() as db:
            db.executescript('''CREATE TABLE IF NOT EXISTS jobs(id INTEGER PRIMARY KEY,operation TEXT NOT NULL,status TEXT NOT NULL,payload TEXT NOT NULL,result TEXT,error TEXT,created_at REAL,updated_at REAL);
                CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY,type TEXT NOT NULL,payload TEXT NOT NULL,created_at REAL NOT NULL);
                CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS models(name TEXT PRIMARY KEY,model TEXT NOT NULL,metrics TEXT NOT NULL,updated_at REAL NOT NULL);''')
            db.execute("UPDATE jobs SET status='interrupted',error='service restart; no automatic re-execution',updated_at=? WHERE status IN ('queued','running')",(time.time(),))
    def _event(self,kind,payload):
        data=_jsonable(payload)
        with self._conn() as db: db.execute('INSERT INTO events(type,payload,created_at) VALUES (?,?,?)',(kind,data,time.time()))
        for cb in list(self.bus_callbacks):
            try: cb(kind,payload)
            except Exception: pass
    def subscribe(self,callback):self.bus_callbacks.append(callback)
    def submit(self,payload):
        if not isinstance(payload,dict) or len(_jsonable(payload))>50000:raise ValueError('bounded JSON object required')
        op=payload.get('op')
        supported={'cpu_hash','golf_status','golf_selfscan','golf_frame','golf_goal','file_list','file_write','file_remove','file_read','file_digest','text_analyze','audio_wav','https_probe','gpu_matmul','matrix_compute','linear_train','linear_predict','app_run'}
        if op not in supported:raise ValueError('unsupported operation')
        if self.pending.full():raise RuntimeError('queue at capacity')
        with self._conn() as db:
            cur=db.execute('INSERT INTO jobs(operation,status,payload,created_at,updated_at) VALUES (?,?,?,?,?)',(op,'queued',_jsonable(payload),time.time(),time.time()))
            job=cur.lastrowid
        try:self.pending.put_nowait(job)
        except queue.Full:
            with self._conn() as db:db.execute('UPDATE jobs SET status=?,error=? WHERE id=?',('rejected','queue full',job))
            raise RuntimeError('queue full')
        self._event('job.queued',{'job_id':job,'op':op});return job
    def _monitor(self):
        while not self.stop.is_set():
            self.last_monitor=telemetry()
            self.stop.wait(2)
    def _safe_to_run(self):
        t=self.last_monitor
        if t.get('temperature_c') is not None and t['temperature_c']>=85:return False,'CPU thermal reading >=85C'
        if t.get('memory_percent') is not None and t['memory_percent']>=90:return False,'memory pressure >=90%'
        if t.get('available_memory_bytes') is not None and t['available_memory_bytes']<200_000_000:return False,'available memory <200 MB'
        if t.get('battery_percent') is not None and t.get('battery_plugged') is False and t['battery_percent']<=12:return False,'low battery'
        return True,None
    def _dispatch(self):
        while not self.stop.is_set():
            try:job=self.pending.get(timeout=.3)
            except queue.Empty:continue
            while not self.stop.is_set():
                permitted,_=self._safe_to_run()
                with self.lock:room=self.active<self.max_workers
                if permitted and room:break
                self.stop.wait(.25)
            if self.stop.is_set():break
            with self.lock:self.active+=1
            self.threads.submit(self._execute,job)
    def _execute(self,job):
        started=time.perf_counter()
        try:
            with self._conn() as db:
                row=db.execute('SELECT payload,operation FROM jobs WHERE id=?',(job,)).fetchone()
                db.execute('UPDATE jobs SET status=?,updated_at=? WHERE id=?',('running',time.time(),job))
            if not row:return
            payload=json.loads(row['payload']);op=row['operation']
            if op=='cpu_hash':
                loops=payload.get('loops',40000);seed=payload.get('seed',1)
                if type(loops)!=int or not 100<=loops<=1_000_000 or type(seed)!=int or not -1_000_000<=seed<=1_000_000:raise ValueError('loops/seed limits')
                # Actual CPU-bound work executes in a distinct worker process.
                result=self.processes.submit(hash_work,loops,seed).result(timeout=120)
            elif op in {'golf_status','golf_selfscan','golf_frame','golf_goal'}:
                result=_node_goal(payload,self.parent_data,timeout=90 if op=='golf_selfscan' else 45)
            elif op=='app_run':
                key=payload.get('name');allowed=self.config.get('approved_apps',{})
                if type(key)!=str or key not in allowed:raise ValueError('application not approved in configuration')
                spec=allowed[key]
                if not isinstance(spec,dict) or any(k not in ('executable','arguments') for k in spec):raise ValueError('invalid app config')
                executable=spec.get('executable');arguments=spec.get('arguments',[])
                if type(executable)!=str or not Path(executable).is_absolute() or not Path(executable).is_file():raise ValueError('configured installed application absent')
                if not isinstance(arguments,list) or len(arguments)>12 or not all(type(a)==str and len(a)<=200 for a in arguments):raise ValueError('invalid fixed app arguments')
                cp=subprocess.run([executable,*arguments],shell=False,capture_output=True,text=True,timeout=15,cwd=str(self.workspace))
                result={'application':key,'exit_code':cp.returncode,'stdout':cp.stdout[:10000],'stderr':cp.stderr[:2000],'truncated_output':len(cp.stdout)>10000 or len(cp.stderr)>2000,'process':'actual explicitly allowlisted installed application; fixed argument vector'}
            elif op=='audio_wav':result=_wav_analyze(self.workspace,payload)
            elif op=='linear_train':
                from .learning import train_csv
                name=payload.get('name','default');epochs=payload.get('epochs',120)
                if type(name)!=str or not (1<=len(name)<=40) or not all(c.isalnum() or c in '_-' for c in name):raise ValueError('model name invalid')
                csv_file=_safe_path(self.workspace,payload.get('path',''),existing=True)
                if csv_file.suffix.lower()!='.csv':raise ValueError('CSV required')
                t=train_csv(csv_file,epochs)
                with self._conn() as db:db.execute('INSERT OR REPLACE INTO models(name,model,metrics,updated_at) VALUES (?,?,?,?)',(name,_jsonable(t['model']),_jsonable(t['metrics']),time.time()))
                result={'name':name,**t['metrics'],'stored':True}
            elif op=='linear_predict':
                from .learning import predict
                name=payload.get('name','default')
                with self._conn() as db:record=db.execute('SELECT model FROM models WHERE name=?',(name,)).fetchone()
                if record is None:raise ValueError('model not trained')
                result=predict(json.loads(record['model']),payload.get('features'))

            elif op=='https_probe':result=_net_probe(payload,set(self.config.get('allowed_https_hosts',[])))
            elif op=='gpu_matmul':result=_gpu_compute(payload,self.hardware['gpu_acceleration'].get('backend') if self.hardware['gpu_acceleration'].get('available') else None)
            elif op=='matrix_compute':
                if self.hardware['gpu_acceleration'].get('available'):
                    result=_gpu_compute(payload,self.hardware['gpu_acceleration'].get('backend'))
                else:
                    import numpy as np
                    n=payload.get('matrix_size',256)
                    if type(n)!=int or not 32<=n<=2048:raise ValueError('matrix size out of range')
                    a=np.ones((n,n),dtype=np.float32)
                    t=time.perf_counter();y=a@a
                    result={'backend':'numpy_cpu','size':n,'observed_cell':float(y[0,0]),'elapsed_seconds':time.perf_counter()-t,'check':'actual CPU matrix multiplication; GPU not available'}
                    if result['observed_cell']!=n:raise RuntimeError('CPU matrix output incorrect')

            else:result=_file_task(self.workspace,payload)
            result=_jsonable({'data':result,'processing_seconds':round(time.perf_counter()-started,6),'evidence_class':'MEASURED_EXECUTION'})
            with self._conn() as db:db.execute('UPDATE jobs SET status=?,result=?,updated_at=? WHERE id=?',('completed',result,time.time(),job))
            self._event('job.completed',{'job_id':job,'op':op,'seconds':round(time.perf_counter()-started,6)})
        except Exception as exc:
            with self._conn() as db:db.execute('UPDATE jobs SET status=?,error=?,updated_at=? WHERE id=?',('failed',(type(exc).__name__+': '+str(exc))[:700],time.time(),job))
            self._event('job.failed',{'job_id':job,'error':type(exc).__name__})
        finally:
            with self.lock:self.active-=1
    def job(self,job):
        with self._conn() as db:
            x=db.execute('SELECT * FROM jobs WHERE id=?',(job,)).fetchone()
            if x is None:return None
            out=dict(x)
            for k in ('payload','result'):
                if out[k] is not None:out[k]=json.loads(out[k])
            return out
    def events(self,limit=30):
        with self._conn() as db:
            return [{**dict(r),'payload':json.loads(r['payload'])} for r in db.execute('SELECT * FROM events ORDER BY id DESC LIMIT ?',(max(1,min(100,int(limit))),))]
    def status(self):
        return {'release':'0.4.0-beta.1','cpu_workers_limit':self.max_workers,'active_jobs':self.active,'pending_queue':self.pending.qsize(),'measured_telemetry':self.last_monitor,'hardware_report_scope':'current process host; not the user Dell unless running there','parent_source':str(PARENT),'database':str(self.db_path)}
    def wait(self,job,timeout=120):
        deadline=time.monotonic()+timeout
        while time.monotonic()<deadline:
            x=self.job(job)
            if x and x['status'] in {'completed','failed','interrupted','rejected'}:return x
            time.sleep(.1)
        raise TimeoutError('job did not finish in deadline')
    def close(self):
        self.stop.set();self.dispatcher.join(timeout=3);self.monitor.join(timeout=3)
        self.threads.shutdown(wait=True,cancel_futures=False)
        self.processes.shutdown(wait=True,cancel_futures=True)
