#!/usr/bin/env sh
# User-initiated user-level systemd service, not root.
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
mkdir -p "$HOME/.config/systemd/user"
PY=$(command -v python3)
cat > "$HOME/.config/systemd/user/golf-ripple-laptop.service" <<EOF
[Unit]
Description=Golf Ripple laptop-native local engine
After=network.target
[Service]
Type=simple
WorkingDirectory="$ROOT"
ExecStart="$PY" -m src.cli serve
Restart=on-failure
RestartSec=10
[Install]
WantedBy=default.target
EOF
systemctl --user daemon-reload
systemctl --user enable --now golf-ripple-laptop.service
printf 'User service registered. Check: systemctl --user status golf-ripple-laptop.service\n'
