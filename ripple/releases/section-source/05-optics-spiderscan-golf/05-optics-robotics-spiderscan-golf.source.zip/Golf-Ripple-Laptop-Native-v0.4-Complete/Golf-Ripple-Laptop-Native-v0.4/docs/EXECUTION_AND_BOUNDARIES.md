# Execution evidence — Golf Ripple Laptop v0.4.0-beta.1

## Engineering status: current release

- **Executed on available Linux compute host, not on the physical Dell**: OS `Linux 6.18.44`, architecture `x86_64`, Python `3.13.5`, Node `v22.16.0`; Intel Xeon Platinum 8573C virtual host reports 5 logical CPUs accessible but a 4-core cgroup quota. Memory at inspection was approximately 6.24 GB total; disk volume approximately 33.77 GB total. These host values must not be transcribed as Dell specifications. Manufacturer/model were not detected (null); `machine_is_dell=false`.
- **Implemented and locally executed**: bounded CPU process pool with spawn process creation; fixed allowlisted installed-program invocation (actual Python interpreter `--version`); background task threads; concurrent SQLite event/job/weights persistence; authenticated loopback HTTP; approved workspace files; PCM WAV RMS; optical screenshot analysis through the locked Golf v0.3; preserved engine status; CPU matrix multiplication; reproducible logistic regression trained on the recorded Iris Setosa-vs-Versicolor dataset.
- **Locally measured**: warm-start concurrent SHA-256 throughput (2,400,000 total rounds per trial): one worker approx **1,682,553 rounds/s**, two workers **3,125,409 rounds/s**, four workers **3,331,215 rounds/s** on this host, measured in separate process pools with untimed warmup. These are small hash workloads and not general AI training throughput. Local real Iris binary classifier heldout **20/20** on a single 80/20 split; this does not imply other datasets or tasks will succeed. `results/benchmark.json` preserves actual raw timings.
- **Locally calculated**: CPU/memory telemetry, hashes, image-space luminance, supervised logistic coefficients. These are deterministic calculations on actual software/data.
- **Simulated/inherited**: original neuron firing and synthetic colonies. The Dell-native runtime invokes preserved mathematical program behavior; it does not relabel simulated neuron events as biological readings.
- **Actual GPU acceleration on the test host**: unavailable: installed PyTorch is CPU-only and no CUDA/MPS matrix backend passed. CPU matrix multiplication executed and returned correct 256×256 matrix cell value of 256. No GPU benchmark claimed.
- **Not tested or delivered**: Dell model/specifications, Windows integration behavior, physically measured laptop CPU/GPU benchmark, verified heat dissipation under sustained load, Windows Scheduled Tasks registration, image capture from a Dell webcam, cloud compute deployment, quantum hardware, arbitrary installed-application automation, general-purpose learned intelligence, automatic execution of arbitrary third-party code. Windows CIM PowerShell probes and a startup registration script are supplied but require a live Dell test.

## Verified parent regressions

- Golf Metrology v0.3 preserved tests: **25 Node + 7 Python** passed, including exact archived-source lock check.
- Earlier Eyes v0.2 verification chain: **20 Python tests**, **16 Eyes Node tests**, **16 additional Eyes Node tests**, **23 OS Engine tests**, **49 inherited services tests** all passed. The command also ran the archived Golf CLI demonstration successfully. These are regression counts from the inherited tests, not newly invented independent experiments.
- Laptop integration test suite: **14 tests** passed, covering true process fork/spawn, authenticated HTTP, memory/temperature pauses, CPU hash validation, real WAV amplitude, file and network protections, SQLite persistence, actual inherited Golf processing, and supervised numeric training.

## Open issues / concrete limitations

1. Scheduled-task and systemd user-service installers are untested here. Run manually and verify on the destination OS before opting into autostart.
2. Temperature sensors may be unavailable on some Windows computers. When they cannot be read, the engine reports `null`; it cannot guarantee overheating protection or adjust fan speeds. Firmware/OS throttling remains authoritative.
3. GPU discovery distinguishes enumerated devices from compute-tested devices. CUDA/MPS are the only compute backends implemented. Intel DirectML, Vulkan compute, oneAPI, ROCm, and GPU inference libraries require additional engineering, not generic abstraction promises.
4. Interrupted jobs persist as `interrupted`, without automatic replay or checkpoint continuation. Background server itself remains active only while operating-system session/service runs.
5. Strict file operations are limited to one workspace; arbitrary filesystem/system automation is intentionally not enabled by default. Network operations are blocked until explicitly allowlisted.
6. Parent v0.3 `selfscan` with nested regression tests stalled/timed out during integration diagnostics. This new child runs all eight actual source inspections **without nested tests** and keeps parent test runs separate. The parent files were not edited to hide that behavior.
7. API is private-loopback and bearer-protected but has not received an external penetration test. Protect both folder permissions and the bearer-token file.

## Independent references

- Python `concurrent.futures.ProcessPoolExecutor` and Windows spawn worker requirements: https://docs.python.org/3/library/concurrent.futures.html
- Microsoft hardware CIM objects (`Win32_ComputerSystem`, `Win32_Processor`, `Win32_VideoController`): https://learn.microsoft.com/en-us/powershell/scripting/samples/collecting-information-about-computers
- NVIDIA `nvidia-smi` monitoring: https://docs.nvidia.com/deploy/nvidia-smi/
- SQLite WAL journal behavior: https://www.sqlite.org/wal.html
- psutil CPU thermal sensor access/limitations: https://psutil.readthedocs.io/
- Real recorded Fisher Iris measurements, scikit-learn loader: https://scikit-learn.org/stable/modules/generated/sklearn.datasets.load_iris.html

No physical Dell hardware was used in the reported Linux execution. This document and the benchmark JSON make that distinction machine-checkable.
