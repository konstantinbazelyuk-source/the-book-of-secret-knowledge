@echo off
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
 py -3 -m src.cli serve
) else (
 python -m src.cli serve
)
pause
