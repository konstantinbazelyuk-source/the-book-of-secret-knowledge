# User-initiated optional registration. Tested only by code inspection on Linux, NOT on Windows.
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Script = Join-Path $Root 'START-GOLF-LAPTOP-WINDOWS.bat'
if (-not (Test-Path $Script)) { throw 'Golf launch script not found' }
$Action = New-ScheduledTaskAction -Execute "$env:ComSpec" -Argument ('/c "' + $Script + '"') -WorkingDirectory $Root
$Trigger = New-ScheduledTaskTrigger -AtLogOn -User "$env:USERDOMAIN\$env:USERNAME"
Register-ScheduledTask -TaskName 'GolfRippleLaptop' -Action $Action -Trigger $Trigger -Description 'Local Golf Ripple authorized laptop runtime at login' -Force | Out-Null
Write-Host 'Registered. It will run at the next interactive logon.'
Write-Host 'The bearer token is stored in runtime\access-token.txt after first start. Keep the folder private.'
Write-Host 'To unregister: Unregister-ScheduledTask -TaskName GolfRippleLaptop -Confirm:$false'
