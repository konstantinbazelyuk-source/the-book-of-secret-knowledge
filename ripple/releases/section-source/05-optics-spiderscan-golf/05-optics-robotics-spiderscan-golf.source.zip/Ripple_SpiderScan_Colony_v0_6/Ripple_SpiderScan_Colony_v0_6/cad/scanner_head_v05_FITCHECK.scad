// Ripple SpiderScan ground v0.5 - prototype FIT CHECK only, units MILLIMETRES
// Manufacturer Octobot mounting coordinates are NOT verified; editable slots.
// Three target exports via -D 'PART="head"' ... -D 'PART="tof"'
PART="head";      // head, tof, strain
$fn=48;
module slot(x,y,w=5.2,length=14,height=9){
 translate([x,y,-1])hull(){translate([-(length-w)/2,0,0])cylinder(d=w,h=height);translate([(length-w)/2,0,0])cylinder(d=w,h=height);}
}
module head(){
 difference(){
  union(){cube([112,86,4],center=true);
  // two low guard rails, no mechanical fastening to camera board assumed
  for(y=[-24,24])translate([0,y,3])cube([44,4,6],center=true);
  }
  translate([0,0,-3])cylinder(d=41,h=10); // lens aperture with 3D optical clearance check
  for(x=[-46,46],y=[-32,32])slot(x,y);
  // alternate mount slots for unknown chassis; do not assume octobot hole pattern
 }
}
module tof(){
 difference(){
 union(){cube([52,28,4],center=true);for(x=[-20,20])translate([x,0,2])cube([4,22,7],center=true);}
 for(x=[-15,15])slot(x,0,3.4,9,9);
 translate([0,0,-4])cube([13,13,10],center=true); // sensor optical aperture
 }
}
module strain(){
 difference(){cube([34,24,5],center=true);
 for(y=[-7,7])slot(0,y,3.6,13,9);
 translate([0,0,2])cube([15,3,3],center=true);
 }
}
if(PART=="head")head();
if(PART=="tof")tof();
if(PART=="strain")strain();
