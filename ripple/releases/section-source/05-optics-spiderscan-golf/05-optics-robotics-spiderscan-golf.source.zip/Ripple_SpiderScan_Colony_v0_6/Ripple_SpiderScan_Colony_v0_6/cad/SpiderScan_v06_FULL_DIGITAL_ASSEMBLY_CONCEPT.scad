// SPIDERSCAN v0.6 - eight-legged digital assembly REFERENCE, NOT qualified hardware.
// Original geometry and mock joint casings are NOT dimensionally matched to Octobot STEP.
// Obtain MIT-licensed real chassis and leg STEP files from https://github.com/Deivid-Negoita/octobot
// Servo dimensions, horn offsets, brackets, battery, mounts, cable exits MUST be measured before manufacture.
// Units: mm. Printable sensor tray is separately inherited from v0.5.
$fn=40;
body_d=160; body_thick=7; leg_mount_radius=87;
coxa=32; femur=72; tibia=95;
hip_z=155; tibia_to_foot=90; foot_z=15;
color([0.1,0.18,0.23]) translate([0,0,hip_z]) cylinder(d=body_d,h=body_thick,center=true,$fn=8);
color([0.1,0.18,0.23]) translate([0,0,hip_z+12]) cylinder(d=128,h=2,center=true,$fn=8);
// Pi 4 85x56 mm envelope and mount brackets; not an electrical enclosure
color([0.16,0.54,0.36])translate([0,15,hip_z+28])cube([85,56,17],center=true);
// Global shutter camera 38x38x19.8mm official physical envelope, pointed downward
color([0.12,0.3,0.55])translate([0,0,hip_z-22])cube([38,38,19.8],center=true);
// 1/4-20 center-lens camera mounting reference shown as optical line
color([0.5,0.7,0.96,0.15])translate([0,0,68])cylinder(h=hip_z-93,d1=92,d2=12,center=false);
// two separate ToF fixture envelopes; breakout board dimensions MUST be checked
color([0.88,0.55,0.1]) translate([0,-53,hip_z-5])cube([23,18,10],center=true); // forward-looking
color([0.88,0.55,0.1]) translate([45,0,hip_z-25])cube([23,18,10],center=true); // downward-looking
module link_between(a,b,r){
  d=[b[0]-a[0],b[1]-a[1],b[2]-a[2]];L=norm(d);
  translate(a)rotate(a=acos(d[2]/L),v=[-d[1],d[0],0]) cylinder(h=L,r=r,center=false);
}
for(i=[0:7]){
 a=i*360/8;
 color([0.17,0.22,0.29]) rotate([0,0,a]) {
   // 3 DOF schematic per leg: hip yaw, shoulder pitch, knee pitch
   translate([leg_mount_radius,0,hip_z])sphere(d=22);
   link_between([leg_mount_radius,0,hip_z],[leg_mount_radius+coxa,0,hip_z],7);
   translate([leg_mount_radius+coxa,0,hip_z])sphere(d=18);
   link_between([leg_mount_radius+coxa,0,hip_z],[leg_mount_radius+coxa+femur*0.771,0,hip_z-femur*0.637],6);
   translate([leg_mount_radius+coxa+femur*0.771,0,hip_z-femur*0.637])sphere(d=15);
   link_between([leg_mount_radius+coxa+femur*0.771,0,hip_z-femur*0.637],[leg_mount_radius+coxa+femur*0.944,0,foot_z],6);
   color([0.05,0.07,0.09])translate([leg_mount_radius+coxa+femur*0.944,0,foot_z])sphere(d=18);
 }
}
