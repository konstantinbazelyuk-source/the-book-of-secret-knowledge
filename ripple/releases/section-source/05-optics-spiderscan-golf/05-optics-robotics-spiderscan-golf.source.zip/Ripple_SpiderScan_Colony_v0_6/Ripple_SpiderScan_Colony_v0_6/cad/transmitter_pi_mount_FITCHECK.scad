// OpenSCAD fit-check cradle for Raspberry Pi 4, 85 x 56 mm nominal.
// NOT mountable on unverified Octobot chassis without drilling/measuring.
$fn=48;
board_x=85;board_y=56;stand_h=10;
base_x=101;base_y=72;base_t=3;
post_pts=[[-29,-24.5],[-29,24.5],[29,-24.5],[29,24.5]];
difference(){
 union(){
  cube([base_x,base_y,base_t],center=true);
  for(p=post_pts) translate([p[0],p[1],0])cylinder(h=stand_h+2,d=8);
 }
 for(p=post_pts)translate([p[0],p[1],-4])cylinder(h=20,d=2.7); // M2.5 nominal clearance - verify
 // 4 horizontal slotted *unconfirmed chassis* tie-downs
 for(sx=[-1,1],sy=[-1,1])translate([sx*44,sy*26,0])hull(){
  translate([0,-3,0])cylinder(h=6,d=4,center=true);
  translate([0,3,0])cylinder(h=6,d=4,center=true);
 }
}
