"""Repeatable software benchmark; does NOT read physical scanner or robot sensors."""
import json, time,statistics,tempfile,hashlib,os
from pathlib import Path
import cv2
from src.ground_colony import GroundColony
from spidercolony.chunkmap import ChunkMap
from spidercolony.colony_memory import ColonyMemory
from spidercolony.transport import Receiver,Outbox,make_packet
from spidercolony.kinematics import solve_leg,forward_leg,wave_support
ROOT=Path(__file__).parent
image=cv2.imread(str(ROOT/'fixtures/archived_photo_NOT_HARDWARE.png'))
assert image is not None
colony=GroundColony();trials=[];pop=[];spikes=0
for i in range(60):
    start=time.perf_counter();o=colony.process(image,dt=.05)
    trials.append((time.perf_counter()-start)*1000);pop.append(o['nodes']);spikes+=o['events']
with tempfile.TemporaryDirectory() as t:
    cm=ChunkMap(Path(t)/'map.sqlite',cell_mm=50)
    start=time.perf_counter();changed=0
    for i in range(80):
        res=cm.update_ray(i*50-2000,0,((i*13)%360),300+(i%8)*150,detected=True,max_ray_mm=2500)
        changed+=res['changed_cells']
    map_ms=(time.perf_counter()-start)*1000
    map_stats=cm.stats();cm.close()
    skill=ColonyMemory(Path(t)/'skills.sqlite')
    for _ in range(22):skill.outcome('image_input_parse',True,'software_fixture')
    for _ in range(8):skill.outcome('sensor_stale_rejection',True,'software_fixture')
    skills=skill.skills();skill.close()
result={'evidence':'MEASURED_SOFTWARE_ONLY','image_origin':'archived_photograph_NOT_SPIDERSCAN',
'image_shape_hwc':list(image.shape),'colony_frames':60,'colony_nodes_min_max':[min(pop),max(pop)],
'colony_events':spikes,'colony_frame_time_ms':{'median':round(statistics.median(trials),3),'p95':round(sorted(trials)[int(.95*(len(trials)-1))],3)},
'heuristic_map_rays':80,'map_runtime_ms':round(map_ms,2),'map_cells_changed':changed,'map_stats':map_stats,
'skill_demo':skills,'physical_sensor_samples':0,'locomotion_trials':0,
'notes':'Map rays use synthetic pose/ranges and are occupancy hypotheses only; no ground navigation clearance.'}
(ROOT/'results/bench_v06.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
