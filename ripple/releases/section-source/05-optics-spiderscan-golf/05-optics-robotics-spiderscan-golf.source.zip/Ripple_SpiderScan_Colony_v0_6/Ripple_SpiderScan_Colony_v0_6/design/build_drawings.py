from pathlib import Path
from math import sin,cos,pi,tan,radians
import numpy as np, matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from spidercolony.kinematics import solve_leg,forward_leg
from spidercolony.chunkmap import ChunkMap
ROOT=Path(__file__).parents[1]

def assembly():
    fig=plt.figure(figsize=(11,8));ax=fig.add_subplot(111,projection='3d')
    phi=np.linspace(0,2*pi,9)
    rad=87
    b=np.array([(rad*cos(v),rad*sin(v),155) for v in phi]);ax.plot(*b.T,color='#263a55',linewidth=7)
    # proposed hip-relative 100mm radial foot reach + 140mm down.
    yaw,shoulder,knee=solve_leg(100,0,140)
    for n in range(8):
        ang=2*pi*n/8
        local=np.array([[0,0,0],[32,0,0],[32+72*cos(shoulder),0,-72*sin(shoulder)],
                        [100,0,-140]],dtype=float)
        X=rad+local[:,0];Y=local[:,1];Z=155+local[:,2]
        Xw=X*cos(ang)-Y*sin(ang);Yw=X*sin(ang)+Y*cos(ang)
        ax.plot(Xw,Yw,Z,color='#2c587e',linewidth=5,marker='o',markersize=6)
    # represent head
    ax.scatter([0],[0],[128],s=650,marker='s',color='#d79532',label='global shutter camera (envelope)')
    ax.plot([-300,300],[0,0],[0,0],color='#aaa',linewidth=1,alpha=.4)
    ax.set(xlabel='X mm',ylabel='Y mm',zlabel='Z mm', title='SPIDERSCAN | eight-leg kinematic assembly (proposed dimensions)')
    ax.set_xlim(-250,250);ax.set_ylim(-250,250);ax.set_zlim(0,215)
    ax.view_init(elev=27,azim=-45);ax.legend(loc='lower left',fontsize=8)
    fig.text(.5,.035,'Not Octobot-derived dimensions. 24 DOF analytical pose; no motor torque, ground contacts or real fit verified.',ha='center',fontsize=9)
    fig.savefig(ROOT/'design/SpiderScan_v06_assembly_reference.png',dpi=160,bbox_inches='tight');plt.close(fig)

def architecture():
    fig,ax=plt.subplots(figsize=(12,7));ax.axis('off')
    blocks=[('Pi Global Shutter IMX296\nPicamera2 BGR bytes',(.01,.66),(.25,.18),'#e6eef5'),('2 x VL53L1X ToF\nTCA9548A I2C mux',(.01,.36),(.25,.17),'#e6eef5'),('RPi 4\nRipple core + colony scheduler',(.34,.53),(.28,.20),'#e5efe8'),('Chunk map\nSQLite / zlib / 16x16',(.70,.68),(.28,.17),'#f4efe3'),('Authenticated TX\nWPA2 Wi-Fi + TCP/TLS',(.70,.38),(.28,.17),'#f4efe3'),('Base station\nACK + SQLite + replay filter',(.70,.10),(.28,.17),'#f4efe3'),('Physical locomotion\nOctobot 24 servo controller',(.02,.07),(.43,.15),'#f2e0e0')]
    for label,(x,y),(w,h),color in blocks:
        from matplotlib.patches import FancyBboxPatch
        ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.012',fc=color,ec='#253543',lw=1.2))
        ax.text(x+w/2,y+h/2,label,ha='center',va='center',fontsize=10)
    arrows=[((.26,.75),(.34,.64)),((.26,.44),(.34,.59)),((.62,.65),(.70,.755)),((.62,.59),(.70,.47)),((.84,.38),(.84,.27))]
    for start,end in arrows:ax.annotate('',xy=end,xytext=start,arrowprops=dict(arrowstyle='->',lw=2,color='#334e68'))
    ax.text(.44,.30,'Observation/report only\nNO actuator-control link',ha='center',fontsize=10,color='#a52d2d',weight='bold')
    ax.text(.5,.95,'SPIDERSCAN COLONY v0.6 | evidence-separated computing + transmitter',ha='center',fontsize=15,weight='bold')
    ax.text(.5,.005,'Motor controller retains separate safety/kill switch. No flight hardware. TLS certificate required for non-loopback transmission.',ha='center',fontsize=9)
    fig.savefig(ROOT/'design/System_architecture_v06.png',dpi=180,bbox_inches='tight');plt.close(fig)

def optical():
    h=np.arange(80,361,20);fx=6.0;sw=1456*.00345;sh=1088*.00345
    fig,ax=plt.subplots(figsize=(9,4.8));ax.plot(h,sw*h/fx,label='Horizontal footprint (theoretical)');ax.plot(h,sh*h/fx,label='Vertical footprint (theoretical)')
    ax.axvline(160,color='grey',linestyle='--');ax.set(xlabel='Working distance (mm)',ylabel='Field of view (mm)',title='Pinhole projection example | 6 mm lens, IMX296 pixels')
    ax.grid(alpha=.2);ax.legend();fig.subplots_adjust(bottom=.26);fig.text(.5,.025,'Calculated only. Actual focus, distortion, motion, and perspective must be measured.',ha='center',fontsize=9)
    fig.savefig(ROOT/'design/optics_working_distance.png',dpi=170,bbox_inches='tight');plt.close(fig)
if __name__=='__main__':assembly();architecture();optical()
