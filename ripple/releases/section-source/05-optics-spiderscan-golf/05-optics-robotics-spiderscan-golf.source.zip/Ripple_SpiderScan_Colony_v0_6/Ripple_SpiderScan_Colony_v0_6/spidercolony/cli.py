"""Runnable image+ground-sensor pipeline. No motor controls.
Example: python -m spidercolony.cli demo --out results/demo
"""
import argparse,hashlib,json,os,socket,time
from pathlib import Path
import cv2
from spidercolony.chunkmap import ChunkMap
from spidercolony.colony_memory import ColonyMemory
from spidercolony.transport import Outbox,run_receiver
from src.ground_colony import GroundColony
from src.scan_quality import image_quality
from src.safety import GroundGate,Ranges

def scan_once(img_bgr,range_sample,pose,cm,colony,memory,outbox,timestamp=None,verified_capture=False,gate=None,dt=0.05):
    timestamp=time.monotonic() if timestamp is None else timestamp
    safety=(gate or GroundGate()).evaluate(range_sample,timestamp)
    visual=image_quality(img_bgr)
    node=colony.process(img_bgr,dt=dt)
    memory.add(timestamp,node['tiles'])
    evidence={'source':range_sample.source,'pose_provided':pose is not None,
              'map_mutation_authorized':bool(verified_capture and pose and range_sample.source=='hardware' and not safety['reasons'])}
    mapchange=None
    if evidence['map_mutation_authorized']:
        # User pose must already be calibrated. Readings do not imply pose accuracy.
        mapchange=cm.update_ray(pose['x_mm'],pose['y_mm'],pose['yaw_deg'],range_sample.forward_mm,
                  detected=range_sample.forward_mm<2000,max_ray_mm=2500)
    report={'origin':range_sample.source,'safety':safety,'image_quality':visual,
            'colony':{'nodes':node['nodes'],'tick':node['tick'],'events':node['events']},
            'map':cm.stats(),'map_update':mapchange,'map_delta':mapchange['delta'] if mapchange else [],'evidence':evidence}
    outbox.put(report)
    return report

def main():
    p=argparse.ArgumentParser();sub=p.add_subparsers(dest='action',required=True)
    d=sub.add_parser('demo');d.add_argument('--out',default='results/demo');d.add_argument('--image',default='fixtures/archived_photo_NOT_HARDWARE.png')
    s=sub.add_parser('scan');s.add_argument('--image',required=True);s.add_argument('--range-json',required=True);s.add_argument('--pose-json');s.add_argument('--out',required=True)
    h=sub.add_parser('capture-hardware');h.add_argument('--out',required=True);h.add_argument('--pose-json')
    r=sub.add_parser('receiver');r.add_argument('--host',default='127.0.0.1');r.add_argument('--port',type=int,default=8765);r.add_argument('--db',default='results/receiver.sqlite');r.add_argument('--cert');r.add_argument('--private-key')
    t=sub.add_parser('transmit');t.add_argument('--host',default='127.0.0.1');t.add_argument('--port',type=int,default=8765);t.add_argument('--out',required=True);t.add_argument('--ca-cert')
    a=p.parse_args();key=os.environ.get('SPIDER_TELEMETRY_KEY','').encode()
    if a.action in ('transmit','receiver') and len(key)<16:raise SystemExit('Set SPIDER_TELEMETRY_KEY of at least 16 characters')
    if a.action=='receiver':return run_receiver(a.host,a.port,a.db,key,a.cert,a.private_key)
    if a.action=='transmit':
        ob=Outbox(str(Path(a.out)/'tx.sqlite'))
        # session only matters for new messages; queued packets preserve original session
        n=ob.transmit(a.host,a.port,key,a.ca_cert)
        print(json.dumps({'transmitted_and_acked':n,'pending':len(ob.pending())}));return
    out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
    verified_capture=False
    if a.action=='capture-hardware':
        from src.hardware_pi_READONLY import SensorHead
        sensor=SensorHead()
        try:
            img=sensor.capture_bgr()
            r_sample=sensor.range_sample()
            verified_capture=True
        finally:sensor.close()
        pose=json.loads(Path(a.pose_json).read_text()) if a.pose_json else None
        fixture={'forward_mm':r_sample.forward_mm,'ground_mm':r_sample.ground_mm,'source':'hardware'}
    else:
        img=cv2.imread(a.image)
        if img is None:raise SystemExit('Cannot read image')
    if a.action=='demo':
        fixture={'forward_mm':900,'ground_mm':120,'source':'fixture'}
        pose=None
    elif a.action=='scan':
        fixture=json.loads(Path(a.range_json).read_text());pose=json.loads(Path(a.pose_json).read_text()) if a.pose_json else None
        if fixture.get('source')!='hardware' and pose is not None:
            raise SystemExit('Fixture-sourced ranges cannot update physical map')
    cm=ChunkMap(out/'map.sqlite');mem=ColonyMemory(out/'memory.sqlite');ob=Outbox(out/'tx.sqlite')
    colony=GroundColony()
    r=r_sample if a.action=='capture-hardware' else Ranges(fixture.get('forward_mm'),fixture.get('ground_mm'),time.monotonic(),fixture.get('source','fixture'))
    if a.action=='capture-hardware':cv2.imwrite(str(out/'captured_hardware.png'),img)
    report=scan_once(img,r,pose,cm,colony,mem,ob,verified_capture=verified_capture)
    (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    (out/'map_window.json').write_text(json.dumps(cm.ros_like_export(-16,-16,32,32),indent=2)+'\n')
    (out/'skills.json').write_text(json.dumps(mem.skills(),indent=2)+'\n')
    print(json.dumps({'report':str(out/'report.json'),'pending_transmission':len(ob.pending()),'map':cm.stats(),'evidence':report['evidence']},indent=2))
    ob.close();cm.close();mem.close()
if __name__=='__main__':main()
