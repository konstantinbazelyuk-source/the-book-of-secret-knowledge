"""Ripple node event ledger and adaptive-skill accounting; original math unchanged."""
import json,math,sqlite3
from pathlib import Path

class ColonyMemory:
    def __init__(self,path):
        self.db=sqlite3.connect(path)
        self.db.execute('CREATE TABLE IF NOT EXISTS observations(ts REAL,tile INTEGER,theta REAL,drive REAL,spikes INTEGER,texture REAL,PRIMARY KEY(ts,tile))')
        self.db.execute('CREATE TABLE IF NOT EXISTS outcomes(skill TEXT,outcome INTEGER,origin TEXT,detail TEXT)')
        self.db.commit()
    def add(self,ts,tiles):
        with self.db:
            self.db.executemany('INSERT OR REPLACE INTO observations VALUES (?,?,?,?,?,?)',[(float(ts),int(x['tile']),float(x['theta']),float(x['drive']),int(x['count']),float(x['texture_std'])) for x in tiles])
    def outcome(self,skill,success,origin,detail=''):
        if origin not in ('software_fixture','hardware_verified'):raise ValueError('outcome origin must be explicit')
        if type(success) is not bool:raise ValueError('binary result required')
        with self.db:self.db.execute('INSERT INTO outcomes VALUES (?,?,?,?)',(skill,int(success),origin,detail))
    def skills(self):
        # Wilson score 95% confidence interval; not an intelligence percentage.
        rows=[]
        for skill,origin,n,k in self.db.execute('SELECT skill,origin,COUNT(*),SUM(outcome) FROM outcomes GROUP BY skill,origin'):
            z=1.96; ph=k/n; denom=1+z*z/n
            center=(ph+z*z/(2*n))/denom
            margin=z*math.sqrt(ph*(1-ph)/n+z*z/(4*n*n))/denom
            rows.append({'skill':skill,'origin':origin,'samples':n,'passed':k,'success_pct':round(100*ph,2),'wilson95_pct':[round(100*(center-margin),2),round(100*(center+margin),2)]})
        return rows
    def close(self):self.db.close()
