"""Store-and-forward telemetry over authenticated, length-framed TCP.
LOOPBACK only without TLS; secure remote link requires validated TLS certificate.
HMAC for message integrity/replay, TLS for confidentiality. No motor commands.
"""
from __future__ import annotations
import hashlib,hmac,json,os,socket,sqlite3,ssl,struct,time
from pathlib import Path
MAX_FRAME=262144

def encode_obj(d):return json.dumps(d,separators=(',',':'),sort_keys=True,allow_nan=False).encode('utf8')
def sign(payload,key):return hmac.new(key,encode_obj(payload),hashlib.sha256).hexdigest()
def make_packet(payload,key):return encode_obj({'payload':payload,'mac':sign(payload,key)})
def verify_packet(raw,key,max_age_s=30,now=None):
    if len(raw)>MAX_FRAME:raise ValueError('too_large')
    obj=json.loads(raw);p=obj['payload'];actual=sign(p,key)
    if not hmac.compare_digest(actual,str(obj.get('mac',''))):raise ValueError('bad_mac')
    if p.get('schema')!=1 or p.get('type') not in ('SCAN','ACK') or not isinstance(p.get('seq'),int) or p['seq']<1:raise ValueError('bad_protocol')
    if not isinstance(p.get('robot_id'),str) or not (1<=len(p['robot_id'])<=64):raise ValueError('bad_robot_id')
    now=time.time() if now is None else now
    if not isinstance(p.get('sent_unix'),(float,int)) or abs(float(p['sent_unix'])-now)>max_age_s:raise ValueError('timestamp_stale')
    return p

def recv_exact(sock,n):
    buf=bytearray()
    while len(buf)<n:
        part=sock.recv(n-len(buf))
        if not part:raise EOFError('closed')
        buf.extend(part)
    return bytes(buf)
def send_framed(sock,msg):
    if len(msg)>MAX_FRAME:raise ValueError('oversize')
    sock.sendall(struct.pack('!I',len(msg))+msg)
def recv_framed(sock):
    length=struct.unpack('!I',recv_exact(sock,4))[0]
    if length>MAX_FRAME:raise ValueError('oversize')
    return recv_exact(sock,length)

def _loopback(host):return host in ('localhost','127.0.0.1','::1')
class Receiver:
    def __init__(self,path,key):
        self.db=sqlite3.connect(path,check_same_thread=False,timeout=10)
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('CREATE TABLE IF NOT EXISTS rx(robot TEXT,session TEXT,seq INTEGER,receipt REAL,packet TEXT, PRIMARY KEY(robot,session,seq))')
        self.db.execute('CREATE TABLE IF NOT EXISTS map_cells(robot TEXT,x INTEGER,y INTEGER,value INTEGER,PRIMARY KEY(robot,x,y))')
        self.db.commit();self.key=key
    def handle(self,raw):
        p=verify_packet(raw,self.key)
        if p['type']!='SCAN' or not isinstance(p.get('session'),str) or not (8<=len(p['session'])<=64):raise ValueError('expected_scan')
        # Do not accept or execute any command/data other than telemetry.
        body=p.get('body')
        if not isinstance(body,dict) or len(encode_obj(body))>128000:raise ValueError('invalid_payload')
        deltas=body.get('map_delta',[])
        if not isinstance(deltas,list) or len(deltas)>2048:raise ValueError('invalid_map_delta')
        for item in deltas:
            if not (isinstance(item,list) and len(item)==3 and all(type(v) is int for v in item) and item[2] in (0,100) and all(abs(v)<10000000 for v in item[:2])):
                raise ValueError('invalid_map_cell')
        with self.db:
            cur=self.db.execute('INSERT OR IGNORE INTO rx VALUES (?,?,?,?,?)',(p['robot_id'],p['session'],p['seq'],time.time(),json.dumps(p,sort_keys=True)))
            if cur.rowcount:
                self.db.executemany('INSERT INTO map_cells VALUES (?,?,?,?) ON CONFLICT(robot,x,y) DO UPDATE SET value=CASE WHEN value=100 AND excluded.value=0 THEN 100 ELSE excluded.value END',[(p['robot_id'],*cell) for cell in deltas])
        return {'schema':1,'type':'ACK','robot_id':p['robot_id'],'session':p['session'],'seq':p['seq'],'sent_unix':time.time(),'new':bool(cur.rowcount)}
    def serve_one(self,conn):
        try:
            p=self.handle(recv_framed(conn));send_framed(conn,make_packet(p,self.key))
        finally:conn.close()
    def count(self):return self.db.execute('SELECT COUNT(*) FROM rx').fetchone()[0]
    def close(self):self.db.close()

class Outbox:
    def __init__(self,path,robot_id='SpiderScan',session=None):
        self.db=sqlite3.connect(path,timeout=10)
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('CREATE TABLE IF NOT EXISTS tx(seq INTEGER PRIMARY KEY AUTOINCREMENT,session TEXT,body TEXT NOT NULL,ack INTEGER DEFAULT 0)')
        self.robot_id=robot_id;self.session=session or os.urandom(10).hex();self.db.commit()
    def put(self,body):
        if not isinstance(body,dict) or len(encode_obj(body))>128000:raise ValueError('bad_body')
        with self.db:
            return self.db.execute('INSERT INTO tx(session,body) VALUES (?,?)',(self.session,json.dumps(body,sort_keys=True))).lastrowid
    def pending(self):return list(self.db.execute('SELECT seq,session,body FROM tx WHERE ack=0 ORDER BY seq'))
    def transmit(self,host,port,key,ca_cert=None,timeout=3):
        if not _loopback(host) and not ca_cert:raise ValueError('remote transmission REQUIRES TLS CA certificate')
        count=0
        for seq,session,body in self.pending():
            payload={'schema':1,'type':'SCAN','robot_id':self.robot_id,'session':session,'seq':seq,'sent_unix':time.time(),'body':json.loads(body)}
            raw=make_packet(payload,key)
            with socket.create_connection((host,port),timeout=timeout) as s:
                s.settimeout(timeout)
                if ca_cert:
                    ctx=ssl.create_default_context(cafile=str(ca_cert))
                    conn=ctx.wrap_socket(s,server_hostname=host)
                else:conn=s
                send_framed(conn,raw)
                ack=verify_packet(recv_framed(conn),key)
                if ack['type']!='ACK' or ack['seq']!=seq or ack.get('session')!=session or ack['robot_id']!=self.robot_id:raise ValueError('ack_mismatch')
            with self.db:self.db.execute('UPDATE tx SET ack=1 WHERE seq=?',(seq,))
            count+=1
        return count
    def close(self):self.db.close()

def run_receiver(host,port,db,key,cert=None,privkey=None):
    if not _loopback(host) and not(cert and privkey):raise ValueError('remote receiver requires TLS cert/key')
    tls=None
    if cert:
        tls=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);tls.load_cert_chain(str(cert),str(privkey))
    receiver=Receiver(db,key)
    with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as server:
        server.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
        server.bind((host,port));server.listen(16)
        print('Receiver listening',server.getsockname(),'TLS',bool(tls),flush=True)
        while True:
            client,_=server.accept()
            try:
                if tls:client=tls.wrap_socket(client,server_side=True)
                receiver.serve_one(client)
            except (OSError,EOFError,ValueError,ssl.SSLError) as ex:print('REJECTED',str(ex),flush=True)
