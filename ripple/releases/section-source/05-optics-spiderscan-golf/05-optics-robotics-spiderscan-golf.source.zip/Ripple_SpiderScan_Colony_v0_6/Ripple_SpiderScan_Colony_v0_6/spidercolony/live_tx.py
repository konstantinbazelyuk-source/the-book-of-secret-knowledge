"""Continuously flush buffered telemetry, with timeouts and retry sleep.
External WiFi still requires real Pi/hotspot, not simulated by this program.
"""
import argparse,os,time
from pathlib import Path
from spidercolony.transport import Outbox

def main():
    p=argparse.ArgumentParser();p.add_argument('--out',required=True);p.add_argument('--host',required=True);p.add_argument('--port',type=int,default=8765);p.add_argument('--ca-cert');p.add_argument('--interval-s',type=float,default=3.0)
    a=p.parse_args()
    if not(.5<=a.interval_s<=300):raise SystemExit('interval must be .5..300s')
    key=os.environ.get('SPIDER_TELEMETRY_KEY','').encode()
    if len(key)<16:raise SystemExit('Set SPIDER_TELEMETRY_KEY with a strong unique secret')
    outbox=Outbox(Path(a.out)/'tx.sqlite')
    print('Running store-and-forward TX; Ctrl+C to stop. No motor commands.',flush=True)
    try:
        while True:
            try:
                n=outbox.transmit(a.host,a.port,key,a.ca_cert,timeout=3)
                if n:print('Acked records',n,flush=True)
            except (OSError,ValueError,TimeoutError) as exc:
                print('Link unavailable; queued data retained:',type(exc).__name__,flush=True)
            time.sleep(a.interval_s)
    finally:outbox.close()
if __name__=='__main__':main()
