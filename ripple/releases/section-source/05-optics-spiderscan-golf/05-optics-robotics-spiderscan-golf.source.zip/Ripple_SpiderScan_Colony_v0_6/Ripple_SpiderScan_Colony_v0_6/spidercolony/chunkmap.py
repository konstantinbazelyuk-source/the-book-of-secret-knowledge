"""SQLite chunked 2D occupancy, inspired by Minecraft region storage but NOT Anvil.
Cells: -1 unknown, 0 observed empty (narrow ray), 100 measured endpoint. 
NO automatic pose estimation; supplied planar pose must be independently measured.
"""
from __future__ import annotations
import json, math, sqlite3, time, zlib
from pathlib import Path

CHUNK=16
UNK=-1

def _valid_float(x): return isinstance(x,(float,int)) and math.isfinite(x)

def grid_walk(x0,y0,x1,y1):
    """Bresenham integer coordinates including endpoints, works in negative quadrants."""
    dx=abs(x1-x0); dy=-abs(y1-y0); sx=1 if x0<x1 else -1; sy=1 if y0<y1 else -1; err=dx+dy
    while True:
        yield x0,y0
        if x0==x1 and y0==y1: break
        e2=2*err
        if e2>=dy: err+=dy;x0+=sx
        if e2<=dx: err+=dx;y0+=sy

class ChunkMap:
    def __init__(self,path,cell_mm=50.0,chunk_size=CHUNK):
        if not _valid_float(cell_mm) or not 5<=cell_mm<=1000 or chunk_size!=CHUNK:
            raise ValueError('Only 16x16 chunks; cell size 5..1000 mm')
        self.path=Path(path);self.path.parent.mkdir(parents=True,exist_ok=True)
        self.db=sqlite3.connect(self.path,timeout=10)
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY, v TEXT NOT NULL)')
        self.db.execute('CREATE TABLE IF NOT EXISTS chunks(cx INTEGER NOT NULL,cy INTEGER NOT NULL, revision INTEGER NOT NULL, data BLOB NOT NULL, updated REAL NOT NULL, PRIMARY KEY(cx,cy))')
        old=self.db.execute('SELECT v FROM meta WHERE k="cell_mm"').fetchone()
        if old and float(old[0])!=float(cell_mm):raise ValueError('cell size mismatch with existing map')
        self.db.execute('INSERT OR IGNORE INTO meta VALUES ("cell_mm",?)',(str(cell_mm),));self.db.commit()
        self.cell_mm=float(cell_mm)
    @staticmethod
    def chunk_coords(x,y):return (x//CHUNK,y//CHUNK,x%CHUNK,y%CHUNK)
    def _load(self,cx,cy):
        row=self.db.execute('SELECT revision,data FROM chunks WHERE cx=? AND cy=?',(cx,cy)).fetchone()
        if row is None:return 0,[UNK]*(CHUNK*CHUNK)
        vals=json.loads(zlib.decompress(row[1]));assert len(vals)==256
        return row[0],vals
    def get(self,x,y):
        cx,cy,xx,yy=self.chunk_coords(x,y)
        return self._load(cx,cy)[1][yy*CHUNK+xx]
    def put(self,x,y,val):
        if val not in (UNK,0,100):raise ValueError('invalid evidence state')
        cx,cy,xx,yy=self.chunk_coords(x,y)
        rev,cells=self._load(cx,cy);i=yy*CHUNK+xx
        # A newly observed free ray cannot erase an obstacle endpoint: no false clearing.
        if cells[i]==100 and val==0:return False
        if cells[i]==val:return False
        cells[i]=val
        blob=zlib.compress(json.dumps(cells,separators=(',',':')).encode(),level=6)
        with self.db:
            self.db.execute('INSERT INTO chunks VALUES (?,?,?,?,?) ON CONFLICT(cx,cy) DO UPDATE SET revision=excluded.revision,data=excluded.data,updated=excluded.updated',(cx,cy,rev+1,blob,time.time()))
        return True
    def update_ray(self,pose_x_mm,pose_y_mm,yaw_deg,distance_mm,detected=True,max_ray_mm=2500):
        """Requires independently measured pose + known sensor forward alignment.
        Stops before range limit; only classify endpoint occupied if detected=True.
        This is *one* narrow beam, not a 3D obstacle or a comprehensive free-space scan.
        """
        v=(pose_x_mm,pose_y_mm,yaw_deg,distance_mm,max_ray_mm)
        if not all(_valid_float(x) for x in v) or not (0<distance_mm<=max_ray_mm<=4000):raise ValueError('pose or ray geometry invalid')
        # Cannot cross a cliff from image processing; ground ToF safety is a separate veto.
        dist=min(distance_mm,max_ray_mm)
        angle=math.radians(yaw_deg)
        end_x=pose_x_mm+dist*math.cos(angle);end_y=pose_y_mm+dist*math.sin(angle)
        a=math.floor(pose_x_mm/self.cell_mm);b=math.floor(pose_y_mm/self.cell_mm)
        c=math.floor(end_x/self.cell_mm);d=math.floor(end_y/self.cell_mm)
        cells=list(grid_walk(a,b,c,d));changed=0;deltas=[]
        for x,y in cells[:-1]:
            if self.put(x,y,0):changed+=1;deltas.append([x,y,0])
        # endpoint localization is a *hypothesis*: VL53L1X full FOV ~27deg.
        if detected and distance_mm<max_ray_mm and self.put(c,d,100):
            changed+=1;deltas.append([c,d,100])
        return {'changed_cells':changed,'beam_cells':len(cells),'pose_source':'external_only',
                'endpoint_cell':[c,d], 'delta':deltas, 'lateral_uncertainty_mm':round(distance_mm*math.tan(math.radians(13.5)),2),
                'safety_qualified':False}
    def chunks(self):
        for cx,cy,rev,blob in self.db.execute('SELECT cx,cy,revision,data FROM chunks ORDER BY cy,cx'):
            yield {'cx':cx,'cy':cy,'revision':rev,'data':json.loads(zlib.decompress(blob))}
    def stats(self):
        vals=[v for ch in self.chunks() for v in ch['data']]
        return {'chunks':self.db.execute('SELECT COUNT(*) FROM chunks').fetchone()[0],
                'known_cells':sum(v!=-1 for v in vals),'occupied_cells':sum(v==100 for v in vals),
                'free_cells':sum(v==0 for v in vals),'unknown_cells_in_loaded_chunks':sum(v==-1 for v in vals),
                'resolution_mm':self.cell_mm}
    def ros_like_export(self,xmin,ymin,width,height):
        if not all(isinstance(a,int) for a in (xmin,ymin,width,height)) or width<=0 or height<=0 or width*height>1000000:raise ValueError('invalid export window')
        return {'format':'ROS2_nav_msgs_OccupancyGrid_data_like_NOT_ROS_MESSAGE',
                'resolution_m':self.cell_mm/1000, 'origin_m':[xmin*self.cell_mm/1000,ymin*self.cell_mm/1000],
                'width':width,'height':height,'data':[self.get(x,y) for y in range(ymin,ymin+height) for x in range(xmin,xmin+width)]}
    def close(self):self.db.close()
