"""Read-only localhost web monitor for received telemetry. No remote exposure.
Run python -m spidercolony.monitor --db results/receiver_run.sqlite
"""
import argparse,json,sqlite3,time
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path

HTML='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SpiderScan Base Station</title><style>body{font:15px system-ui;background:#f0f4f4;color:#1b2e34;max-width:1050px;margin:30px auto;padding:0 15px}header{display:flex;justify-content:space-between;border-bottom:1px solid #abb;padding-bottom:15px}h1{margin:0}.tag{background:#dce9dd;padding:8px;border-radius:6px}.cols{display:grid;grid-template-columns:1fr 1fr;gap:20px}.card{background:white;padding:22px;border-radius:14px;box-shadow:0 1px 6px #0001;overflow:auto}pre{white-space:pre-wrap;overflow-wrap:anywhere}canvas{width:100%;max-width:460px;background:#dbe1e6;image-rendering:pixelated}small{color:#52686f}@media(max-width:750px){.cols{grid-template-columns:1fr}}</style><header><h1>SPIDERSCAN • BASE STATION</h1><span class="tag">READ ONLY</span></header><p>SQLite evidence • authenticated RX • Unknown cells remain unknown. Telemetry does not control motors.</p><div class="cols"><section class="card"><h2>Ground map</h2><canvas id="grid" width="512" height="512" aria-label="Map cells"></canvas><small>Grey: unknown; pale: ray hypothesis; amber: return hypothesis, NOT navigation clearance</small></section><section class="card"><h2>Last received telemetry</h2><pre id="status">Waiting for a received packet…</pre></section></div><script>async function update(){try{let r=await fetch('/api/state',{cache:'no-store'});let d=await r.json();document.getElementById('status').textContent=JSON.stringify(d.last_packet??{status:'none'},null,2);let c=document.getElementById('grid');let q=c.getContext('2d'),N=32,s=16;q.fillStyle='#cbd4d9';q.fillRect(0,0,512,512);for(let item of d.map){let [x,y,value]=item;if(x<-16||x>=16||y<-16||y>=16)continue;q.fillStyle=value===100?'#d79333':'#f5f5e9';q.fillRect((x+16)*s, (y+16)*s, s,s);}q.strokeStyle='#a7b4b8';q.lineWidth=.6;for(let i=0;i<=N;i+=16){q.beginPath();q.moveTo(i*s,0);q.lineTo(i*s,512);q.stroke();q.beginPath();q.moveTo(0,i*s);q.lineTo(512,i*s);q.stroke();}}catch(e){document.getElementById('status').textContent='Monitor error: '+e.message}}update();setInterval(update,2000)</script></html>'''

def state(dbpath):
    if not Path(dbpath).exists():return {'map':[],'last_packet':None}
    with sqlite3.connect(dbpath,timeout=2) as db:
        present={r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if 'rx' not in present:return {'map':[],'last_packet':None}
        latest=db.execute('SELECT packet FROM rx ORDER BY receipt DESC LIMIT 1').fetchone()
        mapping=list(db.execute('SELECT x,y,value FROM map_cells WHERE x>=-16 AND x<16 AND y>=-16 AND y<16')) if 'map_cells' in present else []
        if latest:
            packet=json.loads(latest[0]);packet['body'].pop('map_delta',None) # no bulk on status
        else:packet=None
        return {'map':mapping,'last_packet':packet}

def main():
    p=argparse.ArgumentParser();p.add_argument('--db',default='results/receiver_run.sqlite');p.add_argument('--host',default='127.0.0.1');p.add_argument('--port',type=int,default=8076)
    a=p.parse_args()
    if a.host not in ('127.0.0.1','localhost','::1'):raise SystemExit('Monitor is loopback-only; use a local tunnel to access')
    class H(BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path not in ('/','/api/state'):
                self.send_error(404);return
            data=(json.dumps(state(a.db)) if self.path=='/api/state' else HTML).encode()
            self.send_response(200);self.send_header('Content-Type','application/json' if self.path=='/api/state' else 'text/html; charset=utf-8')
            self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
    print('SpiderScan monitor at http://127.0.0.1:'+str(a.port),flush=True)
    ThreadingHTTPServer((a.host,a.port),H).serve_forever()
if __name__=='__main__':main()
