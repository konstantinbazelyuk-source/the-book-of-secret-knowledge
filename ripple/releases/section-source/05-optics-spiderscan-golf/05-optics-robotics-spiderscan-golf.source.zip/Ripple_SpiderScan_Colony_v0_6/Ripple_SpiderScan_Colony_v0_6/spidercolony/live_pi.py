"""Live Raspberry Pi sensor capture loop, NO physical motors or pose estimation.
Unverified until run on actual Pi camera + ToF sensor kit.
"""
import argparse,json,time
from pathlib import Path
import cv2
from spidercolony.chunkmap import ChunkMap
from spidercolony.colony_memory import ColonyMemory
from spidercolony.transport import Outbox
from spidercolony.cli import scan_once
from src.ground_colony import GroundColony
from src.hardware_pi_READONLY import SensorHead
from src.safety import GroundGate

def run(session_dir,interval_s=.2,max_frames=0,save_every=10):
    if not(0.05<=interval_s<=0.5) or save_every<1 or max_frames<0:raise ValueError('invalid acquisition cadence')
    path=Path(session_dir);path.mkdir(parents=True,exist_ok=True)
    cm=ChunkMap(path/'map.sqlite');mem=ColonyMemory(path/'neuron_memory.sqlite')
    tx=Outbox(path/'tx.sqlite');colony=GroundColony();gate=GroundGate()
    head=SensorHead();frames=0;last_frame_s=None
    try:
        while max_frames==0 or frames<max_frames:
            start=time.monotonic()
            gap_s=(start-last_frame_s) if last_frame_s is not None else interval_s
            gap_reset=gap_s>0.5
            if gap_reset:colony=GroundColony()  # known interrupted activity, no false timing continuity
            last_frame_s=start
            image=head.capture_bgr()
            reading=head.range_sample()
            decision=scan_once(image,reading,None,cm,colony,mem,tx,timestamp=time.monotonic(),verified_capture=True,gate=gate,dt=min(gap_s,0.5))
            if gap_reset:decision['model_state_reset_due_to_large_timing_gap']=round(gap_s,3)
            decision['frame']=frames;decision['recorded_monotonic_s']=time.monotonic()
            if frames%save_every==0:
                frame_path=path/f'frame_{frames:06d}.png'
                if not cv2.imwrite(str(frame_path),image):raise OSError('failed writing real camera PNG')
                (path/f'report_{frames:06d}.json').write_text(json.dumps(decision,indent=2)+'\n')
            if frames%10==0:print(json.dumps({'frame':frames,'nodes':decision['colony']['nodes'],'safety':decision['safety']['reasons'],'pending':tx.db.execute('SELECT COUNT(*) FROM tx WHERE ack=0').fetchone()[0]}),flush=True)
            frames+=1
            delay=interval_s-(time.monotonic()-start)
            if delay>0:time.sleep(delay)
    finally:
        head.close();cm.close();mem.close();tx.close()
    return frames

def main():
    p=argparse.ArgumentParser();p.add_argument('--out',required=True);p.add_argument('--interval-s',type=float,default=.2);p.add_argument('--max-frames',type=int,default=0);p.add_argument('--save-every',type=int,default=10)
    a=p.parse_args()
    print('Observation loop only. No servo command, no inferred pose, no map mutation.',flush=True)
    run(a.out,a.interval_s,a.max_frames,a.save_every)
if __name__=='__main__':main()
