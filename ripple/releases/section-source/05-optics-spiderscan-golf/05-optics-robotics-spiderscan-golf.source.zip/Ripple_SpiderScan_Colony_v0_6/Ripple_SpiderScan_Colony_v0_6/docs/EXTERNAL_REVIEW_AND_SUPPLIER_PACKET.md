# INDEPENDENT MECHANICAL / ELECTRICAL / AI REVIEW REQUEST

**Status:** prepared for independent review. **No Grok, Gemini, Meta AI, manufacturer, or engineering freelancer was invoked or paid by this session.** Their independent assessment is not represented as complete. The software is built and can run locally; physical fit and locomotion are NOT validated.

## Mechanical designer or manufacturer

- Please pin a specific MIT-licensed Octobot GitHub commit and verify dimensions against its actual STEP files. Review the original 8-leg 24-servo load-bearing structure, available torque test basis, stress/concentration, fastener retention, tolerances, 3D print orientation, low-angle LED mounts, camera field-of-view during all leg positions, and real mount attachment.
- Deliver a STEP assembly with integrated Raspberry Pi Global Shutter Camera (38x38x19.8mm), Pi 4 (85x56mm envelope), 2 ToF breakout boards (vendor layout TBD), Pi mount and cable strain relief. Include tolerance stack, mass budget, center of mass, and estimated payload.
- Request quote for **one fit-check sample only**, not a completed robot. Do not fabricate unverified leg-length parts from digital-reference geometry.

## Electronics engineer

- Obtain matching upstream board ERC/DRC and board house fabrication rules; audit 24 servo power rails and correct control firmware repo. No assumption about peak stall current, regulator ratings, or battery.
- Produce an as-built fused power tree with physically independent stop, Pi 5V/3A, 3.3 V I2C breakout logic, radio EMC and tethered lab measurements. Verify that Pi software cannot override servo emergency cut.

## Data-processing researcher or alternate AI reviewer

- Run source-level audit of `spidercolony/chunkmap.py`, `transport.py`, `live_pi.py`, and `src/ground_colony.py` on the enclosed fixtures.
- Check any false inference from cone-beam ToF (typical 27 degree FOV), ROS-like maps (not real ROS OccupancyGrid messages), image tile RGB and spiking events (not learned intelligence), pose provenance, packet ACK semantics, TLS and clock skew, servo kinematic sign conventions, foot contacts and loss-of-signal response.
- Any Google Gemini, Meta AI/SAM2, Grok/xAI model can examine this packet by a separate authorized integration, but **none has been called**. Their outputs must be saved with prompt/model/date and checked against official data sheets. Do not accept auto-generated CAD or circuit claims without independent mechanical/electrical sign-off.

## Source pointers

- Original mechanical reference: https://github.com/Deivid-Negoita/octobot
- Raspberry Pi GS drawing: https://datasheets.raspberrypi.com/gs-camera/gs-camera-product-brief.pdf
- Published ST ToF specifications: https://www.st.com/en/imaging-and-photonics-solutions/vl53l1x.html
- ROS occupancy interface: https://github.com/ros2/common_interfaces/blob/rolling/nav_msgs/msg/OccupancyGrid.msg
- Chunk storage approach: https://minecraft.wiki/w/Chunk_format
