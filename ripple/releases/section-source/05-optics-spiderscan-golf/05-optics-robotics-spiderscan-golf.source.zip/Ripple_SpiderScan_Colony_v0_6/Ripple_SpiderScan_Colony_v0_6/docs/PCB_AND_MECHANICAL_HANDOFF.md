# UPSTREAM THIRD-PARTY CAD/PCB HANDOFF

Mechanical (original creator, MIT): https://github.com/Deivid-Negoita/octobot/tree/main/mechanical
KiCad 7/gerbers/BOM/placements (original creator, MIT): https://github.com/Deivid-Negoita/octobot/tree/main/hardware
IK workbench (original creator, MIT): https://deivid-negoita.github.io/octobot/
Technical kinematics: https://github.com/Deivid-Negoita/octobot/blob/main/docs/kinematics.md

The Octobot README describes STEP archives, a 24-servo board based on ATmega32U4 + 2 x PCA9685 and hardware fabrication data. It explicitly states firmware is maintained separately, therefore no existing externally documented servo command API is verified here. The full motor-controller circuit must be DRC/ERC-checked by an electrical engineer before powering all servos. Do not rely on a schematic screenshot.

For manufacturer: supply pinned upstream CAD/gerber ZIP hash, assembly drawings, actual camera mount hole pattern from Raspberry Pi GS camera official drawing, separately source board standoff dimensions and check cable clearances. Request minimum one test fit of Pi mount/carrier, measure on chassis, then release batch. Full 8-leg chassis parts must use official mechanical files with adherence to original license and manufacturer design responsibility.

New printed fit-check source: ../cad/transmitter_pi_mount_FITCHECK.scad. This is NOT a qualified load-bearing component. Proposed material: PETG or PA12 for low-stress parts, vendor to select based on real temperatures and cable loads; no flight hardware. The overall eight-leg posed assembly in v0.6 is a **schematic reference**, and must not be used to print drivetrain parts in place of upstream Octobot STEP models.

Quotation requested: 1x Pi/telemetry fit tray and 1x scanner-tray fit sample only, itemized material/print orientation/estimated mass, finish and dimensional inspection. No order has been placed.
