# ELECTRICAL INTERFACES / POWER DESIGN STATUS

## Proven sourced equipment vs interface proposals

**Pi4B** requires a stable 5 V / 3 A supply at its input, independent of servo brownouts (Raspberry Pi 4 datasheet). **NO** servo supply through the Raspberry Pi GPIO or 5 V header. GPIO is 3.3 V logic; keep the board grounds referenced as manufacturer documentation requires and investigate isolation/noise.

**Global Shutter Camera** is a 38x38x19.8 mm, 34 g, Sony IMX296 1456x1088 color camera. CSI ribbon to a compatible Pi 4 CSI connector; lens is a separate purchase and must focus at tested floor standoff. Ask manufacturer for actual mount drawing and select lens based on required working distance and measured illumination. The illustrative pinhole width calculation for a **hypothetical** 6 mm focal lens at height 160 mm: 1456 * 0.00345 *160/6 = 133.95 mm; height 1088*0.00345*160/6 = 100.10 mm. Optical distortion and actual focal distance invalidate naïve mm/px unless calibrated.

**VL53L1X** boards (2) on **TCA9548A** channels 0 and 1, vendor breakout I2C. Forward and downward mounting angles must be measured before fusion; VDD and level-shifting follow breakout manufacturer specifications, **NOT the bare ST chip's 2.8 V rail**. Host SBC `board.I2C()` -> mux SDA/SCL -> VL53L1X breakouts. Do not connect sensors directly to servo-current supply. ST quotes 940nm Class 1 internal emitter, 27 degree typical FOV, up to 4 m under specified conditions. This is not an optical phase sensor or an electromagnetic-field detector.

**Octobot drivetrain** 24 servo channels, ATmega32U4 and 2 PCA9685 chips on published KiCad design, 12+12 split power rails. The published code says firmware is maintained outside the mechanical repository. We **do not** assume a serial protocol, servo rail voltage/current, motor controller PID, stall torque, rated battery, or onboard E-stop design without measuring and checking upstream files. Replacing board or servo drive is NOT part of v0.6.

**Power block diagram (proposed, not a wiring-ready production schematic):**

`Battery -> physical fuse -> master physical OFF switch -> (A) independent Pi 5V/3A regulator -> Pi camera, ToF; (B) sized current-limited servo regulator(s) -> Octobot servo rails.`

**Emergency stop** must interrupt servo power independently of Pi, Wi-Fi, or software; verify failure modes in physical trials. Include thermal protection, conductor sizing, connector retention, and reverse-polarity protection. Test input/current traces and separately check each of 24 stall loads. Mechanical leg motion must remain disabled during imaging validation.

**Transmitter:** Raspberry Pi Wi-Fi. Use a lab WLAN with WPA2/3, synchronized clocks, signed per-message HMAC and mutually trusted TLS certificate for any non-loopback remote IP. Network cannot send actuator commands through the v0.6 data receiver.
