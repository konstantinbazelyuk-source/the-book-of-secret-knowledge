# PHYSICAL PRODUCTION GATES (NOT YET SATISFIED)

## Gate A: Reference CAD and controller

1. Download pinned Octobot STEP and KiCad source from its official MIT GitHub repository. Record commit SHA, file hash, and license.
2. Inspect the 24 servo positions/brackets from actual STEP, rather than the SpiderScan schematic model. Verify actuator source and current firmware build. Hardware repo says firmware is separate; missing matching firmware is a real blocker.
3. Record dimensions and 2D mounting drawing of Octobot payload attachment surface. Model mating bolt pattern, cable relief, and camera clear view with real lens.
4. Confirm 3D print orientation, infill/material, support removal, and tolerance coupons. Never substitute the Pi carrier or camera bracket for a load-bearing leg.

## Gate B: Electrical

5. Build a documented rail diagram matching the exact upstream PCB variant and add upstream regulator/servo power limits. Demonstrate a hardware emergency stop. Require certified battery and charger.
6. Bench test 24 servo peak draw under constrained movement, fused distribution, voltage ripple, thermal response, brownout recovery, and tethered emergency cut; no power-supply sizing based on nominal torque guesses.
7. Verify I2C 3.3 V compatibility, two sensor mux readings, staleness handling, camera frame channel order, and camera temperature.
8. Log two ToF sensors against a ruler at 100, 200, 350, 1000 mm and matte/reflective targets; report invalid or out-of-range readings.

## Gate C: Optical metrology

9. Print v0.5 calibration chart at actual size, verify by caliper. Record measured mark separation in mm and pixel separation with lens, focus, and distance fixed.
10. Capture 30 image frames at fixed height with controlled illumination. Measure repeatability, raw pixel statistics, and focus across image corners. Use grazing light only under safe LED current driver and appropriate exposure.
11. Fit model for lens distortion/perspective; the simple planar scale applies only near the reference plane.

## Gate D: Controlled locomotion

12. Weigh entire assembled payload, body, servos, battery, camera, mounts, transmission antennas and harness.
13. Validate all eight feet contacts/servo angular limits/torque margin on tether with independently controlled E-stop. A gait solver reaching target position in software **does not** demonstrate physical walking.
14. Verify the camera clears all spider legs during swing and no limbs obscure ToF cones.
15. Commission velocity, foot placement and odometry using physical fiducials or wheel/leg+IMU fusion; no guessed global pose. Map writes are disabled when pose unavailable.
16. Test abrupt stop, carpet seams, glass, stairs, pets and people. Keep remote motor control disabled until separately reviewed.

## Gate E: Wireless evidence

17. Test TCP/TLS connection over private Wi-Fi, certificate expiry, connection loss/recovery, signed payload spoofing, 20 minute timestamp skew, session collisions and receiver ACK loss; verify dedup and spool replay with a fault harness.
18. Compare hash, measurement times and captured source images on robot and station. Test image-memory and SQLite WAL cleanup on Pi with actual storage endurance constraints.
19. Fill in purchase prices from actual supplier checkout/cart; manufacturing supplier must confirm accepted material, orientation, tolerances, and lead time.

**Release status:** all physical gates remain open; no hardware was handled, fabricated or ordered by this software session.
