from pathlib import Path
import hashlib,math,time
import cv2,numpy as np,pytest
from legacy.ripple_optical_agent_LOCKED import RippleNeuron
from src.ground_colony import GroundColony
from src.scan_quality import marker_calibrate,image_quality,ground_sampling
from src.safety import GroundGate,Ranges
from src.skill_metrics import SkillMeter
from src.groundscan_cli import analyze
BASE=Path(__file__).resolve().parents[1]
OLD=Path('/mnt/data/Ripple_SpiderScan_v0_4/source/ripple_optical_agent_LOCKED.py')

def marks(separation=400,noise=False):
    x=np.full((300,800,3),255,np.uint8)
    cv2.circle(x,(180,150),12,(0,0,0),-1)
    cv2.circle(x,(180+separation,150),12,(0,0,0),-1)
    return x

def test_locked_core_unchanged():
    assert hashlib.sha256((BASE/'legacy/ripple_optical_agent_LOCKED.py').read_bytes()).hexdigest()=='7f2f611cd8f1717c3d3dcae745dbd41efc37e24315d93878231db52eaf614f77'
    if OLD.exists():
        assert hashlib.sha256(OLD.read_bytes()).digest()==hashlib.sha256((BASE/'legacy/ripple_optical_agent_LOCKED.py').read_bytes()).digest()

def test_core_math_unchanged():
    n=RippleNeuron(adaptive=False)
    y=n.step((.5,.2,.1),.05)
    assert y['drive']==pytest.approx(1+.24-.14)

def test_calibration_mm_per_px():
    c=marker_calibrate(marks(),100)
    assert c.pixels_between_marks==pytest.approx(400,abs=.05)
    assert c.mm_per_px==pytest.approx(.25,abs=.00001)
    s=ground_sampling(c,800,300)
    assert s['width_mm']==pytest.approx(200)
    assert s['height_mm']==pytest.approx(75)
    assert s['area_cm2']==pytest.approx(150)

def test_calibration_invalid():
    with pytest.raises(ValueError):marker_calibrate(np.full((100,100,3),255,np.uint8),100)
    with pytest.raises(ValueError):marker_calibrate(marks(),-1)

def test_blur_gate():
    img=np.full((128,128,3),128,np.uint8)
    q=image_quality(img)
    assert not q['passes_provisional_gates']
    assert 'blur_or_low_texture' in q['issues']

def test_stale_stop():
    g=GroundGate();s=g.evaluate(Ranges(900,110,0,source='fixture'),1.0)
    assert s['motion_recommendation']=='STOP' and 'missing_or_stale_data' in s['reasons']

def test_obstacle_stop():
    assert 'forward_obstacle' in GroundGate().evaluate(Ranges(200,120,1,'fixture'),1.0)['reasons']

def test_drop_stop():
    g=GroundGate(ground_max_mm=300)
    assert g.evaluate(Ranges(800,100,1.,'fixture'),1.)['reasons']==[]
    assert 'ground_drop_detected' in g.evaluate(Ranges(800,190,1.1,'fixture'),1.1)['reasons']

def test_valid_never_enables_motors():
    s=GroundGate().evaluate(Ranges(800,100,1.0,'fixture'),1.1)
    assert s['motion_recommendation']=='OBSERVE_ONLY'
    assert s['motor_control_enabled'] is False

def test_nan_rejected():
    s=GroundGate().evaluate(Ranges(float('nan'),120,1.0,'fixture'),1.1)
    assert 'forward_invalid' in s['reasons']

def test_colony_stable_identity_and_scaling():
    c=GroundColony(rows=2,cols=2,capacity=4)
    blank=np.zeros((64,64,3),dtype=np.uint8)
    textured=np.random.default_rng(42).integers(0,256,(64,64,3),dtype=np.uint8)
    first=c.process(blank,.05)
    born={v['tile']:c.nodes[v['tile']].node for v in first['tiles']}
    assert len(born)==2
    assert c.process(textured,.05)['nodes']==2
    third=c.process(textured,.05)
    assert third['nodes']==4
    assert all(c.nodes[k].node is v for k,v in born.items())
    for _ in range(4):c.process(blank,.05)
    assert len(c.nodes)==2
    assert any(e['action']=='retire' for e in c.lifecycle)


def test_colony_invalid():
    with pytest.raises(ValueError):GroundColony(capacity=30)
    with pytest.raises(ValueError):GroundColony(rows=2,cols=2).process(np.zeros((4,4,3),np.uint8))

def test_skills_empirical():
    s=SkillMeter()
    assert s.result()['success_pct'] is None
    for v in [True,True,False,True,False]:s.observe(v)
    assert s.result()['success_pct']==60
    assert s.result()['wilson_95_pct'][0]<60<s.result()['wilson_95_pct'][1]

def test_input_actual_archive_pixels():
    img=cv2.imread(str(BASE/'fixtures/archived_photo_NOT_HARDWARE.png'))
    assert img is not None and img.size>0
    result=analyze(img,'archived_photograph',repeats=3)
    assert result['dimensions_px']==[img.shape[1],img.shape[0]]
    assert result['neuron_count_peak']<=16

def test_exposure_advisor_direction_and_limits():
    from src.adaptive_capture import ExposureAdvisor
    adv=ExposureAdvisor(microseconds=5000)
    dim=np.full((64,64,3),40,np.uint8)
    assert adv.update(dim)['recommended_exposure_us']>5000
    bright=np.full((64,64,3),240,np.uint8)
    assert adv.update(bright)['recommended_exposure_us']<adv.max_us
    for _ in range(100):adv.update(dim)
    assert adv.microseconds<=adv.max_us

def test_exposure_advisor_reference_no_fabricated_improvement():
    from src.adaptive_capture import ExposureAdvisor
    adv=ExposureAdvisor()
    q=adv.update(np.full((64,64,3),128,np.uint8))
    assert q['measured_gray_mean']==128.0
    assert isinstance(q['pass_quality_gate'],bool)

def test_camera_byte_order_matches_picamera2_manual_without_hardware():
    from src.hardware_pi_READONLY import SensorHead
    class MockCamera:
        def capture_array(self):
            # Manufacturer RGB888 buffer pixel represents pure red as B=0,G=0,R=255
            return np.array([[[0,0,255],[255,0,0]]],dtype=np.uint8)
    mock=object.__new__(SensorHead)
    mock.cam=MockCamera()
    bgr=mock.capture_bgr()
    assert bgr[0,0].tolist()==[0,0,255]
    assert cv2.cvtColor(bgr,cv2.COLOR_BGR2RGB)[0,0].tolist()==[255,0,0]


def test_ground_sensor_adapter_mocked_range_and_interrupt():
    from src.hardware_pi_READONLY import SensorHead
    class FakeRanger:
        def __init__(self,cm):self.distance=cm;self.data_ready=True;self.cleared=False
        def clear_interrupt(self):self.cleared=True
    a=object.__new__(SensorHead)
    a.front=FakeRanger(45.)
    a.down=FakeRanger(12.)
    r=a.range_sample()
    assert r.source=='hardware' and r.forward_mm==450 and r.ground_mm==120
    assert a.front.cleared and a.down.cleared

def test_route_serpentine_and_overlap():
    from src.ground_mosaic import serpentine_plan
    p=serpentine_plan(200,100,60,50,.25)
    assert p.waypoints[0].x_mm==0
    assert p.waypoints[-1].y_mm==50
    by_row={}
    for q in p.waypoints:by_row.setdefault(q.y_mm,[]).append(q.x_mm)
    assert by_row[0][0]<by_row[0][-1]
    assert by_row[25][0]>by_row[25][-1]
    for poses in by_row.values():
        assert max(abs(poses[i+1]-poses[i]) for i in range(len(poses)-1)) <= 60*.75 +1e-6


def test_mosaic_known_pose_lossless_reconstruction():
    from src.ground_mosaic import compose_known_pose,ScanPose
    src=np.random.default_rng(3).integers(0,256,(256,256,3),dtype=np.uint8)
    frames=[]
    for y in (0,64,128):
        for x in (0,64,128):
            frames.append((src[y:y+128,x:x+128],ScanPose(x*.2,y*.2,f'{x},{y}')))
    mosaic,mask=compose_known_pose(frames,.2,51.2,51.2)
    assert mask.all()
    assert np.array_equal(mosaic,src)


def test_mosaic_refuses_unknown_invalid_pose():
    from src.ground_mosaic import compose_known_pose,ScanPose
    with pytest.raises(ValueError):compose_known_pose([],1,100,100)
    with pytest.raises(ValueError):compose_known_pose([(np.zeros((8,8,3),np.uint8),ScanPose(-4,0,'bad'))],1,100,100)


def test_composition_coverage_mask_exposes_missing_data():
    from src.ground_mosaic import compose_known_pose,ScanPose
    img=np.full((50,50,3),255,np.uint8)
    mosaic,coverage=compose_known_pose([(img,ScanPose(0,0,'one'))],1,100,100)
    assert coverage.mean()==pytest.approx(.25)
    assert np.all(mosaic[~coverage]==0)


def test_mosaic_memory_guard():
    from src.ground_mosaic import compose_known_pose,ScanPose
    with pytest.raises(ValueError, match='memory guard'):
        compose_known_pose([(np.zeros((16,16,3),np.uint8),ScanPose(0,0,'ref'))],1.,2000,2000)
