from __future__ import annotations
import json,os,socket,sqlite3,threading,time,hashlib
from pathlib import Path
import pytest
from spidercolony.chunkmap import ChunkMap,grid_walk
from spidercolony.transport import Receiver,Outbox,verify_packet,make_packet,send_framed,recv_framed
from spidercolony.colony_memory import ColonyMemory
from spidercolony.kinematics import solve_leg,forward_leg,Unreachable,wave_support

KEY=b'0123456789abcdef0123456789abcdef'

def test_locked_neuron_matches_original_bytes():
    p=Path(__file__).parents[1]
    original=p/'legacy_v05/legacy/ripple_optical_agent_LOCKED.py'
    copy=p/'legacy/ripple_optical_agent_LOCKED.py'
    assert hashlib.sha256(original.read_bytes()).digest()==hashlib.sha256(copy.read_bytes()).digest()

def test_world_negative_chunks(tmp_path):
    m=ChunkMap(tmp_path/'map.sqlite');assert m.get(-1,-1)==-1
    m.put(-1,-1,100);assert m.get(-1,-1)==100
    assert m.chunk_coords(-1,-1)==(-1,-1,15,15)
    m.close();n=ChunkMap(tmp_path/'map.sqlite');assert n.get(-1,-1)==100;n.close()

def test_free_cannot_erase_obstacle(tmp_path):
    m=ChunkMap(tmp_path/'map.sqlite');m.put(1,0,100);m.put(1,0,0);assert m.get(1,0)==100;m.close()

def test_ray_positive_negative(tmp_path):
    m=ChunkMap(tmp_path/'m.sqlite',cell_mm=50)
    a=m.update_ray(0,0,0,200,detected=True,max_ray_mm=500)
    assert a['endpoint_cell']==[4,0] and m.get(4,0)==100 and m.get(1,0)==0
    b=m.update_ray(0,0,180,150,detected=True,max_ray_mm=500)
    assert m.get(-3,0)==100
    assert m.stats()['chunks']>=2
    m.close()

def test_no_endpoint_for_maxrange(tmp_path):
    m=ChunkMap(tmp_path/'m.sqlite');m.update_ray(0,0,90,500,detected=False,max_ray_mm=500)
    assert m.get(0,10)==-1;m.close()

def test_ray_bad_pose_rejected(tmp_path):
    m=ChunkMap(tmp_path/'m.sqlite')
    with pytest.raises(ValueError):m.update_ray(float('nan'),0,0,100)
    with pytest.raises(ValueError):m.update_ray(0,0,0,5000)
    m.close()

def test_ros_like_negative_origin_row_major(tmp_path):
    m=ChunkMap(tmp_path/'m.sqlite');m.put(-1,0,100);out=m.ros_like_export(-1,0,2,2)
    assert out['data']==[100,-1,-1,-1] and out['origin_m'][0]==-.05
    m.close()

def test_invalid_cell_size_mismatch(tmp_path):
    p=tmp_path/'m.sqlite';ChunkMap(p,cell_mm=25).close()
    with pytest.raises(ValueError):ChunkMap(p,cell_mm=50)

def test_bresenham():assert list(grid_walk(0,0,3,0))==[(0,0),(1,0),(2,0),(3,0)]

def test_bad_mac():
    obj={'schema':1,'type':'SCAN','robot_id':'abc','session':'test-session','seq':1,'sent_unix':time.time(),'body':{}}
    raw=make_packet(obj,KEY)
    with pytest.raises(ValueError):verify_packet(raw,KEY+b'X')

def test_old_timestamp_rejected():
    obj={'schema':1,'type':'SCAN','robot_id':'abc','session':'test-session','seq':1,'sent_unix':time.time()-80,'body':{}}
    with pytest.raises(ValueError):verify_packet(make_packet(obj,KEY),KEY)

def test_oversize_rejected():
    with pytest.raises(ValueError):verify_packet(b'a'*262145,KEY)

def test_exactly_once_receiver(tmp_path):
    r=Receiver(tmp_path/'rx.sqlite',KEY)
    obj={'schema':1,'type':'SCAN','robot_id':'abc','session':'test-session','seq':1,'sent_unix':time.time(),'body':{'a':1}}
    raw=make_packet(obj,KEY)
    assert r.handle(raw)['new'] and not r.handle(raw)['new'] and r.count()==1;r.close()

def test_outbox_queue_persists(tmp_path):
    p=tmp_path/'q.sqlite';o=Outbox(p);o.put({'a':'x'});o.close()
    o=Outbox(p);assert len(o.pending())==1;o.close()

def test_remote_requires_tls(tmp_path):
    o=Outbox(tmp_path/'q.sqlite');o.put({'a':1})
    with pytest.raises(ValueError):o.transmit('192.0.2.1',8888,KEY)
    o.close()

def test_loopback_transmission_and_ack(tmp_path):
    receiver=Receiver(tmp_path/'rx.sqlite',KEY);out=Outbox(tmp_path/'tx.sqlite');out.put({'sensor':'fixture','x':7})
    ready=threading.Event();addresses=[]
    def server():
        with socket.socket() as s:
            s.bind(('127.0.0.1',0));s.listen(1);addresses.append(s.getsockname());ready.set()
            client,_=s.accept();receiver.serve_one(client)
    th=threading.Thread(target=server);th.start();assert ready.wait(3)
    assert out.transmit(addresses[0][0],addresses[0][1],KEY)==1
    th.join(timeout=5)
    assert not th.is_alive() and receiver.count()==1 and out.pending()==[]
    receiver.close();out.close()

def test_skill_reports_origin_and_uncertainty(tmp_path):
    c=ColonyMemory(tmp_path/'mem.sqlite')
    for _ in range(5):c.outcome('pixel_calibration',True,'software_fixture')
    stats=c.skills()[0]
    assert stats['success_pct']==100 and stats['wilson95_pct'][0]<60
    with pytest.raises(ValueError):c.outcome('intelligence',True,'made_up')
    c.close()

def test_ik_round_trip():
    # one candidate geometry pose inside joint limits
    g=solve_leg(140,0,60)
    x,y,z=forward_leg(g)
    assert abs(x-140)<1e-8 and abs(y)<1e-8 and abs(z-60)<1e-8

def test_ik_reject_unreachable():
    with pytest.raises(Unreachable):solve_leg(1000,0,0)

def test_wave_support():
    assert min(len(wave_support(i/100)) for i in range(100))>=6


def test_real_delta_updates_once(tmp_path):
    receiver=Receiver(tmp_path/'rx.sqlite',KEY)
    obj={'schema':1,'type':'SCAN','robot_id':'abc','session':'test-session','seq':1,'sent_unix':time.time(),'body':{'map_delta':[[0,1,0],[2,3,100]]}}
    raw=make_packet(obj,KEY);assert receiver.handle(raw)['new']
    assert not receiver.handle(raw)['new']
    assert receiver.db.execute('SELECT COUNT(*) FROM map_cells').fetchone()[0]==2
    assert receiver.db.execute('SELECT value FROM map_cells WHERE x=2 AND y=3').fetchone()[0]==100
    receiver.close()

def test_delta_invalid_rejected_atomically(tmp_path):
    receiver=Receiver(tmp_path/'rx.sqlite',KEY)
    obj={'schema':1,'type':'SCAN','robot_id':'abc','session':'test-session','seq':1,'sent_unix':time.time(),'body':{'map_delta':[[0,1,15]]}}
    with pytest.raises(ValueError):receiver.handle(make_packet(obj,KEY))
    assert receiver.count()==0
    receiver.close()

def test_monitor_readonly_reports_received_data(tmp_path):
    from spidercolony.monitor import state
    db=tmp_path/'rx.sqlite';r=Receiver(db,KEY)
    packet={'schema':1,'type':'SCAN','robot_id':'abc','session':'test-session','seq':1,'sent_unix':time.time(),
            'body':{'map_delta':[[2,3,100]],'evidence':{'source':'fixture'}}}
    r.handle(make_packet(packet,KEY));r.close()
    observed=state(db)
    assert [2,3,100] in [list(x) for x in observed['map']]
    assert observed['last_packet']['body']['evidence']['source']=='fixture'
    assert 'map_delta' not in observed['last_packet']['body']

def test_persistent_ground_gate_detects_drop_between_frames():
    from src.safety import GroundGate,Ranges
    gate=GroundGate()
    old=gate.evaluate(Ranges(950,100,10.0,'fixture'),10.01)
    new=gate.evaluate(Ranges(950,190,10.1,'fixture'),10.11)
    assert old['motion_recommendation']=='OBSERVE_ONLY'
    assert 'ground_drop_detected' in new['reasons']
    assert new['motion_recommendation']=='STOP' and not new['motor_control_enabled']
