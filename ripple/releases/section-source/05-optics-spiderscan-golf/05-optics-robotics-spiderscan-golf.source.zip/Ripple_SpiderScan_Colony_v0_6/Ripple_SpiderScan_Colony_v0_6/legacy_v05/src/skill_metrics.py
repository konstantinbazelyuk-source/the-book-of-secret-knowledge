"""Adaptive skills in percent means empirical success/attempts, not IQ or capability declarations."""
from dataclasses import dataclass,field
import math

@dataclass
class SkillMeter:
    attempts:int=0
    successes:int=0
    trace:list=field(default_factory=list)
    def observe(self,success:bool):
        if not isinstance(success,bool):raise TypeError('success must be bool')
        self.attempts+=1;self.successes+=int(success)
        self.trace.append(100*self.successes/self.attempts)
    def result(self):
        n,k=self.attempts,self.successes
        if n==0:return {'attempts':0,'passes':0,'success_pct':None,'wilson_95_pct':None}
        z=1.9599639845;p=k/n;den=1+z*z/n
        middle=(p+z*z/(2*n))/den
        delta=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
        return {'attempts':n,'passes':k,'success_pct':100*p,
                'wilson_95_pct':[100*(middle-delta),100*(middle+delta)]}
