"""On the actual Pi only: captures real camera frame AND timestamps 2 ToF sensors.
No motor, no automatic gait. Refuses to classify sensor timeouts as safe.
"""
import argparse, json, time
from pathlib import Path
import cv2
from src.hardware_pi_READONLY import SensorHead
from src.safety import GroundGate
from src.groundscan_cli import analyze

def main():
    p=argparse.ArgumentParser();p.add_argument('--out-dir',default='captures');a=p.parse_args()
    out=Path(a.out_dir);out.mkdir(parents=True,exist_ok=True)
    head=SensorHead()
    try:
        r=head.range_sample();gate=GroundGate().evaluate(r,time.monotonic())
        img=head.capture_bgr();path=out/'ground_capture.png'
        if not cv2.imwrite(str(path),img):raise RuntimeError('image write failed')
        result=analyze(img,str(path),'UNVERIFIED physical camera; inspect hardware logs')
        result['range_mm']={'forward':r.forward_mm,'ground':r.ground_mm,'observed_monotonic_s':r.observed_at_s}
        result['gate']=gate
        (out/'ground_capture.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
        print(json.dumps({'saved':str(path),'gate':gate},indent=2))
    finally:head.close()
if __name__=='__main__':main()
