"""Ground scanner Ripple adapter. Original 2026-10-13 neuron is LOCKED in legacy/."""
from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
import math, hashlib, json
import cv2
import numpy as np
from legacy.ripple_optical_agent_LOCKED import RippleNeuron

@dataclass
class NeuronState:
    tile_id: int
    born_at: int
    node: RippleNeuron

class GroundColony:
    """Distinct tile coordinates own their own neuron states, no memory remapping.
    Per-tile observation derives RGB channels normalized to [0,1].
    This computes event frequencies, NOT generalized intelligence.
    """
    def __init__(self, rows=4, cols=4, capacity=16, min_nodes=2, texture_threshold=18.0):
        if not (1 <= rows * cols <= 256 and 1 <= min_nodes <= capacity <= rows * cols):
            raise ValueError('invalid node pool')
        self.rows, self.cols, self.capacity = rows, cols, capacity
        self.min_nodes=min_nodes
        self.texture_threshold=texture_threshold
        self.grow_streak=0
        self.shrink_streak=0
        self.nodes:dict[int,NeuronState]={}
        self.tick=0
        self.lifecycle=[]
    def process(self,img_bgr:np.ndarray,dt=0.05):
        if img_bgr is None or img_bgr.ndim!=3 or img_bgr.shape[2]!=3:
            raise ValueError('expected BGR image')
        h,w=img_bgr.shape[:2]
        if h < self.rows*8 or w < self.cols*8: raise ValueError('image too small')
        if not math.isfinite(dt) or not 0<dt<=0.5: raise ValueError('bad neuron dt')
        features=[]
        for r in range(self.rows):
            for c in range(self.cols):
                tile=img_bgr[r*h//self.rows:(r+1)*h//self.rows,c*w//self.cols:(c+1)*w//self.cols]
                gray=cv2.cvtColor(tile,cv2.COLOR_BGR2GRAY)
                texture=float(gray.std())
                rgb=cv2.cvtColor(tile,cv2.COLOR_BGR2RGB).mean((0,1))/255.
                features.append((r*self.cols+c,texture,tuple(float(x) for x in rgb)))
        # Texture-based demand schedule. Birth/retirement has short hysteresis to
        # avoid thrashing; surviving nodes preserve both tile identity and state.
        # Logical node count NOT multiprocessing, reasoning, nor learned weights.
        rank=sorted(features,key=lambda x:(-x[1],x[0]))
        active_demand=sum(tex>=self.texture_threshold for _,tex,_ in features)
        target=max(self.min_nodes,min(self.capacity,active_demand))
        if not self.nodes:
            for i,_,_ in rank[:self.min_nodes]:
                self.nodes[i]=NeuronState(i,self.tick,RippleNeuron())
                self.lifecycle.append({'frame':self.tick,'action':'birth','tile':i})
        else:
            n=len(self.nodes)
            self.grow_streak=self.grow_streak+1 if target>n else 0
            self.shrink_streak=self.shrink_streak+1 if target<n else 0
            if self.grow_streak>=2:
                for i,_,_ in rank:
                    if len(self.nodes)>=target:break
                    if i not in self.nodes:
                        self.nodes[i]=NeuronState(i,self.tick,RippleNeuron())
                        self.lifecycle.append({'frame':self.tick,'action':'birth','tile':i})
                self.grow_streak=0
            elif self.shrink_streak>=4:
                ranked_low=sorted(features,key=lambda x:(x[1],x[0]))
                for i,_,_ in ranked_low:
                    if len(self.nodes)<=target:break
                    if i in self.nodes:
                        del self.nodes[i]
                        self.lifecycle.append({'frame':self.tick,'action':'retire','tile':i})
                self.shrink_streak=0
        out=[];count=0
        for i,texture,rgb in features:
            if i in self.nodes:
                y=self.nodes[i].node.step(rgb,dt)
                count+=y['count']
                out.append({'tile':i,'rgb':list(rgb),'texture_std':texture,
                    'count':y['count'],'theta':y['theta'],'drive':y['drive'], 'state_age_steps':self.tick-self.nodes[i].born_at+1})
        self.tick+=1
        return {'nodes':len(self.nodes),'node_target':target,'textured_tiles':active_demand,
                'events':count,'tiles':out,'tick':self.tick-1}
