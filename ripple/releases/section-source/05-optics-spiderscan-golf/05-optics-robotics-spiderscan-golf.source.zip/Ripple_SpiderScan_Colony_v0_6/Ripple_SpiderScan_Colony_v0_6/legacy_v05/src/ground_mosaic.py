"""Planar stop-and-scan route and mapped image compose.
Important: all image poses MUST come from external calibration/pose measurements.
No SLAM, no automatic motion or autonomous gait. Calculated route is a proposal.
"""
from __future__ import annotations
import math
from dataclasses import dataclass
import numpy as np

@dataclass(frozen=True)
class ScanPose:
    x_mm:float # calibrated top-left-of-image position on reference plane
    y_mm:float
    label:str

@dataclass(frozen=True)
class ScanPlan:
    waypoints:list[ScanPose]
    field_width_mm:float
    field_height_mm:float
    target_width_mm:float
    target_height_mm:float
    overlap_fraction:float

def _positions(length:float,field:float,overlap:float)->list[float]:
    if not all(map(math.isfinite,(length,field,overlap))) or field<=0 or length<=0 or not 0<=overlap<1:
        raise ValueError('bad scan planner geometry')
    if length<=field:return [0.]
    step=field*(1-overlap)
    n=max(1,math.ceil((length-field)/step))
    # place the final image flush to target edge; every step <= requested max
    return [i*(length-field)/n for i in range(n+1)]

def serpentine_plan(target_width_mm:float,target_height_mm:float,
                    field_width_mm:float,field_height_mm:float,overlap_fraction:float=.30)->ScanPlan:
    xs=_positions(target_width_mm,field_width_mm,overlap_fraction)
    ys=_positions(target_height_mm,field_height_mm,overlap_fraction)
    spots=[]
    for row,y in enumerate(ys):
        for col,x in enumerate(xs if row%2==0 else list(reversed(xs))):
            spots.append(ScanPose(x,y,f'row{row:02d}_col{col:02d}'))
    return ScanPlan(spots,field_width_mm,field_height_mm,target_width_mm,target_height_mm,overlap_fraction)

def compose_known_pose(frames:list[tuple[np.ndarray,ScanPose]],mm_per_pixel:float,
                        target_width_mm:float,target_height_mm:float)->tuple[np.ndarray,np.ndarray]:
    """Merge BGR images into a scaled reference plane; outside pixels remain unknown.
    Assumes already rectified, same scale/orientation and translation-only imagery.
    Cannot validate external pose truth. Missing portions are black with coverage mask 0.
    """
    if not frames:raise ValueError('need at least 1 real image array and supplied pose')
    if not all(math.isfinite(v) and v>0 for v in (mm_per_pixel,target_width_mm,target_height_mm)):
        raise ValueError('invalid geometry')
    out_w=math.ceil(target_width_mm/mm_per_pixel)
    out_h=math.ceil(target_height_mm/mm_per_pixel)
    # On SBCs, float64 RGB accumulators + int32 coverage = 28 bytes/pixel,
    # plus ~3 bytes/pixel for final mosaic, transient crops and frame buffers.
    # 2 million pixels => >=62 MB of primary arrays; real peak must be profiled.
    if out_w*out_h>2_000_000:raise ValueError('requested canvas exceeds 2 Mpixel working-memory guard')
    acc=np.zeros((out_h,out_w,3),np.float64)
    counts=np.zeros((out_h,out_w),np.int32)
    for frame,pose in frames:
        if frame is None or frame.ndim!=3 or frame.shape[2]!=3 or frame.dtype!=np.uint8:
            raise ValueError('must supply 8-bit BGR frame')
        if not math.isfinite(pose.x_mm) or not math.isfinite(pose.y_mm) or pose.x_mm<0 or pose.y_mm<0:
            raise ValueError('pose must be measured and non-negative')
        x=round(pose.x_mm/mm_per_pixel)
        y=round(pose.y_mm/mm_per_pixel)
        h,w=frame.shape[:2]
        if x>=out_w or y>=out_h:raise ValueError('image outside map')
        x1,y1=min(x+w,out_w),min(y+h,out_h)
        crop=frame[:y1-y,:x1-x]
        acc[y:y1,x:x1]+=crop.astype(np.float64)
        counts[y:y1,x:x1]+=1
    mosaic=np.zeros((out_h,out_w,3),np.uint8)
    valid=counts>0
    mosaic[valid]=np.rint(acc[valid]/counts[valid,None]).astype(np.uint8)
    return mosaic,valid
