"""Real image scanner CLI: consumes files or sensor hardware, emits JSON of computed values."""
import argparse, json,hashlib,time
from pathlib import Path
import cv2
from src.scan_quality import image_quality,marker_calibrate,ground_sampling
from src.ground_colony import GroundColony
from src.safety import GroundGate

def analyze(img,source,origin='file',repeats=8,calibration=None):
    colony=GroundColony(capacity=16)
    ticks=[colony.process(img,0.05) for _ in range(repeats)]
    out={'classification':'SOFTWARE PIXEL MEASUREMENT; NOT PHYSICAL SENSOR VALIDATION',
         'source':source,'origin':origin,'dimensions_px':list(img.shape[:2][::-1]),
         'quality':image_quality(img),
         'neuron_count_peak':max(t['nodes'] for t in ticks),
         'neuron_events':sum(t['events'] for t in ticks),
         'colony_lifecycle':colony.lifecycle,
         'last_tick':ticks[-1]}
    if calibration:
        out['calibrated_image_extent']=ground_sampling(calibration,img.shape[1],img.shape[0])
        out['calibration_limit']='plane-only; no distortion/perspective correction'
    return out

def main():
    p=argparse.ArgumentParser();p.add_argument('--image',type=Path,required=True)
    p.add_argument('--calibration',type=Path);p.add_argument('--physical-mark-spacing-mm',type=float,default=100.0)
    p.add_argument('--out',type=Path,default=Path('results/ground_scan.json'))
    a=p.parse_args();img=cv2.imread(str(a.image))
    if img is None:raise SystemExit('Could not decode supplied image')
    cal=None
    if a.calibration:
        marker=cv2.imread(str(a.calibration))
        if marker is None:raise SystemExit('Could not read calibration image')
        cal=marker_calibrate(marker,a.physical_mark_spacing_mm)
    r=analyze(img,str(a.image),origin='supplied_file',calibration=cal)
    r['input_sha256']=hashlib.sha256(a.image.read_bytes()).hexdigest()
    a.out.parent.mkdir(parents=True,exist_ok=True)
    a.out.write_text(json.dumps(r,indent=2,allow_nan=False)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='last_tick'},indent=2))
if __name__=='__main__':main()
