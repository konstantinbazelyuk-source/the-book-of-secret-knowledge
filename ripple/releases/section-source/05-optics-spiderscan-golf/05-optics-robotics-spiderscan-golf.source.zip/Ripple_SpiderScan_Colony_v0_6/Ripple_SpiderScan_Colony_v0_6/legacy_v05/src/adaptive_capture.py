"""Exposure suggestions from actual image luminance. Not a trained ML model.
Values are commands for a future camera integration; safety/range gating remains independent.
"""
from dataclasses import dataclass
import math
from src.scan_quality import image_quality

@dataclass
class ExposureAdvisor:
    microseconds:int=5000
    min_us:int=250
    max_us:int=25000
    target_gray:float=125.0
    damp:float=.65
    adjustments:int=0
    def update(self,bgr):
        q=image_quality(bgr)
        val=q['mean_gray']
        if val<=1:ratio=2.0
        else:ratio=min(2.,max(.5,self.target_gray/val))
        # damping limits oscillation on nonlinear reflectance curves.
        suggested=self.microseconds*ratio**self.damp
        new_us=round(max(self.min_us,min(self.max_us,suggested)))
        if abs(new_us-self.microseconds)>5:self.adjustments+=1
        self.microseconds=new_us
        return {'recommended_exposure_us':new_us,'measured_gray_mean':val,
                'adjustment_count':self.adjustments,'pass_quality_gate':q['passes_provisional_gates'],
                'limitations':'advice only; requires camera auto-exposure disabled and physical testing'}
