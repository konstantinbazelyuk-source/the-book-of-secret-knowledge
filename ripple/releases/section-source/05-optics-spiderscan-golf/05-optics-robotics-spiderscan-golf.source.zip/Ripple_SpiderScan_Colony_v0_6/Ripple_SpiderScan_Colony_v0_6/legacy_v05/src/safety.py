"""Independent sensor health gate. Emits STOP/SCAN_ONLY suggestions, never servo commands."""
from __future__ import annotations
from dataclasses import dataclass
import math

@dataclass(frozen=True)
class Ranges:
    forward_mm:float|None
    ground_mm:float|None
    observed_at_s:float
    source:str='hardware'

class GroundGate:
    def __init__(self,max_age_s=0.35,obstacle_stop_mm=350,ground_min_mm=50,ground_max_mm=220,step_drop_mm=75):
        self.max_age_s,self.obstacle_stop_mm=max_age_s,obstacle_stop_mm
        self.ground_min_mm,self.ground_max_mm=ground_min_mm,ground_max_mm
        self.step_drop_mm=step_drop_mm;self.previous_ground=None
    def evaluate(self,r:Ranges,now_s:float):
        reasons=[]
        if r.source not in ('hardware','fixture'):
            reasons.append('unrecognized_sensor_origin')
        if (not math.isfinite(now_s)) or (not math.isfinite(r.observed_at_s)) or now_s<r.observed_at_s or now_s-r.observed_at_s>self.max_age_s:
            reasons.append('missing_or_stale_data')
        for val,name in ((r.forward_mm,'forward'),(r.ground_mm,'ground')):
            if val is None or (not math.isfinite(val)) or val<=0:
                reasons.append(f'{name}_invalid')
        if not reasons:
            if r.forward_mm<self.obstacle_stop_mm: reasons.append('forward_obstacle')
            if not self.ground_min_mm <=r.ground_mm<=self.ground_max_mm: reasons.append('ground_out_of_range')
            if self.previous_ground is not None and r.ground_mm-self.previous_ground >self.step_drop_mm:
                reasons.append('ground_drop_detected')
            self.previous_ground=r.ground_mm
        return {'motion_recommendation':'STOP' if reasons else 'OBSERVE_ONLY',
                'motor_control_enabled':False,'reasons':reasons,'source':r.source}
