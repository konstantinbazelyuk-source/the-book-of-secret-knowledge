"""For RPi ONLY: real sensor and camera adapter. No locomotion/motor commands.
Requires: pip install adafruit-blinka adafruit-circuitpython-tca9548a
 adafruit-circuitpython-vl53l1x picamera2 (Pi OS package recommended).
Not exercised on physical devices in the authored package.
"""
import time
from src.safety import Ranges

class SensorHead:
    def __init__(self):
        import board
        import adafruit_tca9548a
        import adafruit_vl53l1x
        from picamera2 import Picamera2
        i2c=board.I2C()
        mux=adafruit_tca9548a.TCA9548A(i2c)
        self.front=adafruit_vl53l1x.VL53L1X(mux[0]);self.down=adafruit_vl53l1x.VL53L1X(mux[1])
        self.front.distance_mode=2;self.down.distance_mode=2
        self.front.timing_budget=50;self.down.timing_budget=50
        self.front.start_ranging();self.down.start_ranging()
        self.cam=Picamera2()
        self.cam.configure(self.cam.create_still_configuration(main={'format':'RGB888','size':(1456,1088)}))
        self.cam.start()
    def range_sample(self):
        # Returns None on timeout; no optimistic reuse of stale values.
        def one(sensor):
            return float(sensor.distance)*10.0 if sensor.data_ready and sensor.distance is not None else None
        sample=Ranges(one(self.front),one(self.down),time.monotonic(),source='hardware')
        if self.front.data_ready:self.front.clear_interrupt()
        if self.down.data_ready:self.down.clear_interrupt()
        return sample
    def capture_bgr(self):
        # Picamera2 official manual: RGB888 capture_array() is byte-ordered B,G,R.
        # OpenCV already expects B,G,R; do NOT convert or swap R/B here.
        return self.cam.capture_array()
    def close(self):
        self.front.stop_ranging();self.down.stop_ranging();self.cam.stop()
