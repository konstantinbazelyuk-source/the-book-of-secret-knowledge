"""Only numerical image measurements; calibration requires a PHYSICAL reference target."""
from __future__ import annotations
import math
from dataclasses import dataclass,asdict
import cv2
import numpy as np

@dataclass
class Calibration:
    distance_mm:float
    pixels_between_marks:float
    mm_per_px:float
    plane_only:bool=True

def marker_calibrate(img_bgr:np.ndarray,real_mm:float=100.0)->Calibration:
    """Two circular black ink marks on a clean white calibration image.
    No lens distortion correction or perspective correction: planar orthographic approx.
    Use measured mark-spacing; print size must be independently checked with calipers.
    """
    if not math.isfinite(real_mm) or real_mm<=0: raise ValueError('real marker spacing required')
    gray=cv2.cvtColor(img_bgr,cv2.COLOR_BGR2GRAY)
    if gray.max()-gray.min()<60: raise ValueError('insufficient target contrast')
    mask=np.uint8(gray<min(120,int(np.quantile(gray,.2))))*255
    n,ids,stats,centroids=cv2.connectedComponentsWithStats(mask)
    blobs=[]
    for i in range(1,n):
        x,y,w,h,area=stats[i]
        if area>=15 and 0.6<w/h<1.65 and area/(w*h)>.45:
            blobs.append((area,centroids[i]))
    blobs.sort(key=lambda p:-p[0]);
    if len(blobs)!=2: raise ValueError(f'expected exactly two markers, found {len(blobs)}')
    sep=float(np.linalg.norm(blobs[0][1]-blobs[1][1]))
    if sep<10: raise ValueError('markers too close')
    return Calibration(real_mm,sep,real_mm/sep)

def image_quality(img_bgr:np.ndarray):
    if img_bgr is None or img_bgr.ndim!=3: raise ValueError('BGR expected')
    gray=cv2.cvtColor(img_bgr,cv2.COLOR_BGR2GRAY)
    sharpness=float(cv2.Laplacian(gray,cv2.CV_64F).var())
    clip=float(np.mean((gray<=5)|(gray>=250)))
    exposure=float(gray.mean())
    # illustrative acceptance gates, not universally calibrated photographic thresholds
    reasons=[]
    if sharpness<75.:reasons.append('blur_or_low_texture')
    if clip>.2:reasons.append('clipped_pixels')
    if not 35<=exposure<=220:reasons.append('exposure_outside_range')
    return {'sharpness_laplacian_variance':sharpness,'clipped_fraction':clip,
        'mean_gray':exposure,'passes_provisional_gates':not reasons,'issues':reasons}

def ground_sampling(cal:Calibration,image_width_px:int,image_height_px:int):
    return {'width_mm':image_width_px*cal.mm_per_px,
            'height_mm':image_height_px*cal.mm_per_px,
            'pixel_pitch_mm_per_px':cal.mm_per_px,
            'area_cm2':image_width_px*image_height_px*(cal.mm_per_px**2)/100}
