# SpiderScan Engineering Gates (v0.3, not certified)

| Gate | Quantitative rule / observation | Evidence available | Pass? |
|---|---|---|---|
| Core source continuity | SHA-256 of archived Ripple v0.1 matches locked v0.2 value | Validated unchanged hash | YES (software only) |
| Digital mosaicking | Known +8-pixel crop shifts reconstruct original image and no invalid frames accepted | 20/20 digital images, 0.0 8-bit MAE | YES (synthetic fixture only) |
| Codec path | Decode video, reconstruct and compare against uncompressed archived image | 20/20 frames, 2.8291 8-bit mean absolute error | YES (digital input only) |
| Rotation gate | Reject rotating view that invalidates translation model | 8-degree rotation fixture rejected | YES (selected case only) |
| No texture | Do not make up an optical-flow vector | blank frames correctly rejected | YES (selected case only) |
| Print-ready geometry manifold | All exported mockup STLs are closed watertight meshes | trimesh 3/3 pass | YES (geometry only) |
| Optical focus | Field camera resolves physical target at selected working distance; lens intrinsics verified | No physical device | NOT TESTED |
| Printed piece fit | Camera mounting, lens, cable bend, fasteners, vibration mounts checked | No printed item | NOT TESTED |
| Leg assembly | Rods/sockets assembled and static load fatigue and wobble measured | No physical legs | NOT TESTED |
| Rotor swept-clearance | Confirm actual prop diameter, mount deflection under load, leg clearance, aerodynamic interactions | Ideal geometric static envelopes only | NOT TESTED |
| Flight mass / CG | Actual full airframe weighed and CG measured; design mass budget re-evaluated | No mass measurements | NOT TESTED |
| ESC and motor thrust | Measured max thrust at intended voltage/prop with safety margin; ESC temp logged | No bench testing | NOT TESTED |
| Battery endurance | Measured safe usable capacity and hover current, voltage sag | No battery/hover test | NOT TESTED |
| Scanner color repeatability | Minimum 5 identical flatbed scans, RGB mean ±stdev plus ICC workflow | No physical scanner | NOT TESTED |
| Real flight footage | Verified camera original file and independent calibration before world-unit assertion | No user video | NOT TESTED |
| Flight readiness | Flight controller integration by competent builder, RC failsafe, guards, airspace/legal requirements checked | No aircraft | NOT AUTHORIZED |

The 2:1 thrust-to-weight target used in the sample calculator is an **engineering heuristic** with no claim of regulatory compliance. Real motor bench measurements must be used. Cameras and lenses must not protrude into rotor swept volumes. Standard consumer drone firmware is NOT altered. All flight actions remain human-supervised.
