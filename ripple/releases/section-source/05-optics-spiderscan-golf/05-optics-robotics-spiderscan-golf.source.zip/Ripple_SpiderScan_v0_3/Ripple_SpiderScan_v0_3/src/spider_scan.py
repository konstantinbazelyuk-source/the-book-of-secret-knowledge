#!/usr/bin/env python3
"""Ripple SpiderScan v0.3, local read-only scanner-like mosaic from frames.
Source images/video are measured as digital pixels. No vehicle hardware is
controlled. Core neuron code is imported unchanged from Ripple v0.1.
SPDX-License-Identifier: CC0-1.0
"""
from __future__ import annotations
import argparse, csv, hashlib, json, math, sys
from pathlib import Path
import cv2
import numpy as np

# Run from the repository root, or python -m src.spider_scan
from legacy.ripple_optical_agent import RippleNeuron

def sha256(path:Path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for data in iter(lambda:f.read(1024*1024),b''):
            h.update(data)
    return h.hexdigest()

def write_json(path:Path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(data,indent=2,allow_nan=False)+"\n")

class NodePool:
    """One stateful Ripple neuron per image strip. Capacity is task partitioning,
    not multi-core parallelism. New neurons start with original initial state.
    """
    def __init__(self, min_nodes=2,max_nodes=8,work_unit=40):
        if not 1<=min_nodes<=max_nodes<=32 or work_unit<1:raise ValueError('Invalid pool')
        self.nodes=[RippleNeuron() for _ in range(min_nodes)]
        self.min=min_nodes;self.max=max_nodes;self.work_unit=work_unit
        self.high=0;self.low=0;self.transitions=[]
    def update(self,task_count:int,frame:int):
        wanted=max(self.min,min(self.max,math.ceil(max(0,task_count)/self.work_unit)))
        self.high=self.high+1 if wanted>len(self.nodes) else 0
        self.low=self.low+1 if wanted<len(self.nodes) else 0
        if self.high>=3:
            prev=len(self.nodes)
            self.nodes += [RippleNeuron() for _ in range(wanted-prev)]
            self.transitions.append({'frame':frame,'from':prev,'to':len(self.nodes),'condition':'3 intervals overload'})
            self.high=0
        if self.low>=6:
            prev=len(self.nodes)
            self.nodes=self.nodes[:wanted]
            self.transitions.append({'frame':frame,'from':prev,'to':len(self.nodes),'condition':'6 intervals underload'})
            self.low=0
    def feed(self,frame:np.ndarray,dt:float,step:int):
        rgb=cv2.cvtColor(frame,cv2.COLOR_BGR2RGB)
        n=len(self.nodes);h,w=frame.shape[:2]
        logs=[]
        for i,node in enumerate(self.nodes):
            x0=i*w//n;x1=(i+1)*w//n
            v=rgb[:,x0:x1].mean(axis=(0,1))/255.0
            output=node.step(tuple(float(x) for x in v),dt)
            logs.append({'frame':step,'node':i,'observed_rgb':list(map(float,v)),
                'drive':float(output['drive']),'threshold':float(output['theta']),
                'spikes':int(output['count'])})
        return logs

def estimate_translation(prev:np.ndarray,curr:np.ndarray,min_tracks=14):
    """Estimate p(curr)-p(prev), pixel coordinates. Reject nonplanar/rotational
    scene when a 2D translation alone is not defensible. Quality gates are
    candidate engineering values; real footage requires characterization.
    """
    if prev.shape!=curr.shape:raise ValueError('Video frame dimensions changed')
    a=cv2.cvtColor(prev,cv2.COLOR_BGR2GRAY)
    b=cv2.cvtColor(curr,cv2.COLOR_BGR2GRAY)
    p=cv2.goodFeaturesToTrack(a,400,qualityLevel=.008,minDistance=6,blockSize=5)
    if p is None or len(p)<min_tracks:return None,{'reason':'insufficient initial corners','tracks':0 if p is None else len(p)}
    q,st,_=cv2.calcOpticalFlowPyrLK(a,b,p,None,winSize=(21,21),maxLevel=3)
    if q is None:return None,{'reason':'optical flow unavailable','tracks':0}
    back,st2,_=cv2.calcOpticalFlowPyrLK(b,a,q,None,winSize=(21,21),maxLevel=3)
    if back is None:return None,{'reason':'reverse flow unavailable','tracks':0}
    ok=(st.reshape(-1)==1)&(st2.reshape(-1)==1)&(np.linalg.norm(p.reshape(-1,2)-back.reshape(-1,2),axis=1)<=1.0)
    p0=p.reshape(-1,2)[ok];p1=q.reshape(-1,2)[ok]
    if len(p0)<min_tracks:return None,{'reason':'too few bidirectionally valid tracks','tracks':len(p0)}
    A,inliers=cv2.estimateAffinePartial2D(p0,p1,method=cv2.RANSAC,ransacReprojThreshold=1.25,maxIters=3000,confidence=.99)
    if A is None:return None,{'reason':'affine fit failed','tracks':len(p0)}
    scale=float(np.hypot(A[0,0],A[1,0]));rot=float(math.degrees(math.atan2(A[1,0],A[0,0])))
    mask=inliers.flatten().astype(bool)
    n=int(mask.sum());frac=n/len(p0)
    diff=(p1-p0)[mask]
    median=np.median(diff,axis=0)
    residual=np.linalg.norm(diff-median,axis=1)
    rms=float(np.sqrt(np.mean(residual**2)))
    meta={'tracks':int(len(p0)),'inliers':n,'inlier_fraction':float(frac),'rotation_deg':rot,
          'scale':scale,'translation_px':[float(median[0]),float(median[1])],
          'inlier_translation_residual_rms_px':rms}
    if n<min_tracks or frac<.7 or abs(rot)>1.5 or abs(scale-1)>.02 or rms>1.5:
        meta['reason']='non-translational/unstable camera geometry';return None,meta
    # 2D scene shift: current IMAGE moves by median. Camera pose moves oppositely.
    meta['reason']='accepted planar-translation approximation'
    return median,meta

def mosaic_frames(frames:list[np.ndarray],fps:float,output:Path,source_label='UNSPECIFIED',
                  hashes=None,max_frame_shift_px=45,work_unit=40):
    if len(frames)<2:raise ValueError('At least two frames needed')
    if not np.isfinite(fps) or fps<2:raise ValueError('fps must be at least 2 for the locked neuron step')
    if len({tuple(x.shape) for x in frames})!=1:raise ValueError('All frames must have same dimensions')
    h,w=frames[0].shape[:2]
    if h<40 or w<40:raise ValueError('frames too small')
    if w>2048 or h>2048:raise ValueError('Resize video explicitly to <=2048 per dimension before analysis')
    output.mkdir(parents=True,exist_ok=True)
    pool=NodePool(work_unit=work_unit)
    offsets=[(0.,0.)];accepted=[0];logs=[];per_frame=[]
    logs.extend(pool.feed(frames[0],1/fps,0))
    running=np.array([0.,0.],dtype=float)
    for t in range(1,len(frames)):
        last_good=accepted[-1]
        shift,meta=estimate_translation(frames[last_good],frames[t])
        if shift is not None and float(np.linalg.norm(shift))>max_frame_shift_px:
            meta['reason']='translation exceeds configured maximum';shift=None
        if shift is None:
            # Important: don't silently shift to a fake guessed position.
            per_frame.append({'index':t,'accepted':False,**meta});continue
        running-=shift  # camera displacement opposite scene feature motion relative to LAST ACCEPTED frame
        accepted.append(t);offsets.append(tuple(map(float,running)))
        pool.update(meta['inliers'],t)
        gap=t-last_good
        if gap/fps>.5:
            # Ripple's approved core forbids steps longer than 0.5 s.
            # Feed repeated observed measurement at substeps (sample/hold), documented.
            substeps=math.ceil((gap/fps)/.5)
        else:substeps=1
        for k in range(substeps):
            logs.extend(pool.feed(frames[t],gap/fps/substeps,t))
        per_frame.append({'index':t,'accepted':True,'cumulative_camera_offset_px':list(map(float,running)),**meta})
    # Coordinates are in first-image pixel scale. Do not infer ground GSD.
    rounded=np.rint(np.asarray(offsets)).astype(int)
    lo=rounded.min(axis=0);hi=(rounded+np.array([w,h])).max(axis=0)
    outw=int(hi[0]-lo[0]);outh=int(hi[1]-lo[1])
    if outw*outh>50_000_000:raise ValueError('Refusing panorama allocation >50 million pixels')
    accum=np.zeros((outh,outw,3),dtype=np.float32)
    count=np.zeros((outh,outw),dtype=np.uint16)
    for frame_index,xy in zip(accepted,rounded):
        x,y=(xy-lo).astype(int)
        # no color calibration: simple mean of encoded values, not radiometry
        accum[y:y+h,x:x+w]+=frames[frame_index].astype(np.float32)
        count[y:y+h,x:x+w]+=1
    mask=count>0
    panorama=np.zeros_like(accum,dtype=np.uint8)
    panorama[mask]=np.clip(np.rint(accum[mask]/count[mask,None]),0,255).astype(np.uint8)
    cv2.imwrite(str(output/'panorama.png'),panorama)
    cv2.imwrite(str(output/'coverage.png'),(mask.astype('uint8')*255))
    image_homography_assumption='Planar, approximately pure translation; no camera calibration, radiometric correction or height estimate.'
    summary={'name':'Ripple SpiderScan v0.3', 'source':source_label,'source_sha256':hashes,
             'evidence':'MEASURED PIXELS in supplied frames; physical device origin depends on verified inputs',
             'fps_input':fps,'input_frame_count':len(frames),'accepted_frame_count':len(accepted),
             'rejected_pair_count':len(frames)-len(accepted),
             'frame_shape_hw_px':[h,w], 'panorama_shape_hw_px':[outh,outw],
             'coverage_fraction_of_panorama':float(mask.mean()), 'coverage_pixel_count':int(mask.sum()),
             'mean_observations_per_covered_pixel':float(count[mask].mean()),
             'node_count_final':len(pool.nodes),'node_pool_transitions':pool.transitions,
             'neuron_spikes':sum(x['spikes'] for x in logs),
             'motion_pixels_per_frame_units_only':True,
             'reconstruction_assumption':image_homography_assumption,
             'rejected_frames_not_stitched_or_neuron_fed':True,
             'no_motor_or_printer_or_drone_commands':True,
             'not_measured':'absolute field intensity, laser phase, magnetic field, displacement in meters, autonomy or intelligence'}
    write_json(output/'summary.json',summary)
    write_json(output/'motion_trace.json',per_frame)
    write_json(output/'neuron_trace.json',logs)
    return summary

def recorded_video(path:Path,output:Path,max_frames:int=120,skip:int=1,fps:float|None=None,scale=.5):
    if max_frames<2 or skip<1 or not (0<scale<=1):raise ValueError('Invalid downsample settings')
    cap=cv2.VideoCapture(str(path))
    if not cap.isOpened():raise ValueError('Video cannot be opened')
    recorded_fps=float(cap.get(cv2.CAP_PROP_FPS))
    rate=fps if fps is not None else recorded_fps
    if not np.isfinite(rate) or rate<=0:raise ValueError('No trustworthy FPS; provide --fps')
    frames=[];i=0
    while len(frames)<max_frames:
        ok,frame=cap.read()
        if not ok:break
        if i%skip==0:
            if scale!=1:frame=cv2.resize(frame,None,fx=scale,fy=scale,interpolation=cv2.INTER_AREA)
            frames.append(frame)
        i+=1
    cap.release()
    return mosaic_frames(frames,rate/skip,output,'VIDEO_FILE_NOT_LIVE_FLIGHT',str(path)+'#sha256='+sha256(path))

def calibration(length_mm:float,length_sigma_mm:float,pixel_distance:float,pixel_sigma:float):
    vals=(length_mm,length_sigma_mm,pixel_distance,pixel_sigma)
    if not all(math.isfinite(x) for x in vals) or min(length_mm,pixel_distance)<=0 or min(length_sigma_mm,pixel_sigma)<0:
        raise ValueError('Invalid calibration numbers')
    pitch=length_mm/pixel_distance
    sigma=pitch*math.hypot(length_sigma_mm/length_mm,pixel_sigma/pixel_distance)
    return {'measured_reference_length_mm':length_mm,'length_std_uncertainty_mm':length_sigma_mm,
            'measured_reference_length_px':pixel_distance,'endpoints_std_uncertainty_px':pixel_sigma,
            'local_scale_mm_per_pixel':pitch,'scale_std_uncertainty_mm_per_pixel':sigma,
            'equivalent_local_dpi':25.4/pitch,
            'assumptions':'Independent small uncertainties, local planar calibration only. No airborne geometry claim.'}

def thrust_budget(mass_g:float,thrust_gf_per_motor:float,motor_count:int=4,design_min_twr=2.):
    if min(mass_g,thrust_gf_per_motor,motor_count,design_min_twr)<=0:raise ValueError('positive arguments required')
    total=motor_count*thrust_gf_per_motor
    return {'mass_input_g':mass_g,'motor_count':motor_count,'measured_thrust_input_gf_per_motor':thrust_gf_per_motor,
            'all_motor_static_thrust_gf':total,'gravity_N':mass_g/1000*9.80665,
            'max_static_thrust_N':total/1000*9.80665,'static_thrust_weight_ratio':total/mass_g,
            'design_target_twr':design_min_twr,'meets_arbitrary_design_threshold':total/mass_g>=design_min_twr,
            'warning':'This assumes thrust-gf input from measured motor+prop+battery setup; not a flightworthiness test.'}

def main():
    p=argparse.ArgumentParser(description='Read-only visual scanner for spider drone; never controls motors')
    sub=p.add_subparsers(dest='mode',required=True)
    v=sub.add_parser('scan-video');v.add_argument('--video',required=True,type=Path);v.add_argument('--output',required=True,type=Path)
    v.add_argument('--max-frames',type=int,default=120);v.add_argument('--skip',type=int,default=1)
    v.add_argument('--fps',type=float);v.add_argument('--scale',type=float,default=.5)
    q=sub.add_parser('compare-images');q.add_argument('--reference',required=True,type=Path);q.add_argument('--observed',required=True,type=Path);q.add_argument('--output',required=True,type=Path);q.add_argument('--no-alignment',action='store_true')
    c=sub.add_parser('calibrate');c.add_argument('--length-mm',type=float,required=True);c.add_argument('--sigma-mm',type=float,required=True)
    c.add_argument('--pixels',type=float,required=True);c.add_argument('--sigma-px',type=float,required=True)
    t=sub.add_parser('thrust');t.add_argument('--mass-g',type=float,required=True)
    t.add_argument('--per-motor-gf',type=float,required=True)
    a=p.parse_args()
    if a.mode=='scan-video':answer=recorded_video(a.video,a.output,a.max_frames,a.skip,a.fps,a.scale)
    elif a.mode=='compare-images':
        from legacy.sensor_bridge_v0_2 import scanner_measure
        answer=scanner_measure(a.reference,a.observed,a.output,alignment=not a.no_alignment)
        answer['spider_v0_3_command']='compare-images; inherited verified v0.2 scanner image comparator'
    elif a.mode=='calibrate':answer=calibration(a.length_mm,a.sigma_mm,a.pixels,a.sigma_px)
    else:answer=thrust_budget(a.mass_g,a.per_motor_gf)
    print(json.dumps(answer,indent=2))
if __name__=='__main__':
    try:main()
    except (ValueError,FileNotFoundError) as exc:print('ERROR:',exc,file=sys.stderr);raise SystemExit(2)
