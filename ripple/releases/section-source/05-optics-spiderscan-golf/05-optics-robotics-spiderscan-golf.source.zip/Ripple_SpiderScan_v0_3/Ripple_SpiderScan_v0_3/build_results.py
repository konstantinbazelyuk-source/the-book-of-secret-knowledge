"""Rebuild reproducible software fixtures and engineering drawings."""
from pathlib import Path
import json, math
import numpy as np
import cv2
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Rectangle, FancyArrowPatch
from matplotlib.gridspec import GridSpec
from mpl_toolkits.mplot3d import Axes3D
from src.spider_scan import mosaic_frames, recorded_video,thrust_budget,calibration
import trimesh
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'results';OUT.mkdir(exist_ok=True)
ORIGIN=cv2.imread(str(ROOT/'fixtures'/'archived_photo_NOT_DRONE.png'))
assert ORIGIN is not None
hi=cv2.resize(ORIGIN,(900,600),interpolation=cv2.INTER_LINEAR)
N=20;dx=8
frames=[hi[80:320,30+i*dx:350+i*dx].copy() for i in range(N)]
base=mosaic_frames(frames,20,OUT/'digital_crops',source_label='DIGITALLY_CROPPED_ARCHIVED_PHOTO_NOT_A_DRONE')
pano=cv2.imread(str(OUT/'digital_crops'/'panorama.png'))
truth=hi[80:320,30:30+pano.shape[1]]
err=np.abs(pano.astype(np.float32)-truth.astype(np.float32))
base['vs_original_photo_truth_mean_absolute_encoded_8bit_difference']=float(err.mean())
base['known_digital_crop_motion_x_px_per_frame']=dx
base['known_digital_crop_motion_y_px_per_frame']=0
base['truth_is_pure_software_crop_sequence']=True
base['hardware_measurements']=0
base['original_photo_not_captured_by_project']=True
(OUT/'digital_crops'/'evaluation.json').write_text(json.dumps(base,indent=2))
# Force MP4 video decode path; if encoder unavailable, fail to catch it.
vpath=ROOT/'fixtures'/'synthetic_camera_translation_NOT_DRONE.mp4'
enc=cv2.VideoWriter(str(vpath),cv2.VideoWriter_fourcc(*'mp4v'),20,(320,240))
assert enc.isOpened()
for im in frames:enc.write(im)
enc.release()
vid=recorded_video(vpath,OUT/'decoded_video',max_frames=N,scale=1)
vid['input_is_compressed_software_generated_video']=True
(OUT/'decoded_video'/'evaluation.json').write_text(json.dumps(vid,indent=2))
# Save a side by side to make known original-vs-stitch visible
cv2.imwrite(str(OUT/'reference_truth_region.png'),truth)
fig=plt.figure(figsize=(11,5.5),facecolor='#fff')
gs=GridSpec(2,2,figure=fig,width_ratios=[1,1],hspace=.35,wspace=.05)
for j,(p,title) in enumerate([(pano,'Recovered panorama (calculated)'),(truth,'Original photo crop (reference)')]):
 ax=fig.add_subplot(gs[0,j]);ax.imshow(cv2.cvtColor(p,cv2.COLOR_BGR2RGB));ax.set_title(title,fontsize=11);ax.axis('off')
ax=fig.add_subplot(gs[1,:]);ax.plot(err.mean(axis=2).mean(axis=0),lw=1.2);ax.set(xlabel='Panorama horizontal pixel coordinate',ylabel='Mean channel absolute difference (8-bit)',title='Software fixture pixel discrepancy vs original archived photograph');ax.grid(alpha=.25)
fig.suptitle('Ripple SpiderScan v0.3  |  digital-frame experiment (not flight data)',fontsize=14,fontweight='bold')
fig.savefig(OUT/'mosaic_comparison.png',dpi=175,bbox_inches='tight');plt.close(fig)
# Engineering orthographic drawing
fig=plt.figure(figsize=(14.5,8.5),facecolor='#fff')
ax=fig.add_subplot(121);ax.set_aspect('equal');ax.set_title('TOP VIEW  /  Millimetres  /  Concept geometry',fontweight='bold')
for x in (-105,105):
 for y in (-105,105):
  ax.add_patch(Circle((x,y),63.5,edgecolor='#00a0a0',facecolor='#74dad6',alpha=.14,linewidth=1.5))
  ax.add_patch(Circle((x,y),14,edgecolor='#243946',facecolor='#b4c6cc'))
  ax.plot([0,x],[0,y],color='#475863',lw=9,solid_capstyle='round',zorder=1)
  ax.text(x,y,'M',ha='center',va='center',fontsize=9,zorder=9)
ax.add_patch(Rectangle((-45,-39),90,78,facecolor='#ddd8c9',edgecolor='#495666',lw=2,zorder=4))
ax.add_patch(Rectangle((-29,-29),58,58,facecolor='#f6ad66',edgecolor='#b46c38',lw=1.8,zorder=5))
for angle in np.linspace(0,2*np.pi,8,endpoint=False):
 a=np.array([np.cos(angle),np.sin(angle)])
 ps=np.array([34,99,185])[:,None]*a[None,:]
 ax.plot(ps[:,0],ps[:,1],'-',color='#344e62',lw=4,zorder=2)
 ax.plot(ps[-1,0],ps[-1,1],'o',color='#d17c3c',markersize=8)
ax.text(0,0,'SCAN\nCAM',ha='center',va='center',fontweight='bold',fontsize=10,zorder=10)
ax.plot([-105,105],[-178,-178],color='#334d64',lw=1.4,marker='|',markersize=12)
ax.text(0,-191,'210 mm horizontal rotor spacing',ha='center',va='top',fontsize=10)
ax.set(xlim=(-215,215),ylim=(-210,210),xlabel='X (mm)',ylabel='Y (mm)');ax.grid(alpha=.12)
ax2=fig.add_subplot(122);ax2.set_aspect('equal');ax2.set_title('SIDE VIEW  /  Heights are design coordinates',fontweight='bold')
ax2.add_patch(Rectangle((-45,-1.5),90,3,facecolor='#ddd8c9',edgecolor='#495666'))
ax2.add_patch(Rectangle((-29,-29),58,4,facecolor='#f6ad66',edgecolor='#b46c38'))
ax2.add_patch(Rectangle((-19,-23),38,3,facecolor='#2a3c56'))
for side in (-1,1):
 ax2.plot([side*34,side*99,side*185],[-8,-48,-98],lw=4,color='#344e62')
 ax2.plot([side*105-63.5,side*105+63.5],[42,42],lw=3,color='#009d9d')
 ax2.plot([side*105,side*105],[0,42],lw=5,color='#5d6d79')
ax2.plot([-205,205],[-105,-105],color='#aaaaaa',lw=1.5)
ax2.text(0,-114,'GROUND / conceptual clearance (not tested)',ha='center',fontsize=10)
ax2.text(0,-68,'Camera looking down',ha='center',fontsize=10,color='#b46c38')
ax2.annotate('5-inch rotor disk plane (+42 mm)',xy=(105,42),xytext=(-40,71),arrowprops={'arrowstyle':'->'},fontsize=10)
ax2.annotate('Eight passive carbon-rod legs',xy=(165,-84),xytext=(-15,-135),arrowprops={'arrowstyle':'->'},fontsize=10)
ax2.set(xlim=(-215,215),ylim=(-150,90),xlabel='X (mm)',ylabel='Z (mm)');ax2.grid(alpha=.12)
fig.suptitle('SpiderScan: quadrotor + eight passive legs + downward scanner head\nDO NOT MANUFACTURE PRIMARY FLIGHT ARMS FROM GROUND-MOCKUP CAD',fontsize=15,fontweight='bold')
fig.savefig(ROOT/'design'/'SpiderScan_dimensioned_geometry.png',dpi=170,bbox_inches='tight');plt.close(fig)
# 3D approximation geometry
fig=plt.figure(figsize=(12,9),facecolor='#fff');ax=fig.add_subplot(111,projection='3d');ax.set_proj_type('persp')
for a in np.linspace(0,2*np.pi,8,endpoint=False):
 cos,sin=np.cos(a),np.sin(a)
 x=np.array([34,99,185])*cos;y=np.array([34,99,185])*sin;z=np.array([-8,-48,-98])
 ax.plot(x,y,z,color='#315168',lw=3)
 ax.scatter([x[-1]],[y[-1]],[z[-1]],color='#ba7039',s=22)
for x in (-105,105):
 for y in (-105,105):
  ax.plot([0,x],[0,y],[0,30],color='#627983',lw=5)
  ax.plot([x,x],[y,y],[30,42],color='#203744',lw=7)
  t=np.linspace(0,2*np.pi,150)
  ax.plot(x+63.5*np.cos(t),y+63.5*np.sin(t),np.full_like(t,42),color='#0d9e9c',lw=1.5,alpha=.8)
xs=[-45,45,45,-45,-45];ys=[-39,-39,39,39,-39]
ax.plot(xs,ys,[0]*5,color='#a8845f',lw=7)
ax.plot([-29,29,29,-29,-29],[-29,-29,29,29,-29],[-27]*5,color='#d38544',lw=5)
ax.scatter([0],[0],[-29],color='#d38544',s=130)
ax.set(xlim=(-220,220),ylim=(-220,220),zlim=(-140,95),xlabel='X mm',ylabel='Y mm',zlabel='Z mm')
ax.view_init(elev=22,azim=48);ax.set_box_aspect((1,1,.55));ax.set_title('SPIDER-SHAPED SENSOR AIRFRAME  |  engineering concept\n4 motors + 8 passive landing legs + downward scanner camera\nNot a flight-qualified airframe',fontsize=14,fontweight='bold')
fig.savefig(ROOT/'design'/'SpiderScan_isometric_concept.png',dpi=185,bbox_inches='tight');plt.close(fig)
# Mesh validation and projected mass estimates from assumed densities (NOT measured)
mesh=[]
for stl in sorted((ROOT/'cad').glob('*.stl')):
 m=trimesh.load(stl)
 mesh.append({'part':stl.name,'watertight':bool(m.is_watertight),'bounds_mm':m.bounds.round(4).tolist(),
              'solid_volume_cm3':float(m.volume/1000),
              'approx_PETG_mass_at_1_27_g_cm3_FULLY_SOLID_g':float(m.volume/1000*1.27)})
geometry={'motor_centers_mm':[[x,y] for x in (-105,105) for y in (-105,105)],
 'prop_diameter_mm':127,'motor_adjacent_axis_separation_mm':210,
 'adjacent_prop_clearance_mm':210-127,'motor_diagonal_separation_mm':math.hypot(210,210),
 'approx_flat_foot_span_mm':370,'prop_center_plane_z_mm':42,'foot_plane_z_mm':-98,
 'nominal_prop_to_foot_vertical_distance_mm':140,
 'physical_hardware_status':'UNBUILT; geometry is parametric design only',
 'mesh_validation':mesh,'thrust_example_NOT_MEASURED':thrust_budget(650,350),
 'calibration_example_NOT_MEASURED':calibration(100,.2,1000,2)}
(OUT/'mechanical_math_and_mesh_validation.json').write_text(json.dumps(geometry,indent=2))
print(json.dumps({'digital_crop_experiment':{k:base[k] for k in ('accepted_frame_count','rejected_pair_count','panorama_shape_hw_px','neuron_spikes','node_count_final','vs_original_photo_truth_mean_absolute_encoded_8bit_difference')},
                  'compressed_video_decode':{k:vid[k] for k in ('accepted_frame_count','rejected_pair_count','panorama_shape_hw_px','neuron_spikes','node_count_final')},
                  'meshes_watertight':{x['part']:x['watertight'] for x in mesh}},indent=2))
