from pathlib import Path
import hashlib
import numpy as np
import cv2
import pytest
from src.spider_scan import calibration,thrust_budget,estimate_translation,mosaic_frames,NodePool
from legacy.ripple_optical_agent import RippleNeuron
ROOT=Path(__file__).resolve().parents[1]

def image():
    return cv2.imread(str(ROOT/'fixtures/archived_photo_NOT_DRONE.png'))

def moving(n=14,shift=8):
    src=image()
    assert src is not None
    # Crops of an archived REAL PHOTOGRAPH; camera motion is NOT real.
    src=cv2.resize(src,(900,600))
    return [src[80:320,30+i*shift:350+i*shift].copy() for i in range(n)]

def test_locked_core_source_hash():
    x=hashlib.sha256((ROOT/'legacy/ripple_optical_agent.py').read_bytes()).hexdigest()
    assert x=='7f2f611cd8f1717c3d3dcae745dbd41efc37e24315d93878231db52eaf614f77'

def test_original_neuron_drive():
    n=RippleNeuron();result=n.step((.5,.2,.1),.05)
    assert result['drive']==pytest.approx(1.1)

def test_calibration_uncertainty():
    r=calibration(100.,.2,1000.,2.)
    assert r['local_scale_mm_per_pixel']==pytest.approx(.1)
    assert r['equivalent_local_dpi']==pytest.approx(254.)
    assert r['scale_std_uncertainty_mm_per_pixel']==pytest.approx(.1*(.002**2+.002**2)**.5)

def test_calibration_invalid():
    with pytest.raises(ValueError):calibration(0,0,10,1)

def test_thrust_not_feasibility_without_input():
    r=thrust_budget(650,350)
    assert r['static_thrust_weight_ratio']==pytest.approx(1400/650)
    assert r['meets_arbitrary_design_threshold']
    assert not thrust_budget(850,350)['meets_arbitrary_design_threshold']

def test_flow_from_real_photo_software_shift():
    x=moving(2,8)
    f,stats=estimate_translation(*x)
    assert stats['inliers']>14
    assert f is not None
    assert f[0]==pytest.approx(-8,abs=.3)
    assert f[1]==pytest.approx(0,abs=.3)

def test_mosaic_coverage_and_pixel_fidelity(tmp_path):
    frames=moving()
    res=mosaic_frames(frames,20,tmp_path,source_label='SYNTHETIC_CROP_MOTION_NOT_DRONE')
    pano=cv2.imread(str(tmp_path/'panorama.png'))
    assert res['accepted_frame_count']==len(frames)
    assert res['rejected_pair_count']==0
    assert 400<=pano.shape[1]<=440
    assert pano.shape[0]==240
    # Result compared with the stationary same original photo crop; nonlinear edge/rounding mismatch.
    base=cv2.resize(image(),(900,600))[80:320,30:30+pano.shape[1]]
    err=np.abs(pano.astype(float)-base.astype(float)).mean()
    assert err<2.0

def test_zero_texture_is_rejected(tmp_path):
    blank=np.full((160,160,3),120,np.uint8)
    p,s=estimate_translation(blank,blank)
    assert p is None
    r=mosaic_frames([blank,blank],20,tmp_path)
    assert r['rejected_pair_count']==1

def test_pool_scales_and_limits():
    p=NodePool(2,8,40)
    for t in range(4):p.update(310,t)
    assert len(p.nodes)==8
    for t in range(7):p.update(0,t+10)
    assert len(p.nodes)==2

def test_pool_does_not_change_neuron_constants():
    pool=NodePool()
    assert pool.nodes[0].theta==pytest.approx(.45)
    assert all(x.tau_v==pytest.approx(.5) for x in pool.nodes)

def test_no_pose_for_rotation_fixture():
    a=moving(1)[0]
    h,w=a.shape[:2]
    b=cv2.warpAffine(a,cv2.getRotationMatrix2D((w/2,h/2),8,1),(w,h))
    pose,info=estimate_translation(a,b)
    assert pose is None

def test_reject_bad_frame_shapes(tmp_path):
    x=moving(2)
    with pytest.raises(ValueError):mosaic_frames([x[0],x[1][:100]],20,tmp_path)


def test_scanner_video_same_scene_comparator(tmp_path):
    from legacy.sensor_bridge_v0_2 import scanner_measure
    src=ROOT/'results/reference_truth_region.png'
    obs=ROOT/'results/digital_crops/panorama.png'
    r=scanner_measure(src,obs,tmp_path,alignment=False)
    assert r['mean_absolute_pixel_error_8bit']==pytest.approx(0)

