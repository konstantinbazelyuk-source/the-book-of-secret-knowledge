// Ripple SpiderScan v0.3 - DIMENSIONAL MECHANICAL CONCEPT, NOT FLIGHT QUALIFIED
// All units mm. OpenSCAD 2021.01. CC0-1.0. User chooses PART at command line.
// This is a fit-check and ground-bench mockup. Reference rotor arms are NOT
// printable flight-grade beams. Flight requires certified/tested carbon frame,
// rotor guard, motor thrust measurement, vibration tests, aircraft integration.
PART = "assembly"; // assembly, spider_deck, scan_pod, leg_socket, rotor_envelope
$fn = 48;
motor_xy=105;            // x,y are +/-105 mm, quad diagonal = 296.985 mm
prop_radius=63.5;       // proposed 5-inch prop, 127 mm diameter
rotor_plane_z=42;       // conceptual prop disc center plane
scan_pod_z=-27;
foot_radius=185;
foot_z=-98;
body_length=90;
body_width=78;
deck_thickness=3;

module disk3d(x,y,z,r) {translate([x,y,z]) cylinder(h=0.7,r=r,center=true);}
module capsule(p,q,r) {
    v=q-p;
    translate(p) rotate(a=acos(v[2]/norm(v)),v=[-v[1],v[0],0]) cylinder(h=norm(v),r=r);
}
module slot_2d(len=13,width=3) {hull(){translate([-(len-width)/2,0]) circle(d=width);translate([(len-width)/2,0]) circle(d=width);}}
module spider_deck(){
    difference(){
        linear_extrude(height=deck_thickness,center=true)
            offset(r=6) square([body_length-12,body_width-12],center=true);
        // common generic 30.5 mm square mounting matrix. Verify real FC interface.
        for(x=[-15.25,15.25],y=[-15.25,15.25])
            translate([x,y,0]) cylinder(h=12,d=3.3,center=true);
        // 8 strap slots to fix carbon legs. Positions, not flight-rated mount points.
        for(a=[0:45:315]) rotate([0,0,a]) for(y=[-4.6,4.6])
            translate([36,y,0]) linear_extrude(height=12,center=true) slot_2d(10,2.8);
    }
}
module scan_pod(){
    difference(){
        union(){
            cube([58,58,4],center=true);
            for(x=[-24,24],y=[-24,24]) translate([x,y,4]) cylinder(d=7,h=8,center=true);
        }
        cylinder(d=25,h=20,center=true);  // Unspecified lens clearance
        // Strap slots, NOT claimed camera hole pattern
        for(x=[-21,21]) for(y=[-11,11])
            translate([x,y,0]) cube([3,11,15],center=true);
    }
}
module leg_socket(){
    // Two 4.2 mm rod bores through short socket block, for nonstructural ground mockup.
    difference(){
        hull(){translate([-9,0,0])sphere(r=5.5);translate([9,0,0])sphere(r=5.5);}
        translate([-9,0,0]) rotate([0,90,0]) cylinder(d=4.2,h=12,center=true);
        translate([9,0,0]) rotate([0,90,0]) cylinder(d=4.2,h=12,center=true);
    }
}
module spider_legs(){
    for(a=[0:45:315]) {
        p=[34*cos(a),34*sin(a),-8];
        k=[99*cos(a),99*sin(a),-48];
        f=[foot_radius*cos(a),foot_radius*sin(a),foot_z];
        color("#273E4E") capsule(p,k,2.1);
        color("#273E4E") capsule(k,f,2.1);
        color("#C77843") translate(k) sphere(r=5);
        color("#264C63") translate(f) sphere(r=6);
    }
}
module structure_reference(){
    for(x=[-motor_xy,motor_xy],y=[-motor_xy,motor_xy]){
       color("#4E5F69") capsule([0,0,3],[x,y,30],6); // schematic ONLY
       color("#606C72") translate([x,y,32]) cylinder(d=28,h=14,center=true);
       color([.22,.72,.81,.14]) disk3d(x,y,rotor_plane_z,prop_radius);
       color([.23,.70,.83,.85]) translate([x,y,rotor_plane_z])
            difference(){cylinder(h=1.2,r=prop_radius,center=true);cylinder(h=2,r=prop_radius-.8,center=true);}
    }
}
module assembly(){
    structure_reference();
    color("#DCE1E5") spider_deck();
    translate([0,0,scan_pod_z]) color("#D3884B") scan_pod();
    color("#4F6E82") spider_legs();
    // abstract O4 radio/camera volume above deck, not screw mounting design
    color("#2B3940") translate([0,0,15]) cube([30,30,6],center=true);
    // GS 38x38 board envelope only, not actual mount pattern
    color("#2A3C56") translate([0,0,scan_pod_z+7]) cube([38,38,3],center=true);
}
if(PART=="assembly")assembly();
else if(PART=="spider_deck")spider_deck();
else if(PART=="scan_pod")scan_pod();
else if(PART=="leg_socket")leg_socket();
else if(PART=="rotor_envelope")structure_reference();
else assert(false,"Unknown PART");
