# Ripple SpiderScan v0.3 — engineering research prototype

**Provenance:** an additive development of Ripple Sensor Bridge v0.2 and Ripple Neuron v0.1. 2026-10-13. **Status: executable, tested image/video-processing software and parametric ground-fit CAD; NO physical spider aircraft or scanner instrument was built, flown, calibrated or electrically measured.**

**License:** New original software/graphics/CAD are CC0-1.0. Archived test image comes from the earlier Ripple project's credited `scikit-image.data.astronaut()` public-domain sample; it is NOT a drone image. Any brand names denote real candidate components, not endorsement or product integration.

## What is engineered

A *spider-shaped sensor aircraft* concept with four independent propeller locations and **eight passive (non-walking) landing legs**, plus two intentionally separate cameras:

1. **DJI O4 Air Unit (standard):** FPV pilot video/radio, approximate camera-included unit mass 8.2 g *before* lens mount, antennas, cables. DJI says Betaflight 4.3+ is supported. DJI O4 itself has no compatible DJI mobile/onboard SDK for arbitrary live raw frames and is NOT a software dependency of our sensor application. DJI camera video may be analyzed after local media export; no claim of live O4-to-Pi pixel interface.
2. **Raspberry Pi Global Shutter Camera, Sony IMX296:** 1.6 MP, 34 g camera board (without adapter/dust cap); a **separate, downward** machine-vision camera for ground texture imaging and mosaicking. Connects by CSI to a compatible host; particular CSI connector/cable/power arrangement must be validated for the chosen Pi model. An optional controllable LED lamp could stabilize illumination once mounted and tested, but this iteration contains no built LED synchronizer.
3. **Separate flight controller:** a properly designed and configured FC controls motor safety and flight. **Ripple does not command motors** in this version. Never bypass manufacturer or ArduPilot/Betaflight arming/failsafe policies. A flight-ready platform requires measured propulsion, battery, wiring, radio and structural calculations and separate hover tests.
4. **Ripple observing computer:** ingests recording or native GS camera frames (camera live acquisition NOT implemented), computes a translational photomosaic and feeds regional image measurements into independent unchanged Ripple neurons. Its logs are algorithmic events, not evidence of intelligence.

## Read-only software that actually runs

`src/spider_scan.py`: frame-to-frame tracked corner motion using OpenCV pyramidal Lucas–Kanade, two-way flow consistency and RANSAC geometric fit; explicit quality gates on inliers, rotation, scale and residual error. If frame geometry fails, that frame is not projected into the mosaic or fed to Ripple. If another frame is later accepted, registration is computed relative to the **last accepted frame**, not an untrusted rejected frame. The accepted views are stacked into a mosaic by estimated integer-pixel translations and averaged where they overlap (encoded 8-bit channels). This is a **scanner-like accumulated image, not a flatbed-quality spectrometer**.

- *Drone imagery:* software estimates **scene displacement in image pixels**. Under the pure-translation/planar hypothesis, the camera offset is **minus** the scene feature motion, which allows approximate stitching. It cannot infer world coordinates, altitude or camera motion in meters without intrinsics, 3D scene geometry and calibration. A change in camera orientation, scale or nonplanar parallax may invalidate the output despite heuristics.
- *Scanner fusion:* instead of an electric motor moving a scanner carriage, each successive stable camera exposure is a new spatial strip/field of view; software registers overlapping optical measurements into a scan/mosaic.
- *Ripple:* the existing neuron source is kept **byte-for-byte** in `legacy/ripple_optical_agent.py` with hash `7f2f611cd8f1717c3d3dcae745dbd41efc37e24315d93878231db52eaf614f77`. Input is average **encoded RGB** in vertical regions, divided by 255; not linear light intensity or instantaneous optical field amplitude. Each region has a separate initial state and feedback threshold. Region count can rise from 2 to 8 after 3 consecutive high-load intervals, and contract after 6 low-load intervals. These are logical neurons in ONE process, **not CPU threads**, a large language model, trainable intelligence, autonomy or quantum hardware.
- *Output:* `panorama.png`, `coverage.png`, `motion_trace.json`, `neuron_trace.json`, `summary.json`. All remain local.

### Setup (Python 3.10+)

From this directory:

```bash
python -m pip install -r requirements.txt
python -m pytest tests -q
python -m src.spider_scan scan-video --video fixtures/synthetic_camera_translation_NOT_DRONE.mp4 --output results/my_test --scale 1 --max-frames 20
```

To analyze an **original, verified DJI file** from a supported decoder:

```bash
python -m src.spider_scan scan-video --video /path/to/DJI_0001.MP4 --output results/my_actual_dji_video --scale 0.5 --max-frames 90
```

**Do not imply that this experiment flew a drone.** The software reads files only. It is not wired to DJI control. By design, the video is processed after recording. The actual camera model, shooting height, lens profile, variable-frame timing, rolling shutter, GSD and spatial error must be recorded and checked. Default quality thresholds are experimental, not guaranteed safe for aerial surveying. Command refuses >2048 px frames without user-selected downsizing; 50 MP panorama allocation limit.

### Flatbed scanner versus drone mosaic (two digital sources, one comparator)

Both sources must show **the same planar target**, with physically recorded lighting, lens/distortion and color-management metadata. Comparison results are encoded-pixel errors only; if imagery differs in scale or perspective, image alignment can fail. The following *included* example has already been aligned because it uses the same archived photo; thus `--no-alignment` is appropriate only for this fixture:

```bash
python -m src.spider_scan compare-images \
  --reference results/reference_truth_region.png \
  --observed results/decoded_video/panorama.png \
  --output results/my_reference_comparison --no-alignment
```

Use the older flatbed calibration chart and comparator from v0.2 for a real print/scan sequence. **No user scanner or physical drone has been measured here.**

### How to obtain a physical-distance calibration (once you have a real target)

Measure a target length **L** in mm with uncertainty **sigmaL**, find its separation **n** in image pixels with uncertainty **sigman**, then calculate `s=L/n` mm per pixel and the approximate independent uncertainty `sigma_s=s*sqrt((sigmaL/L)^2+(sigman/n)^2)`. This is valid only at the calibrated plane/depth; the view must not be tilted or distorted without correction.

```bash
python -m src.spider_scan calibrate --length-mm 100 --sigma-mm 0.2 --pixels 1000 --sigma-px 2
```

The example numbers are **made-up calculation inputs** and not measured apparatus: calculated local scale **0.1000 ± 0.000283 mm/pixel**, equivalent to 254 dpi at the calibrated plane. A flying camera does not automatically deliver scanner DPI; optical resolution depends on lens, focus, distance, pixel sampling and motion blur.

### Flight feasibility, not flight authorization

A preliminary necessary thrust condition is `(motor_count * measured_static_thrust_in_gram_force) > weighed_all_up_mass_g`. The example asks for a configurable 2.0:1 thrust/weight ratio as a **design goal**, not a certification standard. No selected motor/prop/battery combination has been tested:

```bash
python -m src.spider_scan thrust --mass-g 650 --per-motor-gf 350
```

Result: `1400/650 = 2.1538` **only if** 650 g is a truly weighed complete aircraft and 350 gf is an actual measured motor+prop+battery bench thrust under matching conditions. The values are illustrative, not measured. Controlled hover cannot be inferred from thrust ratio alone: CG, inertia, flight controller gains, cooling, rotor clearance, prop guards, airflow and vibration remain unproven.

## Mechanical design, not production-ready flight structure

- Parametric model: `cad/SpiderScan_parametric.scad`. Render `PART="assembly"` for all 8 passive carbon rod legs, 4 conceptual rotor envelopes and the lower scanning camera. OpenSCAD reference arms/disk rings are only a *drawing*, not designed structural booms or moving propellers.
- Exported 3 watertight ground mockup STLs: `cad/spider_deck_GROUNDMOCKUP.stl`, `cad/scan_pod_CAMERA_FITCHECK.stl`, and `cad/leg_socket_GROUNDMOCKUP.stl`. The CAD tray assumes only a 38 × 38 mm **board envelope**; it **does not claim to match vendor mounting holes**, lens spacing or fastener torque. Dry fit first; the surface must avoid CSI ribbon bending/interference. The mockup deck 30.5 mm hole pattern is a generic assumed pattern — verify actual flight stack.
- 4 motor axes at `(±105,±105)` mm -> 210 mm between adjacent motors; 5-inch proposed rotor diameter = 127 mm; adjacent swept-disk-to-swept-disk gap = **83 mm** in ideal horizontal geometry. Opposite diagonal motor-to-motor separation = `210*sqrt(2)=296.985 mm`.
- Legs: eight radial, non-actuated carbon-rod approximations from 34 mm radial origin to 99 mm knee to 185 mm foot radius. Nominal foot-to-foot span = **370 mm**. Rotor conceptual plane `z=+42 mm`, foot center `z=-98 mm`, 140 mm separation in height. The ends are below propeller disks; aerodynamic interference, leg flex and ground contact are **NOT** certified. Mount spider legs only on a physically approved frame after mass and ground-clearance tests.
- Ground-mockup CAD watertight manifold geometry validation is in `results/mechanical_math_and_mesh_validation.json`. **Full-density PETG calculated theoretical weights from solid geometry are neither measured print weights nor flightworthy evidence.** Printed density, infill and print process affect actual mass and strength.
- Recommended manufacturing sequence: print **fit-check** parts in PETG or equivalent, mount the **unpowered** camera module mockup with a soft strap, mark exact connector/cable tolerances, measure weights, test any optical reading on a bench before selecting production structure. Use a flight-rated carbon frame, approved compliant attachment method and manufacturer-specific mount specs if pursuing the aerial version. Don't use mockup STLs as primary structural flight arms.

## Demonstration measurements — strictly labeled

`build_results.py` reconstructs a sequence of 20 camera views by cropping the **same archived public-domain photographic pixel array** with 8-pixel x-position increments and **no physical camera motion**. It mosaics these frames and computes digital error relative to the uncropped archived pixel array.

The software fixture produced a recovered **240 × 472 pixel** panorama from 20 overlapping 320 × 240 frames, **0.0 mean absolute encoded-pixel difference** to its original unaltered photograph (integer cropping and exact-sampled offsets), **18 neuron events**, **8 final logical nodes**. Exact-match on such a synthetic sequence is a deterministic sanity test, **not real-camera accuracy**. Compressed MP4 frames are separately decoded and processed, with documented lossy codec variation expected and testable.

The same final panorama processed after MP4 compression showed **2.8291 mean absolute encoded-pixel counts** against the uncompressed archive (the video filename and original photo are in `results/`). This is an image-file measurement of lossy video output, **not scanner accuracy**. A **direct comparison** running the preserved v0.2 scanner comparator produced the same 2.8291 counts when supplied exact aligned photo and generated video mosaic, demonstrating that both data paths can use a common comparator.

The final test suite has **13 passing tests**. Automated tests include: locked source hash, core drive, scale uncertainty formula, invalid calibration, thrust conditional ratio, bidirectional optical flow on known software displacement, panorama overlap reconstruction, blank scene rejected, node growth/shrinkage, original constants, rotation rejection and frame size rejection. Some sample parameters and acceptance bands are **proposed algorithms**, not experimentally optimized.

## Evidence boundaries and next tests

**Measured on supplied digital files:** encoded-pixel differences, tracked image feature displacement, mosaic overlap size/coverage, measured count of software events and STL mesh geometry. **Calculated under named assumptions:** rotor spacing, thrust ratios given hypothetical inputs, local sample pitch given example target, mesh solid volume. **Simulated/created from source files:** digital viewpoint shifts and MP4 video fixture. **Proposed/unvalidated:** mechanical fit to a specific carbon frame, balanced flight with spider legs, real lighting calibration, payload weight, DJI FPV/recording interoperability with selected airframe, direct GS camera acquisition, synchronized illumination, laser/EM or quantum measurements, any autonomous action, neural task learning.

Physical study sequence: (1) measure printed CAD & camera+computer physical envelope with calipers and scales, (2) capture repeatable actual camera views of a manually moved high-contrast planar chart on the bench, (3) measure target displacement and uncertainty, (4) integrate a documented FC after independent mechanical/electrical/payload tests, (5) flight only with appropriate guards, authorized pilot and regulatory compliance. For US operations, FAA registration and Remote ID apply to aircraft that must be registered; business operation is governed by appropriate regulations. Check actual requirements and location before testing outdoors.

### Existing-source continuity

This package adds a new module. It does **not replace** Ripple Sensor Bridge v0.2, its scanner calibration-chart PDF, Linux SANE acquisition tool, DJI-file flow adapter, or the original Ripple v0.1 core. Source file is preserved verbatim. The old scanner tool can still be run separately; its scanner image comparisons are not magically converted to calibrated optical-field sensing.

## Primary engineering references

- DJI O4 Air Unit spec sheet / hardware compatibility: https://www.dji.com/o4-air-unit/specs ; https://www.dji.com/support/product/o4-air-unit
- DJI hardware/SDK compatibility: https://repair.dji.com/help/content?customId=01700000763&documentType=&lang=en&paperDocType=ARTICLE&re=US&spaceId=17
- Raspberry Pi GS camera vendor spec: https://www.raspberrypi.com/products/raspberry-pi-global-shutter-camera/
- Raspberry Pi camera hardware notes: https://www.raspberrypi.com/documentation/accessories/camera.html
- OpenCV: https://docs.opencv.org/4.x/d4/dee/tutorial_optical_flow.html
- ArduPilot pre-arm checks: https://ardupilot.org/copter/docs/common-prearm-safety-checks.html
- US FAA registration and Remote ID: https://www.faa.gov/uas/getting_started/register_drone

**Open engineering offer:** Share the complete ZIP publicly with this README and the filenames showing fixtures are synthetic. Do not advertise as a working flying robot until actual flight and measurements exist.
