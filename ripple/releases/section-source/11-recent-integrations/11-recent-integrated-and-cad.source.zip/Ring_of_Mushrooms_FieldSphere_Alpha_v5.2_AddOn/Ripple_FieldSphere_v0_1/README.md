# Ripple FieldSphere v0.1 — Open Magnetic + Optical Research Rig

**Free, modifiable, open engineering package** — CAD (OpenSCAD, STLs), Pico MicroPython source, computer-side Python acquisition/analysis, numerical Biot–Savart coil model, demonstration data clearly marked as simulation, validation protocols, BOM and safety limitations. [MIT License](LICENSE). Third-party chips, vendor libraries, trademarks, and datasheets retain their own terms.

**Real physics, no imaginary sensor claims.** This rig uses eight currently available LIS2MDL magnetometer boards at the corners of a cube **inscribed inside a spherical measurement radius of 155.88 mm**, attached by curved 3D-printed rails; optionally four diametric red LED/OPT101 pairs provide independent optical obstruction/intensity channels. No laser is supplied in v0.1. This is an 8-site vector magnetometer array, **not a dense 3D scan, medical device, optical magnetometer, or aura detector**. The photodiodes measure light, not the magnetic component of an optical wave.

![CAD-based mechanical and sensor alignment diagram](docs/assembly_diagram.png)

![SIMULATED results, not measurements](docs/simulated_vector_readout.png)

## Engineering readiness

| Item | Status |
|---|---|
| Selected components checked against vendor documents | Verified online (citations in engineering notes) |
| Physics model: circular coil, Biot–Savart + cross-check | Tested numerically |
| 8-node geometry, OpenSCAD printable models | Generated and geometry-checkable |
| Host software, synthetic negative/positive coil control | Tests executable |
| Sensor firmware on actual Pico | **NOT hardware-tested** |
| Actual 3D printer physical fit | **NOT validated** |
| Real magnetic or optical readings | **NONE** |

## Files
- `cad/fieldsphere.scad` — edit dimensions, set `part` in the OpenSCAD UI and render/export. 
- `cad/stl/` — manufacture eight handed hubs, three of each four curved rail variants, optional optical sleeves, coil bobbin and caddies.
- `docs/BUILD_AND_VALIDATION.md` — full wiring, assembly locations, coil testing and calculations.
- `docs/BOM.csv` — sourced parts and **budgetary**, not quoted, prices.
- `firmware/main.py` — Pico real-only data acquisition, refuses silent sensor omission.
- `host/fieldsphere.py` — simulated reference data, numerical model, plot and physical JSONL analysis.
- `host/capture_serial.py` — live serial recording (install `pyserial`), with operator-entered measured coil states.
- `host/orientation_template.json` — **NOT A REAL CALIBRATION**. Each sensor axis must be measured before any vector field comparison.
- `tests/test_fieldsphere.py` — automated code checks.

## Try it on a computer, without equipment
```bash
python -m pip install numpy matplotlib
python -m unittest discover -s tests -v
python host/fieldsphere.py simulate --output data/synthetic_coil_run.jsonl
python host/fieldsphere.py analyze --input data/synthetic_coil_run.jsonl --output docs/simulated_vector_readout.png
```

Output has explicit `kind: simulated` labels and no fake sensors. A nominal 100-turn, 25mm effective radius coil at 0.2 A is predicted to yield approximately 1.48 µT at each nominal probe site. This is a **calculated** test quantity, not a demonstrated sensitivity.

## What it does and does not do
- YES: design for measuring magnetic flux density [µT] as 8 discrete x/y/z vectors, with field reversal test controls.
- YES: independent LED optical transmission/intensity at 4 diametric paths [relative ADC voltage], if optional electronics installed.
- YES: visualize magnetic probe locations and signal readings; compare properly calibrated reversed-current measurements with physics model.
- NO: infer static-field values where no sensor exists; monitor microwave/gamma frequencies; detect EEG theta/beta/gamma; directly measure magnetic component of visible light; identify spiritual auras; or assert intelligence.

## Roadmap (not in v0.1)
1. Physically calibrate sensor die positions, offsets, board axes; measure noise and optical crosstalk.
2. Add proper shielded linear polarization/Faraday-effect optics if magneto-optical detection is desired; ordinary crossing laser beams are insufficient.
3. More probe locations + optical high-speed coherent/heterodyne instrumentation only after accurate field comparison benchmarks; separate data units and provenance.

### Open-use statement
Anyone may manufacture, copy, modify, share, or commercially implement **our original files under the MIT license** provided the copyright and permission notices accompany substantial copies. This is a disclosure of an engineering design, not an assertion of novelty, patent freedom, regulatory certification, or measured hardware accuracy. **Publishing the ZIP here is not the same as publicly deploying it on a code-hosting site.**
