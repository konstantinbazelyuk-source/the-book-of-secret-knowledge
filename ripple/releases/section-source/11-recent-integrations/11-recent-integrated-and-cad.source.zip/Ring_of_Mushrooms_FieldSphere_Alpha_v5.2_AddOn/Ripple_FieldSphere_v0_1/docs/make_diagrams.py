"""Mechanical line diagram from exact CAD centerline math; not a photo or claimed measurement."""
from pathlib import Path
import itertools, numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D # noqa
here=Path(__file__).parent
N=90.; t=np.linspace(-87.5,87.5,140)
def sgn(x):return '+' if x>0 else '-'
def crown(v):
 q=np.maximum(0,np.minimum(1,(75-np.abs(v))/75))
 return 20.227*(3*q*q-2*q*q*q)
fig=plt.figure(figsize=(11,8),facecolor='#f7f9fc')
ax=fig.add_subplot(111,projection='3d')
for y,z in itertools.product([-1,1],repeat=2):
 ax.plot(t, y*(N+crown(t)),z*(N+crown(t)),color='#546b88',linewidth=7,solid_capstyle='round',alpha=.9)
for x,z in itertools.product([-1,1],repeat=2):
 ax.plot(x*(N+crown(t)),t,z*(N+crown(t)),color='#546b88',linewidth=7,solid_capstyle='round',alpha=.9)
for x,y in itertools.product([-1,1],repeat=2):
 ax.plot(x*(N+crown(t)),y*(N+crown(t)),t,color='#546b88',linewidth=7,solid_capstyle='round',alpha=.9)
verts=np.array(list(itertools.product([-1,1],repeat=3)),float)*N
ax.scatter(*verts.T,c='#ffba52',edgecolor='#c47716',s=550,depthshade=True,zorder=10)
for i,p in enumerate(verts):
 ax.text(*(p+np.array([0.,0.,13.])),str(i),fontsize=11,weight='bold',color='#14324e')
for sgn_y,sgn_z in itertools.product([-1,1],repeat=2):
 p=np.array([90,90*sgn_y,90*sgn_z]);q=-p
 ax.plot(*np.column_stack((p,q)),color='#d74c49',linestyle=':',linewidth=2,alpha=.55)
ax.scatter([0],[0],[0],marker='o',s=260,edgecolor='#165b33',facecolor='#a2deb8',label='Reference coil at center')
ax.set(xlabel='X [mm]',ylabel='Y [mm]',zlabel='Z [mm]')
ax.set_box_aspect([1,1,1]);ax.set_xlim(-135,135);ax.set_ylim(-135,135);ax.set_zlim(-135,135)
ax.view_init(elev=22,azim=34)
ax.grid(alpha=.25)
ax.set_title('Ripple FieldSphere v0.1 — CAD-derived assembly geometry\n8 sensor hubs · 12 curved printable rails · 4 optical diagonals',fontsize=16,pad=22)
fig.text(.13,.08,'Hubs: magnetic sensor sites  |  Dotted paths: OPTIONAL LED transmission (not magnetic sensing)\nR = 155.885 mm (nominal hub centers); electronics boards must be located/calibrated separately.\nEngineering diagram, NOT a photograph or laboratory measurement.',fontsize=10,color='#333b46')
fig.savefig(here/'assembly_diagram.png',dpi=160,facecolor=fig.get_facecolor(),bbox_inches='tight');plt.close(fig)
# 2D wiring overview with clear distinction of channels
fig,ax=plt.subplots(figsize=(11.5,5.5));ax.axis('off');ax.set_xlim(0,12);ax.set_ylim(0,5.7)
def block(x,y,w,h,label,fc):
 import matplotlib.patches as patches
 ax.add_patch(patches.FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.16',fc=fc,ec='#516170',lw=1.2))
 ax.text(x+w/2,y+h/2,label,ha='center',va='center',fontsize=11,weight='bold')
def arr(x,y,x2,y2,txt=None):
 ax.annotate('',xy=(x2,y2),xytext=(x,y),arrowprops={'arrowstyle':'->','color':'#4a627a','lw':2})
 if txt:ax.text((x+x2)/2,(y+y2)/2+.12,txt,fontsize=9,ha='center')
block(.25,2.0,2.05,1.1,'Raspberry Pi Pico\nUSB serial', '#e6f0ff')
block(4.0,3.55,2.35,.9,'PCA9548A\n8 I²C channels','#e2f5e7')
block(7.95,3.55,3.25,.9,'8 × LIS2MDL 3-axis\nMagnetic B [µT]','#dbf3e5')
block(4.0,.85,2.35,.9,'ADS1115 ADC\n4 analogue inputs','#fff0da')
block(7.95,.85,3.25,.9,'4 × OPT101 receiver\nOptical delta [V]','#ffead0')
block(4.0,2.25,2.35,.55,'4 × red LEDs\nGPIO10–13','#fff3e3')
arr(2.45,2.95,3.9,4.0,'I²C SDA/SCL')
arr(6.55,4.0,7.8,4.0)
arr(2.45,2.25,3.9,1.25,'I²C SDA/SCL')
arr(6.55,1.25,7.8,1.25)
arr(2.45,2.55,3.9,2.55,'GPIO')
ax.text(6.85,2.5,'LED light → photodiodes\n(no optical magnetic effect assumed)',ha='center',fontsize=9)
fig.suptitle('Hardware wiring architecture · source: engineered design (not physically tested)',fontsize=15)
fig.savefig(here/'wiring_architecture.png',dpi=160,bbox_inches='tight');plt.close(fig)
print('Created diagrams')
