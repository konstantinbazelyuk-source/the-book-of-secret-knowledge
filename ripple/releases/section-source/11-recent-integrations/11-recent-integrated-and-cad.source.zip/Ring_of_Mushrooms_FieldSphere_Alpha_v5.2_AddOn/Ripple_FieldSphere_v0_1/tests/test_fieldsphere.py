import sys, unittest, tempfile, json
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'host'))
from fieldsphere import (POSITIONS_MM,VERTEX_LABELS,expected_vertices_uT,dipole_b,
                         loop_biot_savart_numeric,synth_records,parse_jsonl,
                         coil_measurement,summary,plot_scan)
class TestFieldSphere(unittest.TestCase):
    def test_eight_positions(self):
        self.assertEqual(POSITIONS_MM.shape,(8,3))
        self.assertEqual(len(set(VERTEX_LABELS)),8)
        self.assertTrue(np.allclose(np.linalg.norm(POSITIONS_MM,axis=1),90*np.sqrt(3)))
    def test_field_antisymmetry(self):
        p=np.array([.09,.09,.09]);a=loop_biot_savart_numeric(p)
        b=loop_biot_savart_numeric(-p)
        self.assertTrue(np.allclose(a,b,rtol=1e-11)) # symmetric B for +/- opposite side
    def test_current_linearity(self):
        one=expected_vertices_uT(.1);two=expected_vertices_uT(.2)
        self.assertTrue(np.allclose(2*one,two))
    def test_loop_agrees_with_dipole_at_far_distance(self):
        p=np.array([.9,.9,.9]);exact=loop_biot_savart_numeric(p)
        approx=dipole_b(p)
        self.assertLess(np.linalg.norm(exact-approx)/np.linalg.norm(exact),.002)
    def test_synthetic_coil_sign(self):
        rows=synth_records(n=50,seed=7)
        r=coil_measurement(rows)
        self.assertLess(r['rms_error_uT'],.11)
    def test_synthetic_labels(self):
        rows=synth_records(n=2)
        self.assertTrue(all(r['kind']=='simulated' for r in rows))
    def test_static_bias_reject(self):
        rows=synth_records(n=80)
        r=coil_measurement(rows)
        self.assertLess(r['rms_error_uT'],.11)
    def test_broken_record_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            fn=Path(td)/'bad.jsonl';fn.write_text('{"mag_uT":[null,null]}\n')
            with self.assertRaises(ValueError):parse_jsonl(fn)
    def test_valid_jsonl(self):
        with tempfile.TemporaryDirectory() as td:
            fn=Path(td)/'good.jsonl';records=synth_records(1)
            fn.write_text('\n'.join(map(json.dumps,records))+'\n')
            self.assertEqual(len(parse_jsonl(fn)),3)
    def test_summary(self):
        s=summary(synth_records(3))
        self.assertEqual(s['mean_uT'].shape,(8,3))
    def test_plot(self):
        with tempfile.TemporaryDirectory() as td:
            fn=Path(td)/'viz.png'
            plot_scan(synth_records(3),fn)
            self.assertGreater(fn.stat().st_size,10000)
    def test_coil_state_check(self):
        with self.assertRaises(ValueError):coil_measurement(synth_records(2)[:2])
if __name__=='__main__':unittest.main()
