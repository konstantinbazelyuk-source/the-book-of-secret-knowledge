"""Capture explicit hardware data with coil-state labels set by the operator.
Dependencies: python -m pip install pyserial
Run: python capture_serial.py --port /dev/ttyACM0 --state zero --seconds 10 --output my_log.jsonl
Then repeat with --state plus and --state minus into SAME output.
"""
import argparse, json, time
from pathlib import Path

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--port',required=True)
    p.add_argument('--baud',type=int,default=115200)
    p.add_argument('--seconds',type=float,default=10)
    p.add_argument('--output',required=True)
    p.add_argument('--state',choices=['zero','plus','minus'],required=True)
    p.add_argument('--current-a',type=float,default=.2)
    args=p.parse_args()
    try: import serial
    except ImportError: raise SystemExit('Install pyserial with pip first')
    collected=0
    with serial.Serial(args.port,args.baud,timeout=1) as dev,open(args.output,'a',encoding='utf8') as fp:
        stop=time.monotonic()+args.seconds
        while time.monotonic()<stop:
            msg=dev.readline().decode('utf8','replace').strip()
            if not msg or msg.startswith('#'):continue
            try: row=json.loads(msg)
            except json.JSONDecodeError: continue
            if row.get('kind')!='hardware' or len(row.get('mag_uT',[]))!=8:continue
            # Annotate ONLY the operator-reported applied coil state.
            row['coil_state']=args.state
            row['coil_current_A']={'plus':args.current_a,'minus':-args.current_a,'zero':0}[args.state]
            row['host_wall_time_ns']=time.time_ns()
            row['acquisition_provenance']='serial_hardware_unverified_by_software'
            fp.write(json.dumps(row)+'\n');fp.flush();collected+=1
    print('Wrote',collected,'reported hardware rows to',args.output)
if __name__=='__main__':main()
