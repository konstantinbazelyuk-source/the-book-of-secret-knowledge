"""Ripple FieldSphere host reference implementation. No sensor data invented.
Usage: python fieldsphere.py simulate --output data/synthetic.jsonl
       python fieldsphere.py analyze --input data/synthetic.jsonl --output docs/synthetic_scan.png
       python fieldsphere.py analyze --input live_capture.jsonl --output live_plot.png
Only points at sensor sites are actual samples; all glyphs are vector measurements
(or explicitly simulation). NOT tomography and NOT aura detection.
"""
import argparse, itertools, json, math
from pathlib import Path
import numpy as np

MU0=4*math.pi*1e-7
R_NODE_MM=90.0
POSITIONS_MM=np.array(list(itertools.product([-R_NODE_MM,R_NODE_MM],repeat=3)),dtype=float)
VERTEX_LABELS=[''.join('p' if v>0 else 'm' for v in p) for p in POSITIONS_MM]


def loop_biot_savart_numeric(point_m, radius_m=.025, turns=100, ampere=.2, segments=4096):
    """Direct numerical integral for N circular turns normal to +X axis.
    Coil centered at origin, points in Y-Z plane. Accurate away from wire.
    """
    t=(np.arange(segments)+.5)*(2*math.pi/segments)
    ct,st=np.cos(t),np.sin(t)
    path=np.column_stack((np.zeros_like(t),radius_m*ct,radius_m*st))
    dl=np.column_stack((np.zeros_like(t),-radius_m*st,radius_m*ct)) * (2*math.pi/segments)
    diff=np.asarray(point_m,dtype=float)-path
    norm=np.linalg.norm(diff,axis=1)
    if np.min(norm)<1e-6:
        raise ValueError('point too close to conductor')
    field=np.sum(np.cross(dl,diff)/norm[:,None]**3,axis=0)
    return MU0/(4*math.pi)*turns*ampere*field # T


def dipole_b(point_m,radius_m=.025,turns=100,ampere=.2):
    """Far-field approximation only; used as independent cross-check."""
    r=np.asarray(point_m,dtype=float)
    norm=np.linalg.norm(r)
    if norm==0: raise ValueError('dipole undefined at origin')
    moment=np.array([turns*ampere*math.pi*radius_m**2,0.,0.])
    return MU0/(4*math.pi*norm**3)*(3*np.dot(moment,r/norm)*(r/norm)-moment)


def expected_vertices_uT(current_a=.2,turns=100,radius_m=.025,segments=2048):
    return np.asarray([loop_biot_savart_numeric(p/1000,radius_m,turns,current_a,segments)*1e6
                       for p in POSITIONS_MM])


def synth_records(n=21,seed=64,coil_current=.2):
    """Synthetic ONLY. Simulates baseline, +current, -current, no measurements."""
    rng=np.random.default_rng(seed)
    truth=expected_vertices_uT(coil_current)
    background=np.tile(np.array([19.,-32.,41.]),(8,1))
    node_bias=rng.normal(0,.3,size=(8,3))
    rows=[]
    for kind,current_sign in [('zero',0),('plus',1),('minus',-1)]:
        for j in range(n):
            data=background+node_bias+truth*current_sign+rng.normal(0,.30,(8,3))
            rows.append({'t_ms':len(rows)*125,'kind':'simulated',
                         'coil_state':kind,'coil_current_A':coil_current*current_sign,
                         'mag_uT':(np.rint(data/0.15)*0.15).round(3).tolist(),
                         'optical_delta_V':None})
    return rows


def parse_jsonl(path):
    result=[]
    for line_no,line in enumerate(Path(path).read_text().splitlines(),1):
        if not line.strip() or line.lstrip().startswith('#'):continue
        try: obj=json.loads(line)
        except Exception as exc:raise ValueError('invalid JSON line %d: %s'%(line_no,exc))
        if 'mag_uT' not in obj or len(obj['mag_uT'])!=8:
            raise ValueError('line %d needs eight magnetometer entries' %line_no)
        if any(x is None or len(x)!=3 or not all(np.isfinite(x)) for x in obj['mag_uT']):
            raise ValueError('line %d contains missing/nonfinite sensor(s)'%line_no)
        result.append(obj)
    if not result:raise ValueError('no valid frames')
    return result


def summary(records):
    data=np.array([x['mag_uT'] for x in records],float)
    med=np.median(data,axis=0)
    mean=np.mean(data,axis=0)
    sd=np.std(data,axis=0,ddof=1) if len(records)>1 else np.zeros((8,3))
    return {'samples':len(records),'mean_uT':mean,'median_uT':med,'sd_uT':sd}


def coil_measurement(records, current_a=.2):
    """Physical reversal control: (mean(+I)-mean(-I))/2 to suppress static offsets.
    Not valid if the ambient field drifts during the test.
    """
    plus=[r for r in records if r.get('coil_state')=='plus']
    minus=[r for r in records if r.get('coil_state')=='minus']
    if not plus or not minus: raise ValueError('requires plus and minus coil_state groups')
    p=summary(plus)['mean_uT'];m=summary(minus)['mean_uT']
    measured=(p-m)/2
    predicted=expected_vertices_uT(current_a)
    error=measured-predicted
    return {'measured_uT':measured,'predicted_uT':predicted,
            'error_uT':error,'rms_error_uT':float(np.sqrt(np.mean(error**2)))}


def orient_records(records, matrices):
    """Convert each board-local vector into common global XYZ using measured
    board orientation; matrices map global_B = M @ local_B.
    This does NOT correct hard-iron/soft-iron bias or scale.
    """
    mats=np.asarray(matrices,dtype=float)
    if mats.shape!=(8,3,3):raise ValueError('orientations must be 8 x 3 x 3')
    for i,m in enumerate(mats):
        if not np.allclose(m.T@m,np.eye(3),atol=1e-5) or not np.isclose(np.linalg.det(m),1,atol=1e-5):
            raise ValueError('node %d transform must be proper orthogonal rotation'%i)
    out=[]
    for r in records:
        item=dict(r)
        item['mag_uT']=(np.einsum('nij,nj->ni',mats,np.array(r['mag_uT'],float))).tolist()
        item['orientation']='board to global frame applied; bias calibration still required'
        out.append(item)
    return out


def plot_scan(records,path,global_frame=False):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from mpl_toolkits.mplot3d import Axes3D # noqa
    s=summary(records)
    data=s['mean_uT']; mag=np.linalg.norm(data,axis=1)
    fig=plt.figure(figsize=(11,6),constrained_layout=True)
    ax=fig.add_subplot(121,projection='3d')
    ax.scatter(*POSITIONS_MM.T,c=mag,s=80,cmap='viridis',vmin=0)
    # Normalize glyph lengths; vector values printed as nT/uT separately.
    norms=np.linalg.norm(data,axis=1)
    if global_frame:
        unit=data/np.maximum(norms[:,None],1e-15)
        ax.quiver(POSITIONS_MM[:,0],POSITIONS_MM[:,1],POSITIONS_MM[:,2],
                  unit[:,0],unit[:,1],unit[:,2],length=22,color='#1679a9',normalize=False)
    for p,l in zip(POSITIONS_MM,VERTEX_LABELS):ax.text(*p,l,fontsize=7)
    ax.set(xlabel='X (mm)',ylabel='Y (mm)',zlabel='Z (mm)',
           title='Sample sites only'+(' — oriented XYZ arrows' if global_frame else ' — directions NOT calibrated'))
    ax.set_box_aspect((1,1,1))
    ax2=fig.add_subplot(122)
    ax2.errorbar(np.arange(8),mag,yerr=np.linalg.norm(s['sd_uT'],axis=1),fmt='o',capsize=3)
    ax2.set_xticks(np.arange(8),VERTEX_LABELS)
    ax2.set(ylabel='|B| (µT)',xlabel='Sensor location',title='Per-probe magnitude, 1σ temporal scatter')
    ax2.grid(alpha=.25)
    kinds={r.get('kind','unspecified') for r in records}
    fig.suptitle('Ripple FieldSphere v0.1 — '+(','.join(sorted(kinds))).upper())
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    fig.savefig(path,dpi=160);plt.close(fig)


def main():
    parser=argparse.ArgumentParser(description='Ripple FieldSphere 8-vector-sensor analyzer')
    subs=parser.add_subparsers(dest='cmd',required=True)
    sim=subs.add_parser('simulate');sim.add_argument('--output',required=True)
    an=subs.add_parser('analyze');an.add_argument('--input',required=True);an.add_argument('--output',required=True)
    an.add_argument('--coil-current-a',type=float,default=.2)
    an.add_argument('--orientation-json',help='8 measured 3x3 local-to-global rotation matrices')
    args=parser.parse_args()
    if args.cmd=='simulate':
        records=synth_records();Path(args.output).parent.mkdir(parents=True,exist_ok=True)
        Path(args.output).write_text('\n'.join(json.dumps(x) for x in records)+'\n')
        print('SIMULATED records:',len(records),'saved:',args.output)
    else:
        records=parse_jsonl(args.input)
        print('Input kinds:',sorted(set(r.get('kind','unknown') for r in records)))
        if any(r.get('kind')=='simulated' for r in records):
            print('WARNING: SIMULATION, NOT REAL MAGNETIC FIELD MEASUREMENTS')
        print('Samples:',len(records))
        simulated=all(r.get('kind')=='simulated' for r in records)
        calibrated=simulated or bool(args.orientation_json)
        if args.orientation_json:
            with open(args.orientation_json) as f: matrices=json.load(f)['rotation_local_to_global']
            records=orient_records(records,matrices)
        plot_scan(records,args.output,global_frame=calibrated)
        if {r.get('coil_state') for r in records}.issuperset({'plus','minus'}):
            if calibrated:
                result=coil_measurement(records,args.coil_current_a)
                print('Coil reversal RMS error vs ideal current-loop model: %.4f uT'%result['rms_error_uT'])
                print('Predicted mean vector magnitude: %.3f uT'%np.mean(np.linalg.norm(result['predicted_uT'],axis=1)))
            else:
                print('UNALIGNED BOARD AXES: coil direction-model comparison is disabled.')
        print('Plot saved:',args.output)
if __name__=='__main__':main()
