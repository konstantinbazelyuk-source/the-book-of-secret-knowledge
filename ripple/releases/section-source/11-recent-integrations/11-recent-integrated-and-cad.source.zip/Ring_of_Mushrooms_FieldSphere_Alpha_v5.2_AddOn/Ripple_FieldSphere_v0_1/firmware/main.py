"""Ripple FieldSphere Pico MicroPython v0.1. REAL-sensor only.
8 LIS2MDL devices behind one PCA9548A/TCA9548A; 4 analog OPT101 receivers
optionally via ADS1115. No optical readings are fabricated when ADC absent.
No lasers: GPIO outputs drive CURRENT-LIMITED ordinary visible LEDs only.
"""
from machine import Pin, I2C
import time, json, struct

I2C_HZ = 100_000     # conservative bus for long cables
MUX = 0x70
MAG = 0x1E
ADS = 0x48
LED_PINS = [10, 11, 12, 13]
ALLOW_PARTIAL = False  # fail closed if any expected magnetometer is absent
SAMPLE_INTERVAL_MS = 125  # nominal <=8 complete scans/second, NOT simultaneous

bus = I2C(0, sda=Pin(4), scl=Pin(5), freq=I2C_HZ)
leds = [Pin(g, Pin.OUT, value=0) for g in LED_PINS]

def mux(ch):
    bus.writeto(MUX, bytes((1 << ch,)))

def mag_read_reg(addr, n=1):
    return bus.readfrom_mem(MAG, addr, n)

def init_mags():
    found = []
    for ch in range(8):
        try:
            mux(ch)
            who = mag_read_reg(0x4F)[0]
            if who != 0x40:
                raise ValueError('WHO_AM_I=0x%02x expected 0x40' % who)
            # Continuous mode, temp compensation, 50Hz output (0x80|0x08).
            # Bit 4 LP=0 => high-resolution mode; CTRL C BDU=1.
            bus.writeto_mem(MAG, 0x60, b'\x88')
            bus.writeto_mem(MAG, 0x62, b'\x10')
            found.append(ch)
        except Exception as e:
            print('# sensor channel %d ERROR: %s' % (ch, str(e)))
    mux(0)
    if len(found) != 8 and not ALLOW_PARTIAL:
        raise RuntimeError('%d/8 sensors found, refusing incomplete map' % len(found))
    return found

def read_mag(ch):
    mux(ch)
    # 6 sequential little-endian signed 16-bit bytes from OUTX_L_REG
    data = mag_read_reg(0x68, 6)
    raw = struct.unpack('<hhh', data)
    return [round(value * 0.15, 4) for value in raw]  # microtesla

def ads_read_voltage(chan):
    # ADS1115 single ended MUX=100..111, gain +/-4.096V, 860sps single shot.
    config = 0x8000 | ((4+chan) << 12) | 0x0200 | 0x0100 | 0x00E0 | 0x0003
    bus.writeto_mem(ADS, 0x01, struct.pack('>H', config))
    time.sleep_ms(3)
    raw = struct.unpack('>h', bus.readfrom_mem(ADS, 0x00, 2))[0]
    return round(raw * 4.096 / 32768.0, 6)

def run():
    if MUX not in bus.scan():
        raise RuntimeError('I2C 0x70 mux missing')
    found = init_mags()
    # Deselect magnetometers before checking ADS address.
    bus.writeto(MUX, b'\x00')
    has_adc = ADS in bus.scan()
    if not has_adc:
        print('# ADS1115 missing: optical channels reported as null')
    print('# Ripple FieldSphere v0.1; optics are LED/photodiode, not laser magnetometry')
    print('# IMPORTANT: sequential sensor acquisition; timestamp per scan, not simultaneous')
    while True:
        t0 = time.ticks_ms()
        mags = [None] * 8
        for ch in found:
            mags[ch] = read_mag(ch)
        # Capture optical difference with each emitter driven individually.
        # Do optical measurement AFTER magnetic reading to reduce source interference.
        # Simple DC intensity gates: not optical carrier/heterodyne detection.
        optical = None
        if has_adc:
            optical = []
            bus.writeto(MUX, b'\x00')
            for i, led in enumerate(leds):
                dark = ads_read_voltage(i)
                led.on()
                time.sleep_ms(2)
                bright = ads_read_voltage(i)
                led.off()
                optical.append(round(bright - dark, 6))
        record = {'t_ms':t0,'kind':'hardware', 'mag_uT':mags,
                  'optical_delta_V':optical,
                  'optical_kind':'LED intensity (not magnetic)'}
        print(json.dumps(record))
        elapsed = time.ticks_diff(time.ticks_ms(), t0)
        if elapsed < SAMPLE_INTERVAL_MS:
            time.sleep_ms(SAMPLE_INTERVAL_MS-elapsed)

if __name__ == '__main__':
    try:
        run()
    finally:
        for led in leds: led.off()
