# Ring of Mushrooms v5.1 — verified software to real-device pathways

## Exact scope

This release **retains all files from v5.0 byte-for-byte** and adds `workstation`, a Windows/Linux Tk desktop interface, native Android CameraX sensor-client **source**, a USB loopback transport, actual SQLite data storage, a real EDF reader, research runners, tests, and a manually triggerable GitHub Actions workflow.

The 216 inherited neurons and 8 specialist regions run via `ring.core.Ring.step` on actual decoded frames. On Android, the camera **acquires and sends** frames; the full model is on the Dell host, NOT on the phone. SDK, hardware and installer gates are separately documented.

## Desktop start, actual controls

Install Python 3.11/3.12, optionally Node.js 20+ for inherited modules, unzip, run **START_WINDOWS.bat** on Dell Windows or `./START_LINUX.sh` on supported Linux desktop.

- **Start webcam** requests OpenCV camera device index 0, submits decoded BGR frames to the real Ring and writes a row per processed frame in SQLite. If no device exists, it errors; no fake frame substituted.
- **Record webcam** enables an explicit disk AVI + associated host-monotonic timestamp archive, in addition to Ring processing. **Stop webcam** releases camera and finalizes recording.
- **Analyze video** decodes an existing AVI/MP4 and processes up to 120 frames through the same Ring.
- **Inspect EEG EDF** reads an actual file with MNE; requires EEG channels and valid acquisition timing. Produces log-band-power values with units but no inferred psychological state.
- **Fuse synced data** invokes the existing Ring v5 fusion engine on video/EEG files **only if genuine paired clock anchors are supplied**. Rejects invalid synchronization; no synthetic substitutes.
- **Android USB link** opens a localhost-only token-protected JPEG receiver; it runs the same `Ring.step` and records source as *remote client claim*.
- **Export CSV** extracts recorded timestamps, hashes, spike counts and phase values from SQLite.
- **Save Ring state** writes an authenticated-by-checksum (accidental-corruption detection), bounded, pickle-free state checkpoint. **Restore Ring** verifies inherited source SHA-256 and exact session database row continuity and reproduces the next neuron dynamics. Stop acquisition before saving or restoring.

## Android device

See `android_client/README.md`; requires Android Studio SDK 35, Java 17/Gradle 8.9, `adb` and real camera hardware. On Dell, run `python -m workstation.app --serve-phone`, enter its printed token in the phone, and execute `adb reverse tcp:8789 tcp:8789` over USB before **Start Camera**. USB bridge always binds **127.0.0.1** and rejects unauthenticated JPEGs. Local loopback traffic over adb reverse only; do not expose TCP 8789 on public or Wi-Fi interfaces. The Android project is buildable source **not a verified installable APK in this session**.

## Verifying the inherited & new engine

```
python -m pip install -r requirements_v51.txt
python -m unittest discover -s tests_workstation -v
python -m unittest discover -s tests -q
python -m unittest discover -s tests_v5 -q
python -m workstation.app --diagnose
python -m workstation.app --video results_v5/synthetic_sync_fixture/simulated_camera.avi --frames 60 --db results_v51/test_recording.sqlite
python -m workstation.research --permutations 50 --out results_v51/real_eeg_unique_holdouts.json
python -m workstation.ablation --video results_v5/synthetic_sync_fixture/simulated_camera.avi --replicates 50 --out results_v51/ablation_50.json
```

## Evidence as of this packaged session

- **Executed:** 26 new workstation tests, 24 inherited v5 tests, 45 inherited v4 tests. New tests exercised actual OpenCV decoder and HTTP bridge requests, real Ring integration, SQLite, errors and authentication.
- **Executed:** 60 decoded frames from an explicitly **synthetic** archived video into Ring+SQLite. This is executable I/O testing, **not physical camera validation**.
- **Calculated from published human data:** 20 derived EEG recordings, 5 subject groups, 10 unique two-subject leave-pair-out comparisons. Spectral logistic classifier 0.55; Ring coupled and disconnected 0.475 mean balanced accuracy. Within-subject 50-permutation exploratory null p-values: 0.216 and 0.725. These are exploratory, not independent subjects or evidence of clinical efficacy.
- **Executed simulation-only ablation:** 50 seeds on **the same** 24-frame synthetic video, coupled model spikes exceeded uncoupled by exactly 15 for every tested seed. This reflects algorithmic causality, *not improved comprehension*. Evidence stored in `results_v51/ablation_50.json`.
- **Not executed:** physically connected Dell/Samsung camera tests; BrainFlow EEG device; clock synchronization against independent hardware; Android SDK/Gradle APK build; Windows portable `.exe` build; cloud GitHub Actions workflow. This session does not have access to those devices or a configured CI runner.

## Scientific priorities

1. Verify Samsung CameraX RGBA-to-JPEG channel color using calibrated RGB targets. Verify capture timestamps and 4Hz bound on device, USB link, SQLite activity, app permission/stop behavior.
2. Connect and calibrate Dell webcam; record auto-exposure, frame jitter/dropouts and driver behavior, then test continuous operation.
3. Verify physical EEG with device-specific BrainFlow acquisition. Create **shared measured trigger anchors** to fuse with camera; data timestamps alone do not certify physiological synchronization.
4. Train + evaluate with a substantially larger independently labeled EEG dataset and disjoint subjects; compare Ring features against simple PSD baselines and ablate coupling.
5. Execute the included GitHub workflow to produce APK and portable Windows app; run installation and device thermal/battery tests and resolve build errors.

## Sources

- Android CameraX frame format, callbacks and backpressure: https://developer.android.com/media/camera/camerax/analyze
- OpenCV VideoCapture and backend-dependent controls: https://docs.opencv.org/4.x/d8/dfe/classcv_1_1VideoCapture.html
- MNE EDF file and annotations: https://mne.tools/stable/generated/mne.io.read_raw_edf.html
- BrainFlow boards and data acquisition: https://brainflow.readthedocs.io/en/stable/UserAPI.html
- Published original MILimbEEG derived subset: https://github.com/Human-Machine-Interface/OpenBCI_Classification_Example
- Existing original v5 references in `README.md` and `README_V4_UNMODIFIED.md`.

## Persistence validation

The workstation creates a unique SQLite session ID for each new run. A state checkpoint saves 216 neuron states, internal synapses, active/idle masks, pending delayed spike messages, phases, ring weights, histories, RNG state, and exact previous pixels. The test compares subsequent spikes, phase state, delivered pulses, and ring weights against uninterrupted execution. A mismatched SQLite log, changed parent source, and corrupted state are rejected. File checksums protect accidental corruption, not adversarial tampering. Restored monotonic timestamps are valid only within a compatible host monotonic-clock epoch.


## FieldSphere v5.2 hardware magnetic input

[See WORKSTATION_FIELDSPHERE_V52.md](WORKSTATION_FIELDSPHERE_V52.md) for actual serial controls, 50-pair causal ablation, physical calibration requirements, and the preserved original FieldSphere v0.1 manufacturing rig.
