"""FieldSphere -> Ring v5.2: working eight-probe magneto-optical input.

Sensor units: magnetic flux density in microtesla (uT), optical LED
intensity difference in volt (V), software neuron conductances dimensionless.
Only actual source records are accepted; no synthetic fallback. The provenance
provided by a serial transport is not an independent physical attestation.
"""
from __future__ import annotations
from collections import deque
from dataclasses import dataclass
import json, math, threading, time
from pathlib import Path
import numpy as np

N_PROBES=8
POSITIONS_M=np.asarray([[a*.09,b*.09,c*.09] for a in (-1,1) for b in (-1,1) for c in (-1,1)],float)

@dataclass(frozen=True)
class SphereSample:
    mag_uT:np.ndarray
    optical_delta_V:np.ndarray|None
    t_ms:int
    kind:str
    host_monotonic_s:float|None
    coil_state:str|None=None
    def __post_init__(self):
        if self.mag_uT.shape!=(8,3) or not np.isfinite(self.mag_uT).all():raise ValueError('all eight 3-axis magnetometers required')
        if (np.abs(self.mag_uT)>5000).any():raise ValueError('magnetometer magnitude exceeds configured 5000 uT range')
        if self.optical_delta_V is not None and (self.optical_delta_V.shape!=(4,) or not np.isfinite(self.optical_delta_V).all() or (np.abs(self.optical_delta_V)>4.096).any()):
            raise ValueError('optical delta must contain four finite volt values within ±4.096V')
        if self.kind not in ('hardware','simulated'):raise ValueError('explicit record provenance required')
        if not isinstance(self.t_ms,int) or self.t_ms<0:raise ValueError('nonnegative firmware timestamp required')
        if self.host_monotonic_s is not None and not math.isfinite(self.host_monotonic_s):raise ValueError('host monotonic timestamp must be finite')
        if self.coil_state not in (None,'zero','plus','minus'):raise ValueError('invalid coil state')
    @classmethod
    def from_dict(cls,row,*,received_monotonic_s=None):
        if not isinstance(row,dict):raise ValueError('FieldSphere JSON object required')
        try:
            mag=np.asarray(row['mag_uT'],dtype=float)
            optical=None if row.get('optical_delta_V') is None else np.asarray(row['optical_delta_V'],dtype=float)
            timestamp=row['t_ms']
            if type(timestamp) is not int:raise ValueError('integer millisecond timestamp required')
            return cls(mag,optical,timestamp,str(row['kind']),received_monotonic_s,row.get('coil_state'))
        except (KeyError,TypeError,OverflowError) as exc:raise ValueError('invalid FieldSphere sample: '+str(exc)) from exc

class SphereCalibration:
    """Baseline subtraction; optional measured XYZ rotations and hard/soft iron correction.
    Norm-only anomaly does not require local/global XYZ registration but is
    affected by sensor bias/scale and is NOT an estimate of field geometry.
    """
    def __init__(self,baseline_samples:list[SphereSample]):
        if not baseline_samples:raise ValueError('explicit zero-state baseline required')
        if any(s.coil_state!='zero' for s in baseline_samples):raise ValueError('baseline must be labeled coil_state=zero')
        if len({s.kind for s in baseline_samples})!=1:raise ValueError('cannot mix simulated and hardware baselines')
        self.kind=baseline_samples[0].kind
        self.mag=np.median(np.stack([s.mag_uT for s in baseline_samples]),axis=0)
        opt=[s.optical_delta_V for s in baseline_samples if s.optical_delta_V is not None]
        self.optical=None if not opt else np.median(np.stack(opt),axis=0)
        self.samples=len(baseline_samples)
    def anomalies(self,s:SphereSample):
        if self.kind!=s.kind:raise ValueError('sample/baseline provenance mismatch')
        # A signed difference between scalar field magnitudes, preserving sign.
        # Each difference compares one sensor against its OWN zero baseline.
        scalar=np.linalg.norm(s.mag_uT,axis=1)-np.linalg.norm(self.mag,axis=1)
        optical=None if s.optical_delta_V is None or self.optical is None else s.optical_delta_V-self.optical
        return scalar,optical

class RegisteredVectors:
    """Optional real-measurement local->global transform + finite-site gradient.
    Must be provided calibrated rotation matrices. No inferred 3D tomography.
    """
    def __init__(self,rotation,hard_iron_uT,soft_iron_matrix,*,measured:bool):
        if measured is not True:raise ValueError('measured calibration evidence required')
        r=np.asarray(rotation,float);h=np.asarray(hard_iron_uT,float);a=np.asarray(soft_iron_matrix,float)
        if r.shape!=(8,3,3) or h.shape!=(8,3) or a.shape!=(8,3,3):raise ValueError('expected 8 calibrated 3D probe frames')
        if not all(np.isfinite(v).all() for v in [r,h,a]):raise ValueError('nonfinite calibration')
        for m in r:
            if not np.allclose(m.T@m,np.eye(3),atol=1e-4) or not np.isclose(np.linalg.det(m),1,atol=1e-4):
                raise ValueError('orientation must be proper rotation')
        for m in a:
            if np.linalg.cond(m)>100:raise ValueError('ill-conditioned soft iron calibration')
        self.rotation=r;self.offset=h;self.soft=a
    @classmethod
    def load(cls,path):
        d=json.loads(Path(path).read_text())
        return cls(d['rotation_local_to_global'],d['hard_iron_uT'],d['soft_iron_matrix'],measured=d.get('measured',False))
    def transform(self,s:SphereSample):
        # Right-handed XYZ at each measured probe location.
        return np.einsum('nij,njk,nk->ni',self.rotation,self.soft,s.mag_uT-self.offset)
    def finite_site_gradient(self,s:SphereSample):
        y=self.transform(s)
        x=np.column_stack((np.ones(8),POSITIONS_M))
        coefficients=np.linalg.lstsq(x,y,rcond=None)[0] # rows [B0, dB/dx, dB/dy, dB/dz]
        predicted=x@coefficients
        gradient=coefficients[1:,:].T
        return {'center_uT':coefficients[0].tolist(),
                'gradient_uT_per_m':gradient.tolist(),
                'divergence_uT_per_m':float(np.trace(gradient)),
                'rms_site_residual_uT':float(np.sqrt(np.mean((predicted-y)**2))),
                'sites':8,'interpretation':'least-squares local linear gradient at measured sites, not spatial tomography'}

class SphereRingBridge:
    """Inject scalar probe changes into eight distinct real Charlie conductance states.
    Optical receivers (when physically supplied) go to separate nodes in luminance
    and shadow colonies; no LED voltage -> RGB or EEG semantic conversion.
    """
    def __init__(self,calibration:SphereCalibration,*,threshold_uT=.08,scale_uT=1.,max_exc=1.5,
                 optical_scale_v=.10,max_stale_s=.35,enabled=True,registered_vectors:RegisteredVectors|None=None):
        if not 0<=threshold_uT<=5 or not .01<=scale_uT<=100 or not 0<max_exc<=3 or not .001<=optical_scale_v<=3 or not .01<=max_stale_s<=5:
            raise ValueError('invalid bounded FieldSphere parameters')
        self.calibration=calibration;self.threshold_uT=threshold_uT;self.scale_uT=scale_uT
        self.max_exc=max_exc;self.optical_scale_v=optical_scale_v;self.max_stale_s=max_stale_s
        self.enabled=enabled;self.last=None;self.registered_vectors=registered_vectors
    def inject(self,ring,s:SphereSample,*,frame_time_s=None):
        if frame_time_s is not None:
            if s.host_monotonic_s is None:raise ValueError('live acquisition needs host timestamp')
            age=frame_time_s-s.host_monotonic_s
            if age < -0.015 or age>self.max_stale_s:raise ValueError('stale or future FieldSphere sample')
        delta,optical=self.calibration.anomalies(s)
        if not self.enabled:return {'enabled':False,'magnetic_delta_uT':delta.tolist(),'optical_delta_V':None if optical is None else optical.tolist(),'applied_conductance':0.0,'kind':s.kind}
        magnitude=np.sign(delta)*np.maximum(0,np.abs(delta)-self.threshold_uT)
        units=self.max_exc*np.tanh(magnitude/self.scale_uT)
        applied=[]
        for idx,pulse in enumerate(units):
            target=ring.children[idx].neurons[13]
            if pulse>=0:target.exc=min(target.params.max_synaptic_conductance,target.exc+float(pulse))
            else:target.inh=min(target.params.max_synaptic_conductance,target.inh-float(pulse))
            applied.append(float(pulse))
        # Four actual optional photodiode channels, independent of camera RGB and letter code.
        optical_applied=[]
        if optical is not None:
            for i,volt in enumerate(optical):
                colony=5 if i<2 else 6
                neuron=12 if i%2==0 else 14
                target=ring.children[colony].neurons[neuron]
                pulse=float(self.max_exc*np.tanh(volt/self.optical_scale_v))
                if pulse>=0:target.exc=min(target.params.max_synaptic_conductance,target.exc+pulse)
                else:target.inh=min(target.params.max_synaptic_conductance,target.inh-pulse)
                optical_applied.append(pulse)
        self.last={'enabled':True,'kind':s.kind,'baseline_samples':self.calibration.samples,
                   'magnetic_delta_uT':delta.round(6).tolist(),
                   'optical_delta_V':None if optical is None else optical.round(7).tolist(),
                   'applied_conductance':applied,'optical_applied':optical_applied,
                   't_ms':s.t_ms,'host_monotonic_s':s.host_monotonic_s,
                   'spatial_fit':None if self.registered_vectors is None else self.registered_vectors.finite_site_gradient(s)}
        return self.last

class SphereStream:
    """Thread-safe live serial acquisition and strict host monotonic clock handling."""
    def __init__(self,limit=1024):
        if not 8<=limit<=100000:raise ValueError('stream bounds')
        self.samples=deque(maxlen=limit);self.lock=threading.RLock();self.kind=None
        self.accepted=0;self.rejected=0;self._last_t_ms=None
    def ingest(self,row,*,host_monotonic_s=None):
        s=SphereSample.from_dict(row,received_monotonic_s=host_monotonic_s)
        with self.lock:
            if self.kind is not None and self.kind!=s.kind:raise ValueError('cannot interleave simulated and hardware streams')
            if self._last_t_ms is not None and s.t_ms<=self._last_t_ms:
                # Explicitly fail on reset/wrap; caller must start new session.
                raise ValueError('firmware time reset/wrap/out-of-order: start a new sensor session')
            self.samples.append(s);self._last_t_ms=s.t_ms;self.kind=s.kind;self.accepted+=1
        return s
    def nearest_past(self,frame_time_s,*,max_age_s=.35):
        with self.lock:
            for s in reversed(self.samples):
                if s.host_monotonic_s is not None and s.host_monotonic_s<=frame_time_s+.015:
                    age=frame_time_s-s.host_monotonic_s
                    if -.015<=age<=max_age_s:return s
                    break
        return None
    def zero_samples(self,min_count=3):
        with self.lock:return [s for s in self.samples if s.coil_state=='zero'][-max(min_count,3):]

class SerialSphereReader:
    def __init__(self,stream:SphereStream,port,*,baud=115200,state='unlabeled'):
        if state not in ('unlabeled','zero','plus','minus'):raise ValueError('invalid coil state')
        self.stream=stream;self.port=port;self.baud=baud;self.state=state
        self.stopping=threading.Event();self.thread=None;self.error=None
    def start(self):
        import serial # optional dependency, NEVER simulated if unavailable
        self.dev=serial.Serial(self.port,self.baud,timeout=.3)
        self.thread=threading.Thread(target=self._loop,daemon=True);self.thread.start()
    def _loop(self):
        try:
            while not self.stopping.is_set():
                line=self.dev.readline()
                if not line or line.lstrip().startswith(b'#'):continue
                try:
                    row=json.loads(line.decode('utf-8'))
                    if row.get('kind')!='hardware':raise ValueError('serial line not hardware-tagged')
                    if self.state!='unlabeled':row['coil_state']=self.state
                    self.stream.ingest(row,host_monotonic_s=time.monotonic())
                except (UnicodeError,ValueError,KeyError,TypeError) as exc:
                    self.stream.rejected+=1;self.error=str(exc)
        finally:self.dev.close()
    def close(self):
        self.stopping.set()
        if self.thread:self.thread.join(2)
        if self.thread and self.thread.is_alive():raise TimeoutError('serial sensor reader did not stop')

def read_jsonl(path):
    out=[]
    for no,line in enumerate(Path(path).read_text().splitlines(),1):
        if not line.strip() or line.lstrip().startswith('#'):continue
        try:out.append(SphereSample.from_dict(json.loads(line)))
        except Exception as exc:raise ValueError(f'FieldSphere JSONL line {no}: {exc}') from exc
    if not out:raise ValueError('empty FieldSphere file')
    if len({r.kind for r in out})!=1:raise ValueError('mixed synthetic/hardware file prohibited')
    if any(a.t_ms>=b.t_ms for a,b in zip(out,out[1:])):raise ValueError('non-monotonic FieldSphere samples')
    return out
