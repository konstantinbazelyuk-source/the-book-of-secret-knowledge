"""Mushroom v5.1: real acquisition -> inherited 216-neuron Ring -> durable SQLite.
No frame substitution, no camera mock except explicit test injection. Sensor provenance is
claimed by source and verified only at physical device testing.
"""
from __future__ import annotations
import dataclasses, hashlib, json, queue, sqlite3, threading, time, uuid
from pathlib import Path
import cv2
import numpy as np
from ring.core import Ring, RingParameters
from .fieldsphere import SphereStream, SphereRingBridge, SphereSample

@dataclasses.dataclass(frozen=True)
class FramePacket:
    bgr: np.ndarray
    acquired_monotonic_s: float
    source: str
    device_monotonic_ns: int | None = None
    def __post_init__(self):
        if self.source not in ('usb_camera','android_usb_bridge','video_file'):
            raise ValueError('explicit supported source required')
        if self.bgr.dtype!=np.uint8 or self.bgr.ndim!=3 or self.bgr.shape[2]!=3 or min(self.bgr.shape[:2])<24:
            raise ValueError('uint8 BGR camera frame >=24x24 required')
        if not np.isfinite(self.acquired_monotonic_s):raise ValueError('finite timestamp required')
        if self.device_monotonic_ns is not None and not (0<=self.device_monotonic_ns<2**63):raise ValueError('invalid device monotonic timestamp')

class Workstation:
    def __init__(self, db_path, *, fps=15, slider=.65, recurrent=True, seed=101, qsize=3):
        if not 8<=fps<=30: raise ValueError('bounded FPS 8..30')
        self.ring=Ring(RingParameters(fps=fps,slider=slider,recurrent=recurrent),seed=seed)
        self.session_id=str(uuid.uuid4())
        self.db_path=Path(db_path);self.db_path.parent.mkdir(parents=True,exist_ok=True)
        self.db=sqlite3.connect(self.db_path,check_same_thread=False)
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('CREATE TABLE IF NOT EXISTS observations (id INTEGER PRIMARY KEY, session_id TEXT NOT NULL, monotonic_s REAL NOT NULL, source TEXT NOT NULL, frame_sha256 TEXT NOT NULL, device_monotonic_ns INTEGER, frame_w INTEGER NOT NULL, frame_h INTEGER NOT NULL, elapsed_ms REAL NOT NULL, spikes INTEGER NOT NULL, phase_order REAL NOT NULL, data_json TEXT NOT NULL)')
        self.db.commit()
        self.queue=queue.Queue(maxsize=qsize);self.stop=threading.Event();self.lock=threading.RLock()
        self.thread=None;self.stats={'session_id':self.session_id,'submitted':0,'processed':0,'dropped':0,'failed':0,'last_error':None,'mean_processing_ms':None,'source':'unavailable','last':None}
        self._last_time=None;self._last_shape=None
        self.sphere_stream=None;self.sphere_bridge=None

    def submit(self,pkt:FramePacket):
        if self.stop.is_set(): raise RuntimeError('workstation stopped')
        with self.lock:
            self.stats['submitted']+=1
        try:self.queue.put_nowait(pkt)
        except queue.Full:
            try:self.queue.get_nowait();self.queue.task_done()
            except queue.Empty:pass
            with self.lock:self.stats['dropped']+=1
            self.queue.put_nowait(pkt)

    def configure_fieldsphere(self,stream:SphereStream,bridge:SphereRingBridge):
        with self.lock:
            if stream.kind is not None and stream.kind!=bridge.calibration.kind:
                raise ValueError("live stream/baseline provenance mismatch")
            self.sphere_stream=stream;self.sphere_bridge=bridge

    def disable_fieldsphere(self):
        with self.lock:self.sphere_stream=None;self.sphere_bridge=None

    def process(self,pkt:FramePacket, *, sphere_sample:SphereSample|None=None):
        """Synchronous proven computation. Worker uses this; tests call it directly."""
        with self.lock:
            if self._last_time is not None and pkt.acquired_monotonic_s<=self._last_time:
                raise ValueError('nonincreasing frame timestamps rejected')
            if self._last_shape is not None and pkt.bgr.shape!=self._last_shape:
                raise ValueError('camera resolution changed during session')
            begin=time.perf_counter()
            # Incoming frames are optical signals; Ring's physical_camera flag is a software
            # data classification, not independent authentication of a remote source.
            if sphere_sample is not None and self.sphere_bridge is None:
                raise ValueError('FieldSphere calibration must be configured before using a record')
            selected=sphere_sample
            if selected is None and self.sphere_stream is not None and self.sphere_bridge is not None:
                selected=self.sphere_stream.nearest_past(pkt.acquired_monotonic_s,max_age_s=self.sphere_bridge.max_stale_s)
            field_report=None
            if selected is not None:
                # For offline paired simulation we allow caller-provided records;
                # for live streams, verify host receive-time freshness.
                live_time=pkt.acquired_monotonic_s if sphere_sample is None else None
                field_report=self.sphere_bridge.inject(self.ring,selected,frame_time_s=live_time)
            rec=self.ring.step(pkt.bgr,source_type='physical_camera' if pkt.source!='video_file' else 'decoded_video')
            # Source/provenance audit: inputs logged and never remapped to RGB.
            rec['fieldsphere']={'state':'applied' if field_report and field_report.get('enabled') else
                                         ('disabled' if field_report else 'absent_or_stale'),
                                 'report':field_report,
                                 'raw':None if selected is None else {'mag_uT':selected.mag_uT.tolist(),
                                             'optical_delta_V':None if selected.optical_delta_V is None else selected.optical_delta_V.tolist(),
                                             't_ms':selected.t_ms,'kind':selected.kind,
                                             'host_monotonic_s':selected.host_monotonic_s,
                                             'coil_state':selected.coil_state}}
            elapsed_ms=(time.perf_counter()-begin)*1000
            sha=hashlib.sha256(pkt.bgr.tobytes()).hexdigest()
            h,w=pkt.bgr.shape[:2]
            self.db.execute('INSERT INTO observations(session_id,monotonic_s,source,frame_sha256,device_monotonic_ns,frame_w,frame_h,elapsed_ms,spikes,phase_order,data_json) VALUES(?,?,?,?,?,?,?,?,?,?,?)',
                (self.session_id,float(pkt.acquired_monotonic_s),pkt.source,sha,pkt.device_monotonic_ns,w,h,elapsed_ms,int(rec['spikes_total']),float(rec['phase_order']),json.dumps(rec,separators=(',',':'))))
            self.db.commit()
            self._last_time=pkt.acquired_monotonic_s;self._last_shape=pkt.bgr.shape
            self.stats['processed']+=1
            n=self.stats['processed'];old=self.stats['mean_processing_ms']
            self.stats['mean_processing_ms']=elapsed_ms if old is None else old+(elapsed_ms-old)/n
            self.stats['source']=pkt.source
            self.stats['last']={'spikes':int(rec['spikes_total']),'phase_order':float(rec['phase_order']),
                                'ring_pulses':int(rec['delivered_ring_pulses']),'elapsed_ms':round(elapsed_ms,3),
                                'frame_timestamp_monotonic_s':pkt.acquired_monotonic_s,
                                'frame_sha256':sha,'source':pkt.source,
                                'fieldsphere':rec['fieldsphere']['state']}
            return self.stats['last'].copy()

    def start(self):
        if self.thread and self.thread.is_alive():return
        self.thread=threading.Thread(target=self._consume,name='mushroom-worker',daemon=True)
        self.thread.start()

    def _consume(self):
        while not self.stop.is_set() or not self.queue.empty():
            try:pkt=self.queue.get(timeout=.15)
            except queue.Empty:continue
            try:self.process(pkt)
            except Exception as e:
                with self.lock:self.stats['failed']+=1;self.stats['last_error']=f'{type(e).__name__}: {e}'
            finally:self.queue.task_done()

    def snapshot(self):
        with self.lock:return dict(self.stats,queue_depth=self.queue.qsize(),colonies=8,cells=216,
                                   fieldsphere_state=('disabled' if self.sphere_bridge is None else ('enabled' if self.sphere_bridge.enabled else 'ablation_off')),
                                   fieldsphere_samples=(0 if self.sphere_stream is None else self.sphere_stream.accepted),
                                   data_provenance='source_declared_not_hardware_attested')

    def close(self,timeout=30):
        self.stop.set()
        if self.thread and self.thread.is_alive():self.thread.join(timeout)
        if self.thread and self.thread.is_alive():raise TimeoutError('worker still active; database not closed')
        self.db.commit();self.db.close()


def playback(workstation:Workstation, filename:str, *, frame_limit=120, record_source='video_file'):
    """Use actual OpenCV decoder; video may itself have simulated content and should be labeled."""
    cap=cv2.VideoCapture(str(filename))
    if not cap.isOpened(): raise FileNotFoundError('OpenCV cannot open selected video')
    count=0;fps=cap.get(cv2.CAP_PROP_FPS)
    if not 1<=fps<=120:raise ValueError('unreadable video frame rate')
    anchor=time.monotonic()
    try:
        while count<frame_limit:
            ok,frame=cap.read()
            if not ok:break
            workstation.process(FramePacket(frame,anchor+count/fps,record_source));count+=1
    finally:cap.release()
    if not count:raise ValueError('zero decoded video frames')
    return count

class CameraCapture:
    def __init__(self,station:Workstation,index:int=0,max_fps=15,record_to=None):
        if index<0:raise ValueError('camera index nonnegative')
        self.station=station;self.index=index;self.max_fps=max_fps;self.thread=None
        self.stopping=threading.Event();self.cap=None
        self.record_to=Path(record_to) if record_to else None;self.recorded_times=[];self.writer=None
    def start(self):
        if self.thread and self.thread.is_alive():raise RuntimeError('camera already active')
        cap=cv2.VideoCapture(self.index)
        if not cap.isOpened():cap.release();raise RuntimeError('physical webcam unavailable; no frames generated')
        self.cap=cap;self.stopping.clear()
        self.thread=threading.Thread(target=self._loop,daemon=True)
        self.thread.start()
    def _loop(self):
        last=0
        while not self.stopping.is_set():
            ok,frame=self.cap.read();now=time.monotonic()
            if not ok:
                with self.station.lock:self.station.stats['last_error']='Camera read failed';self.station.stats['failed']+=1
                break
            if now-last>=1/self.max_fps:
                if self.record_to is not None:
                    if self.writer is None:
                        self.record_to.parent.mkdir(parents=True,exist_ok=True)
                        h,w=frame.shape[:2]
                        self.writer=cv2.VideoWriter(str(self.record_to),cv2.VideoWriter_fourcc(*'MJPG'),self.max_fps,(w,h))
                        if not self.writer.isOpened():
                            self.stopping.set();break
                    self.writer.write(frame);self.recorded_times.append(now)
                try:self.station.submit(FramePacket(frame.copy(),now,'usb_camera'))
                except RuntimeError:break
                last=now
        self.cap.release();self.cap=None
        if self.writer is not None:
            self.writer.release();self.writer=None
            np.savez_compressed(str(self.record_to)+'.timestamps.npz',frame_monotonic_s=np.asarray(self.recorded_times))
            self.record_to.with_suffix('.json').write_text(json.dumps({'origin':'physical_camera_requested_unattested','video':str(self.record_to.name),
                'timestamp_file':self.record_to.name+'.timestamps.npz','timebase':'host_monotonic_on_frame_read','frames_recorded':len(self.recorded_times),
                'synchronization_certified':False,'encoding':'MJPG','fps_nominal':self.max_fps},indent=2))
    def stop(self):
        self.stopping.set()
        if self.thread:self.thread.join(6)
        if self.thread and self.thread.is_alive():raise TimeoutError('camera capture did not stop')
