"""FieldSphere v5.2 experiment: input effects on authentic inherited 216-neuron Ring.
For --study the eight-probe magnetic values come from the legacy physical coil
numerical simulator, not a sensor. Independent seeds vary simulated noise.
"""
from __future__ import annotations
import argparse,csv,json,time,hashlib,sys
from pathlib import Path
import cv2,numpy as np
from .engine import Workstation,FramePacket
from .fieldsphere import SphereCalibration,SphereRingBridge,SphereSample,read_jsonl

ROOT=Path(__file__).resolve().parents[1]
FIELD_SOURCE=ROOT.parent/'Ripple_FieldSphere_v0_1'

def paired_replay(video, samples, *, frames=16,seed=101, enabled=True,threshold_uT=.01,scale_uT=.06):
    """Offline controlled pairing by declared model time, NOT hardware sync."""
    from .fieldsphere import SphereStream
    baseline=[x for x in samples if x.coil_state=='zero']
    test=[x for x in samples if x.coil_state=='plus']
    if not baseline or not test:raise ValueError('controlled replay requires labeled zero and plus records')
    if len({x.kind for x in samples})!=1:raise ValueError('mixed provenance')
    cal=SphereCalibration(baseline)
    bridge=SphereRingBridge(cal,threshold_uT=threshold_uT,scale_uT=scale_uT,enabled=enabled)
    # Use in-memory SQLite; camera timestamps are synthetic decoded-video clock.
    st=Workstation(':memory:',seed=seed,fps=15)
    stream=SphereStream();st.configure_fieldsphere(stream,bridge)
    cap=cv2.VideoCapture(str(video))
    if not cap.isOpened():raise FileNotFoundError('video file cannot be opened')
    fps=cap.get(cv2.CAP_PROP_FPS)
    if fps<1:raise ValueError('video frame rate absent')
    t0=test[0].t_ms
    records=[]
    try:
        for k in range(frames):
            okay,frame=cap.read()
            if not okay:break
            frame_ms=1000*k/fps
            eligible=[s for s in test if 0<=frame_ms-(s.t_ms-t0)<=350]
            sample=eligible[-1] if eligible else None
            result=st.process(FramePacket(frame,100.+k/fps,'video_file'),sphere_sample=sample)
            records.append(result)
        if not records:raise ValueError('no decoded frames')
        rec=st.ring.summary()
        report={'frames':len(records),'field_samples_used':sum(x['fieldsphere']=='applied' for x in records),
                'spikes_total':rec['spikes_total'],'markers':rec['markers'],
                'phase_order':rec['mean_phase_order'],'colony_spikes':rec['spikes_by_role'],
                'enabled':enabled,'source_kind':samples[0].kind,
                'video_sha256':hashlib.sha256(Path(video).read_bytes()).hexdigest(),
                'note':'offline software time alignment; not physically synchronized'}
        return report
    finally:cap.release();st.close()

def run_study(video, *,replicates=50,frames=16,out=None):
    if not 1<=replicates<=1000:raise ValueError('bounded repeat count')
    sys.path.insert(0,str(FIELD_SOURCE/'host'))
    try:from fieldsphere import synth_records
    except ImportError as exc:raise RuntimeError('preserved FieldSphere v0.1 source folder must accompany release') from exc
    pairs=[];started=time.perf_counter()
    for seed in range(replicates):
        samples=[SphereSample.from_dict(row) for row in synth_records(n=16,seed=1000+seed)]
        connected=paired_replay(video,samples,frames=frames,seed=101,enabled=True)
        absent=paired_replay(video,samples,frames=frames,seed=101,enabled=False)
        pairs.append({'replicate':seed,'simulation_seed':1000+seed,
                      'connected_spikes':connected['spikes_total'],'disabled_spikes':absent['spikes_total'],
                      'connected_phase':connected['phase_order'],'disabled_phase':absent['phase_order'],
                      'connected_markers':connected['markers'],'disabled_markers':absent['markers'],
                      'field_samples_used':connected['field_samples_used']})
    changes=np.asarray([x['connected_spikes']-x['disabled_spikes'] for x in pairs],float)
    phases=np.asarray([x['connected_phase']-x['disabled_phase'] for x in pairs],float)
    report={'evidence':'SIMULATED eight-probe coil and decoded video, executed 216-neuron Ring',
            'replicates':len(pairs),'total_ring_executions':len(pairs)*2,
            'mean_spike_difference':float(changes.mean()),'sd_spike_difference':float(changes.std(ddof=1)) if len(changes)>1 else None,
            'number_nonzero_spike_differences':int(np.count_nonzero(changes)),
            'mean_phase_difference':float(phases.mean()),
            'seconds':time.perf_counter()-started,'pairs':pairs,
            'interpretation':'Causal software ablation, not measured magnetic sensitivity or intelligence.'}
    if out:Path(out).parent.mkdir(parents=True,exist_ok=True);Path(out).write_text(json.dumps(report,indent=2))
    return report

def main():
    p=argparse.ArgumentParser();p.add_argument('--video',required=True)
    p.add_argument('--fieldsphere-jsonl');p.add_argument('--replicates',type=int,default=0)
    p.add_argument('--frames',type=int,default=16);p.add_argument('--out',default='results_v52/field_study.json')
    a=p.parse_args()
    if a.replicates:
        print(json.dumps({k:v for k,v in run_study(a.video,replicates=a.replicates,frames=a.frames,out=a.out).items() if k!='pairs'},indent=2))
    else:
        if not a.fieldsphere_jsonl:raise ValueError('provide --fieldsphere-jsonl')
        samples=read_jsonl(a.fieldsphere_jsonl)
        if samples[0].kind!='simulated':
            raise ValueError('offline time alignment is supported only for simulated fixture; real capture requires measured shared timestamps')
        connected=paired_replay(a.video,samples,frames=a.frames)
        disabled=paired_replay(a.video,samples,frames=a.frames,enabled=False)
        report={'connected':connected,'disabled':disabled}
        Path(a.out).parent.mkdir(parents=True,exist_ok=True);Path(a.out).write_text(json.dumps(report,indent=2))
        print(json.dumps(report,indent=2))
if __name__=='__main__':main()
