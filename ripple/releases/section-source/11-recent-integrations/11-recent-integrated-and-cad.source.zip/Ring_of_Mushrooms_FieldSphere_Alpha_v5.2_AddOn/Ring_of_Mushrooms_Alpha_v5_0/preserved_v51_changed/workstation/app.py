"""Real desktop controls for Ring v5.1. Tk is stdlib; physical cameras only when attached."""
from __future__ import annotations
import argparse,csv,json,platform,subprocess,sys,threading,time
from pathlib import Path
from .engine import Workstation,CameraCapture,playback
from .bridge import PhoneServer
from .eeg import inspect_edf
from .checkpoint import save as save_checkpoint, load as load_checkpoint

def diagnostics():
    import cv2,numpy as np
    info={'platform':platform.platform(),'python':sys.version.split()[0],
          'processor':platform.processor(),'logical_cores':__import__('os').cpu_count(),
          'cv2':cv2.__version__,'numpy':np.__version__, 'device_access':'not_probed',
          'gpu':'not_detected','memory_bytes':'not_detected'}
    if sys.platform=='win32':
        for name,command in {'laptop': ['powershell','-NoProfile','-Command','Get-CimInstance Win32_ComputerSystem | Select-Object Manufacturer,Model,TotalPhysicalMemory | ConvertTo-Json -Compress'],
            'processor_details':['powershell','-NoProfile','-Command','Get-CimInstance Win32_Processor | Select-Object Name,NumberOfCores,NumberOfLogicalProcessors | ConvertTo-Json -Compress'],
            'graphics':['powershell','-NoProfile','-Command','Get-CimInstance Win32_VideoController | Select-Object Name,AdapterRAM | ConvertTo-Json -Compress']}.items():
            try:r=subprocess.run(command,capture_output=True,text=True,timeout=6);info[name]=json.loads(r.stdout) if r.returncode==0 else {'error':r.stderr.strip()[:300]}
            except Exception as e:info[name]={'error':str(e)}
    else:
        try: info['memory_bytes']=__import__('os').sysconf('SC_PAGE_SIZE')*__import__('os').sysconf('SC_PHYS_PAGES')
        except Exception:pass
    return info

def export_csv(database, output):
    import sqlite3
    con=sqlite3.connect(database)
    try:rows=con.execute('SELECT session_id,monotonic_s,source,device_monotonic_ns,frame_sha256,frame_w,frame_h,elapsed_ms,spikes,phase_order FROM observations ORDER BY id').fetchall()
    finally:con.close()
    with open(output,'w',newline='',encoding='utf-8') as f:
        w=csv.writer(f);w.writerow(['session_id','host_monotonic_s','source','device_monotonic_ns','frame_sha256','frame_width','frame_height','elapsed_ms','model_spikes','model_phase_order']);w.writerows(rows)
    return len(rows)

def start_gui(db_path, *,index=0):
    import tkinter as tk
    from tkinter import ttk,filedialog,messagebox
    station=Workstation(db_path);station.start()
    cap=CameraCapture(station,index=index)
    phone=None
    win=tk.Tk();win.title('Mushroom v5.1 — Evidence Workstation');win.geometry('840x540')
    text=tk.Text(win,height=18,width=102,wrap='word');text.pack(fill='both',expand=True,padx=8,pady=8)
    label=tk.StringVar(value='Unconnected — source unavailable');ttk.Label(win,textvariable=label).pack(fill='x',padx=8)
    controls=ttk.Frame(win);controls.pack(fill='x',padx=8,pady=2)
    controls2=ttk.Frame(win);controls2.pack(fill='x',padx=8,pady=2)
    def log(msg):
        text.insert('end',msg+'\n');text.see('end')
    def on_error(e):log(f'ERROR: {type(e).__name__}: {e}')
    def task(label_,func):
        def start():
            try:out=func();win.after(0,lambda:log(f'{label_}: '+str(out)))
            except Exception as e:win.after(0,lambda err=e:on_error(err))
        threading.Thread(target=start,daemon=True).start()
    def cam_start():
        try:cap.record_to=None;cap.recorded_times=[];cap.start();log('Webcam opened by OpenCV; source flag USB CAMERA (physical hardware test requires local confirmation).')
        except Exception as e:on_error(e)
    def cam_record():
        p=filedialog.asksaveasfilename(defaultextension='.avi',filetypes=[('AVI','*.avi')])
        if not p:return
        try:cap.record_to=Path(p);cap.recorded_times=[];cap.start();log('Recording locally after explicit approval: '+p)
        except Exception as e:on_error(e)
    def cam_stop():task('Camera stopped',lambda:cap.stop() or 'released')
    def video():
        p=filedialog.askopenfilename(filetypes=[('Video','*.avi *.mp4 *.mov'),('All','*.*')])
        if p:task('Decoded video',lambda:playback(station,p,frame_limit=120))
    def edf():
        p=filedialog.askopenfilename(filetypes=[('EEG EDF','*.edf')])
        if p:task('EDF inspection',lambda:json.dumps(inspect_edf(p),indent=2))
    def fusion():
        video=filedialog.askopenfilename(title='Select captured video')
        if not video:return
        acquisition=filedialog.askopenfilename(title='Select independently captured EEG NPZ',filetypes=[('NPZ','*.npz')])
        if not acquisition:return
        anchors=filedialog.askopenfilename(title='Select measured shared-event timestamp CSV',filetypes=[('CSV','*.csv')])
        if not anchors:return
        from ring5.synchronized import execute
        outfile=Path(db_path).with_suffix('.fusion.json')
        task('Real synchronized-fusion experiment',lambda: {'frames':execute(video,acquisition,anchors,output=str(outfile),video_kind='physical_camera')['frames'],'report':str(outfile)})
    def start_phone():
        nonlocal phone
        if phone is not None:log('Phone endpoint already listening');return
        try:
            phone=PhoneServer(station);phone.start();log('PHONE USB LINK listening at 127.0.0.1:8789; run `adb reverse tcp:8789 tcp:8789`.');log('PHONE SESSION TOKEN: '+phone.token)
        except Exception as e:on_error(e)
    def save_state():
        if cap.thread and cap.thread.is_alive():on_error(RuntimeError('Stop live camera before saving exact state'));return
        p=filedialog.asksaveasfilename(defaultextension='.ringstate',filetypes=[('Mushroom checkpoint','*.ringstate')])
        if p:task('Saved exact ring state',lambda:save_checkpoint(station,p))
    def load_state():
        if cap.thread and cap.thread.is_alive():on_error(RuntimeError('Stop camera before loading state'));return
        p=filedialog.askopenfilename(filetypes=[('Mushroom checkpoint','*.ringstate')])
        if p:task('Restored ring state',lambda:load_checkpoint(station,p))
    def export():
        p=filedialog.asksaveasfilename(defaultextension='.csv',filetypes=[('CSV','*.csv')]);
        if p:task('Exported record count',lambda:export_csv(db_path,p))
    def buttons(items):
        for i,(txt,cmd) in enumerate(items):ttk.Button(controls if i<5 else controls2,text=txt,command=cmd).pack(side='left',padx=2)
    buttons([('Start webcam',cam_start),('Record webcam',cam_record),('Stop webcam',cam_stop),('Analyze video',video),('Inspect EEG EDF',edf),('Fuse synced data',fusion),('Android USB link',start_phone),('Export CSV',export),('Save Ring state',save_state),('Restore Ring',load_state)])
    log('This is a real Ring v5 core (8 colonies × 27 neurons). Records saved in SQLite.')
    log('EEG fusion requires real paired time anchors. Android bridge is USB/localhost only.')
    log('Computer diagnostic: '+json.dumps(diagnostics(),default=str))
    last_count=[-1]
    def tick():
        if not win.winfo_exists():return
        snap=station.snapshot();label.set(f"Processed {snap['processed']}  | Dropped {snap['dropped']}  | Errors {snap['failed']}  | Latest {snap['last']}")
        if snap['failed'] and snap['failed']!=last_count[0]:log(f"Processing error: {snap['last_error']}")
        last_count[0]=snap['failed'];win.after(350,tick)
    tick()
    def quit_():
        try:cap.stop()
        except Exception as e:on_error(e)
        if phone:phone.stop()
        try:station.close()
        except Exception as e:on_error(e)
        win.destroy()
    win.protocol('WM_DELETE_WINDOW',quit_)
    win.mainloop()

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--db',default='workstation_records/ring.sqlite');ap.add_argument('--camera',type=int,default=0);ap.add_argument('--diagnose',action='store_true');ap.add_argument('--video');ap.add_argument('--frames',type=int,default=48);ap.add_argument('--eeg-edf');ap.add_argument('--serve-phone',action='store_true')
    a=ap.parse_args()
    if a.diagnose:print(json.dumps(diagnostics(),indent=2));return
    if a.eeg_edf:print(json.dumps(inspect_edf(a.eeg_edf),indent=2));return
    if a.video:
        st=Workstation(a.db)
        try:print(json.dumps({'frames':playback(st,a.video,frame_limit=a.frames),'model':st.ring.summary(),'db':a.db},indent=2))
        finally:st.close()
        return
    if a.serve_phone:
        st=Workstation(a.db);bridge=PhoneServer(st);bridge.start()
        print(f'USB bridge token: {bridge.token}\nadb reverse tcp:8789 tcp:8789\nPress Ctrl+C to stop',flush=True)
        try:
            while True:time.sleep(2)
        except KeyboardInterrupt:pass
        finally:bridge.stop();st.close()
        return
    start_gui(a.db,index=a.camera)
if __name__=='__main__':main()
