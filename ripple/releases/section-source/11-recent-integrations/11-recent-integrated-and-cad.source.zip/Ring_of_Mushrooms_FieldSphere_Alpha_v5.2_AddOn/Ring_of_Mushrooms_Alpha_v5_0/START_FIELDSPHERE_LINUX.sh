#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 -m pip install -r requirements_fieldsphere.txt
python3 start_workstation.py
