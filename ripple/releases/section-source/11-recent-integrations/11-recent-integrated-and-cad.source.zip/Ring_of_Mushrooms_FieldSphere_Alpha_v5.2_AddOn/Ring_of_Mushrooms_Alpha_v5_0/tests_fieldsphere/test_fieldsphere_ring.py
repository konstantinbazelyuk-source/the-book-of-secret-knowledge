from __future__ import annotations
import unittest,sys,tempfile,json,time
from pathlib import Path
import numpy as np
from workstation.fieldsphere import (SphereSample,SphereCalibration,SphereStream,SphereRingBridge,
                                     RegisteredVectors,POSITIONS_M,read_jsonl)
from ring.core import Ring,RingParameters
from workstation.engine import Workstation,FramePacket


def row(t=0,kind='simulated',strength=0,coil_state='zero',optical=None):
    mag=[[20+strength,-30,40]]*8
    return {'kind':kind,'t_ms':t,'mag_uT':mag,'coil_state':coil_state,'optical_delta_V':optical}

class TestSphere(unittest.TestCase):
    def setUp(self):self.zero=SphereSample.from_dict(row())
    def test_type(self):self.assertEqual(self.zero.mag_uT.shape,(8,3))
    def test_missing_sensor(self):
        d=row();d['mag_uT'][3]=None
        with self.assertRaises((ValueError,TypeError)):SphereSample.from_dict(d)
    def test_mixed_source(self):
        c=SphereCalibration([self.zero]);s=SphereSample.from_dict(row(1,'hardware',1,'plus'))
        with self.assertRaises(ValueError):c.anomalies(s)
    def test_baseline_requires_zero(self):
        with self.assertRaises(ValueError):SphereCalibration([SphereSample.from_dict(row(1,coil_state='plus'))])
    def test_baseline_subtracts(self):
        c=SphereCalibration([self.zero]);d,_=c.anomalies(SphereSample.from_dict(row(20,strength=2,coil_state='plus')))
        self.assertTrue(np.all(d>0))
    def test_signed_delta(self):
        c=SphereCalibration([self.zero]);d,_=c.anomalies(SphereSample.from_dict(row(20,strength=-2,coil_state='minus')))
        self.assertTrue(np.all(d<0))
    def test_optical(self):
        base=SphereSample.from_dict(row(optical=[.1,.2,.3,.4]))
        c=SphereCalibration([base]);s=SphereSample.from_dict(row(125,optical=[.2,.1,.5,.4],coil_state='plus'))
        _,o=c.anomalies(s);self.assertTrue(np.allclose(o,[.1,-.1,.2,0]))
    def test_invalid_optical(self):
        with self.assertRaises(ValueError):SphereSample.from_dict(row(optical=[10,0,0,0]))
    def test_strict_time(self):
        s=SphereStream();s.ingest(row(0),host_monotonic_s=10)
        with self.assertRaises(ValueError):s.ingest(row(0),host_monotonic_s=10.1)
    def test_stale_sample_refused(self):
        s=SphereStream();s.ingest(row(0),host_monotonic_s=10)
        self.assertIsNone(s.nearest_past(10.5,max_age_s=.35))
        self.assertEqual(s.nearest_past(10.1).t_ms,0)
    def test_future_refused(self):
        ring=Ring();c=SphereCalibration([self.zero]);b=SphereRingBridge(c)
        sample=SphereSample.from_dict(row(10,strength=2,coil_state='plus'),received_monotonic_s=10.)
        with self.assertRaises(ValueError):b.inject(ring,sample,frame_time_s=9.)
    def test_real_neuron_conductance(self):
        ring=Ring();c=SphereCalibration([self.zero]);b=SphereRingBridge(c,threshold_uT=0,scale_uT=.1)
        sample=SphereSample.from_dict(row(125,strength=2,coil_state='plus'))
        before=ring.children[0].neurons[13].exc
        report=b.inject(ring,sample)
        self.assertGreater(ring.children[0].neurons[13].exc,before)
        self.assertEqual(len(report['applied_conductance']),8)
    def test_ablation_no_change(self):
        ring=Ring();c=SphereCalibration([self.zero]);b=SphereRingBridge(c,enabled=False)
        before=ring.children[0].neurons[13].exc
        r=b.inject(ring,SphereSample.from_dict(row(125,strength=2,coil_state='plus')))
        self.assertEqual(r['applied_conductance'],0.)
        self.assertEqual(before,ring.children[0].neurons[13].exc)
    def test_optical_real_neuron_path(self):
        ring=Ring();c=SphereCalibration([SphereSample.from_dict(row(optical=[0]*4))]);b=SphereRingBridge(c)
        r=b.inject(ring,SphereSample.from_dict(row(125,coil_state='plus',optical=[.1]*4)))
        self.assertEqual(len(r['optical_applied']),4)
        self.assertGreater(ring.children[5].neurons[12].exc,0)
        self.assertGreater(ring.children[6].neurons[14].exc,0)
    def test_calibrated_gradient_attached_to_active_path(self):
        identity=np.tile(np.eye(3),(8,1,1))
        fit=RegisteredVectors(identity,np.zeros((8,3)),identity,measured=True)
        baseline=SphereCalibration([self.zero])
        bridge=SphereRingBridge(baseline,registered_vectors=fit)
        report=bridge.inject(Ring(),SphereSample.from_dict(row(125,strength=1,coil_state='plus')))
        self.assertEqual(report['spatial_fit']['sites'],8)
    def test_registration_rejects_bad_rotation(self):
        r=np.tile(np.eye(3),(8,1,1));r[0,0,0]=-1
        with self.assertRaises(ValueError):RegisteredVectors(r,np.zeros((8,3)),np.tile(np.eye(3),(8,1,1)),measured=True)
    def test_registered_requires_measured(self):
        rot=np.tile(np.eye(3),(8,1,1))
        with self.assertRaises(ValueError):RegisteredVectors(rot,np.zeros((8,3)),rot,measured=False)
    def test_vector_gradient_known(self):
        ident=np.tile(np.eye(3),(8,1,1));reg=RegisteredVectors(ident,np.zeros((8,3)),ident,measured=True)
        center=np.array([19.,-32.,41.]);G=np.array([[3.,2.,1.],[-1.,4.,0.],[2.,3.,-7.]])
        mag=np.array([center+G@p for p in POSITIONS_M])
        s=SphereSample(mag,None,0,'simulated',None)
        result=reg.finite_site_gradient(s)
        self.assertTrue(np.allclose(result['gradient_uT_per_m'],G,atol=1e-10))
        self.assertAlmostEqual(result['rms_site_residual_uT'],0,places=10)
    def test_untrusted_orientation_template(self):
        path=Path(__file__).resolve().parents[2]/'Ripple_FieldSphere_v0_1'/'host'/'orientation_template.json'
        with self.assertRaises((KeyError,ValueError)):RegisteredVectors.load(path)
    def test_read_invalid(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'records.jsonl';p.write_text(json.dumps(row())+'\n'+json.dumps(row())+'\n')
            with self.assertRaises(ValueError):read_jsonl(p)
    def test_stream_provenance(self):
        s=SphereStream();s.ingest(row(0))
        with self.assertRaises(ValueError):s.ingest(row(100,kind='hardware'))
    def test_record_source_persisted(self):
        with tempfile.TemporaryDirectory() as d:
            station=Workstation(Path(d)/'observations.sqlite')
            cal=SphereCalibration([self.zero]);bridge=SphereRingBridge(cal,threshold_uT=0,scale_uT=.05)
            station.configure_fieldsphere(SphereStream(),bridge)
            sample=SphereSample.from_dict(row(125,strength=2,coil_state='plus'))
            out=station.process(FramePacket(np.zeros((32,32,3),np.uint8),20.,'video_file'),sphere_sample=sample)
            self.assertEqual(out['fieldsphere'],'applied')
            raw=json.loads(station.db.execute('select data_json from observations').fetchone()[0])['fieldsphere']
            self.assertEqual(raw['raw']['kind'],'simulated')
            self.assertEqual(len(raw['report']['applied_conductance']),8)
            station.close()
    def test_workstation_disabled_baseline(self):
        with tempfile.TemporaryDirectory() as d:
            station=Workstation(Path(d)/'o.sqlite')
            c=SphereCalibration([self.zero]);station.configure_fieldsphere(SphereStream(),SphereRingBridge(c,enabled=False))
            out=station.process(FramePacket(np.zeros((32,32,3),np.uint8),20.,'video_file'),
                                sphere_sample=SphereSample.from_dict(row(125,strength=2,coil_state='plus')))
            self.assertEqual(out['fieldsphere'],'disabled');station.close()
    def test_absent_has_no_substitute(self):
        with tempfile.TemporaryDirectory() as d:
            station=Workstation(Path(d)/'o.sqlite')
            out=station.process(FramePacket(np.zeros((32,32,3),np.uint8),20.,'video_file'))
            self.assertEqual(out['fieldsphere'],'absent_or_stale');station.close()
    def test_bound_control(self):
        with self.assertRaises(ValueError):SphereRingBridge(SphereCalibration([self.zero]),max_exc=99)
    def test_negative_branch(self):
        ring=Ring();b=SphereRingBridge(SphereCalibration([self.zero]),threshold_uT=0,scale_uT=.1)
        b.inject(ring,SphereSample.from_dict(row(125,strength=-2,coil_state='minus')))
        self.assertGreater(ring.children[0].neurons[13].inh,0)

if __name__=='__main__':unittest.main()
