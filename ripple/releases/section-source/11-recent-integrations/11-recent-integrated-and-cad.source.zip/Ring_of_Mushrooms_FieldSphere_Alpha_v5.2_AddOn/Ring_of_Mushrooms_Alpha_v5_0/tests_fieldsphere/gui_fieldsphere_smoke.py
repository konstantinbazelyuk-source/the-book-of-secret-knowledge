"""Headless functional FieldSphere GUI test; not a physical sensor test."""
import json,tempfile,tkinter as tk,sys
sys.path.insert(0,str(__import__("pathlib").Path(__file__).resolve().parents[1]))
from pathlib import Path
from tkinter import filedialog
from workstation.app import start_gui
root=Path(__file__).resolve().parents[1]
video=str(root/'results_v5/synthetic_sync_fixture/simulated_camera.avi')
sphere=str(root.parent/'Ripple_FieldSphere_v0_1/data/synthetic_coil_run.jsonl')
tmp=Path(tempfile.mkdtemp(prefix='fieldsphere_gui_'))
filedialog.askopenfilename=lambda **kw:(sphere if 'FieldSphere' in kw.get('title','') else video)
orig=tk.Tk.mainloop

def wrapped(self,*a,**kw):
    def discover(w):
        arr=[]
        for x in w.winfo_children():
            if x.winfo_class()=='TButton':arr.append(x)
            arr+=discover(x)
        return arr
    buttons={b.cget('text'):b for b in discover(self)}
    required=['FieldSphere serial','FieldSphere baseline','FieldSphere off','FieldSphere replay','Change coil label','Disconnect sphere']
    assert all(x in buttons for x in required),set(required)-set(buttons)
    buttons['FieldSphere replay'].invoke()
    dest=tmp/'study.fieldsphere.json'
    def check(count=0):
        if dest.exists():
            data=json.loads(dest.read_text())
            assert data['enabled']['frames']==16
            assert data['disabled']['frames']==16
            assert data['enabled']['spikes_total']!=data['disabled']['spikes_total']
            buttons['FieldSphere off'].invoke()
            print('FieldSphere GUI replay PASS: actual control -> decoded video -> Ring model -> output file; enabled %s disabled %s'%
                  (data['enabled']['spikes_total'],data['disabled']['spikes_total']),flush=True)
            self.destroy()
        elif count<100:self.after(100,lambda:check(count+1))
        else:raise TimeoutError('FieldSphere replay button did not produce a result')
    self.after(100,check)
    return orig(self,*a,**kw)
tk.Tk.mainloop=wrapped
try:start_gui(str(tmp/'study.db'))
finally:tk.Tk.mainloop=orig
