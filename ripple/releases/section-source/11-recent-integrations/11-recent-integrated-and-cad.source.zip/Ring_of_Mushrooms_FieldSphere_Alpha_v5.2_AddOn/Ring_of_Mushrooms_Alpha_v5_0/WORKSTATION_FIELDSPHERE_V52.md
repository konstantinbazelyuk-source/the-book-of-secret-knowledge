# FieldSphere × Ring of Mushrooms — device integration v5.2

## Built (executed)

- `workstation/fieldsphere.py`: 8×XYZ magnetometer packets (microtesla), 4 optional LED/photodiode voltages, strictly validated real/simulated provenance and timestamps, explicit zero-state baseline, bounded scalar response, eight inherited Charlie neuron conductance inputs, plus four independent optical conductance inputs. Hard-iron/soft-iron + measured board rotations and an 8-site least-squares vector gradient estimator are optional, not silently assumed.
- `workstation/engine.py`: original Ring v5.1 processing extended to inject the actual current FieldSphere sample before each `Ring.step`. Raw eight-site measurements, their original kind, the calibration-derived anomalies, and applied conductance are recorded in the existing persistent SQLite `observations.data_json`; absent/stale inputs never generate placeholder readings.
- `workstation/app.py`: working desktop controls to connect a real FieldSphere serial port, change the operator-reported coil state, record a zero-baseline, disable/disconnect the sensor, and run a controlled offline source replay.
- `workstation/fieldsphere_study.py`: 50-replicate paired comparison with exact same video and Ring starting state, using original FieldSphere Biot–Savart coil simulator and explicitly independent noise seeds.
- `tests_fieldsphere/`: 26 unit/integration/negative/causal tests.
- `../Ripple_FieldSphere_v0_1/`: the unchanged original v0.1 manufacturing design, firmware, geometry, and 12 original tests.

## Physical source, setup, and calibration

The FieldSphere hardware design specifies **eight ST LIS2MDL 3-axis sensors** and one I2C multiplexer, scanned sequentially by the Raspberry Pi Pico's MicroPython firmware. The design includes four *optional* ordinary LED / photodiode intensity channels. **They are not magneto-optical detectors.** At a nominal 125-ms full scan interval, the nominal array sample rate is at most 8 complete scan frames/s, but hardware timing has not been measured. The scan is not simultaneous, so fast-changing fields cannot be reliably compared across all eight probes without a faster synchronized acquisition system.

1. Physically assemble and power the FieldSphere only after reviewing the included v0.1 BOM, wiring, and firmware. Flash `../Ripple_FieldSphere_v0_1/firmware/main.py` to a supported Pico running MicroPython. **The firmware requires all eight LIS2MDL devices and explicitly reports failure if any is missing.** No Pico or sensor was available during this release's verification.
2. On a Windows/Dell workstation, install Python 3, NumPy, OpenCV and the real serial driver: `python -m pip install -r requirements_fieldsphere.txt`. Connect the Pico USB serial to a genuine port, e.g. `COM4`. Start `python start_workstation.py`.
3. Press **FieldSphere serial**, enter the port, and label the coil state **zero** only when it really is zero. Wait for at least 3 frames, then press **FieldSphere baseline**. The baseline is a *local field reference*, not a physical calibration of each sensor, and not a verified 3D vector registration.
4. Start **Start webcam** or the authenticated Android camera stream. Incoming FieldSphere samples are matched using **host monotonic receipt timestamps**, without assuming the Pico's ticks_ms clock equals the host clock. Samples older than 0.35 seconds are omitted. If all eight probes are absent, the old Ring remains functional; the UI explicitly marks FieldSphere missing.
5. Optional **Change coil label** changes only an operator-reported label and does not verify the current source. Capture a zero/+I/−I experiment using the original `host/capture_serial.py` with hardware and labeled current to estimate reversal response. Verify local sensor orientation and hard/soft iron independently before using vector gradients.
6. **FieldSphere off** removes the extra inputs without changing the Ring. **Disconnect sphere** closes the serial port. Export CSV gives the original camera+Ring summary; full raw FieldSphere readings and per-frame conductance live in the SQLite `data_json` column. Preserve database/recorded original JSONL for any report.

**Important hardware uncertainty:** The user device has not been reached; actual sensor availability, offsets, magnetic range, optical crosstalk, USB port/baud behavior, thermal stability, and sustained Dell/Samsung throughput remain physically untested. The reported `kind: hardware` comes from firmware or data files and is not cryptographic authentication of real physics.

## Controlled software test (executed)

From the `Ring_of_Mushrooms_Alpha_v5_0` folder:

```
python -m unittest discover -s tests_fieldsphere -q
python -m unittest discover -s tests_workstation -q
python -m unittest discover -s tests -q
python -m unittest discover -s tests_v5 -q
python -m workstation.fieldsphere_study --video results_v5/synthetic_sync_fixture/simulated_camera.avi --fieldsphere-jsonl ../Ripple_FieldSphere_v0_1/data/synthetic_coil_run.jsonl --frames 16 --out results_v52/pair_replay.json
python -m workstation.fieldsphere_study --video results_v5/synthetic_sync_fixture/simulated_camera.avi --replicates 50 --frames 16 --out results_v52/study_50.json
```

This test is a simulation-to-neuron **causal integration experiment**, not an observation made by a manufactured FieldSphere. The offline video and magnetic records are paired on their *declared model clocks*, not real hardware timestamps. Use measured synchronization anchors for physical EEG/camera/FieldSphere correlation.

## Equations and limits

For probe i, with local measured vector b_i in µT and baseline vector b_i,0, the orientation-invariant magnitude-change input is:

`d_i = ||b_i||_2 - ||b_i,0||_2` in µT. This is **not** a complete vector magnetic-field estimate, and sensor-specific scale, offset, and soft-iron errors remain.

`q_i = sign(d_i) max(0, |d_i| - theta)`

`u_i = A tanh(q_i / sigma)`, dimensionless conductance units.

`u_i > 0` increments excitatory conductance of the inherited center Charlie neuron in Mushroom i; `u_i < 0` increments inhibitory conductance. The neuron clamps to its inherited `max_synaptic_conductance`. `theta` defaults to 0.08 µT, `sigma` to 1.0 µT, and A to 1.5. These are software experiment parameters, **not physically optimized detection limits**.

Each optional photodiode channel j uses voltage change `Delta V_j=V_j-V_j,0` and `u_j=A tanh(Delta V_j / 0.1 V)` at a separate luminance/shadow neuron. Light intensity is not classified as RGB wavelength, magnetic field, or human EEG.

If measured hard-iron offsets, soft-iron correction matrices, and local->global proper rotations are supplied, compute corrected global vectors `B_i = R_i S_i(b_i-h_i)`; then least-squares fit `B_i=B0+G r_i+epsilon_i` at eight actual cube-corner coordinates (±90 mm, not an arbitrary sphere). Report the 3×3 local gradient G in µT/m and least-squares residual. **This sparse local linear fit is not magnetic tomography.** Without measured orientation and calibration, it is disabled.

## Research integrity, sources and device status

- Parent Ring v5.1 neuron equations and archived physical-design source files have not been modified.
- All new physical-unit conversions adhere to the LIS2MDL `1.5 mgauss/LSB = 0.15 µT/LSB` reference scaling. Manufacturing v0.1 already has that scaling; its firmware has not been hardware-tested.
- Established magnetometer calibration references: ST LIS2MDL datasheet (`https://www.st.com/resource/en/datasheet/lis2mdl.pdf`), NXP AN4246 (`https://www.nxp.com/docs/en/application-note/AN4246.pdf`), ST AN3192 (`https://www.st.com/resource/en/application_note/an3192-3axis-magnetometer-calibration-and-compensation-stmicroelectronics.pdf`).
- The reported replicates are **50 simulated FieldSphere noise seeds**, executed against **the same decoded video**, each with an enabled-vs-disabled Ring control. No inference about generalization to uncontrolled magnetic environments is made.
- The Android CameraX client from v5.1 still sends camera frames into the workstation, unchanged; no new APK has been compiled or tested on Samsung in this session. Windows installer and physical 8-sensor operation are pending device access / applicable cloud build execution.

## Next executable step

Flash the existing Pico firmware to a real LIS2MDL array, capture ≥3 minutes of zero/+I/−I data while logging camera frames with a common host receipt clock and independent coil-current measurements, perform three-axis hard/soft iron and orientation calibration, then benchmark the real FieldSphere against the disconnected Ring and a conventional magnetic-feature classifier on held-out recorded experiments.
