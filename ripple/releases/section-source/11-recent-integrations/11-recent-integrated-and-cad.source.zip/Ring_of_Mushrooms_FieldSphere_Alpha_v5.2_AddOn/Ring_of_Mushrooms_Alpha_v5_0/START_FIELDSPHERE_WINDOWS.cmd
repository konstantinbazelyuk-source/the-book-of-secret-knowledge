@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (set "PY=py -3") else (set "PY=python")
%PY% -c "import numpy,cv2" >nul 2>&1
if errorlevel 1 (
  echo Installing FieldSphere / Ring workstation Python dependencies...
  %PY% -m pip install -r requirements_fieldsphere.txt || exit /b 1
)
%PY% start_workstation.py
endlocal
