# Ripple FieldSphere × Ring of Mushrooms — Alpha v5.2

**Two source roots:** `Ring_of_Mushrooms_Alpha_v5_0/` (Ring v5.1 extended only at its workstation interface) and `Ripple_FieldSphere_v0_1/` (verbatim original FieldSphere 8-probe engineering kit).

START: `cd Ring_of_Mushrooms_Alpha_v5_0`, install `requirements_fieldsphere.txt`, then run `python start_workstation.py`. On Windows the `START_FIELDSPHERE_WINDOWS.cmd` helper launches the Python application if its environment is configured.

**Scientific results and exact status:** `Ring_of_Mushrooms_Alpha_v5_0/WORKSTATION_FIELDSPHERE_V52.md`. **Replicate logs:** `Ring_of_Mushrooms_Alpha_v5_0/results_v52/study_50.json`. **Preservation:** `SOURCE_INTEGRITY.json`. **Cloud build:** `.github/workflows/fieldsphere_ring_v52.yml` is furnished but not executed.

**Device status:** The GUI, frame decoder, magnetic ingestion, Ring synaptic input, persistence and negative controls were executed in Linux. Pico firmware, live physical sensors, Dell Windows binary and Android APK require target build / connected hardware verification.
