"""Headless X display integration with the real desktop control callback."""
import json,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from bridge.gui import WorkstationUI
app=WorkstationUI()
app.frames.set(24)
app.external.set(True);app.eyes.set(True)
app.start_button.invoke()
deadline=time.monotonic()+55
while time.monotonic()<deadline and (app.running or app.last is None):
    app.update();time.sleep(.06)
if app.last is None:raise AssertionError('UI did not finish: '+app.status.get())
assert app.last['frames']==24
assert app.last['events']>=1
assert app.last['events']==app.last['external_program_runs']==app.last['eyes_inspections']
assert app.last['errors']==[],app.last['errors']
app.update();print(json.dumps({'ui_status':app.status.get(),'frames':app.last['frames'],'events':app.last['events'],'external_launches':app.last['external_program_runs']}));app.destroy()
