import hashlib,json,os,sqlite3,sys,tempfile,unittest
from pathlib import Path
import numpy as np,cv2
from bridge.runtime import Bridge,Policy,PACKAGE,RING_PARENT,GOLF_PARENT
from tools.trusted_receiver import run as receiver

FIXTURE=RING_PARENT/'results_v5'/'synthetic_sync_fixture'/'simulated_camera.avi'

class PolicyTests(unittest.TestCase):
    def test_bounds(self):
        for k,v in [('threshold',-1),('threshold',300),('min_regions',0),('min_regions',9),('cooldown_frames',-1),('max_events',0)]:
            with self.subTest(k=k,v=v),self.assertRaises(ValueError):Policy(**{k:v})
    def test_flag_types(self):
        with self.assertRaises(ValueError):Policy(allow_external_app=1)
    def test_defaults_restrict_external(self):
        p=Policy();self.assertFalse(p.allow_external_app);self.assertFalse(p.allow_code_inspection)

class ReceiverTests(unittest.TestCase):
    def test_zero_events(self):
        with tempfile.TemporaryDirectory() as t:
            r=receiver(t);self.assertEqual(r['events'],[])
    def test_invalid_schema_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'events';p.mkdir();(p/'broken.json').write_text('{"schema":"bad"}')
            with self.assertRaises(ValueError):receiver(t)
    def test_count_mismatch_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'events';p.mkdir();(p/'mismatch.json').write_text(json.dumps({'schema':'ripple/ring-golf-event-v1','region_spikes':[1]*8,'ring_spikes':1}))
            with self.assertRaises(ValueError):receiver(t)
    def test_external_program_is_actually_executed(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'events';p.mkdir()
            raw={'schema':'ripple/ring-golf-event-v1','region_spikes':[1]*8,'ring_spikes':8}
            (p/'real.json').write_text(json.dumps(raw));res=receiver(t)
            self.assertEqual(res['events'][0]['spikes'],8)
            self.assertEqual(json.loads((Path(t)/'ring_event_inventory.json').read_text())['total_spikes'],8)

class InheritedExecution(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory();cls.b=Bridge(Path(cls.tmp.name)/'runtime',policy=Policy(threshold=0,allow_external_app=True,allow_code_inspection=True))
    @classmethod
    def tearDownClass(cls):cls.b.close();cls.tmp.cleanup()
    def test_01_legacy_source_parser_reads_real_golf_code(self):
        r=self.b._eyes();self.assertEqual(r['file'],'engine.py');self.assertGreater(r['symbols'],10)
        self.assertEqual(r['sha256'],hashlib.sha256((GOLF_PARENT/'src'/'engine.py').read_bytes()).hexdigest())
    def test_02_end_to_end_video_and_external_execution(self):
        self.assertTrue(FIXTURE.is_file());result=self.b.replay(FIXTURE,max_frames=24)
        self.assertEqual(result['frames'],24);self.assertGreater(result['spikes'],0)
        self.assertGreater(result['events'],0);self.assertEqual(result['errors'],[])
        self.assertEqual(result['events'],result['external_program_runs'])
        self.assertEqual(result['events'],result['eyes_inspections']-1) # standalone code inspection once in prior test
        for event in result['events_detail']:
            self.assertEqual(sum(event['event']['region_spikes']),event['event']['ring_spikes'])
            self.assertEqual(event['audit']['external_application']['exit_code'],0)
        self.__class__.first_run=result
    def test_03_golf_sqlite_jobs_and_receiver_report(self):
        result=self.first_run
        with sqlite3.connect(self.b.golf.db_path) as db:
            jobs=db.execute("SELECT COUNT(*) FROM jobs WHERE status='completed'").fetchone()[0]
            queued=db.execute("SELECT COUNT(*) FROM events WHERE type='job.completed'").fetchone()[0]
        self.assertGreaterEqual(jobs,result['events']*3)
        self.assertGreaterEqual(queued,result['events']*3)
        folder=self.b.golf.workspace
        summary=json.loads((folder/'ring_event_inventory.json').read_text())
        self.assertEqual(len(summary['events']),result['events'])
        self.assertEqual(summary['total_spikes'],sum(e['event']['ring_spikes'] for e in result['events_detail']))
        with sqlite3.connect(self.b.ws.db_path) as db:
            self.assertEqual(db.execute('SELECT COUNT(*) FROM observations').fetchone()[0],24)
    def test_04_approved_app_does_not_mean_arbitrary_execution(self):
        x=self.b.golf.wait(self.b.golf.submit({'op':'app_run','name':'unapproved-program'}),timeout=8)
        self.assertEqual(x['status'],'failed');self.assertIn('not approved',x['error'])
    def test_05_golf_rejects_path_traversal(self):
        x=self.b.golf.wait(self.b.golf.submit({'op':'file_read','path':'../../passwd'}),timeout=8)
        self.assertEqual(x['status'],'failed');self.assertIn('path',x['error'])
    def test_06_inspection_traversal_rejected(self):
        old=self.b.code_filename
        try:
            self.b.code_filename='../outside.py'
            with self.assertRaises(ValueError):self.b._eyes()
        finally:self.b.code_filename=old
    def test_07_frame_timestamp_monotonic_validation(self):
        last=self.b.ws._last_time
        a=np.zeros((32,32,3),dtype=np.uint8)
        with self.assertRaises(ValueError):self.b.process(a,frame_time_s=last-1)
    def test_08_no_physical_camera_is_not_fabricated(self):
        with self.assertRaises(ValueError):self.b.capture(-1,max_frames=1)

class ControlComparisons(unittest.TestCase):
    def test_coupling_does_not_modify_legacy_ring_spikes(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t)
            with Bridge(root/'on',policy=Policy(threshold=0,allow_external_app=False,allow_code_inspection=False)) as b:
                on=b.replay(FIXTURE,max_frames=24)
            with Bridge(root/'off',policy=Policy(threshold=216,min_regions=8,allow_external_app=False,allow_code_inspection=False)) as b:
                off=b.replay(FIXTURE,max_frames=24)
            self.assertEqual(on['spikes'],off['spikes'])
            self.assertEqual([r['ring_spikes'] for r in on['records']],[r['ring_spikes'] for r in off['records']])
            self.assertGreater(on['events'],0);self.assertEqual(off['events'],0)
            self.assertEqual(on['external_program_runs'],0)
    def test_max_events_does_not_disable_ring_processing(self):
        with tempfile.TemporaryDirectory() as t:
            with Bridge(Path(t),policy=Policy(threshold=0,max_events=1)) as b:
                result=b.replay(FIXTURE,max_frames=24)
                self.assertEqual(result['frames'],24)
                self.assertEqual(result['events'],1)
    def test_cooldown_is_enforced(self):
        with tempfile.TemporaryDirectory() as t:
            with Bridge(Path(t),policy=Policy(threshold=0,cooldown_frames=10)) as b:
                result=b.replay(FIXTURE,max_frames=24)
                hits=[e['event']['frame_index'] for e in result['events_detail']]
                self.assertTrue(all(y-x>=10 for x,y in zip(hits,hits[1:])))

if __name__=='__main__':unittest.main()
