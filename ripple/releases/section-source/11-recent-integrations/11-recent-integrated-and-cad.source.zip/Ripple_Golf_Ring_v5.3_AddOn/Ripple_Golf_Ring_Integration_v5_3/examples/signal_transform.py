"""Authorized static inspection target, not a Ring neuron model."""
import math

def normalized_change(previous, current, denominator=255.0):
    if denominator <= 0:
        raise ValueError('denominator')
    return min(1.0,abs(current-previous)/denominator)

def photon_energy(wavelength_nm):
    if wavelength_nm <= 0:
        raise ValueError('wavelength')
    return 6.62607015e-34*299792458.0/(wavelength_nm*1e-9)
