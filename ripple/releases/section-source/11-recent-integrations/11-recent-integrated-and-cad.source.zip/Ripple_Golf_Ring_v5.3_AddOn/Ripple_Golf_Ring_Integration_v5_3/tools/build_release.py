"""Auditable source-preserving release packer; omit generated local runtime credentials."""
from __future__ import annotations
import argparse,hashlib,json,zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
ARCHIVES={
 'Ring_of_Mushrooms_Alpha_v5_0':'/mnt/data/Ring_of_Mushrooms_FieldSphere_Alpha_v5.2_Complete.zip',
 'Golf-Ripple-Dell-Validated-v0.5':'/mnt/data/golf_archive_recovery/Golf-Ripple-Dell-Validated-v0.5-Complete.zip'}
EXCLUDE={'__pycache__','.pytest_cache','.git','runtime_gui','runtime_data','runtime_local','runtime_test','gui_runtime','smoke','build_release_log.json','code_smoke','on','off'}

def readable(p):
    relative=p.relative_to(ROOT)
    return not any(part in EXCLUDE for part in relative.parts) and p.suffix not in {'.pyc','.sqlite3','.sqlite3-shm','.sqlite3-wal'} and p.name!='SHA256_MANIFEST.json' and not p.name.startswith('access-token')

def audit_original():
    records={}
    for name,file in ARCHIVES.items():
        with zipfile.ZipFile(file) as z:
            checked=0
            for info in z.infolist():
                if info.is_dir():continue
                dest=ROOT/'inherited'/info.filename
                if not dest.is_file():raise AssertionError('inherited missing: '+info.filename)
                if hashlib.sha256(z.read(info.filename)).digest()!=hashlib.sha256(dest.read_bytes()).digest():
                    raise AssertionError('original source byte mismatch: '+info.filename)
                checked+=1
        records[name]={'files_matched':checked,'archive_sha256':hashlib.sha256(Path(file).read_bytes()).hexdigest()}
    return records

def pack():
    source=audit_original()
    (ROOT/'results').mkdir(exist_ok=True)
    (ROOT/'results'/'source_audit.json').write_text(json.dumps(source,indent=2))
    included=[p for p in ROOT.rglob('*') if p.is_file() and readable(p) and 'results/source_audit.json' not in str(p)]
    included.append(ROOT/'results'/'source_audit.json')
    manifest={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(included)}
    (ROOT/'SHA256_MANIFEST.json').write_text(json.dumps(manifest,indent=2,sort_keys=True))
    selected=[p for p in ROOT.rglob('*') if p.is_file() and readable(p)]
    selected.append(ROOT/'SHA256_MANIFEST.json')
    root_out=ROOT.parent
    archives={
       root_out/'Ripple_Golf_Ring_v5.3_Complete.zip':selected,
       root_out/'Ripple_Golf_Ring_v5.3_AddOn.zip':[p for p in selected if 'inherited' not in p.relative_to(ROOT).parts]}
    stats={}
    for filename,paths in archives.items():
        with zipfile.ZipFile(filename,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
            for p in paths:z.write(p,arcname='Ripple_Golf_Ring_Integration_v5_3/'+p.relative_to(ROOT).as_posix())
        with zipfile.ZipFile(filename) as z:
            bad=z.testzip()
            if bad:raise AssertionError('zip crc failure: '+bad)
        stats[filename.name]={'bytes':filename.stat().st_size,'members':len(paths)}
    return {'originals':source,'packaged':stats,'manifest_entries':len(manifest)}

if __name__=='__main__':print(json.dumps(pack(),indent=2))
