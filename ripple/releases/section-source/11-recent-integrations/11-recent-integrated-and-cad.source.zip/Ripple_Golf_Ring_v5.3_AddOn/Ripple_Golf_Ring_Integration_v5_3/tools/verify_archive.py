"""Verify complete package SHA256 manifest after ZIP extraction."""
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1] if len(sys.argv)>1 else Path(__file__).resolve().parents[1])
a=json.loads((root/'SHA256_MANIFEST.json').read_text())
for path,h in a.items():
    p=root/path
    if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=h:
        raise SystemExit('SHA256 FAILED: '+path)
print(json.dumps({'verified_files':len(a),'status':'passed'}))
