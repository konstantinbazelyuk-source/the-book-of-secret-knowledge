"""A fixed, approved external Python application operated through Golf's app_run.
Reads immutable event files and writes a separate digest inventory. No source execution.
"""
from __future__ import annotations
import hashlib,json,sys
from pathlib import Path

def run(root):
    root=Path(root).resolve(strict=True)
    folder=root/'events'
    names=sorted(folder.glob('*.json')) if folder.is_dir() else []
    if len(names)>1000:raise ValueError('too many event inputs')
    listing=[]
    for path in names:
        if path.is_symlink() or path.stat().st_size>100_000:raise ValueError('disallowed input')
        data=path.read_bytes();evt=json.loads(data)
        if evt.get('schema')!='ripple/ring-golf-event-v1' or len(evt.get('region_spikes',[]))!=8:
            raise ValueError('unrecognized Ring event schema')
        if not isinstance(evt['ring_spikes'],int) or sum(evt['region_spikes'])!=evt['ring_spikes']:
            raise ValueError('inconsistent Ring spike count')
        listing.append({'filename':path.name,'sha256':hashlib.sha256(data).hexdigest(),
                        'spikes':evt['ring_spikes'],'active_regions':sum(v>0 for v in evt['region_spikes'])})
    result={'schema':'golf/ring-event-inventory-v1','events':listing,'total_spikes':sum(i['spikes'] for i in listing),
            'application':'trusted_receiver','scope':'file/digest inspection only'}
    report=root/'ring_event_inventory.json';report.write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({'processed':len(listing),'inventory_sha256':hashlib.sha256(report.read_bytes()).hexdigest()}))
    return result

if __name__=='__main__':
    if len(sys.argv)!=2:raise SystemExit('usage: trusted_receiver.py WORKSPACE')
    run(sys.argv[1])
