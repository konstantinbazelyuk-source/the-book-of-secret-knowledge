"""Runnable entry point for Golf × Ring, with explicit external-action consent."""
import argparse, json, os
from pathlib import Path
from .runtime import Bridge,Policy,PACKAGE,RING_PARENT

DEFAULT_VIDEO=RING_PARENT/'results_v5'/'synthetic_sync_fixture'/'simulated_camera.avi'

def main(argv=None):
    p=argparse.ArgumentParser(description='Golf × Ring operational connection')
    p.add_argument('operation',nargs='?',choices=['replay','camera','inspect'],default='replay')
    p.add_argument('--video',type=Path,default=DEFAULT_VIDEO)
    p.add_argument('--runtime',type=Path,default=PACKAGE/'runtime_data')
    p.add_argument('--frames',type=int,default=48)
    p.add_argument('--device',type=int,default=0)
    p.add_argument('--spike-threshold',type=int,default=4)
    p.add_argument('--min-regions',type=int,default=2)
    p.add_argument('--cooldown',type=int,default=3)
    p.add_argument('--max-events',type=int,default=10)
    p.add_argument('--external-app',action='store_true',help='opt in to executing bundled allowlisted receiver')
    p.add_argument('--inspect-code',action='store_true',help='opt in to inheriting Golf Digital Eyes parser')
    p.add_argument('--no-marker-filter',action='store_true')
    p.add_argument('--out',type=Path)
    args=p.parse_args(argv)
    pol=Policy(threshold=args.spike_threshold,min_regions=args.min_regions,require_spike_marker=not args.no_marker_filter,
               cooldown_frames=args.cooldown,max_events=args.max_events,allow_external_app=args.external_app,
               allow_code_inspection=args.inspect_code)
    with Bridge(args.runtime,policy=pol) as b:
        if args.operation=='inspect':
            r=b._eyes();print(json.dumps(r,indent=2));return r
        if args.operation=='camera':r=b.capture(args.device,max_frames=args.frames)
        else:r=b.replay(args.video,max_frames=args.frames)
    if args.out:
        args.out.parent.mkdir(parents=True,exist_ok=True)
        args.out.write_text(json.dumps(r,indent=2),encoding='utf-8')
    brief={k:v for k,v in r.items() if k not in ('events_detail','records')}
    print(json.dumps(brief,indent=2))
    if r['errors']:raise SystemExit('Bridge execution contained failures; inspect --out records')
    return r

if __name__=='__main__':main()
