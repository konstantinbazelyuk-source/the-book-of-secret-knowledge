"""Ripple Ring v5.2 -> inherited Golf v0.5 and Digital Eyes v0.2.
This is executable software integration; model spikes are numerical events.
Sources remain immutable under inherited/. No arbitrary command construction.
"""
from __future__ import annotations
from dataclasses import dataclass
import hashlib, json, math, os, re, sqlite3, subprocess, sys, time, uuid
from pathlib import Path
import cv2
import numpy as np

PACKAGE = Path(__file__).resolve().parent.parent
RING_PARENT = PACKAGE/'inherited'/'Ring_of_Mushrooms_Alpha_v5_0'
GOLF_PARENT = PACKAGE/'inherited'/'Golf-Ripple-Dell-Validated-v0.5'
EYES_PARENT = GOLF_PARENT/'parents'/'Golf-Ripple-Metrology-Engine-v0.3'/'parents'/'Golf-Ripple-Digital-Eyes-v0.2'

@dataclass(frozen=True)
class Policy:
    threshold: int = 4
    min_regions: int = 2
    require_spike_marker: bool = True
    cooldown_frames: int = 3
    max_events: int = 10
    allow_external_app: bool = False
    allow_code_inspection: bool = False
    def __post_init__(self):
        if type(self.threshold)!=int or not 0<=self.threshold<=216:raise ValueError('invalid spike threshold')
        if type(self.min_regions)!=int or not 1<=self.min_regions<=8:raise ValueError('invalid region requirement')
        if type(self.cooldown_frames)!=int or not 0<=self.cooldown_frames<=10000:raise ValueError('invalid cooldown')
        if type(self.max_events)!=int or not 1<=self.max_events<=1000:raise ValueError('invalid event limit')
        if not all(type(v) is bool for v in (self.require_spike_marker,self.allow_external_app,self.allow_code_inspection)):
            raise ValueError('flags must be boolean')

class Bridge:
    def __init__(self, runtime_dir:Path, *, policy:Policy=Policy(), fps:int=15, seed:int=101,
                 code_filename:str='src/engine.py'):
        # Inherited paths are inserted ONLY to import source without editing its contents.
        for parent in (GOLF_PARENT,RING_PARENT):
            if str(parent) not in sys.path:sys.path.insert(0,str(parent))
        from src.engine import Engine
        from workstation.engine import Workstation
        self.dir=Path(runtime_dir).resolve(); self.dir.mkdir(parents=True,exist_ok=True)
        self.policy=policy
        self.ws=Workstation(self.dir/'observations.sqlite',fps=fps,seed=seed)
        config={'queue_size':16,'gpu_probe':False,'autoscale_from_benchmark':False,'approved_apps':{
             'ring-event-receiver':{'executable':sys.executable,
                                    'arguments':[str(PACKAGE/'tools'/'trusted_receiver.py'),str((self.dir/'golf'/'workspace').resolve())]}}}
        self.golf=Engine(base_dir=self.dir/'golf',workers=1,config=config)
        self.frame_index=0;self.last_fire=-10**9;self.events=[];self.errors=[]
        self.code_filename=code_filename
        self.eyes_workspace=GOLF_PARENT
        self.external_runs=0
        self.eyes_runs=0
        self.closed=False

    def _job(self, payload,timeout=12):
        j=self.golf.submit(payload)
        result=self.golf.wait(j,timeout=timeout)
        if result is None or result['status']!='completed':
            raise RuntimeError('Golf job failed: '+str(result.get('error') if result else 'missing result'))
        return result

    def _eyes(self):
        if (not re.fullmatch(r'[A-Za-z0-9_.-]+(?:/[A-Za-z0-9_.-]+){0,5}\.(?:py|js|mjs|ts|tsx)',self.code_filename)
                or '..' in Path(self.code_filename).parts):
            raise ValueError('approved relative code filename required')
        cmd=[sys.executable,str(EYES_PARENT/'src'/'eyes.py'),str(self.eyes_workspace)]
        p=subprocess.run(cmd,input=json.dumps({'mode':'code','file':self.code_filename}),text=True,capture_output=True,
                         timeout=10,check=False,shell=False)
        if p.returncode!=0:raise RuntimeError('Digital Eyes error: '+p.stdout[-280:]+p.stderr[-120:])
        o=json.loads(p.stdout)
        if not o.get('ok') or not o['result']['observation'].get('syntaxValid'):
            raise RuntimeError('Digital Eyes source syntax invalid')
        self.eyes_runs+=1
        return {'file':o['result']['file'],'sha256':o['result']['sha256'],
                'symbols':len(o['result']['observation']['symbols']),
                'imports':o['result']['observation']['imports'],
                'parser':'inherited_Golf_Digital_Eyes_v0.2'}

    def process(self, bgr:np.ndarray, *, frame_time_s:float, source='video_file'):
        if self.closed:raise RuntimeError('bridge closed')
        from workstation.engine import FramePacket
        before=len(self.ws.ring.history)
        snap=self.ws.process(FramePacket(bgr,frame_time_s,source))
        rec=self.ws.ring.history[-1]
        if len(self.ws.ring.history)!=before+1:raise RuntimeError('Ring step failed')
        i=self.frame_index;self.frame_index+=1
        count=int(rec['spikes_total']);regions=int(np.count_nonzero(rec['counts']))
        eligible=(count>=self.policy.threshold and regions>=self.policy.min_regions and
                  (not self.policy.require_spike_marker or rec['spike_marker']) and
                  i-self.last_fire>=self.policy.cooldown_frames and len(self.events)<self.policy.max_events)
        result={'index':i,'ring_spikes':count,'active_regions':regions,'marker':bool(rec['spike_marker']),
                'phase_order':float(rec['phase_order']),'golf_triggered':False,
                'frame_sha256':snap['frame_sha256'],'source':source}
        if not eligible:return result
        evt={'schema':'ripple/ring-golf-event-v1','frame_index':i,'session_id':self.ws.session_id,
             'frame_sha256':snap['frame_sha256'],'source':source,'ring_spikes':count,'region_spikes':list(map(int,rec['counts'])),
             'phase_order':float(rec['phase_order']),'spike_marker':bool(rec['spike_marker']),
             'recorded_monotonic_s':float(frame_time_s),'evidence':'executed_model_from_'+source}
        text=json.dumps(evt,sort_keys=True,separators=(',',':'))
        rel=f'events/{self.ws.session_id}_{i:06d}.json'
        try:
            jr=self._job({'op':'file_write','path':rel,'content':text})
            wrote=jr['result']['data']
            digest=self._job({'op':'file_digest','path':rel})['result']['data']['sha256']
            if digest!=hashlib.sha256(text.encode()).hexdigest() or digest!=wrote['sha256']:
                raise RuntimeError('Golf workspace event digest mismatch')
            audit={'file':rel,'sha256':digest,'job_file_write':jr['id']}
            if self.policy.allow_external_app:
                # Only fixed user-approved binary + arguments configured in Golf Engine.
                report=self._job({'op':'app_run','name':'ring-event-receiver'},timeout=20)
                if report['result']['data']['exit_code']!=0:raise RuntimeError('approved program exit code nonzero')
                audit['external_application']={'job_id':report['id'],'exit_code':0}
                self.external_runs+=1
            if self.policy.allow_code_inspection:
                audit['eyes']=self._eyes()
            self.last_fire=i; self.events.append({'event':evt,'audit':audit})
            result['golf_triggered']=True
            result['golf_audit']=audit
        except Exception as err:
            self.errors.append({'frame_index':i,'error':type(err).__name__+': '+str(err)[:500]})
            result['golf_error']=self.errors[-1]['error']
        return result

    def replay(self, path:Path, *, max_frames:int=48):
        if not (1<=max_frames<=20000):raise ValueError('bounded frame limit required')
        video=Path(path)
        cap=cv2.VideoCapture(str(video))
        if not cap.isOpened():raise FileNotFoundError('video failed to open: '+str(video))
        fps=cap.get(cv2.CAP_PROP_FPS)
        if not math.isfinite(fps) or not 1<=fps<=120:cap.release();raise ValueError('invalid FPS')
        records=[]; start=time.monotonic()
        try:
            for i in range(max_frames):
                ok,frame=cap.read()
                if not ok:break
                records.append(self.process(frame,frame_time_s=start+i/fps))
        finally:cap.release()
        if not records:raise ValueError('no video frames decoded')
        return {'frames':len(records),'events':len(self.events),'external_program_runs':self.external_runs,
                'eyes_inspections':self.eyes_runs,'errors':list(self.errors),
                'spikes':sum(x['ring_spikes'] for x in records),
                'events_detail':self.events,'records':records,
                'video_sha256':hashlib.sha256(video.read_bytes()).hexdigest(),
                'video_type':'source_file_not_attested_physical'}

    def capture(self, camera_index:int, *, max_frames:int=48, fps:float=15.0):
        if type(camera_index)!=int or not 0<=camera_index<=8:
            raise ValueError('camera index 0..8 required')
        if not 1<=max_frames<=20000 or not 1<=fps<=60:
            raise ValueError('capture bounds invalid')
        cap=cv2.VideoCapture(camera_index)
        if not cap.isOpened():
            cap.release()
            raise RuntimeError('physical camera could not be opened; no frames substituted')
        records=[]; next_sample=0.
        try:
            while len(records)<max_frames:
                ok,frame=cap.read()
                timestamp=time.monotonic()
                if not ok:raise RuntimeError('live camera stopped returning frames')
                if timestamp<next_sample:continue
                records.append(self.process(frame,frame_time_s=timestamp,source='usb_camera'))
                next_sample=timestamp+1/fps
        finally:cap.release()
        return {'frames':len(records),'events':len(self.events),'external_program_runs':self.external_runs,
                'eyes_inspections':self.eyes_runs,'errors':list(self.errors),
                'spikes':sum(r['ring_spikes'] for r in records),
                'events_detail':self.events,'records':records,
                'video_type':'requested_live_camera_readings_not_independently_calibrated'}

    def close(self):
        if not self.closed:
            self.closed=True
            try:self.ws.close()
            finally:self.golf.close()

    def __enter__(self):return self
    def __exit__(self,*args):self.close()
