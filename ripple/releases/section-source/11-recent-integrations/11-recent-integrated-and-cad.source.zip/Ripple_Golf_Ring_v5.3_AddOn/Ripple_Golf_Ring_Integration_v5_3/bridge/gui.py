"""Actual interactive Tk workstation for inherited Ring+Golf runtime."""
from __future__ import annotations
import json,threading,queue,tkinter as tk
from tkinter import filedialog,ttk,messagebox
from pathlib import Path
from .runtime import Bridge,Policy,PACKAGE,RING_PARENT

class WorkstationUI(tk.Tk):
    def __init__(self):
        super().__init__();self.title('Ripple Ring × Golf — Software Interface');self.geometry('750x590')
        self.video=tk.StringVar(value=str(RING_PARENT/'results_v5'/'synthetic_sync_fixture'/'simulated_camera.avi'))
        self.frames=tk.IntVar(value=48);self.threshold=tk.IntVar(value=4);self.external=tk.BooleanVar(value=False)
        self.eyes=tk.BooleanVar(value=False);self.camera=tk.BooleanVar(value=False);self.status=tk.StringVar(value='Ready — external program execution disabled')
        self.messages=queue.Queue();self.running=False;self.last=None
        frm=ttk.Frame(self,padding=15);frm.pack(fill='both',expand=True)
        ttk.Label(frm,text='Camera input or recorded video → 216-neuron Ring → Golf jobs',font=('TkDefaultFont',12,'bold')).pack(anchor='w')
        row=ttk.Frame(frm);row.pack(fill='x',pady=8)
        ttk.Entry(row,textvariable=self.video).pack(side='left',expand=True,fill='x')
        ttk.Button(row,text='Choose video',command=self.choose).pack(side='left',padx=6)
        for label,var in [('Use camera 0 (hardware required)',self.camera),('Permit allowlisted external program',self.external),('Enable Digital Eyes code inspection',self.eyes)]:
            ttk.Checkbutton(frm,text=label,variable=var).pack(anchor='w')
        row=ttk.Frame(frm);row.pack(fill='x',pady=6)
        ttk.Label(row,text='Max frames').pack(side='left');ttk.Spinbox(row,from_=1,to=2000,textvariable=self.frames,width=7).pack(side='left',padx=10)
        ttk.Label(row,text='Spike threshold').pack(side='left');ttk.Spinbox(row,from_=0,to=216,textvariable=self.threshold,width=7).pack(side='left',padx=10)
        self.start_button=ttk.Button(frm,text='Run verified Ring → Golf integration',command=self.start);self.start_button.pack(anchor='w',pady=8)
        ttk.Label(frm,textvariable=self.status,wraplength=695).pack(anchor='w',pady=6)
        self.output=tk.Text(frm,height=19,state='disabled',wrap='word');self.output.pack(fill='both',expand=True)
        self.after(120,self.poll)
    def choose(self):
        file=filedialog.askopenfilename(filetypes=[('Video','*.avi *.mp4 *.mov *.mkv'),('All','*.*')])
        if file:self.video.set(file)
    def start(self):
        if self.running:return
        try:
            pol=Policy(threshold=self.threshold.get(),allow_external_app=self.external.get(),allow_code_inspection=self.eyes.get())
            frames=self.frames.get();video=Path(self.video.get());camera=self.camera.get()
            if not 1<=frames<=2000:raise ValueError('frame limit 1..2000')
            if not camera and not video.is_file():raise FileNotFoundError('video not found')
        except Exception as e:
            messagebox.showerror('Invalid input',str(e));return
        self.running=True;self.start_button.configure(state='disabled');self.status.set('Running actual Ring/Golf software...')
        def worker():
            try:
                with Bridge(PACKAGE/'runtime_gui',policy=pol) as b:
                    r=b.capture(0,max_frames=frames) if camera else b.replay(video,max_frames=frames)
                self.messages.put(('done',r))
            except Exception as e:self.messages.put(('error',str(e)))
        threading.Thread(target=worker,daemon=True).start()
    def poll(self):
        while not self.messages.empty():
            kind,data=self.messages.get_nowait();self.running=False;self.start_button.configure(state='normal')
            if kind=='error':self.status.set('FAILED: '+data)
            else:
                self.last=data;self.status.set(f"Complete: {data['frames']} frames; {data['events']} Golf events; {data['external_program_runs']} external runs; {data['eyes_inspections']} Digital Eyes inspections")
                report={k:v for k,v in data.items() if k not in ('records','events_detail')}
                report['first_event']=data['events_detail'][:1]
                self.output.configure(state='normal');self.output.delete('1.0','end');self.output.insert('end',json.dumps(report,indent=2));self.output.configure(state='disabled')
        self.after(120,self.poll)

def main():WorkstationUI().mainloop()
if __name__=='__main__':main()
