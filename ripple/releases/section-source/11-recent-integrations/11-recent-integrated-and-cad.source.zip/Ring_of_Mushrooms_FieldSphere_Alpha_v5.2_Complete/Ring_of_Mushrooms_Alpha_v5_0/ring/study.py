"""Fifty independently seeded paired runs on archived synthetic video.
No measured EEG or calibrated photon data."
"""
from __future__ import annotations
import csv,json,time
from pathlib import Path
import cv2,numpy as np
from .core import Ring,RingParameters,model_signature
ROOT=Path(__file__).resolve().parents[1]
V=ROOT/'parents/Mushroom_Ripple_Alpha_v3_0/vendor/v24/Master_Ripple_Camera_Alpha_v2_1'
SCENES=[V/'cluster_results/replay_seed13.avi',V/'cluster_results/holdout_geometry.avi']
def read_scene(path,count=24):
    cap=cv2.VideoCapture(str(path))
    if not cap.isOpened():raise RuntimeError('fixture missing: '+str(path))
    frames=[]
    try:
        for _ in range(count):
            ok,frame=cap.read()
            if not ok:raise RuntimeError('truncated fixture')
            frames.append(frame)
    finally:cap.release()
    return frames

def paired(seed,frames, *, recurrent):
    settings=RingParameters(fps=24,slider=.8,coupling=.5,
                 recurrent=recurrent,allow_photon_proxy=True,plasticity=.015)
    ring=Ring(settings,seed=seed)
    t=time.perf_counter()
    report=ring.run_frames(frames)
    report['cpu_wall_elapsed_s']=time.perf_counter()-t
    report['model_signature']=model_signature(ring.history,24)
    return report,ring

def study(output:Path=ROOT/'results',n=50,steps=24):
    if not 1<=n<=1000 or not 8<=steps<=100:raise ValueError('bounded experiment')
    output.mkdir(parents=True,exist_ok=True)
    scenarios=[read_scene(s,steps) for s in SCENES]
    rows=[];exemplar=None
    t0=time.perf_counter()
    for j in range(n):
        seed=1000+j;scenario=j%2;frames=scenarios[scenario]
        connected,rg=paired(seed,frames,recurrent=True)
        isolated,_=paired(seed,frames,recurrent=False)
        def scalar(v):return {'spikes_total':v['spikes_total'],'markers':v['markers'],
             'end_active_cells':v['end_active_cells'],'delivered_pulses':v['delivered_pulses'],
             'phase_order':v['mean_phase_order'],'cpu_wall_s':v['cpu_wall_elapsed_s']}
        row={'replicate':j,'seed':seed,'scenario':scenario,'source_type':'synthetic_decoded_video_with_poisson_proxy'}
        for mode,summary in [('ring',scalar(connected)),('isolated',scalar(isolated))]:
            for key,v in summary.items():row[mode+'_'+key]=v
        row['difference_spikes']=connected['spikes_total']-isolated['spikes_total']
        row['difference_phase_order']=connected['mean_phase_order']-isolated['mean_phase_order']
        row['difference_active_cells']=connected['end_active_cells']-isolated['end_active_cells']
        rows.append(row)
        if j==0:exemplar={'summary':connected,'history':rg.history,'model_signature':connected['model_signature']}
        if (j+1)%10==0:print('Replicates:',j+1,'/',n,'elapsed seconds',round(time.perf_counter()-t0,1),flush=True)
    with (output/'replicates.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    diffs=np.array([r['difference_spikes'] for r in rows],dtype=float)
    pdiffs=np.array([r['difference_phase_order'] for r in rows],dtype=float)
    rng=np.random.default_rng(8006)
    boot=np.mean(rng.choice(diffs,(3000,n),replace=True),axis=1)
    phase_boot=np.mean(rng.choice(pdiffs,(3000,n),replace=True),axis=1)
    summary={'status':'executed_synthetic_research','paired_replicates':n,'executed_full_ring_runs':n*2,
             'total_computed_frame_updates':n*2*steps,'mushroom_calls':n*2*steps*8,
             'charlie_neuron_steps_nominal':n*2*steps*8*27,
             'distinct_archived_scenes':len(scenarios),'scenario_types':'previously authored synthetic videos, not physical camera captures',
             'poisson_note':'synthetic shot-noise proxy on 8-bit values, NOT counted photons',
             'ring_mean_spikes':float(np.mean([r['ring_spikes_total'] for r in rows])),
             'isolated_mean_spikes':float(np.mean([r['isolated_spikes_total'] for r in rows])),
             'mean_spike_difference':float(np.mean(diffs)),
             'exploratory_paired_bootstrap_95_percent_spikes':np.quantile(boot,[.025,.975]).tolist(),
             'ring_mean_phase_order':float(np.mean([r['ring_phase_order'] for r in rows])),
             'isolated_mean_phase_order':float(np.mean([r['isolated_phase_order'] for r in rows])),
             'mean_phase_order_difference':float(np.mean(pdiffs)),
             'exploratory_paired_bootstrap_95_percent_phase':np.quantile(phase_boot,[.025,.975]).tolist(),
             'ring_mean_active_cells':float(np.mean([r['ring_end_active_cells'] for r in rows])),
             'isolated_mean_active_cells':float(np.mean([r['isolated_end_active_cells'] for r in rows])),
             'ring_mean_markers':float(np.mean([r['ring_markers'] for r in rows])),
             'isolated_mean_markers':float(np.mean([r['isolated_markers'] for r in rows])),
             'ring_mean_elapsed_s':float(np.mean([r['ring_cpu_wall_s'] for r in rows])),
             'isolated_mean_elapsed_s':float(np.mean([r['isolated_cpu_wall_s'] for r in rows])),
             'measured_wall_seconds':time.perf_counter()-t0,
             'limitation':'Within two synthetic scene generators; exploratory intervals do not establish population generalization. Brainwave names denote bands of software spikes only.'}
    (output/'study_summary.json').write_text(json.dumps(summary,indent=2))
    (output/'exemplar_recording.json').write_text(json.dumps(exemplar,indent=2))
    print(json.dumps(summary,indent=2),flush=True)
    return summary
if __name__=='__main__':study()
