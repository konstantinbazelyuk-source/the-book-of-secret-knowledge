"""Optional ACTUAL EEG/ECG-like data reader: CSV time_s + numeric uV channels.
Only a format-and-spectrum interface. No brain state diagnosis or inference.
"""
from __future__ import annotations
import csv,math
from pathlib import Path
import numpy as np
from scipy.signal import welch

BANDS={'delta':(0.5,4),'theta':(4,8),'alpha':(8,13),'beta':(13,30),'gamma':(30,80)}

def eeg_signature(times_s,channels_uv,*,source='external_eeg_csv',channel_labels=None):
    if source!='external_eeg_csv':raise ValueError('no unverified signal provenance')
    t=np.asarray(times_s,dtype=float);x=np.asarray(channels_uv,dtype=float)
    if t.ndim!=1 or x.ndim!=2 or x.shape[0]!=len(t) or len(t)<64 or not np.all(np.isfinite(t)) or not np.all(np.isfinite(x)):
        raise ValueError('valid finite 2D channels and >=64 timestamps required')
    dt=np.diff(t)
    if np.any(dt<=0) or np.std(dt)/np.mean(dt)>0.01:
        raise ValueError('time stamps not monotonic or not close to uniform sampling')
    fs=1/np.mean(dt)
    if not 8<=fs<=10000 or t[-1]-t[0]<2:
        raise ValueError('need >=2 seconds of meaningful sampling')
    labels=channel_labels or [f'ch{i}' for i in range(x.shape[1])]
    if len(labels)!=x.shape[1] or len(labels)>128:raise ValueError('invalid channel labeling')
    f,p=welch(x,fs=fs,axis=0,nperseg=min(len(t),int(fs*4)),detrend='constant')
    bandpowers={}
    for k,(lo,hi) in BANDS.items():
        if hi>fs/2 or not np.any((f>=lo)&(f<hi)):
            bandpowers[k]={'status':'unresolvable','per_channel_uv_squared':None}
        else:
            vals=np.trapezoid(p[(f>=lo)&(f<hi)],f[(f>=lo)&(f<hi)],axis=0)
            bandpowers[k]={'status':'calculated','per_channel_uv_squared':vals.tolist()}
    return {'schema':'ripple/ring/external_eeg_signature_1','origin':source,
            'interpretation':'Signal spectrum only; no diagnosis or verified cortical source',
            'sample_rate_hz':fs,'duration_s':float(t[-1]-t[0]),'channels':labels,'bandpowers':bandpowers}

def eeg_csv(path: str):
    p=Path(path)
    with p.open(newline='') as f:
        reader=csv.DictReader(f)
        if reader.fieldnames is None or 'time_s' not in reader.fieldnames or len(reader.fieldnames)<2:raise ValueError('time_s and one or more numeric channels required')
        names=[c for c in reader.fieldnames if c!='time_s']
        rows=list(reader)
    if len(rows)>2_000_000:raise ValueError('bounded EEG file')
    return eeg_signature([float(r['time_s']) for r in rows],[[float(r[n]) for n in names] for r in rows],channel_labels=names)

if __name__=='__main__':
    import argparse,json
    a=argparse.ArgumentParser(description='Compute frequency-band power from an externally supplied, labeled EEG CSV; not camera EEG')
    a.add_argument('--csv',required=True);a.add_argument('--out',default='results/external_eeg_signature.json')
    args=a.parse_args()
    summary=eeg_csv(args.csv)
    output=Path(args.out);output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2))

def aligned_eeg_drive(path:str,*,fps:int,steps:int,channel:str|None=None)->list[float]:
    """Anti-aliased, time-aligned external EEG µV into the video-domain input clock.
    Requires declared volts, sampling and units; never infers EEG from RGB.
    """
    from scipy.signal import butter,sosfiltfilt
    p=Path(path)
    with p.open(newline='') as f:
        rd=csv.DictReader(f)
        if not rd.fieldnames or 'time_s' not in rd.fieldnames:raise ValueError('time_s required')
        channel=channel or next((x for x in rd.fieldnames if x!='time_s'),None)
        if channel is None or channel not in rd.fieldnames:raise ValueError('EEG channel missing')
        rows=list(rd)
    tt=np.array([float(r['time_s']) for r in rows]);xx=np.array([float(r[channel]) for r in rows])
    eeg_signature(tt,xx[:,None],channel_labels=[channel])
    desired=np.arange(steps)/fps
    if len(tt)<8 or desired[-1]>tt[-1] or desired[0]<tt[0]:raise ValueError('EEG time range does not cover imaging frames')
    source_fs=1/np.mean(np.diff(tt))
    if source_fs>fps*1.1:
        cutoff=min(.40*fps,.45*source_fs)
        xx=sosfiltfilt(butter(3,cutoff,fs=source_fs,output='sos'),xx)
    return np.interp(desired,tt,xx).tolist()
