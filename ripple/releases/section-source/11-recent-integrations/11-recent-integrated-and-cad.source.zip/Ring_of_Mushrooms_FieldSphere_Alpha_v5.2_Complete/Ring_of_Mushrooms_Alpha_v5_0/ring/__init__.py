"""Ring of Mushrooms Alpha 4.0 — actual inherited Mushroom v3 populations."""
