"""Ring of Mushroom v4.0: executing genuine v3.0 Mushroom colonies.
A delayed inter-colony spike -> conductance path with independent phase
oscillators. Optical features are derived image measurements, not EEG.
This is a classical, deterministic stochastic simulation when noise is requested.
"""
from __future__ import annotations
import hashlib, json, math, sys
from dataclasses import dataclass
from pathlib import Path
from collections import defaultdict
import numpy as np
import cv2

ROOT=Path(__file__).resolve().parents[1]
PARENT=ROOT/'parents'/'Mushroom_Ripple_Alpha_v3_0'
sys.path.insert(0,str(PARENT))
from mushroom.core import Mushroom,COORDS,marker

ROLES=('red','green','blue','motion','texture','luminance','shadow','alphabet')
C=299792458.0
H=6.62607015e-34


def photon_energy_j(wavelength_nm:float)->float:
    if not math.isfinite(wavelength_nm) or not 100<=wavelength_nm<=100000:
        raise ValueError('wavelength must be 100..100000 nm')
    return H*C/(wavelength_nm*1e-9)


def poisson_camera_proxy(frame:np.ndarray, rng:np.random.Generator, photons_per_white:float=200.0)->np.ndarray:
    """A SYNTHETIC photoelectron-count *proxy* from display-referred 8-bit RGB;
    not physical calibrated photon flux. Poisson variance follows known statistics.
    Input data remain classified as simulated perturbations of decoded pixels.
    """
    if not isinstance(frame,np.ndarray) or frame.dtype!=np.uint8 or frame.ndim!=3 or frame.shape[2]!=3:
        raise ValueError('uint8 BGR required')
    if not 1<=photons_per_white<=100000:raise ValueError('count proxy outside bounds')
    expectation=(frame.astype(float)/255.)*photons_per_white
    counts=rng.poisson(expectation)
    return np.clip(np.rint(counts/photons_per_white*255),0,255).astype(np.uint8)


def specialized_frame(frame:np.ndarray,role:str,previous:np.ndarray|None,history:np.ndarray|None)->np.ndarray:
    if frame.dtype!=np.uint8 or frame.ndim!=3 or frame.shape[2]!=3 or min(frame.shape[:2])<24:
        raise ValueError('BGR uint8 frame >= 24x24 needed')
    if role not in ROLES:raise ValueError('unregistered region role')
    if role in ('red','green','blue'):
        a=np.zeros_like(frame);channel={'blue':0,'green':1,'red':2}[role];a[:,:,channel]=frame[:,:,channel];return a
    if role=='motion':
        gray=np.zeros(frame.shape[:2],dtype=np.uint8) if previous is None else cv2.absdiff(cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY),cv2.cvtColor(previous,cv2.COLOR_BGR2GRAY))
    elif role=='texture':
        g=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
        dx=cv2.Sobel(g,cv2.CV_32F,1,0);dy=cv2.Sobel(g,cv2.CV_32F,0,1)
        gray=np.clip(np.sqrt(dx*dx+dy*dy),0,255).astype(np.uint8)
    elif role=='luminance':gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
    elif role=='shadow':gray=255-cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
    else:return frame.copy()  # alphabet uses unmodified light data
    return cv2.cvtColor(gray,cv2.COLOR_GRAY2BGR)

@dataclass(frozen=True)
class RingParameters:
    colonies:int=8
    fps:int=24
    slider:float=.65
    coupling:float=.4
    omega_hz:float=1.1
    delay_steps:int=1
    recurrent:bool=True
    optical_alphabet:bool=True
    allow_photon_proxy:bool=False
    plasticity:float=.012
    def __post_init__(self):
        if self.colonies!=8:raise ValueError('8 supported specialized regions needed')
        if not 8<=self.fps<=60 or not 0<=self.slider<=1 or not 0<=self.coupling<=1 or not .15<=self.omega_hz<=5 or not 1<=self.delay_steps<=4 or not 0<=self.plasticity<=.05:
            raise ValueError('ring parameters out of bounds')

class Ring:
    """8 independent inherited 27-cell Mushrooms (216 cells), 8*108 internal
    directed edges plus a delayed 16-edge ring. Cross-region emissions directly
    increment Charlie conductance of recipient central neuron, NOT image RGB.
    The legacy Mushroom source is imported byte-for-byte unchanged.
    """
    def __init__(self,parameters:RingParameters=RingParameters(), *, seed:int=101):
        self.p=parameters;self.seed=int(seed);self.rng=np.random.default_rng(seed)
        self.children=[Mushroom(['prism','canopy','ember','violet'][i%4],seed=seed+i,recurrent=True,growth=True) for i in range(8)]
        self.phase=np.array([2*np.pi*((i+.17*self.rng.random())/8.) for i in range(8)])
        self.natural=2*np.pi*(parameters.omega_hz+np.linspace(-.18,.18,8))
        self.weights={(i,(i+direction)%8):.20 for i in range(8) for direction in (-1,1)}
        self.queue=defaultdict(list);self.previous=None;self.history=[]
        self.delivered_total=0;self.generated_total=0;self._marked=-999
        self._prev_counts=np.zeros(8,dtype=int)
    def step(self,frame:np.ndarray, *, text:str='',source_type:str='decoded_video',eeg_drive_uv:float|None=None):
        t=len(self.history);p=self.p
        if source_type not in ('decoded_video','physical_camera','synthetic_frame'):raise ValueError('source_type required')
        if not isinstance(text,str) or len(text)>64:raise ValueError('bounded text only')
        if eeg_drive_uv is not None and (not isinstance(eeg_drive_uv,(int,float)) or not math.isfinite(eeg_drive_uv) or abs(eeg_drive_uv)>500):
            raise ValueError('bounded finite external EEG microvolt signal required')
        if p.allow_photon_proxy:frame=poisson_camera_proxy(frame,self.rng)
        if self.previous is not None and self.previous.shape!=frame.shape:raise ValueError('changing camera resolution not allowed')
        arriving=self.queue.pop(t,[])
        incoming=np.zeros(8,dtype=int)
        if p.recurrent:
            for src,dst,amount in arriving:
                incoming[dst]+=amount
        actual=np.minimum(8,np.rint(incoming*p.slider).astype(int))
        for i,count in enumerate(actual):
            if count:
                # Ring events enter the real inherited Charlie conductance state.
                # This is equivalent to the documented spike-driven conductance jump.
                target=self.children[i].neurons[13]
                target.exc=min(target.params.max_synaptic_conductance,
                               target.exc+int(count)*target.params.recurrent_exc_pulse)
        self.delivered_total+=int(actual.sum())
        eeg_pulse=0
        if eeg_drive_uv is not None:
            # DATA INTERFACE: EEG electrical amplitude is not light.
            # Map signed user-provided microvolts into up to 4 native Charlie pulses.
            eeg_pulse=min(4,int(round(abs(eeg_drive_uv)/25.0)))
            target=self.children[7].neurons[13]
            if eeg_drive_uv>=0:
                target.exc=min(target.params.max_synaptic_conductance,target.exc+eeg_pulse*target.params.recurrent_exc_pulse)
            else:
                target.inh=min(target.params.max_synaptic_conductance,target.inh+eeg_pulse*target.params.recurrent_inh_pulse)
        record=[]
        for i,(role,m) in enumerate(zip(ROLES,self.children)):
            derived=specialized_frame(frame,role,self.previous,None)
            report=m.step(derived,dt=1/p.fps,letters=text if role=='alphabet' else '',
                          optical_alphabet=p.optical_alphabet and role=='alphabet')
            record.append({'role':role,'spikes':int(report['spike_sum']),
                           'active':int(report['active_count']),'gateway_exc':round(float(m.neurons[13].exc),8),
                           'xyz_spike_positions':report['xyz_active'],'optical_symbol':report['optical_symbol'],
                           'delivered_ring_pulses':int(actual[i])})
        counts=np.array([v['spikes'] for v in record])
        # Coupled oscillator phase is a model variable distinct from spike signals.
        last=self.phase.copy();dt=1/p.fps
        for i in range(8):
            near=[(i-1)%8,(i+1)%8]
            kur=sum(math.sin(last[j]-last[i]) for j in near)/2
            burst=float(min(int(counts[i]),4))/4
            self.phase[i]=(last[i]+dt*(self.natural[i]+(p.coupling if p.recurrent else 0.0)*kur+0.25*burst))%(2*math.pi)
        order=float(abs(np.exp(1j*self.phase).mean()))
        # Actual ring graph propagation: delayed and bounded; no same-step delivery.
        if p.recurrent:
            for i,num in enumerate(counts):
                if num>0:
                    for dst in ((i-1)%8,(i+1)%8):
                        pulse=min(4,max(1,int(np.rint(min(int(num),8)*self.weights[(i,dst)]*2))))
                        self.queue[t+p.delay_steps].append((i,dst,pulse))
                        self.generated_total+=pulse
        if p.recurrent and p.plasticity:
            # Lagged, bounded coactivity, not a biological STDP claim.
            for (src,dst),old in list(self.weights.items()):
                corr=int(self._prev_counts[src]>0)*int(counts[dst]>0)
                self.weights[(src,dst)]=max(.05,min(.45,old+p.plasticity*(corr-.12*old)))
        self._prev_counts=counts.copy()
        # Adaptive spike marker; not genetic mutation or psychological state.
        spike_total=int(counts.sum())
        marked=(spike_total>=4 and int(np.count_nonzero(counts))>=2 and t-self._marked>=3)
        if marked:self._marked=t
        self.previous=frame.copy()
        record_all={'t':t,'sec':round(t/p.fps,8),'counts':counts.tolist(),'regions':record,
                    'phase_order':order,'phase_rad':self.phase.round(7).tolist(),
                    'spikes_total':spike_total,'ring_arrivals':len(arriving),'ring_weight_mean':float(np.mean(list(self.weights.values()))),
                    'delivered_ring_pulses':int(actual.sum()),'spike_marker':bool(marked),
                    'marker_definition':'>=4 model spikes across >=2 regions with 3-step debounce; phase order logged separately',
                    'source_type':source_type,'optical_proxy':p.allow_photon_proxy,
                    'eeg_drive_uv':eeg_drive_uv,'eeg_pulse':eeg_pulse,
                    'eeg_source':'user_supplied_external_csv' if eeg_drive_uv is not None else 'unavailable'}
        self.history.append(record_all)
        return record_all
    def run_frames(self,frames, *, source_type='decoded_video',text='',eeg_values_uv=None):
        if eeg_values_uv is not None and len(eeg_values_uv)!=len(frames):raise ValueError('EEG length mismatch')
        for k,frame in enumerate(frames):self.step(frame,text=text if k==0 else '',source_type=source_type,
                                    eeg_drive_uv=None if eeg_values_uv is None else float(eeg_values_uv[k]))
        return self.summary()
    def summary(self):
        rates=np.array([row['counts'] for row in self.history],dtype=float)
        return {'schema':'ripple/ring-mushrooms-alpha-4','parameters':self.p.__dict__,
                'replicate_seed':self.seed,'colonies':len(self.children),'cells':8*27,
                'internal_directed_edges':8*108,'ring_directed_edges':len(self.weights),
                'steps':len(self.history),'source_types':sorted(set(r['source_type'] for r in self.history)),
                'external_eeg_samples_used':sum(x['eeg_drive_uv'] is not None for x in self.history),
                'spikes_total':int(rates.sum()) if len(rates) else 0,
                'spikes_by_role':{role:int(sum(x['counts'][i] for x in self.history)) for i,role in enumerate(ROLES)},
                'markers':int(sum(r['spike_marker'] for r in self.history)),
                'delivered_pulses':self.delivered_total,'generated_pulses':self.generated_total,
                'ring_weights':{f'{a}->{b}':float(v) for (a,b),v in sorted(self.weights.items())},
                'mean_phase_order':float(np.mean([r['phase_order'] for r in self.history])) if self.history else None,
                'end_active_cells':sum(int(m.active.sum()) for m in self.children),
                'input_note':'Optical specialist input is derived camera BGR; NOT EEG or calibrated photon counts; Z is image scale.'}

def model_signature(history:list[dict],fps:int)->dict:
    """Band powers of a COMPUTATIONAL spike-count signal, never EEG.
    Frequency bins use sampled spike counts. Reject bands above Nyquist and
    explicitly mark insufficient resolution instead of inventing values.
    """
    if fps<=0:raise ValueError('fps')
    if len(history)<8:return {'status':'insufficient_samples','bands':{}}
    signals=np.asarray([r['counts'] for r in history],dtype=float)
    signal=signals.mean(axis=1)
    signal=signal-signal.mean()
    F=np.fft.rfftfreq(len(signal),1./fps)
    ps=(np.abs(np.fft.rfft(signal*np.hanning(len(signal))))**2)/len(signal)**2
    bands={'delta':(0.5,4),'theta':(4,8),'alpha':(8,13),'beta':(13,30),'gamma':(30,80)}
    out={}
    for name,(lo,hi) in bands.items():
        if hi>fps/2 or not np.any((F>=lo)&(F<hi)):
            out[name]={'status':'unresolvable_at_sampling_rate','power':None}
        else:
            out[name]={'status':'calculated_model_spike_power','power':float(ps[(F>=lo)&(F<hi)].sum())}
    return {'status':'model_spike_count_spectrum_not_eeg','nyquist_hz':fps/2,
            'resolution_hz':fps/len(signal),'bands':out,'mean_spikes_per_frame':float(np.mean(signals.sum(axis=1)))}
