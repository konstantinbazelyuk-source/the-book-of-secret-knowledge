"""Machine-readable non-aesthetic node/edge mapping from executable topology."""
from __future__ import annotations
import csv
from pathlib import Path
from .core import Ring,ROLES,COORDS
ROOT=Path(__file__).resolve().parents[1]
def build(output=ROOT/'results'):
    output.mkdir(parents=True,exist_ok=True)
    r=Ring()
    with (output/'node_registry.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['ring_id','role','internal_id','x_tile','y_tile','z_processing_scale','status'])
        for k,m in enumerate(r.children):
            for i,coord in enumerate(COORDS):w.writerow([k,ROLES[k],i,*coord,'active' if m.active[i] else 'dormant'])
    with (output/'edge_registry.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['source_ring','source_role','dest_ring','dest_role','initial_weight','delay_steps'])
        for (i,j),v in sorted(r.weights.items()):w.writerow([i,ROLES[i],j,ROLES[j],v,r.p.delay_steps])
if __name__=='__main__':build()
