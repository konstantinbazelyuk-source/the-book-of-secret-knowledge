from __future__ import annotations
import argparse,json,time
from pathlib import Path
import cv2
from .core import Ring,RingParameters,model_signature

def run():
    a=argparse.ArgumentParser(description='Real Ring of Mushrooms: source camera/video -> 8 inherited Mushroom spiking colonies')
    g=a.add_mutually_exclusive_group(required=True)
    g.add_argument('--video',type=str);g.add_argument('--device',type=int)
    a.add_argument('--frames',type=int,default=48);a.add_argument('--fps',type=int,default=24)
    a.add_argument('--slider',type=float,default=.65);a.add_argument('--coupling',type=float,default=.4)
    a.add_argument('--text',default='');a.add_argument('--out',default='results/ring_recording.json')
    a.add_argument('--eeg-csv',help='Optional external microvolt EEG recording, correctly timestamped; never inferred from video')
    a.add_argument('--proxy-shot-noise',action='store_true');a.add_argument('--uncoupled',action='store_true')
    args=a.parse_args()
    if not 8<=args.frames<=10000:raise SystemExit('frames must be 8..10000')
    p=RingParameters(fps=args.fps,slider=args.slider,coupling=args.coupling,recurrent=not args.uncoupled,allow_photon_proxy=args.proxy_shot_noise)
    cap=cv2.VideoCapture(args.video if args.video else args.device)
    if not cap.isOpened():raise SystemExit('camera/video could not open; no measurements obtained')
    if args.device is not None:origin='physical_camera';print('Device capture requested; physical calibration NOT established')
    else:origin='decoded_video'
    ring=Ring(p);start=time.perf_counter();count=0
    if args.eeg_csv:
        from .eeg import aligned_eeg_drive
        drives=aligned_eeg_drive(args.eeg_csv,fps=args.fps,steps=args.frames)
    else:drives=None
    try:
        while count<args.frames:
            ok,frame=cap.read()
            if not ok:break
            ring.step(frame,source_type=origin,text=args.text if count==0 else '',
                      eeg_drive_uv=None if drives is None else drives[count])
            count+=1
    finally:cap.release()
    if count<8:raise SystemExit('not enough actual decoded frames; no output written')
    out={'summary':ring.summary(),'model_signature':model_signature(ring.history,args.fps),
         'history':ring.history,'elapsed_cpu_wall_s':time.perf_counter()-start,
         'camera_warning':'Video timestamps are modeled at --fps, not recovered from irregular device timestamps.'}
    path=Path(args.out);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(out,indent=2));print(json.dumps(out['summary'],indent=2))
if __name__=='__main__':run()
