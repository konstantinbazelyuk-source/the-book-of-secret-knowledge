"""Evidence plots: actual registered directed ring + executed paired trials."""
from __future__ import annotations
import json,csv,math
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from .core import ROLES
ROOT=Path(__file__).resolve().parents[1]

def make_figures(results=ROOT/'results'):
    dat=json.loads((results/'exemplar_recording.json').read_text())
    history=dat['history']
    # TRUE ring graph, not imagined anatomy.
    fig,ax=plt.subplots(figsize=(9,8))
    theta=2*np.pi*np.arange(8)/8
    xy=np.column_stack((np.cos(theta),np.sin(theta)))
    for i in range(8):
        j=(i+1)%8
        ax.annotate('',xy=xy[j]*.97,xytext=xy[i]*.97,arrowprops=dict(arrowstyle='-|>',lw=.8,alpha=.6))
        ax.annotate('',xy=xy[i]*1.02,xytext=xy[j]*1.02,arrowprops=dict(arrowstyle='-|>',lw=.8,alpha=.6,connectionstyle='arc3,rad=.12'))
    for i,(x,y) in enumerate(xy):
        ax.scatter(x,y,s=700)
        ax.text(x,y,ROLES[i]+'\n27 nodes',ha='center',va='center',fontsize=8,color='white')
    ax.set(aspect='equal',xlim=(-1.38,1.38),ylim=(-1.35,1.35),title='Actual eight-Mushroom ring: 16 directed inter-colony links')
    ax.axis('off');fig.tight_layout();fig.savefig(results/'ring_graph.png',dpi=145);plt.close(fig)
    # Observed/software events, not EEG.
    x=np.array([row['sec'] for row in history]);v=np.array([row['counts'] for row in history]);phi=np.array([row['phase_order'] for row in history])
    fig,ax=plt.subplots(figsize=(11,5));ax.imshow((v>0).T,aspect='auto',origin='lower',interpolation='nearest',extent=(x.min(),x.max(),-.5,7.5))
    ax.set_yticks(range(8),ROLES);ax.set_xlabel('Model seconds (24 fps nominal)');ax.set_ylabel('Mushroom region');ax.set_title('Computed spike-event raster (one saved synthetic-video replicate)')
    fig.tight_layout();fig.savefig(results/'ring_spike_raster.png',dpi=155);plt.close(fig)
    fig,ax=plt.subplots(figsize=(11,4));ax.plot(x,phi,label='Kuramoto phase order (model)');ax.plot(x,[row['ring_weight_mean'] for row in history],label='Mean directed inter-colony weight')
    ax.set_ylim(0,1);ax.set_xlabel('Model seconds');ax.set_title('Computed fluctuating phase order and learned connectivity');ax.legend()
    fig.tight_layout();fig.savefig(results/'ring_dynamics.png',dpi=155);plt.close(fig)
    with (results/'replicates.csv').open() as f:rows=list(csv.DictReader(f))
    fig,axs=plt.subplots(1,2,figsize=(11,4))
    for ax,key,title in [(axs[0],'spikes_total','Total computed neuron events'),(axs[1],'phase_order','Mean simulated oscillator phase order')]:
        a=np.array([float(r['ring_'+key]) for r in rows]);b=np.array([float(r['isolated_'+key]) for r in rows]);dif=a-b
        ax.scatter(range(len(rows)),dif,s=10)
        ax.axhline(0,ls='--',lw=1,color='gray');ax.axhline(dif.mean(),lw=1,label=f'Mean difference {dif.mean():.3g}')
        ax.set(title=title,xlabel='Paired replicate index',ylabel='Connected minus disconnected')
        ax.legend()
    fig.suptitle('50 paired synthetic-video colony trials; no physical neural recordings')
    fig.tight_layout();fig.savefig(results/'paired_replication.png',dpi=155);plt.close(fig)

if __name__=='__main__':make_figures()
