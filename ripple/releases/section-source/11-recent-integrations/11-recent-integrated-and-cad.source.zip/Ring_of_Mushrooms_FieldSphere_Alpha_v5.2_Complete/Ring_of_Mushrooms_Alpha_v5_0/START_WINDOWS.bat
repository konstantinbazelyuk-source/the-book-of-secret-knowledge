@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  echo Python Launcher is missing. Install Python 3.11 or 3.12 with Add to PATH.
  pause
  exit /b 1
)
py -3 -m pip install -r requirements_v51.txt
if errorlevel 1 (echo Dependency installation failed.& pause & exit /b 1)
py -3 start_workstation.py
if errorlevel 1 pause
