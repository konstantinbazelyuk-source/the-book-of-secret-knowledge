# Ring of Mushrooms — Ripple Alpha v4.0 (executable source)

**Status:** executable eight-colony, 3D-inner / delayed-ring-outer spiking model. **Not** a simulated human brain, quantum computer, general AI, calibrated camera EEG, or physical photon counter. New source MIT; frozen parent trees preserve their earlier license terms and are not edited.

## Operational source tree

- `ring/core.py`: actual eight independent inherited Mushroom v3.0 objects (`216` inherited Charlie v2.0 neuron instances). Each Mushroom contains `27` XYZ neurons and `108` directed inner edges. Z remains **Gaussian image processing scale**, never inferred physical depth.
- `ring/core.py` `Ring.step`: eight sensor-derived optical processing roles; causal delayed source-spike to *recipient gateway conductance* delivery through 16 ring links. Bounded plasticity changes actual future message transmission weights. `slider` scales delivered conductance pulses.
- `ring/core.py` `model_signature`: FFT-based **software spike-event** bandpowers, with explicit rejection when video frame rate makes a band unresolvable. Not EEG.
- `ring/eeg.py`: separate **externally supplied** timestamped EEG CSV analyzer. Reports calculated PSD bandpowers in microvolt squared and refuses irregular timing/invalid data. This program does not synthesize EEG from optical video and cannot establish a neurological diagnosis.
- `ring/core.py` `photon_energy_j`: physically correct photon energy from fixed SI Planck constant and vacuum light speed. `poisson_camera_proxy` is an optional Poisson *synthetic perturbation* of ordinary eight-bit camera values: does not infer photons from webcam RGB.
- `ring/cli.py`: actual OpenCV VideoCapture source, including a real camera index or real video decode. Does not switch silently to synthetic data on camera failure. Camera availability and exposure controls were **not** hardware tested in this release.
- `ring/study.py`: seeded 50 paired replicates against connected/uncoupled ring, 2 archived synthetic scenes, controlled noise seeds, metrics and bootstrap audit. **Exploratory**, not blinded clinical science.
- `parents/Mushroom_Ripple_Alpha_v3_0/`: complete unchanged, source-inherited prior Mushroom v3.0 release and its original source libraries.

## Build and run

Python 3.10+ and its NumPy, SciPy, OpenCV, Matplotlib dependencies. Node.js 20+ for inherited specialist programs, though `ring/cli.py` calls the inherited Mushroom grid directly rather than the optional Delta/Daughter specialist process.

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -q
python -m ring.study
python -m ring.visualize
```

**Real video decoding:**

```bash
python -m ring.cli --video parents/Mushroom_Ripple_Alpha_v3_0/vendor/v24/Master_Ripple_Camera_Alpha_v2_1/camera_fixtures/synthetic_color_target_160f.avi --frames 48 --out results/manual_video.json
```

**Physical camera, only when attached and authorized:**

```bash
python -m ring.cli --device 0 --frames 48 --fps 24 --slider 0.8 --out results/camera_record.json
```

**Existing EEG CSV from a real device:** Headers `time_s,FP1_uV,FP2_uV` etc. Units provided by original equipment must be verified by operator:

```bash
python -m ring.eeg --csv YOUR_REAL_EEG.csv --out results/external_eeg_signature.json
```

**Control:** `--uncoupled` switches off inter-colony spike delivery and Kuramoto ring coupling, keeping all eight inherited inner Mushroom populations operating. `--proxy-shot-noise` adds **synthetic** Poisson camera perturbations; off by default.

## Complete model mathematical contracts

### Native inherited conductance dynamics (unchanged)

Charlie core (per neuron): `C du/dt = -g_leak*u + g_exc*(E_exc-u)+g_inh*(E_inh-u)-a`. The excitatory/inhibitory conductance states integrate actual digital pulses with their native leak, adaptation, threshold and refractory behavior. Mushroom v3.0 supplies 27 instances with graph propagation and growth and effective-digital-genome controls. In this release all 216 inherited neuron equations remain unchanged; the ring is a new causal outer layer.

### Ring conductance

Each of eight specialized Mushroom nodes has directed edges to adjacent regions in each direction, **16 directed edges total**. Each timestep t, outgoing spike counts are transformed into bounded pulses for arrival at t+delay_steps, with `delay_steps` between 1 and 4. For source i to neighbor j, `pulse = clip_1..4(round(2*w_ij*clip(spikes_i,0,8)))` when spiking, and 0 otherwise. Delivery is `clip_0..8(round(slider * sum(pulses)))`, changing the target central Charlie cell's actual excitation. Messages do not alter raw RGB camera data or represent actual photon transport.

Adaptive inter-colony weights use **model heuristic**, not empirically calibrated STDP: `w_ij = clip_[.05,.45](w_ij + eta*(1[spike_i(t-1)>0]*1[spike_j(t)>0] - .12*w_ij))`, with 0<=eta<=.05. Parent internal synapses continue to use their own unchanged update equation. Both levels of adaptation are observable and ablatable.

### Fluctuating inter-regional coordination

Model phase `phi_i(t+dt) = phi_i + dt*(omega_i + (coupling/degree)*sum sin(phi_j-phi_i) + 0.25*min(spike_i,4)/4)`. The phase order `|mean_i(exp(j phi_i))|` lies in [0,1]. These are **classical Kuramoto-like phases**; they are *not* modeled EEG recordings. With coupling disabled, neighbor phase interaction is disabled too. Spike markers are triggered when at least four spikes occur across at least two regions in a frame and are debounced for three ticks. They are software event labels rather than genome mutations.

### Optical alphabet and photon statistics

The inherited optical alphabet maps image gray level to A-Z at 26 bins, then injects a bounded sensory pulse into the mapped neuron; the alphabet region retains that functional pathway. It does not decode semantic English from light intensity. The optional simulated photoelectron proxy follows Poisson counting with expected mean/variance equal, at a **chosen count scale**, not measured camera photon arrival. `E=h*c/lambda` uses SI exact constants but assigning a nominal RGB wavelength is **not spectrometry**.

### Signatures and Nyquist limitations

For `fps=24`, Nyquist is 12 Hz. Delta and theta are calculable in the model's spike-count signal; an alpha band extending beyond 12 Hz, beta, and gamma are explicitly unavailable. `ring/eeg.py` computes physically unit-labeled PSD from a provided EEG CSV with sufficient sampling, still **without clinically interpreting the results**.

## Tests, provenance and safeguards

- No outgoing network, no external services, no anthropomorphic comprehension claims, no unsupervised instruction execution.
- No fake real EEG, real laser measurements, camera connectivity, real neuronal signatures, or physical quantum sensing.
- Source files from Mushroom v3.0 were re-used unchanged. Original alpha package preserved in its unmodified `parents/` tree.
- Linked spikes, phase dynamics, plasticity, recruitments, optical encoding and the statistics are executed, tested, and recorded. There are no rendered mock architectures standing in for algorithms.
- The requested `10^23` trials were **not** executed. `50` pairwise replicated trials are feasible and recorded; statistical independence is limited by using only two archived synthetic scene distributions. More trials alone cannot establish out-of-distribution comprehension.

## Scientific foundations (research sources, not copied code)

- https://www.scholarpedia.org/article/Synchronization — Pikovsky & Rosenblum (2007), synchronization and phase oscillators.
- https://www.scholarpedia.org/article/Measures_of_neuronal_signal_synchrony — Kreuz (2011); spike and continuous synchrony are distinct.
- https://pmc.ncbi.nlm.nih.gov/articles/PMC4733815/ — Wilson–Cowan population dynamics, analogy only; neuron formula above is inherited Charlie.
- https://brian2.readthedocs.io/en/2.6.0/user/synapses.html — delayed spike transmission and event-driven network simulation.
- https://camera.hamamatsu.com/us/en/learn/technical_information/thechnical_guide/calculating_snr.html — optical shot-noise foundations.
- https://www.nist.gov/si-redefinition/meet-constants — h and c fixed SI constants.

If working with a real EEG sensor, ensure calibrated hardware, correct channel units, provenance, timestamp fidelity, informed consent and proper signal filtering. A video-driven spike raster is **never** diagnostically interchangeable with a brainwave recording.

### Functional external EEG → ring coupling (optional)

To attach **a separately recorded, explicitly unit-labeled EEG CSV** to the ring, pass `--eeg-csv your_capture.csv` with the normal `--video` or `--device` option. `ring/eeg.py` validates monotonic timestamps, channel values, sample frequency and 2+ seconds; anti-alias filters faster EEG data before synchronizing it to the camera frame clock. Signed amplitude is limited to ±500 µV and mapped to at most four positive excitatory / negative inhibitory Charlie pulses **in the gateway cell of the alphabet Mushroom**. That produces an actual state change in the inherited conductance dynamics. Such scaling is a proposed engineering interface, **not** a scientifically calibrated brain-to-neuron transfer function.

```bash
python -m ring.cli --video parents/Mushroom_Ripple_Alpha_v3_0/vendor/v24/Master_Ripple_Camera_Alpha_v2_1/camera_fixtures/synthetic_color_target_160f.avi --frames 48 --eeg-csv tests/generated_eeg_sine_10hz_128hz.csv --out results/combined_optical_synthetic_EEG_demo.json
```

The bundled EEG fixture is an analytically generated **10 Hz sine wave**, NOT real EEG. The CLI separately labels its imported data as `user_supplied_external_csv`; users must validate provenance. Actual physical EEG equipment was not tested, and the software neither measures neural tissue nor interprets mental states. The 50-replicate study uses **no EEG injection**; it compares visual input and inter-colony communication only. The ring can run without any EEG file.
