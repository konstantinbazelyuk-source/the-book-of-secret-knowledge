import tempfile,json,unittest,csv
from pathlib import Path
import numpy as np
from ring5.fixture import create
from ring5.synchronized import execute
from ring5.evaluate import run_benchmark

class FullSystemTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory();cls.d=create(Path(cls.tmp.name)/'fixture',fps=12,seconds=4)
    @classmethod
    def tearDownClass(cls):cls.tmp.cleanup()
    def test_end_to_end_requires_valid_anchors(self):
        p=self.d/'invalid.csv'
        with p.open('w',newline='') as f:
            w=csv.writer(f);w.writerow(['eeg_device_timestamp_s','camera_monotonic_s'])
            w.writerows([(1700000000,700),(1700000001,701.8),(1700000002,702)])
        with self.assertRaises(ValueError):execute(self.d/'simulated_camera.avi',self.d/'simulated_dual_capture.npz',p,output=self.d/'should_not_exist.json')
        self.assertFalse((self.d/'should_not_exist.json').exists())
    def test_fused_vs_ablation(self):
        args=(self.d/'simulated_camera.avi',self.d/'simulated_dual_capture.npz',self.d/'SYNTHETIC_clock_anchors.csv')
        a=execute(*args,output=self.d/'with.json',video_kind='synthetic_frame')
        b=execute(*args,output=self.d/'without.json',video_kind='synthetic_frame',fusion=False)
        self.assertEqual(a['frames'],48);self.assertEqual(a['v5_eeg_feature_frames'],24)
        self.assertGreater(a['v5_eeg_transferred_conductance_units'],0)
        self.assertEqual(b['v5_eeg_transferred_conductance_units'],0)
        self.assertNotEqual(a['ring']['spikes_total'],b['ring']['spikes_total'])
        self.assertEqual(a['raw_sources']['video_type'],'synthetic_frame')
        self.assertFalse(a['synchronization'].startswith('physically verified'))
    def test_real_derived_input_finite_and_subject_grouped(self):
        f=Path(__file__).resolve().parents[1]/'data_public/openbci_real_derived_features.json'
        data=json.loads(f.read_text()); t=data['trials'];X=np.asarray([r[3] for r in t]);y=np.asarray([r[1] for r in t]);g=np.asarray([r[0] for r in t]);
        self.assertEqual(X.shape,(20,8))
        self.assertEqual(set(g),set(['S1','S2','S3','S4','S5']))
        result=run_benchmark(X,y,g,replicates=3,with_ring=False)
        self.assertTrue(all(x['disjoint_groups'] for x in result['trials']))

if __name__=='__main__':unittest.main()
