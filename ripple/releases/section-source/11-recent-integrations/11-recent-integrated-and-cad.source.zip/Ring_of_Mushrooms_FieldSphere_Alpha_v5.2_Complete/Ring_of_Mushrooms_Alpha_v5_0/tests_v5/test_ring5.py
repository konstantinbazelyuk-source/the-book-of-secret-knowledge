import unittest,tempfile,csv
from pathlib import Path
import numpy as np
from ring5.timebase import fit_clock,align_eeg_frames
from ring5.eeg_features import band_features,load_edf_epochs
from ring5.bridge import EEGNeuralRing,ring_transform
from ring5.evaluate import synthetic_eeg_epochs,run_benchmark
from ring5.live import acquire
from ring5.physionet import fetch

class RingV5Tests(unittest.TestCase):
    def test_clock_identity(self):
        f=fit_clock(np.arange(10.),np.arange(10.));self.assertLess(f.maximum_error_s,1e-9)
    def test_clock_shift(self):
        f=fit_clock(np.arange(10.)+1000,np.arange(10.)+10);self.assertAlmostEqual(float(f.convert([1008])[0]),18)
    def test_clock_drift(self):
        f=fit_clock(np.arange(10.),np.arange(10.)*1.0002);self.assertAlmostEqual(f.drift_ppm,200,places=3)
    def test_clock_reject_large_offset_residual(self):
        with self.assertRaises(ValueError):fit_clock([0,1,2,3,4,5],[0,1.1,2,3.3,4,5.4])
    def test_clock_reject_no_anchors(self):
        with self.assertRaises(ValueError):fit_clock([0,1],[0,1])
    def test_clock_reject_reversed(self):
        with self.assertRaises(ValueError):fit_clock([0,2,1],[0,1,2])
    def test_alignment_valid(self):
        t=np.arange(500)/125
        frames=np.arange(1,3,.1)
        a=align_eeg_frames(frames,t,np.sin(t)[:,None],fit_clock(np.arange(4.),np.arange(4.)))
        self.assertLess(np.max(np.abs(a[:,0]-np.sin(frames))),.0001)
    def test_alignment_reject_missing(self):
        t=np.arange(500)/125
        with self.assertRaises(ValueError):align_eeg_frames([.1,9],t,np.zeros((500,1)),fit_clock(np.arange(4.),np.arange(4.)))
    def test_features_true_frequency(self):
        t=np.arange(250)/125; x=np.sin(2*np.pi*10*t)[None,:]*5
        z=band_features(np.concatenate([x,x],axis=0),125)
        self.assertEqual(len(z),8);self.assertGreater(z[2],z[0]) # alpha > theta
    def test_features_reject_undersample(self):
        with self.assertRaises(ValueError):band_features(np.ones((2,120)),60)
    def test_features_reject_units(self):
        with self.assertRaises(ValueError):band_features(np.ones((2,250))*9000,125)
    def test_edf_fail_closed(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(FileNotFoundError):load_edf_epochs(d)
    def test_synthetic_dataset_disjoint(self):
        X,y,g,_=synthetic_eeg_epochs(subjects=4,per_subject=8)
        self.assertEqual(X.shape,(32,8)); self.assertEqual(len(np.unique(g)),4)
        r=run_benchmark(X,y,g,replicates=2,with_ring=False)
        self.assertTrue(all(z['disjoint_groups'] for z in r['trials']))
    def test_unlabeled_fail(self):
        X,y,g,_=synthetic_eeg_epochs(subjects=4,per_subject=8)
        with self.assertRaises(ValueError):run_benchmark(X,np.zeros_like(y),g,replicates=1)
    def test_ring_real_gateway(self):
        model=EEGNeuralRing(seed=4)
        before=model.ring.children[0].neurons[13].exc
        r=model.step_bands(np.array([3.,0,0,0,0,0,0,0]));after=model.ring.children[0].neurons[13].exc
        self.assertNotEqual(before,after);self.assertEqual(r['source'],'external_eeg_features_to_native_conductance')
    def test_ring_reject_bad_dim(self):
        with self.assertRaises(ValueError):EEGNeuralRing().step_bands([1.,2.])
    def test_ring_transforms_nonvestigial(self):
        X,y,g,_=synthetic_eeg_epochs(subjects=3,per_subject=4)
        a,b=ring_transform(X[:4],X[4:6])
        self.assertEqual(a.shape,(4,10));self.assertTrue(np.all(np.isfinite(a)))
    def test_live_reject_no_hardware(self):
        with self.assertRaises(RuntimeError):acquire(board_id=0,camera_id=0,duration_s=1)
    def test_live_reject_duration(self):
        with self.assertRaises(ValueError):acquire(board_id=0,duration_s=999)
    def test_physionet_bad_id(self):
        with self.assertRaises(ValueError):fetch(subjects=[0],destination='/tmp/no_download')
    def test_source_labels(self):
        from ring.core import Ring
        frame=np.zeros((24,24,3),dtype=np.uint8)
        with self.assertRaises(ValueError):Ring().step(frame,source_type='actual_EEG_video')

if __name__=='__main__':unittest.main()
