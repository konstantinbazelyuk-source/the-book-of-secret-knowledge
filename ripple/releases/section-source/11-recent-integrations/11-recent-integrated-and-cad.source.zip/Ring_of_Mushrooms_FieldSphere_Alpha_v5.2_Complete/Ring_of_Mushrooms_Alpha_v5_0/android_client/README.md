# Android CameraX sensor client — build source, not APK

This is a native Java/CameraX Android app with camera preview, start/stop, real JPEG capture, bounded <=4Hz transmission, token authorization and device-frame timestamps. It talks to Ring v5.1 on a Dell PC using an ADB USB loopback bridge. The **full 216-neuron model executes on the computer**, not yet natively on the Android phone. No external server, subscription or cloud required. Captured images leave the phone only when Start Camera is pressed and are transmitted over the local USB-debugging tunnel.

## Build and run (requires actual Android SDK, Gradle and a compatible device)

Open `android_client/` in Android Studio (AGP 8.7.3, compile SDK 35, Java 17), sync dependencies, and build the debug APK. Enable USB debugging and plug in the phone. On Dell PC:

```
python -m workstation.app --serve-phone
adb devices
adb reverse tcp:8789 tcp:8789
```

Install via Android Studio or `adb install app/build/outputs/apk/debug/app-debug.apk`. Paste printed token in the app and tap **START CAMERA**. View `GET /status` from local authenticated tooling or use desktop GUI. Stop closes the camera; screen background also stops it.

## Verification status

Code exists and source/syntax audited. The APK was **not built in the execution container**, because no Android SDK/Gradle was available. No physical Samsung SM-A176U device or camera was accessible. CameraX device behavior, byte ordering, orientation, USB reverse and Android 16 permissions require actual build/device testing. JPEG RGB channel identity must be confirmed using a known red/green/blue color target. Do not treat source code as a shipped installable app.
