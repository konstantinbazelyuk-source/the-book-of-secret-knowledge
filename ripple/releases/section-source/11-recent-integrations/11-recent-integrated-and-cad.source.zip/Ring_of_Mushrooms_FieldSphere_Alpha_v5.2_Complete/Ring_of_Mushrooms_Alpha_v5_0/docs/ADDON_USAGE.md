# v5-only add-on

The v5-only ZIP is intended to be extracted *into the root of a verified v4.0 installation* containing `ring/`, `parents/`, and `tests/`. Run commands from that installation root, and ensure `ring5/`, `data_public/`, and `tests_v5/` end up alongside `ring/`.

The add-on does NOT overwrite `ring/` or any parent Charlie/Mushroom core. The complete ZIP is recommended for first-time installation and includes the v4 dependencies.

Install `requirements.txt` from the v5 release, and install `brainflow` **only if using an actual compatible EEG board**. Use explicit dataset provenance in every output.
