# Ring of Mushrooms v4.0: executed numerical study

The 50 paired trials use two synthetic archived camera scenes and a synthetic Poisson perturbation of display-referred image data. There is **no physical EEG, human observation, quantum detector, sensor calibration, or general intelligence benchmark** in these data. Each seed runs the eight Mushroom populations with and without delayed inter-region coupling.

| Measure | Connected | Uncoupled |
|---|---:|---:|
| Mean neuron spike events | 185.46 | 177.94 |
| Mean oscillator phase order (0..1) | 0.1659 | 0.1578 |
| Mean active neurons at finish | 154.44 | 151.50 |
| Mean markers/replicate | 6.00 | 6.00 |
| Mean processing seconds/replicate | 0.816 | 0.797 |

Mean paired spike-count difference **7.52**; exploratory paired-bootstrap 95% interval **[7.04, 8.00]**. Mean phase-order difference **0.00813**, exploratory interval **[0.00775, 0.00848]**.

**Limitations:** These intervals describe the selected simulation-seed variability, not generalization to physical sensors or new scenarios. Two synthetic scene families are repeatedly used. More spikes do not establish more information, better task accuracy, intelligence, human-brain similarity, or understanding. The ring increases processing time, and the marker counts are unchanged in this experiment.

The study executed **100 model runs**, **2400 model frame updates**, **19200 Mushroom processing calls**, **518400 nominal Charlie neuron steps**; runtime 81.64 seconds on the available CPU. *Requested 10^23 iterations were not attempted or performed.* Additional iterations without distinct ground truth are not a validation of intelligence.

**Source integrity:** All 411 original v3.0 model files matched source hashes. 45 new ring tests and 64 inherited Mushroom tests passed. The separate EEG sinusoidal fixture (10 Hz @ 128 samples/s) validated a functional external data interface but was not actual patient EEG. Video with/without this synthetic electrical drive produced the same total event count in the 48-frame controlled demo; the injected conductance states were different. Consequently no claimed benefit from EEG coupling is justified yet.

See `replicates.csv`, `exemplar_recording.json`, `study_console.txt`, `ring_spike_raster.png`, `ring_dynamics.png`, `node_registry.csv`, `edge_registry.csv`, and `parent_source_audit.json` for machine-readable evidence.
