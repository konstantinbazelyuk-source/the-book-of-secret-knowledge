# Ring of Mushrooms Alpha v5.0 — sensor evidence and group-holdout evaluation

**Executable research software.** This release does **not** claim general intelligence, equivalence to the brain, medical utility, quantum computing, optical measurement of brainwaves, or verified physical camera+EEG synchrony. Parent v4.0's Charlie neurons, ring connections, code and equations are unchanged. The new modules actually execute real format loaders, conductance injection, common-clock verification, and evaluation pipelines.

## What changed and why

1. **Working, type-checked EEG interface.** `ring5/eeg_features.py` extracts 2-second 125/160Hz+ EEG band features from annotated EDF files (PhysioNet EEGMMIDB) using MNE and Welch PSD, requiring actual files and T1/T2 labels. It rejects impossible rates, missing channels and inappropriate units. Separate `ring5/openbci_csv.py` reproduces the 500-sample 125 Hz public CSV feature study with source-revision checks; actual CSV is not redistributed.
2. **EEG neural pathway.** `ring5/bridge.py` injects bounded continuous spectral contrast into the actual synaptic conductance states of all eight inherited Mushroom gateway neurons and reads their spike, membrane, inhibitory and excitatory states. It never calls its input 'optical' data. For EEG-only benchmarks a fixed black numeric carrier is passed to v4's grid integrator; the recording explicitly labels it as simulated scaffolding, not a camera measurement. No inherited mathematical equations are replaced or overwritten.
3. **Real capture interface.** `ring5/live.py` handles an explicitly chosen BrainFlow board and an OpenCV camera, stores video and lossless-timestamp arrays, and marks the streams **not certified synchronized**. Physical EEG acquisition requires BrainFlow and compatible EEG hardware; synthetic BrainFlow boards require a separate explicit flag. BrainFlow is optional, not installed here; the device itself was NOT tested.
4. **Causal clock certification.** `ring5/timebase.py` takes >=3 genuinely co-recorded anchor events over >=2s, fits affine clock offset and drift, rejects outliers, gaps and >20ms residual. `ring5/synchronized.py` only fuses video with EEG after the clock fit passes. Hardware trigger accuracy and exposure latency still require device validation; a fitted clock alone does not establish that two independent signals have physiological association.
5. **Falsifiable evaluation.** `ring5/evaluate.py` compares regularized spectral logistic regression, majority vote, eight-colony coupled Mushroom and eight-colony uncoupled Mushroom with subject-disjoint heldouts. Model representations are frozen and independent of labels. Every evaluation reports its data source, seeds, repeats, train/test group sizes and limitations.
6. **Actual public human EEG subset.** Features in `data_public/openbci_real_derived_features.json` were calculated directly from published GitHub files corresponding to recorded MILimbEEG 125Hz CSV trials. **Twenty** recordings from **five** source subject folders, two filename-coded tasks (I2 vs I3) and two trials/task/subject. Another group S6 was excluded for near-duplicating S3 feature vectors. This is a tiny exploratory evaluation, not independent replication or verified cognitive-state decoding. See original repository and dataset citations below. Original raw EEG is not bundled.

## How to run locally

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests_v5 -q
python -m unittest discover -s tests -q
python -m ring5.evaluate --dataset public_subset --replicates 50 --output results_v5/my_public_reanalysis.json
python -m ring5.evaluate --dataset synthetic --replicates 50 --output results_v5/my_synthetic_study.json
```

### Real annotated PhysioNet human EEG (internet required on your computer/Colab)

PhysioNet EEG Motor Movement/Imagery Dataset is **ODC-By 1.0**, DOI 10.13026/C28G6P. It has 160 Hz, 64-channel EDF and human T0/T1/T2 annotations. The source uses runs **3,7,11** for left/right hand *execution*; the EDF importer deliberately selects this consistent family. Download is opt-in and separate from the simulation:

```bash
python -m ring5.physionet --subjects 1 2 3 4 5 --runs 3 7 11 --out physionet_edf
python -m ring5.evaluate --dataset edf --edf-root physionet_edf --replicates 50 --output results_v5/actual_physionet_results.json
```

This environment cannot reach the PhysioNet download endpoint. **No PhysioNet EDF data was downloaded, and therefore no numerical PhysioNet classification results were claimed.** An EDF loader exists but has not been tested against genuine EDF+ bytes here. The separately tested published OpenBCI data subset is explicitly a different recording collection and 125Hz, not PhysioNet EDF.

### Record physical camera + EEG on your own hardware

```bash
python -m pip install brainflow
python -m ring5.live --board-id YOUR_BRAINFLOW_BOARD_ID --camera 0 --serial-port YOUR_SERIAL_PORT --seconds 15 --out recordings/session1
```

This saves `session1.avi` and `session1.npz`. It does **not** infer synchronization automatically. Use a real common sync marker (e.g., an event visible to each recording device and logged on their respective clocks), then supply a CSV with fields `eeg_device_timestamp_s,camera_monotonic_s`, >=3 paired events over >=2 seconds. If either device lacks marker capability, do not claim precise multi-sensor sync.

```bash
python -m ring5.synchronized --video recordings/session1.avi --acquisition recordings/session1.npz --anchors measured_clock_events.csv --video-kind physical_camera --out results_v5/physical_fusion.json
```

Use `--disable-fusion` for a matched optical-only ablation. The software **cannot certify physical origin or exposure latency** just from a filename or user-supplied metadata. Camera frames are host-timestamped *after* read, not hardware-exposure-timestamped.

### Complete end-to-end synthetic playback (executes OpenCV + full 216-neuron ring)

```bash
python -m ring5.fixture
python -m ring5.synchronized --video results_v5/synthetic_sync_fixture/simulated_camera.avi --acquisition results_v5/synthetic_sync_fixture/simulated_dual_capture.npz --anchors results_v5/synthetic_sync_fixture/SYNTHETIC_clock_anchors.csv --video-kind synthetic_frame --out results_v5/fused.json
```

The fixture's sine waves and clock anchors are entirely synthetic. The main release also includes the v4.0 50-replicate study and original parent source archives unchanged.

## Observed research results (actually executed)

| Dataset and criterion | Majority | Spectral logistic | Mushroom uncoupled | Mushroom coupled |
|---|---:|---:|---:|---:|
| Mathematical EEG-like fixture, mean 50 grouped holdouts | 0.5000 | 1.0000 | 0.9925 | 0.9925 |
| Published OpenBCI/MILimbEEG derived EEG features, mean 50 grouped holdouts | 0.5000 | 0.5500 | 0.4975 | 0.4975 |

The human-recording subset has **five subject folders**, yielding at most **ten distinct holdouts of two subjects**. Fifty repeated grouped splits are not 50 independent subject samples, and results on 20 chosen recordings cannot be generalized. The source `I2`/`I3` codes are kept literal: identifying them as specific thought/mental states without source confirmation would be an unsupported claim. The scores are *balanced accuracy*; 0.5 is chance for these balanced binary labels. No ring superiority was established. Features were calculated through a Hann-windowed numerical Fourier sum over fixed frequency bins; they have not been cross-checked here against original raw files in a separate processing environment.

**Synthetic synchronization ablation:** A 60-frame generated 15 fps RGB stream and independent generated 125Hz sinusoidal signals were clock-mapped from five generated matched anchors. Adding its EEG conductance path changed native Ring spikes from **1,027** to **1,058**, while camera frames were identical. The new EEG pathway really changes the numerical model. This does not establish human EEG decoding, a biological mechanism or sensor accuracy. The generated source is kept separately from published human recordings.

## Invariants and guardrails

- Original inherited v4 ring, Charlie core, Mushroom voxels and digital genome equations **unmodified**.
- EEG field units and temporal frequency are not electromagnetic/optical carrier frequencies. Source differences never silently substituted.
- No hardware, no MNE EDF files, and no common sync anchors supplied -> explicit exception or report marked unverified; never silently synthesize real data.
- `Ring` has 8 colonies x 27 cells = 216 existing software neurons, with 864 inherited internal edges and 16 inter-colony directed connections; Z is scale, not physical depth.
- No medical diagnostic claims, EEG-derived consciousness interpretation, autonomous language understanding, quantum acceleration or ChatGPT-equivalence claims.
- No outgoing networking by default. Dataset fetch is explicit opt-in.
- New code MIT; inherited source and public data retain original licenses, attributions, and restrictions.

## Primary sources

- PhysioNet EEG Motor Movement/Imagery Dataset, 160Hz, EDF+, annotations, license: https://physionet.org/content/eegmmidb/1.0.0/
- MNE EDF reader and annotation interpretation: https://mne.tools/stable/generated/mne.io.read_raw_edf.html
- BrainFlow device and playback acquisition: https://brainflow.readthedocs.io/en/stable/ and https://brainflow.readthedocs.io/en/stable/SupportedBoards.html
- Lab Streaming Layer clock correction: https://labstreaminglayer.readthedocs.io/info/time_synchronization.html
- Public published EEG CSV example and MILimbEEG attribution: https://github.com/Human-Machine-Interface/OpenBCI_Classification_Example
- Earlier original v4 theory in `README_V4_UNMODIFIED.md`; primary equations are the archived Charlie original source, not pseudocode here.
