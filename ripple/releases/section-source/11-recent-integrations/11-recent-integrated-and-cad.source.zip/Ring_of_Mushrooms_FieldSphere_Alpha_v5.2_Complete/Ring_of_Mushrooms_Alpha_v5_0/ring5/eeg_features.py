"""Real EDF import and calibrated EEG spectral features. No diagnosis."""
from __future__ import annotations
from pathlib import Path
import numpy as np
from scipy.signal import welch

# These are standard EEG frequency ranges for signal analysis, not consciousness states.
BANDS={'theta':(4.,8.),'alpha':(8.,13.),'beta':(13.,30.),'low_gamma':(30.,45.)}

def band_features(epoch_uv,fs):
    v=np.asarray(epoch_uv,dtype=float)
    if v.ndim!=2 or not (1<=v.shape[0]<=128) or len(v[0])<int(1.5*fs) or not np.all(np.isfinite(v)):
        raise ValueError('expected channels x samples of finite >=1.5 s EEG')
    if not 100<=fs<=2000:raise ValueError('EEG sample rate needs >=100 Hz for 45Hz low gamma')
    if np.max(np.abs(v))>5000:raise ValueError('EEG >5000uV; check units/contamination')
    f,p=welch(v,fs=fs,nperseg=min(v.shape[1],int(2*fs)),axis=1,detrend='constant')
    vec=[]
    for name,(lo,hi) in BANDS.items():
        mask=(f>=lo)&(f<hi)
        if mask.sum()<2 or hi>=fs/2:raise ValueError('band not resolvable at sample rate/window')
        vec.extend(np.log10(1e-8+np.trapezoid(p[:,mask],f[mask],axis=1)).tolist())
    return np.asarray(vec,dtype=float)

def load_edf_epochs(directory, *, run_numbers=(3,7,11), channels=('C3..','C4..'), length_s=2., skip_s=.5):
    """PhysioNet EEGMMIDB annotated T1/T2 events; same run-family labels only.
    Requires locally downloaded real EDF+ recordings. Never silently downloads or fabricates.
    Returns features + group IDs by SUBJECT and run, and true dataset provenance.
    """
    import mne
    root=Path(directory);paths=sorted(root.rglob('*.edf'))
    if not paths:raise FileNotFoundError('No genuine EDF files found. Download original PhysioNet EEGMMIDB recordings.')
    X=[]; y=[];groups=[];sources=[]
    allowed=set(run_numbers)
    for path in paths:
        import re
        match=re.match(r'(S\d{3})R(\d{2})\.edf$',path.name,re.I)
        if not match or int(match.group(2)) not in allowed:continue
        raw=mne.io.read_raw_edf(str(path),preload=False,verbose='ERROR')
        fs=float(raw.info['sfreq']); actual=raw.ch_names
        # Explicit channel selection: fail on missing, no guessed channel substitution.
        ch=[next((n for n in actual if n.lower()==c.lower()),None) for c in channels]
        if any(v is None for v in ch):
            raise ValueError(f'{path.name}: missing channels {channels}; got {actual[:12]}')
        events,event_ids=mne.events_from_annotations(raw,verbose='ERROR')
        for t in events:
            tag=next((k for k,v in event_ids.items() if v==t[2]),None)
            if tag not in ('T1','T2'):continue
            start=int(t[0])+round(skip_s*fs);stop=start+round(length_s*fs)
            if stop>raw.n_times:continue
            epoch=raw.get_data(picks=ch,start=start,stop=stop)*1e6 # MNE returns volts
            X.append(band_features(epoch,fs));y.append(0 if tag=='T1' else 1)
            groups.append(match.group(1))
            sources.append({'filename':path.name,'event':tag,'sample':int(t[0]),'sample_rate':fs,'channels':ch,'dataset':'PhysioNet EEGMMIDB', 'run':int(match.group(2))})
    if len(X)<6 or len(set(y))!=2:raise ValueError('insufficient eligible labeled events; need T1 and T2 from same run family')
    return np.stack(X),np.asarray(y),np.asarray(groups),sources
