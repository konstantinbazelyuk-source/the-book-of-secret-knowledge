"""Functional EEG->eight Mushroom conductance gateways, native neuron states unchanged.
The numeric carrier frame is explicitly black/constant and NEVER labeled optical data.
"""
from __future__ import annotations
import numpy as np
from ring.core import Ring,RingParameters

class EEGNeuralRing:
    def __init__(self,seed=0,coupled=True,slider=.7):
        self.ring=Ring(RingParameters(recurrent=coupled,slider=slider,optical_alphabet=False,plasticity=.008),seed=seed)
        self.carrier=np.zeros((24,24,3),dtype=np.uint8)
        self.count=0
    def step_bands(self, features, *, original_uv=True):
        """Four spectral bands x 2 channels (8 values); drive signed contrast relative
        to a TRAINING-only center and scale externally supplied by caller.
        """
        features=np.asarray(features,dtype=float)
        if features.shape!=(8,) or not np.all(np.isfinite(features)) or np.any(np.abs(features)>8):
            raise ValueError('8 calibrated bounded z-scores required')
        for region,v in enumerate(features):
            dest=self.ring.children[region].neurons[13]
            # Continuous bounded conductance preserves subthreshold information.
            # Arbitrary engineering transfer, not a calibrated neurophysiology law.
            drive=min(4.,abs(float(v))*1.5)*dest.params.recurrent_exc_pulse
            if v>=0:
                dest.exc=min(dest.params.max_synaptic_conductance,dest.exc+drive)
            else:
                dest.inh=min(dest.params.max_synaptic_conductance,dest.inh+drive)
        # 1/24 s simulation step; black constant carrier is numeric integration scaffolding.
        rec=self.ring.step(self.carrier,source_type='synthetic_frame')
        self.count+=1
        return {'region_spikes':rec['counts'],'phase_order':rec['phase_order'],
                'delivered_ring_pulses':rec['delivered_ring_pulses'],
                'source':'external_eeg_features_to_native_conductance',
                'gateway_exc':[float(k.neurons[13].exc) for k in self.ring.children],
                'gateway_inh':[float(k.neurons[13].inh) for k in self.ring.children],
                'gateway_membrane':[float(k.neurons[13].membrane) for k in self.ring.children],
                'carrier':'fixed mathematical zero; NOT video/optical capture'}
    def signature(self):
        return self.ring.summary()

def ring_transform(train_features,test_features,*,seed=17,coupled=True):
    """Unsupervised frozen-scaled propagation, independent train and test ring
    resets prevent test contamination; training data alone determines scales.
    Can be comparatively evaluated against ordinary raw spectral features.
    """
    a=np.asarray(train_features,float);b=np.asarray(test_features,float)
    if a.ndim!=2 or b.ndim!=2 or a.shape[1]!=b.shape[1] or a.shape[1]!=8:raise ValueError('8-D band features needed')
    center=np.median(a,axis=0);spread=np.maximum(np.std(a,axis=0),.15)
    def encode(z):
        model=EEGNeuralRing(seed=seed,coupled=coupled)
        out=[]
        for v in z:
            record=model.step_bands(np.clip((v-center)/spread,-6,6))
            out.append(record['region_spikes']+[record['phase_order'],record['delivered_ring_pulses']])
        return np.asarray(out,float)
    return encode(a),encode(b)
