"""Explicit common-clock mapping for dual-stream acquisition.
No presumed device sync.  Requires genuine measured clock anchors to certify alignment.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np

@dataclass(frozen=True)
class ClockFit:
    slope:float
    intercept_s:float
    maximum_error_s:float
    rms_error_s:float
    drift_ppm:float
    anchors:int
    def convert(self, t):
        return self.slope*np.asarray(t, dtype=float)+self.intercept_s


def fit_clock(source_seconds, reference_seconds, *, tolerance_s=.020, max_drift_ppm=2000)->ClockFit:
    """Map source timestamps to a reference clock using measured common events.
    Reject poor alignment instead of manufacturing synchronization.
    """
    a=np.asarray(source_seconds, dtype=float);b=np.asarray(reference_seconds,dtype=float)
    if a.ndim!=1 or a.shape!=b.shape or len(a)<3 or not np.all(np.isfinite(a)) or not np.all(np.isfinite(b)):
        raise ValueError('at least three finite paired hardware/sync anchors required')
    if np.any(np.diff(a)<=0) or np.any(np.diff(b)<=0) or np.ptp(a)<2 or np.ptp(b)<2:
        raise ValueError('clock anchors must increase over >=2 s')
    if not 0<tolerance_s<=.1:raise ValueError('invalid tolerance')
    centered=a-a[0]; z=np.stack([centered, np.ones_like(centered)],axis=1)
    slope,offset=np.linalg.lstsq(z,b,rcond=None)[0]
    intercept=float(offset-slope*a[0]);prediction=slope*a+intercept
    err=b-prediction;max_err=float(np.max(np.abs(err)));rms=float(np.sqrt(np.mean(err**2)))
    drift=float(abs(slope-1)*1e6)
    if not .9<slope<1.1 or drift>max_drift_ppm or max_err>tolerance_s:
        raise ValueError(f'UNSYNCHRONIZED: error={max_err:.6f}s; drift={drift:.1f}ppm')
    return ClockFit(float(slope),intercept,max_err,rms,drift,len(a))


def align_eeg_frames(frame_reference_s,eeg_source_s,eeg_samples_uv,clock:ClockFit,*,max_gap_s=.025):
    """EEG interpolation only after certified source/reference clock mapping."""
    f=np.asarray(frame_reference_s,float);t=np.asarray(eeg_source_s,float);x=np.asarray(eeg_samples_uv,float)
    if f.ndim!=1 or t.ndim!=1 or x.ndim!=2 or len(t)!=len(x) or len(f)==0 or len(t)<4 or not np.all(np.isfinite(x)):
        raise ValueError('invalid frame/EEG arrays')
    if not np.all(np.diff(t)>0) or not np.all(np.diff(f)>0):raise ValueError('unsorted timestamps')
    adjusted=clock.convert(t)
    if f[0]<adjusted[0] or f[-1]>adjusted[-1]:raise ValueError('uncovered reference times: no extrapolation')
    right=np.searchsorted(adjusted,f).clip(1,len(t)-1)
    separation=np.minimum(np.abs(adjusted[right]-f),np.abs(f-adjusted[right-1]))
    if np.max(separation)>max_gap_s: raise ValueError('missing EEG samples or clock gap')
    return np.column_stack([np.interp(f,adjusted,x[:,i]) for i in range(x.shape[1])])
