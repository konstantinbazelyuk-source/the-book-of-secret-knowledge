"""Leakage-controlled subject-grouped experiment; 50 predeclared splits.
No extrapolated cognitive ability, no labels inferred from camera or spike counts.
"""
from __future__ import annotations
import argparse,json
from pathlib import Path
import numpy as np
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.dummy import DummyClassifier
from sklearn.metrics import balanced_accuracy_score
from sklearn.model_selection import GroupShuffleSplit
from .bridge import EEGNeuralRing
from .eeg_features import load_edf_epochs,band_features


def synthetic_eeg_epochs(seed=333,subjects=6,per_subject=4,fs=125):
    """Only for pipeline falsification; has no human EEG content.
    Samples two channels with label dependent mu/beta energy and subject drift.
    """
    r=np.random.default_rng(seed); X=[];y=[]; groups=[]
    for subject in range(subjects):
        drift=r.normal(0,2,size=2)
        for k in range(per_subject):
            label=k%2;t=np.arange(int(2*fs))/fs
            base=r.normal(0,1.9,(2,len(t)))
            # Synthetic C3/C4 mu ERD-like power, phase jitter and artifacts.
            amp=np.array([5.5,2.4]) if label==0 else np.array([2.4,5.5])
            ph=r.uniform(0,2*np.pi,size=2)
            sig=base+drift[:,None]+np.stack([amp[j]*np.sin(2*np.pi*10*t+ph[j]) for j in range(2)])
            sig+=2*np.sin(2*np.pi*23*t+r.uniform(0,2*np.pi))
            X.append(band_features(sig,fs));y.append(label);groups.append(f'S{subject:03d}')
    return np.asarray(X),np.asarray(y),np.asarray(groups),[{'origin':'synthetic_mathematical_eeg'}]*len(X)


def frozen_ring_features(X, *, coupled:bool,steps=4):
    """Independent per-epoch reset; no label fitting, no test/train adaptation.
    Fixed spectral drive scale = 1.0 log10(uV²/Hz) per 2 z-score units.
    Native conductances, delayed ring paths, and spikes all execute.
    """
    rows=[]
    for item in np.asarray(X,float):
        model=EEGNeuralRing(seed=2718,coupled=coupled)
        accumulated=np.zeros(8,dtype=float);last=None
        for _ in range(steps):
            last=model.step_bands(np.clip(item/2.,-6,6))
            accumulated+=np.asarray(last['region_spikes'],float)
        rows.append(np.r_[accumulated,last['gateway_exc'],last['gateway_inh'],last['gateway_membrane'],last['phase_order'],model.ring.delivered_total])
    return np.asarray(rows,float)


def run_benchmark(X,y,groups,*,replicates=50,with_ring=True):
    X=np.asarray(X,dtype=float);y=np.asarray(y);groups=np.asarray(groups)
    if X.ndim!=2 or X.shape[1]!=8 or len(X)!=len(y) or len(y)!=len(groups) or len(np.unique(groups))<3 or len(np.unique(y))!=2:
        raise ValueError('need at least three independent subjects/groups and binary annotated events')
    if not 1<=replicates<=100:raise ValueError('replicates must be 1..100')
    ring_features={}
    if with_ring:
        ring_features={'mushroom_uncoupled':frozen_ring_features(X,coupled=False),
                       'mushroom_coupled':frozen_ring_features(X,coupled=True)}
    splitter=GroupShuffleSplit(n_splits=replicates,test_size=.3,random_state=20261015)
    records=[]
    for rep,(tr,te) in enumerate(splitter.split(X,y,groups)):
        if len(np.unique(y[tr]))<2 or len(np.unique(y[te]))<2:raise ValueError('both labels needed in train/test')
        xtr,xt=X[tr],X[te];yt=y[tr];yv=y[te]
        result={'replicate':rep,'train_group_count':int(len(np.unique(groups[tr]))),'holdout_group_count':int(len(np.unique(groups[te]))),
                'train_records':int(len(tr)),'test_records':int(len(te)),
                'disjoint_groups':bool(not set(groups[tr]).intersection(groups[te]))}
        for name,clf in [('majority',DummyClassifier(strategy='most_frequent')),
                         ('spectral_logistic',make_pipeline(StandardScaler(),LogisticRegression(max_iter=400,random_state=7)))]:
            clf.fit(xtr,yt);result[name]=float(balanced_accuracy_score(yv,clf.predict(xt)))
        for name,R in ring_features.items():
            clf=make_pipeline(StandardScaler(),LogisticRegression(max_iter=300,random_state=7))
            clf.fit(R[tr],yt);result[name]=float(balanced_accuracy_score(yv,clf.predict(R[te])))
        records.append(result)
    keys=['majority','spectral_logistic']+list(ring_features)
    totals={k:{'mean_balanced_accuracy':float(np.mean([v[k] for v in records])),
               'minimum':float(np.min([v[k] for v in records])),
               'maximum':float(np.max([v[k] for v in records]))} for k in keys}
    return {'schema':'ripple/ring-v5/evaluation-2','replicates':len(records),'metric':'balanced_accuracy',
            'split':'subject-grouped, 30% held out; overlapping subject leakage forbidden',
            'method':'Each epoch receives fixed, label-blind 216-neuron processing with independent reset; training-only classifier scaling',
            'results':totals,'trials':records,'ring_feature_checksum':{k:__import__('hashlib').sha256(v.tobytes()).hexdigest() for k,v in ring_features.items()},
            'warning':'Repeated holdout splits from same subjects are not 50 independent populations.'}

def main():
    p=argparse.ArgumentParser();p.add_argument('--dataset',choices=['synthetic','edf','public_subset'],required=True)
    p.add_argument('--edf-root');p.add_argument('--replicates',type=int,default=50);p.add_argument('--output',default='results_v5/benchmark.json')
    a=p.parse_args()
    if a.dataset=='edf':
        if not a.edf_root:p.error('--edf-root is required; no fake download')
        X,y,groups,src=load_edf_epochs(a.edf_root)
    elif a.dataset=='public_subset':
        d=json.loads(Path(__file__).resolve().parents[1].joinpath('data_public/openbci_real_derived_features.json').read_text())
        src=[{'filename':v[2], 'origin':'published_human_EEG_CSV_derived_features'} for v in d['trials']]
        X=np.asarray([v[3] for v in d['trials']],dtype=float)
        y=np.asarray([v[1] for v in d['trials']],dtype=int)
        groups=np.asarray([v[0] for v in d['trials']])
    else:X,y,groups,src=synthetic_eeg_epochs()
    result=run_benchmark(X,y,groups,replicates=a.replicates)
    result.update({'input_provenance': 'real_annotated_EDF' if a.dataset=='edf' else 'published_real_EEG_derived_features' if a.dataset=='public_subset' else 'synthetic_eeg',
                   'subject_groups':int(len(np.unique(groups))),'epochs':int(len(y)),
                   'source_files':sorted(set(s['filename'] for s in src if 'filename' in s))})
    target=Path(a.output);target.parent.mkdir(parents=True,exist_ok=True);target.write_text(json.dumps(result,indent=2))
    print(json.dumps({'provenance':result['input_provenance'],'replicates':result['replicates'],'results':result['results']},indent=2))
if __name__=='__main__':main()
