"""Local, explicit dual-source acquisition: OpenCV + BrainFlow hardware.
Timestamps are recorded as measured by software/device; synchrony is NOT inferred.
"""
from __future__ import annotations
import argparse,json,time,sys
from pathlib import Path
import numpy as np
import cv2

def acquire(*,board_id:int,camera_id:int=0,serial_port:str='',duration_s:float=10.,output='recordings/session',allow_synthetic_board=False):
    if not 1<=duration_s<=300:raise ValueError('bounded 1..300s duration')
    if camera_id<0:raise ValueError('explicit nonnegative camera index required')
    try:from brainflow.board_shim import BoardShim,BrainFlowInputParams,BoardIds
    except ImportError as exc:raise RuntimeError('BrainFlow absent: pip install brainflow for physical EEG') from exc
    if board_id==BoardIds.SYNTHETIC_BOARD.value and not allow_synthetic_board:
        raise ValueError('Synthetic BrainFlow board rejected as real EEG; use explicit --allow-synthetic-board')
    params=BrainFlowInputParams();params.serial_port=serial_port
    board=BoardShim(board_id,params)
    cap=cv2.VideoCapture(camera_id)
    if not cap.isOpened():
        cap.release();raise RuntimeError('camera unavailable: no fake frames generated')
    target=Path(output);target.parent.mkdir(parents=True,exist_ok=True)
    writer=None;frames=[];times=[];samples=[]; eeg_t=[]; board_started=False
    try:
        board.prepare_session();board.start_stream();board_started=True
        eeg_ids=BoardShim.get_eeg_channels(board_id)
        clock_index=BoardShim.get_timestamp_channel(board_id)
        fs=BoardShim.get_sampling_rate(board_id)
        if not eeg_ids:raise RuntimeError('selected board has no EEG channels')
        start=time.monotonic(); wall_ref=time.time();mono_ref=time.monotonic()
        while time.monotonic()-start<duration_s:
            ok,frame=cap.read();now=time.monotonic()
            if not ok or frame is None:raise RuntimeError('camera read failed during acquisition')
            if writer is None:
                h,w=frame.shape[:2]
                if min(h,w)<24:raise RuntimeError('camera resolution too low')
                writer=cv2.VideoWriter(str(target.with_suffix('.avi')),cv2.VideoWriter_fourcc(*'MJPG'),min(30,max(1,int(cap.get(cv2.CAP_PROP_FPS) or 20))),(w,h))
                if not writer.isOpened():raise RuntimeError('cannot save camera video')
            writer.write(frame);times.append(now)
            batch=board.get_board_data()
            if batch.size:
                eeg_t.extend(batch[clock_index].tolist());samples.extend(batch[eeg_ids].T.tolist())
        batch=board.get_board_data()
        if batch.size:
            eeg_t.extend(batch[clock_index].tolist());samples.extend(batch[eeg_ids].T.tolist())
        if len(times)<2 or len(eeg_t)<10:raise RuntimeError('not enough real video/EEG to save validated recording')
        np.savez_compressed(target.with_suffix('.npz'),frame_monotonic_s=np.asarray(times),
             eeg_device_timestamp_s=np.asarray(eeg_t),eeg_uv=np.asarray(samples,dtype=np.float32),
             start_wall_unix_s=wall_ref,start_monotonic_s=mono_ref)
        meta={'camera':'physical_camera_requested','eeg':('BrainFlow_SYNTHETIC' if board_id==BoardIds.SYNTHETIC_BOARD.value else 'BrainFlow_external_board'),
              'board_id':board_id,'eeg_sample_rate_hz_declared':fs,'eeg_channels':len(eeg_ids),
              'frames':len(times),'eeg_samples':len(eeg_t),'source_clock_camera':'host_monotonic_on_frame_read',
              'source_clock_eeg':'board_timestamp_unix_or_board_domain',
              'synchronization_certified':False,'reason':'No shared hardware/event anchors provided; acquisition software does not imply synchronization',
              'hardware_latency_calibrated':False}
        target.with_suffix('.json').write_text(json.dumps(meta,indent=2))
        return meta
    finally:
        cap.release()
        if writer is not None:writer.release()
        try:
            if board_started:board.stop_stream()
            board.release_session()
        except Exception: pass

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--board-id',type=int,required=True);ap.add_argument('--camera',type=int,default=0);ap.add_argument('--serial-port',default='');ap.add_argument('--seconds',type=float,default=10);ap.add_argument('--out',default='recordings/session');ap.add_argument('--allow-synthetic-board',action='store_true')
    a=ap.parse_args()
    print(json.dumps(acquire(board_id=a.board_id,camera_id=a.camera,serial_port=a.serial_port,duration_s=a.seconds,output=a.out,allow_synthetic_board=a.allow_synthetic_board),indent=2))
