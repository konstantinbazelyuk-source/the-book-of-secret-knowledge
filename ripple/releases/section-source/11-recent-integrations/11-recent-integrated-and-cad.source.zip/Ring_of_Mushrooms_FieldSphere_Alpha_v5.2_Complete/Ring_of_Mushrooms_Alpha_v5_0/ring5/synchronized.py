"""Reconstruct synchronized EEG + video only when supplied anchors pass checks."""
import argparse,csv,json
from pathlib import Path
import numpy as np,cv2
from .timebase import fit_clock,align_eeg_frames
from .eeg_features import band_features
from ring.core import Ring,RingParameters

def execute(video, acquisition, anchors, *, output, video_kind="decoded_video", limit=120, fusion=True):
    obj=np.load(acquisition); ft=obj['frame_monotonic_s'];eeg_t=obj['eeg_device_timestamp_s'];channels=obj['eeg_uv']
    with open(anchors,newline='') as f: rows=list(csv.DictReader(f))
    if not rows or not {'eeg_device_timestamp_s','camera_monotonic_s'}.issubset(rows[0]):
        raise ValueError('explicit paired reference event anchors required')
    fit=fit_clock([float(r['eeg_device_timestamp_s']) for r in rows],
                  [float(r['camera_monotonic_s']) for r in rows])
    cap=cv2.VideoCapture(str(video)); frames=[]
    try:
        while len(frames)<limit:
            ok,fr=cap.read()
            if not ok:break
            frames.append(fr)
    finally:cap.release()
    if len(frames)<3 or len(frames)!=len(ft[:len(frames)]):raise RuntimeError('no comparable video frames')
    ft=ft[:len(frames)]
    if np.any(np.diff(eeg_t)<=0) or np.std(np.diff(eeg_t))/np.mean(np.diff(eeg_t))>.02:
        raise ValueError('EEG timestamp dropouts or irregular acquisition; no invalid spectral fusion')
    if np.any(np.diff(ft)<=0) or np.std(np.diff(ft))/np.mean(np.diff(ft))>.08:
        raise ValueError('video capture frame jitter >8%; inherited fixed-dt model not valid')
    camera_fps=1./np.mean(np.diff(ft))
    if not 8<=camera_fps<=60:raise ValueError('camera frame rate 8..60 required')
    source_fs=1./np.mean(np.diff(eeg_t))
    if len(channels)<64 or channels.shape[1]<2:raise ValueError('>=2 EEG channels and 64+ samples needed')
    # No interpolating past missing EEG or extrapolating video timestamps.
    aligned=align_eeg_frames(ft,eeg_t,channels,fit,max_gap_s=min(.04,1.1/source_fs))
    if not 100<=source_fs<=2000:raise ValueError('>=100Hz EEG required for spectral feature fusion')
    if video_kind not in ("decoded_video","physical_camera","synthetic_frame"):raise ValueError("explicit source provenance required")
    ring=Ring(RingParameters(optical_alphabet=True,fps=round(camera_fps)),seed=43)
    baseline=None
    per=[];eeg_gate_frames=0;eeg_conductance_sum=0.0
    # 2 seconds initial calibration is not considered evidence of a phenotype/label.
    for i,(frame,t) in enumerate(zip(frames,ft)):
        source_time=(t-fit.intercept_s)/fit.slope
        end=int(np.searchsorted(eeg_t,source_time));start=end-int(source_fs*2)
        if start<0 or not fusion:
            rec=ring.step(frame,source_type=video_kind);per.append({'frame':i,'injection':('disabled_ablation' if not fusion else 'not_enough_2s_eeg_history'),'spikes':rec['spikes_total']});continue
        sub=channels[start:end,:2].T
        features=band_features(sub,source_fs)
        # Use fixed calibration midpoint; zscores mean physiological amplitude UNKNOWN.
        if baseline is None: baseline=features.copy()
        z=np.clip((features-baseline)/1.0,-4,4)
        for region,val in enumerate(z):
            n=ring.children[region].neurons[13]
            delta=min(4.,abs(float(val)))*n.params.recurrent_exc_pulse*1.5
            eeg_conductance_sum+=delta
            if val>=0:n.exc=min(n.params.max_synaptic_conductance,n.exc+delta)
            else:n.inh=min(n.params.max_synaptic_conductance,n.inh+delta)
        rec=ring.step(frame,source_type=video_kind)
        eeg_gate_frames+=1
        per.append({'frame':i,'injection':'2s EEG PSD differential conductance','spikes':rec['spikes_total'],'eeg_conductance_increment':float(np.sum(np.clip(np.abs(z),0,4)*.17*1.5))})
    result={'schema':'ring-v5/synchronized-fusion','clock_model':fit.__dict__,'synchronization':'paired event clock fit passed; physical trigger source not authenticated',
            'raw_sources':{'video':str(video),'video_type':video_kind,'eeg':str(acquisition)},'frames':len(per),'fusion_enabled':bool(fusion),'camera_fps_observed':camera_fps,'v5_eeg_feature_frames':eeg_gate_frames,'v5_eeg_transferred_conductance_units':eeg_conductance_sum,'events':per,'ring':ring.summary(),
            'accuracy_warning':'Host frame capture timestamps are not hardware exposure times; certified only against supplied anchor events; absolute source latency requires calibration.'}
    dest=Path(output);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(json.dumps(result,indent=2))
    return result
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--video',required=True);p.add_argument('--acquisition',required=True);p.add_argument('--anchors',required=True);p.add_argument('--out',default='results_v5/fused.json');p.add_argument('--video-kind',choices=['decoded_video','physical_camera','synthetic_frame'],default='decoded_video');p.add_argument('--disable-fusion',action='store_true');a=p.parse_args()
    print(json.dumps({k:v for k,v in execute(a.video,a.acquisition,a.anchors,output=a.out,video_kind=a.video_kind,fusion=not a.disable_fusion).items() if k!='events'},indent=2))
