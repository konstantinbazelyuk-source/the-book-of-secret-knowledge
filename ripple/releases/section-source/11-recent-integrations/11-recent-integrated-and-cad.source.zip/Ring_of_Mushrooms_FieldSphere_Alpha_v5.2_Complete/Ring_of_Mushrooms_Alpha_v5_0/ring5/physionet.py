"""Retrieve openly licensed PhysioNet EEGMMIDB recordings on a networked machine.
Separates data acquisition from model training; does not imply successful local download.
"""
from pathlib import Path
from urllib.request import Request,urlopen
import argparse,hashlib
BASE='https://physionet.org/files/eegmmidb/1.0.0/'
def fetch(subjects=(1,2,3),runs=(3,7,11),destination='physionet_edf'):
    base=Path(destination);base.mkdir(parents=True,exist_ok=True)
    reports=[]
    for subj in subjects:
        if not 1<=subj<=109:raise ValueError('subject 1..109')
        for run in runs:
            if run not in (3,7,11):raise ValueError('hand-movement run family only (3,7,11)')
            filename=f'S{subj:03d}R{run:02d}.edf'; path=base/filename
            if not path.exists():
                url=f'{BASE}S{subj:03d}/{filename}'
                request=Request(url,headers={'User-Agent':'Ripple-Open-Research/5.0'})
                try:
                    with urlopen(request,timeout=40) as res,open(path.with_suffix('.part'),'wb') as w:
                        while 1:
                            chunk=res.read(1<<18)
                            if not chunk:break
                            w.write(chunk)
                    path.with_suffix('.part').rename(path)
                except Exception:
                    path.with_suffix('.part').unlink(missing_ok=True)
                    raise
            if path.stat().st_size<1024:raise IOError(f'suspiciously small EDF: {path}')
            reports.append({'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                            'source':f'{BASE}S{subj:03d}/{filename}','license':'ODC-By 1.0'})
    return reports
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--subjects',type=int,nargs='+',default=[1,2,3]);a.add_argument('--runs',type=int,nargs='+',default=[3,7,11]);a.add_argument('--out',default='physionet_edf');args=a.parse_args()
    for v in fetch(args.subjects,args.runs,args.out):print(v)
