"""Independent reproducible extractor for source's 125Hz 500x16 human EEG CSV.
No unverified filename-to-mental-state interpretation.
"""
from __future__ import annotations
from pathlib import Path
import csv,json,hashlib,argparse
import numpy as np

SOURCE_SHA={
'S1R1I2_1.csv':'0ad9a56ca1a11b406b948c5f3425996418a51d9d',
'S1R1I2_2.csv':'26d80f5708466adf9b30102e8e3f0e275618cbc9',
'S1R1I3_1.csv':'1f0390635e0a96009b8daa9f1a078b531d2ee5a7',
'S1R1I3_2.csv':'01b8759ad0fb355f38dc40ef9d6ea9ae12e772f5',
'S2R1I2_1.csv':'f46e9eae2d215e4ccfcc4defba3e73a128c7c88d',
'S2R1I2_2.csv':'d88a0fd9fd152622f4b542e01af40cbcc141d79b',
'S2R1I3_1.csv':'a76a5d81acb23f3301abdabdbaf7c07b853a8810',
'S2R1I3_2.csv':'03ff7aa662e6112b445ad43973f2d238d80c5a4',
'S3R1I2_1.csv':'b2534ca156cff23fe28d5d099a9b128c910aae38',
'S3R1I2_2.csv':'d66624fd1a5ff868c835de98554249c238db8236',
'S3R1I3_1.csv':'2dc9a6c1aa5e099ba7b4689f130a2043483fceb5',
'S3R1I3_2.csv':'72af9507c4b1a72ebcca6e0e308246b7027ee7ae',
'S4R1I2_1.csv':'2875e21fe1e2d83089eab5a8bd15d8c758574999',
'S4R1I2_2.csv':'2520ba84ca5ec649cdc3690d7e3b6be3049de76a',
'S4R1I3_1.csv':'1b337e5239154e19cfb2f4de117d1ccef8b1b121',
'S4R1I3_2.csv':'fe05de017ff002f6cdd3ba865598edd7cd4e9620',
'S5R1I2_1.csv':'4af71a6597560e0b0e97f190f5259bc55435f74f',
'S5R1I2_2.csv':'1d6518a8e2fc34591fd7570373a19d16693fcb19',
'S5R1I3_1.csv':'1e6978dc2b298f145afc336465494a3502f8c45a',
'S5R1I3_2.csv':'af81606f58bb9d7fd30b71f4b6109738e5566959',
'S6R1I2_1.csv':'9ce5bafe5a5134dfe61a81d0ed332a5fbc4d372b',
'S6R1I2_2.csv':'4c85c791bbd04312b54d4e8681c86094ee75492f',
'S6R1I3_1.csv':'84303b07688f60abd568d8b89c53ad3e8bff294d',
'S6R1I3_2.csv':'3efa517412cfc67f2ed79ecd92426e23172bb770'
}

def numeric_features(path, *, verify_hash=True):
    path=Path(path)
    if verify_hash and path.name in SOURCE_SHA:
        # Github Git blob SHA-1 is NOT SHA-256 of raw file. Verify Git Blob bytes.
        raw=path.read_bytes()
        blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
        if blob!=SOURCE_SHA[path.name]:raise ValueError(f'published source revision mismatch: {path.name}')
    with path.open(newline='') as f:
        reader=csv.reader(f)
        header=next(reader)
        if header!=['']+[str(i) for i in range(16)]:raise ValueError('unexpected electrode columns')
        data=np.asarray([[float(x) for x in row] for row in reader])
    if data.shape!=(500,17) or not np.array_equal(data[:,0],np.arange(500)) or not np.all(np.isfinite(data)):
        raise ValueError('source CSV shape/nonfinite/index invalid')
    N=500; t=np.arange(N,dtype=float)/125;w=np.hanning(N);bands=[]
    for c in (11,14):
        v=(data[:,c]-data[:,c].mean())*w
        sums=[0.,0.,0.,0.]
        for freq in range(4,45):
            amp=np.sum(v*np.exp(-2j*np.pi*freq*t))
            k=0 if freq<8 else 1 if freq<13 else 2 if freq<30 else 3
            sums[k]+=float(np.abs(amp)**2)/(N*N)
        bands.append([np.log10(z+1e-8) for z in sums])
    return np.asarray([bands[c][b] for b in range(4) for c in range(2)])

def audit_source_folder(root,features_json):
    target=json.loads(Path(features_json).read_text()); mismatches=[];verified=0
    for subject,label,name,stored in target['trials']:
        path=Path(root)/subject/name
        if not path.is_file(): mismatches.append({'file':str(path),'error':'missing'});continue
        try:
            actual=numeric_features(path)
            if not np.allclose(actual,np.asarray(stored),atol=2e-6,rtol=0):
                raise ValueError('derived values disagree with frozen features')
            verified+=1
        except Exception as exc:mismatches.append({'file':str(path),'error':str(exc)})
    return {'verified':verified,'expected':len(target['trials']),'mismatches':mismatches,'status':'pass' if not mismatches else 'fail'}
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--root',required=True);a.add_argument('--features',default='data_public/openbci_real_derived_features.json');args=a.parse_args()
    print(json.dumps(audit_source_folder(args.root,args.features),indent=2))
