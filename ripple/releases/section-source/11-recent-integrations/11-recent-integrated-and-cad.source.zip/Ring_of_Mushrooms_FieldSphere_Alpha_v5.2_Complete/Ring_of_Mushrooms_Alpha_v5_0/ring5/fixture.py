"""Synthetic full-stack fixture. All origin labels explicitly simulated."""
from pathlib import Path
import json,csv
import cv2,numpy as np

def create(root='results_v5/synthetic_sync_fixture', *,fps=15,seconds=4):
    root=Path(root);root.mkdir(parents=True,exist_ok=True)
    fourcc=cv2.VideoWriter_fourcc(*'MJPG')
    path=root/'simulated_camera.avi'; writer=cv2.VideoWriter(str(path),fourcc,fps,(48,48))
    if not writer.isOpened():raise RuntimeError('MJPG fixture encode unavailable')
    frames=int(fps*seconds)
    for i in range(frames):
        pic=np.zeros((48,48,3),dtype=np.uint8)
        pic[:,:,2]=round(80+60*np.sin(2*np.pi*i/fps));pic[:,:,1]=130
        writer.write(pic)
    writer.release()
    sf=125.;shift=1700000000.;source_t=shift+np.arange(int((seconds+.5)*sf))/sf
    ts=np.arange(len(source_t))/sf
    eeg=np.stack(((6+12*(ts>2.4))*np.sin(2*np.pi*10*ts),(10-6*(ts>2.4))*np.sin(2*np.pi*20*ts))).T
    cam_t=700.+np.arange(frames)/fps
    np.savez_compressed(root/'simulated_dual_capture.npz',frame_monotonic_s=cam_t,
                        eeg_device_timestamp_s=source_t,eeg_uv=eeg.astype('float32'),
                        start_wall_unix_s=shift,start_monotonic_s=700.)
    with (root/'SYNTHETIC_clock_anchors.csv').open('w',newline='') as f:
        writer=csv.writer(f);writer.writerow(['eeg_device_timestamp_s','camera_monotonic_s'])
        for t in range(seconds+1):writer.writerow([shift+t,700+t])
    (root/'PROVENANCE.json').write_text(json.dumps({'camera':'synthetic_video','eeg':'generated_sine_not_human_EEG','anchors':'simulated_clock_pairs','physical_evidence':False},indent=2))
    return root
if __name__=='__main__':print(create())
