"""Full native Ring state save/restore without Python pickles or hidden simulation.
Requires exact parent code version hashes and consistent SQLite session log.
State continuity has independently reproduced output, not just state-file existence.
"""
from __future__ import annotations
import dataclasses, hashlib, io, json, os, sqlite3, zipfile
from collections import defaultdict
from pathlib import Path
import numpy as np
from ring.core import Ring,RingParameters
from mushroom.core import Mushroom
from .engine import Workstation

def _hash(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for buf in iter(lambda:stream.read(1024*1024),b''):h.update(buf)
    return h.hexdigest()

def source_signature():
    root=Path(__file__).resolve().parents[1]
    return {'ring/core.py':_hash(root/'ring/core.py'),
            'parents/Mushroom_Ripple_Alpha_v3_0/mushroom/core.py':_hash(root/'parents/Mushroom_Ripple_Alpha_v3_0/mushroom/core.py')}

def save(station:Workstation, output):
    if station.thread and station.thread.is_alive() and not station.queue.empty():
        raise RuntimeError('drain acquisition before saving an exact checkpoint')
    with station.lock:
        r=station.ring
        rows=station.db.execute('SELECT COUNT(*) FROM observations WHERE session_id=?',(station.session_id,)).fetchone()[0]
        if rows!=len(r.history):raise RuntimeError('database versus Ring history mismatch; no checkpoint')
        metadata={'schema':'mushroom/workstation-checkpoint-1','parent_sha256':source_signature(),
                  'session_id':station.session_id,'ring_params':dataclasses.asdict(r.p),'seed':r.seed,
                  'source_rows':rows,'phase':r.phase.tolist(),'natural':r.natural.tolist(),
                  'ring_weights':[[a,b,w] for (a,b),w in sorted(r.weights.items())],
                  'queue':{str(k):v for k,v in r.queue.items()},'ring_history':r.history,
                  'ring_delivered':r.delivered_total,'ring_generated':r.generated_total,
                  'ring_marked':r._marked,'ring_prev_counts':r._prev_counts.tolist(),
                  'ring_rng_state':r.rng.bit_generator.state,
                  'children':[{'checkpoint':m.checkpoint(),'history':m.history} for m in r.children],
                  'last_input_monotonic_s':station._last_time,
                  'stats':station.snapshot()}
        if r.previous is None:previous=np.empty((0,0,3),dtype=np.uint8)
        else:previous=r.previous
        buff=io.BytesIO();np.save(buff,previous,allow_pickle=False)
        j=json.dumps(metadata,separators=(',',':'),allow_nan=False).encode();payload=buff.getvalue()
        md={'metadata_sha256':hashlib.sha256(j).hexdigest(),
            'last_frame_npy_sha256':hashlib.sha256(payload).hexdigest()}
        dest=Path(output);dest.parent.mkdir(parents=True,exist_ok=True)
        tmp=dest.with_suffix(dest.suffix+'.tmp')
        with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED) as z:
            z.writestr('state.json',j);z.writestr('last_frame.npy',payload);z.writestr('checksums.json',json.dumps(md))
        os.replace(tmp,dest)
        return {'session_id':station.session_id,'rows':rows,'sha256':_hash(dest),'output':str(dest)}

def load(station:Workstation, path):
    if station.thread and station.thread.is_alive() and not station.queue.empty():raise RuntimeError('stop/drain live acquisition first')
    if station.ring.history:raise RuntimeError('refuse overwrite of active neuron state')
    with zipfile.ZipFile(path) as z:
        if sum(x.file_size for x in z.infolist()) > 32_000_000:raise ValueError('checkpoint exceeds bounded size')
        if set(z.namelist())!={'state.json','last_frame.npy','checksums.json'}:raise ValueError('unknown checkpoint fields')
        j=z.read('state.json');payload=z.read('last_frame.npy');checks=json.loads(z.read('checksums.json'))
        if hashlib.sha256(j).hexdigest()!=checks['metadata_sha256'] or hashlib.sha256(payload).hexdigest()!=checks['last_frame_npy_sha256']:
            raise ValueError('checkpoint file checksum failure')
        m=json.loads(j);previous=np.load(io.BytesIO(payload),allow_pickle=False)
    if m.get('schema')!='mushroom/workstation-checkpoint-1':raise ValueError('unknown schema')
    if m['parent_sha256']!=source_signature():raise ValueError('inherited source differs; cannot safely resume')
    if len(m['children'])!=8:raise ValueError('wrong child count')
    db_count=station.db.execute('SELECT COUNT(*) FROM observations WHERE session_id=?',(m['session_id'],)).fetchone()[0]
    if db_count!=m['source_rows'] or len(m['ring_history'])!=db_count:
        raise ValueError('database log/checkpoint mismatch: no silent state reuse')
    r=Ring(RingParameters(**m['ring_params']),seed=int(m['seed']))
    r.children=[Mushroom.from_checkpoint(x['checkpoint']) for x in m['children']]
    for c,x in zip(r.children,m['children']):c.history=x['history']
    r.phase=np.array(m['phase'],float);r.natural=np.array(m['natural'],float)
    r.weights={(int(a),int(b)):float(w) for a,b,w in m['ring_weights']}
    if set(r.weights)!={(a,b) for a in range(8) for b in ((a-1)%8,(a+1)%8)}:raise ValueError('invalid checkpoint ring connections')
    r.queue=defaultdict(list,{int(k):[tuple(item) for item in v] for k,v in m['queue'].items()})
    r.history=m['ring_history'];r.delivered_total=int(m['ring_delivered']);r.generated_total=int(m['ring_generated'])
    r._marked=int(m['ring_marked']);r._prev_counts=np.array(m['ring_prev_counts'],dtype=int)
    if previous.size and (previous.ndim!=3 or previous.dtype!=np.uint8 or previous.shape[2]!=3):raise ValueError('bad previous frame')
    r.previous=previous.copy() if previous.size else None
    r.rng.bit_generator.state=m['ring_rng_state']
    with station.lock:
        station.ring=r;station.session_id=m['session_id'];station._last_time=m['last_input_monotonic_s']
        station._last_shape=None if r.previous is None else r.previous.shape
        station.stats=dict(m['stats'])
    return {'restored_rows':db_count,'session_id':station.session_id,'neurons':216}
