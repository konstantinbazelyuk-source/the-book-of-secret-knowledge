"""50 paired ring on/off software replicates over identical decoded synthetic video.
Tests causal computational effect, not intelligence or physical responsiveness."""
from __future__ import annotations
import argparse,json,time
from pathlib import Path
import cv2,numpy as np
from ring.core import Ring,RingParameters

def execute(video,*,replicates=50,max_frames=24):
    cap=cv2.VideoCapture(str(video))
    if not cap.isOpened():raise RuntimeError('video absent; no fabricated frames')
    frames=[]
    try:
        while len(frames)<max_frames:
            ok,f=cap.read()
            if not ok:break
            frames.append(f)
    finally:cap.release()
    if len(frames)<8:raise ValueError('needs at least 8 decoded frames')
    data=[]
    for seed in range(replicates):
        record={'seed':seed,'frames':len(frames)}
        for name,coupled in [('ring_on',True),('ring_off',False)]:
            ring=Ring(RingParameters(fps=15,recurrent=coupled,plasticity=0.012 if coupled else 0),seed=seed+500)
            tick=time.perf_counter()
            for frame in frames:ring.step(frame,source_type='synthetic_frame')
            runtime_s=time.perf_counter()-tick
            summary=ring.summary()
            record[name]={'model_spikes':summary['spikes_total'],'delivered_pulses':summary['delivered_pulses'],
                          'phase_order':summary['mean_phase_order'],'runtime_s':runtime_s,'markers':summary['markers']}
        data.append(record)
    differences=np.array([r['ring_on']['model_spikes']-r['ring_off']['model_spikes'] for r in data],dtype=float)
    return {'provenance':'synthetic_video_rendered_then_decoded_by_opencv','replicate_count':replicates,
            'independence':'50 model initializations on SAME synthetic frames, not independent real-world observations',
            'frames_per_run':len(frames),'model_spikes_difference_mean_on_minus_off':float(differences.mean()),
            'model_spikes_difference_min_max':[int(differences.min()),int(differences.max())],
            'per_seed':data,'evidence_limit':'Computational ablation only. Any claimed improvement requires task-level ground truth.'}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--video',default='results_v5/synthetic_sync_fixture/simulated_camera.avi');p.add_argument('--replicates',type=int,default=50);p.add_argument('--out',default='results_v51/ablation_50.json');a=p.parse_args()
    r=execute(a.video,replicates=a.replicates);dest=Path(a.out);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(json.dumps(r,indent=2));print(json.dumps({k:r[k] for k in ('replicate_count','frames_per_run','model_spikes_difference_mean_on_minus_off','model_spikes_difference_min_max')},indent=2))
