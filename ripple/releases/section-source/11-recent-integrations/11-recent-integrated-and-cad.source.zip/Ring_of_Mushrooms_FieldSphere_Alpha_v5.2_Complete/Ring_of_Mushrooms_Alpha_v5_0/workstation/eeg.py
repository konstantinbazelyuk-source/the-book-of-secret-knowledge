"""Actual EDF reading and spectral report (not diagnostic, no fake source)."""
from __future__ import annotations
import json,hashlib
from pathlib import Path
import numpy as np
from ring5.eeg_features import band_features, BANDS

def inspect_edf(path:str):
    import mne
    p=Path(path)
    if not p.is_file() or p.suffix.lower()!='.edf':raise FileNotFoundError('select existing EDF file')
    raw=mne.io.read_raw_edf(str(p),preload=False,verbose='ERROR')
    fs=float(raw.info['sfreq']);idx=mne.pick_types(raw.info,eeg=True)
    if len(idx)<2:raise ValueError('EDF has <2 EEG channels; select appropriate channels')
    if not 100<=fs<=2000 or raw.n_times<int(2*fs):raise ValueError('EEG sampling/window outside analyzer contract')
    subset=raw.get_data(picks=idx[:2],start=0,stop=int(2*fs))*1e6
    v=band_features(subset,fs)
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return {'source':'real_file_decoded_not_physiologically_authenticated','file':p.name,'sha256':h.hexdigest(),
            'sampling_rate_hz':fs,'samples':raw.n_times,'channels':[raw.ch_names[int(i)] for i in idx[:2]],
            'first_2s_log10_band_power_by_channel':{band:[float(v[i*2]),float(v[i*2+1])] for i,band in enumerate(BANDS)},
            'units':'log10(1e-8+Welch band power uV^2)','interpretation':'spectral measurement only, not mental state'}
