"""Exploratory real-recording EEG study: all 10 unique two-subject holdouts.
Fifty label-permutation null repetitions are explicitly NOT independent subjects.
"""
from __future__ import annotations
import argparse,itertools,json
from pathlib import Path
import numpy as np
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score
from ring5.evaluate import frozen_ring_features

def compare_real(*,null_permutations=50):
    if not 0<=null_permutations<=500:raise ValueError('bounded permutations 0..500')
    src=Path(__file__).resolve().parents[1]/'data_public/openbci_real_derived_features.json'
    payload=json.loads(src.read_text());tr=payload['trials']
    X=np.array([i[3] for i in tr],float);y=np.array([i[1] for i in tr],int);g=np.array([i[0] for i in tr])
    if len(np.unique(g))!=5 or len(tr)!=20:raise ValueError('unexpected source cohort: review provenance')
    rc=frozen_ring_features(X,coupled=True);rd=frozen_ring_features(X,coupled=False)
    splits=[]
    for holdout in itertools.combinations(sorted(set(g)),2):
        tst=np.isin(g,holdout);trn=~tst
        if not set(g[trn]).isdisjoint(g[tst]):raise AssertionError('subject leakage')
        splits.append((holdout,trn,tst))
    def score(x,y0):
        rows=[]
        for groups,train,test in splits:
            m=make_pipeline(StandardScaler(),LogisticRegression(max_iter=400,random_state=7))
            m.fit(x[train],y0[train]);pred=m.predict(x[test])
            rows.append({'subjects_held_out':list(groups),'balanced_accuracy':float(balanced_accuracy_score(y0[test],pred))})
        return rows
    methods={'spectral_logistic':X,'ring_uncoupled':rd,'ring_coupled':rc}
    observed={k:score(v,y) for k,v in methods.items()}
    means={k:float(np.mean([s['balanced_accuracy'] for s in arr])) for k,arr in observed.items()}
    rng=np.random.default_rng(20261015);null={k:[] for k in methods}
    for _ in range(null_permutations):
        yp=y.copy()
        for grp in np.unique(g):
            ix=np.flatnonzero(g==grp);yp[ix]=rng.permutation(yp[ix])
        for key,x in methods.items():null[key].append(float(np.mean([r['balanced_accuracy'] for r in score(x,yp)])))
    p={k:float((1+sum(v>=means[k] for v in null[k]))/(1+len(null[k]))) if null_permutations else None for k in methods}
    return {'data':'published_derived_human_EEG_features_MILimbEEG_I2_vs_I3_filename_labels','subjects':len(set(g)),'records':len(y),
            'unique_subject_holdout_combinations':len(splits),'experiment_predefined':False,
            'means_balanced_accuracy':means,'per_group_holdout':observed,'permutation_count':null_permutations,
            'within_subject_label_permutation_p_one_sided_exploratory':p,
            'warnings':['Very small public subset; no pre-registration, subject independence only at holdout level.',
                'Original EEG source label semantics not independently certified.',
                'No camera alignment or physical hardware inference; not a medical classifier.',
                '50 permutations are null resampling, NOT 50 independent subjects or 50 cultures.']}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',default='results_v51/real_eeg_unique_holdouts.json');p.add_argument('--permutations',type=int,default=50);a=p.parse_args()
    r=compare_real(null_permutations=a.permutations);out=Path(a.out);out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(r,indent=2));print(json.dumps({k:r[k] for k in ('subjects','unique_subject_holdout_combinations','means_balanced_accuracy','within_subject_label_permutation_p_one_sided_exploratory')},indent=2))
