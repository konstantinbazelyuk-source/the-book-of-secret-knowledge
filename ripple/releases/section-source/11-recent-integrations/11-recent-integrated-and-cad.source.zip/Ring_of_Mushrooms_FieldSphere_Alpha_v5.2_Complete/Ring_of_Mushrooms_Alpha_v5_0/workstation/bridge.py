"""USB-only Android phone camera bridge. Intended for `adb reverse tcp:8789 tcp:8789`.
Default bind 127.0.0.1; no internet exposure. Requires short-lived random token.
A client claiming physical pixels is NOT an independently attested optical measurement.
"""
from __future__ import annotations
import http.server, json, secrets, threading, time
from urllib.parse import urlparse
import cv2,numpy as np
from .engine import FramePacket

MAX_JPEG=2_000_000
class PhoneServer:
    def __init__(self,workstation,*,token=None,port=8789):
        self.station=workstation;self.token=token or secrets.token_urlsafe(24)
        if len(self.token)<24: raise ValueError('token must have at least 24 characters')
        ctx=self
        class Handler(http.server.BaseHTTPRequestHandler):
            def _json(self,code,data):
                raw=json.dumps(data,allow_nan=False).encode()
                self.send_response(code);self.send_header('Content-Type','application/json');self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
            def _auth(self):return secrets.compare_digest(self.headers.get('Authorization',''), 'Bearer '+ctx.token)
            def do_GET(self):
                if not self._auth():return self._json(401,{'error':'invalid session token'})
                if self.path!='/status':return self._json(404,{'error':'not found'})
                return self._json(200,ctx.station.snapshot())
            def do_POST(self):
                if not self._auth():return self._json(401,{'error':'invalid session token'})
                if self.path!='/frame':return self._json(404,{'error':'not found'})
                if self.headers.get('Content-Type','').split(';')[0]!='image/jpeg':return self._json(415,{'error':'JPEG only'})
                try:n=int(self.headers.get('Content-Length','0'))
                except ValueError:return self._json(400,{'error':'invalid content length'})
                if not 128<=n<=MAX_JPEG:return self._json(413,{'error':'bad JPEG size'})
                payload=self.rfile.read(n)
                if len(payload)!=n:return self._json(400,{'error':'truncated payload'})
                im=cv2.imdecode(np.frombuffer(payload,dtype=np.uint8),cv2.IMREAD_COLOR)
                if im is None or im.ndim!=3:return self._json(422,{'error':'undecodable JPEG'})
                h,w=im.shape[:2]
                if w>1920 or h>1080 or w*h>2073600 or w<24 or h<24:return self._json(413,{'error':'unsupported image dimensions'})
                stamp=self.headers.get('X-Device-Monotonic-Ns','')
                try:stamp=int(stamp) if stamp else None
                except ValueError:return self._json(400,{'error':'invalid timestamp'})
                try:ctx.station.submit(FramePacket(im,time.monotonic(),'android_usb_bridge',stamp))
                except (ValueError,RuntimeError) as e:return self._json(422,{'error':str(e)})
                return self._json(202,{'queued':True,'queue_depth':ctx.station.queue.qsize(),
                    'timing':'host_receipt_monotonic_not_camera_exposure','source':'remote_client_claim_unverified'})
            def log_message(self,*_):pass
        self.server=http.server.ThreadingHTTPServer(('127.0.0.1',port),Handler)
        self.thread=None
    def start(self):
        self.station.start();self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
    def stop(self):
        self.server.shutdown();self.server.server_close()
        if self.thread:self.thread.join(3)
