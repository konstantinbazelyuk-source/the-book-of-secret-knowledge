"""Run under xvfb-run. Invokes actual Tk buttons, real OpenCV frames and CSV export."""
from __future__ import annotations
import os,tempfile,time,tkinter as tk,sys
sys.path.insert(0,str(__import__("pathlib").Path(__file__).resolve().parents[1]))
from pathlib import Path
from tkinter import filedialog
from workstation.app import start_gui

root_folder=Path(__file__).resolve().parents[1]
video=str(root_folder/'results_v5/synthetic_sync_fixture/simulated_camera.avi')
tmp=Path(tempfile.mkdtemp(prefix='mushroom_xvfb_'))
filedialog.askopenfilename=lambda **_:video
filedialog.asksaveasfilename=lambda **_:str(tmp/'export.csv')
original=tk.Tk.mainloop

def wrapped(self,*args,**kwargs):
    def buttons(node):
        found=[]
        for child in node.winfo_children():
            if isinstance(child,tk.Button) or child.winfo_class()=='TButton':found.append(child)
            found+=buttons(child)
        return found
    bt={v.cget('text'):v for v in buttons(self)}
    for key in ['Analyze video','Export CSV','Android USB link']:
        if key not in bt:raise AssertionError('Missing functional GUI button '+key)
    bt['Analyze video'].invoke()
    def verify():
        bt['Export CSV'].invoke()
        def check():
            import sqlite3
            with sqlite3.connect(tmp/'station.db') as db: n=db.execute('SELECT count(*) FROM observations').fetchone()[0]
            assert n==60,n
            assert (tmp/'export.csv').exists(), 'Export CSV failed'
            assert sum(1 for _ in (tmp/'export.csv').open())==61
            print(f'GUI INVOCATION PASS: {n} real OpenCV-decoded synthetic-source frames; exported rows={n}')
            self.event_generate('<<closeRequested>>')
        self.after(1200,check)
    self.after(1800,verify)
    self.bind('<<closeRequested>>',lambda evt:self.destroy())
    return original(self,*args,**kwargs)
tk.Tk.mainloop=wrapped
try:start_gui(str(tmp/'station.db'))
finally:tk.Tk.mainloop=original
