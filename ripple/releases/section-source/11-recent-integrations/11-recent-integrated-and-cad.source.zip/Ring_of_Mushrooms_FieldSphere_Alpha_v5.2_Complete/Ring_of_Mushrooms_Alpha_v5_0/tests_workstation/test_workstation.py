import io,json,os,sqlite3,tempfile,threading,time,unittest,urllib.error,urllib.request
from pathlib import Path
import cv2,numpy as np
from workstation.engine import Workstation,FramePacket,playback,CameraCapture
from workstation.bridge import PhoneServer
from workstation.app import diagnostics,export_csv
from workstation.eeg import inspect_edf

class WorkstationTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.db=Path(self.tmp.name)/'test.sqlite';self.station=Workstation(self.db)
    def tearDown(self):
        self.station.close();self.tmp.cleanup()
    def pkt(self,t=1.,val=44,source='video_file'):
        return FramePacket(np.full((32,32,3),val,np.uint8),float(t),source)
    def test_real_ring_calls(self):
        a=self.station.process(self.pkt(1,15));b=self.station.process(self.pkt(2,200));
        self.assertEqual(self.station.stats['processed'],2);self.assertEqual(len(self.station.ring.children),8)
        self.assertNotEqual(a['frame_sha256'],b['frame_sha256'])
        self.assertEqual(self.station.ring.summary()['cells'],216)
    def test_sqlite_actual(self):
        self.station.process(self.pkt());
        with sqlite3.connect(self.db) as db:
            self.assertEqual(db.execute('SELECT COUNT(*) FROM observations').fetchone()[0],1)
            self.assertEqual(db.execute('SELECT source FROM observations').fetchone()[0],'video_file')
    def test_source_unknown_rejected(self):
        with self.assertRaises(ValueError):FramePacket(np.zeros((32,32,3),np.uint8),1,'EEG')
    def test_fabricated_missing_camera_not_replaced(self):
        capture=CameraCapture(self.station,index=9999)
        with self.assertRaises(RuntimeError):capture.start()
        self.assertEqual(self.station.stats['processed'],0)
    def test_invalid_input(self):
        with self.assertRaises(ValueError):self.station.process(FramePacket(np.zeros((8,8,3),np.uint8),1,'video_file'))
    def test_monotonic_required(self):
        self.station.process(self.pkt(2))
        with self.assertRaises(ValueError):self.station.process(self.pkt(1))
    def test_shape_mutation_rejected(self):
        self.station.process(self.pkt(2))
        with self.assertRaises(ValueError):self.station.process(FramePacket(np.zeros((40,40,3),np.uint8),3,'video_file'))
    def test_bounded_queue_drops_not_fake_work(self):
        self.station.submit(self.pkt(1));self.station.submit(self.pkt(2));self.station.submit(self.pkt(3));self.station.submit(self.pkt(4));
        self.assertEqual(self.station.snapshot()['dropped'],1)
        self.assertEqual(self.station.snapshot()['processed'],0)
    def test_worker_consumes(self):
        self.station.start();self.station.submit(self.pkt(1));self.station.queue.join()
        self.assertEqual(self.station.snapshot()['processed'],1)
    def test_export(self):
        self.station.process(self.pkt(1));p=Path(self.tmp.name)/'export.csv'
        self.assertEqual(export_csv(self.db,p),1);self.assertIn('model_spikes',p.read_text())
    def test_video_opencv_decode(self):
        path=str(Path(self.tmp.name)/'a.avi');v=cv2.VideoWriter(path,cv2.VideoWriter_fourcc(*'MJPG'),15,(32,32))
        self.assertTrue(v.isOpened())
        for i in range(6):v.write(np.full((32,32,3),i*40,np.uint8))
        v.release();self.assertEqual(playback(self.station,path,frame_limit=6),6)
        self.assertEqual(self.station.stats['processed'],6)
    def test_nonexistent_video(self):
        with self.assertRaises(FileNotFoundError):playback(self.station,str(Path(self.tmp.name)/'missing.mp4'))
    def test_missing_edf_is_rejected(self):
        with self.assertRaises(FileNotFoundError):inspect_edf('/nonexistent/eeg.edf')
    def test_device_timestamp_checks(self):
        with self.assertRaises(ValueError):FramePacket(np.zeros((32,32,3),np.uint8),1,'android_usb_bridge',-1)
    def test_diagnostics_not_fabricated(self):
        d=diagnostics();self.assertIn('platform',d);self.assertNotIn('SM-A176U',str(d))

class BridgeTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.station=Workstation(Path(self.tmp.name)/'x.db')
        self.srv=PhoneServer(self.station,token='a'*32,port=0);self.srv.start()
        self.port=self.srv.server.server_port
    def tearDown(self):
        self.srv.stop();self.station.close();self.tmp.cleanup()
    def call(self,body=b'',token=None,ctype='image/jpeg',endpoint='/frame',method='POST'):
        headers={'Content-Type':ctype}
        if token:headers['Authorization']='Bearer '+token
        req=urllib.request.Request(f'http://127.0.0.1:{self.port}{endpoint}',data=body if method=='POST' else None,headers=headers,method=method)
        try:
            with urllib.request.urlopen(req,timeout=4) as r:return r.status,json.load(r)
        except urllib.error.HTTPError as e:return e.code,json.loads(e.read())
    def test_reject_unauthorized(self):
        self.assertEqual(self.call(b'x'*200)[0],401)
        self.assertEqual(self.station.stats['submitted'],0)
    def test_reject_non_jpeg(self):
        self.assertEqual(self.call(b'x'*300,'a'*32,'text/plain')[0],415)
    def test_reject_large(self):
        self.assertEqual(self.call(b'x'*(2_000_001),'a'*32)[0],413)
    def test_reject_undecodable(self):
        self.assertEqual(self.call(b'x'*300,'a'*32)[0],422)
    def test_actual_cv2_photo_to_ring(self):
        okay,data=cv2.imencode('.jpg',np.full((40,60,3),(10,50,150),np.uint8))
        self.assertTrue(okay)
        self.assertEqual(self.call(data.tobytes(),'a'*32)[0],202)
        self.station.queue.join()
        self.assertEqual(self.station.snapshot()['processed'],1)
        with sqlite3.connect(self.station.db_path) as db:self.assertEqual(db.execute('SELECT source FROM observations').fetchone()[0],'android_usb_bridge')
    def test_auth_required_for_status(self):
        self.assertEqual(self.call(method='GET')[0],401)
        self.assertEqual(self.call(method='GET',endpoint='/status',token='a'*32)[0],200)
    def test_not_bound_remote(self):
        self.assertEqual(self.srv.server.server_address[0],'127.0.0.1')
    def test_token_minimum(self):
        with self.assertRaises(ValueError):PhoneServer(self.station,token='weak',port=0)

class CheckpointTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.p=Path(self.tmp.name)
    def tearDown(self):self.tmp.cleanup()
    def pkt(self,i):
        return FramePacket(np.full((32,32,3),(50+i*17)%255,np.uint8),float(i),'video_file')
    def test_exact_restart_model_parity(self):
        from workstation.checkpoint import save,load
        orig=Workstation(self.p/'orig.db')
        try:
            for i in range(1,10):orig.process(self.pkt(i))
            reference=orig.ring.history[-1]
        finally:orig.close()
        a=Workstation(self.p/'resume.db')
        for i in range(1,7):a.process(self.pkt(i))
        state=save(a,self.p/'resume.ringstate');a.close()
        b=Workstation(self.p/'resume.db')
        try:
            info=load(b,self.p/'resume.ringstate')
            self.assertEqual(info['restored_rows'],6)
            for i in range(7,10):b.process(self.pkt(i))
            restarted=b.ring.history[-1]
            self.assertEqual(restarted['counts'],reference['counts'])
            self.assertEqual(restarted['phase_rad'],reference['phase_rad'])
            self.assertEqual(restarted['delivered_ring_pulses'],reference['delivered_ring_pulses'])
            self.assertEqual(restarted['ring_weight_mean'],reference['ring_weight_mean'])
        finally:b.close()
    def test_refuse_mismatching_db_log(self):
        from workstation.checkpoint import save,load
        a=Workstation(self.p/'a.db');a.process(self.pkt(1));save(a,self.p/'c.ringstate');a.close()
        b=Workstation(self.p/'empty.db')
        try:
            with self.assertRaises(ValueError):load(b,self.p/'c.ringstate')
        finally:b.close()
    def test_corrupted_state_refused(self):
        from workstation.checkpoint import save,load
        a=Workstation(self.p/'a.db');a.process(self.pkt(1));save(a,self.p/'c.ringstate');a.close()
        b=Workstation(self.p/'a.db')
        try:
            import zipfile
            p=self.p/'c.ringstate';contents={}
            with zipfile.ZipFile(p) as z:contents={name:z.read(name) for name in z.namelist()}
            contents['state.json']=contents['state.json'].replace(b'"seed":101',b'"seed":102')
            with zipfile.ZipFile(p,'w') as z:
                for name,data in contents.items():z.writestr(name,data)
            with self.assertRaises(ValueError):load(b,p)
        finally:b.close()

if __name__=="__main__": unittest.main()
