import unittest,tempfile,csv
from pathlib import Path
import numpy as np
from ring.eeg import eeg_csv
class EEGIOTests(unittest.TestCase):
 def test_generated_file_alpha(self):
  x=eeg_csv('tests/generated_eeg_sine_10hz_128hz.csv')
  self.assertAlmostEqual(x['sample_rate_hz'],128,places=4)
  self.assertGreater(x['bandpowers']['alpha']['per_channel_uv_squared'][0],x['bandpowers']['theta']['per_channel_uv_squared'][0])
 def test_bad_timestamp_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'bad.csv';p.write_text('time_s,uv\n'+'\n'.join(f'{int(i//2)},1' for i in range(80)))
   with self.assertRaises(ValueError):eeg_csv(str(p))
 def test_missing_column_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'bad.csv';p.write_text('t,uv\n1,2\n')
   with self.assertRaises(ValueError):eeg_csv(str(p))

class EegRingInjectionTests(unittest.TestCase):
 def test_eeg_positive_exc(self):
  from ring.core import Ring
  import numpy as np
  f=np.full((48,48,3),140,dtype=np.uint8)
  a=Ring(seed=17);b=Ring(seed=17)
  ra=a.step(f,eeg_drive_uv=100);rb=b.step(f)
  self.assertEqual(ra['eeg_pulse'],4)
  self.assertGreater(a.children[7].neurons[13].exc,b.children[7].neurons[13].exc)
 def test_eeg_negative_inh(self):
  from ring.core import Ring
  import numpy as np
  f=np.full((48,48,3),140,dtype=np.uint8)
  a=Ring(seed=17);b=Ring(seed=17)
  ra=a.step(f,eeg_drive_uv=-100);rb=b.step(f)
  self.assertEqual(ra['eeg_pulse'],4)
  self.assertGreater(a.children[7].neurons[13].inh,b.children[7].neurons[13].inh)
 def test_invalid_eeg_fails(self):
  from ring.core import Ring
  import numpy as np
  with self.assertRaises(ValueError):Ring().step(np.zeros((36,36,3),np.uint8),eeg_drive_uv=float('nan'))
 def test_aligned_real_numeric_file(self):
  from ring.eeg import aligned_eeg_drive
  arr=aligned_eeg_drive('tests/generated_eeg_sine_10hz_128hz.csv',fps=24,steps=48)
  self.assertEqual(len(arr),48)
  self.assertTrue(all(np.isfinite(arr)))
