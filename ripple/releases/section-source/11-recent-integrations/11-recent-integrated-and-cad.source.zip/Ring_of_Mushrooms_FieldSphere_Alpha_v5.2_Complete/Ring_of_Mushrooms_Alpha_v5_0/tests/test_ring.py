import json,math,unittest
import numpy as np
import cv2
from ring.core import (Ring,RingParameters,ROLES,model_signature,photon_energy_j,
                       specialized_frame,poisson_camera_proxy)

class RingTests(unittest.TestCase):
    def setUp(self):
        self.frame=np.zeros((36,36,3),dtype=np.uint8)
        self.frame[:,:,2]=190;self.frame[:,:,1]=45;self.frame[:,:,0]=13
    def test_node_number(self):
        r=Ring();self.assertEqual(len(r.children),8)
        self.assertEqual(sum(len(c.neurons) for c in r.children),216)
    def test_108_edges_per_colony(self):
        self.assertEqual(sum(len(c.edges) for c in Ring().children),864)
    def test_ring_geometry(self):
        r=Ring();self.assertEqual(len(r.weights),16)
        for a,b in r.weights:self.assertIn((b-a)%8,(1,7))
    def test_independent_neuron_instances(self):
        r=Ring();self.assertIsNot(r.children[0].neurons[0],r.children[1].neurons[0])
    def test_params_invalid(self):
        for bad in ({'colonies':4},{'fps':7},{'fps':200},{'slider':-1},{'slider':2},{'coupling':-1},{'delay_steps':0},{'delay_steps':5}):
            with self.assertRaises(ValueError):RingParameters(**bad)
    def test_first_step_no_delivered_pulses(self):
        self.assertEqual(Ring().step(self.frame)['delivered_ring_pulses'],0)
    def test_delayed_signal_no_same_tick(self):
        r=Ring();r.queue[1].append((0,1,4));v=r.step(self.frame)
        self.assertEqual(v['delivered_ring_pulses'],0)
        v=r.step(self.frame);self.assertEqual(v['delivered_ring_pulses'],3)
        self.assertEqual(v['regions'][1]['delivered_ring_pulses'],3)
    def test_immutable_parent_source(self):
        import inspect
        from mushroom.core import Mushroom
        self.assertTrue(callable(Mushroom.step))
        self.assertIsInstance(Ring().children[0],Mushroom)
    def test_no_signal_when_decoupled(self):
        r=Ring(RingParameters(recurrent=False));r.queue[0].append((1,2,4))
        self.assertEqual(r.step(self.frame)['delivered_ring_pulses'],0)
    def test_same_seed_same_output(self):
        a,b=Ring(seed=80),Ring(seed=80)
        self.assertEqual(a.step(self.frame)['spikes_total'],b.step(self.frame)['spikes_total'])
        self.assertEqual(a.step(self.frame)['phase_order'],b.step(self.frame)['phase_order'])
    def test_role_red(self):
        out=specialized_frame(self.frame,'red',None,None)
        self.assertTrue(np.all(out[:,:,0]==0) and np.all(out[:,:,1]==0))
    def test_role_green(self):
        out=specialized_frame(self.frame,'green',None,None)
        self.assertTrue(np.all(out[:,:,2]==0) and np.all(out[:,:,0]==0))
    def test_role_blue(self):
        out=specialized_frame(self.frame,'blue',None,None)
        self.assertTrue(np.all(out[:,:,1]==0) and np.all(out[:,:,2]==0))
    def test_role_motion_first_zero(self):
        self.assertEqual(int(specialized_frame(self.frame,'motion',None,None).max()),0)
    def test_role_motion_change(self):
        next_frame=255-self.frame
        self.assertGreater(int(specialized_frame(next_frame,'motion',self.frame,None).max()),0)
    def test_role_texture_constant(self):
        self.assertEqual(int(specialized_frame(self.frame,'texture',None,None).max()),0)
    def test_role_luminance(self):
        self.assertGreater(int(specialized_frame(self.frame,'luminance',None,None).mean()),0)
    def test_role_shadow(self):
        l=specialized_frame(self.frame,'luminance',None,None)
        d=specialized_frame(self.frame,'shadow',None,None)
        self.assertTrue(np.all(l.astype(int)+d.astype(int)==255))
    def test_role_alphabet(self):
        self.assertTrue(np.array_equal(specialized_frame(self.frame,'alphabet',None,None),self.frame))
    def test_bad_input_rejected(self):
        with self.assertRaises(ValueError):Ring().step(np.zeros((10,10,3),dtype=np.uint8))
    def test_source_must_be_typed(self):
        with self.assertRaises(ValueError):Ring().step(self.frame,source_type='live_physical_verified')
    def test_letter_limit(self):
        with self.assertRaises(ValueError):Ring().step(self.frame,text='A'*65)
    def test_photon_energy(self):
        self.assertAlmostEqual(photon_energy_j(500),3.972891714297857e-19,delta=1e-30)
    def test_photon_invalid(self):
        with self.assertRaises(ValueError):photon_energy_j(0)
    def test_poisson_repeatability(self):
        a=poisson_camera_proxy(self.frame,np.random.default_rng(11))
        b=poisson_camera_proxy(self.frame,np.random.default_rng(11))
        self.assertTrue(np.array_equal(a,b))
    def test_poisson_changes_image(self):
        x=poisson_camera_proxy(self.frame,np.random.default_rng(1),20)
        self.assertFalse(np.array_equal(self.frame,x))
    def test_poisson_variance_mean(self):
        rng=np.random.default_rng(7);samples=rng.poisson(100,size=80000)
        self.assertAlmostEqual(float(samples.var()),100,delta=4)
    def test_signature_nyquist(self):
        h=[{'counts':[1,0,0,0,0,0,0,0]} for _ in range(48)]
        sig=model_signature(h,24)
        self.assertEqual(sig['bands']['gamma']['status'],'unresolvable_at_sampling_rate')
        self.assertEqual(sig['bands']['beta']['power'],None)
        self.assertEqual(sig['bands']['theta']['status'],'calculated_model_spike_power')
    def test_signature_insufficient_samples(self):
        self.assertEqual(model_signature([],24)['status'],'insufficient_samples')
    def test_marker_true_is_multiregion(self):
        r=Ring();
        for _ in range(24):r.step(self.frame)
        self.assertTrue(all(not row['spike_marker'] or sum(c>0 for c in row['counts'])>=2 for row in r.history))
    def test_source_not_transmuted(self):
        r=Ring();r.step(self.frame,source_type='synthetic_frame')
        self.assertEqual(r.summary()['source_types'],['synthetic_frame'])
    def test_real_avi_decodes(self):
        from pathlib import Path
        p=Path('parents/Mushroom_Ripple_Alpha_v3_0/vendor/v24/Master_Ripple_Camera_Alpha_v2_1/camera_fixtures/synthetic_color_target_160f.avi')
        cap=cv2.VideoCapture(str(p));success,frame=cap.read();cap.release()
        self.assertTrue(success)
        self.assertGreater(Ring().step(frame)['phase_order'],0)

if __name__=='__main__':unittest.main()

class ExtendedTests(unittest.TestCase):
    def test_plasticity_config_bound(self):
        with self.assertRaises(ValueError):RingParameters(plasticity=.5)
    def test_plasticity_changes_weights_after_lagged_spikes(self):
        r=Ring(RingParameters(plasticity=.02))
        r._prev_counts=np.ones(8,dtype=int)
        f=np.full((48,48,3),150,dtype=np.uint8)
        for _ in range(18):r.step(f)
        self.assertTrue(any(w!=.2 for w in r.weights.values()))
    def test_plasticity_ablation_keeps_weights(self):
        r=Ring(RingParameters(plasticity=0.))
        import numpy as np
        f=np.full((48,48,3),150,dtype=np.uint8)
        for _ in range(15):r.step(f)
        self.assertEqual(set(r.weights.values()),{.2})
    def test_external_eeg_alpha(self):
        import numpy as np
        from ring.eeg import eeg_signature
        fs=128;t=np.arange(0,6,1/fs)
        s=eeg_signature(t,(5*np.sin(2*np.pi*10*t))[:,None])
        self.assertEqual(s['bandpowers']['alpha']['status'],'calculated')
        self.assertGreater(s['bandpowers']['alpha']['per_channel_uv_squared'][0],s['bandpowers']['theta']['per_channel_uv_squared'][0])
    def test_external_eeg_sampling_reject(self):
        import numpy as np
        from ring.eeg import eeg_signature
        with self.assertRaises(ValueError):eeg_signature(np.arange(80)/30,(np.ones(80))[:,None],source='video_pixels')
    def test_external_eeg_gamma_unavailable_at_128(self):
        import numpy as np
        from ring.eeg import eeg_signature
        t=np.arange(0,4,1/128);x=np.zeros((len(t),1))
        self.assertEqual(eeg_signature(t,x)['bandpowers']['gamma']['status'],'unresolvable')
