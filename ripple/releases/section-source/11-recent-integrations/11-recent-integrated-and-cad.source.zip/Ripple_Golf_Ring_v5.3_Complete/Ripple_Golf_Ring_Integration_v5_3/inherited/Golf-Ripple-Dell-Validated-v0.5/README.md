# Golf Ripple Dell-Validated v0.5

**Start with `README-v0.5.md` and `VERIFY-DELL-WINDOWS.ps1` for the new Windows CPU-training and hardware validation path.**

The following content documents the unchanged inherited v0.4 platform architecture. The exact complete v0.4 archive is preserved in `original-v0.4/`.

---

# Golf Ripple — Laptop-Native Compute Engine v0.4.0-beta.1

This package is **actual executable Python + Node.js source code** with an OS-level worker pool, database, hardware discovery, local API, bounded file and network operations, supervised numeric learning, signal processing and the **unchanged full Golf Metrology v0.3 parent code**. It is an **application runtime on Windows, Linux or macOS**, not a new hardware operating system, self-aware AI, GPU driver, or a physical-sensor measurement system.

**This release was developed and executed in a Linux compute container, NOT on the user's Dell laptop.** The Docker/container measurements cannot be used to infer model, thermal headroom, GPU or speed of the Dell. When started on the Dell, `probe` collects that machine's real available information.

## Install on a Dell running Windows

1. Extract the ZIP into a **private** folder in your user profile, e.g. `Documents\GolfRipple`. Do not place your token in public/shared storage.
2. Install Python 3.11+ and Node.js 20+ (official installers). Confirm `py -3 --version` and `node --version` from PowerShell. This release was **not** executed on Windows and cannot guarantee your actual hardware/driver compatibility until tested there.
3. In that folder, run `py -3 -m pip install -r requirements.txt` (recommended for optical/image and linear-learning modules). If you do not want to install third-party packages, basic file/CPU/SQLite/runtime discovery still works, while image/metrology/learning dependencies may be unavailable.
4. Run `py -3 -m src.cli probe --gpu` to discover the actual host and check for supported CUDA/MPS compute. A listed graphics adapter is **not** proof of GPU compute support.
5. Run `py -3 -m src.cli benchmark` to benchmark the actual CPU parallelism. Results go in `results/benchmark.json` and a host-local scheduler recommendation goes into `runtime/performance.json`. The next server launch can load that recommendation only when the CPU model, effective core count, and age (<7 days) match. Performance may vary between workloads.
6. Double-click `START-GOLF-LAPTOP-WINDOWS.bat`, or run `py -3 -m src.cli serve`. The server listens only at `127.0.0.1:8895`.
7. Use the bearer token displayed by the server and written at initial startup to `runtime\access-token.txt`. Every HTTP operation requires `Authorization: Bearer <token>`.
8. To opt into autostart after interactive Windows login, use `powershell -ExecutionPolicy Bypass -File .\REGISTER-GOLF-WINDOWS.ps1` manually. **This scheduled-task registration was not tested on a physical Windows system.** Do not register until you have run a manual Dell test successfully.

Linux/macOS: `python3 -m pip install -r requirements.txt`, then `python3 -m src.cli probe --gpu`, `python3 -m src.cli benchmark`, `sh START-GOLF-LAPTOP-UNIX.sh`. An optional Linux systemd **user** service installer is included (`REGISTER-GOLF-LINUX-USER.sh`). This installer was not run on a real user session.

## Actual API / operations

```
GET  /api/status                    live scheduler/temperature/memory snapshot
GET  /api/hardware                  actual host model/CPU/RAM/disk/GPU discovery
GET  /api/jobs/{id}                 persistent job state and result
GET  /api/events?limit=30           persistent event ledger
POST /api/jobs                     JSON work submission; 202 + job ID
```

All endpoints require a bearer token. A job example sent with PowerShell (replace token with contents of access-token.txt):

```powershell
$token = (Get-Content .\runtime\access-token.txt).Trim()
$h = @{ Authorization = "Bearer $token" }
Invoke-RestMethod -Uri 'http://127.0.0.1:8895/api/jobs' -Method Post -Headers $h -ContentType 'application/json' -Body '{"op":"cpu_hash","loops":200000,"seed":7}'
Invoke-RestMethod -Uri 'http://127.0.0.1:8895/api/status' -Headers $h
```

Implemented operations: `cpu_hash` (real process-pool computation), `matrix_compute` (verified GPU when supported, otherwise NumPy CPU), `gpu_matmul` (strictly real/verified CUDA or MPS; fails if unavailable), `golf_status`, `golf_selfscan`, `golf_frame`, `golf_goal` (allowlisted invocation of original preserved runtime), `file_list`, `file_write`, `file_read`, `file_digest`, `file_remove`, `text_analyze`, `audio_wav`, `linear_train`, `linear_predict`, `https_probe`, `app_run` (only installed programs explicitly allowlisted with fixed arguments in `config.json`). Unsupported goals are **rejected**. There is **no general shell execution** or unbounded plugin installation capability. To use `app_run`, configure `approved_apps` as a mapping of app names to `{"executable":"<absolute approved path>","arguments":["--version"]}`; the request selects only that name and cannot add arbitrary arguments. `golf_goal` remains constrained by the original Golf goal validator.

File operations are restricted to `runtime/workspace`, with path traversal and symlink escape blocked. `file_write` creates but will not overwrite existing text files, and `file_remove` is restricted to supported document types. WAV requires uncompressed PCM. Copy your own authorized images/code/audio/CSV files into `runtime/workspace` before measuring them.

`golf_selfscan` deliberately performs source measurements without invoking parent tests inside that run; use the separate inherited regression commands in the next section. Earlier testing found the parent's full selfscan-with-nested-tests exceeded its deadline in this environment. Avoid presenting that timeout as success.

`linear_train` accepts CSV with numeric feature columns and final binary column `label`, and stores fitted logistic-regression coefficients in local SQLite. It holds out 20% of rows using a reproducible random split. It does **not** understand natural language; evaluating a model on unseen independent datasets remains necessary.

By default, internet probes are disabled (`allowed_https_hosts` empty in `config.json`). To authorize a particular external host, add its literal HTTPS hostname. The probe uses a bounded HEAD request with redirects disabled. Cloud computing / remote model providers are **not deployed or configured**. Do not interpret a blocked or untested network as a verified connection.

### Resource management and its limits

At startup Golf measures available cores/CPU quotas, memory and disk. A bounded queue routes independently executable jobs to Python threads, subprocesses or a spawn-based process pool. Under measurable high CPU temperature (>=85°C), memory pressure (>=90%), less than 200 MB free memory or low battery (<=12% unplugged), new jobs pause. No supported hardware sensor means temperature remains **unknown**; this software does not replace the Dell firmware/fan controls and cannot guarantee overheat prevention. It does not override OS memory or GPU limits. SQLite WAL persists completed jobs, learned weights and events; jobs interrupted by an abrupt restart are marked `interrupted` and are **not** replayed automatically. Event notifications are in-process callbacks plus persistent event rows.

GPU acceleration is conditional on a real PyTorch CUDA/MPS allocation plus verified matrix multiplication. An NVIDIA/Intel/AMD adapter listed in the hardware report alone does not imply compatible compute support. On typical Windows Dell laptops with Intel/AMD integrated graphics, `matrix_compute` may use CPU NumPy because CUDA/MPS support is absent. Other acceleration stacks, including Intel oneAPI, AMD ROCm, and DirectML, are not yet integrated.

## Verification

```
python3 -m unittest discover -s tests -v
python3 -m src.cli run --request '{"op":"golf_status"}'
python3 -m src.cli run --request '{"op":"golf_frame"}'
cd parents/Golf-Ripple-Metrology-Engine-v0.3 && sh VERIFY-RELEASE.sh
cd parents/Golf-Ripple-Metrology-Engine-v0.3/parents/Golf-Ripple-Digital-Eyes-v0.2 && sh VERIFY-ALL-UNIX.sh
```

On Windows use `py -3 -m unittest discover -s tests -v`; inherited UNIX shell regression scripts require a POSIX shell (e.g., Git Bash) or manual execution of their underlying Node/Python commands. The original parent archives and immutable source hash manifest are also included. See `docs/EXECUTION_AND_BOUNDARIES.md` for execution classification, measured local results, and specifically unverified Dell features.

## Privacy and operations

This engine is **not** a hardened multi-user daemon. Bind only to loopback (enforced), keep the bearer-token file and workspace private, avoid serving sensitive or untrusted third-party files, and use local OS permissions. Installing the task at login is optional and requires your explicit local action. There is no remote plugin install, screen capture, arbitrary application automation, or hardware telemetry transmission in the default install.
