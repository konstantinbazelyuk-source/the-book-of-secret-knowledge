"""v0.5 validates real CPU training and preservation, not implied Dell measurements."""
import hashlib,json,math,os,tempfile,unittest,zipfile
from pathlib import Path
from src.dell_training import train_source_bytes,dell_validation,predict_source_bytes
from src.engine import Engine,ROOT

class DellV05Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try:import torch
        except ImportError:raise unittest.SkipTest('torch not installed; Dell CPU-training tests require PyTorch')
    def test_01_actual_gradient_updates(self):
        out=train_source_bytes(ROOT,steps=1,workers=1,sequence=16,batch=1,seed=18)
        self.assertEqual(out['training_tokens'],16)
        self.assertGreater(out['training_tokens_per_second'],0)
        self.assertTrue(all(math.isfinite(x) for x in out['train_losses_nats']))
        self.assertTrue(all(x>0 for x in out['gradient_norms']))
        self.assertGreater(out['parameter_count'],3_000_000)
        self.assertEqual(out['evidence_class'],'MEASURED_CPU_TRAINING_ON_REAL_ARCHIVED_SOURCE_TEXT')
    def test_02_actual_weights_checkpoint_roundtrip(self):
        import torch
        with tempfile.TemporaryDirectory() as tmp:
            out=train_source_bytes(ROOT,steps=1,workers=1,sequence=16,batch=1,seed=16,save=True,out_dir=tmp)
            f=Path(out['checkpoint_path'])
            self.assertTrue(f.is_file())
            self.assertEqual(hashlib.sha256(f.read_bytes()).hexdigest(),out['checkpoint_sha256'])
            recorded=torch.load(f,map_location='cpu',weights_only=True)
            self.assertEqual(recorded['evidence']['parameter_count'],out['parameter_count'])
            self.assertIn('embed.weight',recorded['weights'])
            self.assertTrue(f.resolve().is_relative_to(Path(tmp).resolve()))
    def test_03_validation_rejects_bad_specs(self):
        for kwargs in [{'steps':0},{'steps':61},{'workers':0},{'batch':0},{'sequence':500},{'seed':-1}]:
            with self.subTest(kwargs=kwargs):
                with self.assertRaises(ValueError):train_source_bytes(ROOT,**kwargs)
    def test_04_identity_is_machine_observed_only(self):
        with tempfile.TemporaryDirectory() as tmp:
            r=dell_validation(ROOT,tmp,include_training=False)
            self.assertEqual(r['checks']['cpu_training']['status'],'NOT_RUN')
            self.assertEqual(r['dell_identity_verified_this_run'],bool(r['hardware']['machine_is_dell'] and r['hardware']['os']['system']=='Windows' and r['hardware']['model']))
            self.assertIn('hardware_scope',r['hardware'])
    def test_05_source_parent_preserved_exactly(self):
        archive=ROOT/'original-v0.4'/'Golf-Ripple-Laptop-Native-v0.4-Complete.zip'
        with zipfile.ZipFile(archive) as z:
            source=[n for n in z.namelist() if '/parents/' in n and not n.endswith('/')]
            self.assertGreater(len(source),100)
            for n in source:
                f=ROOT/Path(n).relative_to('Golf-Ripple-Laptop-Native-v0.4')
                self.assertEqual(hashlib.sha256(z.read(n)).hexdigest(),hashlib.sha256(f.read_bytes()).hexdigest(),n)
    def test_06_live_job_and_unauthorized_bounds(self):
        with tempfile.TemporaryDirectory() as tmp:
            eng=Engine(tmp,workers=1,config={'gpu_probe':False,'queue_size':8})
            try:
                ok=eng.wait(eng.submit({'op':'source_train','steps':1,'sequence':16,'batch':1,'seed':46}),90)
                self.assertEqual(ok['status'],'completed',ok['error'])
                self.assertEqual(ok['result']['data']['training_steps'],1)
                checkpoint=Path(ok['result']['data']['checkpoint_path'])
                self.assertTrue(checkpoint.exists())
                inf=eng.wait(eng.submit({'op':'source_infer','model_id':checkpoint.stem,'prompt':'Ripple','top_k':3}),90)
                self.assertEqual(inf['status'],'completed',inf['error'])
                self.assertEqual(len(inf['result']['data']['top_next_byte_predictions']),3)
                invalid=eng.wait(eng.submit({'op':'source_train','steps':100}),10)
                self.assertEqual(invalid['status'],'failed')
                self.assertIn('steps',invalid['error'])
            finally:eng.close()

    def test_07_actual_model_prediction_is_reproducible(self):
        with tempfile.TemporaryDirectory() as tmp:
            result=train_source_bytes(ROOT,steps=1,workers=1,sequence=16,batch=1,seed=44,save=True,out_dir=tmp)
            name=Path(result['checkpoint_path']).stem
            a=predict_source_bytes(tmp,name,'Ripple neuron',top_k=4)
            b=predict_source_bytes(tmp,name,'Ripple neuron',top_k=4)
            self.assertEqual(a,b)
            self.assertAlmostEqual(sum(p['probability'] for p in a['top_next_byte_predictions']),sum(p['probability'] for p in b['top_next_byte_predictions']))
            self.assertEqual(a['model_sha256'],result['checkpoint_sha256'])
    def test_08_inference_rejects_unapproved_paths(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(ValueError):predict_source_bytes(tmp,'../../secret','hello')
            with self.assertRaises(ValueError):predict_source_bytes(tmp,'sourcebytes-no-model','hello')
            with self.assertRaises(ValueError):predict_source_bytes(tmp,'sourcebytes-no-model','')

if __name__=='__main__':unittest.main()
