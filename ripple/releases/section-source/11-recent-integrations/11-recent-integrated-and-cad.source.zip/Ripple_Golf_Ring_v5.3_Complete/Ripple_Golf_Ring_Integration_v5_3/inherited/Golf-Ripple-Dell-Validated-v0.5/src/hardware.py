"""Local hardware discovery. Unknown means unknown; never infer Dell branding or GPU availability."""
import ctypes
import json
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path


def _command(argv, timeout=6):
    try:
        x = subprocess.run(argv, capture_output=True, text=True, timeout=timeout, shell=False)
        return x.stdout.strip() if x.returncode == 0 else None
    except (OSError, subprocess.TimeoutExpired):
        return None


def _powershell(cim):
    raw = _command(['powershell.exe', '-NoProfile','-NonInteractive','-Command', cim], timeout=12)
    if raw:
        try: return json.loads(raw)
        except (ValueError, TypeError): pass
    return None


def _memory():
    try:
        import psutil
        v=psutil.virtual_memory()
        return {'total_bytes':v.total,'available_bytes':v.available,'source':'psutil'}
    except ImportError: pass
    if sys.platform == 'win32':
        class MEMSTAT(ctypes.Structure):
            _fields_=[('dwLength',ctypes.c_ulong),('dwMemoryLoad',ctypes.c_ulong),('ullTotalPhys',ctypes.c_ulonglong),('ullAvailPhys',ctypes.c_ulonglong),('ullTotalPageFile',ctypes.c_ulonglong),('ullAvailPageFile',ctypes.c_ulonglong),('ullTotalVirtual',ctypes.c_ulonglong),('ullAvailVirtual',ctypes.c_ulonglong),('ullAvailExtendedVirtual',ctypes.c_ulonglong)]
        m=MEMSTAT();m.dwLength=ctypes.sizeof(m)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):
            return {'total_bytes':m.ullTotalPhys,'available_bytes':m.ullAvailPhys,'source':'GlobalMemoryStatusEx'}
    if sys.platform.startswith('linux'):
        try:
            values={}
            for ln in Path('/proc/meminfo').read_text().splitlines():
                k,v=ln.split(':',1);values[k]=int(v.split()[0])*1024
            return {'total_bytes':values.get('MemTotal'),'available_bytes':values.get('MemAvailable'),'source':'/proc/meminfo'}
        except (OSError, ValueError):pass
    return {'total_bytes':None,'available_bytes':None,'source':'unavailable'}


def _effective_cpu():
    logical=os.cpu_count() or 1
    affinity=None
    try: affinity=len(os.sched_getaffinity(0))
    except (AttributeError,OSError): pass
    quota=None
    try:
        q,p=Path('/sys/fs/cgroup/cpu.max').read_text().split()[:2]
        if q!='max': quota=max(1,int(int(q)/int(p)+0.999999))
    except (OSError,ValueError,ZeroDivisionError): pass
    values=[i for i in [logical,affinity,quota] if i]
    return {'logical_os':logical,'affinity_count':affinity,'cgroup_quota_cores':quota,'effective':max(1,min(values))}


def _cpu_model():
    if sys.platform.startswith('linux'):
        try:
            for line in Path('/proc/cpuinfo').read_text().splitlines():
                if line.startswith('model name'):return line.split(':',1)[1].strip()
        except OSError:pass
    if sys.platform=='darwin':return _command(['sysctl','-n','machdep.cpu.brand_string'])
    return platform.processor() or None


def _nvidia():
    raw=_command(['nvidia-smi','--query-gpu=name,memory.total,driver_version,temperature.gpu,utilization.gpu','--format=csv,noheader,nounits'])
    if not raw:return []
    result=[]
    for line in raw.splitlines():
        parts=[x.strip() for x in line.split(',')]
        if len(parts)!=5:continue
        result.append({'name':parts[0],'vram_mib':parts[1],'driver':parts[2],'temperature_c':parts[3],'utilization_percent':parts[4], 'source':'nvidia-smi'})
    return result


def _torch_gpu_test():
    try:
        import torch
    except (ImportError,OSError) as e:return {'available':False,'reason':'PyTorch not installed or not loadable'}
    devices=[]
    if torch.cuda.is_available():devices.append('cuda')
    if getattr(torch.backends,'mps',None) and torch.backends.mps.is_available():devices.append('mps')
    if not devices:return {'available':False,'reason':'No verified CUDA or MPS compute backend','torch_version':torch.__version__}
    for dev in devices:
        try:
            a=torch.ones((128,128),device=dev,dtype=torch.float32)
            y=a@a
            if dev=='cuda':torch.cuda.synchronize()
            z=float(y[0,0].item())
            if z!=128:raise ValueError('GPU compute result mismatch')
            return {'available':True,'backend':dev,'matrix_test':'passed','check_value':z,'torch_version':torch.__version__}
        except Exception as e:
            return {'available':False,'backend':dev,'reason':type(e).__name__+': '+str(e)[:120]}
    return {'available':False,'reason':'No compute test passed'}


def discover(data_dir=None,gpu_probe=False):
    data_dir=Path(data_dir or Path.cwd()).resolve();disk=shutil.disk_usage(data_dir)
    platform_data={'system':platform.system(),'release':platform.release(),'version':platform.version(),'architecture':platform.machine(),'python':platform.python_version(),'node':_command(['node','--version'])}
    manufacturer=None;model=None;gpu=[];storage=[];bios=None
    if sys.platform=='win32':
        info=_powershell("Get-CimInstance Win32_ComputerSystem | Select-Object Manufacturer,Model,TotalPhysicalMemory | ConvertTo-Json -Compress")
        if isinstance(info,dict):manufacturer=info.get('Manufacturer');model=info.get('Model')
        cpu=_powershell("Get-CimInstance Win32_Processor | Select-Object -First 1 Name,NumberOfCores,NumberOfLogicalProcessors | ConvertTo-Json -Compress")
        g=_powershell("Get-CimInstance Win32_VideoController | Select-Object Name,AdapterRAM,DriverVersion | ConvertTo-Json -Compress")
        if g:gpu=g if isinstance(g,list) else [g]
        disks=_powershell("Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' | Select-Object DeviceID,Size,FreeSpace | ConvertTo-Json -Compress")
        if disks:storage=disks if isinstance(disks,list) else [disks]
    elif sys.platform.startswith('linux'):
        vendor=Path('/sys/class/dmi/id/sys_vendor'); product=Path('/sys/class/dmi/id/product_name')
        try:manufacturer=vendor.read_text().strip();model=product.read_text().strip()
        except OSError:pass
        cpu=None
        lspci=_command(['lspci'])
        if lspci:gpu=[{'description':ln.strip(),'source':'lspci (not compute tested)'} for ln in lspci.splitlines() if any(w in ln.lower() for w in ['vga','3d controller'])][:6]
    else:cpu=None
    nv=_nvidia()
    return {'machine_is_dell':manufacturer is not None and 'dell' in manufacturer.lower(),'manufacturer':manufacturer,'model':model,'os':platform_data,
      'cpu':{'model':(cpu.get('Name') if isinstance(cpu,dict) else _cpu_model()),'reported_physical_cores':(cpu.get('NumberOfCores') if isinstance(cpu,dict) else None),**_effective_cpu()},
      'memory':_memory(),'disk_current_volume':{'total_bytes':disk.total,'used_bytes':disk.used,'free_bytes':disk.free},'windows_fixed_disks':storage,
      'graphics_adapters':gpu,'nvidia':nv,'gpu_acceleration':_torch_gpu_test() if gpu_probe else {'available':None,'reason':'Not tested; run probe with --gpu'},
      'hardware_scope':'HOST_RUNNING_THIS_PROCESS; NOT AN UNCONNECTED DELL LAPTOP'}


def telemetry():
    out={'temperature_c':None,'temperature_source':None,'cpu_percent':None,'memory_percent':None,'available_memory_bytes':None,'battery_percent':None,'battery_plugged':None}
    try:
        import psutil
        out['cpu_percent']=psutil.cpu_percent(interval=0.05)
        vm=psutil.virtual_memory();out['memory_percent']=vm.percent;out['available_memory_bytes']=vm.available
        if hasattr(psutil,'sensors_temperatures'):
            sensors=psutil.sensors_temperatures() or {}
            readings=[(s.current,bank) for bank,group in sensors.items() for s in group if isinstance(s.current,(int,float)) and 0<s.current<180 and any(k in bank.lower() for k in ['coretemp','cpu','k10temp','acpitz','thermal'])]
            if readings:out['temperature_c'],out['temperature_source']=max(readings)
        if hasattr(psutil,'sensors_battery'):
            b=psutil.sensors_battery()
            if b:out['battery_percent']=b.percent;out['battery_plugged']=b.power_plugged
    except (ImportError, OSError, ValueError, AttributeError): pass
    return out
