import argparse,json,os,secrets,signal,sys,time
from pathlib import Path
from .hardware import discover
from .engine import Engine,ROOT,hash_work

def main():
    parser=argparse.ArgumentParser(description='Golf Ripple laptop-native runtime')
    parser.add_argument('command',choices=['probe','benchmark','serve','run','status','dellcheck'])
    parser.add_argument('--gpu',action='store_true',help='test GPU matrix compute if torch CUDA/MPS is available')
    parser.add_argument('--skip-training',action='store_true',help='dellcheck: hardware only; skip real PyTorch CPU training')
    parser.add_argument('--steps',type=int,default=2,help='dellcheck: real gradient updates, 1..60 (default 2)')
    parser.add_argument('--workers',type=int,default=None,help='optional lower worker cap')
    parser.add_argument('--port',type=int,default=8895)
    parser.add_argument('--request',type=str,help='JSON request for run')
    parser.add_argument('--config',type=str,default=str(ROOT/'config.json'))
    args=parser.parse_args()
    config={}
    conf=Path(args.config)
    if conf.exists():config=json.loads(conf.read_text())
    if not isinstance(config,dict):raise ValueError('configuration JSON object required')
    if args.gpu:config['gpu_probe']=True
    if args.command=='probe':print(json.dumps(discover(ROOT/'runtime',gpu_probe=args.gpu),indent=2));return
    if args.command=='dellcheck':
        from .dell_training import dell_validation
        report=dell_validation(ROOT,ROOT/'runtime',include_training=not args.skip_training,steps=args.steps)
        reports=ROOT/'reports';reports.mkdir(exist_ok=True)
        outfile=reports/'LOCAL-HARDWARE-VALIDATION.json'
        outfile.write_text(json.dumps(report,indent=2,allow_nan=False),encoding='utf-8')
        print(json.dumps({'saved_report':str(outfile),'dell_identity_verified_this_run':report['dell_identity_verified_this_run'],'training':report['checks']['cpu_training'],'hardware':report['hardware']},indent=2))
        return
    eng=Engine(workers=args.workers,config=config)
    try:
        if args.command=='status':print(json.dumps(eng.status(),indent=2));return
        if args.command=='run':
            if not args.request:parser.error('--request JSON required')
            job=eng.submit(json.loads(args.request));r=eng.wait(job,100)
            print(json.dumps(r,indent=2));sys.exit(0 if r['status']=='completed' else 2)
        if args.command=='benchmark':
            from concurrent.futures import ProcessPoolExecutor
            import multiprocessing as mp
            from concurrent.futures import as_completed
            ceiling=min(eng.max_workers,8)
            counts=sorted(set([1,2,4,8,ceiling]))
            counts=[c for c in counts if c<=ceiling]
            trials=[]
            for workers in counts:
                check=eng._safe_to_run()
                if not check[0]:trials.append({'workers':workers,'skipped':check[1]});break
                jobs=12
                with ProcessPoolExecutor(max_workers=workers,mp_context=mp.get_context('spawn')) as p:
                    list(p.map(hash_work,[1000]*workers,range(workers)))  # untimed process warmup
                    start=time.perf_counter()
                    result=list(p.map(hash_work,[200_000]*jobs,range(jobs)))
                    elapsed=time.perf_counter()-start
                assert len({x['sha256'] for x in result})==jobs
                trials.append({'workers':workers,'jobs':jobs,'hash_rounds':jobs*200_000,'elapsed_seconds':elapsed,'rounds_per_second':jobs*200_000/elapsed,'distinct_worker_pids':len({x['pid'] for x in result})})
            best=max((t for t in trials if 'rounds_per_second' in t),key=lambda x:x['rounds_per_second'],default=None)
            if best:
                (ROOT/'runtime'/'performance.json').write_text(json.dumps({'cpu_model':eng.hardware['cpu']['model'],'effective_cores':eng.cores,'recommended_workers':best['workers'],'timestamp':time.time(),'benchmark':'SHA256 process pool sustained-hash task only'},indent=2))
            result={'host_report':eng.hardware,'process_benchmarks':trials,'fastest_observed_workers':best['workers'] if best else None,'comparison_warning':'Observed results depend on current machine load, Python/OpenSSL and hash task; do not extrapolate to all AI workloads'}
            outfile=ROOT/'results';outfile.mkdir(exist_ok=True);(outfile/'benchmark.json').write_text(json.dumps(result,indent=2))
            print(json.dumps(result,indent=2));return
        if args.command=='serve':
            from .server import create_server
            tokenfile=ROOT/'runtime'/'access-token.txt'
            if tokenfile.exists():
                token=tokenfile.read_text().strip()
                if len(token)<32:raise ValueError('access token is invalid')
            else:
                token=secrets.token_urlsafe(32)
                fd=os.open(tokenfile,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
                with os.fdopen(fd,'w') as f:f.write(token+'\n')
            token=os.environ.get('GOLF_LAPTOP_TOKEN') or token
            server=create_server(eng,token,args.port)
            print('Golf Laptop: http://127.0.0.1:'+str(server.server_port),flush=True)
            print('Access token: '+token,flush=True)
            print('Set Authorization: Bearer <token> for every request. Ctrl-C to stop.',flush=True)
            try:server.serve_forever(poll_interval=.25)
            except KeyboardInterrupt:pass
            finally:server.server_close()
    finally:eng.close()
if __name__=='__main__':main()
