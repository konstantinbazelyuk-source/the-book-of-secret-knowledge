// Child-only bridge. No changes to the archived Golf v0.3 mathematical or source files.
import path from 'node:path';
import process from 'node:process';
import {fileURLToPath} from 'node:url';
import {GolfMetrologyRuntime} from '../parents/Golf-Ripple-Metrology-Engine-v0.3/src/metrology-runtime.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const local=process.env.GOLF_LAPTOP_RUNTIME||path.join(root,'runtime');
const run=new GolfMetrologyRuntime({dataDir:path.join(local,'parent-data'),workspace:path.join(local,'workspace'),python:process.env.GOLF_PYTHON||'python3'});
const op=process.argv[2];
try{
  let output;
  if(op==='status')output=run.status();
  else if(op==='selfscan')output=await run.run({kind:'metrology',mode:'selfscan',runTests:false},'owner');
  else if(op==='frame')output=await run.run({kind:'metrology',mode:'frame',file:process.argv[3]||'observed_before.png',second:process.argv[4]||'observed_after.png'},'owner');
  else if(op==='goal')output=await run.run(JSON.parse(process.argv[3]),'owner');
  else throw Error('Unsupported operation');
  console.log(JSON.stringify(output));
}catch(err){console.error(String(err));process.exitCode=1;}
