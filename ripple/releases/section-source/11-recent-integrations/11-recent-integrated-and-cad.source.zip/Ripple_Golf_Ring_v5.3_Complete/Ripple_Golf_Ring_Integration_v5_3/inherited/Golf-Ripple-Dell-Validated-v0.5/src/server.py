"""Loopback-only authenticated HTTP control protocol; JSON and bounded body sizes."""
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
import hmac,json
import os
from urllib.parse import urlparse,parse_qs


def create_server(engine,token,port=8895,host='127.0.0.1'):
    if host not in ('127.0.0.1','::1'):raise ValueError('public network binding intentionally unsupported')
    class Handler(BaseHTTPRequestHandler):
        protocol_version='HTTP/1.1'
        def log_message(self,format,*args):pass
        def send(self,status,obj):
            raw=json.dumps(obj,allow_nan=False).encode()
            self.send_response(status)
            self.send_header('Content-Type','application/json; charset=utf-8')
            self.send_header('Cache-Control','no-store')
            self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Content-Length',str(len(raw)))
            self.end_headers();self.wfile.write(raw)
        def authorized(self):
            if not hmac.compare_digest(self.headers.get('Authorization',''), 'Bearer '+token):self.send(401,{'error':'bearer token required'});return False
            return True
        def do_GET(self):
            if not self.authorized():return
            url=urlparse(self.path);parts=url.path.rstrip('/').split('/')
            if url.path=='/api/status':return self.send(200,engine.status())
            if url.path=='/api/hardware':return self.send(200,engine.hardware)
            if url.path=='/api/events':return self.send(200,{'events':engine.events(parse_qs(url.query).get('limit',[30])[0])})
            if len(parts)==4 and parts[1:3]==['api','jobs'] and parts[3].isdigit():
                item=engine.job(int(parts[3]));return self.send(200,item) if item else self.send(404,{'error':'unknown job'})
            self.send(404,{'error':'not found'})
        def do_POST(self):
            if not self.authorized():return
            if self.path!='/api/jobs':return self.send(404,{'error':'not found'})
            if not self.headers.get('Content-Type','').startswith('application/json'):return self.send(415,{'error':'JSON expected'})
            try:
                length=int(self.headers.get('Content-Length','-1'))
                if length<0 or length>50000:raise ValueError('request exceeds 50 KB')
                data=json.loads(self.rfile.read(length))
                if not isinstance(data,dict):raise ValueError('object required')
                job=engine.submit(data)
                self.send(202,{'job_id':job,'state':'queued'})
            except (ValueError,RuntimeError,TypeError) as ex:self.send(400,{'error':str(ex)[:250]})
    return ThreadingHTTPServer((host,port),Handler)
