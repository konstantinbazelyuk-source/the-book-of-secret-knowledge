import csv
import hashlib
import http.client
import json
from pathlib import Path
import shutil
import tempfile
import threading
import time
import unittest
import wave
from src.engine import Engine,hash_work,_safe_path,ROOT
from src.hardware import discover
from src.server import create_server


class LaptopTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
    cls.temp=tempfile.TemporaryDirectory()
    cls.engine=Engine(cls.temp.name,workers=2,config={'queue_size':16,'allowed_https_hosts':[],'approved_apps':{'python_version':{'executable':__import__('sys').executable,'arguments':['--version']}}})
 @classmethod
 def tearDownClass(cls):
    cls.engine.close();cls.temp.cleanup()
 def complete(self, payload, timeout=65):
    x=self.engine.wait(self.engine.submit(payload),timeout)
    self.assertEqual(x['status'],'completed',x.get('error'));return x['result']['data']
 def test_01_host_is_not_falsely_dell(self):
    h=discover(self.engine.root)
    self.assertGreaterEqual(h['cpu']['effective'],1)
    self.assertEqual(h['hardware_scope'],'HOST_RUNNING_THIS_PROCESS; NOT AN UNCONNECTED DELL LAPTOP')
    self.assertEqual(h['machine_is_dell'],bool(h['manufacturer'] and 'dell' in h['manufacturer'].lower()))
 def test_02_process_pool(self):
    x=self.complete({'op':'cpu_hash','loops':5000,'seed':37});self.assertEqual(x['sha256'],hash_work(5000,37)['sha256']);self.assertNotEqual(x['pid'],__import__('os').getpid())
 def test_03_file_permissions(self):
    with self.assertRaises(ValueError):_safe_path(self.engine.workspace,'../private-key',False)
    with self.assertRaises(ValueError):self.engine.submit({'op':'execute_arbitrary_code'})
 def test_04_real_file_ops(self):
    self.complete({'op':'file_write','path':'observation.txt','content':'Light Light and Motion'})
    d=self.complete({'op':'file_digest','path':'observation.txt'})
    self.assertEqual(d['sha256'],hashlib.sha256(b'Light Light and Motion').hexdigest())
    c=self.complete({'op':'text_analyze','path':'observation.txt'})
    self.assertEqual(c['words'],4)
    self.assertEqual(dict(c['top_terms'])['light'],2)
    self.assertEqual(self.complete({'op':'file_read','path':'observation.txt'})['text'],'Light Light and Motion')
    names=[x['path'] for x in self.complete({'op':'file_list'})['entries']]
    self.assertIn('observation.txt',names)
    self.complete({'op':'file_remove','path':'observation.txt'})
 def test_05_unauthorized_network(self):
    x=self.engine.wait(self.engine.submit({'op':'https_probe','url':'https://example.com/'}),10)
    self.assertEqual(x['status'],'failed');self.assertIn('allowlisted',x['error'])
 def test_06_real_wav(self):
    target=self.engine.workspace/'measured.wav'
    import struct,math
    with wave.open(str(target),'wb') as w:
        w.setnchannels(1);w.setsampwidth(2);w.setframerate(8000)
        w.writeframes(b''.join(struct.pack('<h',int(12000*math.sin(2*math.pi*440*t/8000))) for t in range(800)))
    result=self.complete({'op':'audio_wav','path':'measured.wav'})
    self.assertAlmostEqual(result['duration_seconds'],.1)
    self.assertGreater(result['rms_normalized'],.2)
 def test_07_golf_parent_status(self):
    result=self.complete({'op':'golf_status'},20)
    self.assertEqual(result['metrology']['release'],'0.3.0')
 def test_08_golf_parent_image(self):
    for name in ['observed_before.png','observed_after.png']:
        shutil.copyfile(ROOT/'parents/Golf-Ripple-Metrology-Engine-v0.3/workspace'/name,self.engine.workspace/name)
    # Parent bridge environment uses ROOT/runtime/workspace by default; checking actual file there.
    result=self.complete({'op':'golf_frame'},30)
    self.assertEqual(result['goal'],'metrology')
    self.assertEqual(result['acceptance']['physicalCalibration'],'NOT_PRESENT')
 def test_09_supervised_model(self):
    p=self.engine.workspace/'fit.csv'
    with p.open('w',newline='') as fp:
        w=csv.writer(fp);w.writerow(['a','b','label'])
        for k in range(60):w.writerow([k/10, (k%5)/4,int(k>=30)])
    x=self.complete({'op':'linear_train','name':'test','path':'fit.csv','epochs':120})
    self.assertGreater(x['heldout_accuracy'],.8)
    y=self.complete({'op':'linear_predict','name':'test','features':[5.5,.5]});self.assertEqual(y['predicted_label'],1)
 def test_10_event_persistence(self):
    events=self.engine.events(50)
    self.assertTrue(any(e['type']=='job.completed' for e in events))
    with self.engine._conn() as con:self.assertIsNotNone(con.execute('SELECT model FROM models WHERE name=?',('test',)).fetchone())
 def test_11_bounded_gpu(self):
    if not self.engine.hardware['gpu_acceleration']['available']:
        x=self.engine.wait(self.engine.submit({'op':'gpu_matmul','matrix_size':128}),15)
        self.assertEqual(x['status'],'failed')
 def test_12_pressure_controls(self):
    backup=self.engine.last_monitor
    self.engine.last_monitor={**backup,'temperature_c':96}
    self.assertFalse(self.engine._safe_to_run()[0])
    self.engine.last_monitor={**backup,'memory_percent':93}
    self.assertFalse(self.engine._safe_to_run()[0])
    self.engine.last_monitor=backup
 def test_13_explicitly_approved_installed_process(self):
    value=self.complete({'op':'app_run','name':'python_version'})
    self.assertEqual(value['exit_code'],0)
    self.assertIn('Python',value['stdout'])
    x=self.engine.wait(self.engine.submit({'op':'app_run','name':'not_allowlisted'}),10)
    self.assertEqual(x['status'],'failed')
 def test_14_bearer_http(self):
    server=create_server(self.engine,'test-token-123',port=0)
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    try:
        conn=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=5)
        conn.request('GET','/api/status');self.assertEqual(conn.getresponse().status,401)
        conn.close()
        conn=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=5)
        conn.request('GET','/api/hardware',headers={'Authorization':'Bearer test-token-123'})
        r=conn.getresponse();self.assertEqual(r.status,200)
        self.assertIn('cpu',json.loads(r.read()))
        conn.request('POST','/api/jobs',body=json.dumps({'op':'cpu_hash','loops':500}),headers={'Authorization':'Bearer test-token-123','Content-Type':'application/json'})
        result=conn.getresponse();self.assertEqual(result.status,202)
        job=json.loads(result.read())['job_id'];self.assertEqual(self.engine.wait(job,15)['status'],'completed')
        conn.close()
    finally:server.shutdown();server.server_close();thread.join(timeout=3)


if __name__=='__main__':unittest.main()
