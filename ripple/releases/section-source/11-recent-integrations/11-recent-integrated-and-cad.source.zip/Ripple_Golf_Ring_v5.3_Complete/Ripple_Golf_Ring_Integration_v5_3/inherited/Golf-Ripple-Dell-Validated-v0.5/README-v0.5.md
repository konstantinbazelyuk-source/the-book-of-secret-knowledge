# Golf Ripple — Dell-Validated Runtime v0.5

This is an **additive Windows-targeted executable Golf branch**, using the preserved Golf Laptop Native v0.4 engine and its source tree. The exact v0.4 ZIP is included unchanged under `original-v0.4`. The original neuron, Daughter triplet, metrology, OS scheduler, SQLite, file boundaries, and web control remain intact.

## First run (Windows Dell)

1. Extract this ZIP into your own private folder (e.g., `Documents\\GolfRipple`). It is source code, not a conventional `.exe` installer.
2. Ensure Python 3.11+ and Node.js 20+ are installed.
3. In PowerShell, run `py -3 -m pip install -r requirements.txt` and install compatible PyTorch (`py -3 -m pip install torch`) for CPU training.
4. Run `powershell -ExecutionPolicy Bypass -File .\\VERIFY-DELL-WINDOWS.ps1` or `py -3 -m src.cli dellcheck --steps 2`. Actual local results are stored in `reports\\LOCAL-HARDWARE-VALIDATION.json`. This program does not automatically transmit its report.
5. To perform the fuller CPU scaling benchmark, run `py -3 -m src.cli benchmark` (CPU hash throughput; not training throughput). To start the local runtime, `py -3 -m src.cli serve` or double click `START-GOLF-LAPTOP-WINDOWS.bat`; API on `http://127.0.0.1:8895` requires a bearer token.

On a machine without PyTorch, `py -3 -m src.cli dellcheck --skip-training` collects the real hardware report without training. Basic engine operations remain usable.

## New functional operations

`source_train` submitted as a normal authorized HTTP/CLI job creates a **real** ~3.3M parameter causal Transformer; all forward/backward steps run on the CPU, with bounded sequence size and steps. Checkpoint is stored under `runtime/models/`; job result includes the assigned `checkpoint_path` (extract its filename without `.pt` for next step). The `source_infer` operation loads that checkpoint on future runs and computes top-k next-byte probabilities.

Example CLI commands:

```powershell
py -3 -m src.cli run --request '{"op":"source_train","steps":2,"sequence":32,"batch":2,"seed":2408}'
py -3 -m src.cli run --request '{"op":"source_infer","model_id":"<filename-without-.pt-from-completed-job>","prompt":"Ripple","top_k":5}'
```

For actual Windows PowerShell quoting, prefer `--request (Get-Content .\\request.json -Raw)` with a local JSON request file; the identifier must be copied from the completed training job. Neither source code nor training labels are invented for this test: the corpus comes from the included real archived Golf documents. The tiny number of steps and narrow byte-prediction task do not imply a learned conversational ability.

## Provenance and limits

The supplied computer profile comes from prior Windows/Dell use **confirmed by the user**, not a hardware reading taken through ChatGPT. The report generated in `results/DEVELOPMENT_HOST_ONLY.json` was recorded on a **different Linux machine**. The `dellcheck` command becomes actual Dell evidence only if executed on the laptop. The script and source passed local tests; execution of this Windows script and physical device behavior have not been tested by the assistant.

For more detail, see `docs/DELL-PROFILE-AND-VALIDATION.md`. For preserved inherited v0.4 operations, see the original `README.md` and original archive under `original-v0.4/`.

The clean-extraction suite passed on a retry in the Linux development environment. Intermittent earlier test-run stalls are disclosed in the validation document; sustained Dell operation has not been certified.
