"""Bounded, actual PyTorch next-byte training on the archived parent source corpus.
A training measurement is a software-performance benchmark, not semantic comprehension.
"""
from __future__ import annotations
import hashlib, json, math, os, time
from pathlib import Path

def _build_model(torch):
    class ByteTransformer(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.embed=torch.nn.Embedding(256,256)
            self.positions=torch.nn.Embedding(128,256)
            layer=torch.nn.TransformerEncoderLayer(d_model=256,nhead=4,dim_feedforward=1024,dropout=0.,batch_first=True,norm_first=True)
            self.layers=torch.nn.TransformerEncoder(layer,num_layers=4,enable_nested_tensor=False)
            self.norm=torch.nn.LayerNorm(256)
            self.head=torch.nn.Linear(256,256)
        def forward(self,x):
            bs,seq=x.shape
            positions=torch.arange(seq,device=x.device)[None,:].expand(bs,-1)
            embedded=self.embed(x)+self.positions(positions)
            mask=torch.triu(torch.ones(seq,seq,dtype=torch.bool,device=x.device),diagonal=1)
            return self.head(self.norm(self.layers(embedded,mask=mask)))
    return ByteTransformer()




def _corpus(root):
    root=Path(root)
    parent=root/'parents'/'Golf-Ripple-Metrology-Engine-v0.3'
    paths=[parent/'README.md',parent/'docs'/'MATHEMATICS_AND_METHODS.md',parent/'docs'/'EXECUTED_RESULTS.md']
    if not all(p.is_file() for p in paths):raise FileNotFoundError('locked Golf source corpus absent')
    pieces=[p.read_bytes()[:400_000] for p in paths]
    corpus=b'\n'.join(pieces)
    if len(corpus)<4096:raise ValueError('insufficient real archived document text')
    return corpus,[{'name':str(p.relative_to(root)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths]


def train_source_bytes(root, *, steps=3, workers=2, sequence=32, batch=2, seed=2408, save=False, out_dir=None):
    """Runs actual gradients on an ~3.4M-parameter causal transformer.
    No model is called an LLM. Held-out text is not used for gradient updates.
    """
    if type(steps)!=int or not 1<=steps<=60:raise ValueError('steps out of bounds (1..60)')
    if type(sequence)!=int or not 16<=sequence<=128:raise ValueError('sequence out of bounds (16..128)')
    if type(batch)!=int or not 1<=batch<=8:raise ValueError('batch out of bounds (1..8)')
    if type(workers)!=int or not 1<=workers<=32:raise ValueError('worker count out of bounds')
    if type(seed)!=int or not 0<=seed<=2**31-1:raise ValueError('seed out of bounds')
    try:import torch
    except (ImportError,OSError) as exc:raise RuntimeError('CPU PyTorch unavailable; install torch for this optional training job') from exc
    torch.set_num_threads(workers)
    torch.manual_seed(seed)
    corpus,provenance=_corpus(root)
    cut=int(len(corpus)*.8)
    train_bytes=corpus[:cut];test_bytes=corpus[cut:]
    if len(test_bytes)<sequence+2:raise ValueError('held-out partition too short')
    model=_build_model(torch).cpu()
    params=sum(x.numel() for x in model.parameters())
    optim=torch.optim.AdamW(model.parameters(),lr=0.0002)
    train_tensor=torch.tensor(list(train_bytes),dtype=torch.long)
    test_tensor=torch.tensor(list(test_bytes),dtype=torch.long)
    random_gen=torch.Generator().manual_seed(seed)
    def samples(data,n,g=None):
        starts=torch.randint(0,len(data)-sequence-1,(n,),generator=g) if g is not None else torch.arange(n,dtype=torch.long)*3
        starts=starts%(len(data)-sequence-1)
        offsets=torch.arange(sequence)
        return data[starts[:,None]+offsets[None,:]],data[starts[:,None]+offsets[None,:]+1]
    xval,yval=samples(test_tensor,min(4,batch))
    def validation():
        model.eval()
        with torch.no_grad():
            logits=model(xval)
            return float(torch.nn.functional.cross_entropy(logits.reshape(-1,256),yval.reshape(-1)).item())
    initial=validation();losses=[];gradient_norms=[];timings=[]
    for _ in range(steps):
        # Separate verified CPU train steps and exact measured wall-clock durations.
        model.train();xx,yy=samples(train_tensor,batch,random_gen)
        start=time.perf_counter()
        optim.zero_grad(set_to_none=True)
        pred=model(xx)
        loss=torch.nn.functional.cross_entropy(pred.reshape(-1,256),yy.reshape(-1))
        loss.backward()
        norm=float(torch.nn.utils.clip_grad_norm_(model.parameters(),1.0).item())
        if not all(math.isfinite(x) for x in (float(loss.item()),norm)):raise RuntimeError('non-finite training metric')
        optim.step();timings.append(time.perf_counter()-start)
        losses.append(float(loss.item()));gradient_norms.append(norm)
    final=validation()
    seconds=sum(timings)
    result={
        'operation':'actual_pytorch_cpu_training','backend':'torch_cpu','torch_version':str(torch.__version__),
        'parameter_count':params,'architecture':'four-layer causal byte Transformer, 256 embedding, 4 attention heads',
        'train_bytes':len(train_bytes),'heldout_bytes':len(test_bytes),'corpus_files':provenance,
        'training_steps':steps,'training_tokens':steps*batch*sequence,'batch_size':batch,'sequence_length':sequence,
        'num_cpu_threads':workers,'training_elapsed_seconds':seconds,'training_tokens_per_second':round(steps*batch*sequence/seconds,4),
        'first_heldout_loss_nats':initial,'last_heldout_loss_nats':final,
        'train_losses_nats':losses,'gradient_norms':gradient_norms,'seed':seed,
        'evidence_class':'MEASURED_CPU_TRAINING_ON_REAL_ARCHIVED_SOURCE_TEXT',
        'limitations':'A few optimizer steps on source bytes; not comprehension, general language learning, laptop thermal certification, or Dell performance unless this command was executed on Dell hardware.'
    }
    if save:
        if out_dir is None:raise ValueError('save location required')
        path=Path(out_dir).resolve();path.mkdir(parents=True,exist_ok=True)
        name='sourcebytes-'+str(seed)+'-'+str(int(time.time()*1_000_000))
        outfile=path/(name+'.pt')
        # Source-generated state tensors only; consumers should load with weights_only=True.
        torch.save({'weights':model.state_dict(),'config':{'vocab':256,'embed_dim':256,'layers':4,'heads':4},'evidence':result},outfile)
        result['checkpoint_path']=str(outfile)
        result['checkpoint_sha256']=hashlib.sha256(outfile.read_bytes()).hexdigest()
    return result


def predict_source_bytes(model_dir, model_id, prompt, *, top_k=5):
    """Load an actual saved GPU-free training state and calculate next-byte probabilities.
    Checkpoints are locally created trusted model states; no arbitrary model paths.
    """
    if not isinstance(model_id,str) or not model_id.startswith('sourcebytes-') or len(model_id)>100 or not all(c.isalnum() or c in '_-' for c in model_id):
        raise ValueError('model identifier must be a saved sourcebytes model ID')
    if not isinstance(prompt,str) or not 1<=len(prompt.encode('utf-8'))<=2048:
        raise ValueError('prompt must contain 1..2048 bytes of text')
    if type(top_k)!=int or not 1<=top_k<=10:raise ValueError('top_k must be 1..10')
    model_dir=Path(model_dir).resolve()
    source=model_dir/(model_id+'.pt')
    if not source.is_file() or source.is_symlink() or not source.resolve().is_relative_to(model_dir) or source.stat().st_size>30_000_000:
        raise ValueError('approved model checkpoint not found or exceeds size limit')
    try:import torch
    except (ImportError,OSError) as exc:raise RuntimeError('PyTorch needed for saved-weight inference') from exc
    # weights_only=True prohibits arbitrary pickle class instantiation.
    checkpoint=torch.load(source,map_location='cpu',weights_only=True)
    if checkpoint.get('config')!={'vocab':256,'embed_dim':256,'layers':4,'heads':4}:
        raise ValueError('incompatible training model configuration')
    torch.set_num_threads(min(4,max(1,os.cpu_count() or 1)))
    model=_build_model(torch).cpu()
    model.load_state_dict(checkpoint['weights'],strict=True)
    model.eval()
    seq=list(prompt.encode('utf-8')[-128:])
    with torch.no_grad():
        logits=model(torch.tensor([seq],dtype=torch.long))[0,-1,:]
        probs=torch.nn.functional.softmax(logits,dim=-1)
        probabilities,indices=probs.topk(top_k)
        dist=[{'byte':int(i),'probability':float(p),'printable_ascii':chr(int(i)) if 32<=int(i)<=126 else None} for p,i in zip(probabilities.tolist(),indices.tolist())]
    return {'model_id':model_id,'model_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
      'input_utf8_bytes':len(prompt.encode('utf-8')),'top_next_byte_predictions':dist,
      'evidence_class':'CALCULATED_WITH_PERSISTED_TRAINED_WEIGHTS',
      'limitations':'Next-byte statistical prediction on small archived Golf text; not semantic understanding or a general conversational system.'}


def dell_validation(root, data_dir, *, include_training=True, steps=2, cores=None):
    from .hardware import discover,telemetry
    hardware=discover(data_dir,gpu_probe=True)
    live=telemetry()
    cap=min(4,hardware['cpu']['effective'],cores or 4)
    # This is an observation of this process's host; the conversational Dell profile is never substituted.
    report={'format_version':'0.5','executed_utc':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),
        'hardware':hardware,'live_telemetry':live,
        'dell_identity_verified_this_run':bool(hardware['machine_is_dell'] and hardware['os']['system']=='Windows' and hardware['model']),
        'historical_reference_only':{'manufacturer':'Dell (user-confirmed)','operating_system':'Windows (earlier use)','python':'3.12.6 reported in prior use','torch_cuda':'not available in earlier recorded training','storage_free_gb':'approximately 120 GB in July 2026','historical_training':'approximately 3.7 million model parameters at approximately 21 tokens/sec; unverified here'},
        'checks':{}}
    if include_training:
        report['checks']['cpu_training']=train_source_bytes(root,steps=steps,workers=max(1,cap))
    else:report['checks']['cpu_training']={'status':'NOT_RUN'}
    return report
