"""Actual supervised numerical learning; not LLM or semantic understanding."""
import csv
import math
from pathlib import Path


def train_csv(path,epochs=120,learning_rate=.14):
    if type(epochs)!=int or not 1<=epochs<=500:raise ValueError('epochs 1..500')
    if type(learning_rate) not in (int,float) or not .00001<=learning_rate<=1:raise ValueError('learning rate invalid')
    try:import numpy as np
    except ImportError as e:raise RuntimeError('numpy is required for learning backend') from e
    if path.stat().st_size>2_000_000:raise ValueError('CSV exceeds 2 MB')
    with path.open(newline='',encoding='utf-8') as f:
        rows=list(csv.reader(f))
    if len(rows)<25 or len(rows)>10001:raise ValueError('minimum 24 labeled rows and maximum 10000')
    # Explicit format: header f1,f2,...,label ; numeric values and labels 0 or 1.
    header=rows[0]
    if header[-1]!='label' or not 1<=len(header)-1<=32 or len(set(header))!=len(header):raise ValueError('CSV must have distinct feature columns and final label')
    data=[]
    for row in rows[1:]:
        if len(row)!=len(header):raise ValueError('unequal CSV columns')
        values=[float(x) for x in row]
        if not all(math.isfinite(x) for x in values) or values[-1] not in (0,1):raise ValueError('all values finite, binary label required')
        data.append(values)
    if len(data)<24 or len(data)>10000:raise ValueError('row bound')
    a=np.array(data,dtype=np.float64)
    rng=np.random.default_rng(29391)
    idx=rng.permutation(len(a));split=int(len(a)*.8)
    train=a[idx[:split]];test=a[idx[split:]]
    if len(set(train[:,-1]))!=2 or len(set(test[:,-1]))!=2:raise ValueError('train and heldout must each contain both classes')
    mu=train[:,:-1].mean(0);sigma=train[:,:-1].std(0);sigma[sigma<1e-12]=1
    X=np.clip((train[:,:-1]-mu)/sigma,-10,10);Y=train[:,-1]
    Xt=np.clip((test[:,:-1]-mu)/sigma,-10,10);Yt=test[:,-1]
    w=np.zeros(X.shape[1]);b=0.
    for _ in range(epochs):
        p=1/(1+np.exp(-np.clip(X@w+b,-40,40)))
        error=p-Y;w-=learning_rate*(X.T@error/len(X)+0.001*w);b-=learning_rate*float(error.mean())
    predictions=(1/(1+np.exp(-np.clip(Xt@w+b,-40,40)))>=.5)
    accuracy=float((predictions==Yt).mean())
    return {'model':{'feature_names':header[:-1],'mean':mu.tolist(),'std':sigma.tolist(),'weights':w.tolist(),'bias':float(b)},
            'metrics':{'train_rows':len(train),'heldout_rows':len(test),'heldout_accuracy':accuracy,'epochs':epochs,'split_seed':29391,'evidence':'supervised logistic regression trained on supplied numeric CSV, NOT natural-language comprehension'}}


def predict(model,features):
    if not isinstance(features,list) or len(features)!=len(model['weights']) or not all(type(v) in (int,float) and math.isfinite(v) for v in features):raise ValueError('feature vector invalid')
    z=sum(min(10,max(-10,(v-m)/s))*w for v,m,s,w in zip(features,model['mean'],model['std'],model['weights']))+model['bias']
    probability=1/(1+math.exp(-max(-40,min(40,z))))
    return {'probability_label_1':probability,'predicted_label':int(probability>=.5),'evidence':'calculated from trained local coefficients'}
