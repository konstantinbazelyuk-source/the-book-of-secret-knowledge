#!/usr/bin/env python3
"""Verify the exact release files included in the SHA256 release manifest."""
import hashlib,json,sys
from pathlib import Path
root=Path(__file__).resolve().parent
manifest=json.loads((root/'SOURCE_MANIFEST.json').read_text())
errors=[]
for rel,expected in manifest['files'].items():
    file=root/rel
    if not file.is_file():errors.append('missing '+rel);continue
    actual=hashlib.sha256(file.read_bytes()).hexdigest()
    if actual!=expected:errors.append('changed '+rel)
print(json.dumps({'release':manifest['release'],'checked':len(manifest['files']),'mismatches':errors},indent=2))
sys.exit(1 if errors else 0)
