package org.ripple.mushroom;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.camera.core.Preview;
import androidx.core.content.ContextCompat;
import com.google.common.util.concurrent.ListenableFuture;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Real CameraX acquisition to the Ring v5.1 workstation through USB `adb reverse`.
 * Does not imply that the full Ring model runs on Android: that runs on the host.
 */
public final class MainActivity extends AppCompatActivity {
    private final ExecutorService imageExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService sendExecutor = Executors.newSingleThreadExecutor();
    private final AtomicBoolean inflight = new AtomicBoolean(false);
    private TextView status;
    private EditText sessionToken;
    private PreviewView cameraPreview;
    private ProcessCameraProvider provider;
    private boolean enabled = false;
    private long lastAttemptNs = 0L;
    private int sent=0, failed=0;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(12,12,12,12);
        TextView title=new TextView(this);title.setText("Ripple Mushroom Sensor | USB camera input to Dell workstation");root.addView(title);
        sessionToken=new EditText(this);sessionToken.setHint("Enter token from Dell workstation");
        sessionToken.setSingleLine(true);root.addView(sessionToken);
        LinearLayout buttons=new LinearLayout(this);
        Button start=new Button(this);start.setText("START CAMERA");buttons.addView(start);
        Button stop=new Button(this);stop.setText("STOP CAMERA");buttons.addView(stop);root.addView(buttons);
        status=new TextView(this);status.setText("Stopped. Requires camera permission, USB debugging and adb reverse.");root.addView(status);
        cameraPreview=new PreviewView(this);root.addView(cameraPreview,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
        start.setOnClickListener(v->startRequest());
        stop.setOnClickListener(v->stopCamera());
    }
    private void startRequest() {
        if(sessionToken.getText().toString().trim().length()<24){status.setText("Enter a valid workstation session token first.");return;}
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.CAMERA},19);return;
        }
        startCamera();
    }
    @Override public void onRequestPermissionsResult(int code,@NonNull String[] permissions,@NonNull int[] results){
        super.onRequestPermissionsResult(code,permissions,results);
        if(code==19 && results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED)startCamera();
        else status.setText("Camera permission not granted.");
    }
    private void startCamera(){
        if(enabled)return;
        enabled=true;
        ListenableFuture<ProcessCameraProvider> future=ProcessCameraProvider.getInstance(this);
        future.addListener(()->{
            try {
                provider=future.get();provider.unbindAll();
                Preview preview=new Preview.Builder().build();preview.setSurfaceProvider(cameraPreview.getSurfaceProvider());
                ImageAnalysis analysis=new ImageAnalysis.Builder()
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build();
                analysis.setAnalyzer(imageExecutor,this::onFrame);
                provider.bindToLifecycle(this,CameraSelector.DEFAULT_BACK_CAMERA,preview,analysis);
                status.setText("Camera running; sending at <=4 JPEG frames/second via USB loopback.");
            }catch(Exception e){enabled=false;status.setText("Camera start error: "+e.getMessage());}
        },ContextCompat.getMainExecutor(this));
    }
    private void onFrame(ImageProxy image){
        try{
            long now=SystemClock.elapsedRealtimeNanos();
            if(!enabled || now-lastAttemptNs<250_000_000L || !inflight.compareAndSet(false,true))return;
            lastAttemptNs=now;
            int width=image.getWidth(),height=image.getHeight();
            // CameraX RGBA output is byte ordered A,R,G,B, possibly padded rows.
            ImageProxy.PlaneProxy plane=image.getPlanes()[0];ByteBuffer data=plane.getBuffer();
            int row=plane.getRowStride(),pixel=plane.getPixelStride();
            if(width<24 || height<24 || width>4096 || height>4096 || pixel<4){inflight.set(false);return;}
            int ow=Math.min(320,width),oh=Math.min(240,height);
            int[] argb=new int[ow*oh];
            for(int y=0;y<oh;y++) for(int x=0;x<ow;x++){
                int px=(x*width/ow),py=(y*height/oh),base=py*row+px*pixel;
                int r=data.get(base+1)&255,g=data.get(base+2)&255,b=data.get(base+3)&255;
                argb[y*ow+x]=0xff000000|(r<<16)|(g<<8)|b;
            }
            Bitmap bm=Bitmap.createBitmap(argb,ow,oh,Bitmap.Config.ARGB_8888);
            ByteArrayOutputStream bos=new ByteArrayOutputStream();
            bm.compress(Bitmap.CompressFormat.JPEG,78,bos);byte[] jpg=bos.toByteArray();bm.recycle();
            final String token=sessionToken.getText().toString().trim();
            // Use the host receipt clock for Ring timing. These device timestamps are metadata only.
            sendExecutor.execute(()->transmit(jpg,now,token));
        }catch(Exception e){inflight.set(false);runOnUiThread(()->status.setText("Frame encoding error: "+e.getMessage()));}
        finally{image.close();}
    }
    private void transmit(byte[] jpeg,long timestamp,String token){
        HttpURLConnection con=null;
        try{
            URL url=new URL("http://127.0.0.1:8789/frame");
            con=(HttpURLConnection)url.openConnection();con.setRequestMethod("POST");
            con.setConnectTimeout(2500);con.setReadTimeout(4000);con.setDoOutput(true);
            con.setRequestProperty("Authorization","Bearer "+token);
            con.setRequestProperty("Content-Type","image/jpeg");
            con.setRequestProperty("X-Device-Monotonic-Ns",Long.toString(timestamp));
            con.setFixedLengthStreamingMode(jpeg.length);
            try(OutputStream out=con.getOutputStream()){out.write(jpeg);}
            int code=con.getResponseCode();if(code!=202)throw new RuntimeException("server HTTP "+code);
            sent++;
            runOnUiThread(()->status.setText("Streaming via USB localhost. Accepted "+sent+"; rejected "+failed+". Server still must process frames."));
        }catch(Exception e){failed++;runOnUiThread(()->status.setText("Connection failed (adb reverse/token/server?): "+e.getMessage()));}
        finally{if(con!=null)con.disconnect();inflight.set(false);}
    }
    private void stopCamera(){enabled=false;if(provider!=null)provider.unbindAll();status.setText("Stopped. Accepted "+sent+" frames; errors "+failed);}
    @Override protected void onStop(){super.onStop();stopCamera();}
    @Override protected void onDestroy(){stopCamera();imageExecutor.shutdown();sendExecutor.shutdown();super.onDestroy();}
}
