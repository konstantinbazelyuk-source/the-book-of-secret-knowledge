# Ripple FieldSphere v0.2 — Parametric CAD, Real Geometry, Magnetic Calibration Engineering

**Status:** mechanically modeled, editable CAD exported, solid/interference checks run, electromagnetic equations independently checked, 50 software-noise replicates executed. **No device has been physically fabricated, magnetometer installed, or bench current applied.** This package is a design and verification deliverable, not a claim of a tested physical instrument.

## Built

- 8 handed, integral 34-mm cube-corner hub + **actual-footprint** sensor supports; 12 structural rails 164 mm long; 1 100-turn calibration-coil bobbin. Geometry in `cad/build_cad.py` and `cad/coil_fixture.py`, generated with CadQuery/OpenCascade.
- Manufacturing files in `cad/STEP` (AutoCAD/Fusion/Inventor-readable 3D solids), `cad/DXF` (dimensioned 2D reference sketches, units mm), `cad/STL` (print-ready separate parts).
- `FieldSphere_v02_mechanical_assembly.step` contains **20 solid structural parts**; `FieldSphere_v02_with_reference_PCBs.step` includes eight additional **reference-only** sensor PCB bodies for checking placement. PCB shapes are NOT printed parts.
- Machine-readable `cad/SENSOR_COORDINATES.json` and `.csv` with explicit MUX channel/XYZ mapping and right-handed panel orientation basis. These are **nominal CAD-derived die positions**, not physical measurements or sensor-axis calibrations.
- `physics_and_tests.py` models magnetic flux density via direct numerical Biot–Savart integration. `results/replicate_noise.py` runs 50 independently seeded **simulated-noise** trials. `tests/` contains geometry, CAD-import, physical equation and reversible Ring v5.2 geometry-upgrade tests.
- `ring_v52_geometry_upgrade/install_geometry.py` performs a **guarded** patch of Ring v5.2's hard-coded probe positions using these coordinates; backs up the original and does not edit any Ripple neural math.
- Original FieldSphere v0.1 ZIP included as `source_archives/` for rollback.

## Source-supported dimensions (Adafruit PCB board design)

We inspected the manufacturer's **actual EagleCAD board file**, `Adafruit LIS2MDL.brd`, sha `f09e763d7c092b81f68a52e9ed9015b0f056b8a7`, from the GitHub repo `adafruit/Adafruit-LIS2MDL-PCB`. Its dimension layer shows **25.40 × 17.78 mm**, and four mounting holes centered at (2.54,2.54), (22.86,2.54), (2.54,15.24), (22.86,15.24) mm. Hole drilling nominal **2.54 mm**, layout pitch **20.32 × 12.70 mm**. The LIS2MDL package center is (12.7,8.89) mm in the EagleCAD board. The board's actual stack height, chip-die depth and production tolerance remain to be verified.

This sensor board is licensed under the original publisher's Creative Commons terms. We do not relicense the vendor PCB file. The new mounting fixtures and mathematical code are independently authored; any vendor PCB drawing reproduced or modified should retain original license and attribution.

## Geometry table and manufacturing rules

| Parameter | Nominal | What it governs |
|--|--:|--|
| Hub-center X/Y/Z | ±90 mm | 8 cube-corner structural nodes |
| Hub size | 34 × 34 × 34 mm | Stable three-rail orthogonal connector |
| Structural rail cross-section | 12.0 × 12.0 mm | Square stock/printer profile |
| Socket opening | 12.5 × 12.5 mm | 0.5 mm total fit clearance, subject to real printing |
| Socket depth | 10.5 mm | 9.0 mm insertion, 1.5 mm remaining clearance |
| Center separation | 180 mm | Nominal cube sides |
| Rail length | **164.0 mm** | 180 - 34 + 2 × 9 |
| M3 fastening clearance | 3.4 mm | Nylon bolt transverse through each hub and beam |
| Board mounting pitch | **20.32 × 12.70 mm** | Exact vendor PCB holes |
| PCB standoff height | 3 mm | Leaves space for wiring/components subject to assembly check |
| Calculated die distance from coil center | **101.785 mm** | After 45 mm inward radial mount plus nominal board/chip stack |
| Calibration coil effective radius | 25 mm assumed | To be measured after winding |
| Coil turns/current | 100 / 0.20 A | Current must be physically measured |

**Manufacture first:** one handed hub, one rail, one 25.40 × 17.78 mm dummy board; check corner pitch, screw fit, 3D-printer shrinkage, and physical connector clearance. Use nonferromagnetic fasteners. If a part does not fit, change the parametric dimensions and regenerate all CAD and its coordinates. Never force a PCB.

## Physics findings (all calculated, none measured)

For a circular coil, magnetic flux density is computed by

`B(r) = μ0 N I /(4π) ∮ [dℓ × (r-r')]/|r-r'|³`

with μ0 = 4π×10⁻⁷ H/m (standard nominal vacuum permeability approximation for engineering). For a circular loop on its axis, the cross-check is:

`Bz(z) = μ0 N I a² / [2(a²+z²)^(3/2)]`.

At 100 turns, 25 mm *effective* winding radius, and 0.2 A, the eight CAD-designed die locations each receive **5.391 µT** nominal calculated field magnitude, versus **1.481 µT** at the original ±90 mm hub-center nominal locations, a factor of **3.639**. Reversing from +0.2 A to -0.2 A gives a predicted 2B differential, approximately **10.782 µT** in norm. The radial design optimizes the calibration-coil signal, not a proven detection score.

**NO signal can be called real until mounted sensors report it.** The ST LIS2MDL has published typical magnetic RMS noise around 3 mgauss = 0.3 µT and typical 1.5 mgauss/LSB = 0.15 µT. That specification is **not our measured noise**; system noise and drift may be worse. Fifty Gaussian-noise simulations use it only as an assumption; their statistical variation is not a confidence interval on the real instrument.

## Compatible with Ring of Mushrooms FieldSphere v5.2

The original v5.2 workstation has a hard-coded eight-site `POSITIONS_M` at ±0.09 m for gradient fitting; those are **structural hub centers, not the new magnetometer die positions**.

With your existing **complete Ring/FieldSphere v5.2** extracted, run:

```bash
python ring_v52_geometry_upgrade/install_geometry.py PATH_TO_EXTRACTED_RING_ROOT
```

The Ring root must contain `workstation/fieldsphere.py`. The script creates a byte-for-byte backup `workstation/fieldsphere.v52_original.py`, installs `field_geometry_v02.json` and its geometry loader, and requires exactly the expected source line. The actual runtime then uses nominal XYZ positions **in meters** from the CAD manifest. The old synthetic data were generated with old positions; **do not compare their field gradients with v0.2 physical geometry without recomputing inputs**. Revert by restoring the backed-up file and removing `field_geometry_v02.json` and `field_geometry_v02.py`.

The existing magnetic anomaly/injection path can continue without sensor-axis calibration. Accurate **global XYZ vector gradients** additionally require measured die positions, each sensor's orientation, hard/soft-iron calibration, timing and repeatable coil tests. Software accepts calibration data only when explicitly supplied; a nominal geometry is never equivalent to physical calibration.

## Execution and AutoCAD

CadQuery and ezdxf are installed in the research environment; regenerate:

```bash
python cad/build_cad.py
python cad/coil_fixture.py
python physics_and_tests.py
python results/replicate_noise.py
python results/sensitivity.py
python -m unittest discover -s tests -v
```

For **full AutoCAD** (Windows), use `IMPORT` → `STEP` → `cad/STEP/FieldSphere_v02_mechanical_assembly.step` (AutoCAD LT and AutoCAD for Mac do not support this 3D STEP import). `cad/DXF/` can open as a 2D reference and be edited. For Autodesk Fusion/Inventor, import STEP. This model was **not opened or edited in Autodesk AutoCAD software**; native DWG and target-device preview are unverified. The parametric master is the Python CadQuery source, not a static mesh.

To print, select **eight `hub_*.stl` (one of each)**, **twelve copies of the identical 164 mm beam** from `beam_x.stl` (rotated per chosen axis), and **one coil bobbin**. The STL's units are interpreted as mm by the slicer (STL itself does not encode units). All M3/M2.5 nylon fastener sizes and thread/retention must be checked on real parts.

## Engineering gate status

- **Implemented/executed:** editable solid CAD, 3D import/revalidation, tested nominal hub–rail clearance, exact PCB footprint from vendor CAD, eight calculated XYZ positions, Biot–Savart model, 50 synthetic-noise replicates, reversible Ring patch, checksums.
- **Calculated:** coil signal at nominal locations, sensor radial improvement, geometric clearance, bounded parameter sensitivity.
- **Unverified:** actual assembled dimensions, 3D-print fit, PCB connectors/standoff, cable length, I²C reliability, probe axes, magnetometer noise and temperature drift, real coil current, physical B field, Dell/Android manufacturing workflow.

## Citable sources

1. Adafruit LIS2MDL manufacturer PCB: https://github.com/adafruit/Adafruit-LIS2MDL-PCB (`Adafruit LIS2MDL.brd`, EagleCAD board; Creative Commons Attribution-ShareAlike).
2. LIS2MDL datasheet, ST DS12144: https://www.st.com/resource/en/datasheet/lis2mdl.pdf (dynamic range, noise, sensitivity, output data rate).
3. Adafruit LIS2MDL breakout: https://www.adafruit.com/product/4488 (fixed 0x1E address, four mounting holes).
4. Adafruit PCA9548A multiplexer: https://www.adafruit.com/product/5626 (8 separate I²C channels).
5. Autodesk official STEP import procedure: https://www.autodesk.com/support/technical/article/caas/sfdcarticles/sfdcarticles/Importing-a-STEP-file-into-AutoCAD.html

**Original v0.1 CAD and firmware remain in the included archive.** This v0.2 release is a geometry and physical-manufacturing upgrade, not a verified physical sensor. Firmware and neural core mathematics have not been silently replaced.
