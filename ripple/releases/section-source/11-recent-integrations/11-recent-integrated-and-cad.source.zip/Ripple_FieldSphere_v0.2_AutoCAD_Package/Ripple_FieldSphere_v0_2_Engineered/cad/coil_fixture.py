"""100-turn calibration coil winding jig, editable STEP/STL; mm."""
import pathlib,json
import cadquery as cq
from cadquery import exporters
root=pathlib.Path(__file__).resolve().parents[1]
core_radius=24.0; flange_radius=30.0; winding_half_width=9.0
core=cq.Solid.makeCylinder(core_radius,18.0,cq.Vector(0,0,-9),cq.Vector(0,0,1))
for z in (-12,9):core=core.fuse(cq.Solid.makeCylinder(flange_radius,3,cq.Vector(0,0,z),cq.Vector(0,0,1)))
core=core.cut(cq.Solid.makeCylinder(19,26,cq.Vector(0,0,-13),cq.Vector(0,0,1)))
# independent wire exit notch: nonconductive clearance only, not through the winding section
for x in (-26.0,26.0):
 core=core.cut(cq.Solid.makeCylinder(1.1,4,cq.Vector(x,0,9),cq.Vector(0,0,1)))
core=core.clean()
assert len(core.Solids())==1
exporters.export(core,str(root/'cad'/'STEP'/'coil_bobbin_v02.step'))
exporters.export(core,str(root/'cad'/'STL'/'coil_bobbin_v02.stl'),tolerance=.08,angularTolerance=.18)
(root/'results'/'COIL_CAD_REPORT.json').write_text(json.dumps({'nominal_effective_radius_mm':25.0,'measured_radius_required':True,'winding_core_radius_mm':24.0,'flange_outer_radius_mm':30.0,'window_width_mm':18.0,'volume_mm3':core.Volume(),'die_radius_mm':101.78457268119897},indent=2))
print('coil one solid volume',core.Volume())
