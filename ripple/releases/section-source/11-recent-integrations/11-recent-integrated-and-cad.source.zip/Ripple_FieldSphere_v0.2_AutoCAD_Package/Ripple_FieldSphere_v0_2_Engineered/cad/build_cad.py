#!/usr/bin/env python3
"""FieldSphere v0.2 exact-dimension, editable mechanical CAD generation.
Units: mm. Board footprint derived from original EagleCAD open-source board.
Usage: python cad/build_cad.py
Exports STEP assembly, STLs, DXFs, machine-readable coordinate ledger.
"""
from __future__ import annotations
import csv, json, itertools, math, pathlib
import cadquery as cq
import ezdxf
from cadquery import exporters

ROOT=pathlib.Path(__file__).resolve().parents[1]
CAD=ROOT/'cad'
STEP=CAD/'STEP'; STL=CAD/'STL'; DXF=CAD/'DXF'
for d in [STEP,STL,DXF,ROOT/'results']:d.mkdir(parents=True,exist_ok=True)

# Manufacturing parameters. NEVER silently change original v0.1 geometry.
NODE_MM=90.0; HUB_SIDE_MM=34.0; SOCKET_DEPTH_MM=10.5
SOCKET_WIDTH_MM=12.5; BEAM_WIDTH_MM=12.0
# Actual beams: center spacing 180, face-to-face gap = 180-34=146 mm,
# nominal insertion each end = 9 mm; beam length = 164 mm.
BEAM_LENGTH_MM=2*NODE_MM-HUB_SIDE_MM+2*9.0
BOLT_HOLE_MM=3.4; BOARD_HOLE_MM=2.90
BOARD_W_MM=25.40; BOARD_H_MM=17.78
BOARD_HOLES_X_MM=20.32; BOARD_HOLES_Y_MM=12.70
PLATE_W_MM=31.5; PLATE_H_MM=23.5; PLATE_THICK_MM=3.5
PLATE_OFFSET_MM=45.0; BOSS_HEIGHT_MM=3.0
BOARD_THICK_ASSUMED_MM=1.6; DIE_HEIGHT_ASSUMED_MM=1.0
STEM_RADIUS_MM=5.0
SENSOR_R_MM=math.sqrt(3)*NODE_MM - (PLATE_OFFSET_MM+PLATE_THICK_MM+BOSS_HEIGHT_MM+BOARD_THICK_ASSUMED_MM+DIE_HEIGHT_ASSUMED_MM)

vec=lambda x:cq.Vector(*[float(v) for v in x])
def norm(v):
 n=math.sqrt(sum(x*x for x in v));return tuple(x/n for x in v)
def mul(v,s):return tuple(x*s for x in v)
def add(a,b):return tuple(x+y for x,y in zip(a,b))
def cross(a,b):return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])

def local_plane(origin,normal):
 n=norm(normal)
 ux=norm(cross((0,0,1),n))
 return cq.Plane(origin=vec(origin),xDir=vec(ux),normal=vec(n)),ux,norm(cross(n,ux))

def shape_hub(sx,sy,sz):
 pos=(sx*NODE_MM,sy*NODE_MM,sz*NODE_MM)
 h=cq.Workplane('XY').box(HUB_SIDE_MM,HUB_SIDE_MM,HUB_SIDE_MM).val().translate(vec(pos))
 for axis,sgn in enumerate((sx,sy,sz)):
  # Local inward arm points opposite to sign of vertex coordinate
  dims=[SOCKET_WIDTH_MM]*3;dims[axis]=SOCKET_DEPTH_MM
  cen=list(pos);cen[axis]+=-sgn*(HUB_SIDE_MM/2-SOCKET_DEPTH_MM/2)
  p=cq.Workplane('XY').box(*dims).val().translate(vec(cen))
  h=h.cut(p)
  # Nylon M3 clearance through BOTH walls and square bar near the socket mouth.
  # x arm drilled parallel Z; y arm drilled parallel X; z arm drilled parallel Y.
  b=[0.0,0.0,0.0];b[axis]=-sgn*14.0
  borepos=add(pos,b)
  drillaxis=(2,0,1)[axis]
  dr=[0.,0.,0.];dr[drillaxis]=1.
  base=add(borepos,mul(dr,-20.0))
  h=h.cut(cq.Solid.makeCylinder(BOLT_HOLE_MM/2,40,vec(base),vec(dr)))
 # Radially inward rigid support: this places all 8 dies closer to test coil.
 n=norm((-sx,-sy,-sz))
 h=h.fuse(cq.Solid.makeCylinder(STEM_RADIUS_MM,24,vec(add(pos,mul(n,23))),vec(n)))
 plane,ux,uy=local_plane(add(pos,mul(n,PLATE_OFFSET_MM)),n)
 plate=cq.Workplane(plane).box(PLATE_W_MM,PLATE_H_MM,PLATE_THICK_MM,centered=(True,True,False)).val()
 h=h.fuse(plate)
 for x,y in itertools.product((-BOARD_HOLES_X_MM/2,BOARD_HOLES_X_MM/2),(-BOARD_HOLES_Y_MM/2,BOARD_HOLES_Y_MM/2)):
  center=add(add(plane.origin.toTuple(),mul(ux,x)),mul(uy,y))
  boss_base=add(center,mul(n,PLATE_THICK_MM))
  h=h.fuse(cq.Solid.makeCylinder(3.15,BOSS_HEIGHT_MM,vec(boss_base),vec(n)))
  # 2.9mm clearance hole through spacer and 3.5mm plate, no decorative bores.
  bore_base=add(center,mul(n,-0.2))
  h=h.cut(cq.Solid.makeCylinder(BOARD_HOLE_MM/2,PLATE_THICK_MM+BOSS_HEIGHT_MM+0.4,vec(bore_base),vec(n)))
 return h.clean(),pos,n,ux,uy

def shape_rail(axis,sign_a,sign_b):
 c=[0.,0.,0.];dims=[]
 other=[i for i in range(3) if i!=axis]
 c[other[0]]=sign_a*NODE_MM;c[other[1]]=sign_b*NODE_MM
 dims=[BEAM_WIDTH_MM]*3;dims[axis]=BEAM_LENGTH_MM
 b=cq.Workplane('XY').box(*dims).val().translate(vec(c))
 boreaxis=(2,0,1)[axis]
 da=[0.,0.,0.];da[boreaxis]=1.
 for t in [-76.,76.]:
  center=c.copy();center[axis]=t
  base=add(center,mul(da,-8.))
  b=b.cut(cq.Solid.makeCylinder(BOLT_HOLE_MM/2,16,vec(base),vec(da)))
 return b.clean(),c

def board_proxy(pos,n,ux,uy):
 # **REFERENCE ONLY** PCB, not a part to manufacture. Its nominal center is
 # identical to the EAGLE LIS2MDL package position x=12.7,y=8.89.
 plane=cq.Plane(origin=vec(add(pos,mul(n,PLATE_OFFSET_MM+PLATE_THICK_MM+BOSS_HEIGHT_MM))),xDir=vec(ux),normal=vec(n))
 b=cq.Workplane(plane).box(BOARD_W_MM,BOARD_H_MM,BOARD_THICK_ASSUMED_MM,centered=(True,True,False)).val()
 for x,y in itertools.product((-BOARD_HOLES_X_MM/2,BOARD_HOLES_X_MM/2),(-BOARD_HOLES_Y_MM/2,BOARD_HOLES_Y_MM/2)):
  p=add(add(plane.origin.toTuple(),mul(ux,x)),mul(uy,y))
  b=b.cut(cq.Solid.makeCylinder(2.54/2,BOARD_THICK_ASSUMED_MM+0.4,vec(add(p,mul(n,-0.2))),vec(n)))
 return b.clean()

def dxf_board():
 doc=ezdxf.new('R2010');m=doc.modelspace()
 m.add_lwpolyline([(-BOARD_W_MM/2,-BOARD_H_MM/2),(BOARD_W_MM/2,-BOARD_H_MM/2),(BOARD_W_MM/2,BOARD_H_MM/2),(-BOARD_W_MM/2,BOARD_H_MM/2)],close=True,dxfattribs={'layer':'REFERENCE_PCB_OUTLINE'})
 for x,y in itertools.product((-BOARD_HOLES_X_MM/2,BOARD_HOLES_X_MM/2),(-BOARD_HOLES_Y_MM/2,BOARD_HOLES_Y_MM/2)):
  m.add_circle((x,y),2.54/2,dxfattribs={'layer':'PCB_HOLES'})
 m.add_circle((0,0),1.0,dxfattribs={'layer':'SENSOR_DIE_CENTER'})
 m.add_text('REFERENCE ONLY: Adafruit Eagle board; drill holes 2.54mm',dxfattribs={'height':1.0,'insert':(-17,-13),'layer':'NOTES'})
 doc.header['$INSUNITS']=4;doc.saveas(DXF/'Adafruit_LIS2MDL_verified_board_footprint_mm.dxf')

def dxf_hub_section():
 d=ezdxf.new('R2010');m=d.modelspace();m.add_lwpolyline([(-17,-17),(17,-17),(17,17),(-17,17)],close=True,dxfattribs={'layer':'HUB_OUTLINE'})
 m.add_lwpolyline([(6.5,-6.25),(17,-6.25),(17,6.25),(6.5,6.25)],close=True,dxfattribs={'layer':'SOCKET_SECTION'})
 m.add_circle((14,0),BOLT_HOLE_MM/2,dxfattribs={'layer':'BOLT_CENTRE_SECTION'})
 m.add_text('HUB 34x34 SECTION - M3 nylon x-arm transverse bolt x=14',dxfattribs={'height':1.4,'insert':(-20,-22)})
 d.header['$INSUNITS']=4;d.saveas(DXF/'Hub_and_socket_dimensioned_mm.dxf')

def main():
 all_shapes=[];rows=[];hubs=[];rails=[];proxies=[]
 for sx,sy,sz in itertools.product((-1,1),repeat=3):
  label=''.join('p' if q>0 else 'm' for q in (sx,sy,sz))
  h,pos,n,u,v=shape_hub(sx,sy,sz)
  assert len(h.Solids())==1,('HUB_NOT_ONE_SOLID',label,len(h.Solids()))
  hubs.append((label,h));all_shapes.append(h)
  exporters.export(h,str(STEP/f'hub_{label}.step'))
  exporters.export(h,str(STL/f'hub_{label}.stl'),tolerance=0.12,angularTolerance=0.2)
  b=board_proxy(pos,n,u,v);proxies.append(b)
  die=add(pos,mul(n,PLATE_OFFSET_MM+PLATE_THICK_MM+BOSS_HEIGHT_MM+BOARD_THICK_ASSUMED_MM+DIE_HEIGHT_ASSUMED_MM))
  mux=((1 if sx>0 else 0)*4 +(1 if sy>0 else 0)*2 +(1 if sz>0 else 0))
  rows.append(dict(mux_channel=mux,hub_label=label,hub_x_mm=pos[0],hub_y_mm=pos[1],hub_z_mm=pos[2],die_x_nominal_mm=round(die[0],5),die_y_nominal_mm=round(die[1],5),die_z_nominal_mm=round(die[2],5),die_radial_nominal_mm=round(math.dist((0,0,0),die),5),axis_x_tangent=[round(z,7) for z in u],axis_y_tangent=[round(z,7) for z in v],normal_inward=[round(z,7) for z in n]))
 for axis in (0,1,2):
  for signs in itertools.product((-1,1),repeat=2):
   sh,c=shape_rail(axis,*signs)
   label=f'rail_{"xyz"[axis]}_{"p" if signs[0]>0 else "m"}{"p" if signs[1]>0 else "m"}'
   assert len(sh.Solids())==1
   rails.append((label,sh));all_shapes.append(sh)
 # All beams orientation-specific placement; manufacturing identical 164mm beam variants
 for a in range(3):
  sh,c=shape_rail(a,1,1)
  exporters.export(sh,str(STEP/f'beam_{"xyz"[a]}.step'))
  exporters.export(sh,str(STL/f'beam_{"xyz"[a]}.stl'),tolerance=0.12,angularTolerance=0.2)
 # Assembly includes hubs/rails; separate layout STEP adds exact PCB proxy for fit verification.
 assembly=cq.Compound.makeCompound(all_shapes)
 exporters.export(assembly,str(STEP/'FieldSphere_v02_mechanical_assembly.step'))
 exporters.export(cq.Compound.makeCompound(all_shapes+proxies),str(STEP/'FieldSphere_v02_with_reference_PCBs.step'))
 rows.sort(key=lambda r:r['mux_channel'])
 with open(CAD/'SENSOR_COORDINATES.json','w') as f:
  json.dump({'units':'mm','sensor_die_position_status':'derived_nominal_not_physical_calibration',
  'board_source':'Adafruit LIS2MDL Eagle PCB repo commit f09e763d7c092b81f68a52e9ed9015b0f056b8a7',
  'pcb_die_package_center_xy_mm':[12.7,8.89],
  'assumptions':{'board_thickness_mm':BOARD_THICK_ASSUMED_MM,'die_height_above_pcb_mm':DIE_HEIGHT_ASSUMED_MM,
  'fixture_plate_offset_mm':PLATE_OFFSET_MM,'boss_height_mm':BOSS_HEIGHT_MM},
  'nodes':rows},f,indent=2)
 with open(CAD/'SENSOR_COORDINATES.csv','w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=['mux_channel','hub_label','hub_x_mm','hub_y_mm','hub_z_mm','die_x_nominal_mm','die_y_nominal_mm','die_z_nominal_mm','die_radial_nominal_mm']);w.writeheader();w.writerows({k:r[k] for k in w.fieldnames} for r in rows)
 dxf_board();dxf_hub_section()
 out={'hub_count':len(hubs),'beam_count':len(rails),'pcb_reference_count':len(proxies),'printable_solid_hub_count':sum(len(h.Solids()) for _,h in hubs),
 'beam_length_mm':BEAM_LENGTH_MM,'sensor_nominal_radius_mm':SENSOR_R_MM,
 'sensor_radius_spread_mm':max(r['die_radial_nominal_mm'] for r in rows)-min(r['die_radial_nominal_mm'] for r in rows),
 'hub_volume_mm3':round(hubs[0][1].Volume(),2),'beam_volume_mm3':round(rails[0][1].Volume(),2),
 'step_files':[p.name for p in STEP.glob('*.step')],'stl_files':[p.name for p in STL.glob('*.stl')]}
 (ROOT/'results'/'CAD_BUILD_REPORT.json').write_text(json.dumps(out,indent=2))
 print(json.dumps(out,indent=2))

if __name__=='__main__':main()
