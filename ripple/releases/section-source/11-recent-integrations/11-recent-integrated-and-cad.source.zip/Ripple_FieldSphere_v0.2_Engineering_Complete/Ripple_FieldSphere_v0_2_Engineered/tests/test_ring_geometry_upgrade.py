import sys,unittest,tempfile,shutil,pathlib,importlib,subprocess,json,os
root=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'ring_v52_geometry_upgrade'))
from install_geometry import upgrade,ORIGINAL
SOURCEDIR=root/'ring_v52_geometry_upgrade'/'fixtures'

class VersionUpgradeTest(unittest.TestCase):
 def test_reversible_geometry_upgrade(self):
  with tempfile.TemporaryDirectory() as d:
   dest=pathlib.Path(d);(dest/'workstation').mkdir()
   (dest/'workstation'/'__init__.py').write_text('')
   src=SOURCEDIR/'fieldsphere_v52_unmodified.py'
   if not src.exists():self.skipTest('Original Ring v5.2 source missing')
   shutil.copy2(src,dest/'workstation'/'fieldsphere.py')
   original=(dest/'workstation'/'fieldsphere.py').read_bytes()
   r=upgrade(dest)
   self.assertFalse(r['already_installed'])
   self.assertTrue(upgrade(dest)['already_installed'])
   self.assertEqual((dest/'workstation'/'fieldsphere.v52_original.py').read_bytes(),original)
   self.assertNotIn(ORIGINAL,(dest/'workstation'/'fieldsphere.py').read_text())
   cmd=[sys.executable,'-c',"from workstation.fieldsphere import POSITIONS_M,POSITION_GEOMETRY_STATUS; print(POSITIONS_M.shape,round(float(POSITIONS_M[0,0]),6),POSITION_GEOMETRY_STATUS)"]
   p=subprocess.run(cmd,cwd=dest,capture_output=True,text=True,timeout=20)
   self.assertEqual(p.returncode,0,p.stderr)
   self.assertIn('derived_nominal_not_physical_calibration',p.stdout)
   self.assertIn('8, 3',p.stdout)
 def test_invalid_version_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   dest=pathlib.Path(d);(dest/'workstation').mkdir();(dest/'workstation'/'fieldsphere.py').write_text('NOT_V52')
   with self.assertRaises(ValueError):upgrade(dest)

if __name__=='__main__':unittest.main()
