"""CAD and physics verification with real executables; no fabricated hardware scores."""
import sys,unittest, math,json,itertools,pathlib,time
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'cad'));sys.path.insert(0,str(ROOT))
import cadquery as cq
import numpy as np
from build_cad import *
from physics_and_tests import loop_field,analytic_axis_field,run_calculations

def bounding_boxes_overlap(a,b):
 return a.xmin <= b.xmax and b.xmin <= a.xmax and a.ymin <= b.ymax and b.ymin <= a.ymax and a.zmin <= b.zmax and b.zmin <= a.zmax

class CADPhysicsTests(unittest.TestCase):
 def test_dimensions_from_board(self):
  self.assertAlmostEqual(BOARD_W_MM,25.4);self.assertAlmostEqual(BOARD_H_MM,17.78)
  self.assertAlmostEqual(BOARD_HOLES_X_MM,20.32);self.assertAlmostEqual(BOARD_HOLES_Y_MM,12.70)
 def test_machinable_nominal_fit(self):
  self.assertGreater(SOCKET_WIDTH_MM-BEAM_WIDTH_MM,0.35)
  self.assertLess(SOCKET_WIDTH_MM-BEAM_WIDTH_MM,0.7)
  self.assertAlmostEqual(2*NODE_MM-HUB_SIDE_MM,146)
  self.assertAlmostEqual(BEAM_LENGTH_MM,164)
  self.assertAlmostEqual((BEAM_LENGTH_MM-(2*NODE_MM-HUB_SIDE_MM))/2,9)
  self.assertLess(9,SOCKET_DEPTH_MM)
 def test_board_edge_clearance(self):
  self.assertGreater((PLATE_W_MM-BOARD_W_MM)/2,2)
  self.assertGreater((PLATE_H_MM-BOARD_H_MM)/2,2)
  self.assertGreater((PLATE_W_MM-BOARD_HOLES_X_MM)/2,5)
 def test_actual_die_radius_is_updated(self):
  self.assertAlmostEqual(SENSOR_R_MM,101.78457268119897,places=5)
  self.assertGreater(SENSOR_R_MM,80)
  self.assertLess(SENSOR_R_MM,120)
 def test_eight_positions_distinct(self):
  coords=json.loads((CAD/'SENSOR_COORDINATES.json').read_text())['nodes']
  self.assertEqual(len(coords),8)
  self.assertEqual([c['mux_channel'] for c in coords],list(range(8)))
  self.assertEqual(len({(c['die_x_nominal_mm'],c['die_y_nominal_mm'],c['die_z_nominal_mm']) for c in coords}),8)
  for c in coords:
   self.assertAlmostEqual(c['die_radial_nominal_mm'],SENSOR_R_MM,places=4)
   self.assertAlmostEqual(sum(a*a for a in c['normal_inward']),1,places=5)
 def test_assembly_count(self):
  asm=cq.importers.importStep(str(STEP/'FieldSphere_v02_mechanical_assembly.step'))
  self.assertEqual(len(asm.solids().vals()),20)
 def test_pcb_reference_in_assembly(self):
  asm=cq.importers.importStep(str(STEP/'FieldSphere_v02_with_reference_PCBs.step'))
  self.assertEqual(len(asm.solids().vals()),28)
 def test_valid_and_solid_hubs(self):
  for f in STEP.glob('hub_*.step'):
   s=cq.importers.importStep(str(f))
   self.assertEqual(len(s.solids().vals()),1,f.name)
   self.assertTrue(s.val().isValid(),f.name)
 def test_valid_and_solid_rails(self):
  for f in STEP.glob('beam_*.step'):
   s=cq.importers.importStep(str(f))
   self.assertEqual(len(s.solids().vals()),1,f.name)
   self.assertTrue(s.val().isValid(),f.name)
 def test_exported_parts_exist(self):
  self.assertEqual(len(list(STL.glob('hub_*.stl'))),8)
  self.assertEqual(len(list(STL.glob('beam_*.stl'))),3)
  self.assertTrue((STL/'coil_bobbin_v02.stl').stat().st_size>10000)
 def test_slot_rod_not_interfering(self):
  # Check nominal beams and all assembled hubs for volume intersections.
  hubs=[shape_hub(*q)[0] for q in itertools.product((-1,1),repeat=3)]
  beams=[shape_rail(ax,*signs)[0] for ax in range(3) for signs in itertools.product((-1,1),repeat=2)]
  max_overlap=0.0
  for h in hubs:
   for b in beams:
    # cheap intersect bounding volumes filter
    if not bounding_boxes_overlap(h.BoundingBox(),b.BoundingBox()):continue
    overlap=h.intersect(b).Volume()
    max_overlap=max(max_overlap,overlap)
  self.assertLess(max_overlap,1e-5,f'volumetric overlap {max_overlap} mm^3')
 def test_beam_holes_transverse_and_symmetric(self):
  for ax in range(3):
   b,c=shape_rail(ax,1,1)
   self.assertGreater(b.Volume(),0)
 def test_reciprocal_magnetic_field(self):
  v=[0.040,-0.065,0.090];B=loop_field(v,segments=1024)
  self.assertTrue(np.allclose(loop_field(v,current_a=-.2,segments=1024),-B,rtol=1e-10,atol=1e-20))
  self.assertTrue(np.allclose(loop_field(v,current_a=0,segments=1024),[0,0,0],atol=1e-20))
 def test_onaxis_physics_crosscheck(self):
  for z in [0.0,0.03,0.10,0.18]:
   calc=loop_field([0,0,z],segments=256)[2]
   self.assertAlmostEqual(calc/analytic_axis_field(z),1,places=11)
 def test_segments_numerical_convergence(self):
  p=[0.064,0.058,0.061]
  fine=loop_field(p,segments=4096)
  coarse=loop_field(p,segments=512)
  self.assertLess(float(np.linalg.norm(fine-coarse)/np.linalg.norm(fine)),1e-10)
 def test_old_and_new_field_ratio(self):
  r=run_calculations();self.assertGreater(r['gain_vs_original_hub_vertex'],3)
  self.assertLess(r['gain_vs_original_hub_vertex'],4)
  self.assertEqual(r['sensor_count'],8)
 def test_50_paired_noise_replications_are_labeled(self):
  result=json.loads((ROOT/'results'/'UNCERTAINTY_50_REPLICATES.json').read_text())
  self.assertEqual(result['runs'],50)
  self.assertEqual(result['input_type'],'simulated_sensor_noise_not_physical_data')
  self.assertEqual(len(result['difference_magnitude_uT_per_rep']),50)
  self.assertGreater(result['mean_delta_magnitude_uT'],0)
 def test_dxf_units_mm(self):
  import ezdxf
  for f in DXF.glob('*.dxf'):
   d=ezdxf.readfile(f);self.assertEqual(d.header['$INSUNITS'],4,f.name)

if __name__=='__main__':unittest.main()
