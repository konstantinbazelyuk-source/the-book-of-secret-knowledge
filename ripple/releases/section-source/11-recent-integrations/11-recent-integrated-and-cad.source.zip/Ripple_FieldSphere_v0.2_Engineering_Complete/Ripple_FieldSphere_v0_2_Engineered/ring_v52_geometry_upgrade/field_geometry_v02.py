"""Read the active FieldSphere physical CAD geometry; no hidden defaults."""
import json,pathlib
import numpy as np

def load_geometry_positions():
 f=pathlib.Path(__file__).with_name('field_geometry_v02.json')
 if not f.is_file():raise FileNotFoundError(f'FieldSphere v0.2 geometry manifest required: {f}')
 d=json.loads(f.read_text())
 rows=d['nodes']
 if len(rows)!=8 or [x['mux_channel'] for x in rows]!=list(range(8)):
  raise ValueError('expected eight unique ordered MUX channels')
 pos=np.array([[x[k] for k in ('die_x_nominal_mm','die_y_nominal_mm','die_z_nominal_mm')] for x in rows],dtype=float)*0.001
 if pos.shape!=(8,3) or not np.isfinite(pos).all():raise ValueError('invalid CAD probe coordinates')
 if any(np.linalg.norm(pos[i]-pos[j])<0.05 for i in range(8) for j in range(i+1,8)):
  raise ValueError('colliding probe die coordinates')
 status=str(d.get('sensor_die_position_status','unknown'))
 if status!='derived_nominal_not_physical_calibration':
  raise ValueError('unexpected or undocumented position calibration status')
 return pos,status
