#!/usr/bin/env python3
"""Idempotent, rollback-safe update of Ring v5.2's spatial probe geometry.
Copies a CAD-derived manifest, adds a checked loader, and changes one hardcoded
POSITIONS_M assignment. Original core neuron equations and other code unchanged.
"""
import argparse,hashlib,json,pathlib,shutil
ROOT=pathlib.Path(__file__).resolve().parents[1]
ORIGINAL='POSITIONS_M=np.asarray([[a*.09,b*.09,c*.09] for a in (-1,1) for b in (-1,1) for c in (-1,1)],float)'
REPLACEMENT='from .field_geometry_v02 import load_geometry_positions\nPOSITIONS_M,POSITION_GEOMETRY_STATUS=load_geometry_positions()'

def upgrade(folder):
 folder=pathlib.Path(folder).resolve()
 fp=folder/'workstation'/'fieldsphere.py'
 if not fp.is_file():raise FileNotFoundError(f'Missing Ring v5.2 workstation fieldsphere.py: {fp}')
 old=fp.read_text(encoding='utf-8')
 if old.count(ORIGINAL)!=1:
  if old.count(REPLACEMENT):return {'already_installed':True,'target':str(fp)}
  raise ValueError('Unexpected workstation version; refused to patch')
 origsha=hashlib.sha256(old.encode()).hexdigest()
 bpath=fp.with_suffix('.v52_original.py')
 if bpath.exists() and bpath.read_bytes()!=fp.read_bytes():raise ValueError('Backup conflict; refused to patch')
 shutil.copy2(fp,bpath)
 geo_src=ROOT/'cad'/'SENSOR_COORDINATES.json'
 target=folder/'workstation'/'field_geometry_v02.json'
 loader_src=pathlib.Path(__file__).parent/'field_geometry_v02.py'
 shutil.copy2(geo_src,target)
 shutil.copy2(loader_src,folder/'workstation'/'field_geometry_v02.py')
 patch=old.replace(ORIGINAL,REPLACEMENT)
 patch=patch.replace("'sites':8,'interpretation':'least-squares local linear gradient at measured sites, not spatial tomography'", "'sites':8,'position_geometry_status':POSITION_GEOMETRY_STATUS,'interpretation':'least-squares linear gradient using CAD nominal probe positions; requires measured die positions and probe orientation for physical claims, not tomography'")
 fp.write_text(patch,encoding='utf-8')
 return {'already_installed':False,'target':str(fp),'original_sha256':origsha,'backup_path':str(bpath),'geometry_manifest':str(target)}

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('ring_v52_root',help='Folder containing workstation/fieldsphere.py')
 a=p.parse_args();print(json.dumps(upgrade(a.ring_v52_root),indent=2))
