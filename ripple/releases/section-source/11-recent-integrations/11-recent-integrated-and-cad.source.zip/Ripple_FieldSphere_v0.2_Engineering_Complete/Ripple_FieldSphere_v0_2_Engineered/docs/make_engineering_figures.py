"""Engineering diagrams generated from manufactured CAD coordinate manifest, not art."""
import sys,json,itertools,pathlib,math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
root=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root))
from physics_and_tests import loop_field
rows=json.loads((root/'cad'/'SENSOR_COORDINATES.json').read_text())['nodes']
vertices=np.array([[r[k] for k in ('hub_x_mm','hub_y_mm','hub_z_mm')] for r in rows]);dies=np.array([[r[k] for k in ('die_x_nominal_mm','die_y_nominal_mm','die_z_nominal_mm')] for r in rows]);
fig=plt.figure(figsize=(11,8));ax=fig.add_subplot(111,projection='3d')
for i in range(8):
 for j in range(i+1,8):
  if (vertices[i]!=vertices[j]).sum()==1:
   ax.plot(*zip(vertices[i],vertices[j]),color='#4b6571',linewidth=3.0)
for i,(v,p) in enumerate(zip(vertices,dies)):
 ax.plot(*zip(v,p),color='#db7e1f',linewidth=3)
 ax.scatter(*v,color='#325f72',s=80,depthshade=True)
 ax.scatter(*p,color='#c23f30',s=52,depthshade=True)
 ax.text(*(p+np.array([3,-3,0])),f'MUX{i}',fontsize=8)
ang=np.linspace(0,2*math.pi,201)
ax.plot(25*np.cos(ang),25*np.sin(ang),np.zeros_like(ang),color='green',lw=4,label='100-turn calibration coil (radius nominal 25 mm)')
ax.scatter([0],[0],[0],c='black',marker='+',s=70)
ax.set(xlabel='X (mm)',ylabel='Y (mm)',zlabel='Z (mm)',title='FieldSphere v0.2 — designed fixture coordinates (no hardware measurements)')
ax.set_box_aspect([1,1,1]);ax.view_init(elev=21,azim=40)
ax.plot([],[],[],color='#db7e1f',label='Integrated radial sensor arm')
ax.plot([],[],[],marker='o',color='#c23f30',linestyle='',label='Calculated die position')
ax.legend(loc='upper right',fontsize=9)
fig.savefig(root/'docs'/'CAD_COORDINATE_ASSEMBLY.png',dpi=170,bbox_inches='tight');plt.close(fig)

# Coil field variation versus radius along the diagonal and selected CAD stations
radii=np.linspace(55,190,110)
positions=np.array([[r/math.sqrt(3)]*3 for r in radii])/1000
magnitudes=np.linalg.norm(loop_field(positions,segments=2048),axis=1)*1e6
fig,ax=plt.subplots(figsize=(9,5.1))
ax.plot(radii,magnitudes,label='Biot–Savart field magnitude (µT), 100 turns, 25 mm, 0.2 A')
for radius,label in [(101.7846,'new nominal die ~101.8 mm'),(math.sqrt(3)*90,'old nominal hub ~155.9 mm')]:
 v=float(np.linalg.norm(loop_field([radius/math.sqrt(3)/1000]*3))*1e6)
 ax.plot(radius,v,'o',markersize=8)
 ax.annotate(f'{label}\n{v:.2f} µT',xy=(radius,v),xytext=(radius+7,v+0.75),arrowprops={'arrowstyle':'->'},fontsize=9)
ax.set(xlabel='Sensor radial distance from coil center (mm)',ylabel='Predicted magnetic field magnitude (µT)',title='Mathematical fixture optimization — no measured sensor data')
ax.grid(alpha=.25);ax.legend(fontsize=9)
fig.savefig(root/'docs'/'MAGNETIC_FIELD_VS_RADIUS.png',dpi=170,bbox_inches='tight');plt.close(fig)

# 2D mechanical elevation with actual beam-hole centers
fig,ax=plt.subplots(figsize=(10,8))
for y in [-90,90]:ax.plot([-90,90],[y,y],c='#586f7b',lw=9,solid_capstyle='butt')
for x in [-90,90]:ax.plot([x,x],[-90,90],c='#586f7b',lw=9,solid_capstyle='butt')
for x in [-90,90]:
 for y in [-90,90]:
  ax.add_patch(plt.Rectangle((x-17,y-17),34,34,facecolor='#dfb96a',edgecolor='#533f24'))
ax.annotate('',xy=(-90,-129),xytext=(90,-129),arrowprops={'arrowstyle':'<->'})
ax.text(0,-136,'180 mm center-to-center',ha='center',fontsize=10)
ax.annotate('',xy=(129,-90),xytext=(129,90),arrowprops={'arrowstyle':'<->'})
ax.text(134,0,'180 mm centers',rotation=90,va='center')
ax.set(xlim=(-155,158),ylim=(-151,139),aspect='equal',xlabel='X (mm)',ylabel='Y (mm)',title='Cube-node mechanical plan: 34 mm hubs, 164 mm rails; two Z layers coincide')
ax.grid(alpha=.15);fig.savefig(root/'docs'/'PLAN_MECHANICAL_DIMENSIONS.png',dpi=160,bbox_inches='tight');plt.close(fig)
print('Created engineering figures')
