"""Reproducible Biot-Savart calculations for the *new CAD die positions*.
Calculations are not field measurements. No inferred magnetic vector axes.
"""
from __future__ import annotations
import pathlib,json,math,csv
import numpy as np
ROOT=pathlib.Path(__file__).resolve().parent
MU0=4*math.pi*1e-7

# SI field for a planar circular N-turn coil, numerical Biot-Savart integration:
# B(r)=mu0 NI/(4pi) integral (dl x (r-r'))/|r-r'|^3.
def loop_field(pos_m, radius_m=.025, turns=100, current_a=.2, segments=4096):
 pts=np.asarray(pos_m,dtype=float)
 one=(pts.ndim==1)
 pts=pts.reshape(-1,3)
 ang=(np.arange(segments)+0.5)*2*math.pi/segments
 dl=np.stack([-radius_m*np.sin(ang),radius_m*np.cos(ang),np.zeros(segments)],axis=1)*(2*math.pi/segments)
 source=np.stack([radius_m*np.cos(ang),radius_m*np.sin(ang),np.zeros(segments)],axis=1)
 vecs=pts[:,None,:]-source[None,:,:]
 r=np.linalg.norm(vecs,axis=2)
 if (r<1e-6).any():raise ValueError('field singular near filament')
 integrand=np.cross(dl[None,:,:],vecs)/r[:,:,None]**3
 B=MU0*turns*current_a/(4*math.pi)*integrand.sum(axis=1)
 return B[0] if one else B

def analytic_axis_field(z_m,radius_m=.025,turns=100,current_a=.2):
 return MU0*turns*current_a*radius_m**2/(2*(radius_m**2+z_m**2)**1.5)

def run_calculations():
 coords=json.loads((ROOT/'cad'/'SENSOR_COORDINATES.json').read_text())['nodes']
 positions=np.array([[c[k]/1000 for k in ('die_x_nominal_mm','die_y_nominal_mm','die_z_nominal_mm')] for c in coords])
 old=np.array([[c[k]/1000 for k in ('hub_x_mm','hub_y_mm','hub_z_mm')] for c in coords])
 B=loop_field(positions)*1e6;B0=loop_field(old)*1e6
 # +/-0.2 A current reversal in uniform background yields 2B response.
 out={'status':'calculated_not_measured','units':'microtesla',
  'coil':{'turns':100,'effective_radius_m_assumed':0.025,'drive_current_A':0.2,'current_reverse_difference_A':0.4},
  'sensor_positions_nominal_not_physically_measured':True,
  'sensor_count':8,
  'new_array_magnitude_mean_uT':float(np.linalg.norm(B,axis=1).mean()),
  'original_hub_vertex_magnitude_mean_uT':float(np.linalg.norm(B0,axis=1).mean()),
  'gain_vs_original_hub_vertex':float(np.linalg.norm(B,axis=1).mean()/np.linalg.norm(B0,axis=1).mean()),
  'new_array_field_vectors_uT':B.round(6).tolist(),
  'new_array_reversed_current_delta_uT':(2*B).round(6).tolist(),
  'old_vertex_field_vectors_uT':B0.round(6).tolist(),
  'ST_typical_noise_assumption_uT_RMS':0.3,
  'ST_typical_sensitivity_per_LSB_uT':0.15,
  'new_array_single_reading_magnitude_over_noise':float(np.linalg.norm(B,axis=1).mean()/0.3),
  'reversal_per_component_requires_orientation_calibration':True}
 (ROOT/'results'/'COIL_PHYSICS.json').write_text(json.dumps(out,indent=2))
 with (ROOT/'results'/'COIL_PHYSICS.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['mux_channel','Bx_calculated_uT','By_calculated_uT','Bz_calculated_uT','magnitude_calculated_uT'])
  for i,row in enumerate(B):w.writerow([i,*row.tolist(),np.linalg.norm(row)])
 return out
if __name__=='__main__':print(json.dumps(run_calculations(),indent=2))
