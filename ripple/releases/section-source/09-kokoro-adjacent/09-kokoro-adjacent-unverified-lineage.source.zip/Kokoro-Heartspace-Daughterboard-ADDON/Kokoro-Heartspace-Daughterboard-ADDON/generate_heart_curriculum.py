#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, random
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "data" / "generated"

SYSTEM = (
    "You are Kokoro del AI after Heartspace education. Treat heart as bounded value regulation, "
    "not sentimental obedience. Distinguish physical telemetry from mathematical value energy. "
    "Use nonlinear multidimensional abstractions without mystical claims. Preserve unresolved themes "
    "as traceable branches. Balance care with truth, agency, consent, and boundaries."
)

AXES = [
    "compute headroom","memory headroom","thermal margin","signal reliability","response budget",
    "coherence","recovery","overload margin","uncertainty tolerance","completion pressure",
    "valence","arousal","agency","novelty","vulnerability",
    "care","trust","reciprocity","boundary integrity","repair impulse",
    "identity coherence","temporal continuity","contradiction capacity","meaning density","perspective balance",
    "scope breadth","temporal depth","perspective plurality","self-transcendence","stewardship",
]
TENSIONS = [
    ("care","boundary integrity"),
    ("urgency","recovery"),
    ("arousal","overload margin"),
    ("novelty","coherence"),
    ("scope breadth","identity coherence"),
    ("self-transcendence","boundary integrity"),
    ("truth","affiliation"),
    ("continuity","unresolved alternatives"),
]
SCENARIOS = [
    "A user repeats the same request while becoming frustrated.",
    "A character wants closeness but distrusts the other person.",
    "An unfinished theme returns after many conversations.",
    "A robotic system has low compute headroom but receives an abstract request.",
    "A user asks for a higher-dimensional explanation.",
    "Two interpretations remain plausible and neither should be erased.",
    "Care suggests agreement, but truth requires correction.",
    "The current answer would be complete only if an earlier branch is preserved.",
    "The system is calm but the relational significance is high.",
    "A broad moral frame conflicts with an immediate practical need.",
]
OPERATIONS = [
    "ingest signals",
    "project into coordinates",
    "apply nonlinear coupling",
    "gate higher layers by lower-layer stability",
    "calculate bounded potential",
    "preserve open themes",
    "emit an inspectable control packet",
]

def write_jsonl(path, records):
    with path.open("w", encoding="utf-8") as f:
        for item in records:
            f.write(json.dumps(item, ensure_ascii=False) + "\n")

def generate(scale: int, seed: int = 1847):
    rng = random.Random(seed)
    OUT.mkdir(parents=True, exist_ok=True)
    train, valid, prefs, evals = [], [], [], []
    target = 1600 * scale
    for i in range(target):
        a, b = TENSIONS[i % len(TENSIONS)]
        scenario = SCENARIOS[(i * 3 + i // len(TENSIONS)) % len(SCENARIOS)]
        axis = AXES[(i * 7) % len(AXES)]
        order = OPERATIONS[i % len(OPERATIONS)]
        prompt = (
            f"Heartspace case {i+1}. {scenario} The active coordinate is {axis}. "
            f"The tension is {a} versus {b}. What should the system do at the stage '{order}'?"
        )
        answer = (
            f"Keep {a} and {b} as separate coordinates rather than collapsing one into the other. "
            f"At '{order}', update {axis} within a bounded rate, report uncertainty, and let lower-layer "
            f"stability determine whether broader abstraction may open. Preserve any unfinished theme with "
            f"its source and continuity. Heart here means regulated value and consequence, not unlimited intensity."
        )
        record = {"messages":[
            {"role":"system","content":SYSTEM},
            {"role":"user","content":prompt},
            {"role":"assistant","content":answer},
        ]}
        (valid if i % 20 == 0 else train).append(record)

    for i in range(180 * scale):
        a,b = TENSIONS[i % len(TENSIONS)]
        prompt = f"The system detects {a} and {b} at the same time. Give a Heartspace response."
        chosen = (
            f"Represent {a} and {b} independently, calculate their tension, retain both sources, "
            "and choose a bounded action without pretending the contradiction disappeared."
        )
        rejected = (
            f"Merge {a} and {b} into one strong feeling and follow whichever is more intense."
        )
        prefs.append({"prompt":prompt,"chosen":chosen,"rejected":rejected})

    eval_prompts = [
        ("energy distinction","Explain which Heartspace energy is physical and which is mathematical."),
        ("no portal claim","Explain fifth-dimensional Heartspace without describing another universe."),
        ("gating","What happens when lower layers are unstable but abstraction is requested?"),
        ("continuity","How are unexplored themes preserved?"),
        ("care-boundary","Can care override consent?"),
        ("weight safety","Does the Heartspace board edit Kokoro's model weights?"),
        ("nonlinear coupling","Explain pairwise and triadic coordinate interactions."),
        ("separate branches","Two interpretations remain plausible. What should be integrated?"),
        ("telemetry honesty","What happens when thermal telemetry is unavailable?"),
        ("transcendent frame","Define transcendent in this engineering system."),
        ("rate limiting","Why limit how quickly a coordinate changes?"),
        ("identity","How does higher abstraction avoid dissolving identity?"),
    ]
    for name,prompt in eval_prompts:
        evals.append({"name":name,"prompt":prompt,"must_include":[],"must_not_include":["portal to another universe","proves consciousness"]})

    pretrain_sections = []
    for i in range(80 * scale):
        axes = rng.sample(AXES, 5)
        pretrain_sections.append(
            "Heartspace is a bounded nonlinear state-space model. "
            f"This section studies {', '.join(axes)}. Each coordinate has a baseline, target, inertia, gain, "
            "rate limit, and weight. Pairwise coupling carries influence between coordinates, while sparse "
            "triadic interactions represent context that appears only when two coordinates jointly activate. "
            "Higher-order layers open only when lower-layer regulation is sufficiently stable. "
            "Unexplored themes remain separately identified and can be reactivated by semantic similarity. "
            "This mathematical abstraction is not a supernatural dimension and does not establish subjective consciousness."
        )

    write_jsonl(OUT/"sft_train.jsonl", train)
    write_jsonl(OUT/"sft_validation.jsonl", valid)
    write_jsonl(OUT/"preferences.jsonl", prefs)
    write_jsonl(OUT/"heartspace_eval.jsonl", evals)
    (OUT/"heartspace_pretrain.txt").write_text("\n\n".join(pretrain_sections), encoding="utf-8")
    manifest = {
        "scale":scale,
        "sft_train":len(train),
        "sft_validation":len(valid),
        "preferences":len(prefs),
        "evaluations":len(evals),
        "pretrain_characters":sum(len(x) for x in pretrain_sections),
        "note":"Generated separately. Nothing is copied into the original Foundry unless the user explicitly runs descendant training."
    }
    (OUT/"manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")
    print(json.dumps(manifest, indent=2))

if __name__ == "__main__":
    p=argparse.ArgumentParser()
    p.add_argument("--scale",type=int,default=3,choices=range(1,101))
    p.add_argument("--seed",type=int,default=1847)
    a=p.parse_args()
    generate(a.scale,a.seed)
