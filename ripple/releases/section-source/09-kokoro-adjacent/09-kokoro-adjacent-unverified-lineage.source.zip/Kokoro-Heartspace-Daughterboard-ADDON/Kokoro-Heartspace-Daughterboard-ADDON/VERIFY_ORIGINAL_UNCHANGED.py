#!/usr/bin/env python3
from pathlib import Path
import argparse, hashlib, json

ADDON=Path(__file__).resolve().parent
def valid(p): return (p/"kokoro.py").is_file()
def find(explicit=None):
    c=[]
    if explicit:c.append(Path(explicit).expanduser().resolve())
    if len(ADDON.parents)>=2:c.append(ADDON.parents[1])
    c += [ADDON.parent.parent/"Kokoro-del-Corazon-Foundry", ADDON.parent/"Kokoro-del-Corazon-Foundry"]
    for p in c:
        if valid(p):return p
    raise FileNotFoundError("Original Foundry not found.")
p=argparse.ArgumentParser();p.add_argument("--base");a=p.parse_args()
base=find(a.base)
expected=json.loads((ADDON/"ORIGINAL_BASE_HASHES.json").read_text())
missing=[];changed=[]
for rel,wanted in expected.items():
    file=base/rel
    if not file.exists(): missing.append(rel);continue
    if hashlib.sha256(file.read_bytes()).hexdigest()!=wanted:changed.append(rel)
print(f"Base: {base}")
print(f"Original packaged files checked: {len(expected)}")
print(f"Missing: {len(missing)}")
print(f"Changed: {len(changed)}")
if missing:
    print("\nMissing:");[print(" ",x) for x in missing]
if changed:
    print("\nChanged:");[print(" ",x) for x in changed]
if not missing and not changed:
    print("\nPASS: original packaged Foundry files are unchanged.")
else:
    print("\nSetup artifacts and training checkpoints are intentionally outside this original-package hash list.")
