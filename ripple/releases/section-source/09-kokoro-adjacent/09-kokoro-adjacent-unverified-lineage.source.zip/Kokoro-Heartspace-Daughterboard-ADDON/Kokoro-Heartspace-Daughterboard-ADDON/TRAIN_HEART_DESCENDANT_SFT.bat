@echo off
setlocal
cd /d "%~dp0"
title Train Separate Heartspace Descendant
set "BASE=%~dp0..\.."
if not exist "%BASE%\kokoro.py" (
 set /p "BASE=Paste the full path to Kokoro-del-Corazon-Foundry: "
 set "BASE=%BASE:"=%"
)
if not exist "%BASE%\checkpoints\pretrain-best.pt" (
 echo pretrain-best.pt does not exist. Finish pretraining first.
 pause
 exit /b 1
)
if not exist "data\generated\sft_train.jsonl" (
 "%BASE%\.venv\Scripts\python.exe" generate_heart_curriculum.py --scale 3
)
if not exist "%BASE%\checkpoints-heartspace" mkdir "%BASE%\checkpoints-heartspace"
"%BASE%\.venv\Scripts\python.exe" "%BASE%\kokoro.py" sft ^
 --config "%BASE%\configs\nano.json" ^
 --tokenizer "%BASE%\artifacts\tokenizer.json" ^
 --train-file "%~dp0data\generated\sft_train.jsonl" ^
 --validation-file "%~dp0data\generated\sft_validation.jsonl" ^
 --checkpoint "%BASE%\checkpoints\pretrain-best.pt" ^
 --output "%BASE%\checkpoints-heartspace" ^
 --steps 2000
pause
