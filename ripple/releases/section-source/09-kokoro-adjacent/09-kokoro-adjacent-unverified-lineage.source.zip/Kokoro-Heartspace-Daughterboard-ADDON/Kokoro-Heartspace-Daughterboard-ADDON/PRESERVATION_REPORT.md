# Preservation report

This package was built as a genuine add-on.

It installs only inside:

`Kokoro-del-Corazon-Foundry\addons\Kokoro-Heartspace-Daughterboard`

It does not replace or modify:

- Kokoro source code
- tokenizer
- prepared pretraining shards
- current pretraining process
- original checkpoints
- original memory database
- Psyche Daughterboard

Optional descendant training writes into:

`Kokoro-del-Corazon-Foundry\checkpoints-heartspace`

The original checkpoints remain under:

`Kokoro-del-Corazon-Foundry\checkpoints`
