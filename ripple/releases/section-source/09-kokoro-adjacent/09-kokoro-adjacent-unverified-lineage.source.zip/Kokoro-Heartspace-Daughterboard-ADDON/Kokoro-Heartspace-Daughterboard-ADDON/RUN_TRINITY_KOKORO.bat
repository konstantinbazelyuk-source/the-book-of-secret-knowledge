@echo off
setlocal
cd /d "%~dp0"
title Kokoro del AI - Trinity Runtime
set "BASE=%~dp0..\.."
if not exist "%BASE%\kokoro.py" (
 set /p "BASE=Paste the full path to Kokoro-del-Corazon-Foundry: "
 set "BASE=%BASE:"=%"
)
if not exist "%BASE%\.venv\Scripts\python.exe" (
 echo Original setup is missing.
 pause
 exit /b 1
)
"%BASE%\.venv\Scripts\python.exe" trinity_chat.py --base "%BASE%"
pause
