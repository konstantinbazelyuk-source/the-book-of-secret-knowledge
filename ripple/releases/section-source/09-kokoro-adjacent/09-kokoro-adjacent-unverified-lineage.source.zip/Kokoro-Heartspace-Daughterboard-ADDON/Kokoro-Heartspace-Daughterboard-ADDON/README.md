# Kokoro Heartspace Daughterboard

A detachable, inspectable **30-dimensional nonlinear energy–value engine** for Kokoro del AI.

## Central architecture

```text
Original Kokoro language brain — unchanged
                 +
Separate Heartspace Daughterboard
                 =
Runtime-bonded Kokoro with value regulation
```

Heartspace does not edit model weights. It supplies a bounded control packet at runtime. A separate optional curriculum can later train a **descendant checkpoint** without overwriting the original.

## What “dimension” means

The full state is a point in a 30-dimensional mathematical coordinate space. Each coordinate has:

- baseline and target
- inertia
- gain
- maximum rate of change
- regulatory weight
- a named layer

The package also emits interpretable 3D, 4D, and 5D projections. These are views of the larger coordinate field, not alternate universes.

## Ordered layers

1. operational
2. homeostatic
3. affective appraisal
4. relational value
5. integrative meaning
6. higher-order or “transcendent” abstraction

Higher layers are gated by lower-layer stability. The design prevents a sudden jump from ordinary operation into maximum abstract intensity.

## Nonlinear cohesion

The update includes:

- pairwise coordinate coupling
- sparse triadic interactions
- `tanh` saturation
- layer gates
- rate limiting
- potential-energy and transition-energy measurements
- unresolved-theme persistence
- 3D/4D/5D semantic projections

## Unexplored themes

An unfinished subject receives a separate theme ID, semantic signature, source text, salience, visit count, and open/resolved status. It can return later without being prematurely collapsed into the main line.

## Files

- `heartspace_board.py` — core 30D engine
- `heartspace_config.json` — axes, layers, couplings, triads, projections
- `bonded_heart_chat.py` — runtime bond to unchanged Kokoro
- `trinity_chat.py` — optional Kokoro + Psyche + Heartspace
- `heartspace_server.py` and `web/` — visual observatory
- `generate_heart_curriculum.py` — scalable follow-up education
- `tests/` — invariants and safety checks
- `docs/` — mathematics, science boundaries, operations, version report

Read `START_HERE.txt` before running it.
