from pathlib import Path
import sys, json, numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from heartspace_board import HeartspaceBoard

db=ROOT/"state"/"heartspace_test.sqlite3"
db.unlink(missing_ok=True)
board=HeartspaceBoard(db,ROOT/"heartspace_config.json")
assert board.n==30
p1=board.reflect("I care about this, but I do not want care to erase the boundary.")
assert len(p1.coordinates)==30
assert all(-1.0<=v<=1.0 for v in p1.coordinates.values())
assert set(p1.projections)=={"3D","4D","5D"}
assert p1.continuity_hash==board.continuity_hash
assert p1.layer_gates["operational"]==1.0

before=np.array(list(p1.coordinates.values()))
p2=board.reflect("A dangerous overload is happening now!", telemetry={"compute_headroom":0.05,"memory_headroom":0.08,"thermal_margin":0.05})
after=np.array(list(p2.coordinates.values()))
assert np.max(np.abs(after-before)) <= max(a.rate_limit for a in board.axes)+1e-9
assert p2.layer_gates["transcendent"] < 0.8
assert p2.coordinates["compute_headroom"] < p1.coordinates["compute_headroom"]
assert p2.coordinates["memory_headroom"] < p1.coordinates["memory_headroom"]
assert p2.coordinates["thermal_margin"] < p1.coordinates["thermal_margin"]

p3=board.reflect("Keep this unexplored theme about nonlinear dimensional order for later?")
assert p3.unresolved_themes
theme_id=p3.unresolved_themes[0]["theme_id"]
assert board.resolve_theme(theme_id)

ctx=board.render_context(p3)
assert "does not" in ctx.lower() or "not a claim" in ctx.lower()
assert "portal" in p3.scientific_note.lower()

packet=json.dumps(p3.to_dict())
assert "coordinates" in packet
board.close()
db.unlink(missing_ok=True)
print("Heartspace tests passed: 12 invariants.")
