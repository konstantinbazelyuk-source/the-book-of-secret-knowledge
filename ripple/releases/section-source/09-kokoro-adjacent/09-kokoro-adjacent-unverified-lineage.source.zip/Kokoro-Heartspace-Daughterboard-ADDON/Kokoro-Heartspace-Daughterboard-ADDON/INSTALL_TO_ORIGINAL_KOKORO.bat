@echo off
setlocal
title Install Kokoro Heartspace Daughterboard
cd /d "%~dp0"
echo.
echo This installer ADDS a separate Heartspace folder.
echo It does not modify Kokoro's model, tokenizer, source, data, or checkpoints.
echo.
set "TARGET=%~dp0..\Kokoro-del-Corazon-Foundry"
if exist "%TARGET%\kokoro.py" goto :found
set "TARGET=%~dp0..\..\Kokoro-del-Corazon-Foundry"
if exist "%TARGET%\kokoro.py" goto :found
set /p "TARGET=Paste the full path to Kokoro-del-Corazon-Foundry: "
set "TARGET=%TARGET:"=%"
:found
if not exist "%TARGET%\kokoro.py" goto :bad
set "DEST=%TARGET%\addons\Kokoro-Heartspace-Daughterboard"
if not exist "%TARGET%\addons" mkdir "%TARGET%\addons"
xcopy "%~dp0*" "%DEST%\" /E /I /Y /EXCLUDE:%~dp0install_exclude.txt >nul
if errorlevel 1 goto :copyfail
echo.
echo Installed only at:
echo %DEST%
echo.
echo Original Kokoro files were not overwritten.
echo Do not run the demo while CPU pretraining is active; it will compete for processor time.
pause
exit /b 0
:bad
echo That folder is not the original Kokoro Foundry.
pause
exit /b 1
:copyfail
echo Copy failed.
pause
exit /b 1
