@echo off
setlocal
cd /d "%~dp0"
title Preference Train Separate Heartspace Descendant
set "BASE=%~dp0..\.."
if not exist "%BASE%\checkpoints-heartspace\sft-best.pt" (
 echo Heartspace SFT checkpoint not found. Run TRAIN_HEART_DESCENDANT_SFT.bat first.
 pause
 exit /b 1
)
"%BASE%\.venv\Scripts\python.exe" "%BASE%\kokoro.py" dpo ^
 --config "%BASE%\configs\nano.json" ^
 --tokenizer "%BASE%\artifacts\tokenizer.json" ^
 --preference-file "%~dp0data\generated\preferences.jsonl" ^
 --policy "%BASE%\checkpoints-heartspace\sft-best.pt" ^
 --reference "%BASE%\checkpoints-heartspace\sft-best.pt" ^
 --output "%BASE%\checkpoints-heartspace" ^
 --steps 500
pause
