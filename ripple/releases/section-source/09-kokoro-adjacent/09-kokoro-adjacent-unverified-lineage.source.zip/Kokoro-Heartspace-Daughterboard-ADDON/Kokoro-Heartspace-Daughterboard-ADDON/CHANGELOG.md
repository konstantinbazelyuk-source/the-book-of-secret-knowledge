# Version 1.0.0

Added as a standalone package:

- 30-dimensional state space
- six ordered layers
- pairwise and triadic nonlinear coupling
- stability gates
- potential and transition energy
- bounded updates and rate limits
- unresolved-theme branch continuity
- 3D, 4D, and 5D semantic projections
- standalone demo
- browser observatory
- original-Kokoro runtime bond
- optional Psyche + Heartspace trinity runtime
- scalable Heartspace curriculum generator
- separate descendant SFT and DPO scripts
- checkpoint freezing and hashing
- original-file verification
- tests and scientific-boundary documentation

Removed from original Kokoro: nothing.
Modified in original Kokoro: nothing.
