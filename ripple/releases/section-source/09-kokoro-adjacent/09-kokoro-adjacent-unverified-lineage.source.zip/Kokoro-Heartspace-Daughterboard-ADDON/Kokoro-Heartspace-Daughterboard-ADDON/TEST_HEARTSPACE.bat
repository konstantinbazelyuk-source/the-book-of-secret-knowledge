@echo off
setlocal
cd /d "%~dp0"
title Test Kokoro Heartspace
set "BASE=%~dp0..\.."
if exist "%BASE%\.venv\Scripts\python.exe" (
 "%BASE%\.venv\Scripts\python.exe" tests\test_heartspace.py
) else (
 python tests\test_heartspace.py
)
pause
