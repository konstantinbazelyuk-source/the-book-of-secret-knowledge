@echo off
setlocal
cd /d "%~dp0"
title Freeze Pre-Heart Checkpoint
set "BASE=%~dp0..\.."
if not exist "%BASE%\kokoro.py" (
 set /p "BASE=Paste the full path to Kokoro-del-Corazon-Foundry: "
 set "BASE=%BASE:"=%"
)
"%BASE%\.venv\Scripts\python.exe" freeze_checkpoint.py --base "%BASE%"
pause
