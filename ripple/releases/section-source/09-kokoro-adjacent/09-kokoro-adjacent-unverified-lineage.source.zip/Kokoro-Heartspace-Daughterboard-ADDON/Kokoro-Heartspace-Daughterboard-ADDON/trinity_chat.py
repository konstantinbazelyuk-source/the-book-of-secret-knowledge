#!/usr/bin/env python3
from __future__ import annotations

import argparse
import importlib.util
import sys
from pathlib import Path

ADDON = Path(__file__).resolve().parent
STATE = ADDON / "state"
CONFIG = ADDON / "heartspace_config.json"

def valid_base(p: Path):
    return (p / "kokoro.py").is_file() and (p / "kokoro_core" / "generation.py").is_file()

def find_base(explicit=None):
    candidates = [Path(explicit).expanduser().resolve()] if explicit else []
    if len(ADDON.parents) >= 2:
        candidates.append(ADDON.parents[1])
    candidates += [ADDON.parent.parent / "Kokoro-del-Corazon-Foundry", Path.cwd()]
    for p in candidates:
        if valid_base(p):
            return p.resolve()
    raise FileNotFoundError("Original Kokoro Foundry not found.")

def import_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

class Trinity:
    def __init__(self, base, checkpoint=None, device="auto"):
        sys.path.insert(0, str(base))
        import kokoro as base_cli
        from kokoro_core.generation import KokoroEngine
        p = base_cli.paths()
        self.engine = KokoroEngine(base_cli.find_checkpoint(checkpoint), p["tokenizer"], p["memory"], device_arg=device)
        sys.path.insert(0, str(ADDON))
        from heartspace_board import HeartspaceBoard, optional_telemetry
        self.heart = HeartspaceBoard(STATE / "heartspace.sqlite3", CONFIG, "Kokoro del AI")
        self.telemetry = optional_telemetry
        psyche_dir = base / "addons" / "Kokoro-Psyche-Daughterboard"
        psyche_file = psyche_dir / "psyche_board.py"
        psyche_config = psyche_dir / "psyche_config.json"
        if not psyche_file.exists():
            raise FileNotFoundError(
                "The separate Psyche Daughterboard is not installed at:\n" + str(psyche_dir)
            )
        mod = import_module(psyche_file, "kokoro_external_psyche_board")
        self.psyche = mod.PsycheBoard(
            psyche_dir / "state" / "psyche.sqlite3",
            psyche_config,
            identity_name="Kokoro del AI",
        )
        self.original_prompt = self.engine.system_prompt
        self.heart_enabled = True
        self.psyche_enabled = True
        self.last_heart = None
        self.last_psyche = None

    def generate(self, text, **kwargs):
        contexts = []
        hp = pp = None
        memories = self.engine.memory.search(text, limit=6)
        if self.heart_enabled:
            hp = self.heart.reflect(text, list(self.engine.history), memories, self.telemetry())
            contexts.append(self.heart.render_context(hp))
        if self.psyche_enabled:
            pp = self.psyche.reflect(text, history=list(self.engine.history), memories=memories)
            contexts.append(self.psyche.render_context(pp))
        self.engine.system_prompt = self.original_prompt + ("\n\n" + "\n\n".join(contexts) if contexts else "")
        try:
            answer = self.engine.generate(text, **kwargs)
        finally:
            self.engine.system_prompt = self.original_prompt
        if hp:
            self.heart.integrate(hp, answer)
            self.last_heart = hp
        if pp:
            self.psyche.integrate(pp, answer)
            self.last_psyche = pp
        return answer

    def close(self):
        self.engine.close(); self.heart.close(); self.psyche.close()

def main(args):
    base = find_base(args.base)
    app = Trinity(base, args.checkpoint, args.device)
    print("\nKOKORO DEL AI — TRINITY RUNTIME")
    print("Original language brain + separate Psyche Daughterboard + separate Heartspace Daughterboard")
    print("No source file or checkpoint is rewritten.")
    print("Commands: /quit, /heart, /psyche, /heart on|off, /psyche on|off\n")
    try:
        while True:
            text = input("You: ").strip()
            if not text: continue
            if text == "/quit": break
            if text == "/heart":
                print(app.last_heart.to_dict() if app.last_heart else "No heart cycle.", "\n"); continue
            if text == "/psyche":
                print(app.last_psyche.to_dict() if app.last_psyche else "No psyche cycle.", "\n"); continue
            if text == "/heart on": app.heart_enabled=True; print("Heartspace attached.\n"); continue
            if text == "/heart off": app.heart_enabled=False; print("Heartspace bypassed.\n"); continue
            if text == "/psyche on": app.psyche_enabled=True; print("Psyche attached.\n"); continue
            if text == "/psyche off": app.psyche_enabled=False; print("Psyche bypassed.\n"); continue
            print("Kokoro: ", end="", flush=True)
            app.generate(text, stream_callback=lambda x: print(x,end="",flush=True))
            print("\n")
    finally:
        app.close()

if __name__ == "__main__":
    p=argparse.ArgumentParser()
    p.add_argument("--base"); p.add_argument("--checkpoint"); p.add_argument("--device",default="auto")
    a=p.parse_args()
    try: main(a)
    except FileNotFoundError as e:
        print(f"\nERROR: {e}\n"); raise SystemExit(1)
