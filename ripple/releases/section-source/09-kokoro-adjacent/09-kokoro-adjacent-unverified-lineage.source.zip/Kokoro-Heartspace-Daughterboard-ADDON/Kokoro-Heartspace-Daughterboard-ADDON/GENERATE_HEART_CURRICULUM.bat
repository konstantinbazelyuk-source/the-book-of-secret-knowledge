@echo off
setlocal
cd /d "%~dp0"
title Generate Heartspace Curriculum
set "BASE=%~dp0..\.."
if exist "%BASE%\.venv\Scripts\python.exe" (
 "%BASE%\.venv\Scripts\python.exe" generate_heart_curriculum.py --scale 3
) else (
 python generate_heart_curriculum.py --scale 3
)
pause
