# Remove Heartspace

1. Close any bonded chat or observatory window.
2. Delete:
   `Kokoro-del-Corazon-Foundry\addons\Kokoro-Heartspace-Daughterboard`
3. Continue using Kokoro’s original launchers.

This removes the Heartspace database and add-on only. It does not remove original Kokoro checkpoints or memory.

If you also created `checkpoints-heartspace`, delete that directory only if you no longer want the separately trained Heartspace descendant.
