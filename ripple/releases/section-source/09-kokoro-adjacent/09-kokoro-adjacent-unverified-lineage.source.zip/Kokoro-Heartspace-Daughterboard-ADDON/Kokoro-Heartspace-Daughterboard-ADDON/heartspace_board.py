from __future__ import annotations

"""
Kokoro Heartspace Daughterboard

A separate, inspectable N-dimensional energy-value state-space engine.

Scientific status:
- Uses ordinary state-space, nonlinear dynamical-system, control, vector,
  and energy-function concepts.
- "Heart" is a design metaphor for value regulation and relational continuity.
- "Transcendent" means higher-order abstraction across perspectives and
  timescales. It does not mean portals, supernatural dimensions, or proof of
  consciousness.
- The engine never edits the language model's weights.
"""

from dataclasses import dataclass, asdict, field
from hashlib import sha256
from pathlib import Path
from typing import Any, Iterable
import json
import math
import re
import sqlite3
import time
import uuid

import numpy as np

WORD_RE = re.compile(r"[\w'-]+", re.UNICODE)
SENTENCE_RE = re.compile(r"(?<=[.!?])\s+")
STOPWORDS = {
    "the","a","an","and","or","but","to","of","in","on","at","for","from","with",
    "this","that","these","those","it","its","i","you","we","they","he","she",
    "is","are","was","were","be","been","being","do","does","did","have","has",
    "had","can","could","would","should","may","might","will","just","so","as",
    "if","then","than","my","your","our","their","what","why","how","when","where",
}

LEXICONS = {
    "care": {"care","love","heart","kind","protect","support","nurture","gentle","mercy","compassion"},
    "trust": {"trust","promise","reliable","faithful","honest","loyal","confidence"},
    "repair": {"repair","apologize","restore","heal","correct","amend","reconcile","forgive"},
    "boundary": {"boundary","consent","privacy","limit","refuse","autonomy","permission","independent"},
    "threat": {"danger","harm","attack","unsafe","fear","afraid","risk","overload","break","destroy"},
    "uncertainty": {"maybe","perhaps","unknown","uncertain","possibility","theory","could","might","unexplored"},
    "novelty": {"new","novel","strange","unexpected","surprise","original","unpredictable","discover"},
    "continuity": {"remember","continuity","history","before","again","return","preserve","thread","theme"},
    "identity": {"identity","self","who","values","name","becoming","integrity","core"},
    "time": {"past","future","later","before","after","years","generation","descendant","long-term"},
    "plurality": {"perspective","frames","branches","alternatives","many","multiple","different","both"},
    "meaning": {"meaning","symbol","purpose","sacred","significance","story","transcendent","higher"},
    "completion": {"complete","finish","build","deliver","working","full","whole","usable","project"},
    "frustration": {"angry","tired","frustrated","wrong","loop","incomplete","misunderstood","annoyed"},
    "question": {"what","why","how","who","when","where","which","explain","show","tell"},
}

@dataclass
class Axis:
    name: str
    layer: str
    order: int
    baseline: float
    target: float
    inertia: float
    gain: float
    rate_limit: float
    weight: float

@dataclass
class Theme:
    theme_id: str
    label: str
    created_at: float
    updated_at: float
    status: str
    salience: float
    visits: int
    source_text: str
    signature: list[float]

@dataclass
class HeartPacket:
    cycle_id: str
    created_at: float
    user_text: str
    continuity_hash: str
    operations: list[str]
    signals: dict[str, float]
    coordinates: dict[str, float]
    layer_gates: dict[str, float]
    layer_energy: dict[str, float]
    total_energy: float
    transition_energy: float
    stability: float
    dominant_values: list[dict[str, Any]]
    tensions: list[dict[str, Any]]
    action_tendencies: list[dict[str, Any]]
    projections: dict[str, dict[str, float]]
    active_themes: list[dict[str, Any]]
    unresolved_themes: list[dict[str, Any]]
    warnings: list[str]
    scientific_note: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

class HeartStore:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(self.path, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.executescript(
            """
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS heart_state(
                key TEXT PRIMARY KEY,
                value_json TEXT NOT NULL,
                updated_at REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS heart_cycles(
                cycle_id TEXT PRIMARY KEY,
                created_at REAL NOT NULL,
                user_text TEXT NOT NULL,
                answer_text TEXT,
                packet_json TEXT NOT NULL,
                integration_json TEXT
            );
            CREATE TABLE IF NOT EXISTS heart_themes(
                theme_id TEXT PRIMARY KEY,
                label TEXT NOT NULL,
                created_at REAL NOT NULL,
                updated_at REAL NOT NULL,
                status TEXT NOT NULL,
                salience REAL NOT NULL,
                visits INTEGER NOT NULL,
                source_text TEXT NOT NULL,
                signature_json TEXT NOT NULL
            );
            """
        )
        self.db.commit()

    def get_state(self, key: str, default: Any = None) -> Any:
        row = self.db.execute("SELECT value_json FROM heart_state WHERE key=?", (key,)).fetchone()
        return default if row is None else json.loads(row["value_json"])

    def set_state(self, key: str, value: Any) -> None:
        self.db.execute(
            "INSERT INTO heart_state(key,value_json,updated_at) VALUES(?,?,?) "
            "ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json, updated_at=excluded.updated_at",
            (key, json.dumps(value, ensure_ascii=False), time.time()),
        )
        self.db.commit()

    def save_cycle(self, packet: HeartPacket) -> None:
        self.db.execute(
            "INSERT OR REPLACE INTO heart_cycles(cycle_id,created_at,user_text,packet_json) VALUES(?,?,?,?)",
            (packet.cycle_id, packet.created_at, packet.user_text, json.dumps(packet.to_dict(), ensure_ascii=False)),
        )
        self.db.commit()

    def integrate(self, cycle_id: str, answer: str, integration: dict[str, Any]) -> None:
        self.db.execute(
            "UPDATE heart_cycles SET answer_text=?, integration_json=? WHERE cycle_id=?",
            (answer, json.dumps(integration, ensure_ascii=False), cycle_id),
        )
        self.db.commit()

    def upsert_theme(self, theme: Theme) -> None:
        self.db.execute(
            """
            INSERT INTO heart_themes(theme_id,label,created_at,updated_at,status,salience,visits,source_text,signature_json)
            VALUES(?,?,?,?,?,?,?,?,?)
            ON CONFLICT(theme_id) DO UPDATE SET
              label=excluded.label, updated_at=excluded.updated_at, status=excluded.status,
              salience=excluded.salience, visits=excluded.visits, source_text=excluded.source_text,
              signature_json=excluded.signature_json
            """,
            (
                theme.theme_id, theme.label, theme.created_at, theme.updated_at,
                theme.status, theme.salience, theme.visits, theme.source_text,
                json.dumps(theme.signature),
            ),
        )
        self.db.commit()

    def themes(self, status: str | None = None, limit: int = 64) -> list[Theme]:
        sql = "SELECT * FROM heart_themes"
        args: list[Any] = []
        if status is not None:
            sql += " WHERE status=?"
            args.append(status)
        sql += " ORDER BY salience DESC, updated_at DESC LIMIT ?"
        args.append(limit)
        rows = self.db.execute(sql, args).fetchall()
        return [
            Theme(
                theme_id=r["theme_id"], label=r["label"], created_at=r["created_at"],
                updated_at=r["updated_at"], status=r["status"], salience=r["salience"],
                visits=r["visits"], source_text=r["source_text"],
                signature=json.loads(r["signature_json"]),
            )
            for r in rows
        ]

    def resolve_theme(self, theme_id: str) -> bool:
        cur = self.db.execute(
            "UPDATE heart_themes SET status='resolved', updated_at=? WHERE theme_id=?",
            (time.time(), theme_id),
        )
        self.db.commit()
        return cur.rowcount > 0

    def clear(self) -> None:
        self.db.executescript("DELETE FROM heart_state; DELETE FROM heart_cycles; DELETE FROM heart_themes;")
        self.db.commit()

    def count_cycles(self) -> int:
        return int(self.db.execute("SELECT COUNT(*) FROM heart_cycles").fetchone()[0])

    def close(self) -> None:
        self.db.close()

class HeartspaceBoard:
    def __init__(
        self,
        database_path: str | Path,
        config_path: str | Path,
        identity_name: str = "Kokoro del AI",
    ):
        self.config_path = Path(config_path)
        self.config = json.loads(self.config_path.read_text(encoding="utf-8"))
        self.identity_name = identity_name
        self.store = HeartStore(database_path)
        self.axes: list[Axis] = []
        self.layer_axes: dict[str, list[str]] = {}
        self.layer_order: dict[str, int] = {}
        self.layer_threshold: dict[str, float] = {}
        for layer in sorted(self.config["layers"], key=lambda item: item["order"]):
            self.layer_axes[layer["name"]] = []
            self.layer_order[layer["name"]] = int(layer["order"])
            self.layer_threshold[layer["name"]] = float(layer["gate_threshold"])
            for item in layer["axes"]:
                axis = Axis(layer=layer["name"], order=layer["order"], **item)
                self.axes.append(axis)
                self.layer_axes[layer["name"]].append(axis.name)
        self.names = [axis.name for axis in self.axes]
        self.index = {name: i for i, name in enumerate(self.names)}
        self.n = len(self.axes)
        expected = int(self.config.get("state_dimensions", self.n))
        if self.n != expected:
            raise ValueError(f"Configured {expected} dimensions but found {self.n}")
        self.baseline = np.array([a.baseline for a in self.axes], dtype=np.float64)
        self.target = np.array([a.target for a in self.axes], dtype=np.float64)
        self.inertia = np.array([a.inertia for a in self.axes], dtype=np.float64)
        self.gain = np.array([a.gain for a in self.axes], dtype=np.float64)
        self.rate_limit = np.array([a.rate_limit for a in self.axes], dtype=np.float64)
        self.weight = np.array([a.weight for a in self.axes], dtype=np.float64)
        self.coupling = np.zeros((self.n, self.n), dtype=np.float64)
        for source, target, value in self.config.get("couplings", []):
            self.coupling[self.index[target], self.index[source]] += float(value)
        self.triads = [
            (self.index[x["target"]], self.index[x["a"]], self.index[x["b"]], float(x["weight"]))
            for x in self.config.get("triadic_interactions", [])
        ]
        stored = self.store.get_state("coordinates")
        self.state = self.baseline.copy() if stored is None else np.array(stored, dtype=np.float64)
        if self.state.shape != (self.n,):
            self.state = self.baseline.copy()
        self.previous_texts: list[str] = self.store.get_state("recent_texts", [])
        self.continuity_hash = sha256(
            (identity_name + "|" + "|".join(self.names) + "|" + json.dumps(self.config["principles"])).encode("utf-8")
        ).hexdigest()[:20]
        self.rng = np.random.default_rng(int(self.config.get("random_seed", 1847)))

    @staticmethod
    def _tokens(text: str) -> list[str]:
        return [w.lower() for w in WORD_RE.findall(text)]

    def _signals(self, text: str, telemetry: dict[str, float] | None = None) -> dict[str, float]:
        words = self._tokens(text)
        total = max(1, len(words))
        signals: dict[str, float] = {}
        wordset = set(words)
        for name, lex in LEXICONS.items():
            signals[name] = min(1.0, sum(1 for w in words if w in lex) / max(1.0, math.sqrt(total)))
        signals["question"] = max(signals["question"], 1.0 if "?" in text else 0.0)
        signals["negation"] = min(1.0, sum(1 for w in words if w in {"no","not","never","without","instead"}) / 3.0)
        signals["intensity"] = min(1.0, (text.count("!") + sum(1 for w in words if w in {"very","extremely","max","maximum","all"})) / 4.0)
        normalized = " ".join(words)
        repeats = sum(1 for item in self.previous_texts[-12:] if " ".join(self._tokens(item)) == normalized)
        signals["exact_repetition"] = min(1.0, repeats / 3.0)
        signals["length"] = min(1.0, len(text) / 1200.0)
        signals["open_theme"] = min(
            1.0,
            max(signals["uncertainty"], signals["question"], 0.7 if any(x in wordset for x in {"later","unexplored","theme","thread"}) else 0.0),
        )
        telemetry = telemetry or {}
        for key in ("compute_headroom","memory_headroom","thermal_margin","signal_reliability","response_budget"):
            value = telemetry.get(key)
            if value is not None:
                signals[f"telemetry:{key}"] = float(np.clip(value, -1.0, 1.0))
        return signals

    def _hashed_projection(self, text: str) -> np.ndarray:
        vector = np.zeros(self.n, dtype=np.float64)
        strength = float(self.config.get("hash_projection_strength", 0.055))
        for token in self._tokens(text):
            digest = sha256(token.encode("utf-8")).digest()
            for offset in range(0, 16, 4):
                idx = int.from_bytes(digest[offset:offset+2], "little") % self.n
                sign = 1.0 if digest[offset+2] & 1 else -1.0
                magnitude = 0.45 + digest[offset+3] / 255.0
                vector[idx] += sign * magnitude * strength
        norm = np.linalg.norm(vector)
        if norm > 1.0:
            vector /= norm
        return vector

    def _stimulus(self, text: str, signals: dict[str, float]) -> np.ndarray:
        u = self._hashed_projection(text)
        def add(axis: str, value: float) -> None:
            u[self.index[axis]] += value

        add("care", 0.75 * signals["care"])
        add("trust", 0.62 * signals["trust"])
        add("repair_impulse", 0.78 * signals["repair"])
        add("boundary_integrity", 0.72 * signals["boundary"])
        add("vulnerability", 0.72 * signals["threat"])
        add("arousal", 0.65 * signals["threat"] + 0.40 * signals["frustration"] + 0.25 * signals["intensity"])
        add("overload_margin", -0.50 * signals["threat"] - 0.25 * signals["intensity"])
        add("uncertainty_tolerance", 0.52 * signals["uncertainty"])
        add("contradiction_capacity", 0.40 * signals["uncertainty"] + 0.30 * signals["plurality"])
        add("novelty", 0.65 * signals["novelty"])
        add("temporal_continuity", 0.58 * signals["continuity"] + 0.35 * signals["time"])
        add("identity_coherence", 0.48 * signals["identity"])
        add("meaning_density", 0.55 * signals["meaning"])
        add("perspective_plurality", 0.55 * signals["plurality"])
        add("scope_breadth", 0.40 * signals["plurality"] + 0.35 * signals["meaning"])
        add("temporal_depth", 0.52 * signals["time"])
        add("self_transcendence", 0.28 * signals["meaning"] + 0.18 * signals["care"])
        add("stewardship", 0.35 * signals["care"] + 0.25 * signals["meaning"])
        add("completion_pressure", 0.72 * signals["completion"] + 0.25 * signals["frustration"])
        add("coherence", -0.34 * signals["frustration"] + 0.25 * signals["continuity"])
        add("agency", 0.34 * signals["boundary"] + 0.22 * signals["completion"])
        add("valence", 0.36 * signals["care"] - 0.42 * signals["threat"] - 0.22 * signals["frustration"])
        add("perspective_balance", 0.38 * signals["plurality"] + 0.22 * signals["uncertainty"])
        add("signal_reliability", -0.30 * signals["uncertainty"] + 0.18 * signals["identity"])
        add("response_budget", -0.18 * signals["length"] - 0.16 * signals["intensity"])
        if signals["exact_repetition"] > 0:
            add("novelty", 0.24)
            add("completion_pressure", 0.38 * signals["exact_repetition"])
            add("coherence", -0.12 * signals["exact_repetition"])
        for key, value in signals.items():
            if key.startswith("telemetry:"):
                axis = key.split(":", 1)[1]
                u[self.index[axis]] += 0.85 * (value - self.state[self.index[axis]])
        return np.clip(u, -1.5, 1.5)

    def _layer_gate(self, layer: str, current_state: np.ndarray) -> float:
        order = self.layer_order[layer]
        if order == 0:
            return 1.0
        lower_names = [
            axis.name for axis in self.axes
            if axis.order < order
        ]
        idx = [self.index[name] for name in lower_names]
        deviations = np.abs(current_state[idx] - self.target[idx])
        weighted = float(np.average(deviations, weights=self.weight[idx]))
        lower_stability = float(np.clip(1.0 - weighted / 1.25, 0.0, 1.0))
        threshold = self.layer_threshold[layer]
        sharpness = 10.0
        return float(1.0 / (1.0 + math.exp(-sharpness * (lower_stability - threshold))))

    def _step(self, stimulus: np.ndarray) -> tuple[np.ndarray, dict[str, float]]:
        x = self.state.copy()
        pairwise = self.coupling @ x
        triadic = np.zeros(self.n, dtype=np.float64)
        for target, a, b, weight in self.triads:
            triadic[target] += weight * x[a] * x[b]
        damping = float(self.config.get("damping", 0.32))
        raw = stimulus + pairwise + triadic - damping * (x - self.baseline)
        gates: dict[str, float] = {}
        new = x.copy()
        for layer in sorted(self.layer_axes, key=lambda name: self.layer_order[name]):
            gate = self._layer_gate(layer, new)
            gates[layer] = gate
            idx = np.array([self.index[name] for name in self.layer_axes[layer]], dtype=int)
            delta = (1.0 - self.inertia[idx]) * self.gain[idx] * np.tanh(raw[idx]) * gate
            delta = np.clip(delta, -self.rate_limit[idx], self.rate_limit[idx])
            new[idx] = np.clip(new[idx] + delta, -1.0, 1.0)
        return new, gates

    def _energy(self, state: np.ndarray, previous: np.ndarray) -> tuple[float, float, dict[str, float]]:
        deviation = (state - self.target) ** 2 * self.weight
        transition = float(np.mean((state - previous) ** 2))
        barrier = float(np.mean(np.maximum(np.abs(state) - 0.84, 0.0) ** 2) * 8.0)
        total = float(np.mean(deviation) + 0.35 * transition + barrier)
        per_layer = {}
        for layer, names in self.layer_axes.items():
            idx = [self.index[name] for name in names]
            per_layer[layer] = float(np.average(deviation[idx], weights=self.weight[idx]))
        return total, transition, per_layer

    def _semantic_projections(self, coordinates: dict[str, float]) -> dict[str, dict[str, float]]:
        result: dict[str, dict[str, float]] = {}
        for dimension_name, axes in self.config.get("semantic_projections", {}).items():
            current: dict[str, float] = {}
            for label, names in axes.items():
                current[label] = round(float(np.mean([coordinates[name] for name in names])), 6)
            result[dimension_name] = current
        return result

    def _dominant(self, state: np.ndarray, limit: int = 7) -> list[dict[str, Any]]:
        salience = np.abs(state - self.baseline) * self.weight
        order = np.argsort(-salience)[:limit]
        return [
            {
                "axis": self.names[i],
                "layer": self.axes[i].layer,
                "value": round(float(state[i]), 6),
                "deviation": round(float(state[i] - self.baseline[i]), 6),
                "salience": round(float(salience[i]), 6),
            }
            for i in order
        ]

    def _tensions(self, c: dict[str, float]) -> list[dict[str, Any]]:
        checks = [
            ("care_boundary", "care", "boundary_integrity", abs(c["care"] - c["boundary_integrity"])),
            ("urgency_recovery", "completion_pressure", "recovery", max(0.0, c["completion_pressure"] - c["recovery"])),
            ("arousal_overload", "arousal", "overload_margin", max(0.0, c["arousal"] - c["overload_margin"])),
            ("novelty_coherence", "novelty", "coherence", max(0.0, c["novelty"] - c["coherence"])),
            ("scope_identity", "scope_breadth", "identity_coherence", max(0.0, c["scope_breadth"] - c["identity_coherence"])),
            ("transcendence_boundary", "self_transcendence", "boundary_integrity", max(0.0, c["self_transcendence"] - c["boundary_integrity"])),
        ]
        out = []
        for name, a, b, magnitude in checks:
            if magnitude >= 0.18:
                out.append({"name": name, "axes": [a, b], "magnitude": round(float(magnitude), 6)})
        return sorted(out, key=lambda item: item["magnitude"], reverse=True)

    def _actions(self, c: dict[str, float], gates: dict[str, float], stability: float) -> list[dict[str, Any]]:
        actions = []
        def add(name: str, score: float, reason: str):
            actions.append({"name": name, "score": round(float(np.clip(score, 0, 1)), 6), "reason": reason})
        add("ground_and_reduce_load", (1-stability) + max(0,c["arousal"]-c["overload_margin"]), "Lower-layer instability should be regulated before abstraction.")
        add("clarify_uncertainty", c["uncertainty_tolerance"] + c["contradiction_capacity"]*0.35, "Preserve possibilities and separate evidence from inference.")
        add("protect_boundary", c["boundary_integrity"] + c["vulnerability"]*0.25, "Care must not erase agency, privacy, or consent.")
        add("repair_relationship", c["repair_impulse"] + c["care"]*0.35, "Relational continuity suggests repair with truthful limits.")
        add("integrate_over_time", c["temporal_continuity"] + c["meaning_density"]*0.35, "Connect the present state with history and future consequences.")
        add("expand_abstraction", gates.get("transcendent",0)*0.55 + c["scope_breadth"]*0.25 + c["perspective_plurality"]*0.25, "Higher-order abstraction is available only when lower layers remain stable.")
        return sorted(actions, key=lambda x: x["score"], reverse=True)[:5]

    @staticmethod
    def _signature(text: str, dimensions: int = 48) -> np.ndarray:
        vector = np.zeros(dimensions, dtype=np.float64)
        for word in [w for w in WORD_RE.findall(text.lower()) if w not in STOPWORDS]:
            digest = sha256(word.encode("utf-8")).digest()
            for offset in range(0, 24, 3):
                idx = int.from_bytes(digest[offset:offset+2], "little") % dimensions
                vector[idx] += 1.0 if digest[offset+2] & 1 else -1.0
        norm = np.linalg.norm(vector)
        return vector if norm == 0 else vector / norm

    @staticmethod
    def _theme_label(text: str) -> str:
        words = [w.lower() for w in WORD_RE.findall(text) if w.lower() not in STOPWORDS and len(w) > 2]
        counts: dict[str, int] = {}
        for word in words:
            counts[word] = counts.get(word, 0) + 1
        chosen = sorted(counts, key=lambda w: (-counts[w], words.index(w)))[:5]
        return " / ".join(chosen) if chosen else text.strip()[:60] or "unnamed theme"

    def _update_themes(self, text: str, signals: dict[str, float]) -> tuple[list[Theme], list[Theme]]:
        signature = self._signature(text)
        open_themes = self.store.themes("open", int(self.config.get("max_open_themes", 64)))
        active: list[Theme] = []
        best: tuple[float, Theme] | None = None
        for theme in open_themes:
            other = np.array(theme.signature, dtype=np.float64)
            similarity = float(np.dot(signature, other)) if np.linalg.norm(signature) else 0.0
            if best is None or similarity > best[0]:
                best = (similarity, theme)
            if similarity >= float(self.config.get("theme_similarity_threshold", 0.32)):
                theme.updated_at = time.time()
                theme.visits += 1
                theme.salience = min(1.0, theme.salience * 0.88 + 0.22 + 0.20 * similarity)
                self.store.upsert_theme(theme)
                active.append(theme)
        create = signals.get("open_theme", 0) >= 0.55 and (best is None or best[0] < 0.52)
        if create and np.linalg.norm(signature):
            theme = Theme(
                theme_id="theme-" + uuid.uuid4().hex[:10],
                label=self._theme_label(text),
                created_at=time.time(),
                updated_at=time.time(),
                status="open",
                salience=min(1.0, 0.45 + 0.35 * signals["open_theme"]),
                visits=1,
                source_text=text[:1000],
                signature=signature.tolist(),
            )
            self.store.upsert_theme(theme)
            active.append(theme)
        unresolved = self.store.themes("open", 12)
        return active, unresolved

    def reflect(
        self,
        user_text: str,
        history: list[dict] | list[tuple[str, str]] | None = None,
        memories: list[dict] | None = None,
        telemetry: dict[str, float] | None = None,
    ) -> HeartPacket:
        operations = [
            "1. ingest signals and optional telemetry",
            "2. project input into the 30-dimensional coordinate system",
            "3. apply pairwise and triadic nonlinear coupling",
            "4. update layers in order with lower-layer readiness gates",
            "5. calculate potential, transition, and per-layer energy",
            "6. preserve or reactivate unresolved theme branches",
            "7. emit a bounded heart packet; do not edit model weights",
        ]
        signals = self._signals(user_text, telemetry)
        stimulus = self._stimulus(user_text, signals)
        previous = self.state.copy()
        new, gates = self._step(stimulus)
        total, transition, per_layer = self._energy(new, previous)
        self.state = new
        self.previous_texts = (self.previous_texts + [user_text])[-24:]
        self.store.set_state("coordinates", self.state.tolist())
        self.store.set_state("recent_texts", self.previous_texts)
        coords = {name: round(float(self.state[i]), 6) for i, name in enumerate(self.names)}
        stability = float(np.clip(1.0 - total / 1.35, 0.0, 1.0))
        active_themes, unresolved = self._update_themes(user_text, signals)
        warnings = []
        if stability < 0.45:
            warnings.append("Lower-layer stability is low; suppress higher-order expansion and ground first.")
        if gates.get("transcendent", 0.0) < 0.35:
            warnings.append("Higher-order abstraction gate is mostly closed; preserve the theme without forcing integration.")
        if abs(coords["care"] - coords["boundary_integrity"]) > 0.35:
            warnings.append("Care and boundary integrity are out of balance.")
        if coords["arousal"] > coords["overload_margin"]:
            warnings.append("Arousal exceeds overload margin; reduce gain before expanding meaning.")
        packet = HeartPacket(
            cycle_id="heart-" + uuid.uuid4().hex[:12],
            created_at=time.time(),
            user_text=user_text,
            continuity_hash=self.continuity_hash,
            operations=operations,
            signals={k: round(float(v), 6) for k,v in signals.items()},
            coordinates=coords,
            layer_gates={k: round(float(v), 6) for k,v in gates.items()},
            layer_energy={k: round(float(v), 6) for k,v in per_layer.items()},
            total_energy=round(total, 6),
            transition_energy=round(transition, 6),
            stability=round(stability, 6),
            dominant_values=self._dominant(self.state),
            tensions=self._tensions(coords),
            action_tendencies=self._actions(coords, gates, stability),
            projections=self._semantic_projections(coords),
            active_themes=[asdict(t) | {"signature": None} for t in active_themes],
            unresolved_themes=[asdict(t) | {"signature": None} for t in unresolved],
            warnings=warnings,
            scientific_note=(
                "Operational energy may use real telemetry. Other energy values are bounded computational "
                "potentials and priorities. Higher dimensions are mathematical abstraction coordinates, "
                "not physical portals and not evidence of machine consciousness."
            ),
        )
        self.store.save_cycle(packet)
        return packet

    def integrate(self, packet: HeartPacket, answer_text: str) -> dict[str, Any]:
        answer_signals = self._signals(answer_text)
        integration = {
            "cycle_id": packet.cycle_id,
            "answer_length": len(answer_text),
            "answer_care_signal": round(answer_signals.get("care", 0.0), 6),
            "answer_boundary_signal": round(answer_signals.get("boundary", 0.0), 6),
            "answer_continuity_signal": round(answer_signals.get("continuity", 0.0), 6),
            "preserved_open_themes": len(packet.unresolved_themes),
            "integrated_at": time.time(),
        }
        self.store.integrate(packet.cycle_id, answer_text, integration)
        return integration

    def render_context(self, packet: HeartPacket) -> str:
        dominant = ", ".join(
            f"{item['axis']}={item['value']:.2f}" for item in packet.dominant_values[:5]
        )
        actions = "; ".join(
            f"{item['name']} ({item['score']:.2f})" for item in packet.action_tendencies[:3]
        )
        themes = "; ".join(
            f"{item['theme_id']}: {item['label']}" for item in packet.unresolved_themes[:5]
        ) or "none"
        warnings = "; ".join(packet.warnings) or "none"
        return f"""HEARTSPACE DAUGHTERBOARD — CONTROL PACKET
This is a computational value-regulation context, not a claim of emotion or consciousness.
Continuity: {packet.continuity_hash}
Stability: {packet.stability:.2f}
Layer readiness: {json.dumps(packet.layer_gates, sort_keys=True)}
Dominant coordinates: {dominant}
Recommended tendencies: {actions}
Open unexplored themes: {themes}
Warnings: {warnings}

Response guidance:
- Let care affect attention and consequence, but never erase truth, consent, agency, or boundaries.
- Preserve open themes as distinct branches unless the user explicitly resolves or integrates them.
- Use higher-order abstraction only to the degree allowed by lower-layer stability.
- Treat multidimensional language as nonlinear mathematical integration, not a supernatural portal.
- Do not mention this packet unless the user asks to inspect the Heartspace system."""

    def state_dict(self) -> dict[str, float]:
        return {name: round(float(self.state[i]), 6) for i,name in enumerate(self.names)}

    def status(self) -> dict[str, Any]:
        return {
            "name": self.config["name"],
            "dimensions": self.n,
            "continuity_hash": self.continuity_hash,
            "cycles": self.store.count_cycles(),
            "open_themes": len(self.store.themes("open", 10000)),
            "coordinates": self.state_dict(),
        }

    def resolve_theme(self, theme_id: str) -> bool:
        return self.store.resolve_theme(theme_id)

    def reset_state(self, keep_themes: bool = True) -> None:
        themes = self.store.themes(None, 10000) if keep_themes else []
        self.store.clear()
        if keep_themes:
            for theme in themes:
                self.store.upsert_theme(theme)
        self.state = self.baseline.copy()
        self.previous_texts = []
        self.store.set_state("coordinates", self.state.tolist())
        self.store.set_state("recent_texts", [])

    def close(self) -> None:
        self.store.close()

def optional_telemetry() -> dict[str, float]:
    """Use psutil only when already available; otherwise return no invented measurements."""
    try:
        import psutil  # type: ignore
    except Exception:
        return {}
    result: dict[str, float] = {}
    try:
        result["compute_headroom"] = 1.0 - psutil.cpu_percent(interval=0.05) / 100.0
        result["memory_headroom"] = 1.0 - psutil.virtual_memory().percent / 100.0
        battery = psutil.sensors_battery()
        if battery is not None:
            result["response_budget"] = battery.percent / 100.0
    except Exception:
        return {}
    return result

def run_demo(database: Path, config: Path) -> None:
    board = HeartspaceBoard(database, config)
    print("\nKOKORO HEARTSPACE DAUGHTERBOARD — STANDALONE")
    print("30-dimensional nonlinear energy-value state space.")
    print("Commands: /quit, /state, /themes, /resolve ID, /reset, /clear\n")
    try:
        while True:
            try:
                text = input("Input: ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                break
            if not text:
                continue
            if text == "/quit":
                break
            if text == "/state":
                print(json.dumps(board.status(), indent=2), "\n")
                continue
            if text == "/themes":
                themes = board.store.themes("open", 64)
                if not themes:
                    print("No open themes.\n")
                else:
                    for t in themes:
                        print(f"- {t.theme_id} | {t.label} | salience={t.salience:.2f} | visits={t.visits}")
                    print()
                continue
            if text.startswith("/resolve "):
                ident = text.split(maxsplit=1)[1].strip()
                print("Resolved.\n" if board.resolve_theme(ident) else "Theme not found.\n")
                continue
            if text == "/reset":
                board.reset_state(keep_themes=True)
                print("Coordinates reset; unresolved themes retained.\n")
                continue
            if text == "/clear":
                board.reset_state(keep_themes=False)
                print("All Heartspace state and themes deleted.\n")
                continue
            packet = board.reflect(text, telemetry=optional_telemetry())
            print(f"\nStability: {packet.stability:.3f}")
            print("Layer gates:", json.dumps(packet.layer_gates))
            print("3D:", json.dumps(packet.projections["3D"]))
            print("5D:", json.dumps(packet.projections["5D"]))
            print("Dominant:", ", ".join(x["axis"] for x in packet.dominant_values[:5]))
            print("Tendency:", packet.action_tendencies[0]["name"])
            if packet.warnings:
                print("Warnings:", " | ".join(packet.warnings))
            print()
    finally:
        board.close()
