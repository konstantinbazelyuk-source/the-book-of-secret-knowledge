#!/usr/bin/env python3
from pathlib import Path
import argparse, hashlib, json, shutil, time

p=argparse.ArgumentParser();p.add_argument("--base",required=True);a=p.parse_args()
base=Path(a.base).resolve()
candidates=[
 base/"checkpoints"/"dpo-latest.pt",
 base/"checkpoints"/"sft-latest.pt",
 base/"checkpoints"/"pretrain-best.pt",
 base/"checkpoints"/"pretrain-latest.pt",
]
source=next((x for x in candidates if x.exists()),None)
if source is None: raise SystemExit("No completed checkpoint found.")
destdir=base/"checkpoints-frozen";destdir.mkdir(exist_ok=True)
stamp=time.strftime("%Y%m%d-%H%M%S")
dest=destdir/f"pre-heart-{source.stem}-{stamp}.pt"
shutil.copy2(source,dest)
digest=hashlib.sha256(dest.read_bytes()).hexdigest()
(dest.with_suffix(dest.suffix+".sha256")).write_text(f"{digest}  {dest.name}\n")
print(f"Frozen checkpoint: {dest}")
print(f"SHA-256: {digest}")
