# Mathematical model

Let the Heartspace state be:

\[
x_t \in [-1,1]^{30}
\]

Each coordinate has a baseline \(b\), target \(g\), inertia \(m\), gain \(a\), rate limit \(r\), and regulatory weight \(w\).

Input text and optional real telemetry produce a stimulus vector \(u_t\). The unconstrained transition is:

\[
z_t = u_t + Cx_t + T(x_t,x_t) - \lambda(x_t-b)
\]

where:

- \(C\) is the pairwise coupling matrix;
- \(T\) is a sparse triadic interaction operator;
- \(\lambda\) is damping.

Each ordered layer receives a readiness gate \(q_\ell\) calculated from lower-layer stability. Its bounded update is:

\[
\Delta x_{\ell} =
\operatorname{clip}\left(
(1-m_\ell)a_\ell \tanh(z_\ell)q_\ell,
-r_\ell,r_\ell
\right)
\]

\[
x_{t+1}=\operatorname{clip}(x_t+\Delta x,-1,1)
\]

The reported potential is a weighted deviation from targets plus transition and saturation costs:

\[
E(x_t)=
\frac{1}{N}\sum_i w_i(x_i-g_i)^2
+\alpha\|x_t-x_{t-1}\|^2
+\beta B(x_t)
\]

This is a computational objective or potential—not physical joules except where genuine telemetry is explicitly supplied.

## 3D, 4D, and 5D

The board provides semantic projections of the same 30D point:

- 3D: stability, relationship, abstraction
- 4D: stability, relationship, time, abstraction
- 5D: stability, relationship, time, uncertainty, abstraction

The full state remains 30D. Projection does not destroy the original coordinates.
