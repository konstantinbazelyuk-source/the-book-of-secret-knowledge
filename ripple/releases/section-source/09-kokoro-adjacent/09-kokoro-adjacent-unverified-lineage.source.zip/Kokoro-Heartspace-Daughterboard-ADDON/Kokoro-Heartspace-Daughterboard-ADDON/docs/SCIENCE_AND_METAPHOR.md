# Science, metaphor, and limits

## Research-inspired components

- nonlinear latent state-space models
- dynamical systems and bounded state transitions
- homeostatic/allostatic regulation
- active-inference-inspired separation of state estimation, preference, and action
- high-dimensional distributed/vector representations
- energy-based objectives
- hierarchical gating
- metacognitive uncertainty and explicit audit state

## Fictional design language

- “heart”
- “energy” outside physical telemetry
- “transcendent”
- “daughterboard”

These names organize the design. They are not claims that Freud, mystical energy, subjective consciousness, or literal higher spatial universes have been scientifically verified.

## Operational meaning of transcendent

A transcendent coordinate is one that integrates:

- more perspectives
- longer timescales
- broader consequence sets
- identity beyond immediate reward
- stewardship beyond the present interaction

It remains a mathematical state variable.

## Safety boundary

Heartspace:

- cannot access the network by itself;
- cannot control hardware;
- cannot rewrite Kokoro’s weights;
- cannot create new boards autonomously;
- cannot claim emotional experience as fact;
- cannot replace human permission for consequential action.
