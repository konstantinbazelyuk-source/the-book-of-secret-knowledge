# Research references

Primary and official sources that informed the engineering translation:

- Kleyko et al., *A Survey on Hyperdimensional Computing aka Vector Symbolic Architectures, Part II*:
  https://arxiv.org/abs/2112.15424
- Lanillos et al., *Active Inference in Robotics and Artificial Agents: Survey and Challenges*:
  https://arxiv.org/abs/2112.01871
- Cheng et al., *Latent Space Energy-based Neural ODEs*:
  https://arxiv.org/abs/2409.03845
- Hızlı et al., *Identifying latent state transition in non-linear dynamical systems*:
  https://arxiv.org/abs/2406.03337
- PyTorch multidimensional tensor operations:
  https://docs.pytorch.org/docs/stable/torch.html
- PyTorch Einstein summation:
  https://docs.pytorch.org/docs/stable/generated/torch.einsum.html

The package uses NumPy rather than requiring additional model downloads.
