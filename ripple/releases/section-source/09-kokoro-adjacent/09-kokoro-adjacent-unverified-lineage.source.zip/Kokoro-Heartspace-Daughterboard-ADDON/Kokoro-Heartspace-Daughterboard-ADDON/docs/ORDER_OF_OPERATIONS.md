# Order of operations

1. Read user input and optional telemetry.
2. Extract inspectable lexical and structural signals.
3. Add a small deterministic hashed projection so unfamiliar language still reaches the field.
4. Project signals into the 30 named coordinates.
5. Apply pairwise coupling.
6. Apply sparse triadic coupling.
7. Update operational coordinates.
8. Calculate readiness for the next layer.
9. Continue layer by layer through higher-order abstraction.
10. Enforce saturation and coordinate-specific rate limits.
11. Calculate potential, transition energy, stability, tensions, and tendencies.
12. Preserve or reactivate unresolved theme branches.
13. Emit a HeartPacket.
14. Temporarily provide the packet to Kokoro as context.
15. Restore Kokoro’s original system prompt.
16. Store the consequence in the separate Heartspace database.

No step edits the language model checkpoint.
