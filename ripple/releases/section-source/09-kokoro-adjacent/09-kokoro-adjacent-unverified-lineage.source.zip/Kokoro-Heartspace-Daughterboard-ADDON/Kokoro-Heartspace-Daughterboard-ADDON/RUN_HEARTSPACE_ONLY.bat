@echo off
setlocal
cd /d "%~dp0"
title Kokoro Heartspace Daughterboard
set "BASE=%~dp0..\.."
if exist "%BASE%\.venv\Scripts\python.exe" (
 "%BASE%\.venv\Scripts\python.exe" bonded_heart_chat.py demo
) else (
 python bonded_heart_chat.py demo
)
pause
