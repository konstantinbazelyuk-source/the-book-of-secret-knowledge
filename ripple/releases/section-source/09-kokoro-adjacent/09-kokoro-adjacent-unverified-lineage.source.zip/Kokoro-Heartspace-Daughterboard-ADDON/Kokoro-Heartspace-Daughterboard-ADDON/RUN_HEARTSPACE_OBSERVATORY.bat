@echo off
setlocal
cd /d "%~dp0"
title Kokoro Heartspace Observatory
set "BASE=%~dp0..\.."
if exist "%BASE%\.venv\Scripts\python.exe" (
 "%BASE%\.venv\Scripts\python.exe" heartspace_server.py
) else (
 python heartspace_server.py
)
pause
