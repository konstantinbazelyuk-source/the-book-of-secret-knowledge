#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ADDON = Path(__file__).resolve().parent
STATE = ADDON / "state"
CONFIG = ADDON / "heartspace_config.json"
STATE.mkdir(exist_ok=True)

def valid_base(path: Path) -> bool:
    return (path / "kokoro.py").is_file() and (path / "kokoro_core" / "generation.py").is_file()

def discover_base(explicit: str | None = None) -> Path:
    candidates = []
    if explicit:
        candidates.append(Path(explicit).expanduser().resolve())
    if len(ADDON.parents) >= 2:
        candidates.append(ADDON.parents[1])
    candidates += [
        ADDON.parent / "Kokoro-del-Corazon-Foundry",
        ADDON.parent.parent / "Kokoro-del-Corazon-Foundry",
        Path.cwd(),
    ]
    for candidate in candidates:
        candidate = candidate.resolve()
        if valid_base(candidate):
            return candidate
    raise FileNotFoundError(
        "Original Kokoro Foundry was not found. Use --base C:\\Kokoro-del-Corazon-Foundry"
    )

def load_base(base: Path):
    sys.path.insert(0, str(base))
    import kokoro as base_cli
    from kokoro_core.generation import KokoroEngine
    return base_cli, KokoroEngine

def load_heart():
    sys.path.insert(0, str(ADDON))
    from heartspace_board import HeartspaceBoard, optional_telemetry
    return HeartspaceBoard, optional_telemetry

class HeartBondedKokoro:
    def __init__(self, base: Path, checkpoint: str | None, device: str = "auto"):
        base_cli, KokoroEngine = load_base(base)
        p = base_cli.paths()
        ckpt = base_cli.find_checkpoint(checkpoint)
        self.engine = KokoroEngine(ckpt, p["tokenizer"], p["memory"], device_arg=device)
        HeartspaceBoard, optional_telemetry = load_heart()
        self.optional_telemetry = optional_telemetry
        self.heart = HeartspaceBoard(STATE / "heartspace.sqlite3", CONFIG, "Kokoro del AI")
        self.original_system_prompt = self.engine.system_prompt
        self.enabled = True
        self.last_packet = None
        self.last_integration = None

    def generate(self, text: str, **kwargs):
        packet = None
        if self.enabled:
            packet = self.heart.reflect(
                text,
                history=list(self.engine.history),
                memories=self.engine.memory.search(text, limit=6),
                telemetry=self.optional_telemetry(),
            )
            self.engine.system_prompt = self.original_system_prompt + "\n\n" + self.heart.render_context(packet)
        else:
            self.engine.system_prompt = self.original_system_prompt
        try:
            answer = self.engine.generate(text, **kwargs)
        finally:
            self.engine.system_prompt = self.original_system_prompt
        if packet is not None:
            self.last_packet = packet
            self.last_integration = self.heart.integrate(packet, answer)
        return answer

    def close(self):
        self.engine.close()
        self.heart.close()

def print_heart(app: HeartBondedKokoro):
    packet = app.last_packet
    if packet is None:
        print("No Heartspace cycle has run.\n")
        return
    print("\nHEARTSPACE LAST CYCLE")
    print(f"Stability: {packet.stability:.3f}")
    print(f"Total potential: {packet.total_energy:.4f}")
    print("Gates:", packet.layer_gates)
    print("3D:", packet.projections.get("3D"))
    print("5D:", packet.projections.get("5D"))
    print("Dominant:", ", ".join(x["axis"] for x in packet.dominant_values[:6]))
    print("Open themes:", ", ".join(x["theme_id"] for x in packet.unresolved_themes[:8]) or "none")
    if packet.warnings:
        print("Warnings:", " | ".join(packet.warnings))
    print()

def chat(args):
    base = discover_base(args.base)
    app = HeartBondedKokoro(base, args.checkpoint, args.device)
    print("\nKOKORO DEL AI — HEARTSPACE BONDED MODE")
    print(f"Original brain: {base}")
    print(f"Heartspace: {ADDON}")
    print("Original source and weights are not modified.")
    print("Commands: /quit, /heart, /axes, /themes, /resolve ID, /heart on, /heart off, /reset, /forget-heart, /forget-all\n")
    try:
        while True:
            try:
                text = input("You: ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                break
            if not text:
                continue
            if text == "/quit":
                break
            if text == "/heart":
                print_heart(app); continue
            if text == "/axes":
                print(app.heart.status(), "\n"); continue
            if text == "/themes":
                themes = app.heart.store.themes("open", 64)
                for t in themes:
                    print(f"- {t.theme_id} | {t.label} | {t.salience:.2f}")
                print(); continue
            if text.startswith("/resolve "):
                print("Resolved.\n" if app.heart.resolve_theme(text.split(maxsplit=1)[1]) else "Not found.\n"); continue
            if text == "/heart on":
                app.enabled = True; print("Heartspace attached.\n"); continue
            if text == "/heart off":
                app.enabled = False; print("Heartspace bypassed; original Kokoro runs alone.\n"); continue
            if text == "/reset":
                app.engine.reset_context()
                app.heart.reset_state(keep_themes=True)
                print("Current context and coordinates reset; long-term memories and open themes retained.\n"); continue
            if text == "/forget-heart":
                app.heart.reset_state(keep_themes=False)
                print("Heartspace state and themes deleted; original Kokoro memory retained.\n"); continue
            if text == "/forget-all":
                app.engine.forget_all()
                app.heart.reset_state(keep_themes=False)
                print("Original conversation memory and Heartspace state deleted.\n"); continue
            print("Kokoro: ", end="", flush=True)
            def stream(piece):
                print(piece, end="", flush=True)
            app.generate(
                text,
                max_new_tokens=args.max_new_tokens,
                temperature=args.temperature,
                top_k=args.top_k,
                top_p=args.top_p,
                stream_callback=stream,
            )
            print("\n")
    finally:
        app.close()

def demo(args):
    from heartspace_board import run_demo
    run_demo(STATE / "heartspace.sqlite3", CONFIG)

def parser():
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="command", required=True)
    c = sub.add_parser("chat")
    c.add_argument("--base")
    c.add_argument("--checkpoint")
    c.add_argument("--device", default="auto")
    c.add_argument("--temperature", type=float, default=0.8)
    c.add_argument("--top-k", type=int, default=50)
    c.add_argument("--top-p", type=float, default=0.95)
    c.add_argument("--max-new-tokens", type=int, default=256)
    c.set_defaults(func=chat)
    d = sub.add_parser("demo")
    d.set_defaults(func=demo)
    return p

if __name__ == "__main__":
    args = parser().parse_args()
    try:
        args.func(args)
    except FileNotFoundError as exc:
        print(f"\nERROR: {exc}\n")
        raise SystemExit(1)
