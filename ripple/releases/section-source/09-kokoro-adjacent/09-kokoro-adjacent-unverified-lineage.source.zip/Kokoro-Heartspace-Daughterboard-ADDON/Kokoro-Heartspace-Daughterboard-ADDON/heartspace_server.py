#!/usr/bin/env python3
from __future__ import annotations
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse
import json, sys, webbrowser

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from heartspace_board import HeartspaceBoard, optional_telemetry

BOARD = HeartspaceBoard(ROOT/"state"/"heartspace.sqlite3", ROOT/"heartspace_config.json")
WEB = ROOT/"web"

class Handler(SimpleHTTPRequestHandler):
    def translate_path(self, path):
        clean = urlparse(path).path.lstrip("/") or "index.html"
        return str(WEB / clean)
    def _json(self, payload, code=200):
        body=json.dumps(payload,ensure_ascii=False).encode("utf-8")
        self.send_response(code); self.send_header("Content-Type","application/json; charset=utf-8")
        self.send_header("Content-Length",str(len(body))); self.end_headers(); self.wfile.write(body)
    def do_GET(self):
        route=urlparse(self.path).path
        if route=="/api/state":
            return self._json(BOARD.status())
        if route=="/api/themes":
            return self._json([{
                "theme_id":t.theme_id,"label":t.label,"salience":t.salience,"visits":t.visits,"status":t.status
            } for t in BOARD.store.themes(None,64)])
        return super().do_GET()
    def do_POST(self):
        route=urlparse(self.path).path
        length=int(self.headers.get("Content-Length","0"))
        try: payload=json.loads(self.rfile.read(length) or b"{}")
        except Exception: return self._json({"error":"invalid json"},400)
        if route=="/api/reflect":
            text=str(payload.get("text","")).strip()
            if not text: return self._json({"error":"text required"},400)
            packet=BOARD.reflect(text,telemetry=optional_telemetry())
            return self._json(packet.to_dict())
        if route=="/api/resolve":
            return self._json({"resolved":BOARD.resolve_theme(str(payload.get("theme_id","")))})
        return self._json({"error":"not found"},404)
    def log_message(self, format, *args):
        pass

if __name__=="__main__":
    host,port="127.0.0.1",8776
    server=ThreadingHTTPServer((host,port),Handler)
    url=f"http://{host}:{port}"
    print(f"Heartspace Observatory: {url}")
    print("Close with Ctrl+C.")
    webbrowser.open(url)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally:
        BOARD.close(); server.server_close()
