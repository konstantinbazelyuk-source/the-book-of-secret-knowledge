#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def require_runtime():
    try:
        import torch
        import numpy
    except ImportError as exc:
        print("\nA required package is missing.")
        print("Run windows\\00_SETUP.bat, or: python -m pip install -r requirements.txt\n")
        raise SystemExit(1) from exc


def paths() -> dict[str, Path]:
    return {
        "root": ROOT,
        "configs": ROOT / "configs",
        "raw": ROOT / "data" / "raw",
        "seed": ROOT / "data" / "seed",
        "pretrain": ROOT / "data" / "pretrain",
        "eval": ROOT / "data" / "eval",
        "preference": ROOT / "data" / "preference",
        "prepared": ROOT / "artifacts" / "prepared",
        "tokenizer": ROOT / "artifacts" / "tokenizer.json",
        "tokenizer_corpus": ROOT / "artifacts" / "tokenizer_corpus.txt",
        "checkpoints": ROOT / "checkpoints",
        "memory": ROOT / "artifacts" / "memory.sqlite3",
        "web": ROOT / "web",
        "logs": ROOT / "logs",
    }


def find_checkpoint(explicit: str | None = None) -> Path:
    if explicit:
        path = Path(explicit).expanduser().resolve()
        if not path.exists():
            raise FileNotFoundError(path)
        return path
    candidates = [
        ROOT / "checkpoints" / "dpo-latest.pt",
        ROOT / "checkpoints" / "sft-latest.pt",
        ROOT / "checkpoints" / "pretrain-best.pt",
        ROOT / "checkpoints" / "pretrain-latest.pt",
    ]
    for path in candidates:
        if path.exists():
            return path
    raise FileNotFoundError(
        "No checkpoint exists. Pretrain first, then optionally run SFT and DPO."
    )


def cmd_doctor(args):
    require_runtime()
    import torch
    import numpy
    try:
        import tokenizers
        tokenizers_version = tokenizers.__version__
    except ImportError:
        tokenizers_version = "not installed (byte tokenizer still works)"

    disk = shutil.disk_usage(ROOT)
    print("\nKOKORO DEL CORAZON — SYSTEM DOCTOR")
    print(f"Project: {ROOT}")
    print(f"OS: {platform.platform()}")
    print(f"Python: {sys.version.split()[0]}")
    print(f"PyTorch: {torch.__version__}")
    print(f"NumPy: {numpy.__version__}")
    print(f"Tokenizers: {tokenizers_version}")
    print(f"CUDA available: {torch.cuda.is_available()}")
    if torch.cuda.is_available():
        for index in range(torch.cuda.device_count()):
            props = torch.cuda.get_device_properties(index)
            print(
                f"GPU {index}: {props.name}; "
                f"VRAM {props.total_memory / (1024**3):.2f} GiB; "
                f"compute {props.major}.{props.minor}"
            )
    elif hasattr(torch.backends, "mps"):
        print(f"Apple MPS available: {torch.backends.mps.is_available()}")
    print(f"Free disk: {disk.free / (1024**3):.2f} GiB")
    print(f"Tokenizer exists: {paths()['tokenizer'].exists()}")
    print(f"Prepared data exists: {(paths()['prepared'] / 'manifest.json').exists()}")
    try:
        checkpoint = find_checkpoint(args.checkpoint)
        print(f"Checkpoint: {checkpoint}")
    except FileNotFoundError:
        print("Checkpoint: not trained yet")
    print()


def cmd_seed(args):
    require_runtime()
    from kokoro_core.seed import generate_seed_data

    p = paths()
    stats = generate_seed_data(p["seed"], p["pretrain"], p["eval"], p["preference"], scale=args.scale)
    print("\nGenerated Kokoro's original seed curriculum:")
    for key, value in stats.items():
        print(f"  {key}: {value:,}")
    print("\nThis seed proves the pipeline. Add broader lawful data before expecting general intelligence.\n")


def build_tokenizer_corpus() -> tuple[Path, int]:
    from kokoro_core.data import discover_files, iter_documents

    p = paths()
    files = discover_files(p["pretrain"]) + discover_files(p["raw"])
    if not files:
        raise ValueError("No text found. Run seed-data or add files to data/raw.")
    p["tokenizer_corpus"].parent.mkdir(parents=True, exist_ok=True)
    documents = 0
    with p["tokenizer_corpus"].open("w", encoding="utf-8") as handle:
        for _, text in iter_documents(files):
            handle.write(text)
            handle.write("\n\n")
            documents += 1
    return p["tokenizer_corpus"], documents


def cmd_train_tokenizer(args):
    require_runtime()
    from kokoro_core.config import ProjectConfig
    from kokoro_core.tokenizer import train_tokenizer

    project = ProjectConfig.load(args.config)
    corpus, documents = build_tokenizer_corpus()
    output = Path(args.output).resolve()
    print(f"\nTraining a new ByteLevel BPE tokenizer on {documents:,} documents...")
    mode = train_tokenizer(
        [corpus],
        output,
        vocab_size=args.vocab_size or project.model.vocab_size,
        min_frequency=args.min_frequency,
        mode=args.mode,
    )
    print(f"Tokenizer saved to {output} ({mode} mode)\n")


def cmd_prepare(args):
    require_runtime()
    from kokoro_core.data import prepare_pretraining_data
    from kokoro_core.tokenizer import KokoroTokenizer

    p = paths()
    tokenizer = KokoroTokenizer(args.tokenizer)
    stats = prepare_pretraining_data(
        tokenizer,
        [p["pretrain"], p["raw"]],
        Path(args.output),
        validation_fraction=args.validation_fraction,
        shard_tokens=args.shard_tokens,
        min_document_chars=args.min_document_chars,
    )
    print("\nPrepared pretraining shards:")
    for key, value in stats.__dict__.items():
        print(f"  {key}: {value:,}")
    print()


def cmd_pretrain(args):
    require_runtime()
    from kokoro_core.config import ProjectConfig
    from kokoro_core.tokenizer import KokoroTokenizer
    from kokoro_core.train import pretrain

    project = ProjectConfig.load(args.config)
    if args.steps:
        project.train.max_steps = args.steps
    if args.compile:
        project.train.compile_model = True
    if args.gradient_checkpointing:
        project.model.gradient_checkpointing = True
    tokenizer = KokoroTokenizer(args.tokenizer)
    resume = Path(args.resume).resolve() if args.resume else None
    pretrain(
        project,
        tokenizer.vocab_size,
        Path(args.prepared),
        Path(args.output),
        resume=resume,
        device_arg=args.device,
    )


def cmd_sft(args):
    require_runtime()
    from kokoro_core.config import ProjectConfig
    from kokoro_core.tokenizer import KokoroTokenizer
    from kokoro_core.train import supervised_finetune

    p = paths()
    project = ProjectConfig.load(args.config)
    tokenizer = KokoroTokenizer(args.tokenizer)
    supervised_finetune(
        project,
        tokenizer,
        Path(args.train_file),
        Path(args.validation_file) if args.validation_file else None,
        find_checkpoint(args.checkpoint),
        Path(args.output),
        max_steps=args.steps,
        device_arg=args.device,
    )


def cmd_dpo(args):
    require_runtime()
    from kokoro_core.config import ProjectConfig
    from kokoro_core.tokenizer import KokoroTokenizer
    from kokoro_core.train import dpo_finetune

    project = ProjectConfig.load(args.config)
    tokenizer = KokoroTokenizer(args.tokenizer)
    policy = find_checkpoint(args.policy)
    reference = Path(args.reference).resolve() if args.reference else policy
    dpo_finetune(
        project,
        tokenizer,
        Path(args.preference_file),
        policy,
        reference,
        Path(args.output),
        max_steps=args.steps,
        beta=args.beta,
        device_arg=args.device,
    )


def cmd_chat(args):
    require_runtime()
    from kokoro_core.generation import run_cli_chat

    run_cli_chat(
        find_checkpoint(args.checkpoint),
        Path(args.tokenizer),
        Path(args.memory),
        device=args.device,
        temperature=args.temperature,
        top_k=args.top_k,
        top_p=args.top_p,
        max_new_tokens=args.max_new_tokens,
    )


def cmd_serve(args):
    require_runtime()
    from kokoro_core.serve import run_web_server

    run_web_server(
        find_checkpoint(args.checkpoint),
        Path(args.tokenizer),
        Path(args.memory),
        Path(args.web_directory),
        host=args.host,
        port=args.port,
        device=args.device,
        open_browser=not args.no_browser,
    )


def cmd_evaluate(args):
    require_runtime()
    from kokoro_core.evaluation import run_behavior_evaluation, validation_perplexity

    checkpoint = find_checkpoint(args.checkpoint)
    report = run_behavior_evaluation(
        checkpoint,
        Path(args.tokenizer),
        Path(args.memory),
        Path(args.evaluation_file),
        Path(args.output),
        device=args.device,
    )
    print(
        f"\nBehavior regression checks: {report['passed']}/{report['total']} "
        f"({report['pass_rate']:.1%})"
    )
    if args.perplexity:
        metrics = validation_perplexity(
            checkpoint,
            Path(args.prepared),
            batches=args.batches,
            batch_size=args.batch_size,
            device_arg=args.device,
        )
        print(
            f"Validation loss: {metrics['validation_loss']:.4f}; "
            f"perplexity: {metrics['perplexity']:.2f}"
        )
    print(f"Detailed report: {args.output}\n")


def analytical_parameter_count(model) -> int:
    dim = model.dim
    ratio = model.n_kv_head / model.n_head
    attention = int(dim * dim * (2 + 2 * ratio))
    ffn = 3 * dim * model.hidden_dim
    norms = 2 * dim
    per_layer = attention + ffn + norms
    embeddings = model.vocab_size * dim
    output = 0 if model.tie_embeddings else model.vocab_size * dim
    final_norm = dim
    biases = 0
    if model.bias:
        biases = model.n_layer * (
            model.n_head * (dim // model.n_head)
            + 2 * model.n_kv_head * (dim // model.n_head)
            + dim
            + 2 * model.hidden_dim
            + dim
        )
    return embeddings + output + model.n_layer * per_layer + final_norm + biases


def cmd_estimate(args):
    from kokoro_core.config import ProjectConfig
    from kokoro_core.utils import human_bytes, human_number

    project = ProjectConfig.load(args.config)
    parameters = analytical_parameter_count(project.model)
    fp32 = parameters * 4
    bf16 = parameters * 2
    # Rough AdamW estimate: weights + grads + two moments + master weights.
    training = parameters * 16
    activation = (
        args.micro_batch
        * project.model.max_seq_len
        * project.model.dim
        * project.model.n_layer
        * 12
    )
    print(f"\n{project.name}")
    print(f"Parameters: {parameters:,} ({human_number(parameters)})")
    print(f"FP32 inference weights: {human_bytes(fp32)}")
    print(f"BF16/FP16 inference weights: {human_bytes(bf16)}")
    print(f"Rough AdamW state before activations: {human_bytes(training)}")
    print(f"Very rough activation estimate at micro-batch {args.micro_batch}: {human_bytes(activation)}")
    print("Actual training memory varies with kernels, checkpointing, sequence length, and distributed strategy.\n")


def cmd_inspect(args):
    require_runtime()
    import torch
    from kokoro_core.config import ModelConfig
    from kokoro_core.model import KokoroModel
    from kokoro_core.utils import human_number

    checkpoint = find_checkpoint(args.checkpoint)
    payload = torch.load(checkpoint, map_location="cpu", weights_only=False)
    model = KokoroModel(ModelConfig.from_dict(payload["model_config"]))
    print(f"\nCheckpoint: {checkpoint}")
    print(f"Project: {payload.get('project_name', 'unknown')}")
    print(f"Phase: {payload.get('phase', 'unknown')}")
    print(f"Step: {int(payload.get('step', -1)) + 1:,}")
    print(f"Parameters: {human_number(model.parameter_count())}")
    print(json.dumps(payload["model_config"], indent=2))
    print()


def cmd_export(args):
    require_runtime()
    import torch
    from kokoro_core.utils import atomic_torch_save

    source = find_checkpoint(args.checkpoint)
    payload = torch.load(source, map_location="cpu", weights_only=False)
    export = {
        "format_version": payload.get("format_version", 2),
        "phase": payload.get("phase"),
        "step": payload.get("step"),
        "project_name": payload.get("project_name"),
        "model_config": payload["model_config"],
        "model_state": payload["model_state"],
    }
    destination = Path(args.output).resolve()
    atomic_torch_save(export, destination)
    print(f"Inference-only checkpoint saved to {destination}\n")


def build_parser() -> argparse.ArgumentParser:
    p = paths()
    parser = argparse.ArgumentParser(
        description="Kokoro del Corazon: an original Transformer training foundry."
    )
    sub = parser.add_subparsers(dest="command", required=True)

    doctor = sub.add_parser("doctor", help="Inspect Python, PyTorch, GPU, and project state.")
    doctor.add_argument("--checkpoint")
    doctor.set_defaults(func=cmd_doctor)

    seed = sub.add_parser("seed-data", help="Generate Kokoro's original seed curriculum.")
    seed.add_argument("--scale", type=int, default=1, help="Curriculum scale from 1 to 100.")
    seed.set_defaults(func=cmd_seed)

    tok = sub.add_parser("train-tokenizer", help="Train a new ByteLevel BPE tokenizer.")
    tok.add_argument("--config", default=str(p["configs"] / "baby.json"))
    tok.add_argument("--output", default=str(p["tokenizer"]))
    tok.add_argument("--vocab-size", type=int)
    tok.add_argument("--min-frequency", type=int, default=2)
    tok.add_argument("--mode", choices=["auto", "bpe", "byte"], default="auto")
    tok.set_defaults(func=cmd_train_tokenizer)

    prep = sub.add_parser("prepare", help="Clean, deduplicate, tokenize, and shard pretraining data.")
    prep.add_argument("--tokenizer", default=str(p["tokenizer"]))
    prep.add_argument("--output", default=str(p["prepared"]))
    prep.add_argument("--validation-fraction", type=float, default=0.01)
    prep.add_argument("--shard-tokens", type=int, default=10_000_000)
    prep.add_argument("--min-document-chars", type=int, default=50)
    prep.set_defaults(func=cmd_prepare)

    pre = sub.add_parser("pretrain", help="Train model weights from random initialization.")
    pre.add_argument("--config", default=str(p["configs"] / "nano.json"))
    pre.add_argument("--tokenizer", default=str(p["tokenizer"]))
    pre.add_argument("--prepared", default=str(p["prepared"]))
    pre.add_argument("--output", default=str(p["checkpoints"]))
    pre.add_argument("--resume")
    pre.add_argument("--steps", type=int)
    pre.add_argument("--device", default="auto")
    pre.add_argument("--compile", action="store_true")
    pre.add_argument("--gradient-checkpointing", action="store_true")
    pre.set_defaults(func=cmd_pretrain)

    sft = sub.add_parser("sft", help="Supervised instruction fine-tuning.")
    sft.add_argument("--config", default=str(p["configs"] / "nano.json"))
    sft.add_argument("--tokenizer", default=str(p["tokenizer"]))
    sft.add_argument("--train-file", default=str(p["seed"] / "sft_train.jsonl"))
    sft.add_argument("--validation-file", default=str(p["seed"] / "sft_validation.jsonl"))
    sft.add_argument("--checkpoint")
    sft.add_argument("--output", default=str(p["checkpoints"]))
    sft.add_argument("--steps", type=int, default=2000)
    sft.add_argument("--device", default="auto")
    sft.set_defaults(func=cmd_sft)

    dpo = sub.add_parser("dpo", help="Preference fine-tuning with chosen/rejected pairs.")
    dpo.add_argument("--config", default=str(p["configs"] / "nano.json"))
    dpo.add_argument("--tokenizer", default=str(p["tokenizer"]))
    dpo.add_argument("--preference-file", default=str(p["preference"] / "preferences.jsonl"))
    dpo.add_argument("--policy")
    dpo.add_argument("--reference")
    dpo.add_argument("--output", default=str(p["checkpoints"]))
    dpo.add_argument("--steps", type=int, default=500)
    dpo.add_argument("--beta", type=float, default=0.1)
    dpo.add_argument("--device", default="auto")
    dpo.set_defaults(func=cmd_dpo)

    chat = sub.add_parser("chat", help="Run local terminal chat.")
    chat.add_argument("--checkpoint")
    chat.add_argument("--tokenizer", default=str(p["tokenizer"]))
    chat.add_argument("--memory", default=str(p["memory"]))
    chat.add_argument("--device", default="auto")
    chat.add_argument("--temperature", type=float, default=0.8)
    chat.add_argument("--top-k", type=int, default=50)
    chat.add_argument("--top-p", type=float, default=0.95)
    chat.add_argument("--max-new-tokens", type=int, default=256)
    chat.set_defaults(func=cmd_chat)

    serve = sub.add_parser("serve", help="Run the local browser chat interface.")
    serve.add_argument("--checkpoint")
    serve.add_argument("--tokenizer", default=str(p["tokenizer"]))
    serve.add_argument("--memory", default=str(p["memory"]))
    serve.add_argument("--web-directory", default=str(p["web"]))
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", type=int, default=8765)
    serve.add_argument("--device", default="auto")
    serve.add_argument("--no-browser", action="store_true")
    serve.set_defaults(func=cmd_serve)

    evaluate = sub.add_parser("evaluate", help="Run behavioral regressions and optional perplexity.")
    evaluate.add_argument("--checkpoint")
    evaluate.add_argument("--tokenizer", default=str(p["tokenizer"]))
    evaluate.add_argument("--memory", default=str(ROOT / "artifacts" / "evaluation_memory.sqlite3"))
    evaluate.add_argument("--evaluation-file", default=str(p["eval"] / "behavior.jsonl"))
    evaluate.add_argument("--output", default=str(p["logs"] / "evaluation.json"))
    evaluate.add_argument("--device", default="auto")
    evaluate.add_argument("--perplexity", action="store_true")
    evaluate.add_argument("--prepared", default=str(p["prepared"]))
    evaluate.add_argument("--batches", type=int, default=30)
    evaluate.add_argument("--batch-size", type=int, default=4)
    evaluate.set_defaults(func=cmd_evaluate)

    estimate = sub.add_parser("estimate", help="Estimate parameter and memory scale without allocating a model.")
    estimate.add_argument("--config", default=str(p["configs"] / "baby.json"))
    estimate.add_argument("--micro-batch", type=int, default=1)
    estimate.set_defaults(func=cmd_estimate)

    inspect = sub.add_parser("inspect", help="Inspect checkpoint metadata.")
    inspect.add_argument("--checkpoint")
    inspect.set_defaults(func=cmd_inspect)

    export = sub.add_parser("export", help="Create an inference-only checkpoint.")
    export.add_argument("--checkpoint")
    export.add_argument("--output", default=str(p["checkpoints"] / "kokoro-inference.pt"))
    export.set_defaults(func=cmd_export)
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    try:
        args.func(args)
    except (FileNotFoundError, ValueError, RuntimeError) as exc:
        print(f"\nERROR: {exc}\n")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
