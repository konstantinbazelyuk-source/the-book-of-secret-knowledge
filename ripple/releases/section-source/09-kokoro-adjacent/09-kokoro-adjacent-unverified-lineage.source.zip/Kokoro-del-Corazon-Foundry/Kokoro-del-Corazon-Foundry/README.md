# Kokoro del Corazon Foundry

Kokoro del Corazon is a complete, local, from-random-initialization language-model project. It contains the code needed to create a tokenizer, clean and shard a corpus, initialize a modern decoder-only Transformer, pretrain its weights, instruction-tune it, preference-tune it, evaluate it, remember conversations locally, and serve a browser chat interface.

It does **not** download or hide a pretrained language model. PyTorch supplies tensor mathematics and GPU execution; the model weights begin as random numbers.

## Fastest Windows path

Extract the ZIP, open `windows`, and run:

1. `00_SETUP.bat`
2. `01_DIAGNOSE.bat`
3. `02_GENERATE_SEED_DATA.bat`
4. `03_TRAIN_TOKENIZER.bat`
5. `04_PREPARE_DATA.bat`
6. `05_PRETRAIN_NANO.bat`
7. `07_SUPERVISED_FINETUNE.bat`
8. `08_PREFERENCE_TRAINING.bat`
9. `09_CHAT_TERMINAL.bat` or `10_CHAT_BROWSER.bat`

The first six steps create a model from random initialization. The next two teach assistant behavior and preferences.

## One central command

Everything is controlled through:

```bash
python kokoro.py <command>
```

Main commands:

```bash
python kokoro.py doctor
python kokoro.py seed-data --scale 3
python kokoro.py train-tokenizer --mode auto
python kokoro.py prepare
python kokoro.py pretrain --config configs/nano.json
python kokoro.py sft --config configs/nano.json
python kokoro.py dpo --config configs/nano.json
python kokoro.py evaluate --perplexity
python kokoro.py chat
python kokoro.py serve
python kokoro.py estimate --config configs/baby.json
```

## What is included

- A dependency-free UTF-8 byte tokenizer fallback.
- Optional newly trained ByteLevel BPE tokenizer.
- Exact-document deduplication, Unicode cleaning, deterministic validation splitting, and memory-mapped binary token shards.
- Decoder-only Transformer with RMSNorm, RoPE, grouped-query attention, PyTorch scaled-dot-product attention, SwiGLU, tied embeddings, gradient checkpointing, mixed precision, gradient accumulation, AdamW, cosine decay, DDP, checkpoint resume, and evaluation.
- Supervised fine-tuning with assistant-only loss masking.
- Direct Preference Optimization using chosen/rejected examples.
- Local SQLite/FTS conversation memory.
- Terminal chat and a local browser interface.
- Original seed curriculum: a scalable original SFT curriculum, preference pairs, behavior checks, and a pretraining seed corpus.
- Scaling configurations from a 400K-parameter smoke test to a roughly 300M-parameter medium model.

## Data first

The included scale-3 curriculum contains roughly 8,800 unique SFT records and validates the pipeline while teaching some desired behavior. It is nowhere near enough for broad knowledge. Put legally usable files in `data/raw`, then retrain the tokenizer and prepare the dataset.

Supported input formats:

- `.txt` and `.md`
- `.jsonl` with `{"text":"..."}`
- `.jsonl` with `{"messages":[{"role":"user","content":"..."}, ...]}`
- `.json` containing the same structures

Read `docs/DATA_GUIDE.md` before collecting a large corpus.

## Configurations

- `smoke-test.json`: validates code only.
- `nano.json`: about 7M parameters with a 16K tokenizer.
- `baby.json`: about 42M parameters.
- `character-specialist.json`: about 70M parameters with longer context.
- `small.json`: about 126M parameters.
- `medium.json`: about 305M parameters.

Actual parameter count changes when tokenizer vocabulary size changes. Run `python kokoro.py estimate --config ...` before training.

## Honest boundary

A complete trainer is not the same as a fully educated model. Strong general intelligence requires a large, diverse, lawful corpus; substantial compute; repeated evaluation; and post-training. This repository gives you ownership of the architecture, data pipeline, tokenizer, weights, memory, evaluation, and deployment path. It does not fabricate trained knowledge that has not been learned.
