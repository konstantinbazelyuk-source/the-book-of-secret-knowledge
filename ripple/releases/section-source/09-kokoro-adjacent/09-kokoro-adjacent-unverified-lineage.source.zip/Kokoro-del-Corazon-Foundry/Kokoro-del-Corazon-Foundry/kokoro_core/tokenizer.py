from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

SPECIAL_TOKENS = [
    "<|pad|>",
    "<|bos|>",
    "<|eos|>",
    "<|system|>",
    "<|user|>",
    "<|assistant|>",
    "<|memory|>",
    "<|eot|>",
]
BYTE_SPECIAL_BASE = 256


@dataclass(frozen=True)
class TokenIds:
    pad: int
    bos: int
    eos: int
    system: int
    user: int
    assistant: int
    memory: int
    eot: int


class KokoroTokenizer:
    """Loads either Kokoro's dependency-free byte tokenizer or a trained BPE tokenizer."""

    def __init__(self, tokenizer_path: str | Path):
        self.path = Path(tokenizer_path)
        if not self.path.exists():
            raise FileNotFoundError(
                f"Tokenizer not found: {self.path}\n"
                "Run: python kokoro.py train-tokenizer"
            )
        self.mode = "bpe"
        self.backend = None
        try:
            payload = json.loads(self.path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError):
            payload = {}
        if payload.get("type") == "kokoro-byte-v1":
            self.mode = "byte"
            token_map = payload["special_tokens"]
            ids = [int(token_map[token]) for token in SPECIAL_TOKENS]
            self.ids = TokenIds(*ids)
            self._vocab_size = int(payload["vocab_size"])
        else:
            try:
                from tokenizers import Tokenizer
            except ImportError as exc:
                raise RuntimeError(
                    "This tokenizer is BPE and requires the 'tokenizers' package. "
                    "Run setup, or create a dependency-free tokenizer with: "
                    "python kokoro.py train-tokenizer --mode byte"
                ) from exc
            self.backend = Tokenizer.from_file(str(self.path))
            ids = [self.backend.token_to_id(token) for token in SPECIAL_TOKENS]
            if any(value is None for value in ids):
                raise ValueError("Tokenizer is missing one or more Kokoro special tokens")
            self.ids = TokenIds(*[int(value) for value in ids])
            self._vocab_size = int(self.backend.get_vocab_size())

    @property
    def vocab_size(self) -> int:
        return self._vocab_size

    def encode(self, text: str, add_bos: bool = False, add_eos: bool = False) -> list[int]:
        if self.mode == "byte":
            tokens = list(text.encode("utf-8", errors="replace"))
        else:
            tokens = self.backend.encode(text, add_special_tokens=False).ids
        if add_bos:
            tokens.insert(0, self.ids.bos)
        if add_eos:
            tokens.append(self.ids.eos)
        return tokens

    def decode(self, tokens: Iterable[int], skip_special_tokens: bool = True) -> str:
        values = list(map(int, tokens))
        if self.mode == "byte":
            byte_values = bytearray(value for value in values if 0 <= value <= 255)
            return byte_values.decode("utf-8", errors="replace")
        return self.backend.decode(values, skip_special_tokens=skip_special_tokens)

    def render_messages(
        self,
        messages: list[dict],
        add_generation_prompt: bool = False,
        include_eos: bool = True,
    ) -> list[int]:
        result = [self.ids.bos]
        role_to_token = {
            "system": self.ids.system,
            "user": self.ids.user,
            "assistant": self.ids.assistant,
            "memory": self.ids.memory,
        }
        for message in messages:
            role = str(message.get("role", "user")).lower()
            content = str(message.get("content", ""))
            result.append(role_to_token.get(role, self.ids.user))
            result.extend(self.encode(content))
            result.append(self.ids.eot)
        if add_generation_prompt:
            result.append(self.ids.assistant)
        elif include_eos:
            result.append(self.ids.eos)
        return result

    def render_sft(self, messages: list[dict], max_length: int) -> tuple[list[int], list[int]]:
        ids = [self.ids.bos]
        labels = [-100]
        role_to_token = {
            "system": self.ids.system,
            "user": self.ids.user,
            "assistant": self.ids.assistant,
            "memory": self.ids.memory,
        }
        for message in messages:
            role = str(message.get("role", "user")).lower()
            content = str(message.get("content", ""))
            role_id = role_to_token.get(role, self.ids.user)
            content_ids = self.encode(content)
            turn = [role_id, *content_ids, self.ids.eot]
            ids.extend(turn)
            if role == "assistant":
                labels.extend([-100, *content_ids, self.ids.eot])
            else:
                labels.extend([-100] * len(turn))
        ids.append(self.ids.eos)
        labels.append(self.ids.eos if messages and messages[-1].get("role") == "assistant" else -100)
        if len(ids) > max_length:
            ids = ids[-max_length:]
            labels = labels[-max_length:]
            ids[0] = self.ids.bos
            labels[0] = -100
        return ids, labels


def create_byte_tokenizer(output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    special = {
        token: BYTE_SPECIAL_BASE + index for index, token in enumerate(SPECIAL_TOKENS)
    }
    payload = {
        "type": "kokoro-byte-v1",
        "description": "Dependency-free UTF-8 byte tokenizer owned by Kokoro del Corazon.",
        "vocab_size": BYTE_SPECIAL_BASE + len(SPECIAL_TOKENS),
        "byte_token_ids": [0, 255],
        "special_tokens": special,
    }
    output_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    output_path.with_suffix(".meta.json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8"
    )


def train_tokenizer(
    files: list[Path],
    output_path: Path,
    vocab_size: int,
    min_frequency: int = 2,
    mode: str = "auto",
) -> str:
    if mode not in {"auto", "bpe", "byte"}:
        raise ValueError("Tokenizer mode must be auto, bpe, or byte")
    if mode == "byte":
        create_byte_tokenizer(output_path)
        return "byte"
    try:
        from tokenizers import Tokenizer, decoders, normalizers, pre_tokenizers, processors
        from tokenizers.models import BPE
        from tokenizers.trainers import BpeTrainer
    except ImportError as exc:
        if mode == "bpe":
            raise RuntimeError(
                "BPE mode requires the 'tokenizers' package. Run setup or use --mode byte."
            ) from exc
        create_byte_tokenizer(output_path)
        return "byte"

    if not files:
        raise ValueError("No text files were provided for tokenizer training")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    tokenizer = Tokenizer(BPE(unk_token=None, byte_fallback=True))
    tokenizer.normalizer = normalizers.NFC()
    tokenizer.pre_tokenizer = pre_tokenizers.ByteLevel(add_prefix_space=False, use_regex=True)
    tokenizer.decoder = decoders.ByteLevel()
    trainer = BpeTrainer(
        vocab_size=vocab_size,
        min_frequency=min_frequency,
        special_tokens=SPECIAL_TOKENS,
        initial_alphabet=pre_tokenizers.ByteLevel.alphabet(),
        show_progress=True,
    )
    tokenizer.train([str(path) for path in files], trainer=trainer)
    bos = tokenizer.token_to_id("<|bos|>")
    eos = tokenizer.token_to_id("<|eos|>")
    tokenizer.post_processor = processors.TemplateProcessing(
        single="$A",
        special_tokens=[("<|bos|>", bos), ("<|eos|>", eos)],
    )
    tokenizer.save(str(output_path), pretty=True)
    metadata = {
        "type": "kokoro-bytelevel-bpe-v1",
        "vocab_size": tokenizer.get_vocab_size(),
        "special_tokens": {
            token: tokenizer.token_to_id(token) for token in SPECIAL_TOKENS
        },
        "training_files": [str(path) for path in files],
    }
    output_path.with_suffix(".meta.json").write_text(
        json.dumps(metadata, indent=2), encoding="utf-8"
    )
    return "bpe"
