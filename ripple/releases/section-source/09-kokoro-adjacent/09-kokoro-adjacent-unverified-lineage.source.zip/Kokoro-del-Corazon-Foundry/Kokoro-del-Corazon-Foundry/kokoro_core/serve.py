from __future__ import annotations

import json
import mimetypes
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

from .generation import KokoroEngine


class KokoroServer:
    def __init__(self, engine: KokoroEngine, web_directory: Path):
        self.engine = engine
        self.web_directory = web_directory

    def handler_class(self):
        engine = self.engine
        web_directory = self.web_directory

        class Handler(BaseHTTPRequestHandler):
            server_version = "KokoroLocal/1.0"

            def log_message(self, format, *args):
                print(f"[web] {self.address_string()} - {format % args}")

            def send_json(self, payload: dict, status: int = 200):
                data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
                self.send_response(status)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

            def do_POST(self):
                parsed = urlparse(self.path)
                length = int(self.headers.get("Content-Length", "0"))
                try:
                    payload = json.loads(self.rfile.read(length) or b"{}")
                except json.JSONDecodeError:
                    return self.send_json({"error": "Invalid JSON"}, 400)
                if parsed.path == "/api/chat":
                    text = str(payload.get("message", "")).strip()
                    if not text:
                        return self.send_json({"error": "Message is empty"}, 400)
                    try:
                        answer = engine.generate(
                            text,
                            max_new_tokens=int(payload.get("max_new_tokens", 256)),
                            temperature=float(payload.get("temperature", 0.8)),
                            top_k=int(payload.get("top_k", 50)),
                            top_p=float(payload.get("top_p", 0.95)),
                        )
                        return self.send_json({"answer": answer})
                    except Exception as exc:
                        return self.send_json({"error": str(exc)}, 500)
                if parsed.path == "/api/reset":
                    engine.reset_context()
                    return self.send_json({"ok": True})
                if parsed.path == "/api/forget":
                    engine.forget_all()
                    return self.send_json({"ok": True})
                return self.send_json({"error": "Not found"}, 404)

            def do_GET(self):
                parsed = urlparse(self.path)
                relative = "index.html" if parsed.path in {"", "/"} else parsed.path.lstrip("/")
                target = (web_directory / relative).resolve()
                try:
                    target.relative_to(web_directory.resolve())
                except ValueError:
                    self.send_error(403)
                    return
                if not target.exists() or not target.is_file():
                    self.send_error(404)
                    return
                content = target.read_bytes()
                content_type = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
                self.send_response(200)
                self.send_header("Content-Type", content_type)
                self.send_header("Content-Length", str(len(content)))
                self.end_headers()
                self.wfile.write(content)

        return Handler


def run_web_server(
    checkpoint: Path,
    tokenizer_path: Path,
    memory_path: Path,
    web_directory: Path,
    host: str = "127.0.0.1",
    port: int = 8765,
    device: str = "auto",
    open_browser: bool = True,
) -> None:
    engine = KokoroEngine(checkpoint, tokenizer_path, memory_path, device)
    wrapper = KokoroServer(engine, web_directory)
    server = ThreadingHTTPServer((host, port), wrapper.handler_class())
    url = f"http://{host}:{port}"
    print(f"\nKokoro del Corazon is running at {url}")
    print("Press Ctrl+C to stop.\n")
    if open_browser:
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        engine.close()
