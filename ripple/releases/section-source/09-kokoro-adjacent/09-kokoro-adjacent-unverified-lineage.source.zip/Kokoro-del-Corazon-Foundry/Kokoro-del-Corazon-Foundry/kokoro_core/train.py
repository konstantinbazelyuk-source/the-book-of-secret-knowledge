from __future__ import annotations

import csv
import math
import os
import time
from dataclasses import asdict
from pathlib import Path
from typing import Callable, Optional

import torch
import torch.distributed as dist
import torch.nn.functional as F
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import DataLoader, DistributedSampler

from .config import ProjectConfig
from .data import PreferenceDataset, SFTDataset, load_split_dataset
from .model import KokoroModel
from .utils import (
    atomic_torch_save,
    autocast_context,
    choose_device,
    cosine_schedule,
    distributed_info,
    human_number,
    is_main_process,
    precision_dtype,
    set_seed,
)


def setup_distributed(device_arg: str = "auto") -> tuple[torch.device, int, int, int]:
    rank, local_rank, world_size = distributed_info()
    if world_size > 1 and not dist.is_initialized():
        backend = "nccl" if torch.cuda.is_available() else "gloo"
        dist.init_process_group(backend=backend, init_method="env://")
    if torch.cuda.is_available():
        if world_size > 1:
            torch.cuda.set_device(local_rank)
            device = torch.device("cuda", local_rank)
        else:
            device = choose_device(device_arg)
    else:
        device = choose_device(device_arg)
    return device, rank, local_rank, world_size


def cleanup_distributed() -> None:
    if dist.is_initialized():
        dist.barrier()
        dist.destroy_process_group()


def unwrap(model: torch.nn.Module) -> KokoroModel:
    current = model.module if isinstance(model, DDP) else model
    # torch.compile wraps the original module as _orig_mod.
    return getattr(current, "_orig_mod", current)


def create_optimizer(model: torch.nn.Module, cfg, device: torch.device):
    decay, no_decay = [], []
    for name, parameter in model.named_parameters():
        if not parameter.requires_grad:
            continue
        if parameter.dim() >= 2 and not name.endswith("norm.weight"):
            decay.append(parameter)
        else:
            no_decay.append(parameter)
    groups = [
        {"params": decay, "weight_decay": cfg.weight_decay},
        {"params": no_decay, "weight_decay": 0.0},
    ]
    kwargs = dict(
        lr=cfg.learning_rate,
        betas=(cfg.beta1, cfg.beta2),
        eps=1e-8,
    )
    if cfg.fused_optimizer and device.type == "cuda":
        try:
            return torch.optim.AdamW(groups, fused=True, **kwargs)
        except TypeError:
            pass
    return torch.optim.AdamW(groups, **kwargs)


def create_scaler(device: torch.device, dtype: torch.dtype):
    enabled = device.type == "cuda" and dtype == torch.float16
    if hasattr(torch, "amp") and hasattr(torch.amp, "GradScaler"):
        try:
            return torch.amp.GradScaler("cuda", enabled=enabled)
        except TypeError:
            return torch.amp.GradScaler(enabled=enabled)
    return torch.cuda.amp.GradScaler(enabled=enabled)


def checkpoint_payload(
    model: torch.nn.Module,
    optimizer: torch.optim.Optimizer,
    scaler,
    project: ProjectConfig,
    step: int,
    best_validation: float,
    phase: str,
) -> dict:
    raw = unwrap(model)
    return {
        "format_version": 2,
        "phase": phase,
        "step": step,
        "best_validation": best_validation,
        "model_config": raw.config_dict(),
        "project_name": project.name,
        "model_state": raw.state_dict(),
        "optimizer_state": optimizer.state_dict(),
        "scaler_state": scaler.state_dict() if scaler is not None else None,
        "train_config": asdict(project.train),
    }


def save_checkpoint(
    output_directory: Path,
    model: torch.nn.Module,
    optimizer: torch.optim.Optimizer,
    scaler,
    project: ProjectConfig,
    step: int,
    best_validation: float,
    phase: str,
    is_best: bool = False,
) -> Path:
    output_directory.mkdir(parents=True, exist_ok=True)
    payload = checkpoint_payload(
        model, optimizer, scaler, project, step, best_validation, phase
    )
    latest = output_directory / f"{phase}-latest.pt"
    atomic_torch_save(payload, latest)
    if is_best:
        atomic_torch_save(payload, output_directory / f"{phase}-best.pt")
    return latest


def load_training_checkpoint(
    path: Path,
    model: KokoroModel,
    optimizer: Optional[torch.optim.Optimizer] = None,
    scaler=None,
) -> tuple[int, float]:
    payload = torch.load(path, map_location="cpu", weights_only=False)
    model.load_state_dict(payload["model_state"], strict=True)
    if optimizer is not None and payload.get("optimizer_state"):
        optimizer.load_state_dict(payload["optimizer_state"])
    if scaler is not None and payload.get("scaler_state"):
        scaler.load_state_dict(payload["scaler_state"])
    return int(payload.get("step", -1)) + 1, float(payload.get("best_validation", math.inf))


def write_log(path: Path, row: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    exists = path.exists()
    with path.open("a", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(row.keys()))
        if not exists:
            writer.writeheader()
        writer.writerow(row)


@torch.inference_mode()
def evaluate_pretraining(
    model: torch.nn.Module,
    dataset,
    batches: int,
    batch_size: int,
    device: torch.device,
    dtype: torch.dtype,
) -> float:
    model.eval()
    losses = []
    for _ in range(batches):
        x, y = dataset.sample(batch_size, device)
        with autocast_context(device, dtype):
            _, loss = model(x, y)
        losses.append(float(loss.item()))
    model.train()
    return sum(losses) / len(losses)


def pretrain(
    project: ProjectConfig,
    tokenizer_vocab_size: int,
    prepared_directory: Path,
    output_directory: Path,
    resume: Optional[Path] = None,
    device_arg: str = "auto",
) -> None:
    device, rank, local_rank, world_size = setup_distributed(device_arg)
    try:
        set_seed(project.train.seed, rank)
        project.model.vocab_size = tokenizer_vocab_size
        project.model.validate()
        train_data = load_split_dataset(
            prepared_directory,
            "train",
            project.model.max_seq_len,
            project.train.seed + rank,
        )
        validation_data = load_split_dataset(
            prepared_directory,
            "validation",
            project.model.max_seq_len,
            project.train.seed + 10_000 + rank,
        )
        raw_model = KokoroModel(project.model).to(device)
        optimizer = create_optimizer(raw_model, project.train, device)
        dtype = precision_dtype(device, project.train.precision)
        scaler = create_scaler(device, dtype)
        start_step = 0
        best_validation = math.inf
        if resume:
            start_step, best_validation = load_training_checkpoint(
                resume, raw_model, optimizer, scaler
            )
        model: torch.nn.Module = raw_model
        if project.train.compile_model and hasattr(torch, "compile"):
            model = torch.compile(model)
        if world_size > 1:
            model = DDP(
                model,
                device_ids=[local_rank] if device.type == "cuda" else None,
                broadcast_buffers=False,
                gradient_as_bucket_view=True,
            )

        if is_main_process():
            effective = (
                project.train.batch_size
                * project.train.grad_accum_steps
                * world_size
                * project.model.max_seq_len
            )
            print("\nKOKORO DEL CORAZON — PRETRAINING FROM RANDOM WEIGHTS")
            print(f"Project: {project.name}")
            print(f"Device: {device}; world size: {world_size}")
            print(f"Parameters: {human_number(unwrap(model).parameter_count())}")
            print(f"Vocabulary: {tokenizer_vocab_size:,}")
            print(f"Sequence length: {project.model.max_seq_len:,}")
            print(f"Tokens per optimizer step: {effective:,}\n")

        model.train()
        optimizer.zero_grad(set_to_none=True)
        started = time.time()
        tokens_since_log = 0
        last_log_time = started
        last_completed_step = start_step - 1
        interrupted = False
        try:
            for step in range(start_step, project.train.max_steps):
                lr = cosine_schedule(
                    step,
                    project.train.warmup_steps,
                    project.train.max_steps,
                    project.train.learning_rate,
                    project.train.min_learning_rate,
                )
                for group in optimizer.param_groups:
                    group["lr"] = lr

                accumulated_loss = 0.0
                for micro_step in range(project.train.grad_accum_steps):
                    x, y = train_data.sample(project.train.batch_size, device)
                    sync = not isinstance(model, DDP) or micro_step == project.train.grad_accum_steps - 1
                    context = model.no_sync() if isinstance(model, DDP) and not sync else _NullContext()
                    with context:
                        with autocast_context(device, dtype):
                            _, loss = model(x, y)
                            scaled_loss = loss / project.train.grad_accum_steps
                        scaler.scale(scaled_loss).backward()
                    accumulated_loss += float(loss.detach().item())
                    tokens_since_log += x.numel() * world_size

                scaler.unscale_(optimizer)
                grad_norm = torch.nn.utils.clip_grad_norm_(
                    model.parameters(), project.train.grad_clip
                )
                scaler.step(optimizer)
                scaler.update()
                optimizer.zero_grad(set_to_none=True)
                last_completed_step = step

                if is_main_process() and (
                    step == start_step or (step + 1) % project.train.log_interval == 0
                ):
                    now = time.time()
                    throughput = tokens_since_log / max(now - last_log_time, 1e-6)
                    average_loss = accumulated_loss / project.train.grad_accum_steps
                    elapsed = now - started
                    print(
                        f"step {step + 1:>7}/{project.train.max_steps} | "
                        f"loss {average_loss:.4f} | lr {lr:.2e} | "
                        f"grad {float(grad_norm):.2f} | {throughput:,.0f} tok/s"
                    )
                    write_log(
                        output_directory.parent / "logs" / "pretrain.csv",
                        {
                            "step": step + 1,
                            "loss": average_loss,
                            "learning_rate": lr,
                            "grad_norm": float(grad_norm),
                            "tokens_per_second": throughput,
                            "elapsed_seconds": elapsed,
                        },
                    )
                    tokens_since_log = 0
                    last_log_time = now

                evaluate_now = (step + 1) % project.train.eval_interval == 0
                if evaluate_now:
                    validation = evaluate_pretraining(
                        model,
                        validation_data,
                        project.train.eval_batches,
                        project.train.batch_size,
                        device,
                        dtype,
                    )
                    if world_size > 1:
                        value = torch.tensor(validation, device=device)
                        dist.all_reduce(value, op=dist.ReduceOp.SUM)
                        validation = float(value.item() / world_size)
                    improved = validation < best_validation
                    best_validation = min(best_validation, validation)
                    if is_main_process():
                        print(
                            f"  validation {validation:.4f} | "
                            f"perplexity {math.exp(min(validation, 20)):.2f}"
                        )
                        save_checkpoint(
                            output_directory,
                            model,
                            optimizer,
                            scaler,
                            project,
                            step,
                            best_validation,
                            "pretrain",
                            is_best=improved,
                        )

                if is_main_process() and (step + 1) % project.train.save_interval == 0:
                    save_checkpoint(
                        output_directory,
                        model,
                        optimizer,
                        scaler,
                        project,
                        step,
                        best_validation,
                        "pretrain",
                    )
        except KeyboardInterrupt:
            interrupted = True
            if is_main_process():
                print("\nTraining interrupted. Saving the latest completed optimizer step...")

        if is_main_process() and last_completed_step >= 0:
            save_checkpoint(
                output_directory,
                model,
                optimizer,
                scaler,
                project,
                last_completed_step,
                best_validation,
                "pretrain",
            )
            print("\nCheckpoint saved after interruption." if interrupted else "\nPretraining complete.")
    finally:
        cleanup_distributed()


class _NullContext:
    def __enter__(self):
        return None

    def __exit__(self, exc_type, exc, tb):
        return False


def load_model_from_checkpoint(path: Path, device: torch.device) -> tuple[KokoroModel, dict]:
    payload = torch.load(path, map_location="cpu", weights_only=False)
    from .config import ModelConfig

    model = KokoroModel(ModelConfig.from_dict(payload["model_config"]))
    model.load_state_dict(payload["model_state"], strict=True)
    return model.to(device), payload


@torch.inference_mode()
def evaluate_sft_loader(model, loader, device, dtype, max_batches: int = 20) -> float:
    model.eval()
    losses = []
    for index, (ids, labels, mask) in enumerate(loader):
        if index >= max_batches:
            break
        ids = ids.to(device)
        labels = labels.to(device)
        mask = mask.to(device)
        with autocast_context(device, dtype):
            _, loss = model(ids[:, :-1], labels[:, 1:], mask[:, :-1])
        losses.append(float(loss.item()))
    model.train()
    return sum(losses) / max(1, len(losses))


def supervised_finetune(
    project: ProjectConfig,
    tokenizer,
    training_file: Path,
    validation_file: Optional[Path],
    base_checkpoint: Path,
    output_directory: Path,
    max_steps: int,
    device_arg: str = "auto",
) -> None:
    device, rank, local_rank, world_size = setup_distributed(device_arg)
    try:
        set_seed(project.train.seed, rank)
        model, payload = load_model_from_checkpoint(base_checkpoint, device)
        model.config.gradient_checkpointing = project.model.gradient_checkpointing
        train_dataset = SFTDataset(training_file, tokenizer, model.config.max_seq_len)
        validation_dataset = (
            SFTDataset(validation_file, tokenizer, model.config.max_seq_len)
            if validation_file and validation_file.exists()
            else None
        )
        sampler = DistributedSampler(train_dataset, shuffle=True) if world_size > 1 else None
        loader = DataLoader(
            train_dataset,
            batch_size=project.train.batch_size,
            shuffle=sampler is None,
            sampler=sampler,
            collate_fn=train_dataset.collate,
            num_workers=project.train.num_workers,
        )
        validation_loader = (
            DataLoader(
                validation_dataset,
                batch_size=project.train.batch_size,
                shuffle=False,
                collate_fn=validation_dataset.collate,
            )
            if validation_dataset
            else None
        )
        optimizer = create_optimizer(model, project.train, device)
        dtype = precision_dtype(device, project.train.precision)
        scaler = create_scaler(device, dtype)
        if project.train.compile_model and hasattr(torch, "compile"):
            model = torch.compile(model)
        if world_size > 1:
            model = DDP(
                model,
                device_ids=[local_rank] if device.type == "cuda" else None,
                broadcast_buffers=False,
            )
        if is_main_process():
            print("\nKOKORO DEL CORAZON — SUPERVISED FINE-TUNING")
            print(f"Examples: {len(train_dataset):,}; steps: {max_steps:,}\n")

        step = 0
        epoch = 0
        best_validation = math.inf
        optimizer.zero_grad(set_to_none=True)
        while step < max_steps:
            if sampler:
                sampler.set_epoch(epoch)
            for ids, labels, mask in loader:
                ids = ids.to(device)
                labels = labels.to(device)
                mask = mask.to(device)
                with autocast_context(device, dtype):
                    _, loss = model(ids[:, :-1], labels[:, 1:], mask[:, :-1])
                    loss = loss / project.train.grad_accum_steps
                scaler.scale(loss).backward()
                if (step + 1) % project.train.grad_accum_steps == 0:
                    scaler.unscale_(optimizer)
                    torch.nn.utils.clip_grad_norm_(model.parameters(), project.train.grad_clip)
                    scaler.step(optimizer)
                    scaler.update()
                    optimizer.zero_grad(set_to_none=True)
                if is_main_process() and (step + 1) % project.train.log_interval == 0:
                    print(f"step {step + 1:>6}/{max_steps} | loss {float(loss.detach().item()) * project.train.grad_accum_steps:.4f}")
                if validation_loader and (step + 1) % project.train.eval_interval == 0:
                    val = evaluate_sft_loader(model, validation_loader, device, dtype)
                    improved = val < best_validation
                    best_validation = min(best_validation, val)
                    if is_main_process():
                        print(f"  validation {val:.4f}")
                        save_checkpoint(
                            output_directory,
                            model,
                            optimizer,
                            scaler,
                            project,
                            step,
                            best_validation,
                            "sft",
                            is_best=improved,
                        )
                step += 1
                if step >= max_steps:
                    break
            epoch += 1
        if is_main_process():
            save_checkpoint(
                output_directory,
                model,
                optimizer,
                scaler,
                project,
                step - 1,
                best_validation,
                "sft",
            )
            print("\nFine-tuning complete.")
    finally:
        cleanup_distributed()


def sequence_log_probability(
    model: torch.nn.Module,
    ids: torch.Tensor,
    labels: torch.Tensor,
    attention_mask: torch.Tensor,
) -> torch.Tensor:
    logits, _ = model(ids[:, :-1], None, attention_mask[:, :-1])
    targets = labels[:, 1:]
    valid = targets != -100
    safe_targets = targets.masked_fill(~valid, 0)
    token_log_probs = F.log_softmax(logits, dim=-1).gather(
        -1, safe_targets.unsqueeze(-1)
    ).squeeze(-1)
    token_log_probs = token_log_probs * valid
    return token_log_probs.sum(-1) / valid.sum(-1).clamp_min(1)


def dpo_finetune(
    project: ProjectConfig,
    tokenizer,
    preference_file: Path,
    policy_checkpoint: Path,
    reference_checkpoint: Path,
    output_directory: Path,
    max_steps: int,
    beta: float = 0.1,
    device_arg: str = "auto",
) -> None:
    device = choose_device(device_arg)
    set_seed(project.train.seed)
    policy, _ = load_model_from_checkpoint(policy_checkpoint, device)
    reference, _ = load_model_from_checkpoint(reference_checkpoint, device)
    reference.eval()
    for parameter in reference.parameters():
        parameter.requires_grad_(False)
    dataset = PreferenceDataset(preference_file, tokenizer, policy.config.max_seq_len)
    loader = DataLoader(
        dataset,
        batch_size=project.train.batch_size,
        shuffle=True,
        collate_fn=dataset.collate,
    )
    optimizer = create_optimizer(policy, project.train, device)
    dtype = precision_dtype(device, project.train.precision)
    scaler = create_scaler(device, dtype)
    print("\nKOKORO DEL CORAZON — PREFERENCE TRAINING (DPO)")
    print(f"Pairs: {len(dataset):,}; steps: {max_steps:,}\n")
    step = 0
    optimizer.zero_grad(set_to_none=True)
    while step < max_steps:
        for batch in loader:
            chosen_ids, chosen_labels, chosen_mask, rejected_ids, rejected_labels, rejected_mask = [
                tensor.to(device) for tensor in batch
            ]
            with autocast_context(device, dtype):
                policy_chosen = sequence_log_probability(policy, chosen_ids, chosen_labels, chosen_mask)
                policy_rejected = sequence_log_probability(policy, rejected_ids, rejected_labels, rejected_mask)
                with torch.no_grad():
                    reference_chosen = sequence_log_probability(reference, chosen_ids, chosen_labels, chosen_mask)
                    reference_rejected = sequence_log_probability(reference, rejected_ids, rejected_labels, rejected_mask)
                logits = beta * (
                    (policy_chosen - policy_rejected)
                    - (reference_chosen - reference_rejected)
                )
                loss = -F.logsigmoid(logits).mean()
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(policy.parameters(), project.train.grad_clip)
            scaler.step(optimizer)
            scaler.update()
            optimizer.zero_grad(set_to_none=True)
            step += 1
            if step % project.train.log_interval == 0:
                accuracy = float((logits > 0).float().mean().item())
                print(f"step {step:>6}/{max_steps} | loss {float(loss.detach().item()):.4f} | preference accuracy {accuracy:.3f}")
            if step >= max_steps:
                break
    save_checkpoint(
        output_directory,
        policy,
        optimizer,
        scaler,
        project,
        step - 1,
        math.inf,
        "dpo",
    )
    print("\nPreference training complete.")
