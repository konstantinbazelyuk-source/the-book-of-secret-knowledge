@echo off
setlocal
cd /d "%~dp0.."
title Kokoro del Corazon Setup

echo Creating a private Python environment...
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 -m venv .venv
) else (
  python -m venv .venv
)
if errorlevel 1 goto :error

call .venv\Scripts\activate.bat
python -m pip install --upgrade pip setuptools wheel
python -m pip install -r requirements.txt
if errorlevel 1 goto :error

echo.
echo Setup complete.
python kokoro.py doctor
pause
exit /b 0

:error
echo.
echo Setup failed. Confirm Python 3.10 or newer is installed and "Add Python to PATH" was selected.
pause
exit /b 1
