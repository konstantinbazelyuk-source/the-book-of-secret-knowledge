# Third-party dependencies

Kokoro del Corazon does not include pretrained model weights. It uses open-source libraries as engineering tools:

- PyTorch — tensor computation, autograd, optimization, distributed training, and accelerated attention.
- Hugging Face Tokenizers — training and executing Kokoro's newly created ByteLevel BPE tokenizer.
- NumPy — binary token shards and memory-mapped data access.
- tqdm — optional progress presentation.

Each dependency remains under its own license. Review installed package metadata before redistribution.
