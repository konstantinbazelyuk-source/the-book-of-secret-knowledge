# Build manifest

## Core

- `kokoro.py`: central command-line interface.
- `kokoro_core/config.py`: model and training configuration.
- `kokoro_core/tokenizer.py`: byte tokenizer and optional from-scratch BPE.
- `kokoro_core/data.py`: cleaning, import, deduplication, sharding, and training datasets.
- `kokoro_core/model.py`: RMSNorm/RoPE/GQA/SwiGLU decoder Transformer.
- `kokoro_core/train.py`: pretraining, SFT, DPO, DDP, mixed precision, evaluation, and checkpoints.
- `kokoro_core/generation.py`: local inference and terminal chat.
- `kokoro_core/memory.py`: SQLite/FTS memory.
- `kokoro_core/serve.py`: local browser server.
- `kokoro_core/evaluation.py`: perplexity and behavior regressions.
- `kokoro_core/seed.py`: original seed curriculum generator.

## Artifacts created during use

- `artifacts/tokenizer.json`
- `artifacts/prepared/*.bin`
- `artifacts/memory.sqlite3`
- `checkpoints/*.pt`
- `logs/*.csv` and `logs/*.json`
