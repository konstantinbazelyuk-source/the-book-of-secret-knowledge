# Validation report

The repository was smoke-tested before packaging on a CPU-only Linux environment with Python 3.13 and PyTorch 2.10.

Validated operations:

- Python compilation of the complete repository.
- Original seed curriculum generation.
- Dependency-free byte tokenizer creation and reload.
- Unicode cleaning, exact deduplication, tokenization, deterministic split, and binary shard creation.
- Random initialization of the Transformer.
- Two optimizer steps of pretraining.
- Validation loss and perplexity calculation.
- Atomic latest and best checkpoint saving.
- Checkpoint inspection.
- Two supervised fine-tuning steps with assistant-only masking.
- One DPO preference step with a frozen reference model.
- Terminal inference and local SQLite memory creation.
- Local browser server, HTML delivery, and JSON API reset endpoint.

Smoke-test pretraining moved from loss 5.6187 to 5.1024, while the one-batch validation signal moved from 5.1001 to 4.8519. These numbers prove gradient flow and checkpoint operation only; they do not represent a trained language model. The tiny test checkpoints were removed from the distributed ZIP so the default chat cannot accidentally present a two-step model as useful intelligence.
