# Architecture

## Central learning path

```text
lawful text and conversations
→ normalization and deduplication
→ Kokoro tokenizer trained from scratch
→ uint32 memory-mapped token shards
→ random model initialization
→ autoregressive next-token pretraining
→ supervised instruction fine-tuning
→ preference optimization
→ behavioral and perplexity evaluation
→ local inference and memory
```

## Model block

Each Transformer block uses:

1. RMSNorm
2. causal grouped-query self-attention
3. rotary position embeddings (RoPE)
4. residual connection
5. RMSNorm
6. SwiGLU feed-forward network
7. residual connection

The attention implementation calls PyTorch's `scaled_dot_product_attention`, allowing PyTorch to select optimized kernels on compatible hardware. The design uses grouped-query attention to reduce key/value computation and memory compared with giving every query head an independent key/value head.

## Training system

- AdamW parameter groups with weight decay excluded from one-dimensional parameters.
- automatic mixed precision: BF16 when supported, otherwise FP16 or FP32.
- gradient scaling for CUDA FP16.
- gradient accumulation for larger effective batches.
- global gradient clipping.
- warmup followed by cosine learning-rate decay.
- periodic validation loss and perplexity.
- atomic checkpoint replacement.
- single-process CPU/GPU or `torchrun` DistributedDataParallel.
- optional `torch.compile`.
- optional activation checkpointing.

## Tokenizer choices

`--mode byte` creates Kokoro's dependency-free 264-token vocabulary: every UTF-8 byte plus eight special tokens. It is maximally robust but token-inefficient.

`--mode bpe` trains a new ByteLevel BPE vocabulary using the local corpus. It is faster and more context-efficient for serious training. The vocabulary is created for Kokoro; no pretrained tokenizer is loaded.

## Post-training

Supervised fine-tuning masks system and user tokens, calculating loss only over assistant output. Preference training uses Direct Preference Optimization with a frozen reference checkpoint and chosen/rejected response pairs.

## Memory

Conversation memory is not hidden in the weights. SQLite stores local turns and FTS5 retrieves relevant earlier turns. Retrieved memories are inserted as a distinct memory role. This gives inspectable, deletable continuity without requiring an outside embedding service.
