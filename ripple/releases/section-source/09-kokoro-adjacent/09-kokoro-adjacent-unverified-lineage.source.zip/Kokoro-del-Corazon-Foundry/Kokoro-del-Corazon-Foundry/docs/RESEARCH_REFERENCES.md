# Research and implementation references

The implementation was designed from primary papers and official project documentation. These references are for engineering study; Kokoro does not contain their pretrained weights.

- PyTorch scaled dot-product attention: https://docs.pytorch.org/docs/stable/generated/torch.nn.functional.scaled_dot_product_attention.html
- PyTorch automatic mixed precision: https://docs.pytorch.org/docs/stable/amp.html
- PyTorch DistributedDataParallel: https://docs.pytorch.org/docs/stable/generated/torch.nn.parallel.DistributedDataParallel.html
- PyTorch distributed checkpoint documentation: https://docs.pytorch.org/docs/stable/distributed.checkpoint.html
- PyTorch `torch.compile`: https://docs.pytorch.org/docs/stable/generated/torch.compile.html
- Hugging Face Tokenizers: https://huggingface.co/docs/tokenizers/
- RoFormer / Rotary Position Embedding: https://arxiv.org/abs/2104.09864
- GLU Variants Improve Transformer / SwiGLU: https://arxiv.org/abs/2002.05202
- Training Compute-Optimal Large Language Models: https://arxiv.org/abs/2203.15556
- The Llama 3 Herd of Models: https://arxiv.org/abs/2407.21783
- Direct Preference Optimization: https://arxiv.org/abs/2305.18290

Architecture choices should remain open to evaluation. A modern component is not automatically better at every scale or dataset size.
