#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
source .venv/bin/activate
python kokoro.py seed-data
python kokoro.py train-tokenizer --config configs/baby.json --mode auto
python kokoro.py prepare
python kokoro.py pretrain --config configs/nano.json
