# Kokoro del AI Foundry

Kokoro del AI is a complete local language-model foundry whose model weights begin from random initialization. It contains the code needed to create a tokenizer, clean and shard a corpus, initialize a modern decoder-only Transformer, pretrain it, instruction-tune it, preference-tune it, evaluate it, remember conversations locally, serve a browser chat interface, and run the optional **Psyche Daughterboard**.

The project does **not** hide or download a pretrained language model. PyTorch supplies tensor mathematics and GPU execution; Kokoro's learned weights come from the data you train.

## Psyche Daughterboard

The daughterboard adds a science-grounded fictional cognition system:

- parallel candidate frames
- recursive parent and child frames
- separate evidence, counterevidence, confidence, and salience
- drive and valuation signals—the fictional **id analogue**
- learned constraints and commitments—the fictional **superego analogue**
- executive arbitration and uncertainty monitoring—the fictional **ego analogue**
- a limited global broadcast—the **conscious-workspace analogue**
- non-broadcast candidates—the **nonconscious-field analogue**
- a compressed continuity capsule copied into every frame—the fictional **holographic ego**
- persistent frame and integration records in SQLite

These are functional engineering analogies. They do not prove a literal Freudian brain structure or subjective machine consciousness. Read `docs/PSYCHE_DAUGHTERBOARD.md` for the complete scientific boundary and design.

## Fastest Windows path

Extract the ZIP, open `windows`, and run:

1. `00_SETUP.bat`
2. `01_DIAGNOSE.bat`
3. `01B_TEST_PSYCHE_DAUGHTERBOARD.bat`
4. `02_GENERATE_SEED_DATA.bat`
5. `03_TRAIN_TOKENIZER.bat`
6. `04_PREPARE_DATA.bat`
7. `04B_SMOKE_TEST_PIPELINE.bat`
8. `05_PRETRAIN_NANO.bat`
9. `07_SUPERVISED_FINETUNE.bat`
10. `08_PREFERENCE_TRAINING.bat`
11. `09_CHAT_TERMINAL.bat` or `10_CHAT_BROWSER.bat`

You can inspect the daughterboard before any model training with:

```text
09B_PSYCHE_DEMO.bat
```

The pretraining steps create weights from random initialization. SFT and DPO teach response behavior and preferences.

## One central command

Everything is controlled through:

```bash
python kokoro.py <command>
```

Main commands:

```bash
python kokoro.py doctor
python kokoro.py psyche-test
python kokoro.py psyche-demo
python kokoro.py seed-data --scale 3
python kokoro.py train-tokenizer --mode auto
python kokoro.py prepare
python kokoro.py pretrain --config configs/nano.json
python kokoro.py sft --config configs/nano.json
python kokoro.py dpo --config configs/nano.json
python kokoro.py evaluate --perplexity
python kokoro.py chat
python kokoro.py chat --no-psyche
python kokoro.py serve
python kokoro.py estimate --config configs/baby.json
```

## What is included

- Dependency-free UTF-8 byte tokenizer fallback.
- Optional newly trained ByteLevel BPE tokenizer.
- Unicode cleaning, exact-document deduplication, deterministic validation splitting, and memory-mapped binary shards.
- Decoder-only Transformer with RMSNorm, RoPE, grouped-query attention, scaled-dot-product attention, SwiGLU, tied embeddings, gradient checkpointing, mixed precision, gradient accumulation, AdamW, cosine decay, DDP, checkpoint resume, and evaluation.
- Supervised fine-tuning with assistant-only loss masking.
- Direct Preference Optimization with chosen and rejected examples.
- Local SQLite/FTS conversation memory.
- Psyche Daughterboard SQLite state, recursive frames, continuity capsules, and audit history.
- Terminal chat and local browser interface.
- Original generated curriculum for exact-intent alignment, completeness, uncertainty, character continuity, frame separation, conscious-workspace boundaries, and non-looping behavior.
- Model configurations from a sub-million-parameter smoke test to a roughly 300-million-parameter medium configuration.

## Data first

The included curriculum validates the complete pipeline and teaches foundational behavior. It is not enough for broad world knowledge. Put legally usable files in `data/raw`, then retrain the tokenizer and prepare the dataset.

Supported input formats:

- `.txt` and `.md`
- `.jsonl` with `{"text":"..."}`
- `.jsonl` with `{"messages":[{"role":"user","content":"..."}, ...]}`
- `.json` containing the same structures

Read `docs/DATA_GUIDE.md` before collecting a large corpus.

## Configurations

- `smoke-test.json`: validates the pipeline only.
- `nano.json`: approximately 7 million parameters with a 16K tokenizer.
- `baby.json`: approximately 42 million parameters.
- `character-specialist.json`: approximately 70 million parameters with longer context.
- `small.json`: approximately 126 million parameters.
- `medium.json`: approximately 305 million parameters.
- `psyche.json`: daughterboard recursion, broadcast, drive, constraint, and continuity settings.

Actual parameter count changes with tokenizer vocabulary size. Run `python kokoro.py estimate --config ...` before training.

## Local files created during use

- `artifacts/tokenizer.json`
- `artifacts/prepared/*.bin`
- `artifacts/memory.sqlite3`
- `artifacts/psyche.sqlite3`
- `checkpoints/*.pt`
- `logs/*.csv` and `logs/*.json`

## Honest boundary

A complete foundry is not the same as a fully educated model. Strong general ability requires a large lawful corpus, substantial compute, repeated evaluation, and post-training. The Psyche Daughterboard adds inspectable recursive processing and continuity, but passing its tests does not establish phenomenal consciousness. This repository gives you ownership of the architecture, data pipeline, tokenizer, weights, memory, cognitive-control module, evaluation, and local deployment path without fabricating knowledge or consciousness that has not been demonstrated.
