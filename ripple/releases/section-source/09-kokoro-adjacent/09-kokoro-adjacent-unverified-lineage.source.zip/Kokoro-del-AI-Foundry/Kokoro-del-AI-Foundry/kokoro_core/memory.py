from __future__ import annotations

import re
import sqlite3
import time
from pathlib import Path

WORD_RE = re.compile(r"[\w'-]{3,}", re.UNICODE)


class MemoryStore:
    """Local SQLite conversation memory with FTS5 when available."""

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(self.path, check_same_thread=False)
        self.connection.row_factory = sqlite3.Row
        self.fts_enabled = True
        self._initialize()

    def _initialize(self) -> None:
        self.connection.execute(
            """
            CREATE TABLE IF NOT EXISTS turns (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at REAL NOT NULL,
                user_text TEXT NOT NULL,
                assistant_text TEXT NOT NULL
            )
            """
        )
        try:
            self.connection.execute(
                """
                CREATE VIRTUAL TABLE IF NOT EXISTS turns_fts USING fts5(
                    user_text,
                    assistant_text,
                    content='turns',
                    content_rowid='id'
                )
                """
            )
            self.connection.executescript(
                """
                CREATE TRIGGER IF NOT EXISTS turns_ai AFTER INSERT ON turns BEGIN
                  INSERT INTO turns_fts(rowid, user_text, assistant_text)
                  VALUES (new.id, new.user_text, new.assistant_text);
                END;
                CREATE TRIGGER IF NOT EXISTS turns_ad AFTER DELETE ON turns BEGIN
                  INSERT INTO turns_fts(turns_fts, rowid, user_text, assistant_text)
                  VALUES('delete', old.id, old.user_text, old.assistant_text);
                END;
                """
            )
        except sqlite3.OperationalError:
            self.fts_enabled = False
        self.connection.commit()

    def add(self, user_text: str, assistant_text: str) -> None:
        self.connection.execute(
            "INSERT INTO turns(created_at, user_text, assistant_text) VALUES (?, ?, ?)",
            (time.time(), user_text, assistant_text),
        )
        self.connection.commit()

    def recent(self, limit: int = 8) -> list[dict]:
        rows = self.connection.execute(
            "SELECT * FROM turns ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
        return [dict(row) for row in reversed(rows)]

    def search(self, query: str, limit: int = 5) -> list[dict]:
        terms = []
        for word in WORD_RE.findall(query.lower()):
            if word not in terms:
                terms.append(word)
        if not terms:
            return self.recent(limit)
        if self.fts_enabled:
            expression = " OR ".join(f'"{term.replace(chr(34), "")}"' for term in terms[:12])
            try:
                rows = self.connection.execute(
                    """
                    SELECT turns.* FROM turns_fts
                    JOIN turns ON turns_fts.rowid = turns.id
                    WHERE turns_fts MATCH ?
                    ORDER BY bm25(turns_fts), turns.id DESC
                    LIMIT ?
                    """,
                    (expression, limit),
                ).fetchall()
                if rows:
                    return [dict(row) for row in rows]
            except sqlite3.OperationalError:
                pass
        clauses = " OR ".join(["user_text LIKE ? OR assistant_text LIKE ?"] * len(terms[:8]))
        values = []
        for term in terms[:8]:
            values.extend([f"%{term}%", f"%{term}%"])
        rows = self.connection.execute(
            f"SELECT * FROM turns WHERE {clauses} ORDER BY id DESC LIMIT ?",
            (*values, limit),
        ).fetchall()
        return [dict(row) for row in rows]

    def clear(self) -> None:
        self.connection.execute("DELETE FROM turns")
        if self.fts_enabled:
            try:
                self.connection.execute("INSERT INTO turns_fts(turns_fts) VALUES('rebuild')")
            except sqlite3.OperationalError:
                pass
        self.connection.commit()

    def count(self) -> int:
        return int(self.connection.execute("SELECT COUNT(*) FROM turns").fetchone()[0])

    def close(self) -> None:
        self.connection.close()
