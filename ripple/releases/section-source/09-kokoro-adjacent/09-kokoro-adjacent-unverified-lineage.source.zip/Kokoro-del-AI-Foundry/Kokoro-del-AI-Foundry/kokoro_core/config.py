from __future__ import annotations

from dataclasses import asdict, dataclass, fields
from pathlib import Path
import json


@dataclass
class ModelConfig:
    vocab_size: int = 16_384
    max_seq_len: int = 1024
    n_layer: int = 8
    n_head: int = 6
    n_kv_head: int = 2
    dim: int = 384
    hidden_dim: int = 1024
    dropout: float = 0.0
    rope_theta: float = 10_000.0
    norm_eps: float = 1e-5
    tie_embeddings: bool = True
    bias: bool = False
    gradient_checkpointing: bool = False

    def validate(self) -> None:
        if self.dim % self.n_head != 0:
            raise ValueError("dim must be divisible by n_head")
        if self.n_head % self.n_kv_head != 0:
            raise ValueError("n_head must be divisible by n_kv_head")
        if (self.dim // self.n_head) % 2 != 0:
            raise ValueError("attention head dimension must be even for RoPE")
        if self.vocab_size < 256:
            raise ValueError("vocab_size is unexpectedly small")
        if self.max_seq_len < 32:
            raise ValueError("max_seq_len must be at least 32")

    @classmethod
    def from_dict(cls, payload: dict) -> "ModelConfig":
        allowed = {f.name for f in fields(cls)}
        cfg = cls(**{k: v for k, v in payload.items() if k in allowed})
        cfg.validate()
        return cfg


@dataclass
class TrainConfig:
    seed: int = 1337
    batch_size: int = 8
    grad_accum_steps: int = 8
    max_steps: int = 20_000
    learning_rate: float = 3e-4
    min_learning_rate: float = 3e-5
    warmup_steps: int = 500
    weight_decay: float = 0.1
    beta1: float = 0.9
    beta2: float = 0.95
    grad_clip: float = 1.0
    eval_interval: int = 250
    eval_batches: int = 20
    save_interval: int = 500
    log_interval: int = 10
    precision: str = "auto"
    compile_model: bool = False
    fused_optimizer: bool = True
    num_workers: int = 0

    @classmethod
    def from_dict(cls, payload: dict) -> "TrainConfig":
        allowed = {f.name for f in fields(cls)}
        return cls(**{k: v for k, v in payload.items() if k in allowed})


@dataclass
class ProjectConfig:
    name: str
    model: ModelConfig
    train: TrainConfig
    description: str = ""

    @classmethod
    def load(cls, path: str | Path) -> "ProjectConfig":
        source = Path(path)
        payload = json.loads(source.read_text(encoding="utf-8"))
        return cls(
            name=payload.get("name", source.stem),
            description=payload.get("description", ""),
            model=ModelConfig.from_dict(payload.get("model", {})),
            train=TrainConfig.from_dict(payload.get("train", {})),
        )

    def save(self, path: str | Path) -> None:
        Path(path).write_text(
            json.dumps(
                {
                    "name": self.name,
                    "description": self.description,
                    "model": asdict(self.model),
                    "train": asdict(self.train),
                },
                indent=2,
            ),
            encoding="utf-8",
        )
