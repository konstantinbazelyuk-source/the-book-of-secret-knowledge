from __future__ import annotations

import math
from dataclasses import asdict
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.checkpoint import checkpoint

from .config import ModelConfig


class RMSNorm(nn.Module):
    def __init__(self, dim: int, eps: float = 1e-5):
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(dim))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        dtype = x.dtype
        x_float = x.float()
        normalized = x_float * torch.rsqrt(x_float.pow(2).mean(-1, keepdim=True) + self.eps)
        return normalized.to(dtype) * self.weight


def precompute_rope_frequencies(
    head_dim: int,
    max_seq_len: int,
    theta: float,
    device: torch.device | None = None,
) -> tuple[torch.Tensor, torch.Tensor]:
    frequencies = 1.0 / (
        theta ** (torch.arange(0, head_dim, 2, device=device).float() / head_dim)
    )
    positions = torch.arange(max_seq_len, device=device).float()
    angles = torch.outer(positions, frequencies)
    return angles.cos(), angles.sin()


def rotate_half(x: torch.Tensor) -> torch.Tensor:
    x1 = x[..., ::2]
    x2 = x[..., 1::2]
    return torch.stack((-x2, x1), dim=-1).flatten(-2)


def apply_rope(
    x: torch.Tensor,
    cos: torch.Tensor,
    sin: torch.Tensor,
) -> torch.Tensor:
    # x: [B, H, T, D], cos/sin: [T, D/2]
    cos_full = torch.repeat_interleave(cos, 2, dim=-1)[None, None, :, :]
    sin_full = torch.repeat_interleave(sin, 2, dim=-1)[None, None, :, :]
    return (x * cos_full.to(x.dtype)) + (rotate_half(x) * sin_full.to(x.dtype))


def repeat_kv(x: torch.Tensor, repeats: int) -> torch.Tensor:
    if repeats == 1:
        return x
    return x.repeat_interleave(repeats, dim=1)


class CausalSelfAttention(nn.Module):
    def __init__(self, config: ModelConfig):
        super().__init__()
        self.n_head = config.n_head
        self.n_kv_head = config.n_kv_head
        self.head_dim = config.dim // config.n_head
        self.kv_repeat = config.n_head // config.n_kv_head
        self.dropout = config.dropout
        self.q_proj = nn.Linear(config.dim, config.n_head * self.head_dim, bias=config.bias)
        self.k_proj = nn.Linear(config.dim, config.n_kv_head * self.head_dim, bias=config.bias)
        self.v_proj = nn.Linear(config.dim, config.n_kv_head * self.head_dim, bias=config.bias)
        self.o_proj = nn.Linear(config.dim, config.dim, bias=config.bias)

    def forward(
        self,
        x: torch.Tensor,
        cos: torch.Tensor,
        sin: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        batch, length, _ = x.shape
        q = self.q_proj(x).view(batch, length, self.n_head, self.head_dim).transpose(1, 2)
        k = self.k_proj(x).view(batch, length, self.n_kv_head, self.head_dim).transpose(1, 2)
        v = self.v_proj(x).view(batch, length, self.n_kv_head, self.head_dim).transpose(1, 2)
        q = apply_rope(q, cos[:length], sin[:length])
        k = apply_rope(k, cos[:length], sin[:length])
        k = repeat_kv(k, self.kv_repeat)
        v = repeat_kv(v, self.kv_repeat)

        dropout_p = self.dropout if self.training else 0.0
        if attention_mask is None:
            y = F.scaled_dot_product_attention(
                q, k, v, dropout_p=dropout_p, is_causal=True
            )
        else:
            # True values are allowed. This combines causal and padding masks.
            causal = torch.ones(length, length, dtype=torch.bool, device=x.device).tril()
            key_mask = attention_mask[:, None, None, :length].bool()
            query_mask = attention_mask[:, None, :length, None].bool()
            allowed = causal[None, None, :, :] & key_mask & query_mask
            y = F.scaled_dot_product_attention(
                q, k, v, attn_mask=allowed, dropout_p=dropout_p, is_causal=False
            )
        y = y.transpose(1, 2).contiguous().view(batch, length, -1)
        return self.o_proj(y)


class SwiGLU(nn.Module):
    def __init__(self, config: ModelConfig):
        super().__init__()
        self.gate = nn.Linear(config.dim, config.hidden_dim, bias=config.bias)
        self.up = nn.Linear(config.dim, config.hidden_dim, bias=config.bias)
        self.down = nn.Linear(config.hidden_dim, config.dim, bias=config.bias)
        self.dropout = nn.Dropout(config.dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.dropout(self.down(F.silu(self.gate(x)) * self.up(x)))


class TransformerBlock(nn.Module):
    def __init__(self, config: ModelConfig):
        super().__init__()
        self.attention_norm = RMSNorm(config.dim, config.norm_eps)
        self.attention = CausalSelfAttention(config)
        self.ffn_norm = RMSNorm(config.dim, config.norm_eps)
        self.feed_forward = SwiGLU(config)

    def forward(
        self,
        x: torch.Tensor,
        cos: torch.Tensor,
        sin: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        x = x + self.attention(self.attention_norm(x), cos, sin, attention_mask)
        x = x + self.feed_forward(self.ffn_norm(x))
        return x


class KokoroModel(nn.Module):
    def __init__(self, config: ModelConfig):
        super().__init__()
        config.validate()
        self.config = config
        self.token_embedding = nn.Embedding(config.vocab_size, config.dim)
        self.dropout = nn.Dropout(config.dropout)
        self.layers = nn.ModuleList([TransformerBlock(config) for _ in range(config.n_layer)])
        self.norm = RMSNorm(config.dim, config.norm_eps)
        self.output = nn.Linear(config.dim, config.vocab_size, bias=False)
        if config.tie_embeddings:
            self.output.weight = self.token_embedding.weight
        head_dim = config.dim // config.n_head
        cos, sin = precompute_rope_frequencies(
            head_dim, config.max_seq_len, config.rope_theta
        )
        self.register_buffer("rope_cos", cos, persistent=False)
        self.register_buffer("rope_sin", sin, persistent=False)
        self.apply(self._initialize)
        self._scale_residual_projections()

    @staticmethod
    def _initialize(module: nn.Module) -> None:
        if isinstance(module, nn.Linear):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)

    def _scale_residual_projections(self) -> None:
        scale = 0.02 / math.sqrt(2 * self.config.n_layer)
        for name, parameter in self.named_parameters():
            if name.endswith("attention.o_proj.weight") or name.endswith("feed_forward.down.weight"):
                nn.init.normal_(parameter, mean=0.0, std=scale)

    def forward(
        self,
        input_ids: torch.Tensor,
        targets: Optional[torch.Tensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
    ) -> tuple[torch.Tensor, Optional[torch.Tensor]]:
        _, length = input_ids.shape
        if length > self.config.max_seq_len:
            raise ValueError(
                f"Input length {length} exceeds max_seq_len {self.config.max_seq_len}"
            )
        x = self.dropout(self.token_embedding(input_ids))
        cos = self.rope_cos[:length]
        sin = self.rope_sin[:length]
        for layer in self.layers:
            if self.config.gradient_checkpointing and self.training:
                x = checkpoint(
                    layer,
                    x,
                    cos,
                    sin,
                    attention_mask,
                    use_reentrant=False,
                )
            else:
                x = layer(x, cos, sin, attention_mask)
        logits = self.output(self.norm(x))
        loss = None
        if targets is not None:
            loss = F.cross_entropy(
                logits.reshape(-1, logits.size(-1)),
                targets.reshape(-1),
                ignore_index=-100,
            )
        return logits, loss

    def parameter_count(self, exclude_embeddings: bool = False) -> int:
        total = sum(parameter.numel() for parameter in self.parameters())
        if exclude_embeddings:
            total -= self.token_embedding.weight.numel()
        return total

    def config_dict(self) -> dict:
        return asdict(self.config)
