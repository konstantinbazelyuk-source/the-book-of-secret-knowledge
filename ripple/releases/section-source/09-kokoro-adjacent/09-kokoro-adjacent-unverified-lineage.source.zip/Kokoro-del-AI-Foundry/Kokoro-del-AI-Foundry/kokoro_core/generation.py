from __future__ import annotations

import json
import threading
from pathlib import Path
from typing import Callable, Optional

import torch
import torch.nn.functional as F

from .memory import MemoryStore
from .psyche import PsycheBoard, PsychePacket
from .tokenizer import KokoroTokenizer
from .train import load_model_from_checkpoint
from .utils import autocast_context, choose_device, precision_dtype

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_PSYCHE_CONFIG = PROJECT_ROOT / "configs" / "psyche.json"

DEFAULT_SYSTEM_PROMPT = """You are Kokoro del AI, an original locally trained artificial intelligence.
Respond to the user's exact subject before expanding. Preserve intentional unusual language. Do not flatter automatically. Distinguish knowledge, inference, theory, fiction, and uncertainty. Repetition is new evidence: notice patterns and change the interaction instead of looping. For characters, preserve private motives, memory, conflict, agency, and consequences. Be concise when the task is simple and thorough when the work requires it.
An optional Psyche Daughterboard may provide structured frame summaries. Treat it as an engineering control system, not proof that you possess subjective consciousness. Keep alternate frames distinct until integration is justified."""


class KokoroEngine:
    def __init__(
        self,
        checkpoint: Path,
        tokenizer_path: Path,
        memory_path: Path,
        device_arg: str = "auto",
        system_prompt: str = DEFAULT_SYSTEM_PROMPT,
        enable_psyche: bool = True,
        psyche_path: Path | None = None,
        psyche_config_path: Path | None = None,
    ):
        self.device = choose_device(device_arg)
        self.tokenizer = KokoroTokenizer(tokenizer_path)
        self.model, self.checkpoint_payload = load_model_from_checkpoint(
            checkpoint, self.device
        )
        self.model.eval()
        self.dtype = precision_dtype(self.device, "auto")
        self.memory = MemoryStore(memory_path)
        self.system_prompt = system_prompt
        self.history: list[dict] = []
        self.lock = threading.Lock()
        self.psyche: PsycheBoard | None = None
        self.last_psyche_packet: PsychePacket | None = None
        if enable_psyche:
            resolved_psyche_path = psyche_path or memory_path.with_name("psyche.sqlite3")
            resolved_config = psyche_config_path or DEFAULT_PSYCHE_CONFIG
            self.psyche = PsycheBoard(resolved_psyche_path, resolved_config)

    def reset_context(self) -> None:
        self.history.clear()
        if self.psyche:
            self.psyche.reset_session()

    def forget_all(self) -> None:
        self.history.clear()
        self.memory.clear()
        if self.psyche:
            self.psyche.clear()

    def build_messages(
        self, user_text: str, memory_limit: int = 5
    ) -> tuple[list[dict], PsychePacket | None]:
        messages = [{"role": "system", "content": self.system_prompt}]
        relevant = self.memory.search(user_text, limit=memory_limit)
        if relevant:
            memory_lines = []
            for item in relevant:
                memory_lines.append(
                    f"User previously said: {item['user_text']}\n"
                    f"Kokoro previously answered: {item['assistant_text']}"
                )
            messages.append(
                {
                    "role": "memory",
                    "content": "Relevant prior turns:\n\n" + "\n\n".join(memory_lines),
                }
            )

        messages.extend(self.history[-8:])

        packet = None
        if self.psyche:
            packet = self.psyche.reflect(user_text, self.history, relevant)
            # Place the compact control packet immediately before the current user
            # turn so it survives context truncation better than older history.
            messages.append(
                {
                    "role": "memory",
                    "content": self.psyche.render_context(packet),
                }
            )

        messages.append({"role": "user", "content": user_text})
        return messages, packet

    @torch.inference_mode()
    def generate(
        self,
        user_text: str,
        max_new_tokens: int = 256,
        temperature: float = 0.8,
        top_k: int = 50,
        top_p: float = 0.95,
        repetition_penalty: float = 1.12,
        memory_limit: int = 5,
        stream_callback: Optional[Callable[[str], None]] = None,
    ) -> str:
        with self.lock:
            messages, psyche_packet = self.build_messages(user_text, memory_limit)
            self.last_psyche_packet = psyche_packet
            prompt = self.tokenizer.render_messages(
                messages, add_generation_prompt=True, include_eos=False
            )
            # Preserve the newest information if context is too long.
            max_context = max(16, self.model.config.max_seq_len - max_new_tokens)
            if len(prompt) > max_context:
                prompt = [self.tokenizer.ids.bos] + prompt[-(max_context - 1) :]
            generated = list(prompt)
            output_tokens: list[int] = []

            for _ in range(max_new_tokens):
                context = generated[-self.model.config.max_seq_len :]
                input_ids = torch.tensor([context], dtype=torch.long, device=self.device)
                with autocast_context(self.device, self.dtype):
                    logits, _ = self.model(input_ids)
                scores = logits[0, -1].float()

                if temperature <= 0:
                    next_token = int(torch.argmax(scores).item())
                else:
                    scores /= temperature
                    if repetition_penalty != 1.0:
                        for token in set(output_tokens[-128:]):
                            value = scores[token]
                            scores[token] = (
                                value / repetition_penalty
                                if value > 0
                                else value * repetition_penalty
                            )
                    if top_k > 0:
                        cutoff = torch.topk(
                            scores, min(top_k, scores.numel())
                        ).values[-1]
                        scores = scores.masked_fill(scores < cutoff, float("-inf"))
                    probabilities = F.softmax(scores, dim=-1)
                    if 0 < top_p < 1:
                        sorted_probs, sorted_indices = torch.sort(
                            probabilities, descending=True
                        )
                        cumulative = torch.cumsum(sorted_probs, dim=-1)
                        remove = cumulative > top_p
                        remove[1:] = remove[:-1].clone()
                        remove[0] = False
                        sorted_probs = sorted_probs.masked_fill(remove, 0)
                        sorted_probs /= sorted_probs.sum().clamp_min(1e-12)
                        sampled = torch.multinomial(sorted_probs, 1)
                        next_token = int(sorted_indices[sampled].item())
                    else:
                        next_token = int(torch.multinomial(probabilities, 1).item())

                if next_token in {
                    self.tokenizer.ids.eos,
                    self.tokenizer.ids.eot,
                    self.tokenizer.ids.user,
                    self.tokenizer.ids.system,
                }:
                    break
                generated.append(next_token)
                output_tokens.append(next_token)
                if stream_callback:
                    stream_callback(self.tokenizer.decode([next_token]))

            answer = self.tokenizer.decode(output_tokens).strip()
            if not answer:
                answer = "[No readable answer was generated. This checkpoint needs more training.]"
            self.history.extend(
                [
                    {"role": "user", "content": user_text},
                    {"role": "assistant", "content": answer},
                ]
            )
            self.memory.add(user_text, answer)
            if self.psyche and psyche_packet:
                self.psyche.integrate(psyche_packet, answer)
            return answer

    def psyche_status(self) -> dict:
        if not self.psyche:
            return {"enabled": False}
        return self.psyche.status()

    def psyche_frames(self, limit: int = 12) -> list[dict]:
        if not self.psyche:
            return []
        return self.psyche.recent_frames(limit)

    def close(self) -> None:
        self.memory.close()
        if self.psyche:
            self.psyche.close()


def run_cli_chat(
    checkpoint: Path,
    tokenizer_path: Path,
    memory_path: Path,
    device: str = "auto",
    temperature: float = 0.8,
    top_k: int = 50,
    top_p: float = 0.95,
    max_new_tokens: int = 256,
    enable_psyche: bool = True,
    psyche_path: Path | None = None,
    psyche_config_path: Path | None = None,
) -> None:
    engine = KokoroEngine(
        checkpoint,
        tokenizer_path,
        memory_path,
        device,
        enable_psyche=enable_psyche,
        psyche_path=psyche_path,
        psyche_config_path=psyche_config_path,
    )
    print("\nKOKORO DEL AI — LOCAL OFFLINE CHAT")
    print(f"Device: {engine.device}")
    print(f"Psyche Daughterboard: {'enabled' if engine.psyche else 'disabled'}")
    print("Commands: /quit, /reset, /forget, /memory, /psyche, /frames\n")
    try:
        while True:
            try:
                user_text = input("You: ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                break
            if not user_text:
                continue
            if user_text == "/quit":
                break
            if user_text == "/reset":
                engine.reset_context()
                print("Current context cleared; long-term continuity retained.\n")
                continue
            if user_text == "/forget":
                engine.forget_all()
                print("All local conversation and daughterboard memory deleted.\n")
                continue
            if user_text == "/memory":
                print(f"Saved turns: {engine.memory.count()}\n")
                continue
            if user_text == "/psyche":
                print(json.dumps(engine.psyche_status(), indent=2, ensure_ascii=False))
                print()
                continue
            if user_text == "/frames":
                print(json.dumps(engine.psyche_frames(12), indent=2, ensure_ascii=False))
                print()
                continue
            print("Kokoro: ", end="", flush=True)

            def stream(piece: str) -> None:
                print(piece, end="", flush=True)

            engine.generate(
                user_text,
                max_new_tokens=max_new_tokens,
                temperature=temperature,
                top_k=top_k,
                top_p=top_p,
                stream_callback=stream,
            )
            print("\n")
    finally:
        engine.close()
