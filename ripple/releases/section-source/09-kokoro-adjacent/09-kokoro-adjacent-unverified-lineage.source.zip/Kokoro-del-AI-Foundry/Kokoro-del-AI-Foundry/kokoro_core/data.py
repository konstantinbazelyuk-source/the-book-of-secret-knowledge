from __future__ import annotations

import hashlib
import json
import random
import re
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Iterator

import numpy as np
import torch

from .tokenizer import KokoroTokenizer
from .utils import iter_jsonl

SUPPORTED_EXTENSIONS = {".txt", ".md", ".jsonl", ".json"}
CONTROL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
SPACE_RE = re.compile(r"[ \t]+")
NEWLINES_RE = re.compile(r"\n{4,}")


def clean_text(text: str) -> str:
    text = unicodedata.normalize("NFC", text.replace("\r\n", "\n").replace("\r", "\n"))
    text = CONTROL_RE.sub("", text)
    text = "\n".join(SPACE_RE.sub(" ", line).rstrip() for line in text.splitlines())
    text = NEWLINES_RE.sub("\n\n\n", text)
    return text.strip()


def render_messages_plain(messages: list[dict]) -> str:
    parts: list[str] = []
    for message in messages:
        role = str(message.get("role", "user")).strip().capitalize()
        content = clean_text(str(message.get("content", "")))
        if content:
            parts.append(f"{role}: {content}")
    return "\n".join(parts)


def iter_documents(paths: Iterable[Path]) -> Iterator[tuple[str, str]]:
    """Yield (source_name, document_text)."""
    for path in paths:
        if not path.is_file() or path.suffix.lower() not in SUPPORTED_EXTENSIONS:
            continue
        suffix = path.suffix.lower()
        if suffix in {".txt", ".md"}:
            text = clean_text(path.read_text(encoding="utf-8", errors="replace"))
            if text:
                yield str(path), text
            continue
        if suffix == ".jsonl":
            for index, record in enumerate(iter_jsonl(path), 1):
                text = ""
                if isinstance(record.get("text"), str):
                    text = record["text"]
                elif isinstance(record.get("messages"), list):
                    text = render_messages_plain(record["messages"])
                elif isinstance(record.get("prompt"), str) and isinstance(record.get("response"), str):
                    text = f"User: {record['prompt']}\nAssistant: {record['response']}"
                text = clean_text(text)
                if text:
                    yield f"{path}#{index}", text
            continue
        if suffix == ".json":
            payload = json.loads(path.read_text(encoding="utf-8", errors="replace"))
            records = payload if isinstance(payload, list) else [payload]
            for index, record in enumerate(records, 1):
                if not isinstance(record, dict):
                    continue
                text = ""
                if isinstance(record.get("text"), str):
                    text = record["text"]
                elif isinstance(record.get("messages"), list):
                    text = render_messages_plain(record["messages"])
                text = clean_text(text)
                if text:
                    yield f"{path}#{index}", text


def discover_files(directory: Path) -> list[Path]:
    if not directory.exists():
        return []
    return sorted(
        path for path in directory.rglob("*")
        if path.is_file() and path.suffix.lower() in SUPPORTED_EXTENSIONS
    )


@dataclass
class PrepareStats:
    documents_seen: int = 0
    documents_kept: int = 0
    duplicates_removed: int = 0
    characters_kept: int = 0
    train_tokens: int = 0
    validation_tokens: int = 0
    train_shards: int = 0
    validation_shards: int = 0


class ShardWriter:
    def __init__(self, directory: Path, split: str, shard_tokens: int):
        self.directory = directory
        self.split = split
        self.shard_tokens = shard_tokens
        self.buffer: list[int] = []
        self.paths: list[Path] = []
        self.total_tokens = 0
        directory.mkdir(parents=True, exist_ok=True)

    def append(self, tokens: list[int]) -> None:
        self.buffer.extend(tokens)
        while len(self.buffer) >= self.shard_tokens:
            self._flush(self.shard_tokens)

    def _flush(self, count: int | None = None) -> None:
        if not self.buffer:
            return
        take = len(self.buffer) if count is None else min(count, len(self.buffer))
        data = np.asarray(self.buffer[:take], dtype=np.uint32)
        del self.buffer[:take]
        path = self.directory / f"{self.split}-{len(self.paths):05d}.bin"
        data.tofile(path)
        self.paths.append(path)
        self.total_tokens += int(data.size)

    def finish(self) -> None:
        self._flush()


def prepare_pretraining_data(
    tokenizer: KokoroTokenizer,
    source_directories: list[Path],
    output_directory: Path,
    validation_fraction: float = 0.01,
    shard_tokens: int = 10_000_000,
    min_document_chars: int = 50,
    seed: int = 1337,
) -> PrepareStats:
    output_directory.mkdir(parents=True, exist_ok=True)
    for old in output_directory.glob("*.bin"):
        old.unlink()
    files: list[Path] = []
    for directory in source_directories:
        files.extend(discover_files(directory))
    if not files:
        raise ValueError("No source files found. Put text in data/raw or generate seed data.")

    stats = PrepareStats()
    seen_hashes: set[str] = set()
    train_writer = ShardWriter(output_directory, "train", shard_tokens)
    val_writer = ShardWriter(output_directory, "validation", shard_tokens)

    for source, text in iter_documents(files):
        stats.documents_seen += 1
        if len(text) < min_document_chars:
            continue
        digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
        if digest in seen_hashes:
            stats.duplicates_removed += 1
            continue
        seen_hashes.add(digest)
        stats.documents_kept += 1
        stats.characters_kept += len(text)
        tokens = tokenizer.encode(text, add_bos=True, add_eos=True)
        # Deterministic split based on document hash, independent of file order.
        bucket = int(digest[:8], 16) / 0xFFFFFFFF
        if bucket < validation_fraction:
            val_writer.append(tokens)
        else:
            train_writer.append(tokens)

    train_writer.finish()
    val_writer.finish()
    if not train_writer.paths:
        raise ValueError("No train shards were produced")
    if not val_writer.paths:
        # For tiny corpora, carve the final 1% from the training token stream.
        candidate = max(train_writer.paths, key=lambda path: path.stat().st_size)
        only = np.fromfile(candidate, dtype=np.uint32)
        count = max(8192, int(len(only) * max(validation_fraction, 0.10)))
        count = min(count, max(0, len(only) - 8192))
        if count > 0:
            validation = only[-count:]
            training = only[:-count]
            training.tofile(candidate)
            val_path = output_directory / "validation-00000.bin"
            validation.tofile(val_path)
            val_writer.paths.append(val_path)
            val_writer.total_tokens = len(validation)
            train_writer.total_tokens -= len(validation)

    stats.train_tokens = train_writer.total_tokens
    stats.validation_tokens = val_writer.total_tokens
    stats.train_shards = len(train_writer.paths)
    stats.validation_shards = len(val_writer.paths)
    manifest = {
        "format": "kokoro.uint32.shards.v1",
        "tokenizer_vocab_size": tokenizer.vocab_size,
        "validation_fraction": validation_fraction,
        "shard_tokens": shard_tokens,
        "stats": stats.__dict__,
        "train_shards": [path.name for path in train_writer.paths],
        "validation_shards": [path.name for path in val_writer.paths],
        "sources": [str(path) for path in files],
    }
    (output_directory / "manifest.json").write_text(
        json.dumps(manifest, indent=2), encoding="utf-8"
    )
    return stats


class RandomWindowDataset:
    """Memory-mapped random token windows across one or more shards."""

    def __init__(self, shard_paths: list[Path], sequence_length: int, seed: int = 1337):
        if not shard_paths:
            raise ValueError("No dataset shards found")
        self.sequence_length = sequence_length
        self.rng = random.Random(seed)
        self.shards = [np.memmap(path, dtype=np.uint32, mode="r") for path in shard_paths]
        self.usable = [max(0, len(shard) - sequence_length - 1) for shard in self.shards]
        if sum(self.usable) <= 0:
            raise ValueError("Dataset is shorter than the configured sequence length")
        self.weights = np.asarray(self.usable, dtype=np.float64)
        self.weights /= self.weights.sum()

    def sample(self, batch_size: int, device: torch.device) -> tuple[torch.Tensor, torch.Tensor]:
        xs: list[torch.Tensor] = []
        ys: list[torch.Tensor] = []
        choices = self.rng.choices(range(len(self.shards)), weights=self.weights, k=batch_size)
        for shard_index in choices:
            shard = self.shards[shard_index]
            start = self.rng.randrange(0, self.usable[shard_index])
            chunk = np.asarray(
                shard[start : start + self.sequence_length + 1], dtype=np.int64
            )
            tensor = torch.from_numpy(chunk)
            xs.append(tensor[:-1])
            ys.append(tensor[1:])
        return torch.stack(xs).to(device), torch.stack(ys).to(device)


def load_split_dataset(
    prepared_directory: Path,
    split: str,
    sequence_length: int,
    seed: int,
) -> RandomWindowDataset:
    paths = sorted(prepared_directory.glob(f"{split}-*.bin"))
    return RandomWindowDataset(paths, sequence_length=sequence_length, seed=seed)


class SFTDataset(torch.utils.data.Dataset):
    def __init__(self, path: Path, tokenizer: KokoroTokenizer, max_length: int):
        self.examples: list[tuple[list[int], list[int]]] = []
        for record in iter_jsonl(path):
            messages = record.get("messages")
            if not isinstance(messages, list) or not messages:
                continue
            ids, labels = tokenizer.render_sft(messages, max_length=max_length)
            if any(label != -100 for label in labels):
                self.examples.append((ids, labels))
        if not self.examples:
            raise ValueError(f"No valid SFT examples found in {path}")
        self.pad_id = tokenizer.ids.pad

    def __len__(self) -> int:
        return len(self.examples)

    def __getitem__(self, index: int):
        return self.examples[index]

    def collate(self, batch):
        max_length = max(len(ids) for ids, _ in batch)
        input_ids = torch.full((len(batch), max_length), self.pad_id, dtype=torch.long)
        labels = torch.full((len(batch), max_length), -100, dtype=torch.long)
        attention_mask = torch.zeros((len(batch), max_length), dtype=torch.bool)
        for row, (ids, target) in enumerate(batch):
            length = len(ids)
            input_ids[row, :length] = torch.tensor(ids, dtype=torch.long)
            labels[row, :length] = torch.tensor(target, dtype=torch.long)
            attention_mask[row, :length] = True
        return input_ids, labels, attention_mask


class PreferenceDataset(torch.utils.data.Dataset):
    def __init__(self, path: Path, tokenizer: KokoroTokenizer, max_length: int):
        self.examples: list[dict] = []
        for record in iter_jsonl(path):
            prompt = record.get("prompt")
            chosen = record.get("chosen")
            rejected = record.get("rejected")
            if not all(isinstance(value, str) for value in (prompt, chosen, rejected)):
                continue
            prompt_messages = [{"role": "user", "content": prompt}]
            chosen_messages = prompt_messages + [{"role": "assistant", "content": chosen}]
            rejected_messages = prompt_messages + [{"role": "assistant", "content": rejected}]
            chosen_ids, chosen_labels = tokenizer.render_sft(chosen_messages, max_length)
            rejected_ids, rejected_labels = tokenizer.render_sft(rejected_messages, max_length)
            self.examples.append(
                {
                    "chosen_ids": chosen_ids,
                    "chosen_labels": chosen_labels,
                    "rejected_ids": rejected_ids,
                    "rejected_labels": rejected_labels,
                }
            )
        if not self.examples:
            raise ValueError(f"No valid preference examples found in {path}")
        self.pad_id = tokenizer.ids.pad

    def __len__(self) -> int:
        return len(self.examples)

    def __getitem__(self, index: int):
        return self.examples[index]

    def collate(self, batch):
        def pad(side: str):
            max_length = max(len(item[f"{side}_ids"]) for item in batch)
            ids = torch.full((len(batch), max_length), self.pad_id, dtype=torch.long)
            labels = torch.full((len(batch), max_length), -100, dtype=torch.long)
            mask = torch.zeros((len(batch), max_length), dtype=torch.bool)
            for row, item in enumerate(batch):
                current_ids = item[f"{side}_ids"]
                current_labels = item[f"{side}_labels"]
                length = len(current_ids)
                ids[row, :length] = torch.tensor(current_ids)
                labels[row, :length] = torch.tensor(current_labels)
                mask[row, :length] = True
            return ids, labels, mask
        return (*pad("chosen"), *pad("rejected"))
