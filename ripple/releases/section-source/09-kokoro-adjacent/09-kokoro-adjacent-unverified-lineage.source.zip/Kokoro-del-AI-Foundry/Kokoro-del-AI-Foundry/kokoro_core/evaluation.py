from __future__ import annotations

import json
import math
import re
from collections import Counter
from pathlib import Path

import torch

from .data import load_split_dataset
from .generation import KokoroEngine
from .train import load_model_from_checkpoint
from .utils import autocast_context, choose_device, iter_jsonl, precision_dtype

WORD_RE = re.compile(r"\b[\w'-]+\b", re.UNICODE)


def ngrams(tokens: list[str], n: int):
    return [tuple(tokens[index : index + n]) for index in range(len(tokens) - n + 1)]


def text_metrics(text: str) -> dict:
    words = [word.lower() for word in WORD_RE.findall(text)]
    result = {"words": len(words)}
    for n in (1, 2, 3):
        items = ngrams(words, n)
        result[f"distinct_{n}"] = len(set(items)) / max(1, len(items))
        counts = Counter(items)
        repeated = sum(count - 1 for count in counts.values() if count > 1)
        result[f"repeat_{n}"] = repeated / max(1, len(items))
    return result


@torch.inference_mode()
def validation_perplexity(
    checkpoint: Path,
    prepared_directory: Path,
    batches: int = 50,
    batch_size: int = 4,
    device_arg: str = "auto",
) -> dict:
    device = choose_device(device_arg)
    model, _ = load_model_from_checkpoint(checkpoint, device)
    dataset = load_split_dataset(
        prepared_directory,
        "validation",
        model.config.max_seq_len,
        seed=99_991,
    )
    dtype = precision_dtype(device, "auto")
    model.eval()
    losses = []
    for _ in range(batches):
        x, y = dataset.sample(batch_size, device)
        with autocast_context(device, dtype):
            _, loss = model(x, y)
        losses.append(float(loss.item()))
    average = sum(losses) / len(losses)
    return {"validation_loss": average, "perplexity": math.exp(min(average, 20))}


def run_behavior_evaluation(
    checkpoint: Path,
    tokenizer_path: Path,
    memory_path: Path,
    evaluation_file: Path,
    output_file: Path,
    device: str = "auto",
) -> dict:
    engine = KokoroEngine(checkpoint, tokenizer_path, memory_path, device)
    results = []
    passed = 0
    total = 0
    try:
        for record in iter_jsonl(evaluation_file):
            prompt = str(record.get("prompt", "")).strip()
            if not prompt:
                continue
            engine.reset_context()
            answer = engine.generate(
                prompt,
                max_new_tokens=int(record.get("max_new_tokens", 180)),
                temperature=float(record.get("temperature", 0.2)),
                top_k=int(record.get("top_k", 30)),
                top_p=float(record.get("top_p", 0.9)),
                memory_limit=0,
            )
            lower = answer.lower()
            must_include = [str(item).lower() for item in record.get("must_include_any", [])]
            must_avoid = [str(item).lower() for item in record.get("must_avoid", [])]
            include_ok = not must_include or any(item in lower for item in must_include)
            avoid_ok = not any(item in lower for item in must_avoid)
            metric = text_metrics(answer)
            repetition_ok = metric["repeat_3"] <= float(record.get("max_repeat_3", 0.15))
            item_passed = include_ok and avoid_ok and repetition_ok
            total += 1
            passed += int(item_passed)
            results.append(
                {
                    "id": record.get("id", total),
                    "prompt": prompt,
                    "answer": answer,
                    "passed": item_passed,
                    "checks": {
                        "include_ok": include_ok,
                        "avoid_ok": avoid_ok,
                        "repetition_ok": repetition_ok,
                    },
                    "metrics": metric,
                }
            )
    finally:
        engine.close()
    report = {
        "passed": passed,
        "total": total,
        "pass_rate": passed / max(1, total),
        "results": results,
        "warning": "Keyword checks are regression signals, not proof of intelligence or safety.",
    }
    output_file.parent.mkdir(parents=True, exist_ok=True)
    output_file.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    return report
