# Changelog

## 2.0.0 — Psyche Daughterboard

- Renamed the project to **Kokoro del AI**.
- Added recursive parent/child frames with separate hypotheses, evidence, counterevidence, confidence, salience, and status.
- Added a persistent continuity capsule copied into every frame.
- Added drive, learned-constraint, executive-arbitration, conscious-workspace, and nonconscious-field functional analogues.
- Added SQLite storage for daughterboard state, cycles, frames, and integration.
- Added `/psyche` and `/frames` terminal commands and browser inspection endpoints.
- Added a daughterboard-only demo that runs before model training.
- Added deterministic self-tests and standard-library unit tests.
- Added science/fiction boundary documentation and research references.
- Expanded seed data, preference pairs, and evaluations for recursive continuity and non-looping behavior.
