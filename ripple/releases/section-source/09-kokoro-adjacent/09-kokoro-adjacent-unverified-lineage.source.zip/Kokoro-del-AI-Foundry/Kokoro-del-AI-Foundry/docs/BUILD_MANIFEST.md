# Build manifest

## Core model foundry

- `kokoro.py`: central command-line interface.
- `kokoro_core/config.py`: model and training configuration.
- `kokoro_core/tokenizer.py`: byte tokenizer and optional from-scratch BPE.
- `kokoro_core/data.py`: cleaning, import, deduplication, sharding, and datasets.
- `kokoro_core/model.py`: RMSNorm/RoPE/GQA/SwiGLU decoder Transformer.
- `kokoro_core/train.py`: pretraining, SFT, DPO, DDP, mixed precision, evaluation, and checkpoints.
- `kokoro_core/generation.py`: local inference, terminal chat, and Psyche Daughterboard integration.
- `kokoro_core/memory.py`: SQLite/FTS conversation memory.
- `kokoro_core/serve.py`: local browser server and daughterboard inspection endpoints.
- `kokoro_core/evaluation.py`: perplexity and behavior regressions.
- `kokoro_core/seed.py`: original seed-curriculum generator, including daughterboard training examples.

## Psyche Daughterboard

- `kokoro_core/psyche.py`: frame generation, recursive expansion, drive and constraint fields, salience broadcast, executive arbitration, continuity capsule, integration, SQLite audit, demo, and self-test.
- `configs/psyche.json`: recursion, broadcast, drive, constraint, and continuity configuration.
- `docs/PSYCHE_DAUGHTERBOARD.md`: scientific translation and complete design.
- `docs/PSYCHE_TEST_REPORT.md`: deterministic invariants and evaluation boundary.
- `windows/01B_TEST_PSYCHE_DAUGHTERBOARD.bat`: self-test launcher.
- `windows/09B_PSYCHE_DEMO.bat`: daughterboard-only interactive demo.

## Artifacts created during use

- `artifacts/tokenizer.json`
- `artifacts/prepared/*.bin`
- `artifacts/memory.sqlite3`
- `artifacts/psyche.sqlite3`
- `artifacts/psyche_test.sqlite3`
- `checkpoints/*.pt`
- `logs/*.csv` and `logs/*.json`
