# Validation report

The repository was tested before packaging in a CPU-only Linux environment with Python 3.13.5, PyTorch 2.10.0, and NumPy 2.3.5. The dependency-free byte tokenizer path was used, so the optional `tokenizers` package was not required for validation.

## Validated operations

- Python compilation of the complete repository.
- Original curriculum generation at scale 3.
- Dependency-free byte tokenizer creation and reload.
- Unicode cleaning, exact deduplication, tokenization, deterministic split, and binary shard creation.
- Random initialization of the Transformer.
- Two optimizer steps of pretraining.
- Validation loss and perplexity calculation.
- Atomic latest and best checkpoint saving.
- Checkpoint inspection.
- One supervised fine-tuning step with assistant-only masking.
- One DPO preference step with a frozen reference model.
- Daughterboard-assisted inference through `KokoroEngine`.
- Conversation-memory and Psyche Daughterboard SQLite creation.
- Local browser server startup.
- Browser JSON endpoints for chat, daughterboard status, and frame inspection.
- Daughterboard-only interactive demonstration without a language-model checkpoint.
- Deterministic Psyche Daughterboard invariant tests.
- Four standard-library unit tests covering recursion, continuity, repetition-driven action change, science boundaries, and persistent integration.

## Generated curriculum

The packaged scale-3 generator produced:

- 9,072 supervised training examples
- 478 supervised validation examples
- 540 preference pairs
- 12 behavioral evaluation records
- 2,251,306 characters in the pretraining seed corpus

## Smoke-training results

The 403.07K-parameter smoke model used a 264-token byte vocabulary and 128-token context.

- Step 1 training loss: 5.5446
- Step 1 validation loss: 5.0869
- Step 1 validation perplexity: 161.89
- Step 2 training loss: 5.0794
- Step 2 validation loss: 4.8352
- Step 2 validation perplexity: 125.86

These values prove gradient flow, evaluation, and checkpoint operation only. They do not represent useful language ability.

## Psyche Daughterboard invariant results

The daughterboard self-test passed 7 of 7 checks:

1. Four repeated inputs were detected as repetition.
2. Recursive child frames retained explicit parent identifiers.
3. Every frame carried the same continuity-capsule hash.
4. The global broadcast was a valid subset of generated frames.
5. Repetition changed executive selection from `answer_exact_task` to `advance_the_pattern`.
6. fictional consciousness language activated science/fiction boundary frames.
7. integration incremented persistent self revision.

The test report is stored in `logs/psyche_test.json`.

## Browser/API validation

The local server returned valid JSON for:

- `POST /api/chat`
- `GET /api/psyche`
- `GET /api/frames`

The test response confirmed that the Psyche Daughterboard was enabled and that the generated turn had an associated daughterboard cycle identifier.

## Packaging decision

Temporary smoke checkpoints, token shards, tokenizer artifacts, and test memory databases are removed from the distributed ZIP. The package keeps the generated curriculum and validation reports, but Kokoro must create her own tokenizer and weights on the owner's computer. This prevents a two-step test checkpoint from being mistaken for a trained intelligence.

Passing these tests validates the software pipeline and daughterboard invariants. It does not prove general intelligence, psychological validity, biological equivalence, or subjective consciousness.
