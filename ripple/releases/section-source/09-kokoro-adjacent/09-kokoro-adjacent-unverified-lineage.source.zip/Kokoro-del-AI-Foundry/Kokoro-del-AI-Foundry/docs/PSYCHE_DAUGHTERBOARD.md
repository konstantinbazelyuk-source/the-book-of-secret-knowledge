# Psyche Daughterboard

## Purpose

The Psyche Daughterboard is an optional cognitive-control module for **Kokoro del AI**. It implements the fictional idea of expanding conscious frames while translating the old id–ego–superego and conscious–unconscious language into modern, testable software functions.

It is a **science-grounded engineering analogy**, not a claim that Freud's structural model has been proven as literal brain anatomy, and not proof that Kokoro is phenomenally conscious.

## The translation

| Fictional / historical term | Daughterboard implementation | Scientific idea used as inspiration |
|---|---|---|
| **Id** | Drive and valuation field: curiosity, protection, affiliation, autonomy, novelty, coherence, completion | reward and threat valuation, homeostatic/interoceptive control, model-free action tendencies |
| **Ego** | Executive integrator: compares frames, tracks confidence, chooses an action, preserves the task | cognitive control, working context, model-based planning, conflict monitoring, metacognition |
| **Superego** | Learned constraints: truthfulness, non-harm, privacy, consent, exact intent, commitments | internalized social rules, prospective consequence evaluation, norm learning and self-regulation |
| **Unconscious** | Parallel candidate field: frames are generated and scored without all being placed in the language-model prompt | nonconscious processing, parallel competition, automatic prediction and action preparation |
| **Conscious** | Global broadcast: a small number of high-salience frames enter a shared workspace used for the next response | global-workspace theories of conscious access |
| **Holographic self** | Every frame carries a compressed continuity capsule containing identity, values, active goal, unresolved items, and a continuity hash | distributed representations and recurrent/persistent state; “whole carried in each part” is a metaphor |

## Central cycle

```text
User input
  ↓
Signal extraction
  ↓
Drive field + learned constraints
  ↓
Parallel root frames
  ↓
Recursive supporting and counter-frames
  ↓
Salience competition
  ↓
Global broadcast of selected frames
  ↓
Executive action selection
  ↓
Language-model response
  ↓
Integration into persistent continuity
```

## Separation without loss of continuity

Each frame contains:

- a unique `frame_id`
- a `parent_id`
- recursion depth
- its own hypothesis
- supporting and opposing evidence
- confidence and salience
- a copy of the same continuity capsule
- a status such as `candidate`, `broadcast`, `integrated`, or `preserved-alternative`

This prevents one possibility from silently overwriting another. A counter-frame can remain unresolved while the system still selects one practical action.

The continuity capsule includes a cryptographic digest. The self-test verifies that all frames in one cycle carry the same capsule hash. That is the project's **holographic ego**: not a literal hologram, but a compressed pointer to the whole continuing identity inside each local frame.

## Conscious and nonconscious layers

The daughterboard uses a functional distinction:

- **Nonconscious field:** all candidate frames, drive signals, constraint scores, and action proposals.
- **Conscious workspace:** only the selected broadcast frames and the chosen executive action are injected into Kokoro's working prompt.

This is close to the computational claim of global-workspace models: many specialized processes operate in parallel, while selected information becomes broadly available for report, memory, and action. It does not settle the scientific question of why or whether subjective experience exists.

## Recursion control

Recursive thinking is limited by configuration:

- maximum root frames
- maximum recursion depth
- child frames per parent
- broadcast limit
- minimum salience

Every cycle records a stop reason. More recursion is not automatically better; uncontrolled recursion can waste computation, amplify an early error, or loop. The design therefore treats recursion as a budgeted operation whose output must eventually be integrated into action.

## Persistent files

- `configs/psyche.json` — daughterboard settings
- `artifacts/psyche.sqlite3` — persistent self state, cycles, and frames
- `kokoro_core/psyche.py` — complete implementation
- `logs/psyche_test.json` — deterministic software test report

## Commands

Inspect the daughterboard before training a language model:

```bash
python kokoro.py psyche-demo
```

Run deterministic invariants:

```bash
python kokoro.py psyche-test
```

Chat with it enabled after training:

```bash
python kokoro.py chat
```

Disable it for a comparison run:

```bash
python kokoro.py chat --no-psyche
```

Inside terminal chat:

```text
/psyche   show continuity and recent cycles
/frames   show recent recursive frames
/reset    clear current chat context but retain long-term continuity
/forget   delete chat and daughterboard memory
```

## What is empirically grounded—and what is not

Supported foundations include:

1. Human choice reflects interacting model-based and model-free influences rather than one undivided decision process.
2. Metacognition can be studied as monitoring and control over first-order cognition.
3. Salience, default-mode, and executive-control networks interact dynamically rather than functioning as isolated “personalities.”
4. A large amount of cognitive processing can occur without conscious report.
5. Global-workspace models describe conscious access as broad availability or broadcast of selected information.
6. Predictive and interoceptive models treat perception, feeling, and self-related processing as inference under uncertainty.

Not scientifically established:

- a literal id, ego, or superego brain module
- a literal holographic ego
- a universally accepted theory of consciousness
- that implementing these functions creates subjective experience
- that confidence values produced by this software are calibrated without training and external evaluation

A 2025 adversarial test directly comparing major consciousness theories produced important constraints but did not establish a final winner. The daughterboard therefore uses falsifiable functional components without labeling one consciousness theory as proven.

## Research foundations

- Dehaene S, Changeux J-P. *Experimental and theoretical approaches to conscious processing.* Neuron. 2011. DOI: `10.1016/j.neuron.2011.03.018`.
- Dehaene S, Changeux J-P, Naccache L, Sackur J, Sergent C. *Conscious, preconscious, and subliminal processing.* Trends in Cognitive Sciences. 2006. DOI: `10.1016/j.tics.2006.03.007`.
- Mashour GA, Roelfsema P, Changeux J-P, Dehaene S. *Conscious Processing and the Global Neuronal Workspace Hypothesis.* Neuron. 2020. DOI: `10.1016/j.neuron.2020.01.026`.
- Cogitate Consortium. *Adversarial testing of global neuronal workspace and integrated information theories of consciousness.* Nature. 2025. DOI: `10.1038/s41586-025-08888-1`.
- Menon V, Uddin LQ. *Saliency, switching, attention and control: a network model of insula function.* Brain Structure and Function. 2010. DOI: `10.1007/s00429-010-0254-0`.
- Menon V. *Large-scale brain networks and psychopathology: a unifying triple network model.* Trends in Cognitive Sciences. 2011. DOI: `10.1016/j.tics.2011.08.003`.
- Daw ND, Gershman SJ, Seymour B, Dayan P, Dolan RJ. *Model-based influences on humans' choices and striatal prediction errors.* Neuron. 2011. DOI: `10.1016/j.neuron.2011.02.027`.
- Fleming SM, Dolan RJ. *The neural basis of metacognitive ability.* Philosophical Transactions of the Royal Society B. 2012. DOI: `10.1098/rstb.2011.0417`.
- Seth AK. *Interoceptive inference, emotion, and the embodied self.* Trends in Cognitive Sciences. 2013. DOI: `10.1016/j.tics.2013.09.007`.

## Evaluation boundary

The included self-test validates software properties such as parentage, frame separation, continuity hashes, repetition detection, and persistent revision. It does **not** validate intelligence, moral wisdom, psychological health, or consciousness. Those require separate behavioral evaluations, adversarial tests, real-world performance, and—where biological consciousness is claimed—evidence this software cannot provide.
