# Data guide

Model quality is bounded by data quality. More text is not automatically better.

## Use only material you may train on

Good categories include:

- your own writing, stories, lessons, corrections, and conversations;
- public-domain works in your jurisdiction;
- datasets whose license explicitly permits your intended use;
- open educational and software material with compatible attribution and share-alike obligations;
- original synthetic curricula that you inspect for accuracy and diversity.

Do not assume that because text is visible on the internet it is lawful to copy, redistribute, or train on. Keep a source and license record for every collection.

## Recommended corpus layers

1. **Language foundation:** diverse clean prose, dialogue, explanations, reference writing, and code.
2. **Kokoro identity:** the project's voice, directness, uncertainty, correction behavior, and exact-subject discipline.
3. **Character intelligence:** motives, beliefs, secrets, evolving relationships, refusals, independent action, and non-looping scene progression.
4. **Instruction data:** concrete tasks with ideal responses.
5. **Preference data:** chosen and rejected answers that clearly differ in usefulness.
6. **Evaluation holdout:** examples never placed in training.

## Quality checks

Before a serious run, inspect samples for:

- duplicated passages;
- broken encoding or markup;
- private information;
- contradictory instructions;
- factual errors;
- generated filler and repetitive templates;
- license uncertainty;
- overrepresentation of one voice or subject;
- train/evaluation leakage.

## Synthetic curriculum scale

`python kokoro.py seed-data --scale 3` regenerates the included curriculum. Larger values create more algorithmic arithmetic, character-agency, uncertainty, and preference examples. This is useful for curriculum experiments, but template-derived data must not crowd out diverse human-authored and verified material.

## Adding data

Place files under `data/raw`, then rebuild:

```bash
python kokoro.py train-tokenizer --config configs/baby.json --mode bpe
python kokoro.py prepare
```

Changing the tokenizer invalidates prepared token shards and existing model checkpoints. Train a new model after changing vocabulary.

## Scale discipline

Do not create a 300M-parameter model for a tiny corpus. A heavily undertrained large model can be worse and more expensive than a smaller model trained on enough high-quality tokens. Use `docs/SCALE_PLAN.md` to match model and data.
