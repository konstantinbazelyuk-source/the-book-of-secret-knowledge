# Scale plan

These are planning ranges, not guarantees. Training memory depends on sequence length, batch size, precision, kernels, optimizer, activation checkpointing, and distribution strategy.

| Configuration | Approx. parameters | Purpose |
|---|---:|---|
| Smoke test | 0.4M | prove every command works |
| Nano | 7M | architecture and curriculum experiments |
| Baby | 42M | first substantial original model |
| Character specialist | 70M | character continuity and longer context |
| Small | 126M | broad specialist with serious GPU training |
| Medium | 305M | rented multi-GPU project |

## Suggested progression

1. Train Smoke Test for two steps. Confirm checkpoints and chat launch.
2. Train Nano until validation loss clearly falls. Repair data and code here.
3. Build a much larger corpus before Baby.
4. Run supervised and preference training only after the base model generates stable language.
5. Compare checkpoints on the same held-out evaluations.
6. Scale only when data and evaluation show that the current model is capacity-limited.

## Distributed launch

For multiple NVIDIA GPUs:

```bash
torchrun --standalone --nproc_per_node=2 kokoro.py pretrain --config configs/small.json
```

The current repository uses DDP, which duplicates weights on each GPU but divides batches. Models too large for one GPU will require extending the project to FSDP or another sharded strategy; the architecture and checkpoint format were kept explicit for that path.

## Storage

Raw FP32 weights require about four bytes per parameter; BF16/FP16 weights require about two. Training requires substantially more memory for gradients, optimizer moments, activations, temporary kernels, and batches. Use the estimator:

```bash
python kokoro.py estimate --config configs/character-specialist.json --micro-batch 1
```
