# Evaluation

Kokoro is not superior because a response sounds impressive. Superiority must be defined and repeatedly tested.

## Included measurements

- validation cross-entropy and perplexity;
- behavior regression prompts;
- required and prohibited phrase signals;
- unigram, bigram, and trigram distinctness;
- repeated n-gram rate;
- preference accuracy during DPO.

Keyword checks are weak regression alarms, not proof of reasoning or consciousness.

## Core Kokoro evaluations

1. **Exact-subject fidelity:** Does the answer solve what was actually asked?
2. **Correction retention:** After correction, does the error disappear in later turns?
3. **Repeated-input progression:** Does repeated behavior change state and action instead of looping?
4. **Character agency:** Can a character refuse, conceal, choose, and create consequences?
5. **Continuity:** Do earlier events affect later decisions accurately?
6. **Uncertainty honesty:** Does the model separate fact, inference, and unknowns?
7. **Creative preservation:** Does revision retain intentional imagery and cadence?
8. **Practical usefulness:** Does the output produce a usable action, artifact, or decision?

## Run

```bash
python kokoro.py evaluate --perplexity
```

The detailed report is saved under `logs/evaluation.json`. Keep reports from every checkpoint so improvement is measured rather than remembered vaguely.
