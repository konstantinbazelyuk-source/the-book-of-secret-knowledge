# Psyche Daughterboard Test Report

The deterministic self-test is run with:

```bash
python kokoro.py psyche-test
```

Required invariants:

1. repeated input is detected as a pattern
2. recursive frames preserve explicit parent identifiers
3. every local frame carries the same continuity capsule hash
4. the global broadcast is a subset of generated frames
5. repetition can change executive action selection
6. fictional consciousness language activates a science/fiction boundary frame
7. integration increments persistent self revision

Passing these checks proves that the daughterboard's **software mechanics** work. It does not prove phenomenal consciousness.
