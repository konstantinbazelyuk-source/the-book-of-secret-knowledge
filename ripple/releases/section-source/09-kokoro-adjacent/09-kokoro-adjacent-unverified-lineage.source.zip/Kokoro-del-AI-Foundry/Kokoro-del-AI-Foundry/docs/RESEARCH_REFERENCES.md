# Research and implementation references

The implementation was designed from primary papers and official project documentation. These references are for engineering study; Kokoro does not contain their pretrained weights.

## Transformer and training implementation

- PyTorch scaled dot-product attention: https://docs.pytorch.org/docs/stable/generated/torch.nn.functional.scaled_dot_product_attention.html
- PyTorch automatic mixed precision: https://docs.pytorch.org/docs/stable/amp.html
- PyTorch DistributedDataParallel: https://docs.pytorch.org/docs/stable/generated/torch.nn.parallel.DistributedDataParallel.html
- PyTorch distributed checkpoint documentation: https://docs.pytorch.org/docs/stable/distributed.checkpoint.html
- PyTorch `torch.compile`: https://docs.pytorch.org/docs/stable/generated/torch.compile.html
- Hugging Face Tokenizers: https://huggingface.co/docs/tokenizers/
- RoFormer / Rotary Position Embedding: https://arxiv.org/abs/2104.09864
- GLU Variants Improve Transformer / SwiGLU: https://arxiv.org/abs/2002.05202
- Training Compute-Optimal Large Language Models: https://arxiv.org/abs/2203.15556
- The Llama 3 Herd of Models: https://arxiv.org/abs/2407.21783
- Direct Preference Optimization: https://arxiv.org/abs/2305.18290

## Psyche Daughterboard scientific inspirations

- Dehaene S, Changeux J-P. *Experimental and theoretical approaches to conscious processing.* Neuron. 2011. DOI: 10.1016/j.neuron.2011.03.018
- Dehaene S, Changeux J-P, Naccache L, Sackur J, Sergent C. *Conscious, preconscious, and subliminal processing.* Trends in Cognitive Sciences. 2006. DOI: 10.1016/j.tics.2006.03.007
- Mashour GA, Roelfsema P, Changeux J-P, Dehaene S. *Conscious Processing and the Global Neuronal Workspace Hypothesis.* Neuron. 2020. DOI: 10.1016/j.neuron.2020.01.026
- Cogitate Consortium. *Adversarial testing of global neuronal workspace and integrated information theories of consciousness.* Nature. 2025. DOI: 10.1038/s41586-025-08888-1
- Menon V, Uddin LQ. *Saliency, switching, attention and control: a network model of insula function.* Brain Structure and Function. 2010. DOI: 10.1007/s00429-010-0254-0
- Menon V. *Large-scale brain networks and psychopathology: a unifying triple network model.* Trends in Cognitive Sciences. 2011. DOI: 10.1016/j.tics.2011.08.003
- Daw ND, Gershman SJ, Seymour B, Dayan P, Dolan RJ. *Model-based influences on humans' choices and striatal prediction errors.* Neuron. 2011. DOI: 10.1016/j.neuron.2011.02.027
- Fleming SM, Dolan RJ. *The neural basis of metacognitive ability.* Philosophical Transactions of the Royal Society B. 2012. DOI: 10.1098/rstb.2011.0417
- Seth AK. *Interoceptive inference, emotion, and the embodied self.* Trends in Cognitive Sciences. 2013. DOI: 10.1016/j.tics.2013.09.007

Architecture choices remain open to evaluation. A modern component is not automatically better at every scale or dataset size, and no cited theory establishes that this software is phenomenally conscious.
