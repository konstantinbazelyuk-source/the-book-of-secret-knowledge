@echo off
cd /d "%~dp0.."
call .venv\Scripts\activate.bat
echo Starting Kokoro del AI locally with memory and the Psyche Daughterboard.
python kokoro.py serve
pause
