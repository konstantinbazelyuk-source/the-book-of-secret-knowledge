@echo off
cd /d "%~dp0.."
call .venv\Scripts\activate.bat
python kokoro.py psyche-test
pause
