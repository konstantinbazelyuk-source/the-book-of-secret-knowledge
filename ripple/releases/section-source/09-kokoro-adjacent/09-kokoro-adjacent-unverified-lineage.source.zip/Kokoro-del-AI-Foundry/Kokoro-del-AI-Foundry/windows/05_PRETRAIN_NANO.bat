@echo off
cd /d "%~dp0.."
call .venv\Scripts\activate.bat
echo Training Kokoro Nano from random weights.
echo Press Ctrl+C to stop. The latest completed checkpoint is preserved.
python kokoro.py pretrain --config configs\nano.json
pause
