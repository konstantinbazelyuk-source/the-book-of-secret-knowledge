@echo off
cd /d "%~dp0.."
call .venv\Scripts\activate.bat
echo Starting Kokoro del AI with the Psyche Daughterboard enabled.
echo Use /psyche or /frames to inspect it.
python kokoro.py chat
pause
