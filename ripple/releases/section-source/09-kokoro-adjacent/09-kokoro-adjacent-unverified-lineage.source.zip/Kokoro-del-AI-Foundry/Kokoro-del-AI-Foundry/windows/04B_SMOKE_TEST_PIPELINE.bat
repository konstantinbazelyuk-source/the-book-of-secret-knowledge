@echo off
cd /d "%~dp0.."
call .venv\Scripts\activate.bat
echo This trains only two steps to prove that training and checkpoints work.
python kokoro.py pretrain --config configs\smoke-test.json --steps 2
pause
