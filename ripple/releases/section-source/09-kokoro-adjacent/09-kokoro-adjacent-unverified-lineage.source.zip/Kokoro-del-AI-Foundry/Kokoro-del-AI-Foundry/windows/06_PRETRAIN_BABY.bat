@echo off
cd /d "%~dp0.."
call .venv\Scripts\activate.bat
echo Kokoro Baby is a much larger training run. Use a substantial corpus and preferably an NVIDIA GPU.
choice /M "Continue"
if errorlevel 2 exit /b 0
python kokoro.py pretrain --config configs\baby.json --gradient-checkpointing
pause
