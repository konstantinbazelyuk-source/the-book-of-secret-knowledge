@echo off
cd /d "%~dp0.."
call .venv\Scripts\activate.bat
echo Training Kokoro's own tokenizer from data\pretrain and data\raw...
python kokoro.py train-tokenizer --config configs\baby.json --mode auto
pause
