@echo off
cd /d "%~dp0.."
call .venv\Scripts\activate.bat
python kokoro.py sft --config configs\nano.json --steps 2000
pause
