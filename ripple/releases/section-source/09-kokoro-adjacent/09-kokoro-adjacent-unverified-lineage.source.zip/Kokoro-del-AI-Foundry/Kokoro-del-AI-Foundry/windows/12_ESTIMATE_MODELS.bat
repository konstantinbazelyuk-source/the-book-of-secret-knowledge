@echo off
cd /d "%~dp0.."
call .venv\Scripts\activate.bat
for %%C in (nano baby character-specialist small medium) do (
  echo ================= %%C =================
  python kokoro.py estimate --config configs\%%C.json --micro-batch 1
)
pause
