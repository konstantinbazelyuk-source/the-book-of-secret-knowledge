@echo off
cd /d "%~dp0.."
call .venv\Scripts\activate.bat
python kokoro.py seed-data --scale 3
pause
