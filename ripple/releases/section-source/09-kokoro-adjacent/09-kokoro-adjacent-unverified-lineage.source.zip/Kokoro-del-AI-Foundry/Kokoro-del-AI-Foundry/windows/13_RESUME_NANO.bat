@echo off
cd /d "%~dp0.."
call .venv\Scripts\activate.bat
python kokoro.py pretrain --config configs\nano.json --resume checkpoints\pretrain-latest.pt
pause
