@echo off
cd /d "%~dp0.."
call .venv\Scripts\activate.bat
python kokoro.py dpo --config configs\nano.json --steps 500
pause
