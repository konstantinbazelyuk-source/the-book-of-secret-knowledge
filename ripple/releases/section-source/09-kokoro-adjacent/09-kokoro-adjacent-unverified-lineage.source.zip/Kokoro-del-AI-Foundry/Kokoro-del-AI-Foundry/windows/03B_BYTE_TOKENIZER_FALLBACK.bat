@echo off
cd /d "%~dp0.."
call .venv\Scripts\activate.bat
echo Creating dependency-free UTF-8 byte tokenizer...
python kokoro.py train-tokenizer --config configs\nano.json --mode byte
pause
