from __future__ import annotations

import tempfile
from pathlib import Path
import unittest

from kokoro_core.psyche import PsycheBoard


class PsycheDaughterboardTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.config = Path(__file__).resolve().parents[1] / "configs" / "psyche.json"
        self.board = PsycheBoard(self.root / "psyche.sqlite3", self.config)

    def tearDown(self):
        self.board.close()
        self.temp.cleanup()

    def test_recursive_frames_share_continuity_without_identity_collapse(self):
        packet = self.board.reflect(
            "Hold two interpretations separately without losing continuity.", [], []
        )
        self.assertTrue(any(frame.parent_id for frame in packet.frames))
        hashes = {
            frame.continuity_capsule["continuity_hash"] for frame in packet.frames
        }
        self.assertEqual(len(hashes), 1)
        self.assertGreater(len({frame.frame_id for frame in packet.frames}), 1)

    def test_repetition_changes_executive_selection(self):
        history = []
        first = self.board.reflect("I stay silent.", history, [])
        for index in range(4):
            history.extend(
                [
                    {"role": "user", "content": "I stay silent."},
                    {"role": "assistant", "content": f"stage {index}"},
                ]
            )
        repeated = self.board.reflect("I stay silent.", history, [])
        self.assertNotEqual(first.selected_action.name, repeated.selected_action.name)
        self.assertEqual(repeated.selected_action.name, "advance_the_pattern")

    def test_scientific_boundary_is_broadcast(self):
        packet = self.board.reflect(
            "Prove the holographic ego and Freud's id are literal consciousness modules.",
            [],
            [],
        )
        frame_map = {frame.frame_id: frame for frame in packet.frames}
        broadcast_lenses = {
            frame_map[frame_id].lens for frame_id in packet.broadcast_frame_ids
        }
        self.assertTrue(
            {"fiction-science-bridge", "epistemic-boundary"} & broadcast_lenses
        )
        self.assertTrue(packet.metacognition["requires_external_verification"])

    def test_integration_persists_revision(self):
        packet = self.board.reflect("Build the complete daughterboard.", [], [])
        before = self.board.continuity_capsule()["self_revision"]
        self.board.integrate(packet, "The daughterboard is implemented and tested.")
        after = self.board.continuity_capsule()["self_revision"]
        self.assertEqual(after, before + 1)


if __name__ == "__main__":
    unittest.main()
