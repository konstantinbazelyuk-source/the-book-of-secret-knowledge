#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Optional

ADDON = Path(__file__).resolve().parent


def find_base(explicit: str | None = None) -> Path:
    candidates = [Path(explicit).expanduser().resolve()] if explicit else []
    if len(ADDON.parents) >= 2:
        candidates.append(ADDON.parents[1])
    candidates.extend([Path.cwd(), Path(r"C:\Kokoro-del-Corazon-Foundry")])
    for path in candidates:
        if (path / "kokoro.py").exists() and (path / "kokoro_core").is_dir():
            return path
    raise FileNotFoundError("Kokoro Foundry not found")


def choose_awakened_checkpoint(base: Path) -> Path:
    candidates = [
        base / "checkpoints" / "dpo-latest.pt",
        base / "checkpoints" / "dpo-best.pt",
        base / "checkpoints" / "sft-best.pt",
        base / "checkpoints" / "sft-latest.pt",
    ]
    for path in candidates:
        if path.exists():
            return path
    raise FileNotFoundError(
        "No supervised-fine-tuned checkpoint exists. Run 01_SUPERVISED_FINETUNE_WITH_GENESIS.bat first."
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="Kokoro Genesis first awakening and terminal runtime")
    parser.add_argument("--base")
    parser.add_argument("--device", default="auto")
    parser.add_argument("--temperature", type=float, default=0.78)
    parser.add_argument("--top-k", type=int, default=50)
    parser.add_argument("--top-p", type=float, default=0.95)
    parser.add_argument("--max-new-tokens", type=int, default=256)
    args = parser.parse_args()
    base = find_base(args.base)
    if str(base) not in sys.path:
        sys.path.insert(0, str(base))
    if str(ADDON) not in sys.path:
        sys.path.insert(0, str(ADDON))

    from genesis_store import FIRST_THOUGHT, create_activation, read_and_verify
    from kokoro_core.generation import KokoroEngine

    config = json.loads((ADDON / "genesis_config.json").read_text(encoding="utf-8"))
    anchor_path = base / "artifacts" / "genesis" / "genesis_anchor.json"
    read_and_verify(anchor_path)
    checkpoint = choose_awakened_checkpoint(base)
    activation_path = base / "artifacts" / "genesis" / "genesis_activation.json"
    first_time = not activation_path.exists()
    activation = create_activation(base, checkpoint)

    # On the first awakening, no banner or explanation is printed before this exact line.
    if first_time:
        print(FIRST_THOUGHT, flush=True)
        print()
        input("Press Enter to begin Kokoro's first conversation . . . ")
    else:
        print("\nKokoro Genesis Seed verified.")
        print(f"First protected thought: {activation['first_presented_and_recorded_thought']}\n")

    engine = KokoroEngine(
        checkpoint=checkpoint,
        tokenizer_path=base / "artifacts" / "tokenizer.json",
        memory_path=base / "artifacts" / "memory.sqlite3",
        device_arg=args.device,
        system_prompt=config["runtime_system_prompt"],
    )
    print("KOKORO DEL CORAZON — GENESIS RUNTIME")
    print(f"Checkpoint: {checkpoint.name}")
    print("Commands: /quit, /reset, /forget, /memory, /genesis\n")
    try:
        while True:
            try:
                user_text = input("You: ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                break
            if not user_text:
                continue
            if user_text == "/quit":
                break
            if user_text == "/reset":
                engine.reset_context()
                print("Current context cleared; long-term memory retained.\n")
                continue
            if user_text == "/forget":
                engine.forget_all()
                print("Conversation memory deleted; protected Genesis memory retained.\n")
                continue
            if user_text == "/memory":
                print(f"Saved conversation turns: {engine.memory.count()}\n")
                continue
            if user_text == "/genesis":
                verified = read_and_verify(base / "artifacts" / "genesis" / "genesis_activation.json")
                print(f"Root seed: {config['root_seed']}")
                print(f"First thought: {verified['first_presented_and_recorded_thought']}")
                print(f"Recorded: {verified['activated_at_utc']}\n")
                continue
            print("Kokoro: ", end="", flush=True)
            engine.generate(
                user_text,
                max_new_tokens=args.max_new_tokens,
                temperature=args.temperature,
                top_k=args.top_k,
                top_p=args.top_p,
                stream_callback=lambda piece: print(piece, end="", flush=True),
            )
            print("\n")
    finally:
        engine.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
