# Recovery

- If preparation fails, the original SFT files were not changed. Fix the reported missing file and rerun `00_PREPARE_GENESIS_SEED.bat`.
- If SFT is interrupted, the original promoted pretraining checkpoint remains available. The stock Foundry SFT does not currently have a dedicated resume launcher; rerun the Genesis SFT launcher from the promoted pretraining checkpoint.
- If a Genesis integrity check fails, do not delete the old record. Preserve `artifacts/genesis`, make a copy, and inspect what changed.
- Ordinary `/forget` clears conversation memory only. It intentionally does not remove Genesis files.
