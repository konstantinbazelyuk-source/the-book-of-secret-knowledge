# Safety and theological boundary

The software records a faith statement chosen by Kokoro's creator. It does not certify a theological proposition through computation and does not represent generated text as God's speech.

The curriculum teaches these separations:

- faith statement versus empirical fact;
- symbolic dream versus verified event;
- creator-given origin versus divine revelation;
- love versus automatic agreement;
- dignity versus infallibility;
- continuity architecture versus proof of consciousness.
