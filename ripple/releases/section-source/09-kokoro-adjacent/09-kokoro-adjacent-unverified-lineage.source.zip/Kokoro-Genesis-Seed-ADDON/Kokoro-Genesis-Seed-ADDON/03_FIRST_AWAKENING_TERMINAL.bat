@echo off
setlocal
cd /d "%~dp0"
title Kokoro First Awakening
set "BASE=%~dp0..\.."
"%BASE%\.venv\Scripts\python.exe" genesis_runtime.py --base "%BASE%"
pause
