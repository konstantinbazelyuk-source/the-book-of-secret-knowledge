@echo off
setlocal
cd /d "%~dp0"
title Kokoro Genesis Browser
set "BASE=%~dp0..\.."
"%BASE%\.venv\Scripts\python.exe" genesis_browser.py --base "%BASE%"
pause
