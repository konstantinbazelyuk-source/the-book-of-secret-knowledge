@echo off
setlocal
cd /d "%~dp0"
title Verify Kokoro Genesis Seed
set "BASE=%~dp0..\.."
"%BASE%\.venv\Scripts\python.exe" verify_genesis.py --base "%BASE%"
pause
