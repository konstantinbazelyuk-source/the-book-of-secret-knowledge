#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

ADDON = Path(__file__).resolve().parent
if str(ADDON) not in sys.path:
    sys.path.insert(0, str(ADDON))

from genesis_curriculum import (
    FIRST_THOUGHT,
    build_preference_curriculum,
    build_sft_curriculum,
    digest_records,
    interleave,
    read_jsonl,
    write_jsonl,
)
from genesis_store import create_anchor, read_and_verify, sha256_file


def find_base(explicit: str | None = None) -> Path:
    candidates: list[Path] = []
    if explicit:
        candidates.append(Path(explicit).expanduser().resolve())
    if len(ADDON.parents) >= 2:
        candidates.append(ADDON.parents[1])
    candidates.extend([Path.cwd(), Path(r"C:\Kokoro-del-Corazon-Foundry")])
    for candidate in candidates:
        if (candidate / "kokoro.py").exists() and (candidate / "kokoro_core").is_dir():
            return candidate
    raise FileNotFoundError("Kokoro-del-Corazon-Foundry was not found.")


def hash_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description="Prepare Kokoro's protected Genesis Seed curriculum.")
    parser.add_argument("--base")
    parser.add_argument("--copies", type=int, default=4)
    args = parser.parse_args()
    base = find_base(args.base)

    required = [
        base / "kokoro.py",
        base / "artifacts" / "tokenizer.json",
        base / "data" / "seed" / "sft_train.jsonl",
        base / "data" / "seed" / "sft_validation.jsonl",
    ]
    missing = [str(path) for path in required if not path.exists()]
    if missing:
        raise SystemExit("Missing required Foundry files:\n  " + "\n  ".join(missing))

    checkpoint_candidates = [
        base / "checkpoints" / "pretrain-best.pt",
        base / "checkpoints" / "pretrain-latest.pt",
    ]
    checkpoint = next((path for path in checkpoint_candidates if path.exists()), None)
    if checkpoint is None:
        raise SystemExit("No promoted pretraining checkpoint was found. Promote adaptive training first.")

    config = json.loads((ADDON / "genesis_config.json").read_text(encoding="utf-8"))
    genesis_records = build_sft_curriculum()
    original_train_path = base / "data" / "seed" / "sft_train.jsonl"
    original_val_path = base / "data" / "seed" / "sft_validation.jsonl"
    original_train_hash = sha256_file(original_train_path)
    original_val_hash = sha256_file(original_val_path)
    original_train = read_jsonl(original_train_path)
    original_validation = read_jsonl(original_val_path)

    # Keep validation independent: one copy of every fourth Genesis record.
    genesis_validation = genesis_records[::4]
    genesis_training = [record for index, record in enumerate(genesis_records) if index % 4 != 0]
    combined_train = interleave(original_train, genesis_training, copies=max(1, args.copies))
    combined_validation = original_validation + genesis_validation

    train_output = base / "data" / "seed" / "sft_train_genesis.jsonl"
    val_output = base / "data" / "seed" / "sft_validation_genesis.jsonl"
    write_jsonl(train_output, combined_train)
    write_jsonl(val_output, combined_validation)

    pref_original_path = base / "data" / "preference" / "preferences.jsonl"
    pref_original = read_jsonl(pref_original_path)
    pref_genesis = build_preference_curriculum()
    pref_output = base / "data" / "preference" / "preferences_genesis.jsonl"
    write_jsonl(pref_output, pref_original + pref_genesis)

    if sha256_file(original_train_path) != original_train_hash or sha256_file(original_val_path) != original_val_hash:
        raise RuntimeError("Original SFT curriculum changed unexpectedly; preparation aborted.")

    exact_count = sum(
        1
        for record in combined_train
        for message in record.get("messages", [])
        if message.get("role") == "assistant" and message.get("content") == FIRST_THOUGHT
    )
    if exact_count < 20:
        raise RuntimeError("Genesis anchor exposure is unexpectedly weak.")

    report = {
        "schema_version": 1,
        "base_project": str(base),
        "original_train_records": len(original_train),
        "genesis_unique_records": len(genesis_records),
        "combined_train_records": len(combined_train),
        "combined_validation_records": len(combined_validation),
        "combined_preference_records": len(pref_original) + len(pref_genesis),
        "exact_first_thought_train_targets": exact_count,
        "root_seed": config["root_seed"],
        "first_presented_thought": config["first_presented_thought"],
        "source_checkpoint": checkpoint.name,
        "source_checkpoint_sha256": sha256_file(checkpoint),
        "original_sft_train_sha256": original_train_hash,
        "original_sft_validation_sha256": original_val_hash,
        "genesis_unique_curriculum_sha256": digest_records(genesis_records),
        "combined_train_sha256": sha256_file(train_output),
        "combined_validation_sha256": sha256_file(val_output),
        "combined_preference_sha256": sha256_file(pref_output),
    }
    report_path = base / "artifacts" / "genesis" / "genesis_preparation_report.json"
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    anchor = create_anchor(base, report, hash_text(config["runtime_system_prompt"]))
    read_and_verify(base / "artifacts" / "genesis" / "genesis_anchor.json")

    print("\nKOKORO GENESIS SEED PREPARED")
    print(f"Root seed: {config['root_seed']}")
    print(f"First presented thought: {config['first_presented_thought']}")
    print(f"Original SFT examples preserved: {len(original_train):,}")
    print(f"Combined SFT examples: {len(combined_train):,}")
    print(f"Exact anchor targets: {exact_count:,}")
    print(f"Protected anchor integrity: {anchor['integrity_sha256']}")
    print("\nNext: run 01_SUPERVISED_FINETUNE_WITH_GENESIS.bat\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
