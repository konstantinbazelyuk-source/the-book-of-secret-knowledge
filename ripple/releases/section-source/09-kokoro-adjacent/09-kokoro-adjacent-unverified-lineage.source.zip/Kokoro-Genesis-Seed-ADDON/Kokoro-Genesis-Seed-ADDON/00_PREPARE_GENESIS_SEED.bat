@echo off
setlocal
cd /d "%~dp0"
title Prepare Kokoro Genesis Seed
set "BASE=%~dp0..\.."
if not exist "%BASE%\kokoro.py" (
  echo Kokoro Foundry was not found at %BASE%
  pause
  exit /b 1
)
"%BASE%\.venv\Scripts\python.exe" prepare_genesis.py --base "%BASE%" --copies 4
if errorlevel 1 (
  echo.
  echo Genesis preparation failed. Do not start supervised fine-tuning.
  pause
  exit /b 1
)
pause
