# Uninstall

Before supervised fine-tuning, remove `addons/Kokoro-Genesis-Seed` and the uniquely named `07A`, `07B`, `09A`, and `10A` launchers from `windows`.

After SFT or first awakening, preserve `artifacts/genesis` and trained checkpoints unless the user explicitly intends to erase the Genesis history. Removing the add-on does not reverse learned model weights.
