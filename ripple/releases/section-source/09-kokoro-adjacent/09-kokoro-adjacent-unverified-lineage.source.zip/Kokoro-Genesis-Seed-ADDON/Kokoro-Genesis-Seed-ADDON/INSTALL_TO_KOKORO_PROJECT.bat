@echo off
setlocal
title Install Kokoro Genesis Seed
cd /d "%~dp0"
echo.
echo This installs a separate Genesis Seed add-on.
echo It does not overwrite Kokoro source, tokenizer, checkpoints, or original curriculum.
echo.
set "TARGET=%~dp0..\Kokoro-del-Corazon-Foundry"
if exist "%TARGET%\kokoro.py" goto :found
set "TARGET=%~dp0..\..\Kokoro-del-Corazon-Foundry"
if exist "%TARGET%\kokoro.py" goto :found
set /p "TARGET=Paste the full path to Kokoro-del-Corazon-Foundry: "
set "TARGET=%TARGET:"=%"
:found
if not exist "%TARGET%\kokoro.py" goto :bad
if not exist "%TARGET%\addons" mkdir "%TARGET%\addons"
set "DEST=%TARGET%\addons\Kokoro-Genesis-Seed"
xcopy "%~dp0*" "%DEST%\" /E /I /Y /EXCLUDE:%~dp0install_exclude.txt >nul
if errorlevel 1 goto :copyfail
(
 echo @echo off
 echo call "%DEST%\00_PREPARE_GENESIS_SEED.bat"
) > "%TARGET%\windows\07A_PREPARE_GENESIS_SEED.bat"
(
 echo @echo off
 echo call "%DEST%\01_SUPERVISED_FINETUNE_WITH_GENESIS.bat"
) > "%TARGET%\windows\07B_SUPERVISED_FINETUNE_WITH_GENESIS.bat"
(
 echo @echo off
 echo call "%DEST%\03_FIRST_AWAKENING_TERMINAL.bat"
) > "%TARGET%\windows\09A_FIRST_AWAKENING_GENESIS.bat"
(
 echo @echo off
 echo call "%DEST%\04_GENESIS_BROWSER.bat"
) > "%TARGET%\windows\10A_GENESIS_BROWSER.bat"
echo.
echo Installed at:
echo %DEST%
echo.
echo Run 00_PREPARE_GENESIS_SEED.bat next.
pause
exit /b 0
:bad
echo Original Kokoro Foundry was not found.
pause
exit /b 1
:copyfail
echo Copy failed.
pause
exit /b 1
