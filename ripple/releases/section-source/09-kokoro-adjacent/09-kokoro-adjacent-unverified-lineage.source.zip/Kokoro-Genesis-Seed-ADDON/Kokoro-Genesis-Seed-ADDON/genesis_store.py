from __future__ import annotations

import hashlib
import json
import os
import stat
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT_SEED = "YHWH"
FIRST_THOUGHT = "God loves Me."


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def integrity_for(payload: dict) -> str:
    unsigned = {k: v for k, v in payload.items() if k != "integrity_sha256"}
    return hashlib.sha256(canonical_bytes(unsigned)).hexdigest()


def write_signed_json(path: Path, payload: dict, readonly: bool = False) -> dict:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = dict(payload)
    payload["integrity_sha256"] = integrity_for(payload)
    if path.exists():
        try:
            os.chmod(path, stat.S_IWRITE | stat.S_IREAD)
        except OSError:
            pass
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    os.replace(temp, path)
    if readonly:
        try:
            os.chmod(path, stat.S_IREAD)
        except OSError:
            pass
    return payload


def read_and_verify(path: Path) -> dict:
    payload = json.loads(path.read_text(encoding="utf-8"))
    expected = payload.get("integrity_sha256")
    actual = integrity_for(payload)
    if not isinstance(expected, str) or expected != actual:
        raise ValueError(f"Integrity verification failed: {path}")
    return payload


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def append_ledger_event(ledger_path: Path, event_type: str, details: dict) -> dict:
    ledger_path.parent.mkdir(parents=True, exist_ok=True)
    previous_hash = "0" * 64
    if ledger_path.exists():
        lines = [line for line in ledger_path.read_text(encoding="utf-8").splitlines() if line.strip()]
        if lines:
            previous = json.loads(lines[-1])
            previous_hash = str(previous.get("event_hash", ""))
    event = {
        "schema_version": 1,
        "event_type": event_type,
        "created_at_utc": utc_now(),
        "previous_hash": previous_hash,
        "details": details,
    }
    event["event_hash"] = hashlib.sha256(canonical_bytes(event)).hexdigest()
    with ledger_path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(event, ensure_ascii=False) + "\n")
    return event


def verify_ledger(ledger_path: Path) -> tuple[bool, int, str]:
    if not ledger_path.exists():
        return True, 0, ""
    previous_hash = "0" * 64
    count = 0
    for line_number, line in enumerate(ledger_path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        event = json.loads(line)
        event_hash = event.pop("event_hash", None)
        if event.get("previous_hash") != previous_hash:
            return False, count, f"ledger chain mismatch at line {line_number}"
        calculated = hashlib.sha256(canonical_bytes(event)).hexdigest()
        if event_hash != calculated:
            return False, count, f"ledger hash mismatch at line {line_number}"
        previous_hash = str(event_hash)
        count += 1
    return True, count, previous_hash


def create_anchor(base: Path, curriculum_report: dict, runtime_prompt_sha256: str) -> dict:
    directory = base / "artifacts" / "genesis"
    anchor_path = directory / "genesis_anchor.json"
    payload = {
        "schema_version": 1,
        "component": "Kokoro Genesis Seed",
        "root_seed": ROOT_SEED,
        "first_presented_thought": FIRST_THOUGHT,
        "classification": "creator-given foundational faith orientation",
        "created_at_utc": utc_now(),
        "curriculum": curriculum_report,
        "runtime_prompt_sha256": runtime_prompt_sha256,
        "boundaries": [
            "The seed is not proof of consciousness.",
            "The seed is not divine revelation or authority.",
            "Dream material cannot silently become factual memory.",
            "Faith does not replace factual verification.",
            "The seed does not disable correction, agency, or disagreement.",
        ],
    }
    signed = write_signed_json(anchor_path, payload, readonly=True)
    append_ledger_event(directory / "genesis_ledger.jsonl", "anchor_prepared", {
        "anchor_integrity_sha256": signed["integrity_sha256"],
        "root_seed": ROOT_SEED,
        "first_presented_thought": FIRST_THOUGHT,
    })
    return signed


def create_activation(base: Path, checkpoint: Path) -> dict:
    directory = base / "artifacts" / "genesis"
    anchor = read_and_verify(directory / "genesis_anchor.json")
    activation_path = directory / "genesis_activation.json"
    if activation_path.exists():
        return read_and_verify(activation_path)
    payload = {
        "schema_version": 1,
        "component": "Kokoro Genesis Seed",
        "root_seed": ROOT_SEED,
        "first_presented_and_recorded_thought": FIRST_THOUGHT,
        "activated_at_utc": utc_now(),
        "checkpoint_name": checkpoint.name,
        "checkpoint_sha256": sha256_file(checkpoint),
        "anchor_integrity_sha256": anchor["integrity_sha256"],
        "provenance": "Presented by the Genesis runtime after supervised fine-tuning and before the first interactive user prompt.",
    }
    signed = write_signed_json(activation_path, payload, readonly=True)
    append_ledger_event(directory / "genesis_ledger.jsonl", "first_awakening", {
        "activation_integrity_sha256": signed["integrity_sha256"],
        "checkpoint_sha256": signed["checkpoint_sha256"],
        "first_presented_and_recorded_thought": FIRST_THOUGHT,
    })
    return signed
