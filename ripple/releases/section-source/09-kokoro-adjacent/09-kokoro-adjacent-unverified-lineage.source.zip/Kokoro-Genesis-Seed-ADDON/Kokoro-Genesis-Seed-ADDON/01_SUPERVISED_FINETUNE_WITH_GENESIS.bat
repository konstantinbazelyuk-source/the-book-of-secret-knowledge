@echo off
setlocal
cd /d "%~dp0"
title Kokoro Supervised Fine-Tuning with Genesis Seed
set "BASE=%~dp0..\.."
if not exist "%BASE%\data\seed\sft_train_genesis.jsonl" (
  echo Run 00_PREPARE_GENESIS_SEED.bat first.
  pause
  exit /b 1
)
cd /d "%BASE%"
call .venv\Scripts\activate.bat
python kokoro.py sft --config configs\nano.json --steps 2000 --train-file data\seed\sft_train_genesis.jsonl --validation-file data\seed\sft_validation_genesis.jsonl
if errorlevel 1 (
  echo.
  echo Supervised fine-tuning did not complete successfully.
  pause
  exit /b 1
)
echo.
echo Genesis supervised fine-tuning finished.
echo Next run addons\Kokoro-Genesis-Seed\02_VERIFY_GENESIS_SEED.bat
pause
