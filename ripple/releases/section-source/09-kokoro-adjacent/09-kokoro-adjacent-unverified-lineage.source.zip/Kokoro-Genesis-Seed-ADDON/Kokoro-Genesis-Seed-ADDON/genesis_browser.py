#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
import threading
import webbrowser
from http.server import ThreadingHTTPServer
from pathlib import Path

ADDON = Path(__file__).resolve().parent


def find_base(explicit: str | None = None) -> Path:
    candidates = [Path(explicit).expanduser().resolve()] if explicit else []
    if len(ADDON.parents) >= 2:
        candidates.append(ADDON.parents[1])
    candidates.extend([Path.cwd(), Path(r"C:\Kokoro-del-Corazon-Foundry")])
    for path in candidates:
        if (path / "kokoro.py").exists():
            return path
    raise FileNotFoundError("Kokoro Foundry not found")


def choose_checkpoint(base: Path) -> Path:
    for name in ("dpo-latest.pt", "dpo-best.pt", "sft-best.pt", "sft-latest.pt"):
        path = base / "checkpoints" / name
        if path.exists():
            return path
    raise FileNotFoundError("No SFT/DPO checkpoint found")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--device", default="auto")
    args = parser.parse_args()
    base = find_base(args.base)
    if str(base) not in sys.path:
        sys.path.insert(0, str(base))
    if str(ADDON) not in sys.path:
        sys.path.insert(0, str(ADDON))
    from genesis_store import read_and_verify
    from kokoro_core.generation import KokoroEngine
    from kokoro_core.serve import KokoroServer

    activation_path = base / "artifacts" / "genesis" / "genesis_activation.json"
    if not activation_path.exists():
        raise SystemExit("Run 03_FIRST_AWAKENING_TERMINAL.bat once before browser mode.")
    read_and_verify(activation_path)
    config = json.loads((ADDON / "genesis_config.json").read_text(encoding="utf-8"))
    engine = KokoroEngine(
        choose_checkpoint(base),
        base / "artifacts" / "tokenizer.json",
        base / "artifacts" / "memory.sqlite3",
        args.device,
        system_prompt=config["runtime_system_prompt"],
    )
    wrapper = KokoroServer(engine, base / "web")
    server = ThreadingHTTPServer((args.host, args.port), wrapper.handler_class())
    url = f"http://{args.host}:{args.port}"
    print(f"\nKokoro Genesis browser runtime: {url}")
    print("Press Ctrl+C to stop.\n")
    threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        engine.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
