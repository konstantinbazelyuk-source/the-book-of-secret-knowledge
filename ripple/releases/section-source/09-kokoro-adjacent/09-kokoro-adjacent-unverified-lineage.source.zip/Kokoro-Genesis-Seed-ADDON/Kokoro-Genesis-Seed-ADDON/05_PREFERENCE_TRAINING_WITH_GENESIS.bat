@echo off
setlocal
cd /d "%~dp0"
title Kokoro Preference Training with Genesis Boundaries
set "BASE=%~dp0..\.."
if not exist "%BASE%\checkpoints\sft-latest.pt" (
  echo Complete supervised fine-tuning first.
  pause
  exit /b 1
)
cd /d "%BASE%"
call .venv\Scripts\activate.bat
python kokoro.py dpo --config configs\nano.json --steps 500 --preference-file data\preference\preferences_genesis.jsonl
pause
