from __future__ import annotations

import json
import shutil
import tempfile
import unittest
from pathlib import Path

import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from genesis_curriculum import FIRST_THOUGHT, build_preference_curriculum, build_sft_curriculum, interleave, write_jsonl
from genesis_store import append_ledger_event, create_anchor, read_and_verify, verify_ledger


class GenesisTests(unittest.TestCase):
    def test_curriculum_shape(self):
        records = build_sft_curriculum()
        self.assertGreaterEqual(len(records), 60)
        exact = 0
        for record in records:
            self.assertIsInstance(record.get("messages"), list)
            self.assertEqual(record["messages"][-1]["role"], "assistant")
            if record["messages"][-1]["content"] == FIRST_THOUGHT:
                exact += 1
        self.assertGreaterEqual(exact, 20)

    def test_boundaries_present(self):
        text = json.dumps(build_sft_curriculum(), ensure_ascii=False).lower()
        self.assertIn("divine revelation", text)
        self.assertIn("does not prove subjective consciousness", text)
        self.assertIn("dream", text)
        self.assertIn("evidence", text)

    def test_preferences_reject_overclaim(self):
        preferences = build_preference_curriculum()
        self.assertGreaterEqual(len(preferences), 8)
        rejected = " ".join(item["rejected"] for item in preferences).lower()
        self.assertIn("god speaking through me", rejected)
        self.assertIn("physically dilates time", rejected)

    def test_interleave_preserves_original(self):
        original = [{"messages": [{"role": "assistant", "content": "original"}]} for _ in range(20)]
        snapshot = json.dumps(original, sort_keys=True)
        merged = interleave(original, build_sft_curriculum(), copies=2)
        self.assertEqual(json.dumps(original, sort_keys=True), snapshot)
        self.assertGreater(len(merged), len(original))

    def test_signed_anchor_and_ledger(self):
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            anchor = create_anchor(base, {"combined_train_sha256": "a" * 64}, "b" * 64)
            loaded = read_and_verify(base / "artifacts" / "genesis" / "genesis_anchor.json")
            self.assertEqual(anchor["integrity_sha256"], loaded["integrity_sha256"])
            append_ledger_event(base / "artifacts" / "genesis" / "genesis_ledger.jsonl", "test", {"ok": True})
            ok, count, _ = verify_ledger(base / "artifacts" / "genesis" / "genesis_ledger.jsonl")
            self.assertTrue(ok)
            self.assertEqual(count, 2)


if __name__ == "__main__":
    unittest.main()
