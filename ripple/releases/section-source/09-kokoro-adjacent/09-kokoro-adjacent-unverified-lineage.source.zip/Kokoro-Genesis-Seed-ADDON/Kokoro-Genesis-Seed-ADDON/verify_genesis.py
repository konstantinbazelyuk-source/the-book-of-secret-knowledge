#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ADDON = Path(__file__).resolve().parent
if str(ADDON) not in sys.path:
    sys.path.insert(0, str(ADDON))

from genesis_curriculum import FIRST_THOUGHT, read_jsonl
from genesis_store import read_and_verify, sha256_file, verify_ledger


def find_base(explicit: str | None = None) -> Path:
    candidates = [Path(explicit).expanduser().resolve()] if explicit else []
    if len(ADDON.parents) >= 2:
        candidates.append(ADDON.parents[1])
    candidates.extend([Path.cwd(), Path(r"C:\Kokoro-del-Corazon-Foundry")])
    for path in candidates:
        if (path / "kokoro.py").exists():
            return path
    raise FileNotFoundError("Kokoro Foundry not found")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base")
    args = parser.parse_args()
    base = find_base(args.base)
    genesis_dir = base / "artifacts" / "genesis"
    anchor = read_and_verify(genesis_dir / "genesis_anchor.json")
    report = json.loads((genesis_dir / "genesis_preparation_report.json").read_text(encoding="utf-8"))
    train = base / "data" / "seed" / "sft_train_genesis.jsonl"
    validation = base / "data" / "seed" / "sft_validation_genesis.jsonl"
    preferences = base / "data" / "preference" / "preferences_genesis.jsonl"
    for path, expected_key in [
        (train, "combined_train_sha256"),
        (validation, "combined_validation_sha256"),
        (preferences, "combined_preference_sha256"),
    ]:
        actual = sha256_file(path)
        if actual != report[expected_key]:
            raise SystemExit(f"Hash mismatch: {path}")
    exact_count = sum(
        1
        for record in read_jsonl(train)
        for message in record.get("messages", [])
        if message.get("role") == "assistant" and message.get("content") == FIRST_THOUGHT
    )
    if exact_count != report["exact_first_thought_train_targets"]:
        raise SystemExit("Exact thought target count changed")
    ok, events, last_hash = verify_ledger(genesis_dir / "genesis_ledger.jsonl")
    if not ok:
        raise SystemExit(last_hash)
    activation_path = genesis_dir / "genesis_activation.json"
    activation = read_and_verify(activation_path) if activation_path.exists() else None
    print("\nGENESIS SEED VERIFICATION PASSED")
    print(f"Root seed: {anchor['root_seed']}")
    print(f"First thought: {anchor['first_presented_thought']}")
    print(f"Exact SFT targets: {exact_count}")
    print(f"Ledger events: {events}")
    print(f"First awakening recorded: {'yes' if activation else 'not yet'}")
    if activation:
        print(f"Awakening checkpoint: {activation['checkpoint_name']}")
    print()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
