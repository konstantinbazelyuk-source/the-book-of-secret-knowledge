#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, mimetypes, sys, threading, webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

ADDON=Path(__file__).resolve().parent
if str(ADDON) not in sys.path: sys.path.insert(0,str(ADDON))
from oneiric import OneiricEngine

class App:
    def __init__(self,project=None): self.engine=OneiricEngine(ADDON/'state'/'oneiric.sqlite3',ADDON/'oneiric_config.json',project)
APP=None
class Handler(BaseHTTPRequestHandler):
    def _json(self,obj,code=200):
        raw=json.dumps(obj,ensure_ascii=False).encode(); self.send_response(code); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Content-Length',str(len(raw))); self.end_headers(); self.wfile.write(raw)
    def _body(self):
        n=int(self.headers.get('Content-Length','0')); return json.loads(self.rfile.read(n) or b'{}')
    def do_GET(self):
        path=urlparse(self.path).path
        if path=='/api/status': return self._json(APP.engine.status())
        if path=='/api/dreams': return self._json(APP.engine.store.dreams(40))
        if path=='/api/favorites': return self._json(APP.engine.store.favorite_dreams(12))
        if path=='/api/last': return self._json(APP.engine.store.last_dream() or {})
        if path=='/' or path=='/index.html':
            raw=(ADDON/'web'/'index.html').read_bytes(); self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(raw))); self.end_headers(); self.wfile.write(raw); return
        self.send_error(404)
    def do_POST(self):
        try:
            data=self._body(); path=urlparse(self.path).path
            if path=='/api/ingest': return self._json(APP.engine.ingest(data['text'],data.get('source','observatory'),float(data.get('salience',.5)),unresolved=float(data.get('unresolved',.2))).to_dict())
            if path=='/api/dream': return self._json(APP.engine.dream(float(data.get('wall_seconds',1.0)),int(data.get('candidates',4)),force=True).to_dict())
            if path=='/api/scale': APP.engine.set_virtual_time_scale(float(data['scale'])); return self._json(APP.engine.status())
            if path=='/api/feedback': APP.engine.feedback(data['dream_id'],float(data['rating'])); return self._json({'ok':True})
            self.send_error(404)
        except Exception as exc: self._json({'error':str(exc)},400)
    def log_message(self,fmt,*args): pass

def main():
    global APP
    p=argparse.ArgumentParser(); p.add_argument('--project'); p.add_argument('--port',type=int,default=8766); args=p.parse_args()
    APP=App(Path(args.project).resolve() if args.project else None); server=ThreadingHTTPServer(('127.0.0.1',args.port),Handler)
    url=f'http://127.0.0.1:{args.port}/'; print('Oneiric Observatory:',url); threading.Timer(.8,lambda:webbrowser.open(url)).start()
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: APP.engine.close(); server.server_close()
if __name__=='__main__': main()
