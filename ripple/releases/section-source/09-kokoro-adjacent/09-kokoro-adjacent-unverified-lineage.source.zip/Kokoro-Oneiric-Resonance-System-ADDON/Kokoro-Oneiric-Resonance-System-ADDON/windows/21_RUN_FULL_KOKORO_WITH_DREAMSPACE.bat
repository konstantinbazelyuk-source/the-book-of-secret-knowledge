@echo off
setlocal EnableExtensions
set "ROOT=%~dp0.."
set "ADDON=%ROOT%\addons\Kokoro-Oneiric-Resonance-System"
if not exist "%ROOT%\.venv\Scripts\python.exe" (echo Kokoro Python environment not found.& pause& exit /b 1)
title Full Kokoro with Oneiric Resonance
"%ROOT%\.venv\Scripts\python.exe" "%ADDON%\bonded_oneiric_runtime.py" --base "%ROOT%" --device auto
pause
