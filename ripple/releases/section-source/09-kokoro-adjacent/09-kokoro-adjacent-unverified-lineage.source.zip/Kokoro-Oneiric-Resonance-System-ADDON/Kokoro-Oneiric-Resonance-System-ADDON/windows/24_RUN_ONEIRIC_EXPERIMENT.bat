@echo off
setlocal EnableExtensions
set "ROOT=%~dp0.."
set "ADDON=%ROOT%\addons\Kokoro-Oneiric-Resonance-System"
if not exist "%ROOT%\.venv\Scripts\python.exe" (echo Kokoro Python environment not found.& pause& exit /b 1)
title Kokoro Oneiric Control Experiment
"%ROOT%\.venv\Scripts\python.exe" "%ADDON%\research\run_control_experiment.py" --output "%ADDON%\research\experiment_report.json"
pause
