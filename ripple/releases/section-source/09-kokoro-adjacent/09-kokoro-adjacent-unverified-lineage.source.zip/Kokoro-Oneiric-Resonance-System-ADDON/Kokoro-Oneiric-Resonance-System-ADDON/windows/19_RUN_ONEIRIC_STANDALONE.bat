@echo off
setlocal EnableExtensions
set "ROOT=%~dp0.."
set "ADDON=%ROOT%\addons\Kokoro-Oneiric-Resonance-System"
if not exist "%ROOT%\.venv\Scripts\python.exe" (echo Kokoro Python environment not found.& pause& exit /b 1)
title Kokoro Oneiric Standalone
"%ROOT%\.venv\Scripts\python.exe" "%ADDON%\oneiric_cli.py" --project "%ROOT%" dream --wall-seconds 1.2 --candidates 4 --export
pause
