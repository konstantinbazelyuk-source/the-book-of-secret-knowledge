@echo off
setlocal EnableExtensions
set "ROOT=%~dp0.."
set "ADDON=%ROOT%\addons\Kokoro-Oneiric-Resonance-System"
if not exist "%ROOT%\.venv\Scripts\python.exe" (echo Kokoro Python environment not found.& pause& exit /b 1)
title Test Kokoro Oneiric Resonance System
"%ROOT%\.venv\Scripts\python.exe" "%ADDON%\tests\run_all.py" --project "%ROOT%"
pause
