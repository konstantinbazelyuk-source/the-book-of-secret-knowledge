@echo off
setlocal EnableExtensions
set "ROOT=%~dp0.."
set "ADDON=%ROOT%\addons\Kokoro-Oneiric-Resonance-System"
if not exist "%ROOT%\.venv\Scripts\python.exe" (echo Kokoro Python environment not found.& pause& exit /b 1)
title Export Kokoro Last Dream
"%ROOT%\.venv\Scripts\python.exe" "%ADDON%\oneiric_cli.py" --project "%ROOT%" export --directory "%ADDON%\artifacts"
pause
