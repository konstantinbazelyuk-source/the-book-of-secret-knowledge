@echo off
setlocal EnableExtensions
set "ROOT=%~dp0.."
set "ADDON=%ROOT%\addons\Kokoro-Oneiric-Resonance-System"
if not exist "%ROOT%\.venv\Scripts\python.exe" (echo Kokoro Python environment not found.& pause& exit /b 1)
title Kokoro Idle Dream Service
"%ROOT%\.venv\Scripts\python.exe" "%ADDON%\idle_dream_service.py" --project "%ROOT%"
pause
