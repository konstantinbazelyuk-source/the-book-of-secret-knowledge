@echo off
setlocal EnableExtensions
set "ROOT=%~dp0.."
set "ADDON=%ROOT%\addons\Kokoro-Oneiric-Resonance-System"
if not exist "%ROOT%\.venv\Scripts\python.exe" (echo Kokoro Python environment not found.& pause& exit /b 1)
title Export Oneiric Device Frame
"%ROOT%\.venv\Scripts\python.exe" "%ADDON%\oneiric_cli.py" --project "%ROOT%" device-frame --output "%ADDON%\artifacts\last_device_frame.json"
pause
