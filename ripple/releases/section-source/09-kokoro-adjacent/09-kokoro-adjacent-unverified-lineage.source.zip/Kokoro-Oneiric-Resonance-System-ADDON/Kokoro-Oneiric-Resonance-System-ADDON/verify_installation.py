from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path

def main():
    p=argparse.ArgumentParser();p.add_argument('--project',required=True);args=p.parse_args();root=Path(args.project).resolve()
    forbidden=[]
    for rel in ['kokoro.py','kokoro_core','checkpoints']:
        if not (root/rel).exists(): forbidden.append(f'missing expected base path: {rel}')
    addon=root/'addons'/'Kokoro-Oneiric-Resonance-System'
    launchers=list((root/'windows').glob('*ONEIRIC*.bat'))+list((root/'windows').glob('*DREAMSPACE*.bat'))
    report={'project':str(root),'addon_exists':addon.exists(),'base_expected_paths_present':not forbidden,'problems':forbidden,'launcher_count':len(launchers),'claim':'Installer copies only into addons/Kokoro-Oneiric-Resonance-System and adds numbered Windows launchers. It does not write to checkpoints or kokoro_core.'}
    print(json.dumps(report,indent=2));raise SystemExit(0 if addon.exists() and not forbidden else 1)
if __name__=='__main__':main()
