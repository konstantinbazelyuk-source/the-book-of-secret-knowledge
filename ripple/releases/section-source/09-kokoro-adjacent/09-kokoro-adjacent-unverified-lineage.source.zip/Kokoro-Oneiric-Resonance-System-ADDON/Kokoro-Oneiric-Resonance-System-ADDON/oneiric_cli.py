#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, sys, time, webbrowser
from pathlib import Path

ADDON=Path(__file__).resolve().parent
if str(ADDON) not in sys.path: sys.path.insert(0,str(ADDON))
from oneiric import OneiricEngine
from oneiric.models import DreamEpisode, DreamMetrics
from oneiric.output_bridge import save_device_frame


def engine(args):
    project=Path(args.project).resolve() if getattr(args,'project',None) else None
    return OneiricEngine(ADDON/'state'/'oneiric.sqlite3', ADDON/'oneiric_config.json', project)

def main():
    p=argparse.ArgumentParser(description='Kokoro Oneiric Resonance System')
    p.add_argument('--project')
    sub=p.add_subparsers(dest='cmd',required=True)
    sub.add_parser('status')
    ing=sub.add_parser('ingest'); ing.add_argument('text'); ing.add_argument('--source',default='manual'); ing.add_argument('--salience',type=float,default=.5); ing.add_argument('--unresolved',type=float,default=.2)
    dr=sub.add_parser('dream'); dr.add_argument('--wall-seconds',type=float,default=1.0); dr.add_argument('--candidates',type=int,default=3); dr.add_argument('--export',action='store_true')
    sub.add_parser('last'); sub.add_parser('favorites')
    ex=sub.add_parser('export'); ex.add_argument('--directory',default=str(ADDON/'artifacts'))
    sc=sub.add_parser('scale'); sc.add_argument('value',type=float)
    fb=sub.add_parser('feedback'); fb.add_argument('dream_id'); fb.add_argument('rating',type=float)
    dev=sub.add_parser('device-frame'); dev.add_argument('--output',default=str(ADDON/'artifacts'/'last_device_frame.json'))
    args=p.parse_args(); e=engine(args)
    try:
        if args.cmd=='status': print(json.dumps(e.status(),indent=2,ensure_ascii=False))
        elif args.cmd=='ingest': print(json.dumps(e.ingest(args.text,args.source,args.salience,unresolved=args.unresolved).to_dict(),indent=2,ensure_ascii=False))
        elif args.cmd=='dream':
            d=e.dream(args.wall_seconds,args.candidates,force=True); print(json.dumps(d.to_dict(),indent=2,ensure_ascii=False))
            if args.export: print(json.dumps(e.export_last(ADDON/'artifacts'),indent=2))
        elif args.cmd=='last': print(json.dumps(e.store.last_dream() or {},indent=2,ensure_ascii=False))
        elif args.cmd=='favorites': print(json.dumps(e.store.favorite_dreams(10),indent=2,ensure_ascii=False))
        elif args.cmd=='export': print(json.dumps(e.export_last(args.directory),indent=2))
        elif args.cmd=='scale': e.set_virtual_time_scale(args.value); print(f'Virtual dream-time scale set to {args.value:g}x.')
        elif args.cmd=='feedback': e.feedback(args.dream_id,args.rating); print('Preference feedback recorded.')
        elif args.cmd=='device-frame':
            raw=e.store.last_dream()
            if raw is None: raise RuntimeError('No dream has been created yet')
            metrics=DreamMetrics(**raw.pop('metrics')); d=DreamEpisode(metrics=metrics,**raw)
            print(save_device_frame(d,args.output))
    finally: e.close()

if __name__=='__main__': main()
