# Synthetic Experiment Report

The included component-level experiment ran 24 bounded dream cycles over a small fixed trace set. It reached complete trace coverage while the mean consecutive replay overlap was 0.323. Mean factual risk was 0.000; no Wake Capsule promoted dream content as fact.

The mean loop-risk score was 0.589. Because the experiment deliberately uses a small, recurrent memory set, this is treated as a monitored variable rather than proof of failure. The production preference system applies negative loop weighting, access habituation, and a hard candidate guard when lower-loop alternatives exist.

This is a mechanics test, not evidence of consciousness or improved intelligence.
