# Research Decision Matrix

| Research idea | Implemented use | Boundary |
|---|---|---|
| Experience replay / sleep-like replay | Prioritized offline trace selection | No claim of biological sleep equivalence |
| Reward-biased reactivation | Reward and value terms in replay | Reward cannot override truth safeguards |
| Slow-oscillation coordination | Kuramoto phase coupling and order parameter | Numerical oscillator, not recorded brain rhythm |
| Hopfield-style collective dynamics | Similarity-coupled trace field | No claim of exact Hopfield learning rule |
| Liquid-state / reservoir computing | Fixed nonlinear recurrent dream field | Does not train or replace Kokoro core |
| Quantum cognition | Complex amplitudes and contextual interference | Classical simulation only |
| Lindblad/dephasing dynamics | Density-matrix coherence loss | Not open-system quantum hardware |
| Quantum-inspired sampling | Norm-weighted bounded selection | No quantum speedup claim |
| CIE color science | Wavelength-to-display mapping | Monitor RGB is not monochromatic light |
| Cymatics | Standing membrane-mode visualization | Not a physical fluid/plate experiment |
| Schumann resonance | Optional 7.83 Hz seed and ablation variable | No consciousness or healing claim |
| Virtual time | Simulated dream horizon and stage timing | No extra arithmetic and no physical dilation |
| World models / latent imagination | Internal candidate generation and symbolic association | Not a learned environment simulator yet |

The architecture retains mechanisms only when they have a defined state variable, transformation, test, and failure boundary.
