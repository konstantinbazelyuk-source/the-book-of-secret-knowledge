from __future__ import annotations
import argparse,json,tempfile,sys
from pathlib import Path
import numpy as np
ADDON=Path(__file__).resolve().parents[1]
if str(ADDON) not in sys.path:sys.path.insert(0,str(ADDON))
from oneiric.config import OneiricConfig
from oneiric.engine import OneiricEngine

MEMORIES=[
('A blue bridge remains unfinished between truth and trust',.9,.7,.8),('The red door represents urgency but not evidence',.7,.4,.6),('A quiet green garden supports restoration and patient thought',.8,.3,.9),('Gold light marks coherence between memory and value',.75,.5,.85),('Violet weather holds unanswered questions without forcing closure',.85,.8,.7),('A factual statement must be checked outside Dreamspace',.95,.2,.95),('Creativity can recombine old fragments into new hypotheses',.8,.6,.8),('Continuity means changes remain traceable rather than erased',.9,.5,.9),('The Psyche preserves competing interpretations',.75,.65,.75),('Heartspace regulates value and expression energy',.82,.45,.92),('The Network separates evidence from inference',.9,.55,.85),('Pocket Time expands virtual dream duration without extra compute',.7,.35,.7)]

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',default=str(ADDON/'research'/'experiment_report.json'));p.add_argument('--cycles',type=int,default=24);args=p.parse_args()
    with tempfile.TemporaryDirectory() as td:
        cfg=OneiricConfig();cfg.idle_threshold_seconds=0;cfg.max_memories_per_dream=7;cfg.max_wall_seconds_per_cycle=.12;cfg.oscillator_steps=40;cfg.quantum_steps=6;cfg.default_virtual_time_scale=60;cfg.save(Path(td)/'cfg.json')
        e=OneiricEngine(Path(td)/'db.sqlite3',Path(td)/'cfg.json')
        for i,(text,sal,unres,val) in enumerate(MEMORIES):e.ingest(text,'experiment',sal,.45,val,unres,.75,.1,['experiment'])
        dreams=[e.dream(.08,4,True) for _ in range(args.cycles)]
        chosen_sets=[set(d.selected_memory_ids) for d in dreams]
        coverage=len(set().union(*chosen_sets))/len(e.store.memories(500))
        consecutive=[len(chosen_sets[i]&chosen_sets[i-1])/max(1,len(chosen_sets[i]|chosen_sets[i-1])) for i in range(1,len(chosen_sets))]
        report={'experiment':'bounded component-level Oneiric sanity experiment','cycles':args.cycles,'control':'no idle process: zero dream episodes, zero symbolic integration output, zero learned dream preference','oneiric':{'dreams_completed':len(dreams),'memory_coverage':coverage,'mean_consecutive_replay_jaccard':float(np.mean(consecutive)),'mean_coherence':float(np.mean([d.metrics.coherence for d in dreams])),'mean_novelty':float(np.mean([d.metrics.novelty for d in dreams])),'mean_integration_gain':float(np.mean([d.metrics.integration_gain for d in dreams])),'mean_factual_risk':float(np.mean([d.metrics.factual_risk for d in dreams])),'mean_loop_risk':float(np.mean([d.metrics.loop_risk for d in dreams])),'virtual_seconds_total':sum(d.virtual_seconds for d in dreams)},'invariants':{'all_density_trace_errors_below_1e-8':all(d.provenance['density_trace_error']<1e-8 for d in dreams),'all_density_min_eigenvalues_above_minus_1e-8':all(d.provenance['density_min_eigenvalue']>-1e-8 for d in dreams),'no_dream_promoted_factual_claims':all(d.wake_capsule.get('factual_claims')==[] for d in dreams),'all_dreams_classical_simulations':all(d.provenance['classical_simulation'] for d in dreams)},'interpretation':'The experiment validates mechanics and bounded causal state, not consciousness, intelligence improvement, or biological equivalence. A later A/B study with trained Kokoro must measure delayed recall, contradiction, creativity, and hallucination.'}
        Path(args.output).write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report,indent=2));e.close()
if __name__=='__main__':main()
