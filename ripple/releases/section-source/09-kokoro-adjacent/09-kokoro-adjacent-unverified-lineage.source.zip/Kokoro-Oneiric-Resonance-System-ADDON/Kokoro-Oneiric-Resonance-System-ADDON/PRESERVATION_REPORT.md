# Preservation Report

## Installation writes

The installer copies this package to:

`addons/Kokoro-Oneiric-Resonance-System`

and copies numbered launcher files `18` through `26` into the existing `windows` folder.

## Installation does not write

- `kokoro.py`
- `kokoro_core/`
- `configs/`
- `data/`
- `artifacts/tokenizer.json`
- existing memory databases
- `checkpoints/`
- installed Psyche, Heartspace, Network, Adaptive Trainer, or Pocket Time source

The core checkpoint is read for inference only when the bonded runtime is launched. Core token embeddings may be averaged under inference mode; no gradient or optimizer operation is performed.

`COMPATIBILITY_FINGERPRINTS.json` records hashes of the source APIs used during integration design. It is not a claim that the user's installed copy must have identical hashes; the included test and verification launchers check the actual installation.
