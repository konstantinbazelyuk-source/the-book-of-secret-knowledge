#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, sys, time
from pathlib import Path
ADDON=Path(__file__).resolve().parent
if str(ADDON) not in sys.path: sys.path.insert(0,str(ADDON))
from oneiric import OneiricEngine, IdleDreamService

def main():
    p=argparse.ArgumentParser();p.add_argument('--project');args=p.parse_args()
    e=OneiricEngine(ADDON/'state'/'oneiric.sqlite3',ADDON/'oneiric_config.json',args.project)
    def notice(d): print('\nDream completed:',d.get('title'),flush=True)
    s=IdleDreamService(e,notice);s.start();print('Idle Dream Service active. Ctrl+C stops it safely.');print(json.dumps(e.status(),indent=2))
    try:
        while True: time.sleep(1)
    except KeyboardInterrupt: pass
    finally: s.stop();e.close()
if __name__=='__main__':main()
