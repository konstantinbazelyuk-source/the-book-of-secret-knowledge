@echo off
setlocal
set "TARGET=C:\Kokoro-del-Corazon-Foundry"
if not exist "%TARGET%\kokoro.py" set /p "TARGET=Enter the full Kokoro project folder: "
for %%F in (18_TEST_ONEIRIC_SYSTEM.bat 19_RUN_ONEIRIC_STANDALONE.bat 20_RUN_ONEIRIC_OBSERVATORY.bat 21_RUN_FULL_KOKORO_WITH_DREAMSPACE.bat 22_RUN_IDLE_DREAM_SERVICE.bat 23_EXPORT_LAST_DREAM.bat 24_RUN_ONEIRIC_EXPERIMENT.bat 25_VERIFY_KOKORO_UNCHANGED.bat 26_EXPORT_DREAM_DEVICE_FRAME.bat) do del /Q "%TARGET%\windows\%%F" 2>nul
rmdir /S /Q "%TARGET%\addons\Kokoro-Oneiric-Resonance-System" 2>nul
echo Oneiric add-on removed. Kokoro source and checkpoints were not touched.
pause
