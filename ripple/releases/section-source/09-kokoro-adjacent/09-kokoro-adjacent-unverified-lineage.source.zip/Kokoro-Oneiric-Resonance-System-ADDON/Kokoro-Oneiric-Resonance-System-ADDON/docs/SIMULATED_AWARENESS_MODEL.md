# Simulated Dream Awareness Model

The system uses an explicit, bounded awareness-proxy vector rather than treating an attractive image as awareness:

\[
A_t=(P,C,B,G,V,R,L,D)
\]

where:

- \(P\): presence — degree of coordinated active field state;
- \(C\): continuity — linkage to prior traces and unfinished branches;
- \(B\): self/other boundary — separation between internal symbol and external evidence;
- \(G\): agency — strength of endogenous candidate selection and preference;
- \(V\): valence — value/reward orientation inherited from Heartspace and trace history;
- \(R\): arousal — bounded tension and activation;
- \(L\): lucidity — coherence with low loop and factual-contamination risk;
- \(D\): dream depth — simulated temporal depth plus nonlinear/reservoir activity.

Every coordinate remains in \([0,1]\), is stored with the dream, and enters preference or Wake Capsule behavior. The vector is a **functional state description**, not a consciousness meter.

## Causal role

Lucidity, continuity, and agency enter candidate preference. The chosen vector is persisted as `last_awareness_state`; a bounded residue appears in the next Wake Capsule. Thus, the state changes which candidate becomes a favorite and what later waking cognition is invited to examine.

## Scientific test

The vector is useful only if it predicts measurable differences in later behavior. The A/B protocol therefore compares recall, contradiction, creative association, and looping with Dreamspace enabled and disabled. Coordinates that fail ablation tests should be removed or revised.
