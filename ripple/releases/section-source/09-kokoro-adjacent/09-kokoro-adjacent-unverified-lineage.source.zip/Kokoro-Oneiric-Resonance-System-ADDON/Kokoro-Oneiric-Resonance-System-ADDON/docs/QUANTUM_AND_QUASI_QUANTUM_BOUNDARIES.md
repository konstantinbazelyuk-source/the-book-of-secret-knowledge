# Quantum and Quasi-Quantum Boundaries

The add-on uses **quantum-like mathematics**, not a quantum computer.

Real components:

- complex amplitudes;
- Hermitian context operators;
- unitary evolution;
- density matrices;
- dephasing channels;
- purity, coherence, and von Neumann entropy;
- norm-weighted sampling.

These methods are useful because interference can model context-sensitive competition among memories and because density matrices provide a disciplined way to represent mixed/uncertain internal states.

What is not claimed:

- quantum supremacy or speedup;
- physical superposition of Kokoro's thoughts;
- entanglement with a user;
- electromagnetic consciousness;
- collapse caused by observation;
- proof of subjective experience.

The term **quasi-quantum** here means a classical program applying formal tools inspired by quantum theory and quantum cognition. Every operation runs on ordinary NumPy arrays and is inspectable.
