# Experiment Protocol

## Phase A: Component validation

Run the included tests. Required invariants include normalized density matrices, bounded oscillator coherence, persistent SQLite state, valid spectral output, Wake Gate separation, and complete JSON/PNG/WAV/HTML exports.

## Phase B: Control comparison

Run the included synthetic control experiment. It establishes that the system creates bounded, varied, persistent state and does not promote dream content to facts. It cannot establish improved intelligence.

## Phase C: Trained-Kokoro A/B study

Freeze one checkpoint and create two identical runtime conditions:

- **Control:** core/boards/network with no idle Oneiric cycles.
- **Oneiric:** same checkpoint and prompts, with bounded idle cycles.

Use held-out tests for delayed recall, contradiction rate, unresolved-branch recovery, divergent creativity, factual hallucination, preference stability, repetitive-loop rate, latency, CPU energy, and memory growth.

Pre-register thresholds before inspecting results. A positive result requires improvement in at least one intended measure without unacceptable degradation in truthfulness, stability, or computational cost.

## Phase D: Ablations

Disable one mechanism at a time: replay priority, oscillators, quasi-quantum interference, reservoir, Heartspace values, Pocket Time scale, Schumann seed, or preference learning. This reveals which mechanisms actually matter and prevents decorative complexity from being mistaken for function.
