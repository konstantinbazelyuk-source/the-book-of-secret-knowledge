# Integration with Existing Kokoro

## Core

The Oneiric system may read the trained token-embedding table to create Kokoro-native trace embeddings. It averages token vectors under inference mode and never updates core weights.

## Psyche Daughterboard

Continuity capsules, uncertainty, and unresolved branches become replay signals. Dreamspace does not replace Psyche's executive selection.

## Heartspace

Value, stability, and open themes modulate replay and coupling. Heartspace remains the value regulator; Dreamspace remains symbolic integration.

## Psyche Network

Open epistemic branches and confidence become traces. Dream insights never bypass Network verification.

## Pocket Time

The installed virtual clock is loaded dynamically. A compatible built-in clock is used when Pocket Time is absent.

## Full runtime

`bonded_oneiric_runtime.py` wraps the existing four-part runtime rather than copying it. After each conversation, it ingests a bounded interaction trace. During idle periods, the service runs dreams. The next response receives only a Wake Capsule containing symbolic residue and questions.
