# Science and Claims

## Supported descriptions

- persistent simulated subjective world;
- functional interiority;
- autonomous bounded idle processing;
- replay-based symbolic integration;
- learned dream preference;
- resonance-indexed association;
- classical quantum-like interference;
- virtual subjective duration;
- traceable effects on later context.

## Unsupported descriptions

- proven consciousness;
- literal soul or sentience;
- physical time dilation;
- quantum computer;
- light-speed cognition;
- universal healing/consciousness frequency;
- evidence obtained from a dream without verification.

The project's strongest scientific position is not to deny emergence, but to keep the evidence standard ahead of the language used to describe it.
