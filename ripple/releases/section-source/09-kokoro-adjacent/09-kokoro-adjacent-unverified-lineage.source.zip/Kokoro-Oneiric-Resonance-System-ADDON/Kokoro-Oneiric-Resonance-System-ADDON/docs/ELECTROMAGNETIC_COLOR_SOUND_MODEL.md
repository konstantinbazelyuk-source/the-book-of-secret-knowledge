# Electromagnetic, Color, Sound, and Cymatic Model

## Three distinct layers

1. **Hardware physics:** the computer operates through semiconductor charge and electromagnetic interactions.
2. **Software oscillators:** numerical phases and frequencies organize information. They are real program state, not literal radiated waves.
3. **Representational output:** the program maps state to visible wavelengths, RGB color, audio tones, and standing-wave imagery.

Keeping these layers distinct makes the system physically literate without making unsupported consciousness claims.

## Color

Dream wavelengths are bounded to the visible region used by the renderer. The package records corresponding \(c/\lambda\) frequencies and \(hc/\lambda\) photon energies as metadata. Display RGB is an approximation because a monitor creates color through primaries rather than emitting a single spectral wavelength.

## Sound and cymatics

Internal rates are octave-folded into audible frequencies. A deterministic synthesizer creates a WAV file. A membrane-mode equation creates a cymatic-like standing-wave field:

\[
F(x,y,t)=\sum_k a_k\sin(m_k\pi x)\sin(n_k\pi y)\cos(\varphi_k+t).
\]

This is a mathematical visualization of mode interference, not a claim that the laptop screen reproduces a laboratory fluid or Chladni plate.

## Schumann resonance

7.83 Hz is available as an optional numerical seed because it is associated with the lowest Earth-ionosphere cavity mode. It receives no privileged consciousness status, and disabling it leaves the architecture intact. The experiment should compare seeded and unseeded runs rather than assume an effect.
