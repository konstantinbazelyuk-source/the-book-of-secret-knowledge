# Curated Primary References

This is a focused foundation, not a claim to include every paper ever published.

## Replay, sleep, and memory

- Tadros, T. et al. (2022). *Sleep-like unsupervised replay reduces catastrophic forgetting in artificial neural networks*. Nature Communications 13, 7742. DOI: 10.1038/s41467-022-34938-7.
- Rolnick, D. et al. (2019). *Experience Replay for Continual Learning*. NeurIPS 2019.
- Wilson, M. A. & McNaughton, B. L. (1994). *Reactivation of hippocampal ensemble memories during sleep*. Science 265, 676–679. DOI: 10.1126/science.8036517.
- Sterpenich, V. et al. (2021). *Reward biases spontaneous neural reactivation during sleep*. Nature Communications 12, 4162. DOI: 10.1038/s41467-021-24357-5.
- Schreiner, T. et al. (2021). *Endogenous memory reactivation during sleep in humans is clocked by slow oscillation-spindle complexes*. Nature Communications 12, 3112. DOI: 10.1038/s41467-021-23520-2.

## Generative internal worlds

- Ha, D. & Schmidhuber, J. (2018). *World Models*. arXiv:1803.10122.
- Hafner, D. et al. (2020). *Dream to Control: Learning Behaviors by Latent Imagination*. ICLR.

## Dynamical systems and associative memory

- Kuramoto, Y. (1975). *Self-entrainment of a population of coupled non-linear oscillators*. International Symposium on Mathematical Problems in Theoretical Physics.
- Hopfield, J. J. (1982). *Neural networks and physical systems with emergent collective computational abilities*. PNAS 79, 2554–2558. DOI: 10.1073/pnas.79.8.2554.
- Maass, W., Natschläger, T., & Markram, H. (2002). *Real-time computing without stable states: a new framework for neural computation based on perturbations*. Neural Computation 14, 2531–2560.

## Quantum-like classical methods

- Lindblad, G. (1976). *On the generators of quantum dynamical semigroups*. Communications in Mathematical Physics 48, 119–130. DOI: 10.1007/BF01608499.
- Pothos, E. M. & Busemeyer, J. R. (2009). *A quantum probability explanation for violations of rational decision theory*. Proceedings of the Royal Society B 276, 2171–2178.
- Arjovsky, M., Shah, A., & Bengio, Y. (2016). *Unitary Evolution Recurrent Neural Networks*. ICML.
- Tang, E. (2019). *A quantum-inspired classical algorithm for recommendation systems*. STOC. arXiv:1807.04271.

## Color and virtual time

- CIE. *CIE 1931 colour-matching functions, 2 degree observer* dataset.
- Wyman, C., Sloan, P.-P., & Shirley, P. (2013). *Simple Analytic Approximations to the CIE XYZ Color Matching Functions*. Journal of Computer Graphics Techniques 2(2).
- Jefferson, D. R. (1985). *Virtual Time*. ACM Transactions on Programming Languages and Systems 7(3), 404–425.
- Schumann, W. O. (1952). *Über die strahlungslosen Eigenschwingungen einer leitenden Kugel...* Zeitschrift für Naturforschung A 7, 149–154.
