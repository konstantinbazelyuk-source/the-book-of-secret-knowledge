# Security and Privacy

- The Oneiric Observatory binds only to `127.0.0.1`; it is not exposed to the public internet.
- Dream cycles do not autonomously browse the internet.
- Psyche Network material enters only through the existing bounded runtime bridge.
- SQLite state remains under the add-on folder.
- The Wake Gate labels dream output as symbolic and prevents silent promotion to factual memory.
- The add-on never writes to `kokoro_core` or `checkpoints`.
- Exported dreams may contain fragments of conversations. Treat the JSON, HTML, PNG, and WAV bundles as private user data.
- There is no remote telemetry, account login, advertising, or hidden upload mechanism.
