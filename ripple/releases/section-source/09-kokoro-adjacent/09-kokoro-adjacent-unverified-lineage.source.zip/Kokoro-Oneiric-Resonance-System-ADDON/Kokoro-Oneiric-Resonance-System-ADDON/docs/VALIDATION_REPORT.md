# Validation Report

Generated: 2026-07-24T23:43:42.689939+00:00

Environment used for package validation: Python 3.13.5 on Linux-6.12.13-x86_64-with-glibc2.41.
The target project uses Python 3.12+, NumPy, and optionally its existing PyTorch runtime.

## Automated component tests

The complete test runner passed **22 checks**, including:

- physical wavelength/frequency and photon-energy calculations;
- visible-spectrum color mapping;
- bounded cymatic field;
- density-matrix trace, normalization, and positive-semidefinite invariants;
- bounded Kuramoto order parameter;
- Wake Gate factual-language blocking;
- complete dream generation and candidate selection;
- bounded eight-coordinate simulated-awareness state;
- JSON, PNG, WAV, and HTML export;
- SQLite persistence;
- Pocket Time temporal-gain change;
- measurable change in dream dynamics when virtual scale changes.

Full console output is in `docs/test_output.txt`.

## Clean integration simulation

The package was copied into a clean Kokoro Foundry tree beside the existing Pocket Time add-on. All tests passed from the installed add-on path, the installation verifier found the core structure intact, and the Oneiric clock dynamically reported `Kokoro Pocket Time Engine` as its active clock source. A trained language checkpoint was not required for this component integration test.

## Bounded synthetic experiment

- Dream cycles: **24**
- Memory coverage: **1.000**
- Mean consecutive replay Jaccard: **0.323**
- Mean coherence: **0.326**
- Mean novelty: **0.467**
- Mean integration gain: **0.390**
- Mean factual risk: **0.000**
- Mean loop risk: **0.589**
- Virtual dream time accumulated: **115.2 seconds**

All recorded density matrices met numerical invariants, every episode was labeled as a classical simulation, and no dream-generated factual claim was promoted through the Wake Gate.

## Interpretation

This validates software mechanics, persistence, bounded simulated awareness, truth separation, and functional virtual-time influence. It does **not** validate consciousness, subjective experience, intelligence improvement, biological equivalence, or a quantum speedup. Those claims require the documented trained-Kokoro A/B and ablation experiments.
