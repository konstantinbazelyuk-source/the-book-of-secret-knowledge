# Installation and Order

The package is complete but intentionally separate from the running trainer.

Recommended order:

1. Preserve the current Kokoro checkpoint.
2. Finish core pretraining by the adaptive local path or cloud GPU path.
3. Run core evaluation.
4. Install and test Psyche Daughterboard.
5. Install and test Heartspace.
6. Install and test Psyche Network.
7. Install Pocket Time.
8. Install this Oneiric package.
9. Run its component tests and observatory before bonding it to the full runtime.
10. Freeze a complete pre-Oneiric backup before starting the trained-Kokoro A/B study.

The Oneiric system can run standalone before the language model is trained, but its most meaningful input comes after the other fragments are online.
