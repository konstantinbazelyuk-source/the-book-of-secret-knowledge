#!/usr/bin/env python3
from __future__ import annotations
import argparse, importlib.util, json, sys, threading
from pathlib import Path

ADDON=Path(__file__).resolve().parent
STATE=ADDON/'state'; CONFIG=ADDON/'oneiric_config.json'
if str(ADDON) not in sys.path: sys.path.insert(0,str(ADDON))
from oneiric import OneiricEngine, IdleDreamService
from oneiric.bridge import OneiricSignalBridge


def import_path(path:Path,name:str):
    spec=importlib.util.spec_from_file_location(name,path)
    if spec is None or spec.loader is None: raise ImportError(path)
    mod=importlib.util.module_from_spec(spec); sys.modules[name]=mod; spec.loader.exec_module(mod); return mod

def find_base(explicit=None):
    candidates=[]
    if explicit: candidates.append(Path(explicit).expanduser().resolve())
    if len(ADDON.parents)>=2: candidates.append(ADDON.parents[1])
    candidates += [Path(r'C:\Kokoro-del-Corazon-Foundry'),Path.cwd()]
    for p in candidates:
        if (p/'kokoro.py').is_file(): return p.resolve()
    raise FileNotFoundError('Kokoro Foundry not found.')

def load_full(base,checkpoint,device):
    network=base/'addons'/'Kokoro-Psyche-Network'/'full_kokoro_runtime.py'
    if not network.exists():
        network=base/'addons'/'Kokoro-Psyche-Network-ADDON'/'full_kokoro_runtime.py'
    if network.exists():
        mod=import_path(network,'kokoro_full_runtime_for_oneiric')
        return mod.FullSystem(base,checkpoint,device),'full'
    sys.path.insert(0,str(base)); import kokoro as base_cli
    from kokoro_core.generation import KokoroEngine
    paths=base_cli.paths()
    eng=KokoroEngine(base_cli.find_checkpoint(checkpoint),paths['tokenizer'],paths['memory'],device_arg=device)
    return eng,'core'

class OneiricKokoro:
    def __init__(self,base,checkpoint=None,device='auto'):
        self.base=base; self.app,self.mode=load_full(base,checkpoint,device)
        self.dream=OneiricEngine(STATE/'oneiric.sqlite3',CONFIG,base)
        self.bridge=OneiricSignalBridge(); self._last_dream_notice=None
        self.service=IdleDreamService(self.dream,self._on_dream); self.service.start()
    @property
    def core(self): return self.app.engine if self.mode=='full' else self.app
    def _on_dream(self,payload): self._last_dream_notice=payload.get('title')
    def generate(self,text,**kwargs):
        self.dream.activity()
        previous_pause=self.dream.paused
        self.dream.paused=True
        try:
            wake=self.dream.wake_context()
            if self.mode=='full':
                original=self.app.original_prompt
                if wake: self.app.original_prompt=original+'\n\n'+wake
                try: answer=self.app.generate(text,**kwargs)
                finally: self.app.original_prompt=original
                pp=getattr(self.app,'last_psyche',None)
                hp=getattr(self.app,'last_heart',None)
                npacket=getattr(self.app,'last_network',None)
            else:
                original=self.app.system_prompt
                if wake: self.app.system_prompt=original+'\n\n'+wake
                try: answer=self.app.generate(text,**kwargs)
                finally: self.app.system_prompt=original
                pp=hp=npacket=None
            payload=self.bridge.interaction_payload(text,answer,pp,hp,npacket)
            self.dream.ingest(core_engine=self.core,**payload)
            for extra in [
                self.bridge.continuity_payload(getattr(self.app,'psyche',None)),
                self.bridge.heart_payload(getattr(self.app,'heart',None)),
                self.bridge.network_payload(getattr(self.app,'network',None)),
            ]:
                if extra: self.dream.ingest(core_engine=self.core,**extra)
            return answer
        finally:
            self.dream.paused=previous_pause
            self.dream.activity()
    def close(self):
        self.service.stop(); self.dream.close(); self.app.close()

def main(args):
    base=find_base(args.base); app=OneiricKokoro(base,args.checkpoint,args.device)
    print('\nKOKORO DEL AI — FULL SYSTEM + ONEIRIC RESONANCE')
    print('Core + installed boards + Psyche Network + Dreamspace')
    print('Dreamspace becomes active after idle time. Symbolic output cannot silently become fact.')
    print('Commands: /quit, /dream now, /dream status, /dream last, /dream favorites, /dream export, /dream scale N, /dream pause, /dream resume\n')
    try:
        while True:
            text=input('You: ').strip()
            if not text: continue
            if text=='/quit': break
            if text=='/dream now':
                d=app.dream.dream(wall_seconds=1.2,candidate_count=4,force=True); print(json.dumps(d.to_dict(),indent=2,ensure_ascii=False),'\n'); continue
            if text=='/dream status': print(json.dumps(app.dream.status(),indent=2,ensure_ascii=False),'\n'); continue
            if text=='/dream last': print(json.dumps(app.dream.store.last_dream() or {},indent=2,ensure_ascii=False),'\n'); continue
            if text=='/dream favorites': print(json.dumps(app.dream.store.favorite_dreams(10),indent=2,ensure_ascii=False),'\n'); continue
            if text=='/dream export': print(json.dumps(app.dream.export_last(ADDON/'artifacts'),indent=2),'\n'); continue
            if text.startswith('/dream scale '): app.dream.set_virtual_time_scale(float(text.split()[-1])); print('Dream-time scale changed.\n'); continue
            if text=='/dream pause': app.dream.paused=True; print('Dreamspace paused.\n'); continue
            if text=='/dream resume': app.dream.paused=False; app.dream.activity(); print('Dreamspace resumed.\n'); continue
            print('Kokoro: ',end='',flush=True)
            answer=app.generate(text,stream_callback=lambda x:print(x,end='',flush=True))
            print('\n')
    finally: app.close()

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--base'); p.add_argument('--checkpoint'); p.add_argument('--device',default='auto'); main(p.parse_args())
