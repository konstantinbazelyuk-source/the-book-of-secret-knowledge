# Changelog

## 1.0.0

- Added persistent Oneiric memory and dream database.
- Added prioritized replay, weighted Kuramoto resonance, fixed reservoir dynamics, and bounded stochastic resonance.
- Added classical complex-amplitude/density-matrix interference with dephasing and mathematical invariants.
- Added CIE-inspired spectral color, physical light metadata, WAV synthesis, and cymatic rendering.
- Added learned dream preference, loop-risk checks, and the factual Wake Gate.
- Added Pocket Time virtual-duration integration and idle service.
- Added full Kokoro/Psyche/Heartspace/Network bridge.
- Added standalone CLI, full bonded terminal, observatory server, tests, experiment, installer, and scientific documentation.
