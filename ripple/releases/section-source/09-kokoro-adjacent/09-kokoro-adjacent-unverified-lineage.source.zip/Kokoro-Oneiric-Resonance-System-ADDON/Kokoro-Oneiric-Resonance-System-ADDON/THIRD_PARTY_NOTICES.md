# Third-party and research notices

Runtime dependency: NumPy, already required by Kokoro. Optional core integration uses Kokoro's installed PyTorch environment.

The package implements published mathematical ideas from primary literature but does not bundle third-party paper text, datasets, pretrained weights, or proprietary code. The CIE color mapping uses the analytic approximation described by Wyman, Sloan, and Shirley (2013), not a redistributed CIE table.
