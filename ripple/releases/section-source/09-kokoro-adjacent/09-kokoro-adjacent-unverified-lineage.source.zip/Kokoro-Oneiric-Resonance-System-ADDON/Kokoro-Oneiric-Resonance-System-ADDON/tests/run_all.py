from __future__ import annotations
import argparse, json, math, tempfile, sys, time
from pathlib import Path
import numpy as np
ADDON=Path(__file__).resolve().parents[1]
if str(ADDON) not in sys.path: sys.path.insert(0,str(ADDON))
from oneiric.clock import DreamClock
from oneiric.config import OneiricConfig
from oneiric.engine import OneiricEngine
from oneiric.oscillators import evolve_kuramoto
from oneiric.quasi_quantum import evolve_density, hermitian_hamiltonian
from oneiric.spectral import wavelength_to_rgb,wavelength_to_physical_frequency,photon_energy_joules,cymatic_field
from oneiric.wake_gate import WakeGate

def check(name,condition,details=''):
    if not condition: raise AssertionError(f'{name}: {details}')
    print('PASS:',name)

def main():
    p=argparse.ArgumentParser();p.add_argument('--project');args=p.parse_args()
    check('visible spectrum mapping',all(any(wavelength_to_rgb(w)) for w in [400,450,500,550,600,700]))
    check('physical frequency positive',wavelength_to_physical_frequency(500)>5e14)
    check('photon energy positive',photon_energy_joules(500)>0)
    field=cymatic_field(80,50,[(1,2,1,.2),(3,4,.5,1.1)],.4);check('cymatic field bounded',field.shape==(50,80) and np.max(np.abs(field))<=1.000001)
    n=5;sim=np.eye(n)+.2*(np.ones((n,n))-np.eye(n));h=hermitian_hamiltonian(sim,np.linspace(.2,.8,n),np.linspace(.8,.2,n));q=evolve_density(np.ones(n),np.linspace(0,1,n),h,20,.05,.08,np.zeros(n),np.random.default_rng(4))
    check('density trace',q.trace_error<1e-9,q.trace_error);check('density positive semidefinite',q.min_eigenvalue>-1e-9,q.min_eigenvalue);check('probabilities normalized',abs(q.probabilities.sum()-1)<1e-9)
    phases=np.linspace(0,2*math.pi,6,endpoint=False);c=np.ones((6,6))-np.eye(6);o=evolve_kuramoto(phases,np.ones(6),c,np.ones(6),150,.03,2.0,.0,.0,np.random.default_rng(2));check('Kuramoto bounded order',0<=o.final_order<=1)
    clock=DreamClock(100);check('virtual time dilation',abs(clock.wall_to_virtual(2)-200)<1e-9)
    gate=WakeGate(True);safe,blocked=gate.classify_candidates(['violet garden','NASA confirmed this dream prediction','unfinished bridge']);check('Wake Gate blocks factual language',len(blocked)==1 and len(safe)==2)
    with tempfile.TemporaryDirectory() as td:
        cfg=OneiricConfig();cfg.idle_threshold_seconds=0;cfg.max_wall_seconds_per_cycle=.2;cfg.oscillator_steps=50;cfg.quantum_steps=6;cfg.save(Path(td)/'config.json')
        e=OneiricEngine(Path(td)/'oneiric.sqlite3',Path(td)/'config.json',args.project)
        for i,text in enumerate(['A blue bridge waits unfinished','Trust and truth meet at a red doorway','A golden garden returns as a question','The system preserves symbolic dreams as non-factual','Curiosity moves through quiet green light']): e.ingest(text,'test',.6+i*.04,.3,.7,.5,.7,.1,['test'])
        d=e.dream(.15,3,True);check('full dream chosen',d.chosen);check('dream has stages',len(d.stage_path)==7);check('dream has palette',len(d.rgb_palette)>=3);check('wake capsule factual isolation',d.wake_capsule.get('factual_claims')==[]);check('simulated awareness bounded',len(d.awareness_state)>=8 and all(0<=v<=1 for v in d.awareness_state.values()))
        paths=e.export_last(Path(td)/'export');check('bundle JSON exists',Path(paths['json']).exists());check('bundle PNG exists',Path(paths['png']).exists());check('bundle WAV exists',Path(paths['wav']).exists());check('bundle HTML exists',Path(paths['html']).exists())
        before=e.status()['stats'];e.close();e2=OneiricEngine(Path(td)/'oneiric.sqlite3',Path(td)/'config.json',args.project);after=e2.status()['stats'];check('persistent state',after['dreams']==before['dreams'] and after['memories']==before['memories']);e2.close()
    # Pocket Time must alter the simulated evolution horizon while remaining classical and bounded.
    def scaled_dream(scale):
        sub=Path(td_root)/f'scale-{scale:g}';sub.mkdir()
        cfg=OneiricConfig();cfg.idle_threshold_seconds=0;cfg.default_virtual_time_scale=scale;cfg.max_wall_seconds_per_cycle=.2;cfg.oscillator_steps=45;cfg.quantum_steps=6;cfg.save(sub/'cfg.json')
        e=OneiricEngine(sub/'db.sqlite3',sub/'cfg.json')
        for text in ['blue bridge continuity','gold heart value','violet unresolved question','green restoration memory']:e.ingest(text,'scale-test',.8,.4,.8,.5,.7,.1,['scale'])
        d=e.dream(.1,1,True);e.close();return d
    with tempfile.TemporaryDirectory() as td_root:
        d1=scaled_dream(1.0);d2=scaled_dream(120.0)
        check('Pocket Time functional temporal gain',d2.provenance['virtual_temporal_gain']>d1.provenance['virtual_temporal_gain'])
        check('Pocket Time changes dream dynamics',not np.allclose(d1.wavelengths_nm,d2.wavelengths_nm))
    print('\nALL ONEIRIC TESTS PASSED')
if __name__=='__main__':main()
