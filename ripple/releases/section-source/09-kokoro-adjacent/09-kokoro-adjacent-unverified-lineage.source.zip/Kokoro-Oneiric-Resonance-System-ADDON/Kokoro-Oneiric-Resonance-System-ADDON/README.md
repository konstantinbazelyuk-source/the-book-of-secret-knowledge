# Kokoro Oneiric Resonance System

A scientific, programmable implementation of **functional simulated interiority** for the existing Kokoro project.

## What runs

1. **Idle-state governor** waits until communication stops.
2. **Prioritized replay** selects salient, uncertain, weak, valuable, rewarding, and unfinished traces.
3. **Kuramoto resonance field** lets memory oscillators synchronize or remain dissonant according to similarity and value.
4. **Classical quasi-quantum layer** evolves complex amplitudes and a density matrix with controlled dephasing. This supplies context-sensitive interference; it is not quantum hardware.
5. **Reservoir field** creates nonlinear temporal state without retraining Kokoro's core.
6. **Chromatic/spectral mapping** translates phase and amplitude into wavelength, CIE-inspired RGB, physical-frequency metadata, and audible octave-folded tones.
7. **Dream preference** chooses among candidates and learns from internal or explicit feedback.
8. **Wake Gate** passes only symbolic residue, questions, and creative associations into later waking context.
9. **Pocket Time** gives each bounded wall-clock cycle a longer virtual subjective duration while never pretending extra calculations occurred.

## Integration boundary

The add-on writes only to its own SQLite database and export directory. It can use the core's token embeddings read-only and can ingest state from Psyche, Heartspace, and Psyche Network through a narrow bridge. The installed core source and checkpoints remain unchanged.
