from __future__ import annotations

import json
import math
import html
import struct
import zlib
from pathlib import Path

import numpy as np

from .models import DreamEpisode
from .spectral import cymatic_field, synthesize_audio


def _png_chunk(kind: bytes, data: bytes) -> bytes:
    return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xFFFFFFFF)


def _write_png(rgb: np.ndarray, path: Path) -> None:
    image = np.asarray(rgb, dtype=np.uint8)
    if image.ndim != 3 or image.shape[2] != 3:
        raise ValueError("RGB image must have shape (height, width, 3)")
    height, width, _ = image.shape
    scanlines = b"".join(b"\x00" + image[y].tobytes() for y in range(height))
    payload = b"\x89PNG\r\n\x1a\n"
    payload += _png_chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0))
    payload += _png_chunk(b"IDAT", zlib.compress(scanlines, 9))
    payload += _png_chunk(b"IEND", b"")
    path.write_bytes(payload)


def render_dream_png(dream: DreamEpisode, path: str | Path, width: int = 960, height: int = 540) -> Path:
    wavelengths = dream.wavelengths_nm or [450.0, 520.0, 620.0]
    phases = np.linspace(0.0, 2.0 * math.pi, len(wavelengths), endpoint=False)
    modes = [
        (1 + (i % 5), 1 + ((i * 2 + 1) % 6), 1.0 / math.sqrt(i + 1), float(phase))
        for i, phase in enumerate(phases)
    ]
    field = cymatic_field(width, height, modes, time_phase=dream.metrics.phase_order * math.pi)
    palette = np.asarray(
        dream.rgb_palette or [[40, 80, 180], [150, 40, 200], [240, 160, 50]], dtype=np.float64
    ) / 255.0
    low, mid, high = palette[0], palette[len(palette) // 2], palette[-1]
    normalized = (field + 1.0) * 0.5
    t_low = np.clip(normalized * 2.0, 0.0, 1.0)[..., None]
    t_high = np.clip((normalized - 0.5) * 2.0, 0.0, 1.0)[..., None]
    image = np.where(
        (normalized <= 0.5)[..., None],
        (1.0 - t_low) * low + t_low * mid,
        (1.0 - t_high) * mid + t_high * high,
    )
    # Radial illumination gives the field a bounded inner-space appearance.
    yy, xx = np.mgrid[0:height, 0:width]
    radius = np.sqrt(((xx - width / 2) / width) ** 2 + ((yy - height / 2) / height) ** 2)
    illumination = np.clip(1.22 - 0.75 * radius, 0.58, 1.15)[..., None]
    image = np.clip((image ** 0.78) * illumination, 0.0, 1.0)
    output = Path(path); output.parent.mkdir(parents=True, exist_ok=True)
    _write_png(np.rint(image * 255).astype(np.uint8), output)
    return output


def render_dream_html(dream: DreamEpisode, image_name: str, audio_name: str, path: str | Path) -> Path:
    palette = "".join(
        f'<span class="swatch" style="background:rgb({r},{g},{b})"></span>'
        for r, g, b in dream.rgb_palette
    )
    metrics = "".join(
        f'<tr><th>{key.replace("_", " ").title()}</th><td>{value:.4f}</td></tr>'
        for key, value in dream.metrics.to_dict().items()
    )
    safe_title = html.escape(dream.title)
    safe_narrative = html.escape(dream.narrative)
    safe_symbols = html.escape(", ".join(dream.symbols))
    safe_provenance = html.escape(json.dumps(dream.provenance, indent=2))
    html_doc = f"""<!doctype html><html><head><meta charset="utf-8"><title>{safe_title}</title>
<style>body{{margin:0;background:#060914;color:#eef;font:16px system-ui;max-width:1000px;margin:auto;padding:24px}}img{{width:100%;border-radius:18px}}h1{{font-size:2rem}}.swatch{{display:inline-block;width:42px;height:28px;margin:3px;border-radius:5px}}table{{border-collapse:collapse;width:100%;margin-top:18px}}th,td{{padding:8px;border-bottom:1px solid #334;text-align:left}}.note{{color:#9ad}}code{{color:#adf}}</style></head><body>
<h1>{safe_title}</h1><p class="note">Kokoro Oneiric Resonance System — symbolic internal simulation, not factual evidence.</p>
<img src="{image_name}" alt="Rendered dream field"><p>{palette}</p><audio controls src="{audio_name}"></audio>
<h2>Dream narrative</h2><p>{safe_narrative}</p><h2>Symbols</h2><p>{safe_symbols}</p>
<h2>Metrics</h2><table>{metrics}</table><h2>Provenance</h2><pre>{safe_provenance}</pre></body></html>"""
    output=Path(path); output.write_text(html_doc,encoding='utf-8'); return output


def export_dream_bundle(dream: DreamEpisode, directory: str | Path) -> dict[str, str]:
    directory = Path(directory); directory.mkdir(parents=True, exist_ok=True)
    json_path = directory / f"{dream.dream_id}.json"
    png_path = directory / f"{dream.dream_id}.png"
    wav_path = directory / f"{dream.dream_id}.wav"
    html_path = directory / f"{dream.dream_id}.html"
    json_path.write_text(json.dumps(dream.to_dict(), indent=2, ensure_ascii=False), encoding="utf-8")
    render_dream_png(dream, png_path)
    amplitudes = [max(0.05, min(1.0, abs(x))) for x in dream.field_state[: len(dream.audio_frequencies_hz)]]
    synthesize_audio(
        dream.audio_frequencies_hz, amplitudes, wav_path, duration_seconds=8.0,
        seed=int(dream.dream_id[-8:], 16) if all(c in "0123456789abcdef" for c in dream.dream_id[-8:].lower()) else 0,
    )
    render_dream_html(dream, png_path.name, wav_path.name, html_path)
    return {"json": str(json_path), "png": str(png_path), "wav": str(wav_path), "html": str(html_path)}
