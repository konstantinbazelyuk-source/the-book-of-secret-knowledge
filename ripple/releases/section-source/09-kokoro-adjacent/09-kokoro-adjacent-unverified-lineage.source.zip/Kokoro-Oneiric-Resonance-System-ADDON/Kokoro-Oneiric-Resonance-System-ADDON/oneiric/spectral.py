from __future__ import annotations

import colorsys
import math
import wave
from pathlib import Path
from typing import Iterable

import numpy as np

C = 299_792_458.0
H = 6.626_070_15e-34


def wavelength_to_physical_frequency(wavelength_nm: float) -> float:
    wavelength_m = max(1e-12, float(wavelength_nm) * 1e-9)
    return C / wavelength_m


def photon_energy_joules(wavelength_nm: float) -> float:
    return H * wavelength_to_physical_frequency(wavelength_nm)


def _gaussian_piecewise(wavelength: float, center: float, left: float, right: float) -> float:
    scale = left if wavelength < center else right
    t = (wavelength - center) * scale
    return math.exp(-0.5 * t * t)


def cie_xyz_approx(wavelength_nm: float) -> tuple[float, float, float]:
    """Wyman/Sloan/Shirley 2013 analytic approximation to CIE 1931 CMFs."""
    w = float(wavelength_nm)
    x = (
        0.362 * _gaussian_piecewise(w, 442.0, 0.0624, 0.0374)
        + 1.056 * _gaussian_piecewise(w, 599.8, 0.0264, 0.0323)
        - 0.065 * _gaussian_piecewise(w, 501.1, 0.0490, 0.0382)
    )
    y = (
        0.821 * _gaussian_piecewise(w, 568.8, 0.0213, 0.0247)
        + 0.286 * _gaussian_piecewise(w, 530.9, 0.0613, 0.0322)
    )
    z = (
        1.217 * _gaussian_piecewise(w, 437.0, 0.0845, 0.0278)
        + 0.681 * _gaussian_piecewise(w, 459.0, 0.0385, 0.0725)
    )
    return max(0.0, x), max(0.0, y), max(0.0, z)


def xyz_to_srgb(x: float, y: float, z: float) -> tuple[int, int, int]:
    # CIE XYZ D65 to linear sRGB.
    r = 3.2406 * x - 1.5372 * y - 0.4986 * z
    g = -0.9689 * x + 1.8758 * y + 0.0415 * z
    b = 0.0557 * x - 0.2040 * y + 1.0570 * z
    values = np.array([r, g, b], dtype=np.float64)
    peak = float(np.max(values))
    if peak > 1e-12:
        values /= peak
    values = np.clip(values, 0.0, 1.0)

    def compand(v: float) -> float:
        return 12.92 * v if v <= 0.0031308 else 1.055 * (v ** (1 / 2.4)) - 0.055

    return tuple(int(round(255 * np.clip(compand(float(v)), 0.0, 1.0))) for v in values)


def wavelength_to_rgb(wavelength_nm: float) -> tuple[int, int, int]:
    if wavelength_nm < 360 or wavelength_nm > 830:
        return 0, 0, 0
    return xyz_to_srgb(*cie_xyz_approx(wavelength_nm))


def latent_to_wavelength(value: float, low: float = 380.0, high: float = 750.0) -> float:
    bounded = 1.0 / (1.0 + math.exp(-float(value)))
    return low + (high - low) * bounded


def phase_to_wavelength(phase: float, amplitude: float = 1.0) -> float:
    normalized = (math.sin(phase) * 0.5 + 0.5) * np.clip(amplitude, 0.0, 1.0)
    return 380.0 + 370.0 * float(normalized)


def oscillator_to_audio_hz(omega: float, base_hz: float = 110.0) -> float:
    # Fold a virtual oscillator rate into the audible range by octaves.
    raw = base_hz * (2.0 ** (float(omega) / (2.0 * math.pi)))
    while raw < 55.0:
        raw *= 2.0
    while raw > 1760.0:
        raw /= 2.0
    return raw


def synthesize_audio(
    frequencies_hz: Iterable[float],
    amplitudes: Iterable[float],
    path: str | Path,
    duration_seconds: float = 8.0,
    sample_rate: int = 22050,
    seed: int = 0,
) -> Path:
    freqs = list(frequencies_hz)
    amps = list(amplitudes)
    if not freqs:
        freqs = [110.0]
    if not amps:
        amps = [1.0] * len(freqs)
    t = np.arange(int(duration_seconds * sample_rate), dtype=np.float64) / sample_rate
    signal = np.zeros_like(t)
    rng = np.random.default_rng(seed)
    for i, freq in enumerate(freqs[:12]):
        amp = float(amps[i % len(amps)])
        phase = float(rng.uniform(0.0, 2.0 * math.pi))
        signal += amp * np.sin(2.0 * math.pi * float(freq) * t + phase)
        signal += 0.18 * amp * np.sin(2.0 * math.pi * float(freq) * 2.0 * t + phase * 0.5)
    envelope = np.sin(np.linspace(0, math.pi, signal.size)) ** 0.65
    signal *= envelope
    peak = float(np.max(np.abs(signal)))
    if peak > 1e-12:
        signal = 0.86 * signal / peak
    pcm = np.int16(np.clip(signal, -1.0, 1.0) * 32767)
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(output), "wb") as handle:
        handle.setnchannels(1)
        handle.setsampwidth(2)
        handle.setframerate(sample_rate)
        handle.writeframes(pcm.tobytes())
    return output


def cymatic_field(
    width: int,
    height: int,
    modes: list[tuple[int, int, float, float]],
    time_phase: float,
) -> np.ndarray:
    x = np.linspace(0.0, 1.0, width)
    y = np.linspace(0.0, 1.0, height)
    xx, yy = np.meshgrid(x, y)
    field = np.zeros((height, width), dtype=np.float64)
    for m, n, amplitude, phase in modes:
        field += (
            float(amplitude)
            * np.sin(int(m) * math.pi * xx)
            * np.sin(int(n) * math.pi * yy)
            * math.cos(time_phase + float(phase))
        )
    max_abs = float(np.max(np.abs(field)))
    return field / max(max_abs, 1e-12)


def palette_from_wavelengths(wavelengths: Iterable[float]) -> list[list[int]]:
    return [list(wavelength_to_rgb(float(w))) for w in wavelengths]
