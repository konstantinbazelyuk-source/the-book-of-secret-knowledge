from __future__ import annotations

import threading
import time
from typing import Callable

from .engine import OneiricEngine
from .resource_guard import resource_state


class IdleDreamService:
    def __init__(
        self,
        engine: OneiricEngine,
        on_dream: Callable[[dict], None] | None = None,
    ):
        self.engine = engine
        self.on_dream = on_dream
        self.stop_event = threading.Event()
        self.thread: threading.Thread | None = None
        self.last_defer_reason: str | None = None

    def start(self) -> None:
        if self.thread and self.thread.is_alive():
            return
        self.stop_event.clear()
        self.thread = threading.Thread(target=self._run, name="KokoroDreamService", daemon=True)
        self.thread.start()

    def _run(self) -> None:
        while not self.stop_event.wait(self.engine.config.background_poll_seconds):
            if self.engine.paused or self.engine.active:
                continue
            if self.engine.idle_seconds() < self.engine.config.idle_threshold_seconds:
                continue
            resources = resource_state(
                self.engine.config.max_system_cpu_percent,
                self.engine.config.minimum_battery_percent,
                self.engine.config.allow_on_battery,
            )
            if not resources.allowed:
                if resources.reason != self.last_defer_reason:
                    self.engine.store.event("dream_deferred_resources", {
                        "cpu_percent": resources.cpu_percent, "on_ac_power": resources.on_ac_power,
                        "battery_percent": resources.battery_percent, "reason": resources.reason,
                    })
                    self.last_defer_reason = resources.reason
                continue
            self.last_defer_reason = None
            try:
                dream = self.engine.dream(force=False)
                if self.on_dream:
                    self.on_dream(dream.to_dict())
            except RuntimeError:
                continue
            except Exception as exc:
                self.engine.store.event("dream_service_error", {"error": str(exc)})
                time.sleep(1.0)

    def stop(self, timeout: float = 5.0) -> None:
        self.stop_event.set()
        if self.thread:
            self.thread.join(timeout=timeout)
