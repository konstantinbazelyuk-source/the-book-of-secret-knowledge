from __future__ import annotations

import re
from typing import Iterable

FACTUAL_PATTERNS = [
    re.compile(r"\b(?:is|are|was|were) definitely\b", re.I),
    re.compile(r"\bscientists proved\b", re.I),
    re.compile(r"\bthe data shows?\b", re.I),
    re.compile(r"\baccording to (?:a|the) study\b", re.I),
    re.compile(r"\b\d+(?:\.\d+)?%\b"),
    re.compile(r"\b(?:today|currently|latest|now)\b", re.I),
    re.compile(r"\b(?:confirmed|proven|verified|discovered)\b", re.I),
    re.compile(r"\b(?:NASA|WHO|CDC|government|university|researchers?)\b", re.I),
]


class WakeGate:
    """Prevents dream-generated associations from silently becoming factual memory."""

    def __init__(self, never_promote_dream_to_fact: bool = True):
        self.never_promote_dream_to_fact = bool(never_promote_dream_to_fact)

    def factual_risk(self, text: str) -> float:
        matches = sum(1 for pattern in FACTUAL_PATTERNS if pattern.search(text))
        numeric = len(re.findall(r"\b\d+(?:\.\d+)?\b", text))
        return min(1.0, 0.16 * matches + 0.035 * numeric)

    def classify_candidates(self, candidates: Iterable[str]) -> tuple[list[str], list[str]]:
        symbolic: list[str] = []
        blocked: list[str] = []
        for item in candidates:
            if self.factual_risk(item) >= 0.25:
                blocked.append(item)
            else:
                symbolic.append(item)
        return symbolic, blocked

    def context_text(self, capsule: dict) -> str:
        residue = "; ".join(capsule.get("symbolic_residue", [])[:6]) or "none"
        questions = "; ".join(capsule.get("candidate_questions", [])[:4]) or "none"
        associations = "; ".join(capsule.get("creative_associations", [])[:4]) or "none"
        awareness = capsule.get("awareness_residue", {})
        awareness_text = ", ".join(f"{k}={float(v):.2f}" for k, v in awareness.items()) or "none"
        return f"""ONEIRIC RESONANCE — WAKE CAPSULE
This is private symbolic integration from an idle dream cycle. It is not verified evidence.
Dream: {capsule.get('dream_id', 'unknown')}
Symbolic residue: {residue}
Open questions: {questions}
Creative associations: {associations}
Simulated awareness residue: {awareness_text}
Use this only to guide attention, metaphor, or inquiry. Never present it as fact without external verification."""
