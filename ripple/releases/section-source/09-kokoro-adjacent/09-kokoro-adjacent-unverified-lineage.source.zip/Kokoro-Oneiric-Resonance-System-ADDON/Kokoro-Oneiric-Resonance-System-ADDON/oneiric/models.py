from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass(slots=True)
class MemoryTrace:
    memory_id: str
    created_at: float
    source: str
    text: str
    embedding: list[float]
    salience: float = 0.5
    uncertainty: float = 0.5
    value: float = 0.5
    unresolved: float = 0.0
    confidence: float = 0.5
    novelty: float = 0.5
    reward: float = 0.0
    access_count: int = 0
    tags: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class DreamMetrics:
    coherence: float
    phase_order: float
    purity: float
    quantum_coherence: float
    entropy: float
    novelty: float
    integration_gain: float
    loop_risk: float
    factual_risk: float
    stability: float
    energy_cost: float
    beauty: float
    lucidity: float = 0.0
    continuity: float = 0.0
    agency: float = 0.0
    preference_score: float = 0.0

    def to_dict(self) -> dict[str, float]:
        return asdict(self)


@dataclass(slots=True)
class DreamEpisode:
    dream_id: str
    started_at: float
    ended_at: float
    wall_seconds: float
    virtual_seconds: float
    stage_path: list[str]
    title: str
    narrative: str
    symbols: list[str]
    selected_memory_ids: list[str]
    wavelengths_nm: list[float]
    rgb_palette: list[list[int]]
    audio_frequencies_hz: list[float]
    field_state: list[float]
    metrics: DreamMetrics
    chosen: bool = False
    favorite_rank: int | None = None
    wake_capsule: dict[str, Any] = field(default_factory=dict)
    awareness_state: dict[str, float] = field(default_factory=dict)
    provenance: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["metrics"] = self.metrics.to_dict()
        return payload


@dataclass(slots=True)
class WakeCapsule:
    dream_id: str
    generated_at: float
    summary: str
    symbolic_residue: list[str]
    candidate_questions: list[str]
    creative_associations: list[str]
    preference_shift: dict[str, float]
    factual_claims: list[str]
    verified_claims: list[str]
    blocked_claims: list[str]
    confidence: float
    classification: str = "symbolic-integration"
    awareness_residue: dict[str, float] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
