from __future__ import annotations

import hashlib
import math
import re
from typing import Any

import numpy as np

TOKEN_RE = re.compile(r"[\w'-]+", re.UNICODE)


def normalize(vector: np.ndarray) -> np.ndarray:
    norm = float(np.linalg.norm(vector))
    if norm <= 1e-12:
        return vector
    return vector / norm


def hash_embedding(text: str, dim: int = 64) -> np.ndarray:
    """Dependency-free signed feature hashing for a deterministic fallback."""
    vec = np.zeros(dim, dtype=np.float64)
    tokens = TOKEN_RE.findall(text.lower())
    if not tokens:
        return vec
    for position, token in enumerate(tokens):
        digest = hashlib.blake2b(token.encode("utf-8"), digest_size=16).digest()
        idx = int.from_bytes(digest[:8], "little") % dim
        sign = 1.0 if digest[8] & 1 else -1.0
        weight = 1.0 / math.sqrt(1.0 + position * 0.025)
        vec[idx] += sign * weight
        if len(token) >= 4:
            for i in range(len(token) - 2):
                tri = token[i : i + 3]
                d2 = hashlib.blake2b(tri.encode("utf-8"), digest_size=8).digest()
                idx2 = int.from_bytes(d2[:4], "little") % dim
                sign2 = 1.0 if d2[4] & 1 else -1.0
                vec[idx2] += 0.18 * sign2
    return normalize(vec)


def core_embedding(text: str, engine: Any, dim: int = 64) -> np.ndarray | None:
    """Average Kokoro's own learned token embeddings without modifying the core."""
    try:
        import torch

        token_ids = engine.tokenizer.encode(text, add_bos=False, add_eos=False)
        if not token_ids:
            return None
        token_ids = token_ids[: min(len(token_ids), 256)]
        ids = torch.tensor(token_ids, dtype=torch.long, device=engine.device)
        with torch.inference_mode():
            vectors = engine.model.token_embedding(ids).float().mean(dim=0).detach().cpu().numpy()
        vectors = np.asarray(vectors, dtype=np.float64)
        if vectors.size > dim:
            # Deterministic random projection preserves approximate geometry.
            rng = np.random.default_rng(424242 + vectors.size * 17 + dim)
            projection = rng.normal(0.0, 1.0 / math.sqrt(dim), size=(vectors.size, dim))
            vectors = vectors @ projection
        elif vectors.size < dim:
            vectors = np.pad(vectors, (0, dim - vectors.size))
        return normalize(vectors[:dim])
    except Exception:
        return None


def embed_text(text: str, dim: int = 64, engine: Any | None = None) -> np.ndarray:
    if engine is not None:
        embedded = core_embedding(text, engine, dim)
        if embedded is not None:
            return embedded
    return hash_embedding(text, dim)


def cosine(a: np.ndarray, b: np.ndarray) -> float:
    an = float(np.linalg.norm(a))
    bn = float(np.linalg.norm(b))
    if an <= 1e-12 or bn <= 1e-12:
        return 0.0
    return float(np.dot(a, b) / (an * bn))


def similarity_matrix(vectors: np.ndarray) -> np.ndarray:
    if vectors.ndim != 2 or vectors.shape[0] == 0:
        return np.zeros((0, 0), dtype=np.float64)
    normalized = vectors / np.maximum(np.linalg.norm(vectors, axis=1, keepdims=True), 1e-12)
    matrix = normalized @ normalized.T
    return np.clip(matrix, -1.0, 1.0)
