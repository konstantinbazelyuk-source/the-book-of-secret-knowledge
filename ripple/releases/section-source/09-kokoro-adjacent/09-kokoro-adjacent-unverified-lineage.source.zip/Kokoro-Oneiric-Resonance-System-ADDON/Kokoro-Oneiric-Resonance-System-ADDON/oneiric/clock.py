from __future__ import annotations

import datetime as dt
import time
from dataclasses import dataclass, field
from pathlib import Path
import importlib.util
import sys


def _load_external_pocket_clock(project_root: Path | None):
    if project_root is None:
        return None
    candidates = [
        project_root / "addons" / "Kokoro-Pocket-Time-Engine" / "pocket_time" / "virtual_clock.py",
        project_root / "addons" / "Kokoro-Pocket-Time-Engine-ADDON" / "pocket_time" / "virtual_clock.py",
    ]
    for path in candidates:
        if not path.exists():
            continue
        spec = importlib.util.spec_from_file_location("kokoro_external_pocket_clock", path)
        if spec and spec.loader:
            module = importlib.util.module_from_spec(spec)
            sys.modules[spec.name] = module
            spec.loader.exec_module(module)
            return getattr(module, "PocketClock", None)
    return None


@dataclass
class DreamClock:
    scale: float = 60.0
    project_root: Path | None = None
    _real_anchor: float = field(default_factory=time.monotonic, init=False)
    _virtual_anchor: dt.datetime = field(default_factory=lambda: dt.datetime.now(dt.timezone.utc), init=False)
    _external: object | None = field(default=None, init=False)

    def __post_init__(self) -> None:
        if self.scale <= 0:
            raise ValueError("scale must be positive")
        external_cls = _load_external_pocket_clock(self.project_root)
        if external_cls is not None:
            try:
                self._external = external_cls(scale=self.scale)
            except Exception:
                self._external = None

    @property
    def source(self) -> str:
        return "Kokoro Pocket Time Engine" if self._external is not None else "built-in compatible virtual clock"

    def monotonic(self) -> float:
        if self._external is not None:
            return float(self._external.monotonic())
        return (time.monotonic() - self._real_anchor) * self.scale

    def now(self) -> dt.datetime:
        if self._external is not None:
            return self._external.now()
        return self._virtual_anchor + dt.timedelta(seconds=self.monotonic())

    def wall_to_virtual(self, wall_seconds: float, cap: float | None = None) -> float:
        virtual = max(0.0, float(wall_seconds)) * self.scale
        return min(virtual, cap) if cap is not None else virtual

    def set_scale(self, scale: float) -> None:
        if scale <= 0:
            raise ValueError("scale must be positive")
        if self._external is not None:
            self._external.set_scale(scale)
        else:
            current = self.now()
            self._virtual_anchor = current
            self._real_anchor = time.monotonic()
        self.scale = float(scale)
