from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(slots=True)
class ReservoirResult:
    state: np.ndarray
    history: np.ndarray
    spectral_radius: float
    activity: float


class DreamReservoir:
    def __init__(
        self,
        input_dim: int,
        reservoir_dim: int,
        spectral_radius: float,
        leak: float,
        seed: int,
    ):
        self.input_dim = int(input_dim)
        self.reservoir_dim = int(reservoir_dim)
        self.leak = float(np.clip(leak, 0.01, 1.0))
        rng = np.random.default_rng(seed)
        self.w_in = rng.normal(0.0, 0.28, size=(self.reservoir_dim, self.input_dim))
        w = rng.normal(0.0, 1.0 / np.sqrt(max(1, self.reservoir_dim)), size=(self.reservoir_dim, self.reservoir_dim))
        mask = rng.random(w.shape) < 0.12
        w *= mask
        eig = np.linalg.eigvals(w)
        current = float(np.max(np.abs(eig))) if eig.size else 1.0
        self.w = w * (float(spectral_radius) / max(current, 1e-12))
        self.bias = rng.normal(0.0, 0.05, size=self.reservoir_dim)
        self.state = np.zeros(self.reservoir_dim, dtype=np.float64)
        self._spectral_radius = float(np.max(np.abs(np.linalg.eigvals(self.w))))

    def reset(self) -> None:
        self.state.fill(0.0)

    def run(
        self,
        inputs: np.ndarray,
        noise_std: float,
        rng: np.random.Generator,
    ) -> ReservoirResult:
        sequence = np.asarray(inputs, dtype=np.float64)
        if sequence.ndim == 1:
            sequence = sequence[np.newaxis, :]
        if sequence.shape[1] != self.input_dim:
            raise ValueError(f"expected input_dim={self.input_dim}, got {sequence.shape[1]}")
        history = np.zeros((sequence.shape[0], self.reservoir_dim), dtype=np.float64)
        for t, item in enumerate(sequence):
            perturbation = rng.normal(0.0, max(0.0, noise_std), size=self.reservoir_dim)
            candidate = np.tanh(self.w_in @ item + self.w @ self.state + self.bias + perturbation)
            self.state = (1.0 - self.leak) * self.state + self.leak * candidate
            history[t] = self.state
        return ReservoirResult(
            state=self.state.copy(),
            history=history,
            spectral_radius=self._spectral_radius,
            activity=float(np.mean(np.abs(history))) if history.size else 0.0,
        )
