from __future__ import annotations
import json, socket
from pathlib import Path
from typing import Any
from .models import DreamEpisode


def device_frame(dream: DreamEpisode) -> dict[str, Any]:
    """Create a device-neutral frame for a local LED/audio/visual controller."""
    return {
        "protocol": "kokoro-oneiric-frame/1",
        "dream_id": dream.dream_id,
        "virtual_seconds": dream.virtual_seconds,
        "palette_rgb": dream.rgb_palette,
        "wavelengths_nm": dream.wavelengths_nm,
        "corresponding_light_frequencies_hz": dream.provenance.get("physical_light_frequencies_hz", []),
        "audio_frequencies_hz": dream.audio_frequencies_hz,
        "awareness_state": dream.awareness_state,
        "metrics": dream.metrics.to_dict(),
        "safety": "Representational output only; external hardware must enforce its own brightness and volume limits.",
    }


def save_device_frame(dream: DreamEpisode, path: str | Path) -> Path:
    output=Path(path);output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(device_frame(dream),indent=2),encoding="utf-8")
    return output


def send_local_udp(dream: DreamEpisode, port: int = 8767) -> None:
    """Send a frame only to localhost. No internet transmission is performed."""
    raw=json.dumps(device_frame(dream),separators=(",",":"),ensure_ascii=False).encode("utf-8")
    with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as sock:
        sock.sendto(raw,("127.0.0.1",int(port)))
