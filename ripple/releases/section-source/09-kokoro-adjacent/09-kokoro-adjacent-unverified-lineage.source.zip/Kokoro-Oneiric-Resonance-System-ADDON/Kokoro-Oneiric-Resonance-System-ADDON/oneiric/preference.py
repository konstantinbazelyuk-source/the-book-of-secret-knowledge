from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Iterable

import numpy as np

from .config import OneiricConfig
from .models import DreamMetrics

FEATURES = [
    "coherence",
    "novelty",
    "integration_gain",
    "beauty",
    "stability",
    "lucidity",
    "continuity",
    "agency",
    "loop_risk",
    "factual_risk",
    "energy_cost",
]


@dataclass(slots=True)
class PreferenceChoice:
    index: int
    scores: list[float]
    probabilities: list[float]


class DreamPreferenceModel:
    def __init__(self, config: OneiricConfig, state: dict | None = None):
        initial = np.array([config.preference_weights.get(name, 0.0) for name in FEATURES], dtype=np.float64)
        if state and isinstance(state.get("weights"), list) and len(state["weights"]) == len(FEATURES):
            initial = np.asarray(state["weights"], dtype=np.float64)
        self.weights = initial
        self.counts = np.ones(len(FEATURES), dtype=np.float64)
        if state and isinstance(state.get("counts"), list) and len(state["counts"]) == len(FEATURES):
            self.counts = np.maximum(1.0, np.asarray(state["counts"], dtype=np.float64))
        self.temperature = max(0.05, config.favorite_temperature)
        self.loop_threshold = float(config.loop_similarity_threshold)
        self.safety_indices = [FEATURES.index("loop_risk"), FEATURES.index("factual_risk"), FEATURES.index("energy_cost")]

    @staticmethod
    def vector(metrics: DreamMetrics) -> np.ndarray:
        return np.array([float(getattr(metrics, name)) for name in FEATURES], dtype=np.float64)

    def score(self, metrics: DreamMetrics) -> float:
        return float(np.dot(self.weights, self.vector(metrics)))

    def choose(self, candidates: Iterable[DreamMetrics], rng: np.random.Generator) -> PreferenceChoice:
        items = list(candidates)
        if not items:
            raise ValueError("at least one dream candidate is required")
        scores = np.array([self.score(item) for item in items], dtype=np.float64)
        loop_values = np.array([item.loop_risk for item in items], dtype=np.float64)
        # When at least one non-looping candidate exists, strongly disfavor candidates over the guardrail.
        if np.any(loop_values < self.loop_threshold):
            scores -= 1.25 * np.maximum(0.0, loop_values - self.loop_threshold)
        factual_values = np.array([item.factual_risk for item in items], dtype=np.float64)
        if np.any(factual_values < 0.25):
            scores -= 2.0 * np.maximum(0.0, factual_values - 0.25)
        # Uncertainty bonus keeps preference from freezing too early.
        exploration = 0.06 * np.sqrt(np.sum(1.0 / self.counts))
        scores += exploration
        logits = scores / self.temperature
        logits -= float(np.max(logits))
        probabilities = np.exp(logits)
        probabilities /= max(float(probabilities.sum()), 1e-12)
        index = int(rng.choice(len(items), p=probabilities))
        return PreferenceChoice(index=index, scores=scores.tolist(), probabilities=probabilities.tolist())

    def update(self, metrics: DreamMetrics, reward: float, learning_rate: float = 0.045) -> None:
        features = self.vector(metrics)
        prediction = math.tanh(float(np.dot(self.weights, features)))
        error = float(np.clip(reward, -1.0, 1.0)) - prediction
        self.weights += learning_rate * error * features / np.sqrt(self.counts)
        self.weights = np.clip(self.weights, -2.0, 2.0)
        # Safety penalties may become stronger, but preference learning cannot flip them positive.
        for index in self.safety_indices:
            self.weights[index] = min(-0.03, self.weights[index])
        self.counts += np.abs(features)

    def state_dict(self) -> dict:
        return {"features": FEATURES, "weights": self.weights.tolist(), "counts": self.counts.tolist()}
