from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np


@dataclass(slots=True)
class QuantumLikeResult:
    density_matrix: np.ndarray
    probabilities: np.ndarray
    phases: np.ndarray
    purity: float
    coherence: float
    entropy: float
    selected_index: int
    trace_error: float
    min_eigenvalue: float


def normalize_amplitudes(weights: np.ndarray, phases: np.ndarray) -> np.ndarray:
    weights = np.maximum(np.asarray(weights, dtype=np.float64), 0.0)
    if float(weights.sum()) <= 1e-12:
        weights = np.ones_like(weights)
    probabilities = weights / float(weights.sum())
    return np.sqrt(probabilities) * np.exp(1j * np.asarray(phases, dtype=np.float64))


def hermitian_hamiltonian(similarity: np.ndarray, values: np.ndarray, tension: np.ndarray) -> np.ndarray:
    similarity = np.asarray(similarity, dtype=np.float64)
    n = similarity.shape[0]
    if similarity.shape != (n, n):
        raise ValueError("similarity must be square")
    values = np.resize(np.asarray(values, dtype=np.float64), n)
    tension = np.resize(np.asarray(tension, dtype=np.float64), n)
    h = 0.42 * (similarity + similarity.T) / 2.0
    diagonal = 0.75 * values - 0.35 * tension
    np.fill_diagonal(h, diagonal)
    return h.astype(np.complex128)


def unitary_from_hamiltonian(hamiltonian: np.ndarray, dt: float) -> np.ndarray:
    # Hermitian eigendecomposition gives a numerically stable classical simulation of exp(-i H dt).
    eigenvalues, eigenvectors = np.linalg.eigh(hamiltonian)
    phases = np.exp(-1j * eigenvalues * float(dt))
    return (eigenvectors * phases) @ eigenvectors.conj().T


def von_neumann_entropy(density: np.ndarray) -> float:
    eigenvalues = np.linalg.eigvalsh((density + density.conj().T) / 2.0).real
    eigenvalues = np.clip(eigenvalues, 0.0, 1.0)
    eigenvalues /= max(float(eigenvalues.sum()), 1e-12)
    nonzero = eigenvalues[eigenvalues > 1e-12]
    if nonzero.size == 0:
        return 0.0
    return float(-np.sum(nonzero * np.log2(nonzero)))


def evolve_density(
    initial_weights: np.ndarray,
    initial_phases: np.ndarray,
    hamiltonian: np.ndarray,
    steps: int,
    dt: float,
    decoherence: float,
    context_bias: np.ndarray | None,
    rng: np.random.Generator,
) -> QuantumLikeResult:
    psi = normalize_amplitudes(initial_weights, initial_phases)
    density = np.outer(psi, psi.conj())
    n = density.shape[0]
    decoherence = float(np.clip(decoherence, 0.0, 1.0))
    if context_bias is not None:
        bias = np.resize(np.asarray(context_bias, dtype=np.float64), n)
        biased_h = hamiltonian.copy()
        biased_h[np.diag_indices(n)] += bias
    else:
        biased_h = hamiltonian
    unitary = unitary_from_hamiltonian(biased_h, dt)

    for _ in range(max(1, int(steps))):
        density = unitary @ density @ unitary.conj().T
        # Classical simulation of dephasing: retain diagonal probabilities while damping off-diagonal terms.
        diagonal = np.diag(np.diag(density))
        density = (1.0 - decoherence) * density + decoherence * diagonal
        density = (density + density.conj().T) / 2.0
        trace = np.trace(density).real
        density /= max(float(trace), 1e-12)

    probabilities = np.clip(np.real(np.diag(density)), 0.0, None)
    probabilities /= max(float(probabilities.sum()), 1e-12)
    selected = int(rng.choice(n, p=probabilities)) if n else 0
    purity = float(np.real(np.trace(density @ density)))
    off_diagonal = density - np.diag(np.diag(density))
    coherence = float(np.sum(np.abs(off_diagonal)) / max(1, n * (n - 1)))
    entropy = von_neumann_entropy(density)
    phase_vector = np.angle(np.sum(density, axis=1) + 1e-12)
    eigenvalues = np.linalg.eigvalsh(density).real
    return QuantumLikeResult(
        density_matrix=density,
        probabilities=probabilities,
        phases=phase_vector,
        purity=float(np.clip(purity, 0.0, 1.0)),
        coherence=max(0.0, coherence),
        entropy=max(0.0, entropy),
        selected_index=selected,
        trace_error=abs(float(np.trace(density).real) - 1.0),
        min_eigenvalue=float(np.min(eigenvalues)) if eigenvalues.size else 0.0,
    )


def l2_sample(vector: np.ndarray, count: int, rng: np.random.Generator) -> np.ndarray:
    """Quantum-inspired norm sampling on a classical vector; no quantum speedup is claimed."""
    weights = np.abs(np.asarray(vector)) ** 2
    if float(weights.sum()) <= 1e-12:
        weights = np.ones_like(weights, dtype=np.float64)
    probabilities = weights / float(weights.sum())
    count = max(1, min(int(count), probabilities.size))
    return rng.choice(probabilities.size, size=count, replace=False, p=probabilities)
