from __future__ import annotations
import ctypes, os, time
from dataclasses import dataclass

@dataclass(slots=True)
class ResourceState:
    cpu_percent: float | None
    on_ac_power: bool | None
    battery_percent: int | None
    allowed: bool
    reason: str

class _FILETIME(ctypes.Structure):
    _fields_=[('low',ctypes.c_uint32),('high',ctypes.c_uint32)]
    def value(self): return (int(self.high)<<32)|int(self.low)

class _SYSTEM_POWER_STATUS(ctypes.Structure):
    _fields_=[('ACLineStatus',ctypes.c_ubyte),('BatteryFlag',ctypes.c_ubyte),('BatteryLifePercent',ctypes.c_ubyte),('SystemStatusFlag',ctypes.c_ubyte),('BatteryLifeTime',ctypes.c_uint32),('BatteryFullLifeTime',ctypes.c_uint32)]

def _windows_cpu_sample(interval=.12):
    k=ctypes.windll.kernel32
    def sample():
        idle,kernel,user=_FILETIME(),_FILETIME(),_FILETIME()
        if not k.GetSystemTimes(ctypes.byref(idle),ctypes.byref(kernel),ctypes.byref(user)): return None
        return idle.value(),kernel.value(),user.value()
    a=sample();time.sleep(interval);b=sample()
    if not a or not b:return None
    idle=b[0]-a[0];total=(b[1]-a[1])+(b[2]-a[2])
    return max(0.0,min(100.0,100.0*(1.0-idle/max(1,total))))

def _windows_power():
    status=_SYSTEM_POWER_STATUS()
    if not ctypes.windll.kernel32.GetSystemPowerStatus(ctypes.byref(status)):return None,None
    ac=None if status.ACLineStatus==255 else status.ACLineStatus==1
    battery=None if status.BatteryLifePercent==255 else int(status.BatteryLifePercent)
    return ac,battery

def resource_state(max_cpu_percent=72.0,min_battery_percent=25,allow_on_battery=True)->ResourceState:
    cpu=None;ac=None;battery=None
    try:
        if os.name=='nt': cpu=_windows_cpu_sample();ac,battery=_windows_power()
        elif hasattr(os,'getloadavg'):
            cpu=min(100.0,100.0*os.getloadavg()[0]/max(1,os.cpu_count() or 1))
    except Exception: pass
    if cpu is not None and cpu>max_cpu_percent:return ResourceState(cpu,ac,battery,False,f'system CPU {cpu:.1f}% exceeds {max_cpu_percent:.1f}%')
    if ac is False and not allow_on_battery:return ResourceState(cpu,ac,battery,False,'battery dreaming is disabled')
    if ac is False and battery is not None and battery<min_battery_percent:return ResourceState(cpu,ac,battery,False,f'battery {battery}% is below {min_battery_percent}%')
    return ResourceState(cpu,ac,battery,True,'resources available')
