from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np


@dataclass(slots=True)
class OscillatorResult:
    phases: np.ndarray
    amplitudes: np.ndarray
    frequencies: np.ndarray
    order_history: np.ndarray
    energy_history: np.ndarray
    final_order: float
    mean_energy: float


def order_parameter(phases: np.ndarray, amplitudes: np.ndarray | None = None) -> float:
    if phases.size == 0:
        return 0.0
    weights = np.ones_like(phases) if amplitudes is None else np.maximum(amplitudes, 0.0)
    total = float(np.sum(weights))
    if total <= 1e-12:
        return 0.0
    vector = np.sum(weights * np.exp(1j * phases)) / total
    return float(abs(vector))


def evolve_kuramoto(
    phases: np.ndarray,
    natural_frequencies: np.ndarray,
    coupling_matrix: np.ndarray,
    amplitudes: np.ndarray,
    steps: int,
    dt: float,
    coupling_strength: float,
    noise_std: float,
    stochastic_resonance_noise: float,
    rng: np.random.Generator,
) -> OscillatorResult:
    phases = np.asarray(phases, dtype=np.float64).copy()
    omega = np.asarray(natural_frequencies, dtype=np.float64).copy()
    amplitudes = np.clip(np.asarray(amplitudes, dtype=np.float64).copy(), 0.01, 1.0)
    n = phases.size
    if n == 0:
        return OscillatorResult(phases, amplitudes, omega, np.zeros(0), np.zeros(0), 0.0, 0.0)
    coupling = np.asarray(coupling_matrix, dtype=np.float64)
    if coupling.shape != (n, n):
        raise ValueError("coupling_matrix must be N x N")
    np.fill_diagonal(coupling, 0.0)
    normalization = max(1.0, float(n - 1))
    orders = np.zeros(max(1, steps), dtype=np.float64)
    energies = np.zeros(max(1, steps), dtype=np.float64)

    for t in range(max(1, steps)):
        phase_difference = phases[np.newaxis, :] - phases[:, np.newaxis]
        interaction = np.sum(coupling * np.sin(phase_difference), axis=1) / normalization
        adaptive_noise = noise_std + stochastic_resonance_noise * (1.0 - order_parameter(phases, amplitudes))
        noise = rng.normal(0.0, adaptive_noise, size=n)
        dtheta = omega + coupling_strength * interaction + noise
        phases = (phases + dt * dtheta) % (2.0 * math.pi)
        # Small homeostatic amplitude update: coherent nodes strengthen, isolated nodes soften.
        local_coherence = np.abs(np.sum(coupling * np.exp(1j * phase_difference), axis=1)) / np.maximum(
            np.sum(np.abs(coupling), axis=1), 1e-12
        )
        amplitudes += dt * 0.08 * (local_coherence - amplitudes)
        amplitudes = np.clip(amplitudes, 0.03, 1.0)
        orders[t] = order_parameter(phases, amplitudes)
        pair_energy = -0.5 * coupling_strength * np.sum(coupling * np.cos(phase_difference)) / normalization
        kinetic = 0.5 * float(np.mean(dtheta**2))
        energies[t] = float(pair_energy / max(1, n) + kinetic)

    return OscillatorResult(
        phases=phases,
        amplitudes=amplitudes,
        frequencies=omega,
        order_history=orders,
        energy_history=energies,
        final_order=float(orders[-1]),
        mean_energy=float(np.mean(energies)),
    )
