from __future__ import annotations

import math
import time
from dataclasses import replace

import numpy as np

from .config import OneiricConfig
from .embedding import cosine
from .models import MemoryTrace


def _clip(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, float(value)))


def memory_priority(memory: MemoryTrace, config: OneiricConfig, now: float | None = None) -> float:
    now = time.time() if now is None else now
    age_days = max(0.0, (now - memory.created_at) / 86400.0)
    recency = math.exp(-age_days / 45.0)
    weakness = 1.0 - _clip(memory.confidence)
    components = {
        "salience": _clip(memory.salience),
        "uncertainty": _clip(memory.uncertainty),
        "value": _clip(memory.value),
        "unresolved": _clip(memory.unresolved),
        "novelty": _clip(memory.novelty),
        "weakness": weakness,
        "reward": _clip(0.5 + 0.5 * memory.reward),
    }
    score = sum(config.replay_weights.get(k, 0.0) * v for k, v in components.items())
    # Repeated access slowly lowers replay pressure unless unresolved remains high.
    habituation = 1.0 / math.sqrt(1.0 + max(0, memory.access_count) * 0.35)
    score *= 0.60 + 0.25 * recency + 0.15 * habituation
    score += 0.12 * memory.unresolved * habituation
    return max(1e-6, score)


def prioritized_replay(
    memories: list[MemoryTrace],
    config: OneiricConfig,
    rng: np.random.Generator,
    count: int | None = None,
) -> tuple[list[MemoryTrace], np.ndarray]:
    if not memories:
        return [], np.zeros(0, dtype=np.float64)
    count = count or config.max_memories_per_dream
    count = max(config.minimum_memories_per_dream, min(int(count), len(memories)))
    priorities = np.array([memory_priority(m, config) for m in memories], dtype=np.float64)
    priorities = priorities ** max(0.01, config.replay_alpha)
    temperature = max(0.05, config.replay_temperature)
    logits = np.log(priorities + 1e-12) / temperature
    logits -= np.max(logits)
    probabilities = np.exp(logits)
    probabilities /= max(float(probabilities.sum()), 1e-12)
    indices = rng.choice(len(memories), size=count, replace=False, p=probabilities)
    selected = [memories[int(i)] for i in indices]
    selected_probabilities = probabilities[indices]
    selected_probabilities /= max(float(selected_probabilities.sum()), 1e-12)
    return selected, selected_probabilities


def estimate_novelty(memory: MemoryTrace, existing: list[MemoryTrace]) -> float:
    if not existing:
        return 1.0
    vector = np.asarray(memory.embedding, dtype=np.float64)
    similarities = [cosine(vector, np.asarray(item.embedding, dtype=np.float64)) for item in existing]
    return _clip(1.0 - max(similarities, default=0.0))


def with_estimated_novelty(memory: MemoryTrace, existing: list[MemoryTrace]) -> MemoryTrace:
    return replace(memory, novelty=estimate_novelty(memory, existing))
