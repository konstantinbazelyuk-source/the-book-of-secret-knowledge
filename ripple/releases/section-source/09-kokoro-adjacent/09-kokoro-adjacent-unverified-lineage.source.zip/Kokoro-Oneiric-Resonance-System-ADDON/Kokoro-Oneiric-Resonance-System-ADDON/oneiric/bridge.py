from __future__ import annotations

from dataclasses import asdict, is_dataclass
from typing import Any


def _to_dict(value: Any) -> dict[str, Any]:
    if value is None:
        return {}
    if isinstance(value, dict):
        return value
    if hasattr(value, "to_dict"):
        try:
            return value.to_dict()
        except Exception:
            pass
    if is_dataclass(value):
        return asdict(value)
    if hasattr(value, "__dict__"):
        return {key: val for key, val in vars(value).items() if not key.startswith("_")}
    return {}


class OneiricSignalBridge:
    """Maps the existing Kokoro fragments into bounded dream-memory signals."""

    def interaction_payload(
        self,
        user_text: str,
        answer_text: str,
        psyche_packet: Any | None = None,
        heart_packet: Any | None = None,
        network_packet: Any | None = None,
    ) -> dict[str, Any]:
        psyche = _to_dict(psyche_packet)
        heart = _to_dict(heart_packet)
        network = _to_dict(network_packet)

        psyche_meta = psyche.get("metacognition", {}) if isinstance(psyche.get("metacognition"), dict) else {}
        uncertainty = float(
            network.get(
                "uncertainty",
                psyche_meta.get("uncertainty", psyche_meta.get("confidence_gap", 0.45)),
            )
            or 0.45
        )
        stability = float(heart.get("stability", 0.62) or 0.62)
        unresolved_count = len(psyche.get("unresolved_branches", []) or [])
        unresolved_count += len(heart.get("unresolved_themes", []) or [])
        unresolved_count += len(network.get("unresolved_branches", []) or [])
        value = 0.5
        dominant = heart.get("dominant_values", [])
        if dominant:
            try:
                value = float(sum(float(x.get("value", 0.5)) for x in dominant[:5]) / min(5, len(dominant)))
            except Exception:
                value = 0.5
        confidence = float(network.get("evidence_confidence", 1.0 - uncertainty) or (1.0 - uncertainty))
        reward = 0.18 * stability + 0.12 * value
        text = f"User experience:\n{user_text}\n\nKokoro response:\n{answer_text}"
        return {
            "text": text,
            "source": "conversation",
            "salience": min(1.0, 0.42 + 0.05 * unresolved_count + 0.20 * uncertainty),
            "uncertainty": max(0.0, min(1.0, uncertainty)),
            "value": max(0.0, min(1.0, value)),
            "unresolved": max(0.0, min(1.0, unresolved_count / 8.0)),
            "confidence": max(0.0, min(1.0, confidence)),
            "reward": max(-1.0, min(1.0, reward)),
            "tags": ["interaction", "continuity"],
            "metadata": {
                "psyche_cycle": psyche.get("cycle_id"),
                "heart_cycle": heart.get("cycle_id"),
                "network_packet": network.get("packet_id"),
                "heart_stability": stability,
                "unresolved_count": unresolved_count,
                "network_assertion_mode": network.get("assertion_mode"),
            },
        }

    def continuity_payload(self, psyche_board: Any | None) -> dict[str, Any] | None:
        if psyche_board is None or not hasattr(psyche_board, "continuity_capsule"):
            return None
        try:
            capsule = psyche_board.continuity_capsule()
        except Exception:
            return None
        return {
            "text": "Psyche continuity capsule: " + str(capsule),
            "source": "psyche-continuity",
            "salience": 0.82,
            "uncertainty": 0.28,
            "value": 0.78,
            "unresolved": min(1.0, len(capsule.get("unresolved", []) or []) / 6.0),
            "confidence": 0.72,
            "reward": 0.25,
            "tags": ["identity", "continuity", "psyche"],
            "metadata": capsule,
        }

    def heart_payload(self, heart_board: Any | None) -> dict[str, Any] | None:
        if heart_board is None:
            return None
        try:
            status = heart_board.status()
            themes = heart_board.store.themes("open", 12) if hasattr(heart_board, "store") else []
        except Exception:
            return None
        theme_labels = [getattr(theme, "label", str(theme)) for theme in themes]
        return {
            "text": "Heartspace state: " + str(status) + "\nOpen themes: " + "; ".join(theme_labels),
            "source": "heartspace-state",
            "salience": 0.72,
            "uncertainty": 0.30,
            "value": 0.90,
            "unresolved": min(1.0, len(theme_labels) / 10.0),
            "confidence": 0.70,
            "reward": 0.30,
            "tags": ["heartspace", "values", "open-themes"],
            "metadata": {"status": status, "themes": theme_labels},
        }

    def network_payload(self, network: Any | None) -> dict[str, Any] | None:
        if network is None:
            return None
        try:
            status = network.status()
            branches = network.store.branches("open", 16) if hasattr(network, "store") else []
        except Exception:
            return None
        return {
            "text": "Psyche Network status: " + str(status) + "\nOpen epistemic branches: " + str(branches),
            "source": "psyche-network-state",
            "salience": 0.62,
            "uncertainty": 0.58,
            "value": 0.55,
            "unresolved": min(1.0, len(branches) / 12.0),
            "confidence": 0.58,
            "reward": 0.05,
            "tags": ["network", "epistemic", "unresolved"],
            "metadata": {"status": status, "branches": branches[:16]},
        }
