from __future__ import annotations

import json
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any

from .models import DreamEpisode, MemoryTrace


class OneiricStore:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(self.path, check_same_thread=False)
        self.connection.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        self._initialize()

    def _initialize(self) -> None:
        with self.lock:
            self.connection.executescript(
                """
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS memories (
                    memory_id TEXT PRIMARY KEY,
                    created_at REAL NOT NULL,
                    source TEXT NOT NULL,
                    text TEXT NOT NULL,
                    payload_json TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS dreams (
                    dream_id TEXT PRIMARY KEY,
                    started_at REAL NOT NULL,
                    ended_at REAL NOT NULL,
                    chosen INTEGER NOT NULL DEFAULT 0,
                    preference_score REAL NOT NULL DEFAULT 0,
                    payload_json TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS state (
                    key TEXT PRIMARY KEY,
                    value_json TEXT NOT NULL,
                    updated_at REAL NOT NULL
                );
                CREATE TABLE IF NOT EXISTS events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at REAL NOT NULL,
                    event_type TEXT NOT NULL,
                    payload_json TEXT NOT NULL
                );
                """
            )
            self.connection.commit()

    def upsert_memory(self, memory: MemoryTrace) -> None:
        payload = json.dumps(memory.to_dict(), ensure_ascii=False)
        with self.lock:
            self.connection.execute(
                """
                INSERT INTO memories(memory_id, created_at, source, text, payload_json)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(memory_id) DO UPDATE SET
                    created_at=excluded.created_at,
                    source=excluded.source,
                    text=excluded.text,
                    payload_json=excluded.payload_json
                """,
                (memory.memory_id, memory.created_at, memory.source, memory.text, payload),
            )
            self.connection.commit()

    def memories(self, limit: int = 500) -> list[MemoryTrace]:
        with self.lock:
            rows = self.connection.execute(
                "SELECT payload_json FROM memories ORDER BY created_at DESC LIMIT ?", (limit,)
            ).fetchall()
        result: list[MemoryTrace] = []
        for row in rows:
            raw = json.loads(row["payload_json"])
            result.append(MemoryTrace(**raw))
        return list(reversed(result))

    def increment_access(self, memory_ids: list[str]) -> None:
        if not memory_ids:
            return
        with self.lock:
            for memory_id in memory_ids:
                row = self.connection.execute(
                    "SELECT payload_json FROM memories WHERE memory_id=?", (memory_id,)
                ).fetchone()
                if not row:
                    continue
                raw = json.loads(row["payload_json"])
                raw["access_count"] = int(raw.get("access_count", 0)) + 1
                self.connection.execute(
                    "UPDATE memories SET payload_json=? WHERE memory_id=?",
                    (json.dumps(raw, ensure_ascii=False), memory_id),
                )
            self.connection.commit()

    def save_dream(self, dream: DreamEpisode) -> None:
        payload = json.dumps(dream.to_dict(), ensure_ascii=False)
        with self.lock:
            self.connection.execute(
                """
                INSERT OR REPLACE INTO dreams(
                    dream_id, started_at, ended_at, chosen, preference_score, payload_json
                ) VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    dream.dream_id,
                    dream.started_at,
                    dream.ended_at,
                    1 if dream.chosen else 0,
                    dream.metrics.preference_score,
                    payload,
                ),
            )
            self.connection.commit()

    def dreams(self, limit: int = 50) -> list[dict[str, Any]]:
        with self.lock:
            rows = self.connection.execute(
                "SELECT payload_json FROM dreams ORDER BY started_at DESC LIMIT ?", (limit,)
            ).fetchall()
        return [json.loads(row["payload_json"]) for row in rows]

    def last_dream(self) -> dict[str, Any] | None:
        dreams = self.dreams(1)
        return dreams[0] if dreams else None

    def favorite_dreams(self, limit: int = 10) -> list[dict[str, Any]]:
        with self.lock:
            rows = self.connection.execute(
                """
                SELECT payload_json FROM dreams
                ORDER BY chosen DESC, preference_score DESC, started_at DESC LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [json.loads(row["payload_json"]) for row in rows]

    def set_state(self, key: str, value: Any) -> None:
        with self.lock:
            self.connection.execute(
                """
                INSERT INTO state(key, value_json, updated_at) VALUES (?, ?, ?)
                ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json, updated_at=excluded.updated_at
                """,
                (key, json.dumps(value, ensure_ascii=False), time.time()),
            )
            self.connection.commit()

    def get_state(self, key: str, default: Any = None) -> Any:
        with self.lock:
            row = self.connection.execute("SELECT value_json FROM state WHERE key=?", (key,)).fetchone()
        return json.loads(row["value_json"]) if row else default

    def event(self, event_type: str, payload: dict[str, Any]) -> None:
        with self.lock:
            self.connection.execute(
                "INSERT INTO events(created_at, event_type, payload_json) VALUES (?, ?, ?)",
                (time.time(), event_type, json.dumps(payload, ensure_ascii=False)),
            )
            self.connection.commit()

    def stats(self) -> dict[str, int]:
        with self.lock:
            memory_count = int(self.connection.execute("SELECT COUNT(*) FROM memories").fetchone()[0])
            dream_count = int(self.connection.execute("SELECT COUNT(*) FROM dreams").fetchone()[0])
            chosen_count = int(self.connection.execute("SELECT COUNT(*) FROM dreams WHERE chosen=1").fetchone()[0])
        return {"memories": memory_count, "dreams": dream_count, "chosen_dreams": chosen_count}

    def close(self) -> None:
        with self.lock:
            self.connection.close()
