@echo off
title Train Kokoro del Corazon
echo Kokoro del Corazon will train from random weights.
echo You can stop with Ctrl+C; it will save a checkpoint.
python kokoro_del_corazon.py train --quick
pause
