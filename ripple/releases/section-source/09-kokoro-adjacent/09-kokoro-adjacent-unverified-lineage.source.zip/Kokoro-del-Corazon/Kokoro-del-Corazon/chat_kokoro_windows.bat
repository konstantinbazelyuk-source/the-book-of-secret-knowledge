@echo off
title Kokoro del Corazon
python kokoro_del_corazon.py chat
pause
