# Kokoro del Corazon — From-Scratch Offline Model

Kokoro del Corazon is a **real decoder-only Transformer initialized with random weights**. It does not call OpenAI, Ollama, Hugging Face models, or any hosted AI. The only major external library is PyTorch, which performs the tensor mathematics.

## Windows: easiest route

1. Install **Python 3.11 or 3.12** from python.org. During installation, check **Add Python to PATH**.
2. Extract this ZIP to a normal folder, such as `Documents\Kokoro del CorazonAI`.
3. Double-click `setup_windows.bat`.
4. Double-click `train_kokoro_windows.bat`.
5. After training finishes, double-click `chat_kokoro_windows.bat`.

Training begins with random weights. The quick model is intentionally small enough for a laptop, but CPU training can still be slow. An NVIDIA GPU makes it much faster.

## Commands

```bash
python kokoro_del_corazon.py status
python kokoro_del_corazon.py train --quick
python kokoro_del_corazon.py chat
python kokoro_del_corazon.py evaluate
python kokoro_del_corazon.py add-data path\to\your_text.txt
python kokoro_del_corazon.py train --quick --resume --steps 2000
```

## Teach it

Edit `data/corpus.txt` and add examples in this form:

```text
User: What the person says
Kokoro del Corazon: The ideal answer
```

Then continue training:

```bash
python kokoro_del_corazon.py train --quick --resume --steps 2000
```

You can also append any UTF-8 `.txt` file:

```bash
python kokoro_del_corazon.py add-data my_book.txt
```

Only use text you created or have the legal right to train on.

## Honest expectations

This package is a complete working AI implementation, but it is a **small newborn model**, not a ready-made frontier assistant. It starts from random numbers and learns only from the bundled corpus and material you add. The included seed corpus is enough to test the entire pipeline, not enough for broad intelligence.

To approach strong general language ability, you will need:

- much more high-quality, legally usable training text
- a larger model
- an NVIDIA GPU or rented GPU
- systematic evaluations
- many rounds of training and correction

The advantage is genuine ownership and understanding: the tokenizer, architecture, weights, corpus, memory, and behavior are under your control.

## Files

- `kokoro_del_corazon.py` — the complete AI, trainer, generator, memory, and CLI
- `data/corpus.txt` — initial training material
- `checkpoints/kokoro_del_corazon.pt` — created after training
- `memory.jsonl` — created by chat and removable with `/forget`
- `ARCHITECTURE.md` — central design and scaling path
