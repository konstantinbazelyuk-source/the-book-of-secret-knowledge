# Kokoro CPU Adaptive Trainer

A separate training-control add-on for the existing Kokoro-del-Corazon-Foundry.

## Purpose

The original Nano launcher uses 32,768 tokens per optimizer step and 10,000
steps: 327,680,000 token exposures. On the measured laptop speed, that is
approximately half a year.

This trainer preserves the architecture and current checkpoint but changes the
training curriculum and stopping logic:

```text
128-token context → 256-token context → 512-token context
```

The model itself retains `max_seq_len=512`; shorter windows are only an efficient
early-training curriculum.

## Hardware adaptation

A local benchmark compares:

- FP32
- CPU BF16 autocast
- multiple PyTorch CPU thread counts

The fastest valid configuration is saved and used. This matters because BF16 is
not faster on every processor.

## Evidence-driven stopping

Each phase uses fixed validation windows. Training stops early when validation
fails to improve by the configured minimum for the configured patience period.
The best phase checkpoint is restored before progression.

## Preservation

- original source files: unchanged
- source checkpoint: frozen with SHA-256
- adaptive outputs: `checkpoints-adaptive`
- promotion to the normal checkpoint directory: explicit final step
