# Pause and recovery

The adaptive launcher always checks:

`checkpoints-adaptive\pretrain-adaptive-latest.pt`

When present, it restores:

- model weights
- optimizer state
- current phase
- current phase step
- total processed tokens
- best validation
- selected CPU settings

Pressing Ctrl+C once triggers a save after the most recently completed optimizer
step. Run the same Balanced launcher later to continue.

The source checkpoint remains frozen in `checkpoints-frozen`.
