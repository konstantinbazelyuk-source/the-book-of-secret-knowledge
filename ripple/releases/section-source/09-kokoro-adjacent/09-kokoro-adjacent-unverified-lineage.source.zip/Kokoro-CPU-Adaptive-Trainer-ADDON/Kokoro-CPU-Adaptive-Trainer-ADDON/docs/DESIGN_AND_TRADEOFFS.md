# Design and tradeoffs

## Preserved

- 3.7-million-parameter Kokoro Nano model
- model weights already learned
- 16k tokenizer actually trained on the project data
- prepared training and validation shards
- AdamW optimization family
- causal language-model objective
- final 512-token context capacity
- original SFT, DPO, evaluation, and chat stages

## Changed

- the optimizer is restarted from the current model weights with a new
  validation-driven schedule;
- context length is introduced progressively;
- total token exposure is corpus-relative rather than a fixed 10,000 giant steps;
- progress prints every optimizer step;
- CPU precision and thread count are benchmarked;
- fixed validation windows reduce measurement noise;
- early stopping prevents blind overtraining.

## Tradeoff

No reduced schedule can promise bit-for-bit equivalence to 327 million token
exposures. The original schedule was not a scientifically established quality
target; it was a ceiling. This package aims for equal or better held-out
validation quality with far less redundant work. The final evaluation remains
the deciding evidence.
