@echo off
setlocal
cd /d "%~dp0"
title Promote Kokoro Adaptive Checkpoint
set "BASE=%~dp0..\.."
"%BASE%\.venv\Scripts\python.exe" promote_adaptive.py --base "%BASE%"
pause
