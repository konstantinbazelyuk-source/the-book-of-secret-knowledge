@echo off
setlocal
cd /d "%~dp0"
title Kokoro CPU Adaptive Training - Balanced
set "BASE=%~dp0..\.."
if not exist "%BASE%\kokoro.py" (
 set /p "BASE=Paste the full path to Kokoro-del-Corazon-Foundry: "
 set "BASE=%BASE:"=%"
)
"%BASE%\.venv\Scripts\python.exe" adaptive_cpu_train.py --base "%BASE%" --profile balanced
pause
