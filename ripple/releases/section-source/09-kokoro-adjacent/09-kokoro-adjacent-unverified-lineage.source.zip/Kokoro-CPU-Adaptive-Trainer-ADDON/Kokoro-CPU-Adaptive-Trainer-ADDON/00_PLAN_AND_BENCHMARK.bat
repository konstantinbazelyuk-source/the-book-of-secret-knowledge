@echo off
setlocal
cd /d "%~dp0"
title Kokoro CPU Adaptive Plan
set "BASE=%~dp0..\.."
if not exist "%BASE%\kokoro.py" (
 set /p "BASE=Paste the full path to Kokoro-del-Corazon-Foundry: "
 set "BASE=%BASE:"=%"
)
if not exist "%BASE%\.venv\Scripts\python.exe" (
 echo Run the original windows\00_SETUP.bat first.
 pause
 exit /b 1
)
"%BASE%\.venv\Scripts\python.exe" adaptive_cpu_train.py --base "%BASE%" --profile balanced --plan-only
pause
