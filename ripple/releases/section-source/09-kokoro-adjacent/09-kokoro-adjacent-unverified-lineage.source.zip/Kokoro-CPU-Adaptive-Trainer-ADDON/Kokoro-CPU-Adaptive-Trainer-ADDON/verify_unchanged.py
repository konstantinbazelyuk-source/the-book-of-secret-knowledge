#!/usr/bin/env python3
from pathlib import Path
import argparse,hashlib,json
ADDON=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument("--base");a=p.parse_args()
base=Path(a.base).resolve() if a.base else ADDON.parents[1]
expected=json.loads((ADDON/"ORIGINAL_SOURCE_HASHES.json").read_text())
missing=[];changed=[]
for rel,wanted in expected.items():
    file=base/rel
    if not file.exists():missing.append(rel)
    elif hashlib.sha256(file.read_bytes()).hexdigest()!=wanted:changed.append(rel)
print(f"Original source files checked: {len(expected)}")
print(f"Missing: {len(missing)}")
print(f"Changed: {len(changed)}")
if missing:
    print("Missing files:");[print(" ",x) for x in missing]
if changed:
    print("Changed files:");[print(" ",x) for x in changed]
if missing or changed:raise SystemExit(1)
print("PASS: original Kokoro source files are unchanged.")
