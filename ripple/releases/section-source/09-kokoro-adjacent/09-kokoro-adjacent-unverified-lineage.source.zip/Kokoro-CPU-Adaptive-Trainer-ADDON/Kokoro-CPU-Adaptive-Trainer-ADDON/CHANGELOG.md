# 1.0.0

Added:

- CPU FP32/BF16 benchmark
- CPU thread benchmark
- automatic selected runtime
- 128/256/512 progressive context curriculum
- corpus-relative token budgets
- fixed-window validation
- early stopping and best-phase restoration
- one-step progress and ETA
- interrupt/resume state
- source checkpoint freezing and hashing
- separate adaptive checkpoint directory
- explicit safe promotion
- Windows QuickEdit disabling
- temporary Windows sleep prevention
- original-source verification

Original Kokoro source modified: 0 files.
