#!/usr/bin/env python3
from __future__ import annotations

import argparse
import contextlib
import csv
import ctypes
import hashlib
import json
import math
import os
import platform
import shutil
import sys
import time
from collections import deque
from dataclasses import asdict
from pathlib import Path
from typing import Any

ADDON = Path(__file__).resolve().parent
CONFIG_PATH = ADDON / "adaptive_config.json"

def find_base(explicit: str | None = None) -> Path:
    candidates: list[Path] = []
    if explicit:
        candidates.append(Path(explicit).expanduser().resolve())
    if len(ADDON.parents) >= 2:
        candidates.append(ADDON.parents[1])
    candidates += [
        ADDON.parent / "Kokoro-del-Corazon-Foundry",
        ADDON.parent.parent / "Kokoro-del-Corazon-Foundry",
        Path.cwd(),
    ]
    for p in candidates:
        p = p.resolve()
        if (p / "kokoro.py").is_file() and (p / "kokoro_core" / "model.py").is_file():
            return p
    raise FileNotFoundError(
        "Original Kokoro-del-Corazon-Foundry was not found. "
        "Use --base C:\\Kokoro-del-Corazon-Foundry"
    )

class WindowsTrainingGuard:
    """Prevents accidental console selection pauses and system sleep during training."""
    STD_INPUT_HANDLE = -10
    ENABLE_QUICK_EDIT_MODE = 0x0040
    ENABLE_EXTENDED_FLAGS = 0x0080
    ES_CONTINUOUS = 0x80000000
    ES_SYSTEM_REQUIRED = 0x00000001
    ES_DISPLAY_REQUIRED = 0x00000002

    def __init__(self, disable_quick_edit: bool = True, prevent_sleep: bool = True):
        self.disable_quick_edit = disable_quick_edit
        self.prevent_sleep = prevent_sleep
        self.kernel32 = None
        self.handle = None
        self.original_mode = None

    def __enter__(self):
        if os.name != "nt":
            return self
        try:
            self.kernel32 = ctypes.windll.kernel32
            if self.prevent_sleep:
                self.kernel32.SetThreadExecutionState(
                    self.ES_CONTINUOUS | self.ES_SYSTEM_REQUIRED | self.ES_DISPLAY_REQUIRED
                )
            if self.disable_quick_edit:
                self.handle = self.kernel32.GetStdHandle(self.STD_INPUT_HANDLE)
                mode = ctypes.c_uint()
                if self.kernel32.GetConsoleMode(self.handle, ctypes.byref(mode)):
                    self.original_mode = mode.value
                    new_mode = (mode.value | self.ENABLE_EXTENDED_FLAGS) & ~self.ENABLE_QUICK_EDIT_MODE
                    self.kernel32.SetConsoleMode(self.handle, new_mode)
        except Exception:
            pass
        return self

    def __exit__(self, exc_type, exc, tb):
        if os.name == "nt" and self.kernel32 is not None:
            try:
                if self.handle is not None and self.original_mode is not None:
                    self.kernel32.SetConsoleMode(self.handle, self.original_mode)
                if self.prevent_sleep:
                    self.kernel32.SetThreadExecutionState(self.ES_CONTINUOUS)
            except Exception:
                pass
        return False

def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))

def atomic_json(data: dict[str, Any], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    os.replace(temp, path)

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def format_seconds(seconds: float) -> str:
    if not math.isfinite(seconds):
        return "unknown"
    seconds = max(0, int(seconds))
    days, rem = divmod(seconds, 86400)
    hours, rem = divmod(rem, 3600)
    minutes, secs = divmod(rem, 60)
    if days:
        return f"{days}d {hours}h {minutes}m"
    if hours:
        return f"{hours}h {minutes}m"
    if minutes:
        return f"{minutes}m {secs}s"
    return f"{secs}s"

def discover_source_checkpoint(base: Path) -> Path:
    candidates = [
        base / "checkpoints" / "pretrain-latest.pt",
        base / "checkpoints" / "pretrain-best.pt",
    ]
    for p in candidates:
        if p.exists():
            return p
    raise FileNotFoundError(
        "No pretraining checkpoint exists. Let the current optimizer step finish, "
        "stop it with Ctrl+C, answer Y, then run this trainer."
    )

def freeze_checkpoint(base: Path, source: Path) -> Path:
    frozen = base / "checkpoints-frozen"
    frozen.mkdir(exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    destination = frozen / f"pre-adaptive-{source.stem}-{stamp}.pt"
    shutil.copy2(source, destination)
    digest = sha256(destination)
    destination.with_suffix(destination.suffix + ".sha256").write_text(
        f"{digest}  {destination.name}\n", encoding="utf-8"
    )
    return destination

def prepared_stats(base: Path) -> tuple[int, int, dict[str, Any]]:
    manifest_path = base / "artifacts" / "prepared" / "manifest.json"
    if not manifest_path.exists():
        raise FileNotFoundError("Prepared data manifest is missing. Run windows\\04_PREPARE_DATA.bat.")
    manifest = load_json(manifest_path)
    stats = manifest.get("stats", {})
    train_tokens = int(stats.get("train_tokens", 0))
    validation_tokens = int(stats.get("validation_tokens", 0))
    if train_tokens <= 0:
        raise ValueError("Prepared training token count is zero.")
    return train_tokens, validation_tokens, manifest

def candidate_threads(maximum: int = 5) -> list[int]:
    logical = max(1, os.cpu_count() or 1)
    values = [1, 2, 4, max(1, logical // 2), logical]
    unique = []
    for x in values:
        x = max(1, min(logical, x))
        if x not in unique:
            unique.append(x)
    if len(unique) > maximum:
        keep = [unique[0], unique[-1]]
        middle = unique[1:-1]
        while len(keep) < maximum and middle:
            keep.insert(-1, middle.pop(len(middle)//2))
        unique = sorted(set(keep))
    return unique

def precision_context(torch, precision: str):
    if precision == "bf16":
        return torch.autocast(device_type="cpu", dtype=torch.bfloat16)
    return contextlib.nullcontext()

def benchmark_runtime(base: Path, source: Path, cfg: dict[str, Any], force: bool = False) -> dict[str, Any]:
    import torch
    sys.path.insert(0, str(base))
    from kokoro_core.config import ModelConfig
    from kokoro_core.data import load_split_dataset
    from kokoro_core.model import KokoroModel

    report_path = ADDON / "state" / "benchmark.json"
    if report_path.exists() and not force:
        prior = load_json(report_path)
        if prior.get("checkpoint_sha256") == sha256(source):
            return prior

    payload = torch.load(source, map_location="cpu", weights_only=False)
    model_cfg = ModelConfig.from_dict(payload["model_config"])
    model = KokoroModel(model_cfg)
    model.load_state_dict(payload["model_state"], strict=True)
    model.train()

    bench_cfg = cfg["benchmark"]
    seq_len = min(int(bench_cfg["sequence_length"]), model_cfg.max_seq_len)
    batch_size = int(bench_cfg["batch_size"])
    dataset = load_split_dataset(
        base / "artifacts" / "prepared", "train", seq_len, 93821
    )
    x, y = dataset.sample(batch_size, torch.device("cpu"))

    try:
        torch.set_num_interop_threads(1)
    except RuntimeError:
        pass

    results = []
    precisions = ["fp32", "bf16"]
    for threads in candidate_threads(int(bench_cfg.get("maximum_thread_candidates", 5))):
        torch.set_num_threads(threads)
        for precision in precisions:
            ok = True
            error = ""
            elapsed = math.inf
            tokens = x.numel()
            try:
                for _ in range(int(bench_cfg.get("warmup_iterations", 1))):
                    model.zero_grad(set_to_none=True)
                    with precision_context(torch, precision):
                        _, loss = model(x, y)
                    loss.backward()
                start = time.perf_counter()
                for _ in range(int(bench_cfg.get("timed_iterations", 1))):
                    model.zero_grad(set_to_none=True)
                    with precision_context(torch, precision):
                        _, loss = model(x, y)
                    loss.backward()
                elapsed = time.perf_counter() - start
                if not math.isfinite(float(loss.detach())):
                    raise FloatingPointError("non-finite loss")
            except Exception as exc:
                ok = False
                error = str(exc)
            tok_s = (
                tokens * int(bench_cfg.get("timed_iterations", 1)) / elapsed
                if ok and elapsed > 0 else 0.0
            )
            results.append({
                "threads": threads,
                "precision": precision,
                "tokens_per_second": round(tok_s, 3),
                "elapsed_seconds": None if not math.isfinite(elapsed) else round(elapsed, 4),
                "ok": ok,
                "error": error,
            })

    good = [r for r in results if r["ok"] and r["tokens_per_second"] > 0]
    if not good:
        raise RuntimeError("Every CPU benchmark configuration failed.")
    selected = max(good, key=lambda r: r["tokens_per_second"])
    report = {
        "format_version": 1,
        "created_at": time.time(),
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "torch": torch.__version__,
        "logical_cpu_count": os.cpu_count(),
        "cpu_capability": getattr(torch.backends.cpu, "get_cpu_capability", lambda: "unknown")(),
        "checkpoint": str(source),
        "checkpoint_sha256": sha256(source),
        "sequence_length": seq_len,
        "batch_size": batch_size,
        "results": results,
        "selected": selected,
    }
    atomic_json(report, report_path)
    return report

def build_plan(
    train_tokens: int,
    model_max_seq_len: int,
    cfg: dict[str, Any],
    profile_name: str,
    measured_tok_s: float,
) -> dict[str, Any]:
    if profile_name not in cfg["profiles"]:
        raise ValueError(f"Unknown profile {profile_name!r}")
    target_per_step = int(cfg["tokens_per_optimizer_step"])
    phases = []
    total_tokens = 0
    for index, item in enumerate(cfg["profiles"][profile_name]):
        seq = min(int(item["sequence_length"]), model_max_seq_len)
        epochs = float(item["epochs"])
        batch_size = 1
        grad_accum = max(1, round(target_per_step / (batch_size * seq)))
        tokens_per_step = batch_size * grad_accum * seq
        target_tokens = max(tokens_per_step, int(train_tokens * epochs))
        steps = math.ceil(target_tokens / tokens_per_step)
        actual_tokens = steps * tokens_per_step
        phases.append({
            "index": index,
            "sequence_length": seq,
            "epochs": epochs,
            "batch_size": batch_size,
            "grad_accum_steps": grad_accum,
            "tokens_per_step": tokens_per_step,
            "target_tokens": actual_tokens,
            "maximum_steps": steps,
        })
        total_tokens += actual_tokens
    original_tokens = 327_680_000
    estimate = total_tokens / max(1e-6, measured_tok_s)
    return {
        "profile": profile_name,
        "train_tokens": train_tokens,
        "model_max_seq_len": model_max_seq_len,
        "phases": phases,
        "total_target_tokens": total_tokens,
        "estimated_seconds_at_benchmark_speed": estimate,
        "estimated_time": format_seconds(estimate),
        "original_default_token_exposures": original_tokens,
        "work_reduction_factor": round(original_tokens / total_tokens, 2),
    }

def create_optimizer(torch, model, opt_cfg: dict[str, Any]):
    decay, no_decay = [], []
    for name, p in model.named_parameters():
        if not p.requires_grad:
            continue
        if p.dim() >= 2 and not name.endswith("norm.weight"):
            decay.append(p)
        else:
            no_decay.append(p)
    groups = [
        {"params": decay, "weight_decay": float(opt_cfg["weight_decay"])},
        {"params": no_decay, "weight_decay": 0.0},
    ]
    return torch.optim.AdamW(
        groups,
        lr=float(opt_cfg["learning_rate"]),
        betas=(float(opt_cfg["beta1"]), float(opt_cfg["beta2"])),
        eps=1e-8,
    )

def cosine_lr(token_position: int, total_tokens: int, cfg: dict[str, Any]) -> float:
    peak = float(cfg["learning_rate"])
    minimum = float(cfg["minimum_learning_rate"])
    warmup = max(1, int(total_tokens * float(cfg["warmup_fraction"])))
    if token_position < warmup:
        return peak * (token_position + 1) / warmup
    ratio = min(1.0, (token_position - warmup) / max(1, total_tokens - warmup))
    return minimum + 0.5 * (peak - minimum) * (1.0 + math.cos(math.pi * ratio))

def checkpoint_payload(
    model,
    optimizer,
    source_payload: dict[str, Any],
    project_name: str,
    original_step: int,
    best_validation: float,
    adaptive_state: dict[str, Any],
) -> dict[str, Any]:
    return {
        "format_version": 2,
        "phase": "pretrain",
        "step": original_step + int(adaptive_state["completed_optimizer_steps"]),
        "best_validation": best_validation,
        "model_config": model.config_dict(),
        "project_name": project_name,
        "model_state": model.state_dict(),
        "optimizer_state": optimizer.state_dict(),
        "scaler_state": None,
        "train_config": source_payload.get("train_config", {}),
        "adaptive_state": adaptive_state,
        "source_checkpoint": adaptive_state.get("source_checkpoint"),
        "source_checkpoint_sha256": adaptive_state.get("source_checkpoint_sha256"),
    }

def atomic_torch_save(torch, payload: dict[str, Any], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    torch.save(payload, temp)
    os.replace(temp, path)

def save_adaptive(
    torch, output: Path, model, optimizer, source_payload, project_name,
    original_step: int, best_validation: float, state: dict[str, Any],
    phase_best: bool = False, final_best: bool = False
) -> Path:
    payload = checkpoint_payload(
        model, optimizer, source_payload, project_name,
        original_step, best_validation, state
    )
    latest = output / "pretrain-adaptive-latest.pt"
    atomic_torch_save(torch, payload, latest)
    if phase_best:
        atomic_torch_save(
            torch, payload,
            output / f"pretrain-adaptive-phase-{int(state['phase_index']) + 1}-best.pt"
        )
    if final_best:
        atomic_torch_save(torch, payload, output / "pretrain-adaptive-best.pt")
    return latest

def fixed_validation_batches(dataset, batch_size: int, count: int, torch):
    batches = []
    for _ in range(count):
        x, y = dataset.sample(batch_size, torch.device("cpu"))
        batches.append((x, y))
    return batches

def evaluate(model, batches, torch, precision: str) -> float:
    model.eval()
    losses = []
    with torch.inference_mode():
        for x, y in batches:
            with precision_context(torch, precision):
                _, loss = model(x, y)
            losses.append(float(loss.item()))
    model.train()
    return sum(losses) / max(1, len(losses))

def append_csv(path: Path, row: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    exists = path.exists()
    with path.open("a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(row))
        if not exists:
            w.writeheader()
        w.writerow(row)

def load_adaptive_resume(torch, path: Path, model, optimizer) -> tuple[dict[str, Any], float]:
    payload = torch.load(path, map_location="cpu", weights_only=False)
    model.load_state_dict(payload["model_state"], strict=True)
    if payload.get("optimizer_state"):
        optimizer.load_state_dict(payload["optimizer_state"])
    state = dict(payload.get("adaptive_state") or {})
    return state, float(payload.get("best_validation", math.inf))

def run_training(base: Path, args, cfg: dict[str, Any]) -> None:
    import torch
    sys.path.insert(0, str(base))
    from kokoro_core.config import ModelConfig
    from kokoro_core.data import load_split_dataset
    from kokoro_core.model import KokoroModel

    source = discover_source_checkpoint(base)
    adaptive_output = base / "checkpoints-adaptive"
    adaptive_output.mkdir(exist_ok=True)
    resume_path = adaptive_output / "pretrain-adaptive-latest.pt"

    source_payload = torch.load(source, map_location="cpu", weights_only=False)
    model_cfg = ModelConfig.from_dict(source_payload["model_config"])
    train_tokens, validation_tokens, _ = prepared_stats(base)

    benchmark = benchmark_runtime(base, source, cfg, force=args.rebenchmark)
    selected = benchmark["selected"]
    threads = int(selected["threads"])
    precision = str(selected["precision"])
    torch.set_num_threads(threads)
    try:
        torch.set_num_interop_threads(1)
    except RuntimeError:
        pass

    plan = build_plan(
        train_tokens, model_cfg.max_seq_len, cfg, args.profile,
        float(selected["tokens_per_second"])
    )
    plan.update({
        "selected_runtime": selected,
        "source_checkpoint": str(source),
        "source_checkpoint_sha256": sha256(source),
        "created_at": time.time(),
    })
    atomic_json(plan, ADDON / "state" / "adaptive_plan.json")

    print("\nKOKORO — CPU ADAPTIVE TRAINING PLAN")
    print(f"Source checkpoint: {source}")
    print(f"Saved source step: {int(source_payload.get('step', -1)) + 1}")
    print(f"CPU setting selected: {threads} threads, {precision}")
    print(f"Benchmark: {selected['tokens_per_second']:,.1f} tokens/second at sequence {benchmark['sequence_length']}")
    print(f"Prepared training tokens: {train_tokens:,}")
    print(f"Adaptive target: {plan['total_target_tokens']:,} token exposures")
    print(f"Original default: {plan['original_default_token_exposures']:,} token exposures")
    print(f"Planned work reduction: {plan['work_reduction_factor']:.1f}x")
    print(f"Rough benchmark estimate: {plan['estimated_time']}")
    print("Actual time changes with sequence length, heat, battery mode, and other programs.\n")
    for phase in plan["phases"]:
        print(
            f"Phase {phase['index']+1}: seq {phase['sequence_length']} | "
            f"{phase['epochs']:.1f} corpus passes | {phase['maximum_steps']:,} steps | "
            f"{phase['tokens_per_step']:,} tokens/step"
        )
    print()

    if args.plan_only:
        print("Plan-only mode complete. No model weights were changed.")
        return

    if not resume_path.exists() and cfg["safety"].get("freeze_source_checkpoint", True):
        frozen = freeze_checkpoint(base, source)
        print(f"Frozen safety copy: {frozen}\n")

    model = KokoroModel(model_cfg)
    model.load_state_dict(source_payload["model_state"], strict=True)
    model.to(torch.device("cpu"))
    model.train()
    optimizer = create_optimizer(torch, model, cfg["optimizer"])

    state = {
        "format_version": 1,
        "profile": args.profile,
        "phase_index": 0,
        "step_in_phase": 0,
        "tokens_in_phase": 0,
        "total_tokens_seen": 0,
        "completed_optimizer_steps": 0,
        "source_checkpoint": str(source),
        "source_checkpoint_sha256": sha256(source),
        "selected_threads": threads,
        "selected_precision": precision,
        "plan": plan,
        "interrupted": False,
        "complete": False,
    }
    best_validation = math.inf
    if resume_path.exists():
        state, best_validation = load_adaptive_resume(torch, resume_path, model, optimizer)
        saved_profile = state.get("profile")
        if saved_profile and saved_profile != args.profile:
            raise ValueError(
                f"Existing adaptive checkpoint uses profile {saved_profile!r}. "
                f"Resume it with that same launcher, or move checkpoints-adaptive before starting {args.profile!r}."
            )
        if state.get("complete"):
            print("Adaptive training is already marked complete.")
            return
        print(
            f"Resuming adaptive training at phase {int(state.get('phase_index',0))+1}, "
            f"step {int(state.get('step_in_phase',0))+1}.\n"
        )

    total_target = int(plan["total_target_tokens"])
    opt_cfg = cfg["optimizer"]
    val_cfg = cfg["validation"]
    original_step = int(source_payload.get("step", -1))
    started = time.time()
    recent_rates: deque[float] = deque(maxlen=12)
    log_path = base / "logs" / "adaptive-pretrain.csv"
    interrupted = False

    try:
        for phase_index in range(int(state["phase_index"]), len(plan["phases"])):
            phase = plan["phases"][phase_index]
            seq = int(phase["sequence_length"])
            batch_size = int(phase["batch_size"])
            grad_accum = int(phase["grad_accum_steps"])
            max_steps = int(phase["maximum_steps"])
            tokens_per_step = int(phase["tokens_per_step"])

            train_data = load_split_dataset(
                base / "artifacts" / "prepared", "train", seq,
                1337 + phase_index * 1000
            )
            val_data = load_split_dataset(
                base / "artifacts" / "prepared", "validation", seq,
                91337 + phase_index * 1000
            )
            fixed_val = fixed_validation_batches(
                val_data, batch_size, int(val_cfg["batches"]), torch
            )
            eval_every = max(
                1,
                math.ceil(
                    train_tokens /
                    max(1, int(val_cfg["evaluations_per_epoch"]) * tokens_per_step)
                )
            )
            phase_best_loss = evaluate(model, fixed_val, torch, precision)
            best_validation = phase_best_loss
            phase_best_path = adaptive_output / f"pretrain-adaptive-phase-{phase_index+1}-best.pt"
            patience_count = 0

            if phase_index != int(state.get("phase_index", 0)):
                state["step_in_phase"] = 0
                state["tokens_in_phase"] = 0
            state["phase_index"] = phase_index

            print(
                f"\nPHASE {phase_index+1}/{len(plan['phases'])} — "
                f"sequence {seq}, initial validation {phase_best_loss:.4f}"
            )
            save_adaptive(
                torch, adaptive_output, model, optimizer, source_payload,
                source_payload.get("project_name", "Kokoro Nano"),
                original_step, phase_best_loss, state, phase_best=True
            )

            for step in range(int(state["step_in_phase"]), max_steps):
                step_start = time.perf_counter()
                lr = cosine_lr(
                    int(state["total_tokens_seen"]), total_target, opt_cfg
                )
                for group in optimizer.param_groups:
                    group["lr"] = lr
                optimizer.zero_grad(set_to_none=True)
                accumulated = 0.0
                for _ in range(grad_accum):
                    x, y = train_data.sample(batch_size, torch.device("cpu"))
                    with precision_context(torch, precision):
                        _, loss = model(x, y)
                        scaled = loss / grad_accum
                    scaled.backward()
                    accumulated += float(loss.detach().item())
                grad_norm = torch.nn.utils.clip_grad_norm_(
                    model.parameters(), float(opt_cfg["grad_clip"])
                )
                optimizer.step()

                elapsed_step = max(1e-6, time.perf_counter() - step_start)
                rate = tokens_per_step / elapsed_step
                recent_rates.append(rate)
                average_rate = sum(recent_rates) / len(recent_rates)

                state["step_in_phase"] = step + 1
                state["tokens_in_phase"] = int(state["tokens_in_phase"]) + tokens_per_step
                state["total_tokens_seen"] = int(state["total_tokens_seen"]) + tokens_per_step
                state["completed_optimizer_steps"] = int(state["completed_optimizer_steps"]) + 1
                state["interrupted"] = False

                remaining = max(0, total_target - int(state["total_tokens_seen"]))
                eta = remaining / max(1e-6, average_rate)
                avg_loss = accumulated / grad_accum
                print(
                    f"phase {phase_index+1} step {step+1:>5}/{max_steps} | "
                    f"loss {avg_loss:.4f} | lr {lr:.2e} | "
                    f"grad {float(grad_norm):.2f} | {rate:,.0f} tok/s | "
                    f"ETA {format_seconds(eta)}"
                )
                append_csv(log_path, {
                    "time": time.time(),
                    "phase": phase_index + 1,
                    "sequence_length": seq,
                    "step_in_phase": step + 1,
                    "total_optimizer_steps": state["completed_optimizer_steps"],
                    "total_tokens_seen": state["total_tokens_seen"],
                    "loss": avg_loss,
                    "learning_rate": lr,
                    "grad_norm": float(grad_norm),
                    "tokens_per_second": rate,
                    "eta_seconds": eta,
                })

                should_eval = ((step + 1) % eval_every == 0) or (step + 1 == max_steps)
                if should_eval:
                    validation = evaluate(model, fixed_val, torch, precision)
                    improved = validation < phase_best_loss - float(val_cfg["minimum_improvement"])
                    print(
                        f"  fixed validation {validation:.4f} | "
                        f"phase best {phase_best_loss:.4f} | "
                        f"{'improved' if improved else 'no material improvement'}"
                    )
                    if improved:
                        phase_best_loss = validation
                        patience_count = 0
                        best_validation = validation
                        save_adaptive(
                            torch, adaptive_output, model, optimizer, source_payload,
                            source_payload.get("project_name", "Kokoro Nano"),
                            original_step, best_validation, state, phase_best=True,
                            final_best=(phase_index == len(plan["phases"]) - 1)
                        )
                    else:
                        patience_count += 1
                        save_adaptive(
                            torch, adaptive_output, model, optimizer, source_payload,
                            source_payload.get("project_name", "Kokoro Nano"),
                            original_step, min(best_validation, validation), state
                        )
                    if patience_count >= int(val_cfg["patience"]):
                        print(
                            "  Early stop: fixed validation stopped improving. "
                            "Restoring the best checkpoint for this phase."
                        )
                        best_payload = torch.load(phase_best_path, map_location="cpu", weights_only=False)
                        model.load_state_dict(best_payload["model_state"], strict=True)
                        if best_payload.get("optimizer_state"):
                            optimizer.load_state_dict(best_payload["optimizer_state"])
                        break

            # Always progress from the strongest fixed-validation checkpoint
            # of the phase, not merely the last chronological update.
            best_payload = torch.load(phase_best_path, map_location="cpu", weights_only=False)
            model.load_state_dict(best_payload["model_state"], strict=True)
            if best_payload.get("optimizer_state"):
                optimizer.load_state_dict(best_payload["optimizer_state"])
            best_validation = float(best_payload.get("best_validation", phase_best_loss))

            state["phase_index"] = phase_index + 1
            state["step_in_phase"] = 0
            state["tokens_in_phase"] = 0
            save_adaptive(
                torch, adaptive_output, model, optimizer, source_payload,
                source_payload.get("project_name", "Kokoro Nano"),
                original_step, best_validation, state
            )

        state["complete"] = True
        state["interrupted"] = False
        state["completed_at"] = time.time()
        state["elapsed_seconds_this_run"] = time.time() - started

        # The final model is saved as the adaptive best even when the final
        # evaluation did not exceed minimum_delta; this guarantees a usable result.
        save_adaptive(
            torch, adaptive_output, model, optimizer, source_payload,
            source_payload.get("project_name", "Kokoro Nano"),
            original_step, best_validation, state, final_best=True
        )
        report = {
            "complete": True,
            "profile": args.profile,
            "source_checkpoint": str(source),
            "adaptive_checkpoint": str(adaptive_output / "pretrain-adaptive-best.pt"),
            "total_tokens_seen": state["total_tokens_seen"],
            "optimizer_steps": state["completed_optimizer_steps"],
            "best_validation": best_validation,
            "elapsed_seconds_this_run": state["elapsed_seconds_this_run"],
            "elapsed": format_seconds(state["elapsed_seconds_this_run"]),
            "selected_runtime": selected,
            "plan": plan,
        }
        atomic_json(report, ADDON / "state" / "completion_report.json")
        print("\nADAPTIVE PRETRAINING COMPLETE")
        print(f"Best checkpoint: {adaptive_output / 'pretrain-adaptive-best.pt'}")
        print("The original checkpoint remains unchanged.")
        print("Run 03_PROMOTE_ADAPTIVE_CHECKPOINT.bat before supervised fine-tuning.\n")

    except KeyboardInterrupt:
        interrupted = True
        state["interrupted"] = True
        print("\nPause requested. Saving the latest completed adaptive optimizer step...")
        save_adaptive(
            torch, adaptive_output, model, optimizer, source_payload,
            source_payload.get("project_name", "Kokoro Nano"),
            original_step, best_validation, state
        )
        print("Saved. Run the same launcher later to continue from this exact adaptive state.\n")
    finally:
        if interrupted:
            pass

def main():
    parser = argparse.ArgumentParser(description="Kokoro CPU Adaptive Trainer")
    parser.add_argument("--base")
    parser.add_argument("--profile", choices=["quick", "balanced", "deep"], default=None)
    parser.add_argument("--plan-only", action="store_true")
    parser.add_argument("--rebenchmark", action="store_true")
    args = parser.parse_args()

    cfg = load_json(CONFIG_PATH)
    args.profile = args.profile or cfg["default_profile"]
    base = find_base(args.base)

    safety = cfg.get("safety", {})
    with WindowsTrainingGuard(
        disable_quick_edit=bool(safety.get("disable_windows_quick_edit_during_training", True)),
        prevent_sleep=bool(safety.get("prevent_windows_sleep_during_training", True)),
    ):
        run_training(base, args, cfg)

if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"\nERROR: {exc}\n")
        raise
