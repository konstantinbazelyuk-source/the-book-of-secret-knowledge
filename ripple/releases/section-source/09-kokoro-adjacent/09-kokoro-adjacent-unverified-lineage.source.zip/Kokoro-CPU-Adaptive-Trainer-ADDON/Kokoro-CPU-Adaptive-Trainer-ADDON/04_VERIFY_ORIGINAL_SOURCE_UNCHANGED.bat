@echo off
setlocal
cd /d "%~dp0"
title Verify Original Kokoro Source
set "BASE=%~dp0..\.."
"%BASE%\.venv\Scripts\python.exe" verify_unchanged.py --base "%BASE%"
pause
