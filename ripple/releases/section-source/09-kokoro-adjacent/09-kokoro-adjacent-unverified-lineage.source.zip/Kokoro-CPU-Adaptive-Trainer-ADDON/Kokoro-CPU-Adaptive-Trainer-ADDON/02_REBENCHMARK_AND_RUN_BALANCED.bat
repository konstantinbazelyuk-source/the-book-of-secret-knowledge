@echo off
setlocal
cd /d "%~dp0"
title Kokoro CPU Adaptive Rebenchmark
set "BASE=%~dp0..\.."
"%BASE%\.venv\Scripts\python.exe" adaptive_cpu_train.py --base "%BASE%" --profile balanced --rebenchmark
pause
