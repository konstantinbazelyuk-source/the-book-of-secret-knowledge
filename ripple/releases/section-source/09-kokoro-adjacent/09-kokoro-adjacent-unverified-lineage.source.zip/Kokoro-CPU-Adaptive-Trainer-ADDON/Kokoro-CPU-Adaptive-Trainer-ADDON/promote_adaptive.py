#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import argparse, hashlib, os, shutil, time

ADDON=Path(__file__).resolve().parent

def find_base(explicit=None):
    candidates=[]
    if explicit:candidates.append(Path(explicit).expanduser().resolve())
    if len(ADDON.parents)>=2:candidates.append(ADDON.parents[1])
    candidates += [ADDON.parent.parent/"Kokoro-del-Corazon-Foundry",Path.cwd()]
    for p in candidates:
        if (p/"kokoro.py").exists():return p
    raise FileNotFoundError("Original Kokoro Foundry not found.")

def digest(path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda:f.read(1024*1024),b""):h.update(block)
    return h.hexdigest()

p=argparse.ArgumentParser();p.add_argument("--base");a=p.parse_args()
base=find_base(a.base)
source=base/"checkpoints-adaptive"/"pretrain-adaptive-best.pt"
if not source.exists():
    raise SystemExit("Adaptive best checkpoint does not exist. Finish adaptive training first.")
checkpoints=base/"checkpoints";checkpoints.mkdir(exist_ok=True)
backup=base/"checkpoints-frozen";backup.mkdir(exist_ok=True)
stamp=time.strftime("%Y%m%d-%H%M%S")
for name in ("pretrain-best.pt","pretrain-latest.pt"):
    current=checkpoints/name
    if current.exists():
        frozen=backup/f"before-adaptive-promotion-{name[:-3]}-{stamp}.pt"
        shutil.copy2(current,frozen)
        frozen.with_suffix(frozen.suffix+".sha256").write_text(f"{digest(frozen)}  {frozen.name}\n")
for name in ("pretrain-best.pt","pretrain-latest.pt"):
    temp=(checkpoints/name).with_suffix(".pt.tmp")
    shutil.copy2(source,temp)
    os.replace(temp,checkpoints/name)
print("Adaptive checkpoint promoted safely.")
print("Original pre-adaptive checkpoints were frozen in checkpoints-frozen.")
print("You may now run windows\\07_SUPERVISED_FINETUNE.bat.")
