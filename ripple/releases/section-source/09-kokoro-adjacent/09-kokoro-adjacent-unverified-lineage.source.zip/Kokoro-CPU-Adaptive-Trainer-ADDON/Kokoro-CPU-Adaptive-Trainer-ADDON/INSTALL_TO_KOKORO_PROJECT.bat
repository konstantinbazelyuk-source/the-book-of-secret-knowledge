@echo off
setlocal
title Install Kokoro CPU Adaptive Trainer
cd /d "%~dp0"
echo.
echo This adds a separate CPU Adaptive Trainer.
echo It does not overwrite Kokoro source, data, tokenizer, or checkpoints.
echo.
set "TARGET=%~dp0..\Kokoro-del-Corazon-Foundry"
if exist "%TARGET%\kokoro.py" goto :found
set "TARGET=%~dp0..\..\Kokoro-del-Corazon-Foundry"
if exist "%TARGET%\kokoro.py" goto :found
set /p "TARGET=Paste the full path to Kokoro-del-Corazon-Foundry: "
set "TARGET=%TARGET:"=%"
:found
if not exist "%TARGET%\kokoro.py" goto :bad
set "DEST=%TARGET%\addons\Kokoro-CPU-Adaptive-Trainer"
if not exist "%TARGET%\addons" mkdir "%TARGET%\addons"
xcopy "%~dp0*" "%DEST%\" /E /I /Y /EXCLUDE:%~dp0install_exclude.txt >nul
if errorlevel 1 goto :copyfail
echo.
echo Installed at:
echo %DEST%
echo.
echo Open that folder and run 00_PLAN_AND_BENCHMARK.bat first.
pause
exit /b 0
:bad
echo Original Kokoro Foundry was not found.
pause
exit /b 1
:copyfail
echo Copy failed.
pause
exit /b 1
