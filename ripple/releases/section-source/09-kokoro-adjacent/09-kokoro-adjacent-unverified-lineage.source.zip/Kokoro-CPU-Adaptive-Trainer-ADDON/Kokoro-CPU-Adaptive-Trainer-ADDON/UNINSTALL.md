# Uninstall

Delete:

`Kokoro-del-Corazon-Foundry\addons\Kokoro-CPU-Adaptive-Trainer`

Optional generated folders:

- `checkpoints-adaptive`
- safety copies in `checkpoints-frozen`

Deleting the add-on does not delete the original model, tokenizer, curriculum,
Psyche, Heartspace, or Psyche Network.
