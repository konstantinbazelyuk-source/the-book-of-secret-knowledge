from pathlib import Path
import json,sys,tempfile,subprocess,math,hashlib
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import adaptive_cpu_train as a

cfg=json.loads((ROOT/"adaptive_config.json").read_text())
plan=a.build_plan(435000,512,cfg,"balanced",50.0)
assert len(plan["phases"])==3
assert [x["sequence_length"] for x in plan["phases"]]==[128,256,512]
assert plan["total_target_tokens"] < plan["original_default_token_exposures"]
assert plan["work_reduction_factor"] > 20
assert all(x["tokens_per_step"]>=512 for x in plan["phases"])
assert all(x["maximum_steps"]>0 for x in plan["phases"])
assert a.cosine_lr(0,100000,cfg["optimizer"]) > 0
assert a.cosine_lr(99999,100000,cfg["optimizer"]) >= cfg["optimizer"]["minimum_learning_rate"]*0.99
assert "h" in a.format_seconds(7200)
threads=a.candidate_threads()
assert threads==sorted(set(threads))
assert min(threads)>=1
print("Adaptive trainer tests passed: 12 invariants.")
