@echo off
setlocal
title Install Kokoro Psyche Network
cd /d "%~dp0"
echo.
echo This installs a FOURTH SEPARATE COMPONENT inside the existing Kokoro project.
echo It does not replace Kokoro, Psyche, Heartspace, data, tokenizer, or checkpoints.
echo.
set "TARGET=%~dp0..\Kokoro-del-Corazon-Foundry"
if exist "%TARGET%\kokoro.py" goto :found
set "TARGET=%~dp0..\..\Kokoro-del-Corazon-Foundry"
if exist "%TARGET%\kokoro.py" goto :found
set /p "TARGET=Paste the full path to Kokoro-del-Corazon-Foundry: "
set "TARGET=%TARGET:"=%"
:found
if not exist "%TARGET%\kokoro.py" goto :bad
set "DEST=%TARGET%\addons\Kokoro-Psyche-Network"
if not exist "%TARGET%\addons" mkdir "%TARGET%\addons"
xcopy "%~dp0*" "%DEST%\" /E /I /Y /EXCLUDE:%~dp0install_exclude.txt >nul
if errorlevel 1 goto :copyfail
echo.
echo Installed at:
echo %DEST%
echo.
echo Existing project files were not overwritten.
pause
exit /b 0
:bad
echo Original Kokoro Foundry was not found.
pause
exit /b 1
:copyfail
echo Copy failed.
pause
exit /b 1
