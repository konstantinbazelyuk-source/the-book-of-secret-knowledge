from pathlib import Path
import sys,time,json
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from psychernet import PsycheNetwork,SourceDocument,BoardSignalBridge
from psychernet.util import stable_id,hash_text
from psychernet.security import validate_public_url,UnsafeURL

def doc(title,text,url,publisher="Source",kind="official_documentation"):
    return SourceDocument(
        source_id=stable_id("src",url,title),provider="test",title=title,url=url,
        publisher=publisher,published_at="2026-01-01",retrieved_at=time.time(),
        source_type=kind,primary_status="official_record",text=text,snippet=text,
        content_hash=hash_text(text),extraction_quality=.9
    )

db=ROOT/"state"/"test.sqlite3";db.unlink(missing_ok=True)
net=PsycheNetwork(db,ROOT/"psychernet_config.json")
docs=[
 doc("One","The instrument measured a 15 percent improvement in accuracy.","https://one.example.org"),
 doc("Two","An independent instrument measured a 15 percent improvement in accuracy.","https://two.example.net"),
 doc("Three","I felt the change was personally meaningful, but it should not be universalized.","https://three.example.com",kind="user_generated"),
]
p=net.research("accuracy and experience",injected_documents=docs)
assert p.sources and p.claims
assert 0<=p.evidence_confidence<=1
assert 0<=p.expression_energy<=1
assert p.objective_candidate>0
assert p.subjective_significance>0
assert p.provenance_capsule["continuity_hash"]==net.continuity_hash
assert all(c.holographic_capsule for c in p.claims)
assert net.render_context(p).startswith("PSYCHE NETWORK")
bridge=BoardSignalBridge()
assert "NETWORK SIGNAL FOR PSYCHE" in bridge.psyche_input("test",p)
assert "NETWORK SIGNAL FOR HEARTSPACE" in bridge.heart_input("test",p)
telemetry=bridge.heart_telemetry(p,{"compute_headroom":.5})
assert "signal_reliability" in telemetry and "compute_headroom" in telemetry
net.set_capacity(.2)
low=net.research("many claims",injected_documents=docs*4)
assert low.effective_capacity<=.21
assert low.capacity_utilization>=p.capacity_utilization or low.recommended_depth=="brief_digest"
try:
    validate_public_url("http://127.0.0.1/private")
    raise AssertionError("loopback URL was not blocked")
except UnsafeURL:
    pass
try:
    validate_public_url("file:///etc/passwd")
    raise AssertionError("file URL was not blocked")
except UnsafeURL:
    pass
net.record_claim_outcome(p.claims[0].claim_id,p.claims[0].confidence,"supported")
assert net.store.calibration_report()["events"]==1
net.close();db.unlink(missing_ok=True)
print("Psyche Network tests passed: 18 invariants.")
