@echo off
setlocal
cd /d "%~dp0"
title Test Kokoro Psyche Network
set "BASE=%~dp0..\.."
if exist "%BASE%\.venv\Scripts\python.exe" (
 "%BASE%\.venv\Scripts\python.exe" tests\test_psychenet.py
 "%BASE%\.venv\Scripts\python.exe" research\run_experiments.py
) else (
 python tests\test_psychenet.py
 python research\run_experiments.py
)
pause
