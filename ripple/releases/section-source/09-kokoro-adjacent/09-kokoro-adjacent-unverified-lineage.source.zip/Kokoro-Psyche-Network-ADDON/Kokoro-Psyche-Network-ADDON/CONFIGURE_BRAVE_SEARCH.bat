@echo off
setlocal
title Configure Optional Brave Search
echo.
echo General web search requires your own Brave Search API key.
echo The key is stored as a Windows user environment variable, not inside Kokoro files.
echo Direct URLs, RSS, OpenAlex, Crossref, and arXiv do not use this key.
echo.
set /p "KEY=Paste Brave Search API key: "
if "%KEY%"=="" exit /b 1
setx KOKORO_BRAVE_API_KEY "%KEY%"
echo.
echo Saved. Close and reopen command windows before using it.
pause
