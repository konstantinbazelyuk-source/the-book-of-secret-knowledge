# Preservation report

This package adds only:

`Kokoro-del-Corazon-Foundry\addons\Kokoro-Psyche-Network`

It does not delete, replace, or edit:

- original Kokoro source;
- tokenizer or prepared data;
- current or completed checkpoints;
- original memory;
- Psyche Daughterboard;
- Heartspace Daughterboard.

The full runtime imports existing components and supplies temporary context. The original system prompt is restored after each answer.
