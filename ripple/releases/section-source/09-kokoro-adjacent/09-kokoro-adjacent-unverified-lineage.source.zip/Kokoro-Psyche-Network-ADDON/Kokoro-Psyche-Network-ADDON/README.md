# Kokoro Psyche Network

A bounded **epistemic information-metabolism add-on** for the existing Kokoro del AI project.

It is not another AI. It sits between internet information and the existing internal systems:

```text
Internet / documents / scholarly APIs
                  ↓
          Psyche Network
         ↙               ↘
Psyche Daughterboard   Heartspace
         \               /
             Kokoro
```

## What it does

- retrieves user-directed sources;
- stores provenance and content hashes;
- segments documents into conservative claims;
- distinguishes objective candidates, subjective reports, normative values, interpretations, and speculation;
- compares support, duplication, context, and contradiction;
- estimates confidence without calling it absolute truth;
- measures cognitive load and available comprehension capacity;
- matures information through explicit stages;
- preserves unresolved branches;
- calculates bounded expression energy;
- gives separate signals to Psyche and Heartspace;
- gives Kokoro compact, traceable source context.

## Built-in connectors

- direct HTTP/HTTPS URL
- RSS/Atom
- OpenAlex
- Crossref
- arXiv
- optional Brave Web Search API

Automatic internet use begins disabled. This prevents silent browsing and protects CPU, privacy, and attention.

## No identity absorption

Retrieved material is non-parametric epistemic memory. It never becomes Kokoro’s identity merely because it was encountered. Every claim retains its source and maturity level.

Read `START_HERE.txt`.
