from __future__ import annotations
from pathlib import Path
from urllib.parse import urlencode, quote_plus
from urllib.request import Request, urlopen
from xml.etree import ElementTree as ET
import json
import os
import time

from .models import SourceDocument
from .security import SafeFetcher, USER_AGENT
from .util import stable_id, hash_text

def _document(
    provider: str, title: str, url: str, publisher: str, text: str,
    source_type: str, primary_status: str, published_at: str | None = None,
    extraction_quality: float = 0.5, metadata: dict | None = None
) -> SourceDocument:
    clean = " ".join((text or "").split())
    snippet = clean[:2400]
    source_id = stable_id("src", provider, url or title, hash_text(clean)[:16])
    return SourceDocument(
        source_id=source_id, provider=provider, title=title.strip() or url,
        url=url, publisher=publisher.strip(), published_at=published_at,
        retrieved_at=time.time(), source_type=source_type,
        primary_status=primary_status, text=clean, snippet=snippet,
        content_hash=hash_text(clean), extraction_quality=extraction_quality,
        metadata=metadata or {}
    )

class DirectURLConnector:
    name = "direct_url"
    def __init__(self, fetcher: SafeFetcher):
        self.fetcher = fetcher

    def fetch(self, url: str) -> list[SourceDocument]:
        result = self.fetcher.fetch(url)
        title = result.title or result.final_url
        text = result.text
        if result.content_type in {"application/json"}:
            try:
                payload = json.loads(result.data)
                text = json.dumps(payload, ensure_ascii=False, indent=2)
            except Exception:
                text = result.data.decode("utf-8", errors="replace")
        if not text:
            text = result.data.decode("utf-8", errors="replace")
        return [_document(
            self.name, title, result.final_url, "",
            text, "unknown", "direct_page", extraction_quality=0.72,
            metadata={"content_type": result.content_type}
        )]

class RSSAtomConnector:
    name = "rss_atom"
    def __init__(self, fetcher: SafeFetcher):
        self.fetcher = fetcher

    def fetch(self, url: str, limit: int = 10) -> list[SourceDocument]:
        result = self.fetcher.fetch(url, accept="application/atom+xml,application/rss+xml,text/xml,application/xml")
        root = ET.fromstring(result.data)
        items = []
        entries = root.findall(".//item")
        atom = "{http://www.w3.org/2005/Atom}"
        if not entries:
            entries = root.findall(f".//{atom}entry")
        for entry in entries[:limit]:
            def find_text(*names):
                for name in names:
                    node = entry.find(name)
                    if node is not None and node.text:
                        return " ".join(node.text.split())
                return ""
            title = find_text("title", f"{atom}title")
            summary = find_text("description", "summary", f"{atom}summary", f"{atom}content")
            published = find_text("pubDate", f"{atom}published", f"{atom}updated") or None
            link = find_text("link")
            if not link:
                node = entry.find(f"{atom}link")
                if node is not None:
                    link = node.attrib.get("href","")
            items.append(_document(
                self.name, title, link or url, "",
                summary, "professional_journalism", "feed_entry",
                published_at=published, extraction_quality=0.58
            ))
        return items

class BraveSearchConnector:
    name = "brave"
    endpoint = "https://api.search.brave.com/res/v1/web/search"
    def __init__(self, api_key: str | None = None):
        self.api_key = api_key or os.environ.get("KOKORO_BRAVE_API_KEY","")

    @property
    def available(self) -> bool:
        return bool(self.api_key)

    def search(self, query: str, limit: int = 8) -> list[SourceDocument]:
        if not self.available:
            return []
        params = urlencode({"q": query[:400], "count": max(1,min(20,limit)), "search_lang":"en", "safesearch":"moderate"})
        req = Request(
            self.endpoint + "?" + params,
            headers={"Accept":"application/json","X-Subscription-Token":self.api_key,"User-Agent":USER_AGENT}
        )
        with urlopen(req, timeout=15) as response:
            payload = json.load(response)
        results = payload.get("web",{}).get("results",[])
        docs = []
        for item in results[:limit]:
            docs.append(_document(
                self.name, item.get("title",""), item.get("url",""),
                item.get("profile",{}).get("long_name","") if isinstance(item.get("profile"),dict) else "",
                item.get("description",""), "unknown", "search_snippet",
                published_at=item.get("age"), extraction_quality=0.42,
                metadata={"language": item.get("language"), "family_friendly": item.get("family_friendly")}
            ))
        return docs

class OpenAlexConnector:
    name = "openalex"
    endpoint = "https://api.openalex.org/works"
    def __init__(self, mailto: str | None = None):
        self.mailto = mailto or os.environ.get("KOKORO_OPENALEX_MAILTO","")

    def search(self, query: str, limit: int = 6) -> list[SourceDocument]:
        params = {"search": query, "per-page": max(1,min(20,limit))}
        if self.mailto:
            params["mailto"] = self.mailto
        req = Request(self.endpoint + "?" + urlencode(params), headers={"User-Agent":USER_AGENT,"Accept":"application/json"})
        with urlopen(req, timeout=15) as response:
            payload = json.load(response)
        docs = []
        for item in payload.get("results",[])[:limit]:
            title = item.get("title") or item.get("display_name") or ""
            abstract_index = item.get("abstract_inverted_index") or {}
            ordered = []
            for word, positions in abstract_index.items():
                for pos in positions:
                    ordered.append((int(pos), word))
            abstract = " ".join(word for _,word in sorted(ordered))
            host = item.get("primary_location",{}).get("source") or {}
            source_name = host.get("display_name","")
            doi = item.get("doi") or item.get("id") or ""
            source_type = "peer_reviewed_primary" if item.get("type") in {"article","review"} and item.get("primary_location",{}).get("is_published") else "scholarly_metadata"
            primary = "primary_research" if item.get("type") == "article" else "scholarly_record"
            docs.append(_document(
                self.name, title, doi, source_name, abstract or title,
                source_type, primary, published_at=item.get("publication_date"),
                extraction_quality=0.80 if abstract else 0.48,
                metadata={
                    "openalex_id": item.get("id"),
                    "doi": item.get("doi"),
                    "cited_by_count": item.get("cited_by_count",0),
                    "type": item.get("type"),
                    "is_retracted": item.get("is_retracted",False),
                    "open_access": item.get("open_access",{})
                }
            ))
        return docs

class CrossrefConnector:
    name = "crossref"
    endpoint = "https://api.crossref.org/works"
    def __init__(self, mailto: str | None = None):
        self.mailto = mailto or os.environ.get("KOKORO_CROSSREF_MAILTO","")

    def search(self, query: str, limit: int = 6) -> list[SourceDocument]:
        params = {"query": query, "rows": max(1,min(20,limit))}
        if self.mailto:
            params["mailto"] = self.mailto
        req = Request(self.endpoint + "?" + urlencode(params), headers={"User-Agent":USER_AGENT,"Accept":"application/json"})
        with urlopen(req, timeout=15) as response:
            payload = json.load(response)
        docs = []
        for item in payload.get("message",{}).get("items",[])[:limit]:
            title = " ".join(item.get("title") or [])
            abstract = item.get("abstract") or ""
            publisher = item.get("publisher") or ""
            doi = item.get("URL") or (f"https://doi.org/{item.get('DOI')}" if item.get("DOI") else "")
            date_parts = ((item.get("published-print") or item.get("published-online") or item.get("issued") or {}).get("date-parts") or [[]])[0]
            published = "-".join(str(x) for x in date_parts) if date_parts else None
            subtype = item.get("subtype") or item.get("type") or ""
            docs.append(_document(
                self.name, title, doi, publisher, abstract or title,
                "scholarly_metadata", "bibliographic_record",
                published_at=published, extraction_quality=0.72 if abstract else 0.45,
                metadata={
                    "doi": item.get("DOI"), "type": subtype,
                    "reference_count": item.get("reference-count",0),
                    "is_referenced_by_count": item.get("is-referenced-by-count",0),
                    "update_to": item.get("update-to",[]),
                    "relation": item.get("relation",{})
                }
            ))
        return docs

class ArxivConnector:
    name = "arxiv"
    endpoint = "https://export.arxiv.org/api/query"
    atom = "{http://www.w3.org/2005/Atom}"

    def search(self, query: str, limit: int = 6) -> list[SourceDocument]:
        params = urlencode({"search_query":"all:" + query, "start":0, "max_results":max(1,min(10,limit))})
        req = Request(self.endpoint + "?" + params, headers={"User-Agent":USER_AGENT,"Accept":"application/atom+xml"})
        with urlopen(req, timeout=20) as response:
            data = response.read()
        root = ET.fromstring(data)
        docs = []
        for entry in root.findall(f"{self.atom}entry")[:limit]:
            def text(name):
                node = entry.find(f"{self.atom}{name}")
                return " ".join((node.text or "").split()) if node is not None else ""
            title, summary, published, ident = text("title"), text("summary"), text("published"), text("id")
            authors = [text_node.text.strip() for text_node in entry.findall(f"{self.atom}author/{self.atom}name") if text_node.text]
            docs.append(_document(
                self.name, title, ident, "arXiv", summary,
                "preprint_primary", "preprint", published_at=published,
                extraction_quality=0.86,
                metadata={"authors": authors, "acknowledgement":"Thank you to arXiv for use of its open access interoperability."}
            ))
        return docs

class ConnectorRegistry:
    def __init__(self, config: dict):
        self.config = config
        self.fetcher = SafeFetcher(
            maximum_bytes=int(config.get("maximum_fetch_bytes",2_000_000)),
            timeout=int(config.get("fetch_timeout_seconds",15)),
            respect_robots=bool(config.get("respect_robots_txt",True)),
            minimum_interval=float(config.get("minimum_request_interval_seconds",1.0))
        )
        self.direct = DirectURLConnector(self.fetcher)
        self.rss = RSSAtomConnector(self.fetcher)
        self.brave = BraveSearchConnector()
        self.openalex = OpenAlexConnector()
        self.crossref = CrossrefConnector()
        self.arxiv = ArxivConnector()

    def web_search(self, query: str, limit: int) -> list[SourceDocument]:
        return self.brave.search(query, limit) if self.brave.available else []

    def scholarly_search(self, query: str, limit: int) -> list[SourceDocument]:
        docs = []
        each = max(1, limit // 3)
        for connector in (self.openalex, self.crossref, self.arxiv):
            try:
                docs.extend(connector.search(query, each))
            except Exception:
                continue
        return docs[:limit]
