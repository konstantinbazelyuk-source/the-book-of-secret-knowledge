from __future__ import annotations
from dataclasses import dataclass
from html.parser import HTMLParser
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin, urlparse
from urllib.request import (
    Request, build_opener, HTTPRedirectHandler, HTTPHandler, HTTPSHandler
)
from urllib.robotparser import RobotFileParser
import ipaddress
import socket
import time

USER_AGENT = "KokoroPsycheNetwork/1.0 (local research assistant; user-directed)"

class UnsafeURL(ValueError):
    pass

def validate_public_url(url: str) -> str:
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"}:
        raise UnsafeURL("Only http and https URLs are allowed.")
    if not parsed.hostname:
        raise UnsafeURL("URL has no hostname.")
    host = parsed.hostname.strip().lower()
    if host in {"localhost"} or host.endswith(".local"):
        raise UnsafeURL("Local/private hosts are blocked.")
    try:
        addresses = {item[4][0] for item in socket.getaddrinfo(host, parsed.port or (443 if parsed.scheme=="https" else 80))}
    except socket.gaierror as exc:
        raise UnsafeURL(f"Host could not be resolved: {host}") from exc
    for value in addresses:
        ip = ipaddress.ip_address(value)
        if (
            ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved
            or ip.is_multicast or ip.is_unspecified
        ):
            raise UnsafeURL(f"Private or reserved address blocked: {ip}")
    return url

class SafeRedirectHandler(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        validate_public_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)

class TextExtractor(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.skip = 0
        self.parts: list[str] = []
        self.title_parts: list[str] = []
        self.in_title = False

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        if tag in {"script","style","noscript","svg","canvas","template"}:
            self.skip += 1
        if tag == "title":
            self.in_title = True
        if tag in {"p","div","section","article","li","h1","h2","h3","h4","br"} and not self.skip:
            self.parts.append("\n")

    def handle_endtag(self, tag):
        tag = tag.lower()
        if tag in {"script","style","noscript","svg","canvas","template"} and self.skip:
            self.skip -= 1
        if tag == "title":
            self.in_title = False

    def handle_data(self, data):
        if self.skip:
            return
        clean = " ".join(data.split())
        if clean:
            self.parts.append(clean + " ")
            if self.in_title:
                self.title_parts.append(clean)

    def result(self) -> tuple[str, str]:
        text = "\n".join(
            line.strip() for line in "".join(self.parts).splitlines() if line.strip()
        )
        return " ".join(self.title_parts).strip(), text

@dataclass
class FetchResult:
    final_url: str
    content_type: str
    data: bytes
    title: str = ""
    text: str = ""

class SafeFetcher:
    def __init__(
        self,
        maximum_bytes: int = 2_000_000,
        timeout: int = 15,
        respect_robots: bool = True,
        minimum_interval: float = 1.0,
    ):
        self.maximum_bytes = maximum_bytes
        self.timeout = timeout
        self.respect_robots = respect_robots
        self.minimum_interval = minimum_interval
        self.last_fetch: dict[str, float] = {}
        self.opener = build_opener(SafeRedirectHandler(), HTTPHandler(), HTTPSHandler())

    def _wait(self, host: str) -> None:
        elapsed = time.time() - self.last_fetch.get(host, 0.0)
        if elapsed < self.minimum_interval:
            time.sleep(self.minimum_interval - elapsed)
        self.last_fetch[host] = time.time()

    def _robots_allowed(self, url: str) -> bool:
        if not self.respect_robots:
            return True
        parsed = urlparse(url)
        robots = f"{parsed.scheme}://{parsed.netloc}/robots.txt"
        parser = RobotFileParser()
        parser.set_url(robots)
        try:
            parser.read()
            return parser.can_fetch(USER_AGENT, url)
        except Exception:
            # RFC 9309 distinguishes unavailable and unreachable robots files.
            # For this local user-directed client, failure is treated conservatively
            # only for automated crawling; a single explicitly requested page remains allowed.
            return True

    def fetch(self, url: str, accept: str = "text/html,application/xhtml+xml,application/json,application/atom+xml,application/rss+xml,text/plain") -> FetchResult:
        validate_public_url(url)
        parsed = urlparse(url)
        self._wait(parsed.hostname or "")
        if not self._robots_allowed(url):
            raise PermissionError("robots.txt disallows this user agent for the requested URL.")
        req = Request(url, headers={"User-Agent": USER_AGENT, "Accept": accept})
        try:
            with self.opener.open(req, timeout=self.timeout) as response:
                final_url = response.geturl()
                validate_public_url(final_url)
                content_type = response.headers.get_content_type()
                length = response.headers.get("Content-Length")
                if length and int(length) > self.maximum_bytes:
                    raise ValueError("Response exceeds maximum configured size.")
                data = response.read(self.maximum_bytes + 1)
                if len(data) > self.maximum_bytes:
                    raise ValueError("Response exceeded maximum configured size while reading.")
        except (HTTPError, URLError, TimeoutError, OSError) as exc:
            raise ConnectionError(f"Fetch failed: {exc}") from exc
        title, text = "", ""
        if content_type in {"text/html","application/xhtml+xml"}:
            charset = "utf-8"
            try:
                charset = response.headers.get_content_charset() or "utf-8"
            except Exception:
                pass
            parser = TextExtractor()
            parser.feed(data.decode(charset, errors="replace"))
            title, text = parser.result()
        elif content_type.startswith("text/"):
            text = data.decode("utf-8", errors="replace")
        return FetchResult(final_url=final_url, content_type=content_type, data=data, title=title, text=text)
