from __future__ import annotations
from hashlib import sha256
from urllib.parse import urlparse
import math
import re

WORD_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9'_-]*")
SENTENCE_RE = re.compile(r"(?<=[.!?])\s+(?=[A-Z0-9\"'])")
NUMBER_RE = re.compile(r"(?<!\w)[+-]?(?:\d+(?:,\d{3})*(?:\.\d+)?|\.\d+)(?:%|[A-Za-z]+)?")
CAPITALIZED_RE = re.compile(r"\b(?:[A-Z][a-z]+(?:\s+[A-Z][a-z]+){0,3}|[A-Z]{2,})\b")
STOP = {
    "the","a","an","and","or","but","to","of","in","on","at","for","from","with",
    "this","that","these","those","it","its","is","are","was","were","be","been",
    "being","do","does","did","have","has","had","can","could","would","should",
    "may","might","will","as","by","about","into","than","then","there","their",
    "we","you","they","he","she","i","our","your","my","not","no"
}
NEGATIONS = {"no","not","never","none","without","cannot","can't","didn't","doesn't","isn't","wasn't","won't"}

def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, float(value)))

def sigmoid(value: float) -> float:
    if value >= 0:
        z = math.exp(-value)
        return 1.0 / (1.0 + z)
    z = math.exp(value)
    return z / (1.0 + z)

def tokens(text: str) -> list[str]:
    return [x.lower() for x in WORD_RE.findall(text)]

def content_tokens(text: str) -> list[str]:
    return [x for x in tokens(text) if x not in STOP and len(x) > 2]

def normalized(text: str) -> str:
    return " ".join(tokens(text))

def stable_id(prefix: str, *parts: str, length: int = 14) -> str:
    raw = "|".join(parts)
    return f"{prefix}-" + sha256(raw.encode("utf-8")).hexdigest()[:length]

def cosine_set(a: str, b: str) -> float:
    aa, bb = set(content_tokens(a)), set(content_tokens(b))
    if not aa or not bb:
        return 0.0
    return len(aa & bb) / math.sqrt(len(aa) * len(bb))

def source_family(url: str, publisher: str = "") -> str:
    host = (urlparse(url).hostname or "").lower()
    bits = [x for x in host.split(".") if x]
    domain = ".".join(bits[-2:]) if len(bits) >= 2 else host
    return (publisher.strip().lower() or domain or "unknown")[:120]

def hash_text(text: str) -> str:
    return sha256(text.encode("utf-8", errors="ignore")).hexdigest()

def extract_entities(text: str) -> list[str]:
    seen = []
    for item in CAPITALIZED_RE.findall(text):
        item = item.strip()
        if item.lower() not in STOP and item not in seen:
            seen.append(item)
    return seen[:12]

def extract_numbers(text: str) -> list[str]:
    return NUMBER_RE.findall(text)[:12]

def has_negation(text: str) -> bool:
    return any(x in NEGATIONS for x in tokens(text))
