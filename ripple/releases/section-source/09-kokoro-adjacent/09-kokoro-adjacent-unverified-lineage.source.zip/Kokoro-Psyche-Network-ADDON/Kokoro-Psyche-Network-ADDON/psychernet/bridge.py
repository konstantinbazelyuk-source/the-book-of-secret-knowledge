from __future__ import annotations
from typing import Any
from .models import EpistemicPacket
from .util import clamp

class BoardSignalBridge:
    """
    Translates one network packet into bounded inputs for the existing separate
    Psyche and Heartspace boards. No source code is modified.
    """
    def psyche_input(self, user_text: str, packet: EpistemicPacket) -> str:
        s=packet.psyche_signal
        return (
            user_text
            + "\n\n[NETWORK SIGNAL FOR PSYCHE — not user identity]\n"
            + f"Epistemic boundary={s['epistemic_boundary_strength']}; "
              f"alternative-frame need={s['alternative_frame_need']}; "
              f"broadcast budget={s['broadcast_budget']}; "
              f"recommended frames={s['recommended_frame_count']}.\n"
            + s["instruction"]
        )

    def psyche_memory(self, packet: EpistemicPacket) -> dict[str,str]:
        return {
            "user_text":"Psyche Network epistemic packet",
            "assistant_text":(
                f"confidence={packet.evidence_confidence:.3f}; uncertainty={packet.uncertainty:.3f}; "
                f"conflict={packet.conflict:.3f}; maturity={packet.maturity_stage}; "
                f"assertion={packet.assertion_mode}; open branches="
                + ",".join(x["branch_id"] for x in packet.unresolved_branches[:6])
            )
        }

    def heart_input(self, user_text: str, packet: EpistemicPacket) -> str:
        s=packet.heart_signal
        return (
            user_text
            + "\n\n[NETWORK SIGNAL FOR HEARTSPACE — mathematical value signal]\n"
            + f"reliability={s['signal_reliability']}; meaning significance={s['meaning_significance']}; "
              f"expression energy={s['expression_energy']}; overload risk={s['overload_risk']}.\n"
            + s["instruction"]
        )

    def heart_telemetry(self, packet: EpistemicPacket, physical: dict[str,float] | None = None) -> dict[str,float]:
        result=dict(physical or {})
        result["signal_reliability"]=clamp(packet.heart_signal["signal_reliability"])
        result["response_budget"]=clamp(packet.heart_signal["response_budget"])
        return result

    def summary(self, packet: EpistemicPacket) -> dict[str,Any]:
        return {
            "psyche":packet.psyche_signal,
            "heart":packet.heart_signal,
            "kokoro":{
                "assertion_mode":packet.assertion_mode,
                "recommended_depth":packet.recommended_depth,
                "expression_energy":packet.expression_energy
            }
        }
