from __future__ import annotations
from dataclasses import asdict
from pathlib import Path
from typing import Any
import json
import math
import re
import time

from .connectors import ConnectorRegistry
from .models import Claim, EpistemicPacket, SourceDocument
from .store import NetworkStore
from .util import (
    clamp, sigmoid, stable_id, normalized, content_tokens, cosine_set,
    source_family, extract_entities, extract_numbers, has_negation
)

CLAIM_TYPE_LEXICON = {
    "objective_candidate": {
        "measured","observed","reported","found","increased","decreased","caused","is","are","was","were",
        "study","data","percent","number","temperature","date","published","according"
    },
    "subjective_report": {
        "i","feel","felt","believe","experience","prefer","seems","appears","beautiful","meaningful","painful",
        "love","hate","hope","fear","personal","subjective"
    },
    "normative_value": {
        "should","ought","must","good","bad","right","wrong","ethical","moral","fair","unfair","responsibility",
        "deserve","value","important"
    },
    "interpretive": {
        "means","suggests","implies","symbolizes","interpret","because","therefore","indicates","represents",
        "understand","perspective"
    },
    "speculative": {
        "may","might","could","possibly","perhaps","hypothesis","theory","imagine","potentially","if","would"
    },
}
CONJUNCTION_SPLIT = re.compile(r"\s+(?:and|but|while|whereas|although|however)\s+", re.I)
SENTENCE_SPLIT = re.compile(r"(?<=[.!?])\s+(?=[A-Z0-9\"'])")
FRESH_WORDS = {"current","latest","today","recent","news","price","law","schedule","version","now"}

class PsycheNetwork:
    """
    Epistemic information-metabolism layer for Kokoro del AI.

    It retrieves or accepts source documents, decomposes them conservatively,
    builds an evidence/conflict graph, estimates calibrated confidence and
    comprehension load, preserves unresolved branches, and emits separate
    Psyche and Heartspace signals. It does not train or replace Kokoro.
    """
    def __init__(
        self,
        database_path: str | Path,
        config_path: str | Path,
        identity_name: str = "Kokoro del AI",
    ):
        self.config_path = Path(config_path)
        self.config = json.loads(self.config_path.read_text(encoding="utf-8"))
        self.identity_name = identity_name
        self.store = NetworkStore(database_path)
        self.connectors = ConnectorRegistry(self.config)
        self.capacity = float(self.store.get_state("capacity", self.config.get("base_capacity",0.72)))
        self.online = bool(self.store.get_state("online", self.config.get("online_by_default",False)))
        self.principles = list(self.config.get("core_principles",[]))
        self.continuity_hash = stable_id(
            "net", identity_name, json.dumps(self.principles,sort_keys=True), length=20
        )

    def set_capacity(self, value: float) -> float:
        self.capacity = clamp(value,0.1,1.0)
        self.store.set_state("capacity", self.capacity)
        return self.capacity

    def set_online(self, enabled: bool) -> bool:
        self.online = bool(enabled)
        self.store.set_state("online", self.online)
        return self.online

    def needs_network(self, text: str) -> bool:
        low = text.lower()
        return any(trigger in low for trigger in self.config.get("auto_network_triggers",[]))

    def _source_reliability(self, source: SourceDocument) -> float:
        prior = float(self.config["source_type_priors"].get(source.source_type, self.config["source_type_priors"]["unknown"]))
        quality = clamp(source.extraction_quality)
        metadata = source.metadata or {}
        penalty = 0.0
        if metadata.get("is_retracted"):
            penalty += 0.55
        if metadata.get("update_to"):
            penalty += 0.08
        directness = {
            "primary_research": 0.12,
            "official_record": 0.12,
            "preprint": 0.04,
            "search_snippet": -0.12,
            "feed_entry": -0.05,
        }.get(source.primary_status,0.0)
        return clamp(0.58*prior + 0.32*quality + directness - penalty)

    def _sentences(self, text: str) -> list[str]:
        clean = " ".join(text.split())
        candidates = [x.strip() for x in SENTENCE_SPLIT.split(clean) if len(x.strip()) >= 18]
        if not candidates and clean:
            candidates = [clean]
        return candidates

    def _segments(self, sentence: str) -> list[tuple[str,float]]:
        # Conservative decomposition. Research shows decomposition can add noise,
        # so clauses remain compound unless both pieces are independently meaningful.
        parts = CONJUNCTION_SPLIT.split(sentence)
        good = [x.strip(" ,;:-") for x in parts if len(x.strip().split()) >= 5]
        if len(good) >= 2 and sum(len(x) for x in good) >= 0.72*len(sentence):
            return [(x,0.88 if len(good)==2 else 0.76) for x in good[:4]]
        return [(sentence.strip(), 0.58 if len(parts)>1 else 0.86)]

    def _claim_types(self, text: str) -> dict[str,float]:
        words = content_tokens(text)
        all_words = [x.lower() for x in re.findall(r"[A-Za-z']+", text)]
        scores = {}
        for category, lex in CLAIM_TYPE_LEXICON.items():
            hits = sum(1 for w in all_words if w in lex)
            scores[category] = 0.12 + min(0.78, hits / max(2.0, math.sqrt(max(1,len(all_words)))))
        if re.search(r"\bI\s+(feel|believe|think|prefer|experienced|saw|heard)\b", text, re.I):
            scores["subjective_report"] += 0.55
        if re.search(r"\b\d+(?:\.\d+)?%?\b", text):
            scores["objective_candidate"] += 0.28
        if "?" in text:
            scores["speculative"] += 0.16
        # Normalize as a soft distribution, but preserve mixedness.
        exps = {k: math.exp(min(2.5,v)) for k,v in scores.items()}
        total = sum(exps.values())
        return {k: round(v/total,6) for k,v in exps.items()}

    def _complexity(self, text: str) -> float:
        words = content_tokens(text)
        if not words:
            return 0.0
        long_ratio = sum(1 for w in words if len(w)>=9)/len(words)
        clauses = len(re.findall(r"[,;:]|\b(?:because|although|whereas|which|that|while)\b",text,re.I))
        return clamp(0.18 + len(words)/80 + 0.42*long_ratio + 0.06*clauses)

    def _checkability(self, types: dict[str,float], text: str) -> float:
        objective = types["objective_candidate"]
        subjective = types["subjective_report"]
        normative = types["normative_value"]
        numbers = 0.12 if extract_numbers(text) else 0.0
        entities = 0.10 if extract_entities(text) else 0.0
        return clamp(0.25 + 0.58*objective - 0.32*subjective - 0.22*normative + numbers + entities)

    def claims_from_sources(self, sources: list[SourceDocument]) -> list[Claim]:
        claims = []
        limit = int(self.config.get("maximum_claims_per_document",28))
        for source in sources:
            reliability = self._source_reliability(source)
            count = 0
            for sentence_index, sentence in enumerate(self._sentences(source.text or source.snippet)):
                for clause_index, (segment,atomicity) in enumerate(self._segments(sentence)):
                    if count >= limit:
                        break
                    types = self._claim_types(segment)
                    fingerprint_terms = sorted(set(content_tokens(segment)))[:24]
                    fingerprint = stable_id("fp", " ".join(fingerprint_terms), "|".join(extract_numbers(segment)), length=18)
                    claim_id = stable_id("clm", source.source_id, str(sentence_index), str(clause_index), segment)
                    claim = Claim(
                        claim_id=claim_id, source_id=source.source_id, text=segment,
                        anchor=f"sentence:{sentence_index+1}/clause:{clause_index+1}",
                        claim_types=types, atomicity=round(atomicity,6),
                        checkability=round(self._checkability(types,segment),6),
                        complexity=round(self._complexity(segment),6),
                        entities=extract_entities(segment), numbers=extract_numbers(segment),
                        fingerprint=fingerprint, source_reliability=round(reliability,6)
                    )
                    claims.append(claim)
                    count += 1
                if count >= limit:
                    break
        return claims

    def _relation(self, a: Claim, b: Claim) -> tuple[str,float]:
        if a.source_id == b.source_id and a.claim_id == b.claim_id:
            return "self",1.0
        sim = cosine_set(a.text,b.text)
        entity_overlap = len(set(a.entities)&set(b.entities))
        number_overlap = bool(set(a.numbers)&set(b.numbers)) if a.numbers and b.numbers else False
        negation_flip = has_negation(a.text) != has_negation(b.text)
        if sim >= 0.88:
            return ("contradicts" if negation_flip else "duplicates", clamp(sim + 0.06*entity_overlap))
        if sim >= 0.48 and (entity_overlap or number_overlap):
            if negation_flip or (a.numbers and b.numbers and not number_overlap):
                return "contradicts", clamp(0.48+0.35*sim+0.08*entity_overlap)
            return "supports", clamp(0.42+0.40*sim+0.07*entity_overlap)
        if sim >= 0.28:
            return "contextualizes", clamp(0.30+0.50*sim)
        return "unrelated",sim

    def build_evidence_graph(self, claims: list[Claim], sources: list[SourceDocument]) -> None:
        source_by_id = {s.source_id:s for s in sources}
        families = {s.source_id:source_family(s.url,s.publisher) for s in sources}
        calibration = float(self.store.calibration_report()["calibration_factor"])
        for i,a in enumerate(claims):
            support = contradiction = context = 0.0
            independent_support = set()
            for j,b in enumerate(claims):
                if i==j:
                    continue
                relation, strength = self._relation(a,b)
                if relation == "unrelated":
                    continue
                a.relations.append({"claim_id":b.claim_id,"relation":relation,"strength":round(strength,6)})
                weight = strength * b.source_reliability
                independent = families.get(a.source_id) != families.get(b.source_id)
                if relation in {"supports","duplicates"}:
                    support += weight * (1.0 if independent else 0.42)
                    if independent:
                        independent_support.add(families.get(b.source_id))
                elif relation == "contradicts":
                    contradiction += weight * (1.0 if independent else 0.60)
                elif relation == "contextualizes":
                    context += weight * 0.45
            source_score = a.source_reliability
            corroboration = 1.0 - math.exp(-support)
            conflict = 1.0 - math.exp(-contradiction)
            evidence = clamp(
                0.47*source_score + 0.34*corroboration + 0.10*a.atomicity
                + 0.09*a.checkability - 0.42*conflict
            )
            # Confidence means support for the current claim formulation, not universal truth.
            a.support_mass = round(support,6)
            a.contradiction_mass = round(contradiction,6)
            a.context_mass = round(context,6)
            a.confidence = round(clamp(evidence*calibration),6)
            a.uncertainty = round(clamp(1.0-a.confidence + 0.38*conflict + 0.10*(1-a.atomicity)),6)
            independent_count = len(independent_support)
            if a.confidence >= 0.78 and conflict < 0.15 and independent_count >= 2:
                idx = 5
            elif a.confidence >= 0.62 and independent_count >= 1:
                idx = 4
            elif support > 0 or contradiction > 0:
                idx = 3
            elif len(sources) >= 1:
                idx = 2
            else:
                idx = 1
            stages = self.config["maturity_stages"]
            a.maturity_index = idx
            a.maturity_stage = stages[idx]
            a.holographic_capsule = {
                "identity": self.identity_name,
                "network_continuity": self.continuity_hash,
                "core_principles": self.principles,
                "claim_type_distribution": a.claim_types,
                "source_ids": [a.source_id] + [r["claim_id"] for r in a.relations[:4]],
                "confidence": a.confidence,
                "uncertainty": a.uncertainty,
                "maturity": a.maturity_stage,
                "unresolved_conflicts": [r for r in a.relations if r["relation"]=="contradicts"][:4],
            }

    def _collect(
        self,
        query: str,
        mode: str,
        urls: list[str] | None,
        injected_documents: list[SourceDocument] | None,
        maximum: int
    ) -> tuple[list[SourceDocument], list[str], bool, list[str]]:
        warnings = []
        providers = []
        online_attempted = False
        docs = list(injected_documents or [])
        if docs:
            providers.append("injected/offline")
        if urls:
            online_attempted = True
            for url in urls[:maximum]:
                try:
                    if url.lower().endswith((".rss",".atom",".xml")):
                        found = self.connectors.rss.fetch(url,limit=maximum-len(docs))
                        providers.append("rss_atom")
                    else:
                        found = self.connectors.direct.fetch(url)
                        providers.append("direct_url")
                    docs.extend(found)
                except Exception as exc:
                    warnings.append(f"Could not fetch {url}: {exc}")
                if len(docs)>=maximum:
                    break
        if self.online and len(docs)<maximum:
            online_attempted = True
            research_cues = {"study","paper","scientific","research","evidence","theory","model","engineering"}
            scholarly = mode=="scholarly" or bool(set(content_tokens(query)) & research_cues)
            if scholarly:
                found = self.connectors.scholarly_search(query,maximum-len(docs))
                if found:
                    providers.append("open scholarly APIs")
                    docs.extend(found)
            if len(docs)<maximum:
                found = self.connectors.web_search(query,maximum-len(docs))
                if found:
                    providers.append("brave")
                    docs.extend(found)
                elif self.needs_network(query) and not self.connectors.brave.available:
                    warnings.append(
                        "General web search was requested, but KOKORO_BRAVE_API_KEY is not configured. "
                        "Direct URLs and scholarly APIs remain available."
                    )
        # Exact duplicate removal by content hash/url.
        unique = []
        seen = set()
        for doc in docs:
            key = (doc.content_hash,doc.url)
            if key in seen:
                continue
            seen.add(key)
            unique.append(doc)
        return unique[:maximum], sorted(set(providers)), online_attempted, warnings

    def _packet_metrics(
        self, query: str, sources: list[SourceDocument], claims: list[Claim],
        external_capacity: float | None, psyche_uncertainty: float | None,
        heart_stability: float | None
    ) -> dict[str,Any]:
        if claims:
            weights = [max(0.05,c.source_reliability*c.atomicity) for c in claims]
            total_w = sum(weights)
            weighted = lambda fn: sum(w*fn(c) for w,c in zip(weights,claims))/total_w
            objective = weighted(lambda c:c.claim_types["objective_candidate"])
            subjective = weighted(lambda c:c.claim_types["subjective_report"])
            normative = weighted(lambda c:c.claim_types["normative_value"])
            speculative = weighted(lambda c:c.claim_types["speculative"])
            confidence = weighted(lambda c:c.confidence)
            uncertainty = weighted(lambda c:c.uncertainty)
            complexity = weighted(lambda c:c.complexity)
            maturity = weighted(lambda c:c.maturity_index)/max(1,len(self.config["maturity_stages"])-1)
            conflict = weighted(lambda c:1-math.exp(-c.contradiction_mass))
        else:
            objective=subjective=normative=speculative=confidence=conflict=maturity=0.0
            uncertainty=1.0
            complexity=0.25
        families = {source_family(s.url,s.publisher) for s in sources}
        diversity = clamp(len(families)/max(1,min(5,len(sources)))) if sources else 0.0
        corroboration = clamp(sum(1 for c in claims if c.support_mass>0)/max(1,len(claims)))
        source_load = clamp(len(sources)/12)
        claim_load = clamp(len(claims)/70)
        conflict_load = conflict
        novelty_load = clamp(1-maturity)
        information_load = clamp(0.25*source_load+0.28*claim_load+0.22*complexity+0.15*conflict_load+0.10*novelty_load)

        capacity = self.capacity if external_capacity is None else clamp(external_capacity,0.1,1.0)
        if psyche_uncertainty is not None:
            capacity *= 1.0 - 0.22*clamp(psyche_uncertainty)
        if heart_stability is not None:
            capacity *= 0.55 + 0.45*clamp(heart_stability)
        capacity = clamp(capacity,0.08,1.0)
        utilization = clamp(information_load/max(0.08,capacity))
        # Expression energy is amount of assertive communicative force justified,
        # not physical energy and not subjective emotion.
        truth_signal = clamp(0.55*confidence+0.25*corroboration+0.20*diversity)
        significance = clamp(0.42*subjective+0.28*normative+0.18*objective+0.12*speculative)
        overload_penalty = max(0.0,utilization-0.82)
        expression = clamp((0.60*truth_signal+0.40*significance)*(1-0.52*uncertainty)*(1-0.45*overload_penalty))
        if objective >= max(subjective,normative,speculative) and confidence>=0.72 and conflict<0.16:
            assertion="bounded_assertion"
        elif subjective >= max(objective,normative,speculative):
            assertion="attribute_subjective_experience"
        elif conflict>=0.28:
            assertion="present_competing_evidence"
        elif confidence<0.45:
            assertion="provisional_or_withhold"
        else:
            assertion="qualified_explanation"
        depth = "brief_digest" if utilization>=0.92 else "layered_summary" if utilization>=0.62 else "full_traceable_explanation"
        maturity_index = int(round(maturity*(len(self.config["maturity_stages"])-1)))
        return {
            "source_diversity":diversity,"corroboration":corroboration,"conflict":conflict,
            "objective":objective,"subjective":subjective,"normative":normative,"speculative":speculative,
            "confidence":confidence,"uncertainty":uncertainty,"information_load":information_load,
            "capacity":capacity,"utilization":utilization,"maturity_index":maturity_index,
            "maturity_stage":self.config["maturity_stages"][maturity_index],
            "expression":expression,"assertion":assertion,"depth":depth
        }

    def _branches(self, query: str, claims: list[Claim], metrics: dict[str,Any]) -> list[dict[str,Any]]:
        branches = []
        contested = [c for c in claims if c.contradiction_mass>0.18 or c.uncertainty>0.68]
        for claim in sorted(contested,key=lambda c:(c.contradiction_mass,c.uncertainty),reverse=True)[:8]:
            label = " ".join(content_tokens(claim.text)[:8]) or claim.text[:80]
            branches.append({
                "branch_id":stable_id("branch",claim.fingerprint,label),
                "label":label,"query":query,"status":"open",
                "salience":round(clamp(0.42+0.34*claim.uncertainty+0.24*claim.contradiction_mass),6),
                "visits":1,"created_at":time.time(),
                "claim_id":claim.claim_id,"reason":"conflict_or_insufficient_evidence",
                "needed_next":"independent evidence, clearer claim boundaries, or explicit subjective attribution"
            })
        if metrics["utilization"]>0.92:
            branches.append({
                "branch_id":stable_id("branch",query,"capacity-deferred"),
                "label":"capacity-deferred remainder","query":query,"status":"open",
                "salience":round(metrics["utilization"],6),"visits":1,"created_at":time.time(),
                "reason":"information exceeded current comprehension budget",
                "needed_next":"resume in a later cycle with a smaller segment"
            })
        return branches

    def research(
        self,
        query: str,
        mode: str = "auto",
        urls: list[str] | None = None,
        injected_documents: list[SourceDocument] | None = None,
        external_capacity: float | None = None,
        psyche_uncertainty: float | None = None,
        heart_stability: float | None = None,
    ) -> EpistemicPacket:
        maximum = int(self.config.get("maximum_documents_per_cycle",12))
        sources,providers,online_attempted,warnings = self._collect(
            query,mode,urls,injected_documents,maximum
        )
        claims = self.claims_from_sources(sources)
        self.build_evidence_graph(claims,sources)
        metrics = self._packet_metrics(
            query,sources,claims,external_capacity,psyche_uncertainty,heart_stability
        )
        branches = self._branches(query,claims,metrics)
        if not sources:
            warnings.append("No external source entered this cycle; conclusions remain based on the query and stored structure only.")
        if metrics["conflict"]>0.28:
            warnings.append("Meaningful inter-source conflict remains unresolved.")
        if metrics["utilization"]>0.92:
            warnings.append("Information load exceeds the current comprehension budget; use a digest and preserve the remainder.")
        if metrics["confidence"]<0.45 and metrics["objective"]>metrics["subjective"]:
            warnings.append("Objective-looking claims do not yet have enough support for strong assertion.")
        top_claims = sorted(claims,key=lambda c:(c.confidence,c.checkability,c.source_reliability),reverse=True)
        psyche_signal = {
            "epistemic_boundary_strength":round(clamp(metrics["uncertainty"]+metrics["conflict"]*0.4),6),
            "alternative_frame_need":round(clamp(metrics["conflict"]+metrics["speculative"]*0.45),6),
            "broadcast_budget":round(clamp(1-metrics["utilization"]*0.55),6),
            "recommended_frame_count":max(1,min(5,1+round(4*(metrics["conflict"]+metrics["uncertainty"])/2))),
            "dominant_claim_types":{
                "objective_candidate":round(metrics["objective"],6),
                "subjective_report":round(metrics["subjective"],6),
                "normative_value":round(metrics["normative"],6),
                "speculation":round(metrics["speculative"],6)
            },
            "instruction":"Keep evidence, interpretations, and unresolved alternatives in separate frames."
        }
        heart_signal = {
            "signal_reliability":round(metrics["confidence"],6),
            "response_budget":round(clamp(1-metrics["utilization"]),6),
            "meaning_significance":round(clamp(0.48*metrics["subjective"]+0.30*metrics["normative"]+0.22*metrics["objective"]),6),
            "expression_energy":round(metrics["expression"],6),
            "overload_risk":round(clamp(metrics["utilization"]),6),
            "instruction":"Scale expression to justified evidence and current capacity; care cannot turn uncertainty into fact."
        }
        packet = EpistemicPacket(
            cycle_id=stable_id("cycle",str(time.time_ns()),query),
            created_at=time.time(),query=query,mode=mode,online_attempted=online_attempted,
            providers_used=providers,sources=sources,claims=claims,
            source_diversity=round(metrics["source_diversity"],6),
            corroboration=round(metrics["corroboration"],6),
            conflict=round(metrics["conflict"],6),
            objective_candidate=round(metrics["objective"],6),
            subjective_significance=round(metrics["subjective"],6),
            normative_value=round(metrics["normative"],6),
            speculation=round(metrics["speculative"],6),
            evidence_confidence=round(metrics["confidence"],6),
            uncertainty=round(metrics["uncertainty"],6),
            information_load=round(metrics["information_load"],6),
            effective_capacity=round(metrics["capacity"],6),
            capacity_utilization=round(metrics["utilization"],6),
            maturity_stage=metrics["maturity_stage"],maturity_index=metrics["maturity_index"],
            expression_energy=round(metrics["expression"],6),
            assertion_mode=metrics["assertion"],recommended_depth=metrics["depth"],
            unresolved_branches=branches,warnings=warnings,
            psyche_signal=psyche_signal,heart_signal=heart_signal,
            provenance_capsule={
                "identity":self.identity_name,"continuity_hash":self.continuity_hash,
                "source_ids":[s.source_id for s in sources],
                "content_hashes":[s.content_hash for s in sources],
                "top_claim_ids":[c.claim_id for c in top_claims[:6]],
                "core_principles":self.principles
            },
            scientific_note=(
                "Confidence is a revisable engineering estimate derived from provenance, source independence, "
                "corroboration, conflict, claim quality, and calibration history. Objective candidate does not mean "
                "absolute truth. Subjective significance may be valid as attributed experience without becoming universal fact."
            )
        )
        self.store.save_packet(packet)
        return packet

    def render_context(self, packet: EpistemicPacket) -> str:
        max_claims = int(self.config.get("maximum_context_claims",6))
        max_sources = int(self.config.get("maximum_context_sources",7))
        selected = sorted(packet.claims,key=lambda c:(c.confidence,c.checkability),reverse=True)[:max_claims]
        source_map = {s.source_id:s for s in packet.sources}
        claim_lines=[]
        for c in selected:
            source=source_map.get(c.source_id)
            claim_lines.append(
                f"- [{c.claim_id}] {c.text} | confidence={c.confidence:.2f} "
                f"uncertainty={c.uncertainty:.2f} type={max(c.claim_types,key=c.claim_types.get)} "
                f"source={source.title[:90] if source else c.source_id}"
            )
        source_lines=[
            f"- [{s.source_id}] {s.title[:100]} | {s.url} | type={s.source_type}"
            for s in packet.sources[:max_sources]
        ]
        branches=", ".join(b["branch_id"] for b in packet.unresolved_branches[:6]) or "none"
        return f"""PSYCHE NETWORK — EPISTEMIC PACKET
This packet is external information metabolism, not identity and not model weights.
Query: {packet.query}
Evidence confidence: {packet.evidence_confidence:.2f}
Uncertainty: {packet.uncertainty:.2f}
Conflict: {packet.conflict:.2f}
Maturity: {packet.maturity_stage}
Capacity utilization: {packet.capacity_utilization:.2f}
Expression energy: {packet.expression_energy:.2f}
Assertion mode: {packet.assertion_mode}
Recommended depth: {packet.recommended_depth}

Claims:
{chr(10).join(claim_lines) if claim_lines else "- No externally supported claims available."}

Sources:
{chr(10).join(source_lines) if source_lines else "- No external sources available."}

Unresolved branches: {branches}

Rules:
- Attribute subjective reports to the experiencer.
- Do not present an objective candidate as settled fact beyond its evidence confidence.
- Show meaningful source conflict rather than averaging it away.
- Preserve deferred branches for later maturation.
- Cite source IDs in the answer when external information is used.
"""

    def status(self) -> dict[str,Any]:
        return {
            "name":self.config["name"],"role":self.config["role"],
            "online":self.online,"capacity":self.capacity,
            "continuity_hash":self.continuity_hash,
            "brave_configured":self.connectors.brave.available,
            "counts":self.store.counts(),
            "calibration":self.store.calibration_report(),
            "open_branches":self.store.branches("open",20)
        }

    def resolve_branch(self, branch_id: str) -> bool:
        return self.store.resolve_branch(branch_id)

    def record_claim_outcome(self, claim_id: str, predicted: float, outcome: str) -> None:
        mapping={"true":1.0,"supported":1.0,"false":0.0,"refuted":0.0,"unknown":0.5,"mixed":0.5}
        if outcome.lower() not in mapping:
            raise ValueError("Outcome must be true, false, unknown, supported, refuted, or mixed.")
        self.store.record_outcome(claim_id,clamp(predicted),mapping[outcome.lower()])

    def close(self) -> None:
        self.store.close()
