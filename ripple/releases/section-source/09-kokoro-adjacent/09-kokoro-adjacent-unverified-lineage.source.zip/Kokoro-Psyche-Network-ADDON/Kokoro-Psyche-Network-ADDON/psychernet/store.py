from __future__ import annotations
from pathlib import Path
from typing import Any
import json
import sqlite3
import time

from .models import EpistemicPacket, SourceDocument, Claim

class NetworkStore:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(self.path, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.executescript("""
        PRAGMA journal_mode=WAL;
        CREATE TABLE IF NOT EXISTS network_state(
            key TEXT PRIMARY KEY,
            value_json TEXT NOT NULL,
            updated_at REAL NOT NULL
        );
        CREATE TABLE IF NOT EXISTS network_cycles(
            cycle_id TEXT PRIMARY KEY,
            created_at REAL NOT NULL,
            query TEXT NOT NULL,
            mode TEXT NOT NULL,
            packet_json TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS network_sources(
            source_id TEXT PRIMARY KEY,
            cycle_id TEXT NOT NULL,
            provider TEXT NOT NULL,
            title TEXT NOT NULL,
            url TEXT NOT NULL,
            publisher TEXT,
            content_hash TEXT NOT NULL,
            source_json TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS network_claims(
            claim_id TEXT PRIMARY KEY,
            cycle_id TEXT NOT NULL,
            source_id TEXT NOT NULL,
            fingerprint TEXT NOT NULL,
            maturity_index INTEGER NOT NULL,
            confidence REAL NOT NULL,
            uncertainty REAL NOT NULL,
            claim_json TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_claim_fingerprint ON network_claims(fingerprint);
        CREATE TABLE IF NOT EXISTS unresolved_branches(
            branch_id TEXT PRIMARY KEY,
            label TEXT NOT NULL,
            query TEXT NOT NULL,
            status TEXT NOT NULL,
            salience REAL NOT NULL,
            visits INTEGER NOT NULL,
            created_at REAL NOT NULL,
            updated_at REAL NOT NULL,
            payload_json TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS calibration_events(
            event_id INTEGER PRIMARY KEY AUTOINCREMENT,
            claim_id TEXT NOT NULL,
            predicted_confidence REAL NOT NULL,
            outcome REAL NOT NULL,
            created_at REAL NOT NULL
        );
        """)
        self.db.commit()

    def get_state(self, key: str, default: Any = None) -> Any:
        row = self.db.execute("SELECT value_json FROM network_state WHERE key=?", (key,)).fetchone()
        return default if row is None else json.loads(row["value_json"])

    def set_state(self, key: str, value: Any) -> None:
        self.db.execute(
            "INSERT INTO network_state(key,value_json,updated_at) VALUES(?,?,?) "
            "ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json,updated_at=excluded.updated_at",
            (key, json.dumps(value, ensure_ascii=False), time.time())
        )
        self.db.commit()

    def save_packet(self, packet: EpistemicPacket) -> None:
        payload = packet.to_dict()
        self.db.execute(
            "INSERT OR REPLACE INTO network_cycles(cycle_id,created_at,query,mode,packet_json) VALUES(?,?,?,?,?)",
            (packet.cycle_id, packet.created_at, packet.query, packet.mode, json.dumps(payload, ensure_ascii=False))
        )
        for source in packet.sources:
            self.db.execute(
                "INSERT OR REPLACE INTO network_sources(source_id,cycle_id,provider,title,url,publisher,content_hash,source_json) VALUES(?,?,?,?,?,?,?,?)",
                (source.source_id, packet.cycle_id, source.provider, source.title, source.url,
                 source.publisher, source.content_hash, json.dumps(source.to_dict(), ensure_ascii=False))
            )
        for claim in packet.claims:
            self.db.execute(
                "INSERT OR REPLACE INTO network_claims(claim_id,cycle_id,source_id,fingerprint,maturity_index,confidence,uncertainty,claim_json) VALUES(?,?,?,?,?,?,?,?)",
                (claim.claim_id, packet.cycle_id, claim.source_id, claim.fingerprint,
                 claim.maturity_index, claim.confidence, claim.uncertainty,
                 json.dumps(claim.to_dict(), ensure_ascii=False))
            )
        for branch in packet.unresolved_branches:
            self.upsert_branch(branch)
        self.db.commit()

    def upsert_branch(self, branch: dict[str, Any]) -> None:
        now = time.time()
        prior = self.db.execute(
            "SELECT visits,created_at FROM unresolved_branches WHERE branch_id=?",
            (branch["branch_id"],)
        ).fetchone()
        visits = int(prior["visits"]) + 1 if prior else int(branch.get("visits", 1))
        created = float(prior["created_at"]) if prior else float(branch.get("created_at", now))
        self.db.execute("""
            INSERT INTO unresolved_branches(branch_id,label,query,status,salience,visits,created_at,updated_at,payload_json)
            VALUES(?,?,?,?,?,?,?,?,?)
            ON CONFLICT(branch_id) DO UPDATE SET
              label=excluded.label,query=excluded.query,status=excluded.status,
              salience=excluded.salience,visits=excluded.visits,updated_at=excluded.updated_at,
              payload_json=excluded.payload_json
        """, (
            branch["branch_id"], branch["label"], branch["query"], branch.get("status","open"),
            float(branch.get("salience",0.5)), visits, created, now,
            json.dumps(branch, ensure_ascii=False)
        ))

    def branches(self, status: str = "open", limit: int = 50) -> list[dict[str, Any]]:
        rows = self.db.execute(
            "SELECT * FROM unresolved_branches WHERE status=? ORDER BY salience DESC,updated_at DESC LIMIT ?",
            (status, limit)
        ).fetchall()
        return [{
            "branch_id": r["branch_id"], "label": r["label"], "query": r["query"],
            "status": r["status"], "salience": r["salience"], "visits": r["visits"],
            "created_at": r["created_at"], "updated_at": r["updated_at"],
        } for r in rows]

    def resolve_branch(self, branch_id: str) -> bool:
        cur = self.db.execute(
            "UPDATE unresolved_branches SET status='resolved',updated_at=? WHERE branch_id=?",
            (time.time(), branch_id)
        )
        self.db.commit()
        return cur.rowcount > 0

    def record_outcome(self, claim_id: str, predicted: float, outcome: float) -> None:
        self.db.execute(
            "INSERT INTO calibration_events(claim_id,predicted_confidence,outcome,created_at) VALUES(?,?,?,?)",
            (claim_id, predicted, outcome, time.time())
        )
        self.db.commit()

    def calibration_report(self) -> dict[str, Any]:
        rows = self.db.execute(
            "SELECT predicted_confidence,outcome FROM calibration_events"
        ).fetchall()
        if not rows:
            return {"events": 0, "brier_score": None, "calibration_factor": 1.0}
        brier = sum((r["predicted_confidence"] - r["outcome"]) ** 2 for r in rows) / len(rows)
        factor = max(0.55, min(1.0, 1.0 - brier))
        return {"events": len(rows), "brier_score": round(brier, 6), "calibration_factor": round(factor, 6)}

    def latest_packet(self) -> dict[str, Any] | None:
        row = self.db.execute(
            "SELECT packet_json FROM network_cycles ORDER BY created_at DESC LIMIT 1"
        ).fetchone()
        return None if row is None else json.loads(row["packet_json"])

    def counts(self) -> dict[str, int]:
        return {
            "cycles": int(self.db.execute("SELECT COUNT(*) FROM network_cycles").fetchone()[0]),
            "sources": int(self.db.execute("SELECT COUNT(*) FROM network_sources").fetchone()[0]),
            "claims": int(self.db.execute("SELECT COUNT(*) FROM network_claims").fetchone()[0]),
            "open_branches": int(self.db.execute("SELECT COUNT(*) FROM unresolved_branches WHERE status='open'").fetchone()[0]),
        }

    def clear(self) -> None:
        self.db.executescript(
            "DELETE FROM network_state;DELETE FROM network_cycles;DELETE FROM network_sources;"
            "DELETE FROM network_claims;DELETE FROM unresolved_branches;DELETE FROM calibration_events;"
        )
        self.db.commit()

    def close(self) -> None:
        self.db.close()
