from __future__ import annotations
from dataclasses import dataclass, asdict, field
from typing import Any

@dataclass
class SourceDocument:
    source_id: str
    provider: str
    title: str
    url: str
    publisher: str
    published_at: str | None
    retrieved_at: float
    source_type: str
    primary_status: str
    text: str
    snippet: str
    language: str = "en"
    content_hash: str = ""
    extraction_quality: float = 0.5
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

@dataclass
class Claim:
    claim_id: str
    source_id: str
    text: str
    anchor: str
    claim_types: dict[str, float]
    atomicity: float
    checkability: float
    complexity: float
    entities: list[str]
    numbers: list[str]
    fingerprint: str
    source_reliability: float
    relations: list[dict[str, Any]] = field(default_factory=list)
    support_mass: float = 0.0
    contradiction_mass: float = 0.0
    context_mass: float = 0.0
    confidence: float = 0.0
    uncertainty: float = 1.0
    maturity_stage: str = "segmented"
    maturity_index: int = 1
    holographic_capsule: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

@dataclass
class EpistemicPacket:
    cycle_id: str
    created_at: float
    query: str
    mode: str
    online_attempted: bool
    providers_used: list[str]
    sources: list[SourceDocument]
    claims: list[Claim]
    source_diversity: float
    corroboration: float
    conflict: float
    objective_candidate: float
    subjective_significance: float
    normative_value: float
    speculation: float
    evidence_confidence: float
    uncertainty: float
    information_load: float
    effective_capacity: float
    capacity_utilization: float
    maturity_stage: str
    maturity_index: int
    expression_energy: float
    assertion_mode: str
    recommended_depth: str
    unresolved_branches: list[dict[str, Any]]
    warnings: list[str]
    psyche_signal: dict[str, Any]
    heart_signal: dict[str, Any]
    provenance_capsule: dict[str, Any]
    scientific_note: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
