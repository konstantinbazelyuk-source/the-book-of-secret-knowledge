#!/usr/bin/env python3
from __future__ import annotations
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse
import json, sys, webbrowser

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from psychernet import PsycheNetwork
NET=PsycheNetwork(ROOT/"state"/"psychernet.sqlite3",ROOT/"psychernet_config.json")
WEB=ROOT/"web"

class Handler(SimpleHTTPRequestHandler):
    def translate_path(self,path):
        return str(WEB/(urlparse(path).path.lstrip("/") or "index.html"))
    def send_json(self,obj,code=200):
        data=json.dumps(obj,ensure_ascii=False).encode()
        self.send_response(code);self.send_header("Content-Type","application/json; charset=utf-8")
        self.send_header("Content-Length",str(len(data)));self.end_headers();self.wfile.write(data)
    def do_GET(self):
        route=urlparse(self.path).path
        if route=="/api/status":return self.send_json(NET.status())
        if route=="/api/latest":return self.send_json(NET.store.latest_packet() or {})
        if route=="/api/branches":return self.send_json(NET.store.branches("open",100))
        return super().do_GET()
    def do_POST(self):
        route=urlparse(self.path).path
        size=int(self.headers.get("Content-Length","0"))
        try:body=json.loads(self.rfile.read(size) or b"{}")
        except Exception:return self.send_json({"error":"invalid json"},400)
        if route=="/api/research":
            NET.set_online(bool(body.get("online",False)))
            packet=NET.research(str(body.get("query","")),urls=body.get("urls") or None)
            return self.send_json(packet.to_dict())
        if route=="/api/settings":
            if "capacity" in body:NET.set_capacity(float(body["capacity"]))
            if "online" in body:NET.set_online(bool(body["online"]))
            return self.send_json(NET.status())
        return self.send_json({"error":"not found"},404)
    def log_message(self,*args):pass

if __name__=="__main__":
    host,port="127.0.0.1",8786
    server=ThreadingHTTPServer((host,port),Handler)
    url=f"http://{host}:{port}"
    print("Psyche Network Observatory:",url);print("Close with Ctrl+C.")
    webbrowser.open(url)
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:NET.close();server.server_close()
