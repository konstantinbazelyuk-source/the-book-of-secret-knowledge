# Architecture

## Ordered cycle

1. Receive a user question, URL, feed, or API search result.
2. Retain provenance, retrieval time, URL, provider, source class, and content hash.
3. Segment text conservatively into claims.
4. Estimate claim type and checkability.
5. Build pairwise support, contradiction, duplicate, and context relations.
6. Weight evidence by source quality and source independence.
7. Estimate confidence and uncertainty.
8. Measure information load.
9. Combine configured capacity with prior Psyche uncertainty and Heartspace stability.
10. Choose maturity stage, assertion mode, depth, and expression energy.
11. Preserve unresolved conflicts and capacity-deferred material as branches.
12. Send an epistemic signal to Psyche.
13. Send reliability, significance, and expression-energy signals to Heartspace.
14. Give Kokoro a compact source-bound packet.
15. Store the cycle in the Network’s separate SQLite database.

## Separation of authority

The Network may recommend how information should be handled. It cannot:

- rewrite Kokoro’s weights;
- modify either daughterboard;
- make physical actions;
- declare subjective meaning to be universal fact;
- silently browse when online mode is disabled.
