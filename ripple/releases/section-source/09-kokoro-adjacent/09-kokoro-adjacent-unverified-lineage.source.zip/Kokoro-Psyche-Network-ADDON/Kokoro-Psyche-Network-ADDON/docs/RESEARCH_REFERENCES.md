# Primary research and official technical references

- Lewis et al. (2020), Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks:
  https://arxiv.org/abs/2005.11401
- Hu, Long, and Wang (2024), Decomposition Dilemmas:
  https://arxiv.org/abs/2411.02400
- Zhang and de Marneffe (2021), Identifying inherent disagreement in natural language inference:
  https://aclanthology.org/2021.naacl-main.390/
- Jiang et al. (2021), Commonsense implications of negation and contradiction:
  https://aclanthology.org/2021.naacl-main.346/
- Lanillos et al. (2021), Active Inference in Robotics and Artificial Agents:
  https://arxiv.org/abs/2112.01871
- Kawaguchi et al. (2023), How Does Information Bottleneck Help Deep Learning?:
  https://arxiv.org/abs/2305.18887
- OpenAlex official API:
  https://developers.openalex.org/api-reference/introduction
- Crossref official REST API:
  https://www.crossref.org/documentation/retrieve-metadata/rest-api/
- arXiv official API manual:
  https://info.arxiv.org/help/api/user-manual.html
- Brave official Web Search API:
  https://api-dashboard.search.brave.com/api-reference/web/search/get
- RFC 9309, Robots Exclusion Protocol:
  https://www.rfc-editor.org/rfc/rfc9309
