# Integration with the existing project

Install location:

`Kokoro-del-Corazon-Foundry\addons\Kokoro-Psyche-Network`

The full runtime dynamically discovers:

- `addons\Kokoro-Psyche-Daughterboard`
- `addons\Kokoro-Heartspace-Daughterboard`

No edits are made to either one.

## Signal sent to Psyche

- epistemic boundary strength
- need for alternative frames
- broadcast budget
- recommended frame count
- objective / subjective / normative / speculative distribution
- unresolved branch identifiers

## Signal sent to Heartspace

- source reliability
- response budget
- meaning significance
- expression energy
- overload risk

The bridge uses existing public methods. It restores Kokoro’s original system prompt after every response.
