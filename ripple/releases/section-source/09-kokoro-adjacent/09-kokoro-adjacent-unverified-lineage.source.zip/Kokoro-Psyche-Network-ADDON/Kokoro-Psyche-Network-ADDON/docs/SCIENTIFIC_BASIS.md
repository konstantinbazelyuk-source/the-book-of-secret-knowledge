# Scientific basis and honest limits

The package translates established research ideas into inspectable local engineering:

- retrieval-augmented generation motivates separating model parameters from external evidence;
- claim decomposition supports smaller verification units, while conservative splitting addresses documented decomposition noise;
- natural-language inference motivates explicit support and contradiction relations;
- uncertainty calibration motivates revisable confidence and outcome scoring;
- information-bottleneck ideas motivate preserving relevant information while limiting overload;
- active-inference and control perspectives motivate state, capacity, uncertainty, and bounded action signals;
- curriculum and self-paced learning motivate maturity-gated exposure rather than instant integration.

No combination of these components proves consciousness, a human psyche, or objective access to absolute truth. The implementation is a testable architecture.

## Original research proposals included here

The package operationalizes four new engineering hypotheses:

1. **Epistemic Metabolic Load** — information should be gated by source volume, claim density, complexity, novelty, and conflict.
2. **Bilateral Value Envelope** — objective evidential confidence and subjective significance should remain separate but jointly inform expression.
3. **Maturity-Gated Retrieval** — information should move through explicit stages instead of being immediately absorbed.
4. **Cross-Board Energy Translation** — one epistemic packet should generate distinct Psyche and Heartspace signals.

These are proposed hypotheses, not validated scientific laws. `research/run_experiments.py` provides falsifiable monotonicity tests and a place for later empirical datasets.
