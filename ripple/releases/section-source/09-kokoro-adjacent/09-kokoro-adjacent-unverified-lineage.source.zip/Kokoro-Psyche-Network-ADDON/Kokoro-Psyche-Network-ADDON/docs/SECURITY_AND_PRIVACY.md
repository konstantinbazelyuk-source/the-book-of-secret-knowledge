# Security and privacy

- Online retrieval is off by default.
- HTTP and HTTPS only.
- Loopback, private, link-local, reserved, multicast, and `.local` destinations are blocked.
- Redirect destinations are revalidated.
- Response size and timeout are bounded.
- robots.txt is checked for direct page access.
- Requests use an identifiable local user agent.
- General search keys are read from a Windows user environment variable.
- The key is never written into package manifests or databases.
- Full page text is not retained by default; excerpts, metadata, source URLs, and hashes are stored.
- The Network has no autonomous scheduler, network crawler, email access, hardware control, or self-installation.
