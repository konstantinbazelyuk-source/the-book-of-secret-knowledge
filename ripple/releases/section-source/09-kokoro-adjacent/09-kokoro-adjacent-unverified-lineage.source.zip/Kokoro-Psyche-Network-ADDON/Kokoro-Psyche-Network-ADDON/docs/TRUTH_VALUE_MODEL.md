# True and near-true value model

The Network does not calculate metaphysical Truth. It calculates a revisable engineering envelope.

For claim \(c\):

\[
C(c) = \operatorname{clip}(
0.47R_s + 0.34K + 0.10A + 0.09Q - 0.42X
)
\]

Where:

- \(R_s\): source reliability;
- \(K\): independent corroboration;
- \(A\): claim atomicity;
- \(Q\): checkability;
- \(X\): contradiction mass.

Calibration history multiplies the result. A user can later mark a claim supported, refuted, mixed, or unknown. The system records a Brier score rather than assuming its own confidence is trustworthy.

## Two value channels

### Objective candidate

Externally checkable content supported by evidence. It remains a candidate until support, source independence, and conflict justify stronger language.

### Subjective significance

A reported experience, preference, relationship meaning, or interpretation. It can be valid as an attributed experience without becoming a universal statement about the world.

## Expression energy

\[
E_x =
(0.60T + 0.40S)
(1 - 0.52U)
(1 - 0.45O)
\]

- \(T\): evidence-supported truth signal;
- \(S\): significance signal;
- \(U\): uncertainty;
- \(O\): overload above the safe capacity region.

Expression energy means justified communicative force, detail, and emphasis. It is not physical energy and not proof of emotion.
