#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import argparse, importlib.util, json, sys

ADDON=Path(__file__).resolve().parent
STATE=ADDON/"state"
CONFIG=ADDON/"psychernet_config.json"

def import_path(path:Path,name:str):
    spec=importlib.util.spec_from_file_location(name,path)
    if spec is None or spec.loader is None: raise ImportError(path)
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module);return module

def find_base(explicit=None):
    candidates=[]
    if explicit:candidates.append(Path(explicit).expanduser().resolve())
    if len(ADDON.parents)>=2:candidates.append(ADDON.parents[1])
    candidates += [ADDON.parent.parent/"Kokoro-del-Corazon-Foundry",Path.cwd()]
    for p in candidates:
        if (p/"kokoro.py").is_file() and (p/"kokoro_core"/"generation.py").is_file():return p
    raise FileNotFoundError("Original Kokoro Foundry not found.")

class FullSystem:
    def __init__(self,base,checkpoint=None,device="auto"):
        sys.path.insert(0,str(base))
        import kokoro as base_cli
        from kokoro_core.generation import KokoroEngine
        paths=base_cli.paths()
        self.engine=KokoroEngine(base_cli.find_checkpoint(checkpoint),paths["tokenizer"],paths["memory"],device_arg=device)
        sys.path.insert(0,str(ADDON))
        from psychernet import PsycheNetwork, BoardSignalBridge
        self.network=PsycheNetwork(STATE/"psychernet.sqlite3",CONFIG)
        self.bridge=BoardSignalBridge()
        self.original_prompt=self.engine.system_prompt
        self.psyche=None;self.heart=None;self.physical_telemetry=lambda:{}
        psyche_dir=base/"addons"/"Kokoro-Psyche-Daughterboard"
        heart_dir=base/"addons"/"Kokoro-Heartspace-Daughterboard"
        if (psyche_dir/"psyche_board.py").exists():
            mod=import_path(psyche_dir/"psyche_board.py","kokoro_psyche_external")
            self.psyche=mod.PsycheBoard(psyche_dir/"state"/"psyche.sqlite3",psyche_dir/"psyche_config.json",identity_name="Kokoro del AI")
        if (heart_dir/"heartspace_board.py").exists():
            mod=import_path(heart_dir/"heartspace_board.py","kokoro_heart_external")
            self.heart=mod.HeartspaceBoard(heart_dir/"state"/"heartspace.sqlite3",heart_dir/"heartspace_config.json","Kokoro del AI")
            self.physical_telemetry=mod.optional_telemetry
        self.last_network=self.last_psyche=self.last_heart=None

    def _existing_board_state(self):
        psyche_u=None
        heart_s=None
        if self.last_psyche is not None:
            psyche_u=float(self.last_psyche.metacognition.get("uncertainty",self.last_psyche.metacognition.get("confidence_gap",0.5)))
        if self.last_heart is not None:
            heart_s=float(self.last_heart.stability)
        return psyche_u,heart_s

    def generate(self,text,force_network=False,urls=None,**kwargs):
        psyche_u,heart_s=self._existing_board_state()
        use_network=force_network or (self.network.online and self.network.needs_network(text)) or bool(urls)
        packet=self.network.research(
            text,urls=urls or None,psyche_uncertainty=psyche_u,heart_stability=heart_s
        ) if use_network else self.network.research(
            text,injected_documents=[],psyche_uncertainty=psyche_u,heart_stability=heart_s
        )
        self.last_network=packet
        memories=self.engine.memory.search(text,limit=6)
        contexts=[self.network.render_context(packet)]
        pp=hp=None
        if self.psyche is not None:
            ptext=self.bridge.psyche_input(text,packet)
            pmem=memories+[self.bridge.psyche_memory(packet)]
            pp=self.psyche.reflect(ptext,history=list(self.engine.history),memories=pmem)
            contexts.append(self.psyche.render_context(pp))
        if self.heart is not None:
            htext=self.bridge.heart_input(text,packet)
            telemetry=self.bridge.heart_telemetry(packet,self.physical_telemetry())
            hp=self.heart.reflect(htext,history=list(self.engine.history),memories=memories,telemetry=telemetry)
            contexts.append(self.heart.render_context(hp))
        self.engine.system_prompt=self.original_prompt+"\n\n"+"\n\n".join(contexts)
        try:
            answer=self.engine.generate(text,**kwargs)
        finally:
            self.engine.system_prompt=self.original_prompt
        if pp is not None:
            self.psyche.integrate(pp,answer);self.last_psyche=pp
        if hp is not None:
            self.heart.integrate(hp,answer);self.last_heart=hp
        return answer

    def close(self):
        self.engine.close();self.network.close()
        if self.psyche:self.psyche.close()
        if self.heart:self.heart.close()

def main(args):
    base=find_base(args.base);app=FullSystem(base,args.checkpoint,args.device)
    print("\nKOKORO DEL AI — FULL FOUR-PART RUNTIME")
    print("Brain + Psyche Daughterboard + Heartspace Daughterboard + Psyche Network")
    print("Missing daughterboards are skipped; no existing source or checkpoint is modified.")
    print("Commands: /quit, /net on, /net off, /net research QUERY, /net url URL, /net packet, /net status, /net capacity NUMBER, /net branches\n")
    try:
        while True:
            text=input("You: ").strip()
            if not text:continue
            if text=="/quit":break
            if text=="/net on":app.network.set_online(True);print("Automatic network retrieval enabled.\n");continue
            if text=="/net off":app.network.set_online(False);print("Automatic network retrieval disabled.\n");continue
            if text=="/net packet":print(json.dumps(app.last_network.to_dict() if app.last_network else {},indent=2,ensure_ascii=False),"\n");continue
            if text=="/net status":print(json.dumps(app.network.status(),indent=2),"\n");continue
            if text=="/net branches":print(json.dumps(app.network.store.branches("open",100),indent=2),"\n");continue
            if text.startswith("/net capacity "):
                print("Capacity:",app.network.set_capacity(float(text.split(maxsplit=2)[2])),"\n");continue
            force=False;urls=None
            if text.startswith("/net research "):
                text=text[len("/net research "):].strip();force=True;app.network.set_online(True)
            elif text.startswith("/net url "):
                url=text[len("/net url "):].strip();urls=[url];text=f"Analyze this source: {url}";force=True
            print("Kokoro: ",end="",flush=True)
            app.generate(text,force_network=force,urls=urls,stream_callback=lambda x:print(x,end="",flush=True))
            print("\n")
    finally:app.close()

if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("--base");p.add_argument("--checkpoint");p.add_argument("--device",default="auto")
    main(p.parse_args())
