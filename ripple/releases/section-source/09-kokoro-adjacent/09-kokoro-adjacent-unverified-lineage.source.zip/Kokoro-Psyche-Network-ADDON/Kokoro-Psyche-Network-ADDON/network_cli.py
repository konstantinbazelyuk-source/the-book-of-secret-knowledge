#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import argparse, json, sys

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from psychernet import PsycheNetwork

def display(packet):
    print("\nPSYCHE NETWORK PACKET")
    print(f"Sources: {len(packet.sources)} | Claims: {len(packet.claims)}")
    print(f"Confidence: {packet.evidence_confidence:.3f} | Uncertainty: {packet.uncertainty:.3f} | Conflict: {packet.conflict:.3f}")
    print(f"Maturity: {packet.maturity_stage} | Capacity use: {packet.capacity_utilization:.3f}")
    print(f"Expression energy: {packet.expression_energy:.3f} | Mode: {packet.assertion_mode}")
    for claim in sorted(packet.claims,key=lambda x:x.confidence,reverse=True)[:6]:
        print(f"- {claim.claim_id} [{claim.confidence:.2f}] {claim.text[:180]}")
    if packet.warnings:
        print("Warnings:")
        for item in packet.warnings: print(" -",item)
    print()

def main(args):
    net=PsycheNetwork(ROOT/"state"/"psychernet.sqlite3",ROOT/"psychernet_config.json")
    try:
        if args.online:
            net.set_online(True)
        if args.capacity is not None:
            net.set_capacity(args.capacity)
        if args.command=="status":
            print(json.dumps(net.status(),indent=2))
        elif args.command=="research":
            packet=net.research(args.query,mode=args.mode,urls=args.url)
            display(packet)
            if args.json:
                print(json.dumps(packet.to_dict(),indent=2,ensure_ascii=False))
        elif args.command=="url":
            packet=net.research(args.url,mode="url",urls=[args.url])
            display(packet)
        elif args.command=="branches":
            print(json.dumps(net.store.branches("open",100),indent=2))
        elif args.command=="resolve":
            print("Resolved." if net.resolve_branch(args.branch_id) else "Branch not found.")
        elif args.command=="clear":
            net.store.clear();print("Psyche Network state deleted.")
    finally:
        net.close()

if __name__=="__main__":
    p=argparse.ArgumentParser(description="Kokoro Psyche Network")
    p.add_argument("--online",action="store_true")
    p.add_argument("--capacity",type=float)
    sub=p.add_subparsers(dest="command",required=True)
    s=sub.add_parser("status")
    r=sub.add_parser("research");r.add_argument("query");r.add_argument("--mode",default="auto");r.add_argument("--url",action="append");r.add_argument("--json",action="store_true")
    u=sub.add_parser("url");u.add_argument("url")
    sub.add_parser("branches")
    x=sub.add_parser("resolve");x.add_argument("branch_id")
    sub.add_parser("clear")
    main(p.parse_args())
