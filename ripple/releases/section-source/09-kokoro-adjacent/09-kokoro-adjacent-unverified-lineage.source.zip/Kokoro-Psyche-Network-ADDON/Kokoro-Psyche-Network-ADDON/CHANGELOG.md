# 1.0.0

Added:

- bounded internet and document connectors;
- safe URL fetcher and robots handling;
- conservative claim decomposition;
- objective/subjective/normative/speculative classification;
- support, contradiction, duplicate, and context graph;
- provenance and source-independence weighting;
- calibration outcomes and Brier reporting;
- seven maturity stages;
- comprehension capacity and information-load gating;
- expression-energy model;
- holographic epistemic capsules;
- separate signals for Psyche and Heartspace;
- unresolved branch continuity;
- full four-part Kokoro runtime;
- browser observatory;
- verification, tests, experiments, documentation, and installer.

Existing project files removed: 0.
Existing project files intentionally modified: 0.
