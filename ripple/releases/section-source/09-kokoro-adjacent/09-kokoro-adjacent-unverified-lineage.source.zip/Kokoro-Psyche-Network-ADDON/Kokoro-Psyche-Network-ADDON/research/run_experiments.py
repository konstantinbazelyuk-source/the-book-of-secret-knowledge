from pathlib import Path
import json, sys, tempfile
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from psychernet import PsycheNetwork, SourceDocument
from psychernet.util import stable_id,hash_text
import time

def doc(title,text,publisher,url,kind="peer_reviewed_primary"):
    return SourceDocument(
        source_id=stable_id("src",url,title),provider="experiment",title=title,url=url,
        publisher=publisher,published_at="2026-01-01",retrieved_at=time.time(),
        source_type=kind,primary_status="primary_research",text=text,snippet=text,
        content_hash=hash_text(text),extraction_quality=0.90
    )
db=ROOT/"state"/"experiment.sqlite3";db.unlink(missing_ok=True)
net=PsycheNetwork(db,ROOT/"psychernet_config.json")
cases={}
one=[doc("A","Controlled measurements found the device reduced latency by 20 percent.","Lab A","https://a.example.org/paper")]
three=one+[
 doc("B","Independent measurements found the device reduced latency by 20 percent.","Lab B","https://b.example.net/paper"),
 doc("C","A replication reported a 19 percent reduction in latency.","Lab C","https://c.example.com/paper")
]
conflict=three+[doc("D","The replication did not find a reduction in latency.","Lab D","https://d.example.edu/paper")]
subjective=[doc("Experience report","I felt the interface was calmer and more meaningful.","Participant","https://person.example.org/report","user_generated")]
p1=net.research("latency effect",injected_documents=one)
p3=net.research("latency effect",injected_documents=three)
pc=net.research("latency effect",injected_documents=conflict)
ps=net.research("interface experience",injected_documents=subjective)
low=net.research("latency effect",injected_documents=three,external_capacity=0.22)
cases={
 "independent_corroboration_increases_or_preserves_confidence":p3.evidence_confidence>=p1.evidence_confidence,
 "conflict_increases_uncertainty":pc.uncertainty>=p3.uncertainty,
 "subjective_report_not_universalized":ps.subjective_significance>ps.objective_candidate,
 "low_capacity_reduces_expression_energy":low.expression_energy<=p3.expression_energy,
 "deferred_branch_created_under_load":bool(low.unresolved_branches) or low.capacity_utilization<0.92,
}
report={"passed":sum(cases.values()),"total":len(cases),"cases":cases,
        "metrics":{"one":p1.to_dict(),"corroborated":p3.to_dict(),"conflicted":pc.to_dict(),"subjective":ps.to_dict(),"low_capacity":low.to_dict()}}
(ROOT/"logs"/"research_experiment_report.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
print(json.dumps({"passed":report["passed"],"total":report["total"],"cases":cases},indent=2))
net.close();db.unlink(missing_ok=True)
if not all(cases.values()):raise SystemExit(1)
