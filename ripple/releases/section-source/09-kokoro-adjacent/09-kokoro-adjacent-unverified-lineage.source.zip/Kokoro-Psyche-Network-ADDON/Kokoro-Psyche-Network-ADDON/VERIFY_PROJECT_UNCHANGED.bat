@echo off
setlocal
cd /d "%~dp0"
title Verify Kokoro Project Unchanged
set "BASE=%~dp0..\.."
if not exist "%BASE%\kokoro.py" (
 set /p "BASE=Paste the full path to Kokoro-del-Corazon-Foundry: "
 set "BASE=%BASE:"=%"
)
"%BASE%\.venv\Scripts\python.exe" VERIFY_PROJECT_UNCHANGED.py --base "%BASE%"
pause
