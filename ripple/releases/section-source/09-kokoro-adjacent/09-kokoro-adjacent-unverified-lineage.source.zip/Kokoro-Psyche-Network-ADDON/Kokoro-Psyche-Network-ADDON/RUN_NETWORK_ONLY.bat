@echo off
setlocal
cd /d "%~dp0"
title Kokoro Psyche Network
set "BASE=%~dp0..\.."
if exist "%BASE%\.venv\Scripts\python.exe" (
 "%BASE%\.venv\Scripts\python.exe" network_cli.py status
) else (
 python network_cli.py status
)
pause
