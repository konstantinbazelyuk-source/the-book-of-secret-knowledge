from pathlib import Path
import argparse,hashlib,json
ADDON=Path(__file__).resolve().parent
def check(root,manifest):
    expected=json.loads((ADDON/manifest).read_text())
    missing=[];changed=[]
    for rel,wanted in expected.items():
        p=root/rel
        if not p.exists():missing.append(rel)
        elif hashlib.sha256(p.read_bytes()).hexdigest()!=wanted:changed.append(rel)
    return len(expected),missing,changed
p=argparse.ArgumentParser();p.add_argument("--base",required=True);a=p.parse_args()
base=Path(a.base).resolve()
targets=[
 ("Original Foundry",base,"ORIGINAL_BASE_HASHES.json"),
 ("Psyche Daughterboard",base/"addons"/"Kokoro-Psyche-Daughterboard","ORIGINAL_PSYCHE_ADDON_HASHES.json"),
 ("Heartspace Daughterboard",base/"addons"/"Kokoro-Heartspace-Daughterboard","ORIGINAL_HEARTSPACE_ADDON_HASHES.json")
]
failed=False
for label,path,manifest in targets:
    expected=json.loads((ADDON/manifest).read_text())
    if not expected:
        print(f"{label}: reference package was unavailable when Psyche Network was built; compatibility will be runtime-tested.")
        continue
    if not path.exists():
        print(f"{label}: not installed at {path}; skipped.")
        continue
    n,missing,changed=check(path,manifest)
    print(f"{label}: checked {n}; missing={len(missing)}; changed={len(changed)}")
    if missing or changed:failed=True
print("PASS: existing project components are unchanged." if not failed else "FAIL: existing files differ from packaged reference hashes.")
raise SystemExit(1 if failed else 0)
