# Uninstall

1. Close the full runtime and observatory.
2. Delete:
   `Kokoro-del-Corazon-Foundry\addons\Kokoro-Psyche-Network`

This removes Network state only. Kokoro, Psyche, Heartspace, their databases, and all checkpoints remain.
