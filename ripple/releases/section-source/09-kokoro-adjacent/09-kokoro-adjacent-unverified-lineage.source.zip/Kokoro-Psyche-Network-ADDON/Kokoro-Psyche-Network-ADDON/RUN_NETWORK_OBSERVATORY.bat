@echo off
setlocal
cd /d "%~dp0"
title Kokoro Psyche Network Observatory
set "BASE=%~dp0..\.."
if exist "%BASE%\.venv\Scripts\python.exe" (
 "%BASE%\.venv\Scripts\python.exe" network_server.py
) else (
 python network_server.py
)
pause
