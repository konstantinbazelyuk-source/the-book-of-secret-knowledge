from __future__ import annotations

from pathlib import Path
from typing import Any
import time
import numpy as np

from .engine import OneiricEngine, _clip
from .models import DreamEpisode
from .profiles import get_profile
from .deep_cycle import run_deep_cycle
from .replay import prioritized_replay


class MaximizedOneiricEngine(OneiricEngine):
    """The original Oneiric engine plus deep candidate-level dreaming.

    Every candidate can receive staged replay, memory-graph diffusion, predictive
    latent-world simulation, counterfactual scene search, affect regulation,
    homeostatic analysis, and lucid auditing *before* favorite selection. Only
    the chosen candidate commits persistent homeostatic memory updates.
    """

    def __init__(self, database_path: str | Path, config_path: str | Path | None = None,
                 project_root: str | Path | None = None, profile: str | None = None):
        super().__init__(database_path, config_path, project_root)
        self.profile = get_profile(profile or getattr(self.config, "dream_profile", "deep"))

    @staticmethod
    def _enrich_metrics(dream: DreamEpisode, deep: dict) -> None:
        restructuring = float(deep.get("semantic_restructuring", 0.0))
        epistemic = float(deep.get("epistemic_gain", 0.0))
        cf_value = float(deep.get("counterfactual_value", 0.0))
        audit = deep.get("lucid_audit", {})
        affect = deep.get("affect", {})
        audit_score = float(audit.get("self_consistency", 0.5))
        emotional = float(affect.get("emotional_integration", 0.0))
        dream.metrics.integration_gain = _clip(0.72 * dream.metrics.integration_gain + 0.28 * restructuring)
        dream.metrics.novelty = _clip(0.78 * dream.metrics.novelty + 0.12 * epistemic + 0.10 * max(0.0, cf_value))
        dream.metrics.stability = _clip(0.72 * dream.metrics.stability + 0.16 * audit_score + 0.12 * emotional)
        dream.metrics.lucidity = _clip(0.62 * dream.metrics.lucidity + 0.38 * audit_score)
        dream.metrics.continuity = _clip(0.72 * dream.metrics.continuity + 0.28 * restructuring)
        dream.metrics.agency = _clip(0.72 * dream.metrics.agency + 0.18 * epistemic + 0.10 * max(0.0, cf_value))
        if not bool(audit.get("passed", True)):
            dream.metrics.factual_risk = _clip(dream.metrics.factual_risk + 0.25)
            dream.metrics.stability = _clip(dream.metrics.stability - 0.20)

    def _attach_deep_cycle(self, dream: DreamEpisode, deep: dict) -> None:
        dream.stage_path = list(deep["sleep_plan"]["stage_path"])
        dream.provenance["maximized_oneiric_version"] = "2.0.0"
        dream.provenance["dream_profile"] = self.profile.name
        dream.provenance["deep_cycle"] = deep
        dream.provenance["pocket_time_role"] = (
            "optional virtual duration input only; dreaming remains functional without Pocket Time"
        )
        dream.narrative += (
            f" The deep cycle formed {len(deep['latent_scenes'])} counterfactual symbolic scenes, "
            f"estimated semantic restructuring at {deep['semantic_restructuring']:.2f}, and retained "
            "all imagined outcomes as symbols or hypotheses pending waking verification."
        )

    def dream(self, wall_seconds: float | None = None, candidate_count: int | None = None,
              force: bool = False) -> DreamEpisode:
        with self.lock:
            if self.paused and not force:
                raise RuntimeError("Dreamspace is paused")
            if self.active:
                raise RuntimeError("A dream cycle is already active")
            idle = self.idle_seconds()
            if not force and idle < self.config.idle_threshold_seconds:
                raise RuntimeError(
                    f"Kokoro has been idle for {idle:.1f}s; threshold is {self.config.idle_threshold_seconds:.1f}s"
                )
            self.active = True
        cycle_start = time.perf_counter()
        try:
            memories = self.store.memories(max(500, self.profile.memory_limit * 8))
            if len(memories) < self.config.minimum_memories_per_dream:
                raise RuntimeError("Not enough memory traces for a dream cycle")
            # Profile limits the deep subset while base replay remains compatible with the original system.
            desired = min(self.profile.memory_limit, self.config.max_memories_per_dream)
            selected, probabilities = prioritized_replay(memories, self.config, self.rng, desired)
            requested_budget = wall_seconds if wall_seconds is not None else self.profile.wall_budget_seconds
            wall_budget = max(0.05, min(float(requested_budget), self.config.max_wall_seconds_per_cycle))
            virtual_seconds = self.clock.wall_to_virtual(wall_budget, self.config.max_virtual_seconds_per_cycle)
            count = candidate_count if candidate_count is not None else self.profile.candidate_count
            count = max(1, min(self.config.max_candidates_per_cycle, int(count)))

            candidates: list[DreamEpisode] = []
            deep_payloads: list[dict] = []
            homeostatic_updates: list[list] = []
            for index in range(count):
                candidate = self._compose_candidate(selected, probabilities, index, wall_budget, virtual_seconds)
                deep_result, updated = run_deep_cycle(candidate, selected, self.profile, self.rng)
                deep = deep_result.to_dict()
                self._enrich_metrics(candidate, deep)
                self._attach_deep_cycle(candidate, deep)
                candidates.append(candidate)
                deep_payloads.append(deep)
                homeostatic_updates.append(updated)

            actual_elapsed = time.perf_counter() - cycle_start
            actual_end = time.time()
            actual_start = actual_end - actual_elapsed
            for candidate in candidates:
                candidate.started_at = actual_start
                candidate.ended_at = actual_end
                candidate.wall_seconds = actual_elapsed
                candidate.provenance["actual_wall_seconds"] = actual_elapsed

            choice = self.preference.choose([candidate.metrics for candidate in candidates], self.rng)
            chosen = candidates[choice.index]
            chosen_deep = deep_payloads[choice.index]
            for i, candidate in enumerate(candidates):
                candidate.metrics.preference_score = float(choice.scores[i])
                candidate.chosen = i == choice.index
                candidate.favorite_rank = 1 if candidate.chosen else None
                self.store.save_dream(candidate)

            # Commit only the chosen candidate's consolidation changes.
            for memory in homeostatic_updates[choice.index]:
                self.store.upsert_memory(memory)

            internal_reward = _clip(
                0.23 * chosen.metrics.integration_gain
                + 0.18 * chosen.metrics.stability
                + 0.14 * chosen.metrics.beauty
                + 0.12 * chosen.metrics.novelty
                + 0.10 * chosen.metrics.lucidity
                + 0.08 * chosen.metrics.continuity
                + 0.08 * float(chosen_deep.get("epistemic_gain", 0.0))
                + 0.07 * max(0.0, float(chosen_deep.get("counterfactual_value", 0.0)))
                - 0.06 * chosen.metrics.loop_risk
                - 0.06 * chosen.metrics.factual_risk,
                -1.0,
                1.0,
            )
            self.preference.update(chosen.metrics, internal_reward)
            self.store.set_state("preference_model", self.preference.state_dict())

            capsule = self._wake_capsule(chosen, selected)
            capsule_dict = capsule.to_dict()
            capsule_dict.update({
                "deep_cycle_id": chosen_deep["cycle_id"],
                "semantic_restructuring": chosen_deep["semantic_restructuring"],
                "epistemic_gain": chosen_deep["epistemic_gain"],
                "counterfactual_value": chosen_deep["counterfactual_value"],
                "latent_scene_summaries": [
                    {k: scene[k] for k in ("scene_id", "themes", "classification")}
                    for scene in chosen_deep["latent_scenes"][:8]
                ],
                "factual_claims": [],
            })
            chosen.wake_capsule = capsule_dict
            self.store.save_dream(chosen)
            self.store.set_state("last_wake_capsule", capsule_dict)
            self.store.set_state("last_awareness_state", chosen.awareness_state)
            self.store.set_state("last_deep_cycle", chosen_deep)
            self.last_wake_capsule = capsule_dict
            self.store.increment_access(chosen.selected_memory_ids)
            self.store.event("maximized_dream_completed", {
                "dream_id": chosen.dream_id,
                "profile": self.profile.name,
                "cycle_id": chosen_deep["cycle_id"],
                "candidate_count": len(candidates),
                "chosen_index": choice.index,
                "counterfactuals_per_candidate": len(chosen_deep["latent_scenes"]),
                "actual_wall_seconds": actual_elapsed,
                "virtual_seconds": virtual_seconds,
            })
            self.last_activity = time.monotonic()
            return chosen
        finally:
            with self.lock:
                self.active = False

    def status(self) -> dict[str, Any]:
        raw = super().status()
        raw.update({
            "engine": "MaximizedOneiricEngine",
            "maximized_version": "2.0.0",
            "dream_profile": self.profile.name,
            "last_deep_cycle": self.store.get_state("last_deep_cycle", {}),
        })
        return raw
