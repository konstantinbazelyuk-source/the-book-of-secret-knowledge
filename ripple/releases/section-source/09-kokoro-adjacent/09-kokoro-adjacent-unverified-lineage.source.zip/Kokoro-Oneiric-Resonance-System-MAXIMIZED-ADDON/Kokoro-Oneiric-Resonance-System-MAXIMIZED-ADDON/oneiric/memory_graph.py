from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Sequence
import math
import numpy as np

from .models import MemoryTrace


@dataclass(slots=True)
class MemoryGraphResult:
    adjacency: list[list[float]]
    centrality: list[float]
    bridge_scores: list[float]
    communities: list[int]
    schema_centroids: list[list[float]]
    sequence_score: float
    source_diversity: float

    def to_dict(self) -> dict:
        return asdict(self)


def _cosine_matrix(x: np.ndarray) -> np.ndarray:
    norms = np.linalg.norm(x, axis=1, keepdims=True)
    y = x / np.maximum(norms, 1e-12)
    return np.clip(y @ y.T, -1.0, 1.0)


def build_memory_graph(memories: Sequence[MemoryTrace], diffusion_steps: int = 6, cluster_passes: int = 6) -> MemoryGraphResult:
    n = len(memories)
    if n == 0:
        return MemoryGraphResult([], [], [], [], [], 0.0, 0.0)
    x = np.asarray([m.embedding for m in memories], dtype=np.float64)
    sim = (_cosine_matrix(x) + 1.0) * 0.5
    adjacency = np.zeros((n, n), dtype=np.float64)
    for i, a in enumerate(memories):
        atags = set(a.tags)
        for j, b in enumerate(memories):
            if i == j:
                continue
            tag_union = atags | set(b.tags)
            tag_overlap = len(atags & set(b.tags)) / max(1, len(tag_union))
            age_days = abs(a.created_at - b.created_at) / 86400.0
            temporal = math.exp(-age_days / 14.0)
            value_alignment = 1.0 - abs(a.value - b.value)
            source_bridge = 1.0 if a.source != b.source else 0.0
            adjacency[i, j] = np.clip(
                0.56 * sim[i, j] + 0.14 * tag_overlap + 0.12 * temporal
                + 0.10 * value_alignment + 0.08 * source_bridge,
                0.0,
                1.0,
            )
    np.fill_diagonal(adjacency, 0.0)
    row = adjacency / np.maximum(adjacency.sum(axis=1, keepdims=True), 1e-12)
    centrality = np.full(n, 1.0 / n)
    for _ in range(max(1, diffusion_steps)):
        centrality = 0.15 / n + 0.85 * row.T @ centrality
        centrality /= max(float(centrality.sum()), 1e-12)
    local_mean = np.divide(adjacency.sum(axis=1), np.maximum((adjacency > 0.45).sum(axis=1), 1))
    bridge = centrality * (1.0 - np.clip(local_mean, 0.0, 1.0))
    if bridge.max() > 0:
        bridge /= bridge.max()

    labels = np.arange(n, dtype=int)
    for _ in range(max(1, cluster_passes)):
        changed = False
        for i in range(n):
            scores: dict[int, float] = {}
            for j in range(n):
                if i == j or adjacency[i, j] < 0.40:
                    continue
                scores[int(labels[j])] = scores.get(int(labels[j]), 0.0) + float(adjacency[i, j])
            if scores:
                best = max(scores.items(), key=lambda kv: (kv[1], -kv[0]))[0]
                if best != labels[i]:
                    labels[i] = best
                    changed = True
        if not changed:
            break
    unique = {old: new for new, old in enumerate(sorted(set(int(v) for v in labels)))}
    labels = np.asarray([unique[int(v)] for v in labels], dtype=int)
    centroids: list[list[float]] = []
    for label in sorted(set(labels.tolist())):
        centroids.append(np.mean(x[labels == label], axis=0).tolist())

    ordered = sorted(range(n), key=lambda i: memories[i].created_at)
    sequential_edges = [adjacency[a, b] for a, b in zip(ordered, ordered[1:])]
    sequence_score = float(np.mean(sequential_edges)) if sequential_edges else 0.0
    source_diversity = len({m.source for m in memories}) / n
    return MemoryGraphResult(
        adjacency=adjacency.tolist(),
        centrality=centrality.tolist(),
        bridge_scores=bridge.tolist(),
        communities=labels.tolist(),
        schema_centroids=centroids,
        sequence_score=sequence_score,
        source_diversity=source_diversity,
    )
