from __future__ import annotations

from dataclasses import dataclass, asdict
import re


FACT_MARKERS = re.compile(r"\b(confirmed|proved|scientists found|according to|the fact is|definitely happened)\b", re.I)


@dataclass(slots=True)
class LucidAudit:
    self_consistency: float
    factual_separation: float
    loop_resistance: float
    provenance_completeness: float
    uncertainty_honesty: float
    passed: bool
    warnings: list[str]

    def to_dict(self) -> dict:
        return asdict(self)


def audit(narrative: str, loop_risk: float, factual_risk: float, provenance: dict) -> LucidAudit:
    warnings: list[str] = []
    fact_hits = len(FACT_MARKERS.findall(narrative or ""))
    factual_separation = max(0.0, 1.0 - max(factual_risk, min(1.0, fact_hits * 0.25)))
    loop_resistance = max(0.0, 1.0 - loop_risk)
    required = {"classical_simulation", "literal_quantum_hardware", "clock_source"}
    provenance_completeness = len(required.intersection(provenance)) / len(required)
    uncertainty_honesty = 1.0 if any(w in (narrative or "").lower() for w in ("symbol", "possibility", "question", "not a fact")) else 0.55
    self_consistency = 0.55 * factual_separation + 0.45 * loop_resistance
    if factual_separation < 0.70:
        warnings.append("dream language approached factual assertion")
    if loop_resistance < 0.25:
        warnings.append("dream repeated a recent pattern too closely")
    if provenance_completeness < 1.0:
        warnings.append("provenance record incomplete")
    passed = factual_separation >= 0.65 and loop_resistance >= 0.15 and provenance_completeness >= 0.66
    return LucidAudit(self_consistency, factual_separation, loop_resistance,
                      provenance_completeness, uncertainty_honesty, passed, warnings)
