from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Sequence
import hashlib
import numpy as np

from .models import MemoryTrace, DreamEpisode
from .profiles import DreamProfile
from .sleep_architecture import build_cycle_plan
from .memory_graph import build_memory_graph
from .predictive_world import build_predictive_world
from .homeostasis import consolidate
from .affect import regulate
from .lucid_audit import audit


@dataclass(slots=True)
class DeepCycleResult:
    cycle_id: str
    sleep_plan: dict
    memory_graph: dict
    predictive_world: dict
    homeostasis: dict
    affect: dict
    lucid_audit: dict
    latent_scenes: list[dict]
    abstraction_score: float
    counterfactual_value: float
    epistemic_gain: float
    semantic_restructuring: float

    def to_dict(self) -> dict:
        return asdict(self)


def _scene(memories: Sequence[MemoryTrace], branch: dict, index: int, communities: list[int]) -> dict:
    source = {m.memory_id: m for m in memories}
    chosen = [source[mid] for mid in branch["source_memory_ids"] if mid in source]
    themes: list[str] = []
    for m in chosen:
        themes.extend([t for t in m.tags if t not in themes])
    if not themes:
        themes = [w.strip(".,:;!?()[]").lower() for m in chosen for w in m.text.split() if len(w) >= 5][:6]
    return {
        "scene_id": f"scene-{index + 1:03d}",
        "branch_id": branch["branch_id"],
        "themes": themes[:8],
        "source_memory_ids": branch["source_memory_ids"],
        "novelty": branch["novelty"],
        "plausibility": branch["plausibility"],
        "epistemic_value": branch["epistemic_value"],
        "pragmatic_value": branch["pragmatic_value"],
        "risk": branch["risk"],
        "expected_free_energy": branch["expected_free_energy"],
        "community_ids": sorted({communities[memories.index(m)] for m in chosen}) if chosen else [],
        "classification": "counterfactual-symbolic-scene",
    }


def run_deep_cycle(dream: DreamEpisode, memories: Sequence[MemoryTrace], profile: DreamProfile,
                   rng: np.random.Generator) -> tuple[DeepCycleResult, list[MemoryTrace]]:
    cycle_id = "deep-" + hashlib.sha256((dream.dream_id + profile.name).encode()).hexdigest()[:16]
    graph = build_memory_graph(memories, profile.graph_diffusion_steps, profile.graph_cluster_passes)
    world = build_predictive_world(memories, profile.latent_dim, profile.counterfactual_branches, rng)
    plan = build_cycle_plan(dream.virtual_seconds, profile.simulated_cycles)
    home = consolidate(memories, graph.centrality, profile.homeostatic_rate, cycle_id)
    affect = regulate(memories, dream.metrics.coherence, dream.metrics.stability)
    lucid = audit(dream.narrative, dream.metrics.loop_risk, dream.metrics.factual_risk, dream.provenance)
    branch_dicts = [b.to_dict() for b in world.counterfactuals]
    scenes = [_scene(memories, b, i, graph.communities) for i, b in enumerate(branch_dicts)]
    epistemic = float(np.mean([b["epistemic_value"] for b in branch_dicts]))
    cf_value = float(np.max([b["pragmatic_value"] - b["risk"] for b in branch_dicts]))
    abstraction = float(np.clip(
        profile.abstraction_strength * (0.35 * world.explained_variance + 0.25 * graph.sequence_score
        + 0.20 * dream.metrics.integration_gain + 0.20 * graph.source_diversity), 0.0, 1.0))
    restructuring = float(np.clip(0.45 * abstraction + 0.30 * epistemic + 0.25 * dream.metrics.novelty, 0.0, 1.0))
    result = DeepCycleResult(
        cycle_id=cycle_id,
        sleep_plan=plan.to_dict(),
        memory_graph=graph.to_dict(),
        predictive_world=world.to_dict(),
        homeostasis=home.to_dict(),
        affect=affect.to_dict(),
        lucid_audit=lucid.to_dict(),
        latent_scenes=scenes,
        abstraction_score=abstraction,
        counterfactual_value=cf_value,
        epistemic_gain=epistemic,
        semantic_restructuring=restructuring,
    )
    return result, home.updated_memories
