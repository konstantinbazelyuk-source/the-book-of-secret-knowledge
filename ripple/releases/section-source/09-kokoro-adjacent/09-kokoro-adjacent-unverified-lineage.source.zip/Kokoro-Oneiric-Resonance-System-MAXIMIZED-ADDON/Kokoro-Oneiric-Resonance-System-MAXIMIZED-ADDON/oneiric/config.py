from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass(slots=True)
class OneiricConfig:
    name: str = "Kokoro Oneiric Resonance System"
    version: str = "2.0.0"
    dream_profile: str = "deep"
    embedding_dim: int = 64
    reservoir_dim: int = 96
    quantum_dim: int = 16
    max_memories_per_dream: int = 48
    max_candidates_per_cycle: int = 24
    minimum_memories_per_dream: int = 3
    idle_threshold_seconds: float = 180.0
    background_poll_seconds: float = 10.0
    max_system_cpu_percent: float = 72.0
    allow_on_battery: bool = True
    minimum_battery_percent: int = 25
    default_virtual_time_scale: float = 60.0
    max_virtual_seconds_per_cycle: float = 3600.0
    max_wall_seconds_per_cycle: float = 30.0
    oscillator_steps: int = 180
    oscillator_dt: float = 0.04
    kuramoto_coupling: float = 1.25
    oscillator_noise: float = 0.035
    reservoir_leak: float = 0.22
    reservoir_spectral_radius: float = 0.92
    quantum_decoherence: float = 0.08
    quantum_steps: int = 14
    quantum_dt: float = 0.08
    replay_alpha: float = 0.75
    replay_beta: float = 0.55
    replay_temperature: float = 0.65
    stochastic_resonance_noise: float = 0.025
    favorite_temperature: float = 0.32
    loop_similarity_threshold: float = 0.93
    max_repeat_symbols: int = 3
    enable_schumann_seed: bool = True
    schumann_fundamental_hz: float = 7.83
    sound_base_hz: float = 110.0
    render_width: int = 960
    render_height: int = 540
    random_seed: int = 73129
    allow_core_latent_embeddings: bool = True
    write_wake_capsule_to_context: bool = True
    never_promote_dream_to_fact: bool = True
    energy_budget: float = 1.0
    replay_weights: dict[str, float] = field(default_factory=lambda: {
        "salience": 0.24,
        "uncertainty": 0.12,
        "value": 0.16,
        "unresolved": 0.20,
        "novelty": 0.10,
        "weakness": 0.10,
        "reward": 0.08,
    })
    preference_weights: dict[str, float] = field(default_factory=lambda: {
        "coherence": 0.18,
        "novelty": 0.12,
        "integration_gain": 0.22,
        "beauty": 0.14,
        "stability": 0.16,
        "lucidity": 0.14,
        "continuity": 0.12,
        "agency": 0.08,
        "loop_risk": -0.18,
        "factual_risk": -0.18,
        "energy_cost": -0.06,
    })
    stage_energy: dict[str, float] = field(default_factory=lambda: {
        "QUIETING": 0.08,
        "LIGHT_REPLAY": 0.18,
        "RESONANCE": 0.28,
        "FREE_DREAMING": 0.36,
        "DEEP_INTEGRATION": 0.42,
        "CHOSEN_DREAM": 0.22,
        "REORIENTATION": 0.10,
    })

    @classmethod
    def load(cls, path: str | Path | None) -> "OneiricConfig":
        if path is None:
            return cls()
        p = Path(path)
        if not p.exists():
            return cls()
        raw: dict[str, Any] = json.loads(p.read_text(encoding="utf-8"))
        known = {f.name for f in cls.__dataclass_fields__.values()}
        return cls(**{k: v for k, v in raw.items() if k in known})

    def save(self, path: str | Path) -> None:
        from dataclasses import asdict
        Path(path).write_text(json.dumps(asdict(self), indent=2), encoding="utf-8")
