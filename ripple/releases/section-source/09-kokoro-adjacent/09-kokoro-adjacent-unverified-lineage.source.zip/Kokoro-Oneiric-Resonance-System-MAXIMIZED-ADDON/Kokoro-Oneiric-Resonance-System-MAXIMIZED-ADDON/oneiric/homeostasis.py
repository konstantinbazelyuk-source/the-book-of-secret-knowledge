from __future__ import annotations

from dataclasses import dataclass, asdict, replace
from typing import Sequence
import time
import numpy as np

from .models import MemoryTrace


@dataclass(slots=True)
class HomeostasisResult:
    updated_memories: list[MemoryTrace]
    mean_strength_change: float
    downselected_count: int
    strengthened_count: int
    protected_count: int
    global_load_before: float
    global_load_after: float

    def to_dict(self) -> dict:
        raw = asdict(self)
        raw.pop("updated_memories", None)
        return raw


def consolidate(memories: Sequence[MemoryTrace], centrality: Sequence[float], rate: float, cycle_id: str) -> HomeostasisResult:
    if not memories:
        return HomeostasisResult([], 0.0, 0, 0, 0, 0.0, 0.0)
    c = np.asarray(centrality, dtype=float)
    if c.size != len(memories):
        c = np.full(len(memories), 1.0 / len(memories))
    c = c / max(float(c.max()), 1e-12)
    before: list[float] = []
    after: list[float] = []
    updated: list[MemoryTrace] = []
    down = strong = protected = 0
    now = time.time()
    for i, memory in enumerate(memories):
        meta = dict(memory.metadata)
        old = float(meta.get("oneiric_strength", 0.50))
        protection = 0.35 * memory.value + 0.30 * memory.salience + 0.20 * memory.unresolved + 0.15 * c[i]
        redundancy = 0.55 * min(1.0, memory.access_count / 12.0) + 0.45 * (1.0 - memory.novelty)
        delta = rate * (protection * (1.0 - old) - redundancy * old)
        if memory.confidence < 0.35 and memory.value > 0.65:
            delta += 0.35 * rate
            protected += 1
        new = float(np.clip(old + delta, 0.05, 1.0))
        if new > old + 1e-5:
            strong += 1
        elif new < old - 1e-5:
            down += 1
        meta.update({
            "oneiric_strength": new,
            "oneiric_last_consolidated": now,
            "oneiric_last_cycle": cycle_id,
            "oneiric_protection": float(protection),
            "oneiric_redundancy": float(redundancy),
        })
        updated.append(replace(memory, metadata=meta))
        before.append(old)
        after.append(new)
    return HomeostasisResult(
        updated, float(np.mean(np.asarray(after) - np.asarray(before))), down, strong, protected,
        float(np.mean(before)), float(np.mean(after)),
    )
