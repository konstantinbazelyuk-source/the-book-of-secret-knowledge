from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Sequence
import numpy as np

from .models import MemoryTrace


@dataclass(slots=True)
class CounterfactualScene:
    branch_id: str
    latent: list[float]
    novelty: float
    plausibility: float
    epistemic_value: float
    pragmatic_value: float
    ambiguity: float
    risk: float
    expected_free_energy: float
    source_memory_ids: list[str]

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(slots=True)
class PredictiveWorldResult:
    latent_dim: int
    reconstruction_error: float
    prediction_error: float
    explained_variance: float
    counterfactuals: list[CounterfactualScene]
    dominant_branch: int

    def to_dict(self) -> dict:
        raw = asdict(self)
        raw["counterfactuals"] = [c.to_dict() for c in self.counterfactuals]
        return raw


def _clip(v: float) -> float:
    return max(0.0, min(1.0, float(v)))


def build_predictive_world(memories: Sequence[MemoryTrace], latent_dim: int, branches: int, rng: np.random.Generator) -> PredictiveWorldResult:
    x = np.asarray([m.embedding for m in memories], dtype=np.float64)
    n, d = x.shape
    mean = x.mean(axis=0)
    centered = x - mean
    if n <= 1:
        basis = np.eye(d)[:1]
        z = centered @ basis.T
        explained = 0.0
    else:
        _, s, vt = np.linalg.svd(centered, full_matrices=False)
        k = max(1, min(latent_dim, vt.shape[0]))
        basis = vt[:k]
        z = centered @ basis.T
        explained = float(np.sum(s[:k] ** 2) / max(np.sum(s ** 2), 1e-12))
    recon = z @ basis + mean
    reconstruction_error = float(np.mean((x - recon) ** 2))

    if n >= 3:
        z0, z1 = z[:-1], z[1:]
        reg = 1e-3 * np.eye(z0.shape[1])
        transition = np.linalg.solve(z0.T @ z0 + reg, z0.T @ z1).T
        predicted = z0 @ transition.T
        prediction_error = float(np.mean((predicted - z1) ** 2))
        anchor = z[-1] @ transition.T
    else:
        transition = np.eye(z.shape[1])
        prediction_error = 0.0
        anchor = z[-1]

    spreads = np.std(z, axis=0) + 1e-6
    counterfactuals: list[CounterfactualScene] = []
    values = np.asarray([m.value for m in memories], dtype=float)
    unresolved = np.asarray([m.unresolved for m in memories], dtype=float)
    uncertainty = np.asarray([m.uncertainty for m in memories], dtype=float)
    source_ids = [m.memory_id for m in memories]
    for i in range(max(1, branches)):
        direction = rng.normal(size=anchor.shape)
        direction /= max(float(np.linalg.norm(direction)), 1e-12)
        radius = (0.25 + 0.75 * (i + 1) / max(1, branches)) * spreads
        latent = anchor + direction * radius
        distances = np.linalg.norm(z - latent, axis=1)
        nearest = np.argsort(distances)[: min(4, n)]
        novelty = _clip(float(np.min(distances)) / (1.0 + float(np.mean(spreads))))
        plausibility = _clip(float(np.exp(-np.min(distances) / (1.0 + float(np.mean(spreads))))))
        epistemic = _clip(float(np.mean(uncertainty[nearest])) * (0.55 + 0.45 * novelty))
        pragmatic = _clip(0.55 * float(np.mean(values[nearest])) + 0.45 * float(np.mean(unresolved[nearest])))
        ambiguity = _clip(float(np.var(distances[nearest])) / (1.0 + float(np.mean(distances[nearest]) ** 2)))
        risk = _clip(0.55 * (1.0 - plausibility) + 0.25 * ambiguity + 0.20 * max(0.0, novelty - 0.85))
        efe = risk + ambiguity - epistemic - pragmatic
        counterfactuals.append(CounterfactualScene(
            branch_id=f"cf-{i + 1:03d}",
            latent=latent.tolist(), novelty=novelty, plausibility=plausibility,
            epistemic_value=epistemic, pragmatic_value=pragmatic,
            ambiguity=ambiguity, risk=risk, expected_free_energy=float(efe),
            source_memory_ids=[source_ids[int(j)] for j in nearest],
        ))
    dominant = int(np.argmin([c.expected_free_energy for c in counterfactuals]))
    return PredictiveWorldResult(
        latent_dim=int(z.shape[1]), reconstruction_error=reconstruction_error,
        prediction_error=prediction_error, explained_variance=explained,
        counterfactuals=counterfactuals, dominant_branch=dominant,
    )
