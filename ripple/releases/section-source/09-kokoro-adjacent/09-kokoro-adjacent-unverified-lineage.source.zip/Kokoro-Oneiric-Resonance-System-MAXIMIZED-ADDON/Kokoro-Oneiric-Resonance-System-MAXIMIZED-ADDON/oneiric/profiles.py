from __future__ import annotations

from dataclasses import dataclass
import os


@dataclass(frozen=True, slots=True)
class DreamProfile:
    name: str
    memory_limit: int
    candidate_count: int
    graph_diffusion_steps: int
    graph_cluster_passes: int
    latent_dim: int
    counterfactual_branches: int
    simulated_cycles: int
    rem_association_radius: float
    homeostatic_rate: float
    abstraction_strength: float
    wall_budget_seconds: float


PROFILES: dict[str, DreamProfile] = {
    "balanced": DreamProfile("balanced", 18, 5, 4, 4, 8, 8, 2, 0.44, 0.045, 0.42, 4.0),
    "deep": DreamProfile("deep", 32, 9, 7, 7, 12, 18, 4, 0.58, 0.065, 0.60, 12.0),
    "maximum": DreamProfile("maximum", 48, 15, 11, 10, 16, 32, 6, 0.72, 0.085, 0.78, 30.0),
    "cloud": DreamProfile("cloud", 72, 24, 16, 14, 24, 64, 8, 0.84, 0.100, 0.90, 75.0),
}


def auto_profile_name(configured: str = "deep") -> str:
    configured = (configured or "deep").lower()
    if configured != "auto":
        return configured if configured in PROFILES else "deep"
    cpus = os.cpu_count() or 2
    if cpus >= 24:
        return "maximum"
    if cpus >= 8:
        return "deep"
    return "balanced"


def get_profile(name: str = "deep") -> DreamProfile:
    return PROFILES[auto_profile_name(name)]
