from __future__ import annotations

from dataclasses import dataclass, asdict
import math


@dataclass(frozen=True, slots=True)
class DreamStage:
    name: str
    family: str
    fraction: float
    replay_gain: float
    association_gain: float
    downselection_gain: float
    lucidity_gain: float

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class DreamCyclePlan:
    cycles: int
    stages: tuple[DreamStage, ...]
    virtual_seconds: float
    compression_ratio: float

    @property
    def stage_path(self) -> list[str]:
        result: list[str] = []
        for cycle in range(self.cycles):
            result.extend(f"C{cycle + 1}:{s.name}" for s in self.stages)
        return result

    def to_dict(self) -> dict:
        return {
            "cycles": self.cycles,
            "virtual_seconds": self.virtual_seconds,
            "compression_ratio": self.compression_ratio,
            "stages": [s.to_dict() for s in self.stages],
            "stage_path": self.stage_path,
        }


BASE_STAGES: tuple[DreamStage, ...] = (
    DreamStage("QUIETING", "transition", 0.05, 0.10, 0.05, 0.05, 0.08),
    DreamStage("NREM2_TRIAGE", "selection", 0.12, 0.70, 0.10, 0.20, 0.08),
    DreamStage("NREM3_REPLAY", "consolidation", 0.24, 1.00, 0.12, 0.48, 0.06),
    DreamStage("OSCILLATORY_COUPLING", "binding", 0.14, 0.80, 0.20, 0.24, 0.12),
    DreamStage("REM_HYPERASSOCIATION", "imagination", 0.24, 0.35, 1.00, 0.10, 0.32),
    DreamStage("DEEP_INTEGRATION", "abstraction", 0.12, 0.72, 0.64, 0.42, 0.20),
    DreamStage("LUCID_REVIEW", "metacognition", 0.05, 0.15, 0.10, 0.05, 1.00),
    DreamStage("REORIENTATION", "transition", 0.04, 0.08, 0.05, 0.02, 0.45),
)


def build_cycle_plan(virtual_seconds: float, requested_cycles: int) -> DreamCyclePlan:
    virtual_seconds = max(1.0, float(virtual_seconds))
    # More virtual duration deepens the simulated path, not the real compute performed.
    duration_factor = max(0.75, min(1.55, math.log1p(virtual_seconds) / math.log1p(3600.0)))
    cycles = max(1, min(12, int(round(requested_cycles * duration_factor))))
    compression = virtual_seconds / max(1.0, sum(s.fraction for s in BASE_STAGES) * cycles)
    return DreamCyclePlan(cycles, BASE_STAGES, virtual_seconds, compression)
