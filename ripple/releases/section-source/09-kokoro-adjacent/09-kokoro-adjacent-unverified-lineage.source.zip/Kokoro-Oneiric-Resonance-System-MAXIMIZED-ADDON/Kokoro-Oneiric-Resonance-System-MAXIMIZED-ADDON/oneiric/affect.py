from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Sequence
import numpy as np

from .models import MemoryTrace


@dataclass(slots=True)
class AffectResult:
    valence_before: float
    arousal_before: float
    valence_after: float
    arousal_after: float
    emotional_integration: float
    unresolved_emotional_load: float
    regulation_vector: list[float]

    def to_dict(self) -> dict:
        return asdict(self)


def regulate(memories: Sequence[MemoryTrace], coherence: float, stability: float) -> AffectResult:
    if not memories:
        return AffectResult(0.5, 0.0, 0.5, 0.0, 0.0, 0.0, [0.0, 0.0])
    values = np.asarray([m.value for m in memories], dtype=float)
    rewards = np.asarray([0.5 + 0.5 * m.reward for m in memories], dtype=float)
    tensions = np.asarray([0.55 * m.uncertainty + 0.45 * m.unresolved for m in memories], dtype=float)
    weights = np.asarray([0.2 + 0.5 * m.salience + 0.3 * m.unresolved for m in memories], dtype=float)
    weights /= max(float(weights.sum()), 1e-12)
    valence = float(np.sum((0.55 * values + 0.45 * rewards) * weights))
    arousal = float(np.sum(tensions * weights))
    target_valence = 0.50 + 0.20 * (valence - 0.50)
    target_arousal = 0.18 + 0.35 * arousal
    gain = np.clip(0.35 * coherence + 0.35 * stability + 0.30 * (1.0 - arousal), 0.0, 1.0)
    valence_after = float(np.clip(valence + gain * (target_valence - valence), 0.0, 1.0))
    arousal_after = float(np.clip(arousal + gain * (target_arousal - arousal), 0.0, 1.0))
    integration = float(np.clip(gain * (1.0 - abs(valence_after - valence)) + 0.25 * coherence, 0.0, 1.0))
    unresolved_load = float(np.sum(np.asarray([m.unresolved for m in memories]) * weights))
    return AffectResult(valence, arousal, valence_after, arousal_after, integration, unresolved_load,
                        [valence_after - valence, arousal_after - arousal])
