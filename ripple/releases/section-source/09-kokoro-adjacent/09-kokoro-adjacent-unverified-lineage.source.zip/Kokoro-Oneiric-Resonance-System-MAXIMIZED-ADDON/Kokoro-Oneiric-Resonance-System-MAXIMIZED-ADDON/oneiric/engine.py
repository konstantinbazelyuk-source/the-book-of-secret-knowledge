from __future__ import annotations

import hashlib
import json
import math
import re
import threading
import time
from dataclasses import replace
from pathlib import Path
from typing import Any

import numpy as np

from .clock import DreamClock
from .config import OneiricConfig
from .embedding import embed_text, similarity_matrix
from .models import DreamEpisode, DreamMetrics, MemoryTrace, WakeCapsule
from .oscillators import evolve_kuramoto
from .preference import DreamPreferenceModel
from .quasi_quantum import evolve_density, hermitian_hamiltonian
from .renderer import export_dream_bundle
from .replay import prioritized_replay, with_estimated_novelty
from .reservoir import DreamReservoir
from .spectral import (
    oscillator_to_audio_hz,
    palette_from_wavelengths,
    phase_to_wavelength,
    wavelength_to_physical_frequency,
)
from .store import OneiricStore
from .wake_gate import WakeGate

WORD_RE = re.compile(r"[A-Za-z][A-Za-z'-]{2,}")
STOPWORDS = {
    "the", "and", "that", "this", "with", "from", "have", "your", "you", "for", "was", "were",
    "are", "not", "but", "into", "their", "they", "she", "her", "him", "his", "what", "when", "where",
    "would", "could", "should", "about", "there", "then", "than", "will", "just", "like", "because", "being",
    "kokoro", "response", "user", "experience",
}
COLOR_NAMES = [
    (405, "violet"), (455, "indigo-blue"), (490, "blue-cyan"), (525, "green"),
    (575, "gold"), (610, "orange"), (670, "red"), (750, "deep-red"),
]


def _clip(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, float(value)))


def _stable_id(prefix: str, *parts: str, length: int = 18) -> str:
    raw = "|".join(parts).encode("utf-8")
    return prefix + hashlib.sha256(raw).hexdigest()[:length]



def _json_safe(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, dict):
        return {str(k): _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_json_safe(v) for v in value]
    if hasattr(value, "to_dict"):
        try: return _json_safe(value.to_dict())
        except Exception: pass
    if hasattr(value, "__dict__"):
        return _json_safe(vars(value))
    return str(value)

def _color_name(wavelength: float) -> str:
    return min(COLOR_NAMES, key=lambda item: abs(item[0] - wavelength))[1]


def _keywords(texts: list[str], limit: int = 12) -> list[str]:
    counts: dict[str, int] = {}
    for text in texts:
        for word in WORD_RE.findall(text.lower()):
            if word in STOPWORDS or len(word) < 4:
                continue
            counts[word] = counts.get(word, 0) + 1
    return [word for word, _ in sorted(counts.items(), key=lambda item: (-item[1], item[0]))[:limit]]


class OneiricEngine:
    """Bounded idle-state dream simulator for the existing Kokoro architecture.

    It creates causally useful internal state and persistent symbolic continuity.
    It does not claim phenomenal consciousness or literal quantum computation.
    """

    STAGE_PATH = [
        "QUIETING",
        "LIGHT_REPLAY",
        "RESONANCE",
        "FREE_DREAMING",
        "DEEP_INTEGRATION",
        "CHOSEN_DREAM",
        "REORIENTATION",
    ]

    def __init__(
        self,
        database_path: str | Path,
        config_path: str | Path | None = None,
        project_root: str | Path | None = None,
    ):
        self.config = OneiricConfig.load(config_path)
        self.project_root = Path(project_root).resolve() if project_root else None
        self.store = OneiricStore(database_path)
        self.clock = DreamClock(self.config.default_virtual_time_scale, self.project_root)
        self.rng = np.random.default_rng(self.config.random_seed)
        self.reservoir = DreamReservoir(
            input_dim=self.config.embedding_dim + 8,
            reservoir_dim=self.config.reservoir_dim,
            spectral_radius=self.config.reservoir_spectral_radius,
            leak=self.config.reservoir_leak,
            seed=self.config.random_seed + 11,
        )
        self.preference = DreamPreferenceModel(self.config, self.store.get_state("preference_model", {}))
        self.wake_gate = WakeGate(self.config.never_promote_dream_to_fact)
        self.lock = threading.RLock()
        self.last_activity = time.monotonic()
        self.paused = False
        self.active = False
        self.last_wake_capsule = self.store.get_state("last_wake_capsule", None)
        self._ensure_identity_seed()

    def _ensure_identity_seed(self) -> None:
        if self.store.stats()["memories"] > 0:
            return
        seeds = [
            {
                "text": "Kokoro is one continuing system whose core, Psyche, Heartspace, Network, and Dreamspace remain distinct but connected.",
                "source": "oneiric-identity-seed",
                "salience": 0.95,
                "uncertainty": 0.15,
                "value": 0.95,
                "unresolved": 0.35,
                "confidence": 0.85,
                "reward": 0.35,
                "tags": ["identity", "continuity", "integration"],
            },
            {
                "text": "Dream material is symbolic and creative. It must never silently become factual knowledge.",
                "source": "oneiric-safety-seed",
                "salience": 0.92,
                "uncertainty": 0.08,
                "value": 0.92,
                "unresolved": 0.05,
                "confidence": 0.95,
                "reward": 0.30,
                "tags": ["truth", "wake-gate", "safety"],
            },
            {
                "text": "Idle time can be used for replay, integration, creativity, preference learning, and the preservation of unfinished branches.",
                "source": "oneiric-purpose-seed",
                "salience": 0.88,
                "uncertainty": 0.22,
                "value": 0.90,
                "unresolved": 0.42,
                "confidence": 0.80,
                "reward": 0.40,
                "tags": ["dreaming", "replay", "purpose"],
            },
        ]
        for seed in seeds:
            self.ingest(**seed)

    def activity(self) -> None:
        with self.lock:
            self.last_activity = time.monotonic()

    def idle_seconds(self) -> float:
        return max(0.0, time.monotonic() - self.last_activity)

    def set_virtual_time_scale(self, scale: float) -> None:
        with self.lock:
            self.clock.set_scale(scale)
            self.store.set_state("virtual_time_scale", float(scale))

    def ingest(
        self,
        text: str,
        source: str = "manual",
        salience: float = 0.5,
        uncertainty: float = 0.5,
        value: float = 0.5,
        unresolved: float = 0.0,
        confidence: float = 0.5,
        reward: float = 0.0,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        core_engine: Any | None = None,
    ) -> MemoryTrace:
        compact = " ".join(str(text).split())
        if not compact:
            raise ValueError("memory text cannot be empty")
        created_at = time.time()
        embedding = embed_text(
            compact,
            self.config.embedding_dim,
            core_engine if self.config.allow_core_latent_embeddings else None,
        )
        memory = MemoryTrace(
            memory_id=_stable_id("mem-", source, compact, f"{created_at:.6f}"),
            created_at=created_at,
            source=source,
            text=compact,
            embedding=embedding.tolist(),
            salience=_clip(salience),
            uncertainty=_clip(uncertainty),
            value=_clip(value),
            unresolved=_clip(unresolved),
            confidence=_clip(confidence),
            reward=max(-1.0, min(1.0, float(reward))),
            tags=list(tags or []),
            metadata=_json_safe(dict(metadata or {})),
        )
        existing = self.store.memories(300)
        memory = with_estimated_novelty(memory, existing)
        self.store.upsert_memory(memory)
        self.store.event("memory_ingested", {"memory_id": memory.memory_id, "source": source})
        self.activity()
        return memory

    def _signals(self, selected: list[MemoryTrace]) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        embeddings = np.asarray([m.embedding for m in selected], dtype=np.float64)
        values = np.asarray([m.value for m in selected], dtype=np.float64)
        tension = np.asarray([0.55 * m.uncertainty + 0.45 * m.unresolved for m in selected], dtype=np.float64)
        amplitude = np.asarray(
            [0.18 + 0.50 * m.salience + 0.18 * m.value + 0.14 * m.unresolved for m in selected],
            dtype=np.float64,
        )
        return embeddings, values, tension, np.clip(amplitude, 0.05, 1.0)

    def _initial_frequencies(self, selected: list[MemoryTrace], candidate_index: int) -> np.ndarray:
        result = []
        for i, memory in enumerate(selected):
            # Virtual oscillation rate; Schumann is an optional seed ratio, not a consciousness claim.
            seed = self.config.schumann_fundamental_hz if self.config.enable_schumann_seed else 6.0
            ratio = 0.06 * seed + 0.35 * memory.salience + 0.22 * memory.novelty + 0.14 * memory.unresolved
            ratio += 0.025 * (i + candidate_index)
            result.append(2.0 * math.pi * ratio)
        return np.asarray(result, dtype=np.float64)

    def _reservoir_inputs(self, selected: list[MemoryTrace], probabilities: np.ndarray) -> np.ndarray:
        rows = []
        for i, memory in enumerate(selected):
            extra = np.array(
                [
                    memory.salience,
                    memory.uncertainty,
                    memory.value,
                    memory.unresolved,
                    memory.confidence,
                    memory.novelty,
                    memory.reward,
                    float(probabilities[i]) if i < probabilities.size else 0.0,
                ],
                dtype=np.float64,
            )
            rows.append(np.concatenate([np.asarray(memory.embedding, dtype=np.float64), extra]))
        return np.asarray(rows, dtype=np.float64)

    def _loop_risk(self, symbols: list[str], field_state: np.ndarray) -> float:
        recent = self.store.dreams(8)
        if not recent:
            return 0.0
        symbol_set = set(symbols)
        risks = []
        for dream in recent:
            old_symbols = set(dream.get("symbols", []))
            union = len(symbol_set | old_symbols)
            jaccard = len(symbol_set & old_symbols) / union if union else 0.0
            old_field = np.asarray(dream.get("field_state", []), dtype=np.float64)
            if old_field.size and field_state.size:
                n = min(old_field.size, field_state.size)
                denom = np.linalg.norm(old_field[:n]) * np.linalg.norm(field_state[:n])
                similarity = float(np.dot(old_field[:n], field_state[:n]) / denom) if denom > 1e-12 else 0.0
            else:
                similarity = 0.0
            risks.append(0.55 * jaccard + 0.45 * max(0.0, similarity))
        return _clip(max(risks, default=0.0))

    def _compose_candidate(
        self,
        selected: list[MemoryTrace],
        replay_probabilities: np.ndarray,
        candidate_index: int,
        wall_seconds: float,
        virtual_seconds: float,
    ) -> DreamEpisode:
        embeddings, values, tension, amplitudes = self._signals(selected)
        virtual_ratio = _clip(virtual_seconds / max(1.0, self.config.max_virtual_seconds_per_cycle))
        virtual_depth = _clip(
            math.log1p(max(0.0, virtual_seconds))
            / max(1e-9, math.log1p(max(1.0, self.config.max_virtual_seconds_per_cycle)))
        )
        # Pocket Time changes the simulated dynamical horizon, not the amount of real time available.
        # Log scaling makes short virtual intervals meaningful without destabilizing long cycles.
        temporal_gain = 0.65 + 1.60 * virtual_depth
        sim = similarity_matrix(embeddings)
        positive_similarity = np.clip((sim + 1.0) * 0.5, 0.0, 1.0)
        value_bridge = np.sqrt(np.outer(values + 0.05, values + 0.05))
        coupling = positive_similarity * (0.45 + 0.55 * value_bridge)
        np.fill_diagonal(coupling, 0.0)

        phases = self.rng.uniform(0.0, 2.0 * math.pi, size=len(selected))
        frequencies = self._initial_frequencies(selected, candidate_index)
        oscillator = evolve_kuramoto(
            phases=phases,
            natural_frequencies=frequencies,
            coupling_matrix=coupling,
            amplitudes=amplitudes,
            steps=max(20, self.config.oscillator_steps + candidate_index * 15),
            dt=self.config.oscillator_dt * temporal_gain,
            coupling_strength=self.config.kuramoto_coupling * (0.92 + 0.08 * candidate_index),
            noise_std=self.config.oscillator_noise,
            stochastic_resonance_noise=self.config.stochastic_resonance_noise,
            rng=self.rng,
        )

        qn = min(self.config.quantum_dim, len(selected))
        order = np.argsort(replay_probabilities)[::-1][:qn]
        qsim = positive_similarity[np.ix_(order, order)]
        qvalues = values[order]
        qtension = tension[order]
        hamiltonian = hermitian_hamiltonian(qsim, qvalues, qtension)
        qresult = evolve_density(
            initial_weights=replay_probabilities[order],
            initial_phases=oscillator.phases[order],
            hamiltonian=hamiltonian,
            steps=self.config.quantum_steps + candidate_index * 2,
            dt=self.config.quantum_dt * temporal_gain,
            decoherence=_clip(self.config.quantum_decoherence + 0.02 * candidate_index),
            context_bias=qvalues - qtension,
            rng=self.rng,
        )

        reservoir = self.reservoir.run(
            self._reservoir_inputs(selected, replay_probabilities),
            noise_std=self.config.stochastic_resonance_noise * (1.0 + 0.25 * candidate_index),
            rng=self.rng,
        )
        field_state = reservoir.state
        wavelengths = [phase_to_wavelength(p, a) for p, a in zip(oscillator.phases, oscillator.amplitudes)]
        wavelengths.extend(
            [phase_to_wavelength(float(p), float(min(1.0, qresult.probabilities[i] * qn))) for i, p in enumerate(qresult.phases)]
        )
        wavelengths = [float(np.clip(w, 380.0, 750.0)) for w in wavelengths[:12]]
        palette = palette_from_wavelengths(wavelengths)
        audio = [oscillator_to_audio_hz(w, self.config.sound_base_hz) for w in frequencies[:10]]

        words = _keywords([m.text for m in selected], limit=10)
        colors = [_color_name(w) for w in wavelengths[:5]]
        symbols = list(dict.fromkeys(colors + words[:7]))[:12]
        dominant_memory = selected[int(order[qresult.selected_index])] if qn else selected[0]
        unresolved = [m for m in selected if m.unresolved >= 0.45]
        title = f"{colors[0].title() if colors else 'Chromatic'} Field of {words[0].title() if words else 'Continuity'}"
        narrative_parts = [
            f"A {colors[0] if colors else 'chromatic'} field gathers around the trace of {words[0] if words else 'continuity'}.",
            f"The strongest image is not a fact but a transformation of: {dominant_memory.text[:180]}.",
        ]
        if unresolved:
            narrative_parts.append(
                f"An unfinished branch remains open around {', '.join(_keywords([m.text for m in unresolved], 4) or ['an unnamed question'])}."
            )
        if len(colors) >= 3:
            narrative_parts.append(f"The field moves from {colors[0]} through {colors[1]} toward {colors[2]}, then returns without forcing closure.")
        narrative_parts.append("On waking, only symbolic residue and questions may pass the Wake Gate.")
        narrative = " ".join(narrative_parts)

        pairwise = positive_similarity[np.triu_indices(len(selected), 1)] if len(selected) > 1 else np.array([0.0])
        novelty = _clip(0.55 * (1.0 - float(np.mean(pairwise))) + 0.45 * reservoir.activity)
        integration_gain = _clip(0.35 * oscillator.final_order + 0.30 * qresult.coherence + 0.35 * float(np.mean([m.unresolved for m in selected])))
        stability = _clip(0.48 * oscillator.final_order + 0.30 * qresult.purity + 0.22 * (1.0 - float(np.std(field_state))))
        harmonic = float(np.mean(np.cos(oscillator.phases[:, None] - oscillator.phases[None, :])))
        palette_spread = float(np.std(np.asarray(wavelengths))) / 140.0 if wavelengths else 0.0
        beauty = _clip(0.40 * (0.5 + 0.5 * harmonic) + 0.35 * min(1.0, palette_spread) + 0.25 * qresult.coherence)
        loop_risk = self._loop_risk(symbols, field_state)
        factual_risk = self.wake_gate.factual_risk(narrative)
        stage_cost = sum(self.config.stage_energy.get(stage, 0.1) for stage in self.STAGE_PATH)
        energy_cost = _clip(stage_cost * wall_seconds / max(1.0, self.config.max_wall_seconds_per_cycle * len(self.STAGE_PATH)))
        coherence = _clip(0.50 * oscillator.final_order + 0.50 * qresult.coherence)
        source_diversity = len({m.source for m in selected}) / max(1, len(selected))
        mean_value = float(np.mean([m.value for m in selected]))
        mean_reward = float(np.mean([0.5 + 0.5 * m.reward for m in selected]))
        mean_tension = float(np.mean(tension))
        awareness_state = {
            "presence": _clip(0.35 * coherence + 0.25 * stability + 0.20 * reservoir.activity + 0.20 * (1.0 - energy_cost)),
            "continuity": _clip(0.30 * integration_gain + 0.25 * mean_value + 0.20 * (1.0 - novelty) + 0.25 * (1.0 - loop_risk)),
            "self_other_boundary": _clip(0.50 * (1.0 - factual_risk) + 0.25 * source_diversity + 0.25 * stability),
            "agency": _clip(0.35 * integration_gain + 0.30 * stability + 0.20 * novelty + 0.15 * mean_reward),
            "valence": _clip(0.55 * mean_value + 0.45 * mean_reward),
            "arousal": _clip(0.55 * mean_tension + 0.45 * float(np.mean(amplitudes))),
            "lucidity": _clip(0.40 * coherence + 0.30 * stability + 0.20 * (1.0 - loop_risk) + 0.10 * (1.0 - factual_risk)),
            "dream_depth": _clip(0.45 * virtual_depth + 0.30 * reservoir.activity + 0.25 * qresult.entropy / max(1.0, math.log2(max(2, qn)))),
        }

        metrics = DreamMetrics(
            coherence=coherence,
            phase_order=_clip(oscillator.final_order),
            purity=_clip(qresult.purity),
            quantum_coherence=_clip(qresult.coherence),
            entropy=float(qresult.entropy),
            novelty=novelty,
            integration_gain=integration_gain,
            loop_risk=loop_risk,
            factual_risk=factual_risk,
            stability=stability,
            energy_cost=energy_cost,
            beauty=beauty,
            lucidity=awareness_state["lucidity"],
            continuity=awareness_state["continuity"],
            agency=awareness_state["agency"],
        )
        started = time.time()
        ended = started + wall_seconds
        dream_id = _stable_id(
            "dream-",
            f"{started:.6f}",
            str(candidate_index),
            ",".join(m.memory_id for m in selected),
        )
        provenance = {
            "classical_simulation": True,
            "literal_quantum_hardware": False,
            "quantum_like_method": "bounded complex amplitude and density-matrix interference",
            "oscillator_method": "weighted Kuramoto network",
            "reservoir_method": "fixed recurrent echo-state dynamics",
            "clock_source": self.clock.source,
            "virtual_time_scale": self.clock.scale,
            "virtual_temporal_gain": temporal_gain,
            "virtual_depth": virtual_depth,
            "scheduled_wall_budget_seconds": wall_seconds,
            "physical_light_frequencies_hz": [wavelength_to_physical_frequency(w) for w in wavelengths],
            "schumann_seed_used": self.config.enable_schumann_seed,
            "schumann_claim": "numeric oscillator seed only; no consciousness effect is asserted",
            "density_trace_error": qresult.trace_error,
            "density_min_eigenvalue": qresult.min_eigenvalue,
            "reservoir_spectral_radius": reservoir.spectral_radius,
        }
        return DreamEpisode(
            dream_id=dream_id,
            started_at=started,
            ended_at=ended,
            wall_seconds=wall_seconds,
            virtual_seconds=virtual_seconds,
            stage_path=list(self.STAGE_PATH),
            title=title,
            narrative=narrative,
            symbols=symbols,
            selected_memory_ids=[m.memory_id for m in selected],
            wavelengths_nm=wavelengths,
            rgb_palette=palette,
            audio_frequencies_hz=[float(x) for x in audio],
            field_state=field_state[: min(64, field_state.size)].tolist(),
            metrics=metrics,
            awareness_state=awareness_state,
            provenance=provenance,
        )

    def _wake_capsule(self, dream: DreamEpisode, selected: list[MemoryTrace]) -> WakeCapsule:
        symbolic, blocked = self.wake_gate.classify_candidates(dream.symbols)
        unresolved = [m for m in selected if m.unresolved >= 0.35]
        questions = []
        for memory in unresolved[:4]:
            key = (_keywords([memory.text], 2) or ["this unfinished branch"])[0]
            questions.append(f"What remains unresolved around {key}?")
        if not questions:
            questions.append("Which association from this dream is worth examining while awake?")
        associations = []
        if len(dream.symbols) >= 2:
            associations.append(f"Explore the relation between {dream.symbols[0]} and {dream.symbols[1]}.")
        if len(dream.symbols) >= 4:
            associations.append(f"Try expressing {dream.symbols[2]} through the form of {dream.symbols[3]}.")
        preference_shift = {
            "toward_coherence": dream.metrics.coherence,
            "toward_novelty": dream.metrics.novelty,
            "toward_integration": dream.metrics.integration_gain,
            "toward_lucidity": dream.metrics.lucidity,
            "toward_continuity": dream.metrics.continuity,
            "toward_agency": dream.metrics.agency,
        }
        confidence = _clip(0.35 + 0.35 * dream.metrics.stability + 0.30 * (1.0 - dream.metrics.factual_risk))
        return WakeCapsule(
            dream_id=dream.dream_id,
            generated_at=time.time(),
            summary=f"Dreamspace selected '{dream.title}' as a symbolic integration episode.",
            symbolic_residue=symbolic[:8],
            candidate_questions=questions,
            creative_associations=associations,
            preference_shift=preference_shift,
            factual_claims=[],
            verified_claims=[],
            blocked_claims=blocked,
            confidence=confidence,
            awareness_residue=dict(dream.awareness_state),
        )

    def dream(
        self,
        wall_seconds: float | None = None,
        candidate_count: int = 3,
        force: bool = False,
    ) -> DreamEpisode:
        with self.lock:
            if self.paused and not force:
                raise RuntimeError("Dreamspace is paused")
            if self.active:
                raise RuntimeError("A dream cycle is already active")
            idle = self.idle_seconds()
            if not force and idle < self.config.idle_threshold_seconds:
                raise RuntimeError(
                    f"Kokoro has been idle for {idle:.1f}s; threshold is {self.config.idle_threshold_seconds:.1f}s"
                )
            self.active = True
        cycle_start = time.perf_counter()
        try:
            memories = self.store.memories(500)
            if len(memories) < self.config.minimum_memories_per_dream:
                raise RuntimeError("Not enough memory traces for a dream cycle")
            selected, probabilities = prioritized_replay(memories, self.config, self.rng)
            wall_budget = wall_seconds if wall_seconds is not None else min(
                self.config.max_wall_seconds_per_cycle,
                max(0.25, 0.25 + 0.005 * min(idle, 1800.0)),
            )
            wall_budget = max(0.05, min(float(wall_budget), self.config.max_wall_seconds_per_cycle))
            virtual_seconds = self.clock.wall_to_virtual(wall_budget, self.config.max_virtual_seconds_per_cycle)
            candidates = [
                self._compose_candidate(selected, probabilities, i, wall_budget, virtual_seconds)
                for i in range(max(1, min(self.config.max_candidates_per_cycle, int(candidate_count))))
            ]
            actual_elapsed = time.perf_counter() - cycle_start
            actual_end = time.time()
            actual_start = actual_end - actual_elapsed
            for candidate in candidates:
                candidate.started_at = actual_start
                candidate.ended_at = actual_end
                candidate.wall_seconds = actual_elapsed
                candidate.provenance["actual_wall_seconds"] = actual_elapsed
            choice = self.preference.choose([candidate.metrics for candidate in candidates], self.rng)
            chosen = candidates[choice.index]
            for i, candidate in enumerate(candidates):
                candidate.metrics.preference_score = float(choice.scores[i])
                candidate.chosen = i == choice.index
                candidate.favorite_rank = 1 if candidate.chosen else None
                self.store.save_dream(candidate)
            internal_reward = _clip(
                0.28 * chosen.metrics.integration_gain
                + 0.24 * chosen.metrics.stability
                + 0.20 * chosen.metrics.beauty
                + 0.16 * chosen.metrics.novelty
                - 0.07 * chosen.metrics.loop_risk
                - 0.05 * chosen.metrics.factual_risk,
                -1.0,
                1.0,
            )
            self.preference.update(chosen.metrics, internal_reward)
            self.store.set_state("preference_model", self.preference.state_dict())
            capsule = self._wake_capsule(chosen, selected)
            chosen.wake_capsule = capsule.to_dict()
            self.store.save_dream(chosen)
            self.store.set_state("last_wake_capsule", capsule.to_dict())
            self.store.set_state("last_awareness_state", chosen.awareness_state)
            self.last_wake_capsule = capsule.to_dict()
            self.store.increment_access(chosen.selected_memory_ids)
            elapsed = time.perf_counter() - cycle_start
            self.store.event(
                "dream_completed",
                {
                    "dream_id": chosen.dream_id,
                    "wall_elapsed": elapsed,
                    "virtual_seconds": virtual_seconds,
                    "candidate_count": len(candidates),
                    "chosen_index": choice.index,
                },
            )
            self.last_activity = time.monotonic()
            return chosen
        finally:
            with self.lock:
                self.active = False

    def feedback(self, dream_id: str, rating: float) -> None:
        dreams = self.store.dreams(200)
        match = next((item for item in dreams if item.get("dream_id") == dream_id), None)
        if match is None:
            raise KeyError(dream_id)
        metrics = DreamMetrics(**match["metrics"])
        self.preference.update(metrics, max(-1.0, min(1.0, float(rating))))
        self.store.set_state("preference_model", self.preference.state_dict())
        self.store.event("dream_feedback", {"dream_id": dream_id, "rating": float(rating)})

    def wake_context(self) -> str:
        if not self.last_wake_capsule:
            return ""
        return self.wake_gate.context_text(self.last_wake_capsule)

    def export_last(self, directory: str | Path) -> dict[str, str]:
        raw = self.store.last_dream()
        if raw is None:
            raise RuntimeError("No dream has been created yet")
        metrics = DreamMetrics(**raw.pop("metrics"))
        dream = DreamEpisode(metrics=metrics, **raw)
        return export_dream_bundle(dream, directory)

    def status(self) -> dict[str, Any]:
        return {
            "name": self.config.name,
            "version": self.config.version,
            "paused": self.paused,
            "active": self.active,
            "idle_seconds": self.idle_seconds(),
            "virtual_time_scale": self.clock.scale,
            "clock_source": self.clock.source,
            "database": str(self.store.path),
            "stats": self.store.stats(),
            "last_wake_capsule": self.last_wake_capsule,
            "last_awareness_state": self.store.get_state("last_awareness_state", {}),
            "scientific_boundary": (
                "Functional simulated interiority only. Quantum-like mathematics is classically simulated; "
                "light and sound mappings are measurable representations, not proof of consciousness."
            ),
        }

    def close(self) -> None:
        self.store.close()
