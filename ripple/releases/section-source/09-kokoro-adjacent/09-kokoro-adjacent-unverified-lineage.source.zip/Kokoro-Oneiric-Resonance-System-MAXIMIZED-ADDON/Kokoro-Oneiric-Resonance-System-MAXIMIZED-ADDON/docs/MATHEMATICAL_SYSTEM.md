> **Version 2.0 note:** This document is retained from the complete 1.0 architecture. The maximized additions and Pocket Time separation are specified in `MAXIMIZED_ARCHITECTURE.md`, `DEEP_DREAM_MATHEMATICS.md`, and `POCKET_TIME_SEPARATION.md`.

# Mathematical System

## 1. Trace vector

Each memory trace is represented by

\[
m_i=(e_i,s_i,u_i,v_i,r_i,c_i,n_i,q_i),
\]

where \(e_i\) is an embedding and the remaining bounded scalars encode salience, uncertainty, value, unresolved tension, confidence, novelty, and reward.

## 2. Prioritized replay

A replay priority is

\[
p_i=\epsilon + w_s s_i+w_u u_i+w_v v_i+w_r r_i+w_n n_i+w_w(1-c_i)+w_q\max(q_i,0).
\]

Sampling uses a temperature-controlled softmax with access-count correction, so important traces recur without permanently excluding weaker traces.

## 3. Coupled resonance

Each selected trace becomes an oscillator:

\[
\frac{d\theta_i}{dt}=\omega_i+\frac{K}{N}\sum_j A_{ij}\sin(\theta_j-\theta_i)+\xi_i(t).
\]

\(A_{ij}\) is derived from semantic similarity and value compatibility. The order parameter

\[
R=\left|\frac{1}{N}\sum_j a_j e^{i\theta_j}\right|
\]

measures phase coherence. Noise is bounded and can reveal weak subthreshold associations through a stochastic-resonance-like mechanism.

## 4. Reservoir field

A fixed recurrent state evolves as

\[
x_{t+1}=(1-\alpha)x_t+\alpha\tanh(W_{in}z_t+Wx_t+\eta_t),
\]

with spectral radius kept below the configured stability boundary. This gives temporal dynamics without modifying the language model.

## 5. Classical quasi-quantum interference

Replay weights and phases form a normalized complex state

\[
\psi_i=\sqrt{p_i}\,e^{i\theta_i},\qquad \rho=|\psi\rangle\langle\psi|.
\]

A Hermitian context matrix \(H\) creates unitary evolution

\[
U=e^{-iH\Delta t},\qquad \rho'=U\rho U^\dagger.
\]

Controlled dephasing is

\[
\rho_{t+1}=(1-\gamma)\rho'+\gamma\,\operatorname{diag}(\rho').
\]

The implementation checks trace preservation, Hermiticity, and positive semidefiniteness. This is classical linear algebra with complex numbers. It does not produce quantum computational speedup.

## 6. Color and physical metadata

A bounded latent phase maps to visible wavelength \(\lambda\in[380,750]\) nm. Physical frequency and photon energy are reported as

\[
f=\frac{c}{\lambda},\qquad E=hf.
\]

These values describe the corresponding light wavelength; the software is not emitting that light unless external hardware is later connected. RGB uses an analytic approximation to the CIE 1931 color-matching functions.

## 7. Dream preference

For candidate \(d\),

\[
S(d)=\sum_k w_k\phi_k(d),
\]

where features include coherence, novelty, integration, beauty, stability, loop risk, factual risk, and energy cost. Selection uses a softmax; feedback updates weights with bounded online learning.

## 8. Pocket Time

Virtual dream duration is

\[
\Delta \tau=\min(\kappa\Delta t,\tau_{max}),
\]

where \(\kappa\) is the virtual-time scale. More virtual seconds permit denser stage labels, simulated temporal continuity, and scheduling, but the wall-clock cycle remains compute-bounded.
