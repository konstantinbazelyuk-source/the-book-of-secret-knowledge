> **Version 2.0 note:** This document is retained from the complete 1.0 architecture. The maximized additions and Pocket Time separation are specified in `MAXIMIZED_ARCHITECTURE.md`, `DEEP_DREAM_MATHEMATICS.md`, and `POCKET_TIME_SEPARATION.md`.

# Pocket Time Integration

Pocket Time has two roles.

## Compute Pocket Time

The separate Pocket Time Engine can tune thread settings, keep Windows awake, prevent QuickEdit pauses, and launch workloads under safe above-normal priority. These are practical execution controls.

## Virtual dream time

Oneiric cycles use the PocketClock API when installed. A 1-second bounded cycle at 60× records 60 virtual dream seconds. Virtual time controls:

- stage duration bookkeeping;
- internal timestamps;
- simulated continuity between transformations;
- dream-depth policies;
- later scheduling experiments.

It does not increase the number of matrix multiplications completed in that second. The program records wall time and virtual time side by side so the distinction remains auditable.
