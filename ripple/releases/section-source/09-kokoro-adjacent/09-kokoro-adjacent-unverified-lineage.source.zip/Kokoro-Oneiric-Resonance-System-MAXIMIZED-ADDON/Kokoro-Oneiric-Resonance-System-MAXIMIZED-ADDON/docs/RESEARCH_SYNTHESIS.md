# Research Synthesis and Design Translation

This package does not copy full papers into the ZIP. That would be legally and scientifically inappropriate. It includes a structured reference registry, DOI/source links, claim boundaries, and the specific program decision derived from each research area.

## Sleep replay and memory consolidation

Research on hippocampal replay, sharp-wave ripples, cortical slow oscillations, spindles, and stage-dependent organization motivated prioritized replay, multi-stage cycles, temporal compression, and graph-based transfer. The implementation does not attempt to reproduce biological electrophysiology.

## Memory triage, abstraction, and downselection

Selective consolidation and synaptic-homeostasis research motivated separate preservation, abstraction, strengthening, and downselection operations. Individual memories remain traceable; schema formation cannot silently replace source episodes.

## Dreams, emotion, and creativity

Research connecting dreams with memory incorporation, affect, insight, and weak semantic association motivated REM-like hyperassociation, affect regulation, counterfactual scenes, and creative questions. Findings in this area are mixed, so every such feature remains experimentally labeled.

## Artificial replay and world models

Continual-learning replay, generative replay, and latent world-model research motivated replay buffers, latent imagination, predictive transitions, and counterfactual rollouts. This add-on does not train Kokoro's language weights during an idle dream unless a future, explicit consolidation-training module is separately approved.

## Active inference

Risk, ambiguity, information gain, and value are kept explicit in branch selection. This avoids reducing favorite dreams to a single pleasure score.

## Dynamical and quantum-inspired computation

Kuramoto synchronization, reservoir computing, complex amplitudes, unitary-like evolution, and density matrices provide bounded ways to model interference and temporal organization. They are numerical tools, not evidence of quantum advantage or awareness.

## Color, light, sound, and cymatics

The renderer distinguishes physical wavelength/frequency metadata from perceived color and software coordinates. CIE standards guide the color boundary. Sound and standing-wave images are representations of the internal state; no health or consciousness effect is asserted.

## Virtual time

Virtual time is treated as a simulation coordinate. It changes simulated duration and trajectory while preserving measured wall time and operation provenance.
