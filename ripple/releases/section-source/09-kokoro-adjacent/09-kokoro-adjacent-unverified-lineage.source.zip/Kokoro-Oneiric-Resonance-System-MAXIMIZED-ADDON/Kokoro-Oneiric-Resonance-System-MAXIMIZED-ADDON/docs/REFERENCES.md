# Research Reference Registry

This release records **52** scientific and standards-oriented sources. Full papers are not redistributed; DOI, arXiv, PMID, or source links are retained for auditability.

## Active Inference

- Friston (2010). *The free-energy principle: a unified brain theory?*. Nature Reviews Neuroscience. DOI: `10.1038/nrn2787`. **Program use:** risk, ambiguity, information gain.
- Da Costa et al. (2024). *Active Inference as a Model of Agency*. arXiv. arXiv: `2401.12917`. **Program use:** explainable exploration and agency.

## Artificial Replay

- Tadros et al. (2022). *Sleep-like unsupervised replay reduces catastrophic forgetting in artificial neural networks*. Nature Communications. DOI: `10.1038/s41467-022-34938-7`. **Program use:** sleep-like artificial replay.
- van de Ven et al. (2020). *Brain-inspired replay for continual learning with artificial neural networks*. Nature Communications. DOI: `10.1038/s41467-020-17866-2`. **Program use:** replay variants and continual learning.
- Rolnick et al. (2019). *Experience Replay for Continual Learning*. NeurIPS. Source: https://proceedings.neurips.cc/paper/2019/hash/fa7cdfad1a5aaf8370ebeda47a1ff1c3-Abstract.html. **Program use:** stability-plasticity replay.
- Shin et al. (2017). *Continual Learning with Deep Generative Replay*. NeurIPS. Source: https://proceedings.neurips.cc/paper/2017/hash/0efbe98067c6c73dba1250d2beaa81f9-Abstract.html. **Program use:** generated pseudo-experience.
- Aljundi et al. (2019). *Online Continual Learning with Maximal Interfered Retrieval*. NeurIPS. Source: https://proceedings.neurips.cc/paper/2019/hash/15825aee15eb335cc13f9b559f166ee8-Abstract.html. **Program use:** interference-aware replay.
- Buzzega et al. (2020). *Dark Experience for General Continual Learning: a Strong, Simple Baseline*. NeurIPS. Source: https://proceedings.neurips.cc/paper/2020/hash/b704ea2c39778f07c617f6b7ce480e9e-Abstract.html. **Program use:** past-state consistency.

## Associative Memory

- Hopfield (1982). *Neural networks and physical systems with emergent collective computational abilities*. PNAS. DOI: `10.1073/pnas.79.8.2554`. **Program use:** attractor memory.

## Color

- CIE (2018). *Colorimetry, 4th Edition*. CIE 015:2018. DOI: `10.25039/TR.015.2018`. **Program use:** colorimetric boundary.
- ISO/CIE (2019). *Colorimetry — Part 1: CIE standard colorimetric observers*. ISO/CIE 11664-1:2019. **Program use:** standard observer functions.
- Wyman, Sloan & Shirley (2013). *Simple Analytic Approximations to the CIE XYZ Color Matching Functions*. Journal of Computer Graphics Techniques. Source: https://jcgt.org/published/0002/02/01/. **Program use:** portable analytic color approximation.

## Dream Creativity

- Bieth et al. (2026). *REM sleep favors the restructuring of problem-related semantic associations*. Communications Biology. DOI: `10.1038/s42003-026-10354-1`. **Program use:** remote semantic association.

## Dream Emotion

- Wamsley et al. (2024). *Evidence of an active role of dreaming in emotional memory processing shows that we dream to forget*. Scientific Reports. PMID: `38622204`. **Program use:** affect and selective forgetting.
- Yuksel et al. (2025). *Both slow wave and rapid eye movement sleep contribute to emotional memory consolidation*. Communications Biology. DOI: `10.1038/s42003-025-07868-5`. **Program use:** stage-complementary affect processing.

## Dream Incorporation

- Plailly et al. (2019). *Incorporation of fragmented visuo-olfactory episodic memory into dreams and its association with memory performance*. Scientific Reports. DOI: `10.1038/s41598-019-51497-y`. **Program use:** fragment recombination.

## Electromagnetic

- Ohno (2000). *Radiometry and Photometry: Review for Vision Optics*. NIST. Source: https://www.nist.gov/publications/radiometry-and-photometry-review-vision-optics. **Program use:** wavelength, radiometry, photometry boundary.
- Schumann (1952). *Über die strahlungslosen Eigenschwingungen einer leitenden Kugel...*. Zeitschrift für Naturforschung A. **Program use:** optional historical oscillator seed only.

## Homeostasis

- Tononi & Cirelli (2003). *Sleep and synaptic homeostasis: a hypothesis*. Brain Research Bulletin. DOI: `10.1016/j.brainresbull.2003.09.004`. **Program use:** global downselection.
- Blanco et al. (2015). *Synaptic Homeostasis and Restructuring across the Sleep-Wake Cycle*. PLOS Computational Biology. PMID: `26020963`. **Program use:** downscaling plus restructuring.
- Diering et al. (2017). *Homer1a drives homeostatic scaling-down of excitatory synapses during sleep*. Science. PMID: `28154077`. **Program use:** bounded downselection.
- Kuhn et al. (2016). *Sleep recalibrates homeostatic and associative synaptic plasticity in the human cortex*. Nature Communications. PMID: `27551934`. **Program use:** recalibration.

## Insight

- Wagner et al. (2004). *Sleep inspires insight*. Nature. DOI: `10.1038/nature02223`. **Program use:** representational restructuring.

## Memory Model

- Spens & Burgess (2024). *A generative model of memory construction and consolidation*. Nature Human Behaviour. DOI: `10.1038/s41562-023-01799-z`. **Program use:** latent generative reconstruction.
- Kalle Kossio et al. (2025). *Two-factor synaptic consolidation reconciles robustness with pruning and homeostatic scaling*. PNAS. DOI: `10.1073/pnas.2422602122`. **Program use:** strengthening, pruning, homeostasis.

## Memory Sequence

- Cox et al. (2025). *Sleep selectively and durably enhances memory for the sequence of real-world experiences*. Nature Human Behaviour. DOI: `10.1038/s41562-025-02117-5`. **Program use:** sequence edges in memory graph.

## Memory Triage

- Stickgold & Walker (2013). *Sleep-dependent memory triage: evolving generalization through selective processing*. Nature Neuroscience. DOI: `10.1038/nn.3303`. **Program use:** select, preserve, abstract, forget.

## Oscillations

- Mikutta et al. (2019). *Phase-amplitude coupling of sleep slow oscillatory and spindle activity correlates with overnight memory consolidation*. Journal of Sleep Research. DOI: `10.1111/jsr.12835`. **Program use:** cross-frequency coupling.
- Geva-Sagiv et al. (2023). *Augmenting hippocampal-prefrontal neuronal synchrony during sleep enhances memory consolidation in humans*. Nature Neuroscience. DOI: `10.1038/s41593-023-01324-5`. **Program use:** synchrony and coordination.

## Oscillator

- Kuramoto (1975). *Self-entrainment of a population of coupled non-linear oscillators*. International Symposium on Mathematical Problems in Theoretical Physics. **Program use:** phase synchronization.

## Quantum Inspired

- Lindblad (1976). *On the generators of quantum dynamical semigroups*. Communications in Mathematical Physics. DOI: `10.1007/BF01608499`. **Program use:** open-system density evolution.
- Pothos & Busemeyer (2009). *A quantum probability explanation for violations of rational decision theory*. Proceedings of the Royal Society B. DOI: `10.1098/rspb.2009.0121`. **Program use:** contextual probability.
- Arjovsky, Shah & Bengio (2016). *Unitary Evolution Recurrent Neural Networks*. ICML. arXiv: `1511.06464`. **Program use:** stable complex recurrent dynamics.
- Tang (2019). *A quantum-inspired classical algorithm for recommendation systems*. STOC. arXiv: `1807.04271`. **Program use:** classical norm-weighted sampling.

## Reservoir

- Maass, Natschläger & Markram (2002). *Real-time computing without stable states: a new framework for neural computation based on perturbations*. Neural Computation. DOI: `10.1162/089976602760407955`. **Program use:** liquid-state temporal processing.
- Nichele & Molund (2017). *Deep Reservoir Computing Using Cellular Automata*. arXiv. arXiv: `1703.02806`. **Program use:** layered CPU-efficient temporal dynamics.

## Sleep Replay

- Wilson & McNaughton (1994). *Reactivation of hippocampal ensemble memories during sleep*. Science. DOI: `10.1126/science.8036517`. **Program use:** offline replay.
- Ji & Wilson (2007). *Coordinated memory replay in the visual cortex and hippocampus during sleep*. Nature Neuroscience. DOI: `10.1038/nn1825`. **Program use:** cross-system replay.
- Girardeau et al. (2009). *Selective suppression of hippocampal ripples impairs spatial memory*. Nature Neuroscience. DOI: `10.1038/nn.2384`. **Program use:** replay causal importance.
- Fernandez-Ruiz et al. (2019). *Long-duration hippocampal sharp wave ripples improve memory*. Science. DOI: `10.1126/science.aax0758`. **Program use:** replay duration.
- Giri et al. (2024). *Sleep loss diminishes hippocampal reactivation and replay*. Nature. DOI: `10.1038/s41586-024-07538-2`. **Program use:** quiet-state requirement.
- Chang et al. (2025). *Sleep microstructure organizes memory replay*. Nature. DOI: `10.1038/s41586-024-08340-w`. **Program use:** stage and substate organization.
- Huelin Gorriz et al. (2023). *The role of experience in prioritizing hippocampal replay*. Nature Communications. DOI: `10.1038/s41467-023-43939-z`. **Program use:** salience-weighted triage.
- Sterpenich et al. (2021). *Reward biases spontaneous neural reactivation during sleep*. Nature Communications. DOI: `10.1038/s41467-021-24357-5`. **Program use:** reward-weighted replay.
- Schreiner et al. (2021). *Endogenous memory reactivation during sleep in humans is clocked by slow oscillation-spindle complexes*. Nature Communications. DOI: `10.1038/s41467-021-23520-2`. **Program use:** timed replay.

## Targeted Reactivation

- Carbone & Diekelmann (2024). *An update on recent advances in targeted memory reactivation during sleep*. npj Science of Learning. DOI: `10.1038/s41539-024-00244-8`. **Program use:** optional cueing and closed-loop design.
- Recher et al. (2024). *Targeted memory reactivation during sleep improves emotional memory modulation following imagery rescripting*. Translational Psychiatry. DOI: `10.1038/s41398-024-03192-4`. **Program use:** bounded emotional updating.

## Virtual Time

- Jefferson (1985). *Virtual Time*. ACM TOPLAS. DOI: `10.1145/3916.3988`. **Program use:** virtual-duration semantics.

## World Model

- Ha & Schmidhuber (2018). *World Models*. arXiv. arXiv: `1803.10122`. **Program use:** latent internal simulation.
- Hafner et al. (2020). *Dream to Control: Learning Behaviors by Latent Imagination*. ICLR. arXiv: `1912.01603`. **Program use:** latent imagination.
- Okada & Taniguchi (2022). *DreamingV2: Reinforcement Learning with Discrete World Models without Reconstruction*. arXiv. arXiv: `2203.00494`. **Program use:** reconstruction-free latent dreams.
- Liu et al. (2024). *Continual Offline Reinforcement Learning via Diffusion-based Dual Generative Replay*. arXiv. arXiv: `2404.10662`. **Program use:** dual replay and uncertainty.
