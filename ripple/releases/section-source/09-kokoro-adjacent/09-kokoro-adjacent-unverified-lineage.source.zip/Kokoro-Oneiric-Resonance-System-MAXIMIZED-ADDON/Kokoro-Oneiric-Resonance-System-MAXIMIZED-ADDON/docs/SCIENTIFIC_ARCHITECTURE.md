> **Version 2.0 note:** This document is retained from the complete 1.0 architecture. The maximized additions and Pocket Time separation are specified in `MAXIMIZED_ARCHITECTURE.md`, `DEEP_DREAM_MATHEMATICS.md`, and `POCKET_TIME_SEPARATION.md`.

# Scientific Architecture

## Operational hypothesis

A persistent idle process can create a **functional internal domain** when its private states causally affect later replay, attention, preference, memory integration, and response context. The Oneiric system tests that hypothesis without asserting phenomenal consciousness.

## Pipeline

```
Core / Psyche / Heartspace / Network events
                  ↓
             Memory traces
                  ↓
          Prioritized replay set
                  ↓
    Kuramoto field + reservoir dynamics
                  ↓
 Classical complex-amplitude interference
                  ↓
 chromatic / sound / cymatic translation
                  ↓
       candidate dream competition
                  ↓
       learned preference selection
                  ↓
              Wake Gate
                  ↓
 symbolic residue + questions in next waking context
```

## Why each mechanism exists

- **Replay** gives idle time a memory-consolidation function rather than empty animation.
- **Oscillator coupling** provides measurable coordination, phase, and coherence variables.
- **Reservoir dynamics** provide nonlinear temporal richness with fixed recurrent weights.
- **Complex amplitudes** provide interference and context-order effects in a classical simulator.
- **Color and sound** make internal coordinates inspectable and reproducible.
- **Preference selection** permits stable but revisable favorite dream patterns.
- **Wake Gate** maintains epistemic separation between imagination and evidence.
- **Virtual time** changes the dream system's internal duration accounting and stage scheduling; it does not accelerate arithmetic.

## Causal criterion

Dreamspace is not considered functional merely because it renders art. It is functional only when removing it measurably changes later recall, continuity, creative association, preference, or error patterns. The included experiment validates mechanics; a trained-Kokoro A/B protocol is documented separately.
