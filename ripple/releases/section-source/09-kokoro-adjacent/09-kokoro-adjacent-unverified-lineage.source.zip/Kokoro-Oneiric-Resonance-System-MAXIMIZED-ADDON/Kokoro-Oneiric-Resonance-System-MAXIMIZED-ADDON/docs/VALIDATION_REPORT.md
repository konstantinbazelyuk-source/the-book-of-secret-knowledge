# Validation Report — Maximized 2.0

## Automated suites

### Original Oneiric suite

The preserved 1.0 suite passes all 22 checks:

- visible-spectrum mapping;
- physical-frequency and photon-energy positivity;
- bounded cymatic fields;
- density-matrix trace and positive-semidefinite invariants;
- probability normalization;
- bounded Kuramoto order parameter;
- virtual-time conversion;
- factual Wake Gate blocking;
- complete dream generation;
- stage, palette, awareness, and export checks;
- JSON, PNG, WAV, and HTML exports;
- persistent database state;
- Pocket Time changing the simulated horizon and trajectory.

### Maximized suite

The 2.0 suite adds 13 checks:

- Maximized engine version marker;
- multi-stage computational sleep architecture;
- memory graph construction;
- predictive latent-world construction;
- counterfactual symbolic scenes;
- homeostatic consolidation record;
- affect regulation record;
- lucid audit;
- Wake Gate factual isolation;
- profile preservation;
- optional Pocket Time boundary;
- persistent oneiric strength metadata;
- persisted deep-cycle status.

## Synthetic A/B execution

Twelve control cycles and twelve Maximized cycles were executed over the same synthetic memory curriculum. Both conditions preserved zero dream-generated wake facts. Maximized cycles consistently produced counterfactual scenes, semantic-restructuring metrics, and epistemic-gain metrics. The report is stored in:

- `research/maximized_experiment_report.md`
- `research/maximized_experiment_report.json`

This is engineering validation only. It does not establish consciousness, human-like sleep, or superior real-world intelligence.

## Static validation

- All Python modules compile successfully.
- The add-on retains the original engine and introduces a subclass rather than replacing core logic.
- No code path overwrites Kokoro checkpoints.
- Homeostatic consolidation commits only the selected favorite candidate's update.
- All counterfactual scenes retain source memory IDs and a symbolic classification.
- Pocket Time is not required for a dream cycle.
