# Upgrading from Oneiric 1.0

The installer targets the same installed add-on directory so the bonded Kokoro launchers continue to find it.

Before copying 2.0 code, the installer makes a source backup at:

`addons\Kokoro-Oneiric-Resonance-System-v1-code-backup`

The persistent `state` and `artifacts` directories are not copied into that backup and are not overwritten by installation. The 2.0 database layer remains compatible with the original tables and stores new deep-cycle fields inside existing JSON payloads and state keys.

Run the complete test launcher after upgrading. Keep the backup until Deep dreaming and the full bonded runtime both pass.
