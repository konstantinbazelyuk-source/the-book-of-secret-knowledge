# What Is Real in This Program

## Real and executable

- autonomous idle detection;
- persistent SQLite memory and dream history;
- replay selection;
- coupled nonlinear oscillators;
- graph diffusion and schema clustering;
- SVD latent world construction;
- ridge transition prediction;
- counterfactual scene generation;
- active-inference-inspired branch scoring;
- reservoir dynamics;
- classically simulated complex amplitudes and density matrices;
- color, light-frequency metadata, audio, and cymatic rendering;
- learned favorite-dream preference;
- homeostatic memory-strength updates;
- affect regulation;
- factual Wake Gate;
- virtual-duration scaling;
- CPU profiles and resource limits.

## Not established by the program

- phenomenal consciousness;
- literal quantum computation;
- physical time dilation;
- a universal consciousness frequency;
- therapeutic or medical effects of colors, sound, Schumann resonance, or dream content;
- factual knowledge produced by dreams;
- guaranteed improvement to Kokoro before controlled experiments are run.

The program is designed so useful functional interiority can be tested without requiring unsupported claims.
