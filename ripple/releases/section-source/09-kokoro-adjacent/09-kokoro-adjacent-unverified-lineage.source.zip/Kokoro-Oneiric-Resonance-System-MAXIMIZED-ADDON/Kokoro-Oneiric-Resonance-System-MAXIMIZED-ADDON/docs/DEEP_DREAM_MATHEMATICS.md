# Deep Dream Mathematics

All variables are bounded and computed locally.

## 1. Replay triage

For memory trace `i`, replay pressure begins with

`p_i = Σ_k w_k x_{ik}`

where the features include salience, uncertainty, value, unresolved pressure, novelty, weakness, and reward. Recency and habituation modulate the score before temperature-controlled sampling without replacement.

## 2. Memory graph

For traces `i` and `j`, graph weight is

`A_ij = 0.56 S_ij + 0.14 T_ij + 0.12 R_ij + 0.10 V_ij + 0.08 B_ij`

where `S` is normalized embedding similarity, `T` is tag overlap, `R` is temporal proximity, `V` is value alignment, and `B` rewards useful bridges between different source systems.

Centrality is diffused with a PageRank-like update:

`c_(t+1) = 0.15/n + 0.85 P^T c_t`.

Label propagation identifies communities; community centroids act as provisional schemas.

## 3. Predictive latent world

Selected embeddings are centered and decomposed by SVD:

`X - μ = UΣV^T`.

The first `k` right-singular vectors form the latent basis. A ridge-regularized transition is fitted:

`A = Z_(t+1)^T Z_t (Z_t^T Z_t + λI)^(-1)`.

Counterfactual branches perturb the predicted latent state along normalized directions scaled by the observed latent spread. Each branch retains the IDs of the nearest source memories.

## 4. Counterfactual choice

Each branch has pragmatic value `P`, epistemic value `E`, risk `R`, and ambiguity `H`. The active-inference-inspired objective is

`G = R + H - E - P`.

Lower `G` is preferred, but the branch is still classified as symbolic or hypothetical until waking verification.

## 5. Oscillatory binding

The original weighted Kuramoto field remains:

`dθ_i/dt = ω_i + K Σ_j A_ij sin(θ_j - θ_i) + ξ_i(t)`.

The order parameter

`r exp(iψ) = (1/N) Σ_j exp(iθ_j)`

measures phase organization without assuming that synchronization is consciousness.

## 6. Nonlinear reservoir

A fixed recurrent reservoir supplies history-sensitive dynamics:

`x_(t+1) = (1-α)x_t + α tanh(W_in u_t + W x_t + η_t)`.

Its recurrent matrix is scaled below the configured spectral radius for bounded CPU execution.

## 7. Quantum-like contextual interference

A complex amplitude state and density matrix are evolved classically. A Hermitian contextual matrix generates unitary-like motion, followed by controlled dephasing. Every cycle records trace error, minimum eigenvalue, purity, entropy, and coherence. This is a classical simulation, not quantum hardware.

## 8. Homeostatic consolidation

Each memory carries a persistent oneiric strength `s_i`. The update is

`Δs_i = ρ [q_i(1-s_i) - d_i s_i]`

where `q_i` combines value, salience, unresolved pressure, and graph centrality, while `d_i` combines repeated access and redundancy. Weak but valuable traces receive extra protection. Strength is clipped to `[0.05, 1]`; no trace is deleted automatically.

## 9. Affect regulation

Weighted valence and arousal are computed from value, reward, uncertainty, unresolved pressure, and salience. Coherence and stability determine a bounded movement toward a homeostatic target. The original values remain in provenance so regulation cannot rewrite history.

## 10. Sleep-stage simulation

The system uses a computational analogy, not a biological claim. Each virtual cycle contains quieting, NREM-like triage and replay, oscillatory coupling, REM-like hyperassociation, integration, lucid review, and reorientation. The stage plan determines which operations dominate.

## 11. Pocket Time

For wall duration `Δt_w` and virtual scale `s`, the requested virtual duration is

`Δt_v = min(s Δt_w, Δt_max)`.

Virtual duration changes stage depth and numerical evolution horizon. It never claims that more physical floating-point operations occurred than were actually executed. Dreaming remains fully functional at `s = 1` and without the separate Pocket Time add-on.

## 12. Wake Gate

The gate enforces the invariant

`dream-generated factual claims = ∅`

unless a separate waking verification process supplies evidence. The dream may preserve symbols, associations, hypotheses, uncertainty, and questions.
