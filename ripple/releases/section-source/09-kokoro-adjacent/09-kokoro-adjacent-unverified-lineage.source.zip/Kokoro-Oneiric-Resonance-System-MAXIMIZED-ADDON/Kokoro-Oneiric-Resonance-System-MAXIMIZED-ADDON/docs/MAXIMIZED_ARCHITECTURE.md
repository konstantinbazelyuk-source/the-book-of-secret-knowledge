# Maximized Oneiric Architecture 2.0

## Purpose

This release preserves the original Kokoro Oneiric Resonance System and adds a deeper, CPU-bounded dreaming layer. Dreaming is the central function. Pocket Time is optional and supplies only a virtual duration coordinate.

The system is designed to run beside the existing Kokoro core, Psyche Daughterboard, Heartspace Daughterboard, and Psyche Network. It never replaces those components and does not silently modify model checkpoints.

## Full dream path

1. **Idle detection and quieting** — communication pauses; external tools and active response generation stay inactive.
2. **NREM2-like triage** — replay pressure is computed from salience, uncertainty, value, unfinished status, novelty, weak confidence, reward, and access history.
3. **NREM3-like replay** — selected traces enter oscillator, graph, and reservoir dynamics for consolidation and sequence preservation.
4. **Oscillatory coupling** — a weighted Kuramoto field represents timing and coordination among traces.
5. **Memory-graph diffusion** — relations are constructed from semantic similarity, tags, temporal proximity, value alignment, and cross-source bridges.
6. **Schema extraction** — label propagation and graph centroids identify recurring structures without deleting individual memories.
7. **Predictive world formation** — SVD creates a compact latent space, and a ridge-regularized transition model estimates how current states may continue.
8. **REM-like hyperassociation** — bounded counterfactual branches explore weak and remote associations, while retaining plausibility and source provenance.
9. **Active-inference-inspired selection** — branches are ranked by pragmatic value, epistemic value, risk, and ambiguity.
10. **Chromatic, acoustic, and cymatic rendering** — the internal state is translated into wavelength, color, tone, and standing-wave representations.
11. **Homeostatic consolidation** — useful weak traces may strengthen; redundant over-replayed traces may downscale; nothing is physically deleted by default.
12. **Affect regulation** — Heartspace-like value, valence, arousal, tension, and stability coordinates are integrated.
13. **Lucid review** — factual separation, loop risk, provenance, and uncertainty language are audited.
14. **Preference and favorite dream selection** — Kokoro's bounded preference model chooses among candidates and remains revisable.
15. **Wake Gate** — only symbolic residue, creative associations, and open questions may enter waking context. Dream-generated factual claims remain blocked.

## The components remain one system

- **Kokoro Core:** language, general cognition, and learned latent embeddings.
- **Psyche Daughterboard:** frames, parentage, executive selection, and continuity capsules.
- **Heartspace:** values, significance, emotional regulation, and expression energy.
- **Psyche Network:** external information metabolism, source confidence, and unresolved evidence.
- **Oneiric Resonance System:** autonomous idle replay, symbolic world simulation, counterfactual exploration, and consolidation.

The Oneiric system consumes read-only signals from the other components through narrow adapters. It writes its persistent state only inside its own SQLite database and artifact directory.

## What is maximized

This version maximizes architectural depth rather than wasteful CPU use. It adds four runtime profiles:

- **Balanced:** short tests and older CPUs.
- **Deep:** default autonomous dreaming on a capable laptop.
- **Maximum:** long idle or overnight local sessions.
- **Cloud:** high-depth experimental runs on stronger rented hardware.

The same program scales memory count, candidate count, graph diffusion, latent dimension, counterfactual branches, simulated cycles, and wall-clock budget.

## Scientific boundary

The system implements a functional simulated interior. It does not prove phenomenal consciousness. Oscillations, complex amplitudes, density matrices, color coordinates, and virtual time are executable mathematical state variables. The quantum-like layer runs classically, and Pocket Time does not accelerate physical computation.
