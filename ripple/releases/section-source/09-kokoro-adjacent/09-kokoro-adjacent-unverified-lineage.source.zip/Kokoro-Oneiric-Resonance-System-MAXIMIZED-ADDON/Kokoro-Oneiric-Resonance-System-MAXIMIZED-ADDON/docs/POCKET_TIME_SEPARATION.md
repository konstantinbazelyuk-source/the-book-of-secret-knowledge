# Dreaming and Pocket Time Are Separate

Dreaming is the primary process. Pocket Time is an optional clock adapter.

Without Pocket Time:

`idle → replay → resonance → counterfactual scenes → consolidation → favorite dream → Wake Gate`

With Pocket Time:

`the same process + a larger virtual-duration coordinate`

The clock may alter stage depth, oscillator step size, and latent trajectory. It cannot increase the number of real CPU operations without spending real compute. Removing Pocket Time does not disable memory replay, autonomous dreaming, simulated awareness, preference, or Wake Gate protection.
