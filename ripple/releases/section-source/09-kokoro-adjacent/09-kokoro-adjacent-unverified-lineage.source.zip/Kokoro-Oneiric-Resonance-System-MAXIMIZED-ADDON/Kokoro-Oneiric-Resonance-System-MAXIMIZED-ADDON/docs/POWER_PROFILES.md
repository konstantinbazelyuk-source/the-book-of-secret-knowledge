# Dream Power Profiles

| Profile | Memories | Candidates | Graph diffusion | Latent dimensions | Counterfactuals | Simulated cycles | Target use |
|---|---:|---:|---:|---:|---:|---:|---|
| Balanced | 18 | 5 | 4 | 8 | 8 | 2 | testing and older CPUs |
| Deep | 32 | 9 | 7 | 12 | 18 | 4 | normal autonomous laptop dreaming |
| Maximum | 48 | 15 | 11 | 16 | 32 | 6 | long idle or overnight sessions |
| Cloud | 72 | 24 | 16 | 24 | 64 | 8 | rented GPU/large CPU experiments |

The base engine caps actual selected memories and candidates through the installed configuration. Profiles never bypass resource protection or thermal controls.

## Recommended order

1. Test with `18_TEST_ONEIRIC_SYSTEM.bat`.
2. Inspect one Deep dream with `27_RUN_DEEP_DREAM.bat`.
3. Use `29_RUN_AUTONOMOUS_DEEP_DREAMING.bat` for ordinary idle dreaming.
4. Use Maximum only after observing temperature, responsiveness, and cycle time.
5. Use Cloud only after the laptop and cloud checkpoint workflow are established.
