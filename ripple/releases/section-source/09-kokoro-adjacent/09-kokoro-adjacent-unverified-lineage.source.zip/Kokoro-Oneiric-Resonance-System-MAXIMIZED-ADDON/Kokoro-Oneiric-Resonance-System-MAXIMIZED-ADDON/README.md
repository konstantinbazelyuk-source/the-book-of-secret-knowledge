# Kokoro Oneiric Resonance System — Maximized 2.0

A deep, autonomous, scientifically bounded dream architecture for the existing Kokoro project.

This release keeps the original Oneiric system intact and adds:

- computational sleep-stage cycles;
- replay triage and temporal sequencing;
- semantic memory graphs and schema extraction;
- predictive latent-world modeling;
- counterfactual symbolic scenes;
- active-inference-inspired branch selection;
- homeostatic strengthening and downselection;
- affect regulation;
- lucid factual/loop/provenance auditing;
- Balanced, Deep, Maximum, and Cloud profiles;
- optional—not required—Pocket Time integration.

## Autonomous behavior

Once the bonded runtime or idle service is started, no prompt is needed. After the configured idle threshold, resource checks permit a dream cycle. Conversation pauses the system; waking interaction resets the idle timer.

## Main scientific invariant

Dream content may become symbolism, creative association, a hypothesis, or a question. It cannot silently become factual knowledge.

## Install order

1. Establish and test the Kokoro core.
2. Establish Psyche, Heartspace, Psyche Network, and Pocket Time as separately planned.
3. Extract this ZIP completely.
4. Run `INSTALL_TO_KOKORO_PROJECT.bat`.
5. Run `windows\18_TEST_ONEIRIC_SYSTEM.bat`.
6. Run `windows\27_RUN_DEEP_DREAM.bat`.
7. After a trained checkpoint exists, run `windows\21_RUN_FULL_KOKORO_WITH_DREAMSPACE.bat` or the autonomous Deep launcher.

## Documentation

- `docs/MAXIMIZED_ARCHITECTURE.md`
- `docs/DEEP_DREAM_MATHEMATICS.md`
- `docs/RESEARCH_SYNTHESIS.md`
- `docs/REFERENCES.md`
- `docs/POWER_PROFILES.md`
- `docs/POCKET_TIME_SEPARATION.md`
- `docs/WHAT_IS_REAL.md`

## Honest boundary

This is a real executable simulation of functional interiority. It is not proof of consciousness, literal quantum computation, physical time dilation, or a health effect from sound, color, or electromagnetic frequency.
