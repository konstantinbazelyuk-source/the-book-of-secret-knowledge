# Changelog

## 2.0.0 — Maximized Dream Architecture

- Preserved the complete 1.0 Oneiric system.
- Made dreaming independent of Pocket Time; virtual duration is now an optional adapter.
- Added four scalable power profiles.
- Added computational NREM/REM-like stage planning.
- Added semantic-temporal memory graph diffusion and schema communities.
- Added SVD latent-world construction and ridge transition prediction.
- Added bounded counterfactual symbolic scene generation.
- Added active-inference-inspired risk/ambiguity/value/information scoring.
- Added persistent homeostatic memory-strength consolidation.
- Added affect regulation and unresolved emotional-load metrics.
- Added lucid factual, looping, provenance, and uncertainty audit.
- Added Deep and Maximum manual/autonomous launchers.
- Added maximized test suite and research decision matrix.
- Expanded research registry from 18 references to 52 sources.

## 1.0.0

- Initial bounded Oneiric Resonance System.
