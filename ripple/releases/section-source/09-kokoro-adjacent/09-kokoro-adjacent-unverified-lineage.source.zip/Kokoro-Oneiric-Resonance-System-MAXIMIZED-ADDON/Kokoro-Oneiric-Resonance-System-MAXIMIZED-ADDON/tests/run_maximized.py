from __future__ import annotations

import argparse
import json
import sys
import tempfile
from pathlib import Path

ADDON = Path(__file__).resolve().parents[1]
if str(ADDON) not in sys.path:
    sys.path.insert(0, str(ADDON))

from oneiric.config import OneiricConfig
from oneiric.maximized_engine import MaximizedOneiricEngine
from oneiric.memory_graph import build_memory_graph
from oneiric.predictive_world import build_predictive_world


def check(name: str, condition: bool, details: object = "") -> None:
    if not condition:
        raise AssertionError(f"{name}: {details}")
    print("PASS:", name)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project")
    args = parser.parse_args()
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        cfg = OneiricConfig()
        cfg.idle_threshold_seconds = 0
        cfg.dream_profile = "balanced"
        cfg.max_wall_seconds_per_cycle = 0.4
        cfg.oscillator_steps = 45
        cfg.quantum_steps = 5
        cfg.max_memories_per_dream = 12
        cfg.save(root / "config.json")
        engine = MaximizedOneiricEngine(root / "state.sqlite3", root / "config.json", args.project, "balanced")
        samples = [
            ("A blue bridge preserves an unfinished promise across time", "psyche", .8, .6, .8, .8, ["continuity", "bridge"]),
            ("A gold heart weighs truth against kindness", "heartspace", .9, .3, .95, .5, ["value", "truth"]),
            ("A green garden represents restoration after conflict", "core", .7, .2, .8, .4, ["restoration", "garden"]),
            ("A violet doorway opens toward an uncertain future", "network", .75, .75, .65, .9, ["uncertainty", "doorway"]),
            ("Memory should remain correctable instead of becoming rigid", "psyche", .85, .25, .9, .55, ["memory", "correction"]),
            ("Dream symbols may inspire questions but do not establish facts", "safety", .95, .1, .95, .2, ["wake-gate", "symbol"]),
        ]
        for text, source, salience, uncertainty, value, unresolved, tags in samples:
            engine.ingest(text, source, salience, uncertainty, value, unresolved, .75, .2, tags)
        dream = engine.dream(.2, 5, True)
        deep = dream.provenance.get("deep_cycle", {})
        check("maximized engine marker", dream.provenance.get("maximized_oneiric_version") == "2.0.0")
        check("scientific sleep architecture", len(deep.get("sleep_plan", {}).get("stage_path", [])) >= 8)
        check("memory graph built", len(deep.get("memory_graph", {}).get("centrality", [])) >= 3)
        check("predictive world built", len(deep.get("predictive_world", {}).get("counterfactuals", [])) >= 1)
        check("homeostatic consolidation recorded", "mean_strength_change" in deep.get("homeostasis", {}))
        check("affect regulation recorded", "emotional_integration" in deep.get("affect", {}))
        check("lucid audit passed", deep.get("lucid_audit", {}).get("passed") is True, deep.get("lucid_audit"))
        check("wake gate still empty facts", dream.wake_capsule.get("factual_claims") == [])
        check("latent scenes retained", len(deep.get("latent_scenes", [])) >= 1)
        check("profile preserved", dream.provenance.get("dream_profile") == "balanced")
        check("Pocket Time optionalized", "optional" in dream.provenance.get("pocket_time_role", ""))
        check("strength metadata persisted", any("oneiric_strength" in m.metadata for m in engine.store.memories(50)))
        status = engine.status()
        check("deep state status", bool(status.get("last_deep_cycle")))
        engine.close()
    print("\nALL MAXIMIZED ONEIRIC TESTS PASSED")


if __name__ == "__main__":
    main()
