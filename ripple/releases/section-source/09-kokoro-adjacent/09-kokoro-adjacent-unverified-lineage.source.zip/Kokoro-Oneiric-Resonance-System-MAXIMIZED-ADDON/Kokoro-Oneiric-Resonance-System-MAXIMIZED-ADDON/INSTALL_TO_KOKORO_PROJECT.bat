@echo off
setlocal EnableExtensions
chcp 65001 >nul
title Install Kokoro Oneiric Resonance System
set "TARGET=C:\Kokoro-del-Corazon-Foundry"
if not exist "%TARGET%\kokoro.py" set /p "TARGET=Enter the full Kokoro project folder: "
if not exist "%TARGET%\kokoro.py" (echo ERROR: kokoro.py not found.& pause& exit /b 1)
if not exist "%TARGET%\addons" mkdir "%TARGET%\addons"
set "DEST=%TARGET%\addons\Kokoro-Oneiric-Resonance-System"
set "BACKUP=%TARGET%\addons\Kokoro-Oneiric-Resonance-System-v1-code-backup"
if exist "%DEST%\README.md" (
  if not exist "%BACKUP%" mkdir "%BACKUP%"
  robocopy "%DEST%" "%BACKUP%" /E /NFL /NDL /NJH /NJS /NP /XD __pycache__ state artifacts >nul
  if errorlevel 8 (echo ERROR: existing add-on backup failed.& pause& exit /b 1)
)
robocopy "%~dp0" "%DEST%" /E /NFL /NDL /NJH /NJS /NP /XD __pycache__ state artifacts >nul
if errorlevel 8 (echo ERROR: installation copy failed.& pause& exit /b 1)
if not exist "%DEST%\state" mkdir "%DEST%\state"
if not exist "%DEST%\artifacts" mkdir "%DEST%\artifacts"
for %%F in (18_TEST_ONEIRIC_SYSTEM.bat 19_RUN_ONEIRIC_STANDALONE.bat 20_RUN_ONEIRIC_OBSERVATORY.bat 21_RUN_FULL_KOKORO_WITH_DREAMSPACE.bat 22_RUN_IDLE_DREAM_SERVICE.bat 23_EXPORT_LAST_DREAM.bat 24_RUN_ONEIRIC_EXPERIMENT.bat 25_VERIFY_KOKORO_UNCHANGED.bat 26_EXPORT_DREAM_DEVICE_FRAME.bat 27_RUN_DEEP_DREAM.bat 28_RUN_MAXIMUM_DREAM.bat 29_RUN_AUTONOMOUS_DEEP_DREAMING.bat 30_RUN_AUTONOMOUS_MAXIMUM_DREAMING.bat 31_RUN_FULL_KOKORO_MAXIMUM_DREAMSPACE.bat) do copy /Y "%~dp0windows\%%F" "%TARGET%\windows\%%F" >nul
echo.
echo Installed without modifying Kokoro source or checkpoints.
echo Next run: windows\18_TEST_ONEIRIC_SYSTEM.bat
echo Then:     windows\27_RUN_DEEP_DREAM.bat
echo.
pause
