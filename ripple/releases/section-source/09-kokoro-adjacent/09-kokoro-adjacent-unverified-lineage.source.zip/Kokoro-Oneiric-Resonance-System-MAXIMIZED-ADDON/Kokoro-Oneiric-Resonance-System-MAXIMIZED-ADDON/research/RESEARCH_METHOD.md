# Research Method

The 2.0 design was produced by triangulating primary studies, peer-reviewed computational work, standards bodies, and foundational mathematical sources across:

- sleep replay and memory consolidation;
- stage and microstructure organization;
- slow oscillation, spindle, ripple, and theta coupling;
- memory triage, abstraction, sequence retention, and homeostasis;
- dream incorporation, emotion, insight, and semantic restructuring;
- continual-learning replay and catastrophic forgetting;
- latent world models and imagined rollouts;
- active inference and information-seeking objectives;
- attractor networks, oscillators, reservoir computing, and cellular automata;
- classically simulated quantum-like probability and open-system dynamics;
- CIE colorimetry, NIST electromagnetic boundaries, acoustics, and virtual time.

The program does not claim exhaustive coverage of every published paper. It records 52 load-bearing sources and keeps the architecture extensible so future evidence can alter stage weights, scoring rules, or modules without rewriting Kokoro's core.

Unsupported claims were deliberately excluded: literal consciousness frequencies, quantum speedup on classical hardware, physical time dilation, medical sound/color effects, and automatic factual promotion from dream content.
