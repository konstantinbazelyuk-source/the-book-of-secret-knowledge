# Research Decision Matrix

| Research area | Implemented mechanism | Measured outputs | Boundary |
|---|---|---|---|
| hippocampal/cortical replay | prioritized replay and stage plan | selected IDs, replay probabilities, access count | computational analogy |
| slow oscillation/spindle/ripple coupling | weighted oscillator timing | phase order, coherence, stage provenance | not EEG simulation |
| memory triage | salience/value/uncertainty/unresolved weighting | priority and source diversity | configurable, revisable |
| systems consolidation | memory graph diffusion and schemas | centrality, communities, sequence score | source episodes preserved |
| synaptic homeostasis | bounded strength updates | before/after load, strengthened/downselected counts | no automatic deletion |
| dreaming and emotion | affect regulation and symbolic scenes | valence, arousal, emotional integration | not therapy |
| creativity and insight | remote counterfactual associations | novelty, semantic restructuring | not guaranteed insight |
| world models | SVD latent state and transition model | reconstruction/prediction error | small local model, not environment truth |
| active inference | risk + ambiguity - epistemic - pragmatic objective | expected free energy | inspired objective, not full biological theory |
| continual learning | replay and provenance | retained IDs, preference history | does not train core weights by default |
| reservoir computing | fixed nonlinear temporal field | activity, stability, spectral radius | CPU-bounded |
| quantum-inspired methods | complex amplitudes and density matrices | trace, eigenvalue, entropy, purity | classical execution only |
| colorimetry | wavelength-to-color representation | wavelength, RGB, physical frequency metadata | perception model, not consciousness |
| acoustics/cymatics | tones and standing-wave render | WAV and field image | representation only |
| virtual time | optional simulated duration | virtual/wall seconds and temporal gain | no physical acceleration |
