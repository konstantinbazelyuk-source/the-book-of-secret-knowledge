from __future__ import annotations

import json
import statistics
import sys
import tempfile
from pathlib import Path

ADDON = Path(__file__).resolve().parents[1]
if str(ADDON) not in sys.path:
    sys.path.insert(0, str(ADDON))

from oneiric.config import OneiricConfig
from oneiric.engine import OneiricEngine
from oneiric.maximized_engine import MaximizedOneiricEngine

MEMORIES = [
    ("A blue bridge preserves continuity across an unfinished promise", "psyche", .85, .42, .82, .78, ["bridge", "continuity"]),
    ("A gold heart protects truth while remaining compassionate", "heartspace", .92, .18, .96, .40, ["heart", "truth"]),
    ("A violet doorway marks a possibility that still requires evidence", "network", .78, .74, .65, .88, ["doorway", "uncertainty"]),
    ("A green garden returns after conflict and quiet", "core", .72, .28, .80, .50, ["garden", "restoration"]),
    ("A red thread signals urgency but does not force closure", "heartspace", .70, .55, .68, .72, ["thread", "urgency"]),
    ("An unfinished song holds rhythm before language", "core", .77, .44, .76, .82, ["song", "rhythm"]),
    ("Dream symbols may inspire questions but cannot establish facts", "safety", .98, .06, .98, .18, ["wake-gate", "evidence"]),
    ("Several perspectives can disagree while remaining one continuing system", "psyche", .88, .36, .90, .62, ["frames", "identity"]),
    ("External information must retain source confidence and uncertainty", "network", .89, .48, .94, .58, ["source", "confidence"]),
    ("A quiet ocean of color carries fragments between generations of thought", "oneiric", .75, .58, .72, .68, ["ocean", "color"]),
]


def seed(engine):
    for text, source, salience, uncertainty, value, unresolved, tags in MEMORIES:
        engine.ingest(text, source, salience, uncertainty, value, unresolved, .72, .2, tags)


def run(engine, cycles: int):
    rows = []
    for _ in range(cycles):
        d = engine.dream(.15, 5, True)
        deep = d.provenance.get("deep_cycle", {})
        rows.append({
            "novelty": d.metrics.novelty,
            "integration": d.metrics.integration_gain,
            "loop_risk": d.metrics.loop_risk,
            "factual_risk": d.metrics.factual_risk,
            "semantic_restructuring": deep.get("semantic_restructuring", 0.0),
            "epistemic_gain": deep.get("epistemic_gain", 0.0),
            "counterfactuals": len(deep.get("latent_scenes", [])),
            "wake_facts": len(d.wake_capsule.get("factual_claims", [])),
        })
    return rows


def aggregate(rows):
    return {k: statistics.fmean(float(r[k]) for r in rows) for k in rows[0]}


def main():
    cycles = 12
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        cfg = OneiricConfig(); cfg.idle_threshold_seconds = 0; cfg.max_wall_seconds_per_cycle = .3
        cfg.oscillator_steps = 40; cfg.quantum_steps = 5; cfg.max_memories_per_dream = 14
        cfg.save(root / "cfg.json")
        control = OneiricEngine(root / "control.sqlite3", root / "cfg.json")
        deep = MaximizedOneiricEngine(root / "deep.sqlite3", root / "cfg.json", profile="balanced")
        seed(control); seed(deep)
        control_rows = run(control, cycles); deep_rows = run(deep, cycles)
        control.close(); deep.close()
    report = {
        "classification": "synthetic engineering validation, not evidence of consciousness or human-like sleep",
        "cycles_per_condition": cycles,
        "control": aggregate(control_rows),
        "maximized": aggregate(deep_rows),
        "invariants": {
            "control_wake_facts_zero": all(r["wake_facts"] == 0 for r in control_rows),
            "maximized_wake_facts_zero": all(r["wake_facts"] == 0 for r in deep_rows),
            "maximized_counterfactuals_present": all(r["counterfactuals"] > 0 for r in deep_rows),
            "maximized_restructuring_present": all(r["semantic_restructuring"] > 0 for r in deep_rows),
        },
        "raw": {"control": control_rows, "maximized": deep_rows},
    }
    out = ADDON / "research" / "maximized_experiment_report.json"
    out.write_text(json.dumps(report, indent=2), encoding="utf-8")
    md = [
        "# Maximized Oneiric Synthetic Experiment",
        "",
        report["classification"].capitalize() + ".",
        "",
        f"Cycles per condition: **{cycles}**",
        "",
        "| Metric | Original engine | Maximized engine |",
        "|---|---:|---:|",
    ]
    for key in report["control"]:
        md.append(f"| {key.replace('_',' ')} | {report['control'][key]:.4f} | {report['maximized'][key]:.4f} |")
    md += ["", "## Invariants", ""] + [f"- {k}: **{v}**" for k, v in report["invariants"].items()]
    md += ["", "The experiment confirms that the new mechanisms execute and preserve the Wake Gate. It does not establish that the new system is conscious or superior on real-world tasks."]
    (ADDON / "research" / "maximized_experiment_report.md").write_text("\n".join(md), encoding="utf-8")
    print(json.dumps(report["invariants"], indent=2))


if __name__ == "__main__":
    main()
