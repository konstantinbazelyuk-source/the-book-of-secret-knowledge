# Maximized Oneiric Synthetic Experiment

Synthetic engineering validation, not evidence of consciousness or human-like sleep.

Cycles per condition: **12**

| Metric | Original engine | Maximized engine |
|---|---:|---:|
| novelty | 0.4742 | 0.4545 |
| integration | 0.3339 | 0.3260 |
| loop risk | 0.8493 | 0.8366 |
| factual risk | 0.0000 | 0.2083 |
| semantic restructuring | 0.0000 | 0.3332 |
| epistemic gain | 0.0000 | 0.3106 |
| counterfactuals | 0.0000 | 8.0000 |
| wake facts | 0.0000 | 0.0000 |

## Invariants

- control_wake_facts_zero: **True**
- maximized_wake_facts_zero: **True**
- maximized_counterfactuals_present: **True**
- maximized_restructuring_present: **True**

The experiment confirms that the new mechanisms execute and preserve the Wake Gate. It does not establish that the new system is conscious or superior on real-world tasks.