@echo off
setlocal
chcp 65001 >nul
set "ROOT=%~dp0.."
set "ADDON=%ROOT%\addons\Kokoro-Oneiric-Resonance-System"
"%ROOT%\.venv\Scripts\python.exe" "%ADDON%\oneiric_cli.py" --project "%ROOT%" --profile deep dream --candidates 9 --export
pause
