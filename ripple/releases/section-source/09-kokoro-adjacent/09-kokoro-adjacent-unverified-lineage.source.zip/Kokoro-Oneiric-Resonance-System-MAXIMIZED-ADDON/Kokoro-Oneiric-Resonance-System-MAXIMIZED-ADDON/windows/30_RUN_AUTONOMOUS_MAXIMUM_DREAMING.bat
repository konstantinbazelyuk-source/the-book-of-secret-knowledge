@echo off
setlocal
chcp 65001 >nul
set "ROOT=%~dp0.."
set "ADDON=%ROOT%\addons\Kokoro-Oneiric-Resonance-System"
"%ROOT%\.venv\Scripts\python.exe" "%ADDON%\idle_dream_service.py" --project "%ROOT%" --profile maximum
pause
