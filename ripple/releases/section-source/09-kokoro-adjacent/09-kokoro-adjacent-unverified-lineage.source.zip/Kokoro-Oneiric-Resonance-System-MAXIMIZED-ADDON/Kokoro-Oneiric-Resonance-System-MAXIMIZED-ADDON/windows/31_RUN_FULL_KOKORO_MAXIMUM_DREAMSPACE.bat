@echo off
setlocal EnableExtensions
set "ROOT=%~dp0.."
set "ADDON=%ROOT%\addons\Kokoro-Oneiric-Resonance-System"
if not exist "%ROOT%\.venv\Scripts\python.exe" (echo Kokoro Python environment not found.& pause& exit /b 1)
title Full Kokoro with Maximum Oneiric Dreamspace
"%ROOT%\.venv\Scripts\python.exe" "%ADDON%\bonded_oneiric_runtime.py" --base "%ROOT%" --device auto --profile maximum
pause
