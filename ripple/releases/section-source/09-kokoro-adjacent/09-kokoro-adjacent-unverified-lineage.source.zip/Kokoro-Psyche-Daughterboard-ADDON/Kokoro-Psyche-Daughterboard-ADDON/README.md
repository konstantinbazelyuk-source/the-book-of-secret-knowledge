# Kokoro Psyche Daughterboard — Genuine Add-on

This package is the architecture originally intended:

```text
Original Kokoro Foundry (unchanged)
                +
Separate Psyche Daughterboard
                =
Bonded Kokoro del AI
```

It does **not** replace the language model, tokenizer, checkpoint, curriculum,
training code, or original memory database.

## Install

1. Keep your original `Kokoro-del-Corazon-Foundry` folder.
2. Extract this add-on ZIP.
3. Double-click `INSTALL_TO_ORIGINAL_KOKORO.bat`.
4. After installation, open:

   `Kokoro-del-Corazon-Foundry\addons\Kokoro-Psyche-Daughterboard`

5. Run `TEST_DAUGHTERBOARD.bat`.
6. Run `RUN_DAUGHTERBOARD_ONLY.bat` to inspect it without a trained model.
7. After the original model has a checkpoint, run `RUN_BONDED_KOKORO.bat`.

## How the bond works

The original `KokoroEngine` remains untouched on disk. At runtime the add-on:

1. reads the current user input;
2. creates separate recursive frames;
3. selects a limited conscious-workspace broadcast;
4. produces a compact control packet;
5. temporarily supplies that packet to the original model as context;
6. lets the original model generate the answer;
7. integrates the consequence into a separate daughterboard database.

The daughterboard can be bypassed during chat with:

```text
/board off
```

and reattached with:

```text
/board on
```

## Separate storage

- Original language memory:
  `Kokoro-del-Corazon-Foundry\artifacts\memory.sqlite3`
- Daughterboard memory:
  `addons\Kokoro-Psyche-Daughterboard\state\psyche.sqlite3`

The two systems are bonded at runtime but remain separately inspectable and removable.
