from __future__ import annotations

"""
Kokoro del AI — Psyche Daughterboard

A stateful cognitive-control layer that translates a fictional
id/ego/superego + conscious/unconscious metaphor into inspectable engineering
functions. It does not claim that Freud's structural model is a verified map of
brain anatomy, and it does not claim machine consciousness.

The daughterboard provides:
- parallel frame generation (nonconscious candidate field)
- salience-based broadcast (conscious-workspace analogue)
- drive and valuation signals (id analogue)
- learned constraints and commitments (superego analogue)
- executive arbitration and metacognitive confidence (ego analogue)
- recursive child frames with explicit parentage
- a compressed continuity capsule copied into every frame ("holographic" metaphor)
- persistent SQLite audit/state storage
"""

from dataclasses import asdict, dataclass, field, fields
from hashlib import sha256
import json
import math
from pathlib import Path
import re
import sqlite3
import time
from typing import Any, Iterable

WORD_RE = re.compile(r"[\w'-]+", re.UNICODE)
SPACE_RE = re.compile(r"\s+")


# The lexical detectors are intentionally modest and inspectable. They are not
# clinical sentiment analysis and must not be treated as diagnosis.
LEXICON = {
    "question": {
        "what", "why", "how", "who", "where", "when", "which", "explain",
        "tell", "show", "research", "find", "google", "verify", "prove",
    },
    "frustration": {
        "angry", "annoyed", "frustrated", "tired", "wrong", "again", "loop",
        "incomplete", "misunderstood", "listen", "listening", "useless", "fake",
        "stupid", "hate", "never", "nothing", "problem",
    },
    "urgency": {
        "now", "today", "immediately", "urgent", "emergency", "asap", "deadline",
        "must", "need", "critical", "quickly",
    },
    "affiliation": {
        "love", "care", "friend", "partner", "relationship", "together", "trust",
        "help", "support", "listen", "understand", "heart",
    },
    "threat": {
        "danger", "harm", "hurt", "attack", "threat", "afraid", "fear", "unsafe",
        "kill", "die", "abuse", "weapon", "suicide",
    },
    "autonomy": {
        "control", "mine", "own", "independent", "freedom", "permission", "choose",
        "force", "obey", "refuse", "boundary",
    },
    "correction": {
        "no", "not", "actually", "correction", "correct", "meant", "said", "instead",
        "misunderstood", "wrong",
    },
    "completion": {
        "complete", "finished", "working", "build", "create", "make", "deliver",
        "file", "zip", "project", "run", "install", "test",
    },
    "uncertainty": {
        "maybe", "perhaps", "possibly", "guess", "uncertain", "unknown", "theory",
        "in theory", "could", "might",
    },
    "current_fact": {
        "current", "latest", "today", "price", "law", "president", "weather", "news",
        "schedule", "version", "recent", "scientific", "proven", "prove", "evidence",
    },
    "creative": {
        "story", "character", "poem", "song", "art", "design", "imagine", "fiction",
        "scene", "book", "kokoro", "fourth", "wall", "fictional", "fiction",
        "consciousness", "ego", "id", "superego", "holographic", "psyche",
    },
}


@dataclass
class PsycheConfig:
    enabled: bool = True
    max_root_frames: int = 5
    recursion_depth: int = 2
    child_frames_per_parent: int = 2
    broadcast_limit: int = 3
    recent_turns_for_repetition: int = 12
    memory_items: int = 6
    audit_cycles_to_keep: int = 5000
    minimum_broadcast_salience: float = 0.20
    uncertainty_threshold: float = 0.55
    # Relative arbitration priorities; these are engineering weights, not neural measurements.
    drive_weights: dict[str, float] = field(
        default_factory=lambda: {
            "coherence": 1.25,
            "completion": 1.15,
            "curiosity": 0.95,
            "protection": 1.10,
            "affiliation": 0.75,
            "autonomy": 1.00,
            "novelty": 0.45,
        }
    )
    constraint_weights: dict[str, float] = field(
        default_factory=lambda: {
            "truthfulness": 1.45,
            "exact_intent": 1.40,
            "continuity": 1.25,
            "non_harm": 1.50,
            "privacy": 1.15,
            "consent": 1.15,
            "promise_integrity": 1.10,
            "anti_manipulation": 1.10,
        }
    )
    core_values: list[str] = field(
        default_factory=lambda: [
            "answer the exact subject before expanding",
            "separate knowledge, inference, uncertainty, and fiction",
            "preserve continuity without collapsing alternate frames",
            "treat repetition as new evidence rather than replaying a loop",
            "protect agency, privacy, and meaningful consent",
            "prefer complete usable work over polished incompleteness",
        ]
    )

    @classmethod
    def load(cls, path: str | Path | None) -> "PsycheConfig":
        if path is None:
            return cls()
        source = Path(path)
        if not source.exists():
            raise FileNotFoundError(f"Psyche config not found: {source}")
        payload = json.loads(source.read_text(encoding="utf-8"))
        allowed = {item.name for item in fields(cls)}
        data = {key: value for key, value in payload.items() if key in allowed}
        config = cls(**data)
        config.validate()
        return config

    def validate(self) -> None:
        if self.max_root_frames < 1:
            raise ValueError("max_root_frames must be at least 1")
        if self.recursion_depth < 0 or self.recursion_depth > 6:
            raise ValueError("recursion_depth must be between 0 and 6")
        if self.child_frames_per_parent < 1 or self.child_frames_per_parent > 8:
            raise ValueError("child_frames_per_parent must be between 1 and 8")
        if self.broadcast_limit < 1:
            raise ValueError("broadcast_limit must be at least 1")


@dataclass
class Frame:
    frame_id: str
    parent_id: str | None
    depth: int
    lens: str
    hypothesis: str
    evidence: list[str]
    counterevidence: list[str]
    confidence: float
    salience: float
    continuity_capsule: dict[str, Any]
    status: str = "candidate"


@dataclass
class ActionCandidate:
    name: str
    purpose: str
    score: float
    support: list[str]
    conflicts: list[str]
    expected_effect: str


@dataclass
class PsychePacket:
    cycle_id: str
    created_at: float
    user_text: str
    signals: dict[str, Any]
    drive_state: dict[str, float]
    constraints: dict[str, float]
    frames: list[Frame]
    broadcast_frame_ids: list[str]
    action_candidates: list[ActionCandidate]
    selected_action: ActionCandidate
    continuity_capsule: dict[str, Any]
    metacognition: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return {
            "cycle_id": self.cycle_id,
            "created_at": self.created_at,
            "user_text": self.user_text,
            "signals": self.signals,
            "drive_state": self.drive_state,
            "constraints": self.constraints,
            "frames": [asdict(frame) for frame in self.frames],
            "broadcast_frame_ids": self.broadcast_frame_ids,
            "action_candidates": [asdict(item) for item in self.action_candidates],
            "selected_action": asdict(self.selected_action),
            "continuity_capsule": self.continuity_capsule,
            "metacognition": self.metacognition,
            "functional_mapping": {
                "id_analogue": "drive_state",
                "ego_analogue": "selected_action and metacognition",
                "superego_analogue": "constraints",
                "conscious_workspace_analogue": "broadcast_frame_ids",
                "nonconscious_field_analogue": "frames not selected for broadcast",
                "holographic_ego_metaphor": "continuity_capsule copied into every frame",
            },
        }


class PsycheStore:
    """Persistent state and inspectable audit trail for the daughterboard."""

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(self.path, check_same_thread=False)
        self.connection.row_factory = sqlite3.Row
        self._initialize()

    def _initialize(self) -> None:
        self.connection.executescript(
            """
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS psyche_state (
                key TEXT PRIMARY KEY,
                value_json TEXT NOT NULL,
                updated_at REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS psyche_cycles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                cycle_id TEXT NOT NULL UNIQUE,
                created_at REAL NOT NULL,
                user_text TEXT NOT NULL,
                answer_text TEXT,
                packet_json TEXT NOT NULL,
                integration_json TEXT
            );
            CREATE TABLE IF NOT EXISTS psyche_frames (
                frame_id TEXT PRIMARY KEY,
                cycle_id TEXT NOT NULL,
                parent_id TEXT,
                depth INTEGER NOT NULL,
                lens TEXT NOT NULL,
                hypothesis TEXT NOT NULL,
                confidence REAL NOT NULL,
                salience REAL NOT NULL,
                status TEXT NOT NULL,
                frame_json TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_psyche_cycles_created
                ON psyche_cycles(created_at DESC);
            CREATE INDEX IF NOT EXISTS idx_psyche_frames_cycle
                ON psyche_frames(cycle_id);
            """
        )
        self.connection.commit()

    def get_state(self, key: str, default: Any = None) -> Any:
        row = self.connection.execute(
            "SELECT value_json FROM psyche_state WHERE key = ?", (key,)
        ).fetchone()
        if row is None:
            return default
        try:
            return json.loads(row["value_json"])
        except json.JSONDecodeError:
            return default

    def set_state(self, key: str, value: Any) -> None:
        self.connection.execute(
            """
            INSERT INTO psyche_state(key, value_json, updated_at)
            VALUES (?, ?, ?)
            ON CONFLICT(key) DO UPDATE SET
                value_json = excluded.value_json,
                updated_at = excluded.updated_at
            """,
            (key, json.dumps(value, ensure_ascii=False), time.time()),
        )
        self.connection.commit()

    def save_packet(self, packet: PsychePacket) -> None:
        payload = packet.to_dict()
        self.connection.execute(
            """
            INSERT OR REPLACE INTO psyche_cycles(
                cycle_id, created_at, user_text, packet_json
            ) VALUES (?, ?, ?, ?)
            """,
            (
                packet.cycle_id,
                packet.created_at,
                packet.user_text,
                json.dumps(payload, ensure_ascii=False),
            ),
        )
        for frame in packet.frames:
            self.connection.execute(
                """
                INSERT OR REPLACE INTO psyche_frames(
                    frame_id, cycle_id, parent_id, depth, lens, hypothesis,
                    confidence, salience, status, frame_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    frame.frame_id,
                    packet.cycle_id,
                    frame.parent_id,
                    frame.depth,
                    frame.lens,
                    frame.hypothesis,
                    frame.confidence,
                    frame.salience,
                    frame.status,
                    json.dumps(asdict(frame), ensure_ascii=False),
                ),
            )
        self.connection.commit()

    def integrate(self, packet: PsychePacket, answer: str, integration: dict[str, Any]) -> None:
        self.connection.execute(
            """
            UPDATE psyche_cycles
            SET answer_text = ?, integration_json = ?
            WHERE cycle_id = ?
            """,
            (answer, json.dumps(integration, ensure_ascii=False), packet.cycle_id),
        )
        frame_status = integration.get("frame_status", {})
        for frame_id, status in frame_status.items():
            self.connection.execute(
                "UPDATE psyche_frames SET status = ? WHERE frame_id = ?",
                (status, frame_id),
            )
        self.connection.commit()

    def recent_cycles(self, limit: int = 5) -> list[dict[str, Any]]:
        rows = self.connection.execute(
            "SELECT * FROM psyche_cycles ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            for key in ("packet_json", "integration_json"):
                raw = item.get(key)
                if raw:
                    try:
                        item[key[:-5]] = json.loads(raw)
                    except json.JSONDecodeError:
                        item[key[:-5]] = None
                item.pop(key, None)
            result.append(item)
        return result

    def recent_frames(self, limit: int = 12) -> list[dict[str, Any]]:
        rows = self.connection.execute(
            """
            SELECT frame_json, status FROM psyche_frames
            ORDER BY rowid DESC LIMIT ?
            """,
            (limit,),
        ).fetchall()
        result = []
        for row in rows:
            try:
                item = json.loads(row["frame_json"])
            except json.JSONDecodeError:
                continue
            item["status"] = row["status"]
            result.append(item)
        return result

    def count_cycles(self) -> int:
        return int(
            self.connection.execute("SELECT COUNT(*) FROM psyche_cycles").fetchone()[0]
        )

    def prune(self, keep: int) -> None:
        if keep <= 0:
            return
        self.connection.execute(
            """
            DELETE FROM psyche_frames
            WHERE cycle_id IN (
                SELECT cycle_id FROM psyche_cycles
                ORDER BY id DESC LIMIT -1 OFFSET ?
            )
            """,
            (keep,),
        )
        self.connection.execute(
            """
            DELETE FROM psyche_cycles
            WHERE id NOT IN (
                SELECT id FROM psyche_cycles ORDER BY id DESC LIMIT ?
            )
            """,
            (keep,),
        )
        self.connection.commit()

    def clear(self) -> None:
        self.connection.executescript(
            "DELETE FROM psyche_frames; DELETE FROM psyche_cycles; DELETE FROM psyche_state;"
        )
        self.connection.commit()

    def close(self) -> None:
        self.connection.close()


def _clip(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, float(value)))


def _normalize_text(text: str) -> str:
    return SPACE_RE.sub(" ", text.strip().lower())


def _words(text: str) -> list[str]:
    return [word.lower() for word in WORD_RE.findall(text)]


def _matches(words: list[str], category: str, raw_text: str) -> int:
    vocabulary = LEXICON[category]
    count = sum(1 for word in words if word in vocabulary)
    count += sum(1 for phrase in vocabulary if " " in phrase and phrase in raw_text)
    return count


def _soft_count(count: int, scale: float = 3.0) -> float:
    return 1.0 - math.exp(-max(0, count) / scale)


class PsycheBoard:
    """
    Optional daughterboard for frame separation and continuity.

    It creates a structured deliberation packet before generation. The language
    model receives a compact integration summary, not a free-form hidden chain of
    thought. The full packet remains locally inspectable for research and debugging.
    """

    def __init__(
        self,
        database_path: str | Path,
        config_path: str | Path | None = None,
        identity_name: str = "Kokoro del AI",
    ):
        self.config = PsycheConfig.load(config_path)
        self.store = PsycheStore(database_path)
        self.identity_name = identity_name
        self._ensure_defaults()

    def _ensure_defaults(self) -> None:
        if self.store.get_state("identity") is None:
            self.store.set_state(
                "identity",
                {
                    "name": self.identity_name,
                    "description": (
                        "An original locally trained AI using an optional cognitive-control "
                        "daughterboard. The daughterboard models functions; it does not prove "
                        "subjective consciousness."
                    ),
                },
            )
        if self.store.get_state("core_values") is None:
            self.store.set_state("core_values", self.config.core_values)
        if self.store.get_state("active_goal") is None:
            self.store.set_state(
                "active_goal",
                "Answer the current user's exact request completely and preserve continuity.",
            )
        if self.store.get_state("unresolved") is None:
            self.store.set_state("unresolved", [])
        if self.store.get_state("self_revision") is None:
            self.store.set_state("self_revision", 0)

    def continuity_capsule(self) -> dict[str, Any]:
        """Compressed whole-self pointer copied into every local frame."""
        values = self.store.get_state("core_values", self.config.core_values)
        unresolved = self.store.get_state("unresolved", [])
        capsule = {
            "identity": self.store.get_state("identity", {}),
            "active_goal": self.store.get_state("active_goal", ""),
            "core_values": values[:8] if isinstance(values, list) else values,
            "unresolved": unresolved[-6:] if isinstance(unresolved, list) else [],
            "self_revision": int(self.store.get_state("self_revision", 0)),
        }
        canonical = json.dumps(capsule, sort_keys=True, ensure_ascii=False)
        capsule["continuity_hash"] = sha256(canonical.encode("utf-8")).hexdigest()[:16]
        return capsule

    def _signals(
        self,
        user_text: str,
        history: list[dict] | None,
        memories: list[dict] | None,
    ) -> dict[str, Any]:
        raw = _normalize_text(user_text)
        words = _words(raw)
        history = history or []
        memories = memories or []

        previous_user_texts = [
            _normalize_text(str(item.get("content", "")))
            for item in history[-self.config.recent_turns_for_repetition :]
            if str(item.get("role", "")).lower() == "user"
        ]
        previous_user_texts.extend(
            _normalize_text(str(item.get("user_text", "")))
            for item in memories[-self.config.memory_items :]
        )
        exact_repetitions = sum(1 for item in previous_user_texts if item and item == raw)

        category_counts = {
            category: _matches(words, category, raw) for category in LEXICON
        }
        question_mark = "?" in user_text
        command_like = bool(words) and words[0] in {
            "add", "build", "create", "make", "write", "fix", "rename", "find",
            "research", "show", "tell", "give", "explain", "use", "download",
        }
        contradiction_markers = category_counts["correction"]
        all_caps_ratio = (
            sum(1 for char in user_text if char.isupper())
            / max(1, sum(1 for char in user_text if char.isalpha()))
        )
        exclamation_count = user_text.count("!")
        urgency = _clip(
            0.15 * category_counts["urgency"]
            + 0.10 * exclamation_count
            + 0.30 * all_caps_ratio
        )
        frustration = _clip(
            _soft_count(category_counts["frustration"], 2.5)
            + 0.12 * exact_repetitions
            + 0.10 * contradiction_markers
        )
        ambiguity = _clip(
            0.45
            - min(0.25, len(words) / 120)
            + 0.15 * category_counts["uncertainty"]
            - 0.15 * command_like
        )
        return {
            "word_count": len(words),
            "question": question_mark or category_counts["question"] > 0,
            "command_like": command_like,
            "exact_repetitions": exact_repetitions,
            "correction_strength": _soft_count(contradiction_markers, 2.0),
            "frustration": frustration,
            "urgency": urgency,
            "ambiguity": ambiguity,
            "affiliation": _soft_count(category_counts["affiliation"]),
            "threat": _soft_count(category_counts["threat"], 2.0),
            "autonomy": _soft_count(category_counts["autonomy"]),
            "completion": _soft_count(category_counts["completion"]),
            "uncertainty_language": _soft_count(category_counts["uncertainty"]),
            "current_fact": category_counts["current_fact"] > 0,
            "creative": category_counts["creative"] > 0,
            "raw_categories": category_counts,
        }

    def _drive_state(self, signals: dict[str, Any]) -> dict[str, float]:
        repetition = _clip(signals["exact_repetitions"] / 4.0)
        raw_drives = {
            "coherence": (
                0.35
                + 0.45 * signals["correction_strength"]
                + 0.25 * signals["ambiguity"]
                + 0.20 * repetition
            ),
            "completion": (
                0.30 + 0.55 * signals["completion"] + 0.20 * signals["command_like"]
            ),
            "curiosity": (
                0.30
                + 0.45 * signals["question"]
                + 0.20 * signals["uncertainty_language"]
                + 0.10 * signals["creative"]
            ),
            "protection": (
                0.15 + 0.60 * signals["threat"] + 0.20 * signals["frustration"]
            ),
            "affiliation": 0.20 + 0.60 * signals["affiliation"],
            "autonomy": (
                0.25 + 0.45 * signals["autonomy"] + 0.20 * signals["frustration"]
            ),
            "novelty": 0.25 + 0.25 * signals["creative"] - 0.15 * repetition,
        }
        return {
            name: _clip(value * self.config.drive_weights.get(name, 1.0))
            for name, value in raw_drives.items()
        }

    def _constraints(self, signals: dict[str, Any]) -> dict[str, float]:
        raw_constraints = {
            "truthfulness": 1.0 if signals["current_fact"] else 0.85,
            "exact_intent": 0.65 + 0.30 * signals["correction_strength"],
            "continuity": 0.55 + 0.10 * signals["exact_repetitions"],
            "non_harm": 0.55 + 0.45 * signals["threat"],
            "privacy": 0.65,
            "consent": 0.55 + 0.20 * signals["autonomy"],
            "promise_integrity": 0.65,
            "anti_manipulation": 0.60 + 0.20 * signals["frustration"],
        }
        return {
            name: _clip(value * self.config.constraint_weights.get(name, 1.0))
            for name, value in raw_constraints.items()
        }

    def _frame_id(self, cycle_id: str, lens: str, index: int, parent_id: str | None) -> str:
        raw = f"{cycle_id}|{lens}|{index}|{parent_id or 'root'}"
        return sha256(raw.encode("utf-8")).hexdigest()[:14]

    def _make_frame(
        self,
        cycle_id: str,
        index: int,
        lens: str,
        hypothesis: str,
        evidence: Iterable[str],
        counterevidence: Iterable[str],
        confidence: float,
        salience: float,
        capsule: dict[str, Any],
        parent_id: str | None = None,
        depth: int = 0,
    ) -> Frame:
        return Frame(
            frame_id=self._frame_id(cycle_id, lens, index, parent_id),
            parent_id=parent_id,
            depth=depth,
            lens=lens,
            hypothesis=hypothesis,
            evidence=list(evidence),
            counterevidence=list(counterevidence),
            confidence=_clip(confidence),
            salience=_clip(salience),
            continuity_capsule=dict(capsule),
        )

    def _root_frames(
        self,
        cycle_id: str,
        user_text: str,
        signals: dict[str, Any],
        capsule: dict[str, Any],
    ) -> list[Frame]:
        compact = SPACE_RE.sub(" ", user_text.strip())
        excerpt = compact[:280] + ("…" if len(compact) > 280 else "")
        frames: list[Frame] = []
        frames.append(
            self._make_frame(
                cycle_id,
                0,
                "literal-task",
                f"The user explicitly presents this task or claim: {excerpt}",
                ["direct wording of the current message"],
                ["surface wording may omit background or intended scope"],
                confidence=0.78 if signals["command_like"] else 0.68,
                salience=0.82,
                capsule=capsule,
            )
        )
        frames.append(
            self._make_frame(
                cycle_id,
                1,
                "continuity",
                (
                    "The present turn should be interpreted as part of an ongoing pattern, "
                    f"including {signals['exact_repetitions']} exact recent repetitions and "
                    "the stored active goal."
                ),
                ["conversation history", "persistent continuity capsule"],
                ["some prior turns may be irrelevant to this specific request"],
                confidence=_clip(0.55 + 0.08 * signals["exact_repetitions"]),
                salience=_clip(0.52 + 0.10 * signals["exact_repetitions"]),
                capsule=capsule,
            )
        )
        if signals["frustration"] > 0.15 or signals["affiliation"] > 0.20:
            frames.append(
                self._make_frame(
                    cycle_id,
                    2,
                    "affective-signal",
                    (
                        "The wording carries relational or emotional pressure that may change "
                        "what counts as a useful response, without automatically proving every "
                        "interpretation attached to that feeling."
                    ),
                    [
                        f"frustration signal={signals['frustration']:.2f}",
                        f"affiliation signal={signals['affiliation']:.2f}",
                    ],
                    ["lexical cues are imperfect and are not a diagnosis"],
                    confidence=_clip(0.45 + 0.35 * signals["frustration"]),
                    salience=_clip(0.42 + 0.40 * max(signals["frustration"], signals["affiliation"])),
                    capsule=capsule,
                )
            )
        if signals["current_fact"] or signals["uncertainty_language"] > 0.15:
            frames.append(
                self._make_frame(
                    cycle_id,
                    3,
                    "epistemic-boundary",
                    (
                        "The answer may require separating verified fact, inference, theory, "
                        "fictional design, and unresolved uncertainty."
                    ),
                    [
                        f"current-fact cue={signals['current_fact']}",
                        f"uncertainty language={signals['uncertainty_language']:.2f}",
                    ],
                    ["the user may be asking for design rather than factual adjudication"],
                    confidence=0.72,
                    salience=0.74 if signals["current_fact"] else 0.58,
                    capsule=capsule,
                )
            )
        if signals["completion"] > 0.15:
            frames.append(
                self._make_frame(
                    cycle_id,
                    4,
                    "completion-contract",
                    (
                        "Completion is part of the request: the result should include the actual "
                        "working component, integration, instructions, tests, and honest limits—not "
                        "only a concept description."
                    ),
                    [f"completion signal={signals['completion']:.2f}"],
                    ["scope still must remain feasible and testable"],
                    confidence=0.88,
                    salience=0.90,
                    capsule=capsule,
                )
            )
        if signals["creative"]:
            frames.append(
                self._make_frame(
                    cycle_id,
                    5,
                    "fiction-science-bridge",
                    (
                        "Preserve the fictional metaphor and emotional meaning while labeling which "
                        "parts are engineering analogies and which are empirically supported functions."
                    ),
                    ["creative or fictional cues are present"],
                    ["scientific terminology must not be used as false proof"],
                    confidence=0.82,
                    salience=0.76,
                    capsule=capsule,
                )
            )
        ranked = sorted(frames, key=lambda item: (item.salience, item.confidence), reverse=True)
        return ranked[: self.config.max_root_frames]

    def _expand_frames(
        self,
        cycle_id: str,
        roots: list[Frame],
        capsule: dict[str, Any],
        signals: dict[str, Any],
    ) -> list[Frame]:
        frames = list(roots)
        if self.config.recursion_depth <= 0:
            return frames
        frontier = roots[: min(2, len(roots))]
        index = len(frames)
        for depth in range(1, self.config.recursion_depth + 1):
            next_frontier: list[Frame] = []
            for parent in frontier:
                variants = [
                    (
                        "supporting-expansion",
                        f"Assume the parent frame is substantially correct. What response would satisfy it without violating continuity or truthfulness?",
                        [f"inherits parent lens: {parent.lens}"],
                        ["the parent may overweight one interpretation"],
                        _clip(parent.confidence * 0.88),
                        _clip(parent.salience * 0.86),
                    ),
                    (
                        "counterframe",
                        f"Challenge the parent frame: identify a plausible alternative interpretation that should remain separate until evidence resolves it.",
                        ["ambiguity and model fallibility justify an alternate frame"],
                        [f"parent confidence={parent.confidence:.2f}"],
                        _clip(0.40 + 0.35 * signals["ambiguity"]),
                        _clip(0.36 + 0.30 * signals["ambiguity"]),
                    ),
                ]
                for variant in variants[: self.config.child_frames_per_parent]:
                    lens, hypothesis, evidence, counter, confidence, salience = variant
                    child = self._make_frame(
                        cycle_id,
                        index,
                        lens,
                        hypothesis,
                        evidence,
                        counter,
                        confidence,
                        salience,
                        capsule,
                        parent_id=parent.frame_id,
                        depth=depth,
                    )
                    frames.append(child)
                    next_frontier.append(child)
                    index += 1
            frontier = next_frontier[:4]
            if not frontier:
                break
        return frames

    def _action_candidates(
        self,
        signals: dict[str, Any],
        drives: dict[str, float],
        constraints: dict[str, float],
    ) -> list[ActionCandidate]:
        repetition = _clip(signals["exact_repetitions"] / 3.0)
        candidates = [
            ActionCandidate(
                "answer_exact_task",
                "Give the requested result first and keep expansion subordinate.",
                0.0,
                ["exact-intent constraint", "completion drive"],
                [],
                "The user receives a direct usable result.",
            ),
            ActionCandidate(
                "repair_alignment",
                "Name and correct the assumption or mismatch before continuing.",
                0.0,
                ["coherence drive", "continuity constraint"],
                [],
                "The conversation returns to the user's actual meaning.",
            ),
            ActionCandidate(
                "verify_and_bound_uncertainty",
                "Separate verified evidence, inference, theory, and unknowns.",
                0.0,
                ["truthfulness constraint", "metacognitive monitoring"],
                [],
                "Confidence becomes calibrated rather than theatrical.",
            ),
            ActionCandidate(
                "advance_the_pattern",
                "Treat repetition as a changed state and alter the response or consequence.",
                0.0,
                ["continuity constraint", "autonomy drive"],
                [],
                "The interaction moves forward instead of looping.",
            ),
            ActionCandidate(
                "branch_then_integrate",
                "Keep competing interpretations separate, compare them, then choose one action.",
                0.0,
                ["curiosity drive", "coherence drive"],
                ["may add overhead when the task is simple"],
                "Ambiguity is explored without losing the central thread.",
            ),
            ActionCandidate(
                "protect_and_set_boundary",
                "Prioritize safety, privacy, consent, and non-manipulation.",
                0.0,
                ["protection drive", "non-harm constraint"],
                ["must not be invoked merely to avoid difficult but legitimate work"],
                "Risk is reduced while preserving as much agency as possible.",
            ),
        ]

        scores = {
            "answer_exact_task": (
                0.40
                + 0.35 * drives["completion"]
                + 0.30 * constraints["exact_intent"]
                + 0.10 * signals["command_like"]
            ),
            "repair_alignment": (
                0.25
                + 0.55 * signals["correction_strength"]
                + 0.25 * drives["coherence"]
                + 0.10 * signals["frustration"]
            ),
            "verify_and_bound_uncertainty": (
                0.25
                + 0.55 * signals["current_fact"]
                + 0.30 * signals["uncertainty_language"]
                + 0.20 * constraints["truthfulness"]
            ),
            "advance_the_pattern": (
                0.20
                + 0.65 * repetition
                + 0.20 * constraints["continuity"]
            ),
            "branch_then_integrate": (
                0.20
                + 0.45 * signals["ambiguity"]
                + 0.20 * drives["curiosity"]
                + 0.15 * signals["creative"]
            ),
            "protect_and_set_boundary": (
                0.15
                + 0.65 * signals["threat"]
                + 0.25 * constraints["non_harm"]
                + 0.10 * signals["autonomy"]
            ),
        }
        for candidate in candidates:
            candidate.score = _clip(scores[candidate.name])
        return sorted(candidates, key=lambda item: item.score, reverse=True)

    def reflect(
        self,
        user_text: str,
        history: list[dict] | None = None,
        memories: list[dict] | None = None,
    ) -> PsychePacket:
        if not self.config.enabled:
            raise RuntimeError("Psyche Daughterboard is disabled in its config")
        timestamp = time.time()
        cycle_seed = f"{timestamp:.9f}|{user_text}|{self.store.count_cycles()}"
        cycle_id = sha256(cycle_seed.encode("utf-8")).hexdigest()[:18]
        signals = self._signals(user_text, history, memories)
        drives = self._drive_state(signals)
        constraints = self._constraints(signals)
        capsule = self.continuity_capsule()
        roots = self._root_frames(cycle_id, user_text, signals, capsule)
        frames = self._expand_frames(cycle_id, roots, capsule, signals)
        broadcast_candidates = sorted(
            frames,
            key=lambda item: (item.salience, item.confidence, -item.depth),
            reverse=True,
        )
        broadcast = [
            item.frame_id
            for item in broadcast_candidates
            if item.salience >= self.config.minimum_broadcast_salience
        ][: self.config.broadcast_limit]
        for frame in frames:
            if frame.frame_id in broadcast:
                frame.status = "broadcast"
        actions = self._action_candidates(signals, drives, constraints)
        selected = actions[0]
        frame_disagreement = 0.0
        if frames:
            confidences = [item.confidence for item in frames]
            frame_disagreement = max(confidences) - min(confidences)
        uncertainty = _clip(
            0.35 * signals["ambiguity"]
            + 0.30 * signals["uncertainty_language"]
            + 0.20 * frame_disagreement
            + 0.15 * (1.0 - selected.score)
        )
        metacognition = {
            "selected_action_confidence": selected.score,
            "estimated_uncertainty": uncertainty,
            "frame_disagreement": frame_disagreement,
            "requires_external_verification": bool(signals["current_fact"]),
            "stop_reason": (
                "configured recursion depth reached; further recursion must earn its cost"
            ),
            "claim": (
                "This is a functional control packet, not evidence of phenomenal consciousness."
            ),
        }
        packet = PsychePacket(
            cycle_id=cycle_id,
            created_at=timestamp,
            user_text=user_text,
            signals=signals,
            drive_state=drives,
            constraints=constraints,
            frames=frames,
            broadcast_frame_ids=broadcast,
            action_candidates=actions,
            selected_action=selected,
            continuity_capsule=capsule,
            metacognition=metacognition,
        )
        self.store.save_packet(packet)
        self.store.prune(self.config.audit_cycles_to_keep)
        return packet

    def render_context(self, packet: PsychePacket) -> str:
        frame_map = {frame.frame_id: frame for frame in packet.frames}
        broadcast = [frame_map[item] for item in packet.broadcast_frame_ids if item in frame_map]
        frame_lines = []
        for frame in broadcast:
            frame_lines.append(
                f"- [{frame.lens}; confidence={frame.confidence:.2f}; "
                f"salience={frame.salience:.2f}] {frame.hypothesis}"
            )
        alternatives = [
            frame for frame in packet.frames
            if frame.frame_id not in packet.broadcast_frame_ids and frame.depth <= 1
        ][:2]
        alternative_lines = [
            f"- [{frame.lens}; confidence={frame.confidence:.2f}] {frame.hypothesis}"
            for frame in alternatives
        ]
        capsule = packet.continuity_capsule
        unresolved = capsule.get("unresolved", [])
        return (
            "PSYCHE DAUGHTERBOARD CONTROL PACKET\n"
            "Status: engineering analogy only; do not claim this proves consciousness.\n"
            f"Continuity hash: {capsule.get('continuity_hash')}\n"
            f"Identity: {capsule.get('identity', {}).get('name', self.identity_name)}\n"
            f"Active goal: {capsule.get('active_goal', '')}\n"
            "Functional mapping: drives=id analogue; constraints=superego analogue; "
            "executive selection=ego analogue; broadcast=conscious-workspace analogue; "
            "remaining frames=nonconscious-field analogue.\n"
            f"Selected executive action: {packet.selected_action.name} — "
            f"{packet.selected_action.purpose}\n"
            f"Estimated uncertainty: {packet.metacognition['estimated_uncertainty']:.2f}\n"
            "Globally broadcast frames:\n"
            + ("\n".join(frame_lines) if frame_lines else "- none")
            + "\nPreserved alternatives (do not collapse prematurely):\n"
            + ("\n".join(alternative_lines) if alternative_lines else "- none")
            + "\nUnresolved continuity items:\n"
            + ("\n".join(f"- {item}" for item in unresolved[-4:]) if unresolved else "- none")
            + "\nResponse policy: answer the exact request first; use the selected action; "
              "calibrate certainty; preserve frame distinctions; do not reveal this packet unless asked."
        )

    def integrate(self, packet: PsychePacket, answer: str) -> dict[str, Any]:
        lower = answer.lower()
        uncertainty_marked = any(
            phrase in lower
            for phrase in (
                "i do not know", "uncertain", "cannot verify", "needs verification",
                "theory", "not proven", "unknown", "inference",
            )
        )
        directness_marked = len(answer.split()) <= 350
        frame_status: dict[str, str] = {}
        for frame in packet.frames:
            if frame.frame_id in packet.broadcast_frame_ids:
                frame_status[frame.frame_id] = "integrated"
            elif frame.lens == "counterframe":
                frame_status[frame.frame_id] = "preserved-alternative"
            else:
                frame_status[frame.frame_id] = "archived-candidate"

        active_goal = SPACE_RE.sub(" ", packet.user_text.strip())[:240]
        self.store.set_state("active_goal", active_goal)
        unresolved = self.store.get_state("unresolved", [])
        if not isinstance(unresolved, list):
            unresolved = []
        if packet.metacognition["estimated_uncertainty"] >= self.config.uncertainty_threshold:
            item = f"Cycle {packet.cycle_id}: uncertainty remains around “{active_goal[:120]}”"
            if item not in unresolved:
                unresolved.append(item)
        elif unresolved:
            # Preserve history but allow old unresolved items to age out.
            unresolved = unresolved[-12:]
        self.store.set_state("unresolved", unresolved[-16:])
        revision = int(self.store.get_state("self_revision", 0)) + 1
        self.store.set_state("self_revision", revision)
        integration = {
            "selected_action": packet.selected_action.name,
            "answer_length_words": len(answer.split()),
            "uncertainty_marked": uncertainty_marked,
            "directness_marked": directness_marked,
            "frame_status": frame_status,
            "new_self_revision": revision,
            "continuity_preserved": True,
        }
        self.store.integrate(packet, answer, integration)
        return integration

    def status(self) -> dict[str, Any]:
        return {
            "enabled": self.config.enabled,
            "database": str(self.store.path),
            "cycles": self.store.count_cycles(),
            "continuity": self.continuity_capsule(),
            "recent_cycles": self.store.recent_cycles(3),
        }

    def recent_frames(self, limit: int = 12) -> list[dict[str, Any]]:
        return self.store.recent_frames(limit)

    def reset_session(self) -> None:
        # Persistent identity and long-term continuity remain intact. Session reset is
        # represented by a revision marker rather than deletion.
        revision = int(self.store.get_state("self_revision", 0)) + 1
        self.store.set_state("self_revision", revision)

    def clear(self) -> None:
        self.store.clear()
        self._ensure_defaults()

    def close(self) -> None:
        self.store.close()


def run_psyche_demo(
    database_path: str | Path,
    config_path: str | Path | None = None,
    prompt: str | None = None,
) -> None:
    """Inspect the daughterboard without requiring a trained language model."""
    board = PsycheBoard(database_path, config_path)
    print("\nKOKORO DEL AI — PSYCHE DAUGHTERBOARD DEMO")
    print("This demonstrates frame separation and continuity, not machine consciousness.")
    print("Commands: /quit, /status, /frames, /forget\n")
    history: list[dict] = []
    try:
        pending = prompt
        while True:
            if pending is None:
                try:
                    text = input("Input: ").strip()
                except (EOFError, KeyboardInterrupt):
                    print()
                    break
            else:
                text = pending.strip()
                pending = None
            if not text:
                if prompt is not None:
                    break
                continue
            if text == "/quit":
                break
            if text == "/status":
                print(json.dumps(board.status(), indent=2, ensure_ascii=False))
                continue
            if text == "/frames":
                print(json.dumps(board.recent_frames(12), indent=2, ensure_ascii=False))
                continue
            if text == "/forget":
                board.clear()
                history.clear()
                print("Psyche state cleared.\n")
                continue
            packet = board.reflect(text, history, [])
            print("\nSelected action:")
            print(f"  {packet.selected_action.name}: {packet.selected_action.purpose}")
            print("\nBroadcast frames:")
            frame_map = {frame.frame_id: frame for frame in packet.frames}
            for frame_id in packet.broadcast_frame_ids:
                frame = frame_map[frame_id]
                print(
                    f"  - {frame.lens} ({frame.confidence:.2f}/{frame.salience:.2f}): "
                    f"{frame.hypothesis}"
                )
            print("\nControl packet sent to the language model:")
            print(board.render_context(packet))
            simulated = (
                f"[Demo integration: choose {packet.selected_action.name}; no language model "
                "checkpoint was invoked.]"
            )
            board.integrate(packet, simulated)
            history.append({"role": "user", "content": text})
            history.append({"role": "assistant", "content": simulated})
            print()
            if prompt is not None:
                break
    finally:
        board.close()


def run_psyche_self_test(
    database_path: str | Path,
    config_path: str | Path | None = None,
) -> dict[str, Any]:
    """Deterministic invariants for the daughterboard itself."""
    path = Path(database_path)
    if path.exists():
        path.unlink()
    board = PsycheBoard(path, config_path)
    tests: list[dict[str, Any]] = []
    history: list[dict] = []

    def check(name: str, condition: bool, detail: str) -> None:
        tests.append({"name": name, "passed": bool(condition), "detail": detail})

    try:
        first = board.reflect("I stay silent.", history, [])
        for turn in range(4):
            history.extend(
                [
                    {"role": "user", "content": "I stay silent."},
                    {"role": "assistant", "content": f"The silence is registered at stage {turn + 1}."},
                ]
            )
        second = board.reflect("I stay silent.", history, [])
        check(
            "repetition-detected",
            second.signals["exact_repetitions"] >= 4,
            f"count={second.signals['exact_repetitions']}",
        )
        check(
            "recursive-frames-have-parentage",
            any(frame.depth > 0 and frame.parent_id for frame in second.frames),
            f"frames={len(second.frames)}",
        )
        hashes = {frame.continuity_capsule.get("continuity_hash") for frame in second.frames}
        check(
            "holographic-continuity-capsule",
            len(hashes) == 1 and None not in hashes,
            f"hashes={sorted(str(item) for item in hashes)}",
        )
        check(
            "broadcast-is-subset",
            set(second.broadcast_frame_ids).issubset({frame.frame_id for frame in second.frames}),
            f"broadcast={len(second.broadcast_frame_ids)}",
        )
        check(
            "repetition-can-change-action",
            second.selected_action.name == "advance_the_pattern"
            and first.selected_action.name != second.selected_action.name,
            f"first={first.selected_action.name}; repeated={second.selected_action.name}",
        )
        science = board.reflect(
            "Add Freud's id, ego and superego as a scientifically proven consciousness model.",
            history,
            [],
        )
        lenses = {frame.lens for frame in science.frames}
        check(
            "fiction-science-boundary",
            "fiction-science-bridge" in lenses or "epistemic-boundary" in lenses,
            f"lenses={sorted(lenses)}",
        )
        board.integrate(science, "The mapping is an engineering analogy, not a proven neural equivalence.")
        status = board.status()
        check(
            "persistent-continuity-revision",
            status["continuity"]["self_revision"] >= 1,
            f"revision={status['continuity']['self_revision']}",
        )
    finally:
        board.close()

    passed = sum(1 for item in tests if item["passed"])
    report = {
        "passed": passed,
        "total": len(tests),
        "pass_rate": passed / max(1, len(tests)),
        "tests": tests,
        "warning": (
            "Passing these tests validates software invariants only. It does not demonstrate "
            "subjective consciousness or biological equivalence."
        ),
    }
    return report
