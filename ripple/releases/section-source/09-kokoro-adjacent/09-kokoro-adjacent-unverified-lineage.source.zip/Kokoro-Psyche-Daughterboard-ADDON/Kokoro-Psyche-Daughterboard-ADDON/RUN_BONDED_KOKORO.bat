@echo off
setlocal
cd /d "%~dp0"
title Kokoro del AI - Bonded Daughterboard
set "BASE=%~dp0..\.."
if not exist "%BASE%\kokoro.py" (
  echo Original Kokoro was not found two folders above this add-on.
  set /p "BASE=Paste the full path to the original Kokoro Foundry: "
  set "BASE=%BASE:"=%"
)
if not exist "%BASE%\kokoro.py" (
  echo Invalid base folder.
  pause
  exit /b 1
)
if not exist "%BASE%\.venv\Scripts\python.exe" (
  echo The original setup has not created .venv yet.
  echo Run the original windows\00_SETUP.bat first.
  pause
  exit /b 1
)
"%BASE%\.venv\Scripts\python.exe" bonded_chat.py chat --base "%BASE%"
pause
