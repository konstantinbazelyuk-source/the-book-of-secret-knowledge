@echo off
setlocal
cd /d "%~dp0"
title Verify Original Kokoro Files
set "BASE=%~dp0..\.."
if exist "%BASE%\.venv\Scripts\python.exe" (
  "%BASE%\.venv\Scripts\python.exe" VERIFY_ORIGINAL_UNCHANGED.py --base "%BASE%"
) else (
  python VERIFY_ORIGINAL_UNCHANGED.py --base "%BASE%"
)
pause
