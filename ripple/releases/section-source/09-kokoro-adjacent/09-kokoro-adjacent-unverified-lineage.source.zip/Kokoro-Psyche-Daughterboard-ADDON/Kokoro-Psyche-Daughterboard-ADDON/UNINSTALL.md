# Removing the add-on

The daughterboard does not replace the original Kokoro files.

To remove it:

1. Close Kokoro.
2. Delete this folder:
   `Kokoro-del-Corazon-Foundry\addons\Kokoro-Psyche-Daughterboard`
3. Continue using the original launchers in the Foundry's `windows` folder.

Deleting the add-on folder also deletes its separate psyche database.
The original Kokoro checkpoint, tokenizer, training data, source code, and
conversation-memory database remain untouched.
