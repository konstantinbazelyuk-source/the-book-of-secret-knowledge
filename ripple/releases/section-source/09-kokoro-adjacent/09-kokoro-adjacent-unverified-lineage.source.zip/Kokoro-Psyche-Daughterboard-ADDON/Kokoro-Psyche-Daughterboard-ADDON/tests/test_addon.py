from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from psyche_board import PsycheBoard

db = ROOT / "state" / "test_psyche.sqlite3"
db.unlink(missing_ok=True)
board = PsycheBoard(db, ROOT / "psyche_config.json", identity_name="Kokoro del AI")

p1 = board.reflect("I stay silent.", [], [])
board.integrate(p1, "The silence is noted.")
p2 = board.reflect(
    "I stay silent.",
    [{"role": "user", "content": "I stay silent."}],
    [{"user_text": "I stay silent.", "assistant_text": "The silence is noted."}],
)

assert p1.continuity_capsule["continuity_hash"] != ""
assert all(
    f.continuity_capsule["continuity_hash"] == p1.continuity_capsule["continuity_hash"]
    for f in p1.frames
)
assert any(f.parent_id is not None for f in p1.frames)
assert p2.signals["exact_repetitions"] >= 1
assert p2.selected_action.name in {
    "advance_the_pattern", "answer_exact_task", "repair_alignment"
}
assert board.status()["cycles"] == 2
board.close()
db.unlink(missing_ok=True)
print("Daughterboard add-on tests passed.")
