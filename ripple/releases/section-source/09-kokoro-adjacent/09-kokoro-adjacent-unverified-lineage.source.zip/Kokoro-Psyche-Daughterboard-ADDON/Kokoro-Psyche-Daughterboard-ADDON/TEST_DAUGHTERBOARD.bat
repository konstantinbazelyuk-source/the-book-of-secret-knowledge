@echo off
setlocal
cd /d "%~dp0"
title Test Kokoro Psyche Daughterboard Add-on
set "BASE=%~dp0..\.."
if exist "%BASE%\.venv\Scripts\python.exe" (
  "%BASE%\.venv\Scripts\python.exe" tests\test_addon.py
) else (
  python tests\test_addon.py
)
pause
