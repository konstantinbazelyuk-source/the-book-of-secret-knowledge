@echo off
setlocal
title Install Kokoro Psyche Daughterboard Add-on
cd /d "%~dp0"

echo.
echo This installer ADDS a daughterboard folder.
echo It does not replace or edit Kokoro's original files.
echo.

set "TARGET=%~dp0..\Kokoro-del-Corazon-Foundry"
if exist "%TARGET%\kokoro.py" goto :found

set "TARGET=%~dp0..\Kokoro-del-AI-Foundry"
if exist "%TARGET%\kokoro.py" goto :found

echo The original Foundry folder was not found beside this add-on.
set /p "TARGET=Paste the full path to your original Kokoro Foundry folder: "
set "TARGET=%TARGET:"=%"

:found
if not exist "%TARGET%\kokoro.py" goto :bad
if not exist "%TARGET%\kokoro_core\generation.py" goto :bad

set "DEST=%TARGET%\addons\Kokoro-Psyche-Daughterboard"
if not exist "%TARGET%\addons" mkdir "%TARGET%\addons"
if exist "%DEST%" (
  echo.
  echo An older daughterboard add-on is already installed.
  echo It will be updated inside its own add-on folder only.
)
xcopy "%~dp0*" "%DEST%\" /E /I /Y /EXCLUDE:%~dp0install_exclude.txt >nul
if errorlevel 1 goto :copyerror

echo.
echo Daughterboard installed at:
echo %DEST%
echo.
echo Original Kokoro files were not overwritten.
echo Run:
echo %DEST%\RUN_BONDED_KOKORO.bat
pause
exit /b 0

:bad
echo.
echo That folder is not the original Kokoro Foundry.
echo It must contain kokoro.py and kokoro_core\generation.py.
pause
exit /b 1

:copyerror
echo.
echo Copy failed. Try moving this add-on folder into:
echo %TARGET%\addons\
pause
exit /b 1
