#!/usr/bin/env python3
from pathlib import Path
import argparse, hashlib, json

ADDON = Path(__file__).resolve().parent

def looks_like_base(p: Path) -> bool:
    return (p / "kokoro.py").is_file() and (p / "kokoro_core" / "generation.py").is_file()

def find_base(explicit=None):
    candidates = []
    if explicit:
        candidates.append(Path(explicit).expanduser().resolve())
    if len(ADDON.parents) >= 2:
        candidates.append(ADDON.parents[1])
    candidates.extend([
        ADDON.parent / "Kokoro-del-Corazon-Foundry",
        ADDON.parent.parent / "Kokoro-del-Corazon-Foundry",
    ])
    for p in candidates:
        if looks_like_base(p):
            return p
    raise FileNotFoundError("Original Kokoro Foundry folder not found.")

parser = argparse.ArgumentParser()
parser.add_argument("--base")
args = parser.parse_args()
base = find_base(args.base)
expected = json.loads((ADDON / "ORIGINAL_BASE_HASHES.json").read_text(encoding="utf-8"))

changed = []
missing = []
for rel, wanted in expected.items():
    p = base / rel
    if not p.exists():
        missing.append(rel)
        continue
    got = hashlib.sha256(p.read_bytes()).hexdigest()
    if got != wanted:
        changed.append(rel)

print(f"Base: {base}")
print(f"Original files checked: {len(expected)}")
print(f"Missing original files: {len(missing)}")
print(f"Changed original files: {len(changed)}")
if missing:
    print("\nMissing:")
    for x in missing:
        print(f"  {x}")
if changed:
    print("\nChanged:")
    for x in changed:
        print(f"  {x}")
if not missing and not changed:
    print("\nPASS: The original Foundry source package is unchanged.")
else:
    print("\nNOTE: Setup-created files are not checked; only original packaged files are compared.")
