#!/usr/bin/env python3
"""
Kokoro Psyche Daughterboard — bonded sidecar launcher.

This file does not replace or edit the original Kokoro Foundry.
It imports the original KokoroEngine at runtime, runs a separate PsycheBoard,
then supplies a compact control packet to the unchanged language engine.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Optional

ADDON_DIR = Path(__file__).resolve().parent
STATE_DIR = ADDON_DIR / "state"
STATE_DIR.mkdir(exist_ok=True)
DEFAULT_BOARD_DB = STATE_DIR / "psyche.sqlite3"
DEFAULT_CONFIG = ADDON_DIR / "psyche_config.json"


def looks_like_base(path: Path) -> bool:
    return (
        path.is_dir()
        and (path / "kokoro.py").is_file()
        and (path / "kokoro_core" / "generation.py").is_file()
        and (path / "configs" / "nano.json").is_file()
    )


def discover_base(explicit: str | None = None) -> Path:
    candidates: list[Path] = []
    if explicit:
        candidates.append(Path(explicit).expanduser().resolve())

    # Installed layout:
    # Kokoro-del-Corazon-Foundry/addons/Kokoro-Psyche-Daughterboard/
    if len(ADDON_DIR.parents) >= 2:
        candidates.append(ADDON_DIR.parents[1])

    # Side-by-side extracted folders.
    candidates.extend(
        [
            ADDON_DIR.parent / "Kokoro-del-Corazon-Foundry",
            ADDON_DIR.parent / "Kokoro-del-AI-Foundry",
            ADDON_DIR.parent.parent / "Kokoro-del-Corazon-Foundry",
            Path.cwd(),
        ]
    )

    seen = set()
    for candidate in candidates:
        candidate = candidate.resolve()
        if candidate in seen:
            continue
        seen.add(candidate)
        if looks_like_base(candidate):
            return candidate

    raise FileNotFoundError(
        "Could not locate the original Kokoro Foundry folder.\n"
        "Run with: python bonded_chat.py --base \"C:\\path\\to\\Kokoro-del-Corazon-Foundry\""
    )


def load_base(base_dir: Path):
    if str(base_dir) not in sys.path:
        sys.path.insert(0, str(base_dir))
    import kokoro as base_cli
    from kokoro_core.generation import KokoroEngine
    return base_cli, KokoroEngine


def load_board():
    if str(ADDON_DIR) not in sys.path:
        sys.path.insert(0, str(ADDON_DIR))
    from psyche_board import PsycheBoard
    return PsycheBoard


class BondedKokoro:
    """Bonds a separate daughterboard to the unchanged original engine."""

    def __init__(
        self,
        base_dir: Path,
        checkpoint: Optional[Path],
        device: str,
        board_enabled: bool = True,
    ):
        base_cli, KokoroEngine = load_base(base_dir)
        base_paths = base_cli.paths()
        selected_checkpoint = base_cli.find_checkpoint(
            str(checkpoint) if checkpoint else None
        )
        self.engine = KokoroEngine(
            selected_checkpoint,
            base_paths["tokenizer"],
            base_paths["memory"],
            device_arg=device,
        )
        PsycheBoard = load_board()
        self.board = PsycheBoard(
            DEFAULT_BOARD_DB,
            DEFAULT_CONFIG,
            identity_name="Kokoro del AI",
        )
        self.base_dir = base_dir
        self.board_enabled = board_enabled
        self.original_system_prompt = self.engine.system_prompt
        self.last_packet = None
        self.last_integration = None

    def generate(
        self,
        user_text: str,
        max_new_tokens: int = 256,
        temperature: float = 0.8,
        top_k: int = 50,
        top_p: float = 0.95,
        stream_callback=None,
    ) -> str:
        packet = None
        if self.board_enabled:
            memories = self.engine.memory.search(user_text, limit=6)
            packet = self.board.reflect(
                user_text,
                history=list(self.engine.history),
                memories=memories,
            )
            board_context = self.board.render_context(packet)
            self.engine.system_prompt = (
                self.original_system_prompt
                + "\n\n"
                + board_context
            )
        else:
            self.engine.system_prompt = self.original_system_prompt

        try:
            answer = self.engine.generate(
                user_text,
                max_new_tokens=max_new_tokens,
                temperature=temperature,
                top_k=top_k,
                top_p=top_p,
                stream_callback=stream_callback,
            )
        finally:
            self.engine.system_prompt = self.original_system_prompt

        if packet is not None:
            self.last_packet = packet
            self.last_integration = self.board.integrate(packet, answer)
        return answer

    def close(self):
        self.engine.close()
        self.board.close()


def print_packet(app: BondedKokoro) -> None:
    if app.last_packet is None:
        print("No daughterboard cycle has run yet.\n")
        return
    packet = app.last_packet
    print("\nDAUGHTERBOARD LAST CYCLE")
    print(f"Cycle: {packet.cycle_id}")
    print(f"Continuity: {packet.continuity_capsule.get('continuity_hash')}")
    print(
        f"Executive action: {packet.selected_action.name} "
        f"({packet.selected_action.score:.2f})"
    )
    print("Broadcast frames:")
    frame_map = {f.frame_id: f for f in packet.frames}
    for frame_id in packet.broadcast_frame_ids:
        frame = frame_map.get(frame_id)
        if frame:
            print(
                f"  - {frame.lens}: {frame.hypothesis} "
                f"[confidence={frame.confidence:.2f}]"
            )
    print()


def run_chat(args: argparse.Namespace) -> None:
    base_dir = discover_base(args.base)
    checkpoint = Path(args.checkpoint).expanduser().resolve() if args.checkpoint else None
    app = BondedKokoro(
        base_dir,
        checkpoint,
        device=args.device,
        board_enabled=not args.board_off,
    )
    print("\nKOKORO DEL AI — BONDED MODE")
    print(f"Original brain: {base_dir}")
    print(f"Daughterboard: {ADDON_DIR}")
    print(f"Daughterboard enabled: {app.board_enabled}")
    print("The original model files are not modified.")
    print(
        "Commands: /quit, /reset, /memory, /psyche, /frames, "
        "/board on, /board off, /forget-board, /forget-all\n"
    )
    try:
        while True:
            try:
                text = input("You: ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                break
            if not text:
                continue
            lowered = text.lower()
            if lowered == "/quit":
                break
            if lowered == "/reset":
                app.engine.reset_context()
                app.board.reset_session()
                print("Current context reset; both long-term stores retained.\n")
                continue
            if lowered == "/memory":
                print(
                    f"Language-memory turns: {app.engine.memory.count()}; "
                    f"daughterboard cycles: {app.board.status()['cycles']}\n"
                )
                continue
            if lowered == "/psyche":
                print_packet(app)
                continue
            if lowered == "/frames":
                frames = app.board.recent_frames(12)
                if not frames:
                    print("No stored daughterboard frames.\n")
                else:
                    print()
                    for frame in frames:
                        print(
                            f"- {frame.get('frame_id')} | {frame.get('lens')} | "
                            f"{frame.get('status')} | {frame.get('hypothesis')}"
                        )
                    print()
                continue
            if lowered == "/board on":
                app.board_enabled = True
                print("Daughterboard attached.\n")
                continue
            if lowered == "/board off":
                app.board_enabled = False
                print("Daughterboard bypassed. Original Kokoro runs alone.\n")
                continue
            if lowered == "/forget-board":
                app.board.clear()
                print("Daughterboard state deleted; original Kokoro memory retained.\n")
                continue
            if lowered == "/forget-all":
                app.engine.forget_all()
                app.board.clear()
                print("Both original conversation memory and daughterboard state deleted.\n")
                continue

            print("Kokoro: ", end="", flush=True)

            def stream(piece: str) -> None:
                print(piece, end="", flush=True)

            app.generate(
                text,
                max_new_tokens=args.max_new_tokens,
                temperature=args.temperature,
                top_k=args.top_k,
                top_p=args.top_p,
                stream_callback=stream,
            )
            print("\n")
    finally:
        app.close()


def run_demo(args: argparse.Namespace) -> None:
    PsycheBoard = load_board()
    from psyche_board import run_psyche_demo
    run_psyche_demo(DEFAULT_BOARD_DB, DEFAULT_CONFIG, prompt=args.prompt)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Attach the Psyche Daughterboard to the original Kokoro Foundry."
    )
    sub = parser.add_subparsers(dest="command", required=True)

    chat = sub.add_parser("chat", help="Run original Kokoro plus daughterboard.")
    chat.add_argument("--base")
    chat.add_argument("--checkpoint")
    chat.add_argument("--device", default="auto")
    chat.add_argument("--temperature", type=float, default=0.8)
    chat.add_argument("--top-k", type=int, default=50)
    chat.add_argument("--top-p", type=float, default=0.95)
    chat.add_argument("--max-new-tokens", type=int, default=256)
    chat.add_argument("--board-off", action="store_true")
    chat.set_defaults(func=run_chat)

    demo = sub.add_parser("demo", help="Run daughterboard without a trained model.")
    demo.add_argument("--prompt")
    demo.set_defaults(func=run_demo)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    try:
        args.func(args)
    except FileNotFoundError as exc:
        print(f"\nERROR: {exc}\n")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
