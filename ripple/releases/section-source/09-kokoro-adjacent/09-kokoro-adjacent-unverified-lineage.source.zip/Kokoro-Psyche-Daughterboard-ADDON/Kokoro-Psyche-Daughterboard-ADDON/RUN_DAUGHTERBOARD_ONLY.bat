@echo off
setlocal
cd /d "%~dp0"
title Kokoro Psyche Daughterboard Demo
set "BASE=%~dp0..\.."
if exist "%BASE%\.venv\Scripts\python.exe" (
  "%BASE%\.venv\Scripts\python.exe" bonded_chat.py demo
) else (
  python bonded_chat.py demo
)
pause
