@echo off
title Kokoro del Korazon Setup
echo Installing Kokoro del Korazon requirements...
python --version
if errorlevel 1 (
  echo Python was not found. Install Python 3.11 or 3.12 and check Add Python to PATH.
  pause
  exit /b 1
)
python -m pip install --upgrade pip
python -m pip install torch
echo.
echo Setup complete.
python kokoro_del_korazon.py status
pause
