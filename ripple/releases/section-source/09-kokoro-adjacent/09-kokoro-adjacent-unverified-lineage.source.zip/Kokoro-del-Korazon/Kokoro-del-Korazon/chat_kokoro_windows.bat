@echo off
title Kokoro del Korazon
python kokoro_del_korazon.py chat
pause
