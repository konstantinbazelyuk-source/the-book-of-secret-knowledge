@echo off
title Train Kokoro del Korazon
echo Kokoro del Korazon will train from random weights.
echo You can stop with Ctrl+C; it will save a checkpoint.
python kokoro_del_korazon.py train --quick
pause
