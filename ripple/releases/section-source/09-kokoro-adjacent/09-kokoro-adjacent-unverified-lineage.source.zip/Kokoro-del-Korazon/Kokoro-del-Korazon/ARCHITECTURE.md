# Kokoro del Korazon Central Design

## One cycle

```text
UTF-8 text
→ owned byte tokenizer
→ token and position embeddings
→ causal self-attention blocks
→ next-token probability distribution
→ sampled token
→ generated answer
→ local memory
→ future training corrections
```

## Why byte tokens

A byte tokenizer has a fixed 262-token vocabulary and can represent every UTF-8 language without borrowing another model's vocabulary. It is less efficient than a carefully trained subword tokenizer, but it makes the first model independent, inspectable, and difficult to break on unknown words.

## Model

The implementation is a decoder-only Transformer:

- learned token embeddings
- learned positional embeddings
- pre-normalized residual blocks
- multi-head masked self-attention
- GELU feed-forward networks
- tied input/output embedding weights
- AdamW optimization
- gradient clipping
- cosine learning-rate decay
- train/validation split
- atomic checkpoints

## Current laptop profile

Quick mode:

- 3 layers
- 4 attention heads
- 128-dimensional embeddings
- 192-byte context
- roughly 0.8 million parameters

This size proves the system end to end. It is not expected to contain broad knowledge.

## Scaling without changing the design

Example:

```bash
python kokoro_del_korazon.py train --layers 8 --heads 8 --width 512 --block-size 512 --batch-size 8 --steps 100000
```

Do not select a larger configuration until the hardware and dataset justify it.

## Superiority target

Kokoro del Korazon should not claim universal superiority before measurement. Build evaluations for:

1. preserving the user's exact intent
2. changing behavior under repeated input
3. long-term continuity
4. non-looping character action
5. honest uncertainty
6. useful artifacts and decisions
7. preservation of intentional unusual language

Train against these tests. A smaller model can beat a larger general model on a carefully defined domain.
