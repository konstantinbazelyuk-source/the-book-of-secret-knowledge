#!/usr/bin/env python3
"""
Kokoro del Korazon
A small, offline, decoder-only Transformer trained from random initialization.

This program does not download or call a pretrained language model or hosted AI.
It owns:
- a byte-level tokenizer
- a GPT-style causal Transformer
- training and checkpoint code
- local conversation memory
- interactive generation
- evaluation and dataset import

License: MIT
"""

from __future__ import annotations

import argparse
import json
import math
import os
import random
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
except ImportError:
    print("\nPyTorch is not installed.")
    print("Run setup_windows.bat on Windows, or:")
    print("  python -m pip install torch\n")
    raise SystemExit(1)

APP_DIR = Path(__file__).resolve().parent
DATA_DIR = APP_DIR / "data"
CHECKPOINT_DIR = APP_DIR / "checkpoints"
MEMORY_FILE = APP_DIR / "memory.jsonl"
CORPUS_FILE = DATA_DIR / "corpus.txt"
CHECKPOINT_FILE = CHECKPOINT_DIR / "kokoro_del_korazon.pt"

# Byte IDs 0..255 are literal UTF-8 bytes.
BOS = 256
EOS = 257
USER = 258
ASSISTANT = 259
MEMORY = 260
EOT = 261
VOCAB_SIZE = 262

SPECIAL_NAMES = {
    BOS: "<|bos|>",
    EOS: "<|eos|>",
    USER: "<|user|>",
    ASSISTANT: "<|assistant|>",
    MEMORY: "<|memory|>",
    EOT: "<|eot|>",
}


class ByteTokenizer:
    """A deterministic tokenizer owned by this project."""

    vocab_size = VOCAB_SIZE

    def encode_text(self, text: str) -> list[int]:
        return list(text.encode("utf-8", errors="replace"))

    def decode(self, ids: Iterable[int], hide_special: bool = True) -> str:
        out = bytearray()
        pieces: list[str] = []

        def flush() -> None:
            nonlocal out
            if out:
                pieces.append(out.decode("utf-8", errors="replace"))
                out = bytearray()

        for token in ids:
            token = int(token)
            if 0 <= token <= 255:
                out.append(token)
            else:
                flush()
                if not hide_special:
                    pieces.append(SPECIAL_NAMES.get(token, f"<|{token}|>"))
        flush()
        return "".join(pieces)

    def encode_training_text(self, text: str) -> list[int]:
        """
        Converts readable corpus markers:
          User: ...
          Kokoro del Korazon: ...
        into special-token conversation records.
        """
        ids: list[int] = [BOS]
        lines = text.replace("\r\n", "\n").splitlines()
        for line in lines:
            if line.startswith("User:"):
                ids.extend([USER])
                ids.extend(self.encode_text(line[5:].lstrip()))
                ids.append(EOT)
            elif line.startswith("Kokoro del Korazon:"):
                ids.extend([ASSISTANT])
                ids.extend(self.encode_text(line[9:].lstrip()))
                ids.append(EOT)
            elif line.startswith("Memory:"):
                ids.extend([MEMORY])
                ids.extend(self.encode_text(line[7:].lstrip()))
                ids.append(EOT)
            else:
                ids.extend(self.encode_text(line + "\n"))
        ids.append(EOS)
        return ids


@dataclass
class ModelConfig:
    vocab_size: int = VOCAB_SIZE
    block_size: int = 256
    n_layer: int = 4
    n_head: int = 6
    n_embd: int = 192
    dropout: float = 0.1


@dataclass
class TrainConfig:
    batch_size: int = 24
    steps: int = 2000
    learning_rate: float = 3e-4
    weight_decay: float = 0.1
    eval_interval: int = 100
    eval_batches: int = 20
    grad_clip: float = 1.0
    seed: int = 1337


class CausalSelfAttention(nn.Module):
    def __init__(self, config: ModelConfig):
        super().__init__()
        if config.n_embd % config.n_head != 0:
            raise ValueError("n_embd must be divisible by n_head")
        self.n_head = config.n_head
        self.head_dim = config.n_embd // config.n_head
        self.qkv = nn.Linear(config.n_embd, 3 * config.n_embd, bias=False)
        self.proj = nn.Linear(config.n_embd, config.n_embd, bias=False)
        self.attn_dropout = nn.Dropout(config.dropout)
        self.resid_dropout = nn.Dropout(config.dropout)
        mask = torch.tril(torch.ones(config.block_size, config.block_size, dtype=torch.bool))
        self.register_buffer("causal_mask", mask.view(1, 1, config.block_size, config.block_size))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, t, c = x.shape
        q, k, v = self.qkv(x).split(c, dim=2)
        q = q.view(b, t, self.n_head, self.head_dim).transpose(1, 2)
        k = k.view(b, t, self.n_head, self.head_dim).transpose(1, 2)
        v = v.view(b, t, self.n_head, self.head_dim).transpose(1, 2)
        scale = 1.0 / math.sqrt(self.head_dim)
        att = (q @ k.transpose(-2, -1)) * scale
        att = att.masked_fill(~self.causal_mask[:, :, :t, :t], float("-inf"))
        att = F.softmax(att, dim=-1)
        att = self.attn_dropout(att)
        y = att @ v
        y = y.transpose(1, 2).contiguous().view(b, t, c)
        return self.resid_dropout(self.proj(y))


class MLP(nn.Module):
    def __init__(self, config: ModelConfig):
        super().__init__()
        hidden = 4 * config.n_embd
        self.net = nn.Sequential(
            nn.Linear(config.n_embd, hidden, bias=False),
            nn.GELU(),
            nn.Linear(hidden, config.n_embd, bias=False),
            nn.Dropout(config.dropout),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class Block(nn.Module):
    def __init__(self, config: ModelConfig):
        super().__init__()
        self.ln1 = nn.LayerNorm(config.n_embd)
        self.attn = CausalSelfAttention(config)
        self.ln2 = nn.LayerNorm(config.n_embd)
        self.mlp = MLP(config)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x + self.attn(self.ln1(x))
        x = x + self.mlp(self.ln2(x))
        return x


class Kokoro del KorazonModel(nn.Module):
    def __init__(self, config: ModelConfig):
        super().__init__()
        self.config = config
        self.token_embedding = nn.Embedding(config.vocab_size, config.n_embd)
        self.position_embedding = nn.Embedding(config.block_size, config.n_embd)
        self.dropout = nn.Dropout(config.dropout)
        self.blocks = nn.ModuleList([Block(config) for _ in range(config.n_layer)])
        self.final_norm = nn.LayerNorm(config.n_embd)
        self.lm_head = nn.Linear(config.n_embd, config.vocab_size, bias=False)
        self.lm_head.weight = self.token_embedding.weight
        self.apply(self._init_weights)

    @staticmethod
    def _init_weights(module: nn.Module) -> None:
        if isinstance(module, nn.Linear):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)
        elif isinstance(module, nn.Embedding):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)

    def forward(
        self, tokens: torch.Tensor, targets: torch.Tensor | None = None
    ) -> tuple[torch.Tensor, torch.Tensor | None]:
        b, t = tokens.shape
        if t > self.config.block_size:
            raise ValueError(f"Sequence length {t} exceeds block size {self.config.block_size}")
        positions = torch.arange(t, device=tokens.device)
        x = self.token_embedding(tokens) + self.position_embedding(positions)
        x = self.dropout(x)
        for block in self.blocks:
            x = block(x)
        logits = self.lm_head(self.final_norm(x))
        loss = None
        if targets is not None:
            loss = F.cross_entropy(
                logits.reshape(-1, logits.size(-1)),
                targets.reshape(-1),
            )
        return logits, loss

    @torch.inference_mode()
    def generate(
        self,
        prompt: list[int],
        device: torch.device,
        max_new_tokens: int = 220,
        temperature: float = 0.85,
        top_k: int = 50,
        repetition_penalty: float = 1.12,
    ) -> list[int]:
        self.eval()
        generated = list(prompt)
        recent_counts: dict[int, int] = {}
        for token in generated[-128:]:
            recent_counts[token] = recent_counts.get(token, 0) + 1

        for _ in range(max_new_tokens):
            context = generated[-self.config.block_size :]
            x = torch.tensor([context], dtype=torch.long, device=device)
            logits, _ = self(x)
            logits = logits[0, -1] / max(temperature, 1e-5)

            # Discourage immediate loops without banning useful words.
            for token, count in recent_counts.items():
                if 0 <= token < logits.numel() and count > 0:
                    value = logits[token]
                    logits[token] = (
                        value / repetition_penalty
                        if value > 0
                        else value * repetition_penalty
                    )

            # Do not generate structural tokens other than end-of-turn.
            for forbidden in (BOS, EOS, USER, ASSISTANT, MEMORY):
                logits[forbidden] = float("-inf")

            if top_k > 0:
                k = min(top_k, logits.numel())
                cutoff = torch.topk(logits, k).values[-1]
                logits[logits < cutoff] = float("-inf")

            probabilities = F.softmax(logits, dim=-1)
            next_token = int(torch.multinomial(probabilities, 1).item())
            if next_token in (EOT, EOS):
                break
            generated.append(next_token)
            recent_counts[next_token] = recent_counts.get(next_token, 0) + 1

        return generated[len(prompt) :]


def choose_device() -> torch.device:
    if torch.cuda.is_available():
        return torch.device("cuda")
    if getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


def ensure_directories() -> None:
    DATA_DIR.mkdir(exist_ok=True)
    CHECKPOINT_DIR.mkdir(exist_ok=True)


def parameter_count(model: nn.Module) -> int:
    return sum(p.numel() for p in model.parameters())


def read_corpus(tokenizer: ByteTokenizer) -> torch.Tensor:
    if not CORPUS_FILE.exists():
        raise FileNotFoundError(
            f"Missing {CORPUS_FILE}. Keep the data folder beside kokoro_del_korazon.py."
        )
    text = CORPUS_FILE.read_text(encoding="utf-8", errors="replace")
    if len(text.strip()) < 500:
        raise ValueError("The corpus is too small. Add more text to data/corpus.txt.")
    tokens = tokenizer.encode_training_text(text)
    # Repeat a tiny seed corpus enough to make random block sampling possible.
    while len(tokens) < 10_000:
        tokens = tokens + tokens
    return torch.tensor(tokens, dtype=torch.long)


def split_data(data: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    cut = int(0.92 * len(data))
    return data[:cut], data[cut:]


def get_batch(
    data: torch.Tensor,
    batch_size: int,
    block_size: int,
    device: torch.device,
) -> tuple[torch.Tensor, torch.Tensor]:
    if len(data) <= block_size + 1:
        raise ValueError("Corpus is shorter than the configured block size.")
    starts = torch.randint(0, len(data) - block_size - 1, (batch_size,))
    x = torch.stack([data[i : i + block_size] for i in starts])
    y = torch.stack([data[i + 1 : i + block_size + 1] for i in starts])
    return x.to(device), y.to(device)


@torch.inference_mode()
def estimate_loss(
    model: Kokoro del KorazonModel,
    train_data: torch.Tensor,
    val_data: torch.Tensor,
    train_cfg: TrainConfig,
    model_cfg: ModelConfig,
    device: torch.device,
) -> dict[str, float]:
    model.eval()
    result = {}
    for name, dataset in (("train", train_data), ("validation", val_data)):
        losses = []
        for _ in range(train_cfg.eval_batches):
            x, y = get_batch(
                dataset, train_cfg.batch_size, model_cfg.block_size, device
            )
            _, loss = model(x, y)
            losses.append(float(loss.item()))
        result[name] = sum(losses) / len(losses)
    model.train()
    return result


def save_checkpoint(
    model: Kokoro del KorazonModel,
    optimizer: torch.optim.Optimizer,
    model_cfg: ModelConfig,
    train_cfg: TrainConfig,
    step: int,
    best_val: float,
) -> None:
    ensure_directories()
    payload = {
        "model_state": model.state_dict(),
        "optimizer_state": optimizer.state_dict(),
        "model_config": asdict(model_cfg),
        "train_config": asdict(train_cfg),
        "step": step,
        "best_val": best_val,
        "format_version": 1,
    }
    temp = CHECKPOINT_FILE.with_suffix(".tmp")
    torch.save(payload, temp)
    temp.replace(CHECKPOINT_FILE)


def load_checkpoint(
    device: torch.device,
) -> tuple[Kokoro del KorazonModel, dict]:
    if not CHECKPOINT_FILE.exists():
        raise FileNotFoundError(
            "\nNo trained checkpoint exists yet.\n"
            "Run: python kokoro_del_korazon.py train --quick\n"
            "Then run: python kokoro_del_korazon.py chat\n"
        )
    payload = torch.load(CHECKPOINT_FILE, map_location=device, weights_only=False)
    model_cfg = ModelConfig(**payload["model_config"])
    model = Kokoro del KorazonModel(model_cfg).to(device)
    model.load_state_dict(payload["model_state"])
    model.eval()
    return model, payload


def cosine_lr(step: int, total_steps: int, peak_lr: float) -> float:
    warmup = max(10, int(total_steps * 0.03))
    if step < warmup:
        return peak_lr * (step + 1) / warmup
    progress = (step - warmup) / max(1, total_steps - warmup)
    return peak_lr * (0.1 + 0.9 * 0.5 * (1.0 + math.cos(math.pi * progress)))


def train(args: argparse.Namespace) -> None:
    ensure_directories()
    tokenizer = ByteTokenizer()
    device = choose_device()

    if args.quick:
        model_cfg = ModelConfig(block_size=192, n_layer=3, n_head=4, n_embd=128)
        train_cfg = TrainConfig(
            batch_size=12 if device.type == "cpu" else 32,
            steps=args.steps or 500,
            eval_interval=50,
            eval_batches=8,
            learning_rate=4e-4,
        )
    else:
        model_cfg = ModelConfig(
            block_size=args.block_size,
            n_layer=args.layers,
            n_head=args.heads,
            n_embd=args.width,
        )
        train_cfg = TrainConfig(
            batch_size=args.batch_size,
            steps=args.steps or 2000,
            learning_rate=args.learning_rate,
        )

    random.seed(train_cfg.seed)
    torch.manual_seed(train_cfg.seed)
    if device.type == "cuda":
        torch.cuda.manual_seed_all(train_cfg.seed)

    data = read_corpus(tokenizer)
    train_data, val_data = split_data(data)
    model = Kokoro del KorazonModel(model_cfg).to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=train_cfg.learning_rate,
        weight_decay=train_cfg.weight_decay,
        betas=(0.9, 0.95),
    )

    start_step = 0
    best_val = float("inf")
    if args.resume and CHECKPOINT_FILE.exists():
        prior = torch.load(CHECKPOINT_FILE, map_location=device, weights_only=False)
        if prior["model_config"] != asdict(model_cfg):
            print("Checkpoint architecture differs; starting a new model.")
        else:
            model.load_state_dict(prior["model_state"])
            optimizer.load_state_dict(prior["optimizer_state"])
            start_step = int(prior["step"]) + 1
            best_val = float(prior.get("best_val", best_val))
            print(f"Resuming from step {start_step}.")

    print("\nKOKORO DEL KORAZON TRAINING")
    print(f"Device: {device}")
    print(f"Parameters: {parameter_count(model):,}")
    print(f"Training tokens: {len(train_data):,}")
    print(f"Validation tokens: {len(val_data):,}")
    print(f"Steps: {train_cfg.steps}")
    print("Press Ctrl+C to stop safely after the next checkpoint.\n")

    model.train()
    started = time.time()
    try:
        for step in range(start_step, train_cfg.steps):
            lr = cosine_lr(step, train_cfg.steps, train_cfg.learning_rate)
            for group in optimizer.param_groups:
                group["lr"] = lr

            x, y = get_batch(
                train_data, train_cfg.batch_size, model_cfg.block_size, device
            )
            _, loss = model(x, y)
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), train_cfg.grad_clip)
            optimizer.step()

            should_evaluate = (
                step == start_step
                or (step + 1) % train_cfg.eval_interval == 0
                or step + 1 == train_cfg.steps
            )
            if should_evaluate:
                losses = estimate_loss(
                    model, train_data, val_data, train_cfg, model_cfg, device
                )
                elapsed = time.time() - started
                print(
                    f"step {step + 1:>5}/{train_cfg.steps} | "
                    f"train {losses['train']:.4f} | "
                    f"validation {losses['validation']:.4f} | "
                    f"lr {lr:.2e} | {elapsed:.0f}s"
                )
                if losses["validation"] <= best_val:
                    best_val = losses["validation"]
                save_checkpoint(
                    model, optimizer, model_cfg, train_cfg, step, best_val
                )
    except KeyboardInterrupt:
        print("\nStopping training and saving the current model...")
        save_checkpoint(
            model, optimizer, model_cfg, train_cfg, step, best_val
        )

    print(f"\nSaved model to: {CHECKPOINT_FILE}")
    print("Start it with: python kokoro_del_korazon.py chat")


def load_memories(limit: int = 10) -> list[dict]:
    if not MEMORY_FILE.exists():
        return []
    records = []
    for line in MEMORY_FILE.read_text(encoding="utf-8", errors="replace").splitlines():
        try:
            records.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return records[-limit:]


def save_memory(user_text: str, answer: str) -> None:
    record = {
        "time": time.strftime("%Y-%m-%d %H:%M:%S"),
        "user": user_text,
        "fireclay": answer,
    }
    with MEMORY_FILE.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, ensure_ascii=False) + "\n")


def make_prompt(
    tokenizer: ByteTokenizer,
    user_text: str,
    history: list[tuple[str, str]],
    memory_limit: int,
) -> list[int]:
    tokens = [BOS]
    memories = load_memories(memory_limit)
    if memories:
        summary_lines = []
        for item in memories[-memory_limit:]:
            summary_lines.append(
                f"Earlier, User said: {item.get('user', '')}\n"
                f"Kokoro del Korazon answered: {item.get('fireclay', '')}"
            )
        tokens.append(MEMORY)
        tokens.extend(tokenizer.encode_text("\n".join(summary_lines)))
        tokens.append(EOT)

    for prior_user, prior_answer in history[-3:]:
        tokens.append(USER)
        tokens.extend(tokenizer.encode_text(prior_user))
        tokens.append(EOT)
        tokens.append(ASSISTANT)
        tokens.extend(tokenizer.encode_text(prior_answer))
        tokens.append(EOT)

    tokens.append(USER)
    tokens.extend(tokenizer.encode_text(user_text))
    tokens.append(EOT)
    tokens.append(ASSISTANT)
    return tokens


def chat(args: argparse.Namespace) -> None:
    tokenizer = ByteTokenizer()
    device = choose_device()
    model, payload = load_checkpoint(device)
    history: list[tuple[str, str]] = []

    print("\nKOKORO DEL KORAZON — OFFLINE")
    print(f"Device: {device}")
    print(f"Model parameters: {parameter_count(model):,}")
    print("Commands: /quit, /clear, /memory, /forget\n")

    while True:
        try:
            user_text = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye.")
            break

        if not user_text:
            continue
        if user_text == "/quit":
            break
        if user_text == "/clear":
            history.clear()
            print("Current conversation cleared.")
            continue
        if user_text == "/memory":
            memories = load_memories(20)
            if not memories:
                print("No saved memories.")
            for item in memories:
                print(f"- {item.get('time')}: {item.get('user')}")
            continue
        if user_text == "/forget":
            MEMORY_FILE.unlink(missing_ok=True)
            history.clear()
            print("All conversation memory deleted.")
            continue

        prompt = make_prompt(tokenizer, user_text, history, args.memory)
        answer_ids = model.generate(
            prompt,
            device=device,
            max_new_tokens=args.max_tokens,
            temperature=args.temperature,
            top_k=args.top_k,
            repetition_penalty=args.repetition_penalty,
        )
        answer = tokenizer.decode(answer_ids).strip()
        if not answer:
            answer = "[The model produced no readable text. Continue training it.]"

        print(f"Kokoro del Korazon: {answer}\n")
        history.append((user_text, answer))
        save_memory(user_text, answer)


def add_data(args: argparse.Namespace) -> None:
    ensure_directories()
    source = Path(args.file).expanduser().resolve()
    if not source.exists():
        raise FileNotFoundError(source)
    text = source.read_text(encoding="utf-8", errors="replace").strip()
    if not text:
        raise ValueError("The added file is empty.")
    with CORPUS_FILE.open("a", encoding="utf-8") as handle:
        handle.write("\n\n" + text + "\n")
    print(f"Added {len(text):,} characters from {source.name}.")
    print("Retrain with: python kokoro_del_korazon.py train --resume")


@torch.inference_mode()
def evaluate(args: argparse.Namespace) -> None:
    tokenizer = ByteTokenizer()
    device = choose_device()
    model, _ = load_checkpoint(device)
    prompts = [
        "Who are you?",
        "I pressed the same button twenty times. Do something different.",
        "Explain the difference between memory and repetition.",
        "Write one strange but meaningful sentence.",
    ]
    print("\nKOKORO DEL KORAZON EVALUATION\n")
    for prompt_text in prompts:
        prompt = make_prompt(tokenizer, prompt_text, [], 0)
        answer = tokenizer.decode(
            model.generate(
                prompt,
                device,
                max_new_tokens=160,
                temperature=0.75,
                top_k=40,
                repetition_penalty=1.15,
            )
        ).strip()
        print(f"PROMPT: {prompt_text}")
        print(f"ANSWER: {answer}\n")
    print("Evaluation is qualitative at this stage. Save results between training runs.")


def status(_: argparse.Namespace) -> None:
    ensure_directories()
    print("\nKOKORO DEL KORAZON STATUS")
    print(f"Python: {sys.version.split()[0]}")
    print(f"PyTorch: {torch.__version__}")
    print(f"Device: {choose_device()}")
    print(f"Corpus: {CORPUS_FILE}")
    print(f"Corpus exists: {CORPUS_FILE.exists()}")
    if CORPUS_FILE.exists():
        print(f"Corpus size: {CORPUS_FILE.stat().st_size:,} bytes")
    print(f"Checkpoint exists: {CHECKPOINT_FILE.exists()}")
    if CHECKPOINT_FILE.exists():
        model, payload = load_checkpoint(choose_device())
        print(f"Parameters: {parameter_count(model):,}")
        print(f"Last completed step: {int(payload.get('step', -1)) + 1}")
        print(f"Best validation loss: {payload.get('best_val', 'unknown')}")
    print(f"Memory records: {len(load_memories(1_000_000))}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Train and run Kokoro del Korazon, an offline Transformer built from scratch."
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_train = sub.add_parser("train", help="Train weights from random initialization.")
    p_train.add_argument("--quick", action="store_true", help="Use a small laptop-friendly model.")
    p_train.add_argument("--resume", action="store_true", help="Continue a compatible checkpoint.")
    p_train.add_argument("--steps", type=int, default=None)
    p_train.add_argument("--batch-size", type=int, default=24)
    p_train.add_argument("--block-size", type=int, default=256)
    p_train.add_argument("--layers", type=int, default=4)
    p_train.add_argument("--heads", type=int, default=6)
    p_train.add_argument("--width", type=int, default=192)
    p_train.add_argument("--learning-rate", type=float, default=3e-4)
    p_train.set_defaults(func=train)

    p_chat = sub.add_parser("chat", help="Talk to a trained local checkpoint.")
    p_chat.add_argument("--temperature", type=float, default=0.85)
    p_chat.add_argument("--top-k", type=int, default=50)
    p_chat.add_argument("--max-tokens", type=int, default=220)
    p_chat.add_argument("--repetition-penalty", type=float, default=1.12)
    p_chat.add_argument("--memory", type=int, default=5)
    p_chat.set_defaults(func=chat)

    p_add = sub.add_parser("add-data", help="Append a UTF-8 text file to the corpus.")
    p_add.add_argument("file")
    p_add.set_defaults(func=add_data)

    p_eval = sub.add_parser("evaluate", help="Run a small fixed evaluation set.")
    p_eval.set_defaults(func=evaluate)

    p_status = sub.add_parser("status", help="Inspect installation and model state.")
    p_status.set_defaults(func=status)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    try:
        args.func(args)
    except (FileNotFoundError, ValueError) as error:
        print(f"\nERROR: {error}\n")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
