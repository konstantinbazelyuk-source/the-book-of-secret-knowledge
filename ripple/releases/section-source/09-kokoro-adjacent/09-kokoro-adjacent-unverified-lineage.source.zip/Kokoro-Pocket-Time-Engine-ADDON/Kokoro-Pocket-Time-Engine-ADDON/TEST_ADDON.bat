@echo off
setlocal
py -3 "%~dp0tests\test_virtual_clock.py"
if errorlevel 1 (
  echo TEST FAILED
  pause
  exit /b 1
)
echo All Pocket Time tests passed.
pause
