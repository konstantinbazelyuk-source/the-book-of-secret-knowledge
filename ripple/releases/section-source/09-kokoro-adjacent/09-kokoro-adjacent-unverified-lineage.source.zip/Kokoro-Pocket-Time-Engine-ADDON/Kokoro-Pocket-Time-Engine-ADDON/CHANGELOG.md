# Changelog

## 1.0.0

- Added CPU benchmark and thread selection.
- Added above-normal-priority process runner.
- Added Windows sleep prevention.
- Added QuickEdit/Select-mode protection.
- Added adaptive-trainer discovery.
- Added run-state reporting.
- Added cooperative virtual clock with adjustable time scale.
- Added installer, uninstall script, launchers, and tests.
