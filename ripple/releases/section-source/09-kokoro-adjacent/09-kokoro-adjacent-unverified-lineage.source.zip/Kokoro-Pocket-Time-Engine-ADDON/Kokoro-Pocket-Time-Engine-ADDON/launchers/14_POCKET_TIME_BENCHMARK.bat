@echo off
setlocal EnableExtensions
title Kokoro Pocket Time Benchmark
set "ROOT=%~dp0.."
set "ENGINE=%ROOT%\addons\Kokoro-Pocket-Time-Engine"
"%ROOT%\.venv\Scripts\python.exe" "%ENGINE%\pocket_time\engine.py" benchmark --project-root "%ROOT%"
pause
