@echo off
setlocal
title Kokoro Virtual Pocket Time Demo
set "ROOT=%~dp0.."
set "ENGINE=%ROOT%\addons\Kokoro-Pocket-Time-Engine"
"%ROOT%\.venv\Scripts\python.exe" "%ENGINE%\pocket_time\engine.py" virtual-demo --scale 100
pause
