@echo off
setlocal EnableExtensions
title Kokoro Pocket Time Runner
set "ROOT=%~dp0.."
set "ENGINE=%ROOT%\addons\Kokoro-Pocket-Time-Engine"

"%ROOT%\.venv\Scripts\python.exe" "%ENGINE%\pocket_time\engine.py" run-kokoro --project-root "%ROOT%"
set "CODE=%ERRORLEVEL%"

echo.
echo Pocket Time runner exited with code %CODE%.
pause
exit /b %CODE%
