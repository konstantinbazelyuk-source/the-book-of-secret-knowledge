@echo off
setlocal
title Kokoro Pocket Time Status
set "ROOT=%~dp0.."
set "ENGINE=%ROOT%\addons\Kokoro-Pocket-Time-Engine"
"%ROOT%\.venv\Scripts\python.exe" "%ENGINE%\pocket_time\engine.py" status --project-root "%ROOT%"
pause
