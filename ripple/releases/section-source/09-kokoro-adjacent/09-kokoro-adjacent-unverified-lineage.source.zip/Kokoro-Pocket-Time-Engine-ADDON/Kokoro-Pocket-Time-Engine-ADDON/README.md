# Kokoro Pocket Time Engine

## Honest definition

The engine does **not** bend physical spacetime and does not use quantum effects
to make a CPU perform impossible work.

It offers:

- **Compute time compression:** benchmarking, thread tuning, higher-but-safe
  process priority, sleep prevention, QuickEdit protection, and clean monitoring.
- **Virtual time dilation:** a clock API for simulations/tests whose timers can
  advance faster or slower than wall-clock time.

## Expected effect

For Kokoro, the large improvement comes from the CPU Adaptive Trainer. Pocket
Time can add stability and sometimes a modest speed gain, commonly in the range
of a few percent to a few tens of percent, depending on the processor and current
Windows load. It cannot promise a fixed multiplier.

## Safety choices

- Uses `ABOVE_NORMAL_PRIORITY_CLASS`, never real-time priority.
- Does not overclock or change BIOS settings.
- Does not disable thermal protection.
- Does not alter Kokoro model weights.
- Saves benchmark and run-state files in its own add-on directory.
- Can launch the adaptive trainer, but does not replace it.

## Virtual clock example

```python
from pocket_time.virtual_clock import PocketClock

clock = PocketClock(scale=100.0)
print(clock.now())
clock.sleep(300)  # five virtual minutes pass in three real seconds
print(clock.now())
```

Only code that explicitly uses `PocketClock` sees this virtual time.
