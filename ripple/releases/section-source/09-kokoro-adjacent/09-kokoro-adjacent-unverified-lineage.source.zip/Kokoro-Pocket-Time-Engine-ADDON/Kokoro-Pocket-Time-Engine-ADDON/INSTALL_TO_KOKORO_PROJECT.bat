@echo off
setlocal EnableExtensions
title Install Kokoro Pocket Time Engine

set "DEFAULT_TARGET=C:\Kokoro-del-Corazon-Foundry"
set "TARGET=%DEFAULT_TARGET%"

if not exist "%TARGET%" (
  echo Default Kokoro folder not found:
  echo   %DEFAULT_TARGET%
  echo.
  set /p "TARGET=Enter the full Kokoro project folder: "
)

if not exist "%TARGET%\.venv\Scripts\python.exe" (
  echo.
  echo ERROR: Kokoro Python environment was not found at:
  echo   %TARGET%\.venv\Scripts\python.exe
  echo.
  pause
  exit /b 1
)

set "DEST=%TARGET%\addons\Kokoro-Pocket-Time-Engine"
if not exist "%TARGET%\addons" mkdir "%TARGET%\addons"

echo Installing to:
echo   %DEST%
echo.

robocopy "%~dp0" "%DEST%" /E /NFL /NDL /NJH /NJS /NP /XD "__pycache__" >nul
if errorlevel 8 (
  echo ERROR: Copy failed.
  pause
  exit /b 1
)

copy /Y "%~dp0launchers\14_POCKET_TIME_BENCHMARK.bat" "%TARGET%\windows\14_POCKET_TIME_BENCHMARK.bat" >nul
copy /Y "%~dp0launchers\15_RUN_KOKORO_IN_POCKET_TIME.bat" "%TARGET%\windows\15_RUN_KOKORO_IN_POCKET_TIME.bat" >nul
copy /Y "%~dp0launchers\16_POCKET_TIME_STATUS.bat" "%TARGET%\windows\16_POCKET_TIME_STATUS.bat" >nul
copy /Y "%~dp0launchers\17_VIRTUAL_TIME_DEMO.bat" "%TARGET%\windows\17_VIRTUAL_TIME_DEMO.bat" >nul

echo.
echo Installed successfully.
echo.
echo Next:
echo   1. Open %TARGET%\windows
echo   2. Run 14_POCKET_TIME_BENCHMARK.bat
echo   3. Run 15_RUN_KOKORO_IN_POCKET_TIME.bat
echo.
pause
