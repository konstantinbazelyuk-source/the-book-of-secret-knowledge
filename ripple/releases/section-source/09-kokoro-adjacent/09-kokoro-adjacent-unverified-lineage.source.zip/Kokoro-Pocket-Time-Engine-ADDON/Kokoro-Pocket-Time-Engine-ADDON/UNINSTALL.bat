@echo off
setlocal
set "TARGET=C:\Kokoro-del-Corazon-Foundry"

if not exist "%TARGET%" (
  set /p "TARGET=Enter the full Kokoro project folder: "
)

del /Q "%TARGET%\windows\14_POCKET_TIME_BENCHMARK.bat" 2>nul
del /Q "%TARGET%\windows\15_RUN_KOKORO_IN_POCKET_TIME.bat" 2>nul
del /Q "%TARGET%\windows\16_POCKET_TIME_STATUS.bat" 2>nul
del /Q "%TARGET%\windows\17_VIRTUAL_TIME_DEMO.bat" 2>nul
rmdir /S /Q "%TARGET%\addons\Kokoro-Pocket-Time-Engine" 2>nul

echo Pocket Time Engine removed. Kokoro checkpoints and source files were not touched.
pause
