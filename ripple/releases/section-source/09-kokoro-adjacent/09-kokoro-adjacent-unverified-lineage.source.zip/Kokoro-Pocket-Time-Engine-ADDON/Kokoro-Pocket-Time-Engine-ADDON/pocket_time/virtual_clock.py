from __future__ import annotations

import datetime as _dt
import time as _time
from dataclasses import dataclass, field


@dataclass
class PocketClock:
    """A cooperative virtual clock.

    scale=100 means 100 virtual seconds pass per real second.
    This affects only code that calls this object.
    """

    scale: float = 1.0
    _real_anchor: float = field(default_factory=_time.monotonic, init=False)
    _virtual_anchor: _dt.datetime = field(
        default_factory=lambda: _dt.datetime.now(_dt.timezone.utc), init=False
    )

    def __post_init__(self) -> None:
        if self.scale <= 0:
            raise ValueError("scale must be greater than zero")

    def monotonic(self) -> float:
        return (_time.monotonic() - self._real_anchor) * self.scale

    def now(self, tz: _dt.tzinfo | None = None) -> _dt.datetime:
        current = self._virtual_anchor + _dt.timedelta(seconds=self.monotonic())
        return current if tz is None else current.astimezone(tz)

    def sleep(self, virtual_seconds: float) -> None:
        if virtual_seconds < 0:
            raise ValueError("virtual_seconds cannot be negative")
        _time.sleep(virtual_seconds / self.scale)

    def set_scale(self, new_scale: float) -> None:
        if new_scale <= 0:
            raise ValueError("new_scale must be greater than zero")
        current_virtual = self.now()
        self._virtual_anchor = current_virtual
        self._real_anchor = _time.monotonic()
        self.scale = new_scale
