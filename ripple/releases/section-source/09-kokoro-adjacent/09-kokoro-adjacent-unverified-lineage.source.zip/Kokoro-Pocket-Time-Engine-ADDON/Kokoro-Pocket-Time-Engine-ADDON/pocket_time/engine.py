from __future__ import annotations

import argparse
import ctypes
import json
import math
import os
import platform
import subprocess
import signal
import sys
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any

ADDON_ROOT = Path(__file__).resolve().parents[1]
STATE_DIR = ADDON_ROOT / "state"
STATE_DIR.mkdir(exist_ok=True)
BENCHMARK_FILE = STATE_DIR / "benchmark.json"
RUN_STATE_FILE = STATE_DIR / "last_run.json"

ABOVE_NORMAL_PRIORITY_CLASS = 0x00008000
CREATE_NEW_PROCESS_GROUP = 0x00000200

ES_CONTINUOUS = 0x80000000
ES_SYSTEM_REQUIRED = 0x00000001
ES_DISPLAY_REQUIRED = 0x00000002

ENABLE_QUICK_EDIT_MODE = 0x0040
ENABLE_EXTENDED_FLAGS = 0x0080
STD_INPUT_HANDLE = -10


def _save_json(path: Path, data: dict[str, Any]) -> None:
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def _load_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def disable_quick_edit() -> bool:
    if os.name != "nt":
        return False
    kernel32 = ctypes.windll.kernel32
    handle = kernel32.GetStdHandle(STD_INPUT_HANDLE)
    mode = ctypes.c_uint()
    if handle in (0, -1) or not kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
        return False
    new_mode = (mode.value | ENABLE_EXTENDED_FLAGS) & ~ENABLE_QUICK_EDIT_MODE
    return bool(kernel32.SetConsoleMode(handle, new_mode))


@contextmanager
def keep_awake():
    if os.name == "nt":
        ctypes.windll.kernel32.SetThreadExecutionState(
            ES_CONTINUOUS | ES_SYSTEM_REQUIRED | ES_DISPLAY_REQUIRED
        )
    try:
        yield
    finally:
        if os.name == "nt":
            ctypes.windll.kernel32.SetThreadExecutionState(ES_CONTINUOUS)


def candidate_threads() -> list[int]:
    count = max(1, os.cpu_count() or 1)
    values = {1, 2, 4, count}
    if count >= 6:
        values.add(6)
    if count >= 8:
        values.add(8)
    if count >= 12:
        values.add(12)
    return sorted(v for v in values if v <= count)


def _torch_benchmark(thread_count: int) -> float:
    import torch

    torch.set_num_threads(thread_count)
    torch.set_num_interop_threads(1)

    size = 384
    x = torch.randn(size, size)
    y = torch.randn(size, size)

    for _ in range(2):
        z = x @ y
        _ = float(z[0, 0])

    start = time.perf_counter()
    rounds = 5
    for _ in range(rounds):
        z = x @ y
        _ = float(z[0, 0])
    elapsed = time.perf_counter() - start
    return rounds / max(elapsed, 1e-9)


def run_benchmark(project_root: Path) -> int:
    print("KOKORO POCKET TIME — CPU BENCHMARK")
    print("=" * 42)
    print(f"Computer: {platform.processor() or platform.machine()}")
    print(f"Logical CPUs: {os.cpu_count() or 1}")
    print()

    try:
        import torch
    except Exception as exc:
        print(f"ERROR: PyTorch could not be imported: {exc}")
        return 1

    results: list[dict[str, float | int]] = []
    for threads in candidate_threads():
        try:
            score = _torch_benchmark(threads)
            results.append({"threads": threads, "matmuls_per_second": score})
            print(f"{threads:>2} threads: {score:8.3f} matrix rounds/second")
        except RuntimeError as exc:
            # PyTorch may reject changing interop threads after parallel work begins.
            print(f"{threads:>2} threads: skipped ({exc})")
            break

    if not results:
        print("No benchmark result was produced.")
        return 1

    best = max(results, key=lambda item: float(item["matmuls_per_second"]))
    payload = {
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "project_root": str(project_root),
        "logical_cpus": os.cpu_count() or 1,
        "best_threads": int(best["threads"]),
        "results": results,
        "note": "Synthetic benchmark; actual training speed may differ.",
    }
    _save_json(BENCHMARK_FILE, payload)

    print()
    print(f"Selected thread count: {payload['best_threads']}")
    print(f"Saved: {BENCHMARK_FILE}")
    return 0


def find_adaptive_runner(project_root: Path) -> Path | None:
    candidates = [
        project_root / "addons" / "Kokoro-CPU-Adaptive-Trainer" / "01_RUN_OR_RESUME_BALANCED.bat",
        project_root / "addons" / "Kokoro-CPU-Adaptive-Trainer" / "windows" / "01_RUN_OR_RESUME_BALANCED.bat",
        project_root / "windows" / "01_RUN_OR_RESUME_BALANCED.bat",
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return None


def tuned_environment(thread_count: int) -> dict[str, str]:
    env = os.environ.copy()
    value = str(max(1, thread_count))
    env.update(
        {
            "OMP_NUM_THREADS": value,
            "MKL_NUM_THREADS": value,
            "OPENBLAS_NUM_THREADS": value,
            "NUMEXPR_NUM_THREADS": value,
            "VECLIB_MAXIMUM_THREADS": value,
            "KMP_BLOCKTIME": "0",
            "KMP_AFFINITY": "granularity=fine,compact,1,0",
            "PYTHONUNBUFFERED": "1",
            "KOKORO_POCKET_TIME": "1",
        }
    )
    return env


def run_target(project_root: Path, target: Path) -> int:
    benchmark = _load_json(BENCHMARK_FILE)
    threads = int(benchmark.get("best_threads") or max(1, (os.cpu_count() or 2) // 2))

    quick_edit_disabled = disable_quick_edit()
    env = tuned_environment(threads)

    command = ["cmd.exe", "/d", "/c", str(target)] if target.suffix.lower() == ".bat" else [str(target)]
    flags = 0
    if os.name == "nt":
        flags = ABOVE_NORMAL_PRIORITY_CLASS | CREATE_NEW_PROCESS_GROUP

    start = time.time()
    _save_json(
        RUN_STATE_FILE,
        {
            "status": "starting",
            "target": str(target),
            "threads": threads,
            "started_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "quick_edit_disabled": quick_edit_disabled,
        },
    )

    print("KOKORO POCKET TIME — COMPUTE MODE")
    print("=" * 38)
    print(f"Target: {target}")
    print(f"CPU threads: {threads}")
    print(f"QuickEdit protection: {'on' if quick_edit_disabled else 'unavailable'}")
    print("Priority: above normal (not real-time)")
    print("Sleep prevention: on while this runner is active")
    print()
    print("This improves execution conditions. It does not bend physical time.")
    print("Press Ctrl+C once for a controlled stop.")
    print()

    with keep_awake():
        process = subprocess.Popen(
            command,
            cwd=str(project_root),
            env=env,
            creationflags=flags,
        )
        _save_json(
            RUN_STATE_FILE,
            {
                "status": "running",
                "pid": process.pid,
                "target": str(target),
                "threads": threads,
                "started_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                "quick_edit_disabled": quick_edit_disabled,
            },
        )
        try:
            code = process.wait()
        except KeyboardInterrupt:
            print("\nControlled stop requested.")
            try:
                process.send_signal(getattr(signal, "CTRL_BREAK_EVENT", 1))
                code = process.wait(timeout=30)
            except Exception:
                process.terminate()
                code = process.wait()
        finally:
            elapsed = time.time() - start
            _save_json(
                RUN_STATE_FILE,
                {
                    "status": "finished",
                    "exit_code": int(code) if "code" in locals() else None,
                    "target": str(target),
                    "threads": threads,
                    "elapsed_seconds": elapsed,
                    "finished_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                },
            )

    print()
    print(f"Finished after {elapsed / 60:.1f} minutes with exit code {code}.")
    return int(code)


def show_status() -> int:
    benchmark = _load_json(BENCHMARK_FILE)
    run_state = _load_json(RUN_STATE_FILE)

    print("KOKORO POCKET TIME STATUS")
    print("=" * 27)
    if benchmark:
        print(f"Benchmarked threads: {benchmark.get('best_threads')}")
        print(f"Benchmark date: {benchmark.get('created_at')}")
    else:
        print("Benchmark: not run yet")

    print()
    if run_state:
        for key, value in run_state.items():
            print(f"{key}: {value}")
    else:
        print("No Pocket Time run recorded yet.")
    return 0


def virtual_demo(scale: float) -> int:
    from virtual_clock import PocketClock

    clock = PocketClock(scale=scale)
    print("VIRTUAL POCKET TIME DEMO")
    print("=" * 24)
    print(f"Scale: {scale:g}x")
    print(f"Virtual start: {clock.now().isoformat()}")
    print("Advancing five virtual minutes...")
    real_start = time.perf_counter()
    clock.sleep(300)
    real_elapsed = time.perf_counter() - real_start
    print(f"Virtual end:   {clock.now().isoformat()}")
    print(f"Real elapsed:  {real_elapsed:.3f} seconds")
    print()
    print("Only programs written to use PocketClock experience this virtual time.")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Kokoro Pocket Time Engine")
    sub = parser.add_subparsers(dest="command", required=True)

    benchmark_parser = sub.add_parser("benchmark")
    benchmark_parser.add_argument("--project-root", type=Path, required=True)

    run_parser = sub.add_parser("run-kokoro")
    run_parser.add_argument("--project-root", type=Path, required=True)

    sub.add_parser("status")

    virtual_parser = sub.add_parser("virtual-demo")
    virtual_parser.add_argument("--scale", type=float, default=100.0)

    args = parser.parse_args()

    if args.command == "benchmark":
        return run_benchmark(args.project_root.resolve())
    if args.command == "run-kokoro":
        root = args.project_root.resolve()
        target = find_adaptive_runner(root)
        if target is None:
            print("Adaptive trainer launcher was not found.")
            print("Install the CPU Adaptive Trainer first, then run this again.")
            return 2
        return run_target(root, target)
    if args.command == "status":
        return show_status()
    if args.command == "virtual-demo":
        return virtual_demo(args.scale)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
