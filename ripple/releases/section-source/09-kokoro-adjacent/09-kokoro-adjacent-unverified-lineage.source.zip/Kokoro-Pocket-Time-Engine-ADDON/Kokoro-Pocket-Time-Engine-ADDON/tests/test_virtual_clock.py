from __future__ import annotations

import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from pocket_time.virtual_clock import PocketClock


def main() -> None:
    clock = PocketClock(scale=100.0)
    start = time.perf_counter()
    clock.sleep(1.0)
    elapsed = time.perf_counter() - start
    assert elapsed < 0.2, elapsed
    assert clock.monotonic() >= 1.0
    print("PASS: virtual clock")


if __name__ == "__main__":
    main()
