"""Ripple ClusterNeuron Alpha v2.3: causal camera-feature neural population.

Reuses original v2.2 numerical image tasks and preserved v0.1 JS Ripple neurons.
Cluster nodes process numeric *feature encodings*, not real magnetometry or gamma rays.
"""
from __future__ import annotations
import hashlib
import json
import math
import subprocess
import sys
import time
from pathlib import Path
from typing import Sequence

import cv2
import numpy as np

from colony_lab.engine import TASKS, task_compute, execute, validate_frames, evaluate_task_coverage

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
NODES = ('chromatic', 'motion', 'focus', 'shadow')
COLORS = {'chromatic':'#ef4444', 'motion':'#38bdf8','focus':'#a78bfa','shadow':'#eab308'}
CHEAP = ('rgb','frame_delta','focus_laplacian','dark_fraction')
HEAVY = ('edge_density','optical_flow','tile_texture')


def clamp(v:float,lo=0.,hi=1.):
    return max(lo,min(hi,v))


def genome_overlay(name='prism'):
    # Inherited live config, not an independently trained set of weights.
    from master import inherited_genomes
    registry=inherited_genomes()
    if name not in registry:raise ValueError('unrecognized preserved Master genome')
    g=registry[name]
    gains=(clamp(g.optical_gain[0],.5,1.5),
           clamp(.80+.4*g.diffusion_gain,.5,1.5),
           clamp(.80+.4*g.density_gain,.5,1.5),
           clamp(.80+.4*g.occlusion_gain,.5,1.5))
    return {'name':name,'marker':g.marker(),'parent':g.parent,'color':g.color,'gains':[float(v) for v in gains]}


def cheap_features(frames:Sequence[np.ndarray],fps:float):
    validate_frames(frames)
    if not math.isfinite(fps) or not 2<=fps<=120:raise ValueError('FPS out of bounds')
    if 1000./fps>500 or 1000./fps<1:raise ValueError('incompatible neuron integration step')
    rows=[];cheap={}
    for i,frame in enumerate(frames):
        prev=frames[i-1] if i else None
        r={k:task_compute(k,frame,prev) for k in CHEAP}
        rgb=r['rgb']['rgb']; delta=r['frame_delta']['mean_gray_delta_normalized']
        focus=r['focus_laplacian']['laplacian_variance_proxy']
        dark=r['dark_fraction']['central_roi_fraction_gray_below_55']
        signal=[clamp((rgb[0]-rgb[1])*3.5), clamp(delta/.020),
                clamp(1.0/(1.0+focus/150.0)),clamp(dark)]
        rows.append({'t_ms':round(i*1000./fps,8),'features':signal})
        for k,v in r.items():cheap[(i,k)]=v
    return rows,cheap


def run_original_cluster(samples:list[dict], *, gains:list[float],coupling=.08,eta=.03):
    payload={'samples':samples,'gains':gains,'coupling':coupling,'eta':eta}
    p=subprocess.run(['node',str(ROOT/'cluster_neuron'/'cluster.cjs')],input=json.dumps(payload,allow_nan=False),
                     capture_output=True,text=True,timeout=25,cwd=str(ROOT))
    if p.returncode:raise RuntimeError('JS cluster failed: '+p.stderr[-1000:])
    return json.loads(p.stdout)


def select_work(samples, observations, cheap, *,period=12,delta_threshold=.008,mode="quality"):
    if not 4<=period<=48 or not .001<=delta_threshold<=.1:raise ValueError('invalid gate')
    if mode not in {'quality','economy'}:raise ValueError('unknown policy mode')
    work=[]; audit=[];counts={'periodic':0,'motion':0,'appearance':0,'cluster':0}
    for i,(sample,obs) in enumerate(zip(samples,observations)):
        feat=sample['features'];spikes=obs['spikes']
        periodic=(i%period==0)
        # Both optical-flow and texture sampling have independent periodic fallbacks.
        # This is a deliberately conservative response gate, not predictive object detection.
        motion=(feat[1]>=clamp(delta_threshold/.020) or (spikes[1]>0 and feat[1]>.26))
        color_change=(feat[0]>.60 or (i and abs(feat[0]-samples[i-1]['features'][0])>.18))
        focus_change=(i>0 and abs(feat[2]-samples[i-1]['features'][2])>.2)
        shadow_change=(i>0 and abs(feat[3]-samples[i-1]['features'][3])>.12)
        attention=(obs['score']>.56 and sum(spikes)>=2)
        appearance=(color_change or focus_change or shadow_change or attention)
        do_flow=(mode=="quality") or periodic or motion or attention
        do_spatial=periodic or appearance
        for k in CHEAP:work.append((i,k))
        if do_flow:work.append((i,'optical_flow'))
        if do_spatial:
            for k in ('edge_density','tile_texture'):work.append((i,k))
        counts['periodic']+=int(periodic);counts['motion']+=int(motion)
        counts['appearance']+=int(appearance);counts['cluster']+=int(attention)
        audit.append({'frame':i,'flow':do_flow,'spatial':do_spatial,'cluster_score':obs['score'],
                      'spikes':spikes,'reasons':{'periodic':periodic,'motion':motion,'appearance':appearance,'cluster':attention}})
    return work,audit,counts


def run_cluster(frames:Sequence[np.ndarray],fps:float,*,genome='prism',workers=2,
                period=12,compare_full=True, include_trace=False,mode="quality")->dict:
    t0=time.perf_counter()
    samples,cheap=cheap_features(frames,fps)
    inherited=genome_overlay(genome)
    neural=run_original_cluster(samples,gains=inherited['gains'])
    if len(neural['observations'])!=len(frames):raise AssertionError('neuron event count mismatch')
    work,audit,reasons=select_work(samples,neural['observations'],cheap,period=period,mode=mode)
    full_count=len(frames)*len(TASKS)
    # Do not recompute continuous, safety-critical cheap tasks; they were actually executed.
    heavy_work=[(i,k) for i,k in work if k not in CHEAP]
    heavy=execute(frames,heavy_work,workers=workers)
    results=dict(cheap);results.update(heavy['results'])
    reference=None
    if compare_full:
        allwork=[(i,k) for i in range(len(frames)) for k in TASKS]
        exhaustive=execute(frames,allwork,workers=1)
        from colony_lab.engine import tasks_for_frames
        hybrid_work,_=tasks_for_frames(frames,'hybrid')
        hybrid=execute(frames,hybrid_work,workers=1)
        coverage=evaluate_task_coverage(exhaustive['results'],results)
        reference={'exhaustive_tasks':len(allwork),'v2_2_hybrid_tasks':len(hybrid_work),
                  'v2_2_hybrid_coverage':evaluate_task_coverage(exhaustive['results'],hybrid['results']),
                  'v2_3_cluster_coverage':coverage}
    digest=hashlib.sha256(json.dumps({'genome':inherited['marker'],'work':work,'coupling':.08,'eta':.03},sort_keys=True).encode()).hexdigest()
    report={'schema':'ripple-cluster-study/2.3','classification':'calculated_from_camera_pixels_source_declared_separately',
      'frames':len(frames),'fps_supplied':float(fps),'genome':inherited,'node_colors':COLORS,
      'mode':mode,
      'original_lif_source':'legacy/ripple-core.js (unmodified)',
      'node_event_counts':dict(zip(NODES,neural['spikes_per_node'])),
      'final_attention_weights':dict(zip(NODES,neural['observations'][-1]['weights'])),
      'tasks_executed':len(work),'full_workload_tasks':full_count,
      'fraction_of_full_workload':round(len(work)/full_count,5),'scheduled_heavy_tasks':len(heavy_work),
      'dispatch_reasons':reasons,'audit_sha256':digest,'elapsed_ms':round((time.perf_counter()-t0)*1000,3),
      'reference':reference,
      'recommendation': ('Quality mode computes optical flow on every frame; selected to avoid silent motion misses' if mode=='quality' else 'Economy mode can miss positive optical-flow frames; use quality mode if motion coverage matters'),
      'warnings':['feature input is a numerical signal encoding, NOT actual optical color per subneuron',
        'focus variance is scene texture dependent','dark pixels are not direct measurements of physical occlusion',
        'zero missed positive frames against a chosen numerical reference is not semantic accuracy',
        'CPU timings include optional offline exhaustive evaluation when enabled',
        'captured sensor hardware and calibration not verified']}
    if include_trace:
        report['trace']=[{'frame':i,'signal':s['features'],'weights':o['weights'],'spikes':o['spikes'],
                          'score':o['score'],'selected':audit[i]} for i,(s,o) in enumerate(zip(samples,neural['observations']))]
    return report
