"""Different synthetic scene generator, no fixture 2.2 shared geometry or interventions."""
from pathlib import Path
import cv2
import numpy as np

def generate(path:Path,seed=57,n=192):
    if not 48<=n<=240:raise ValueError('48..240 frames')
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    rng=np.random.default_rng(seed)
    W,H=160,120
    yy,xx=np.mgrid[:H,:W]
    base=np.stack([38+xx*.35,55+yy*.35,62+xx*.25+yy*.11],axis=2).astype('float32')
    wr=cv2.VideoWriter(str(path),cv2.VideoWriter_fourcc(*'MJPG'),24,(W,H))
    if not wr.isOpened():raise RuntimeError('failed to make video')
    for i in range(n):
        out=base.copy()
        out+=rng.normal(0,2,size=(H,W,1))
        # Independent event ordering and geometry: central fast-moving checkerboard,
        # defocus interval, dark curtain, and amber/red floodlight.
        if 16<=i<51:
            x=10+((i-16)*4)%100;y=24+(i%8)
            cv2.rectangle(out,(x,y),(x+26,y+43),(230,80,110),thickness=-1)
        if 49<=i<76:
            out[:,:,2]+=65;out[:,:,1]+=10
        if 85<=i<122:
            out=cv2.GaussianBlur(out,(19,19),7)
        if 128<=i<160:
            out[12:107,22:139,:]=8
        if 161<=i<187:
            out+=45*np.sin(2*np.pi*(i-161)/7)
        wr.write(np.uint8(np.clip(out,0,255)))
    wr.release()
    return path
