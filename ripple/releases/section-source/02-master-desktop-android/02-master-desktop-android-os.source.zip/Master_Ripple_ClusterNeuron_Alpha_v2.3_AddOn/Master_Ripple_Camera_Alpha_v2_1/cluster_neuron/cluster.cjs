/* v2.3 ClusterNeuron: original v0.1 RippleNeuron is instantiated four times,
   not rewritten; feature inputs are numerical encodings, NOT physical RGB.
   Bounded EWMA population weights + last-step bounded lateral coupling.
   Strictly no external actions, training labels, model downloads, or IO except stdin/out. */
'use strict';
const fs=require('node:fs');
require('../legacy/ripple-core.js');
const TYPES=['chromatic','motion','focus','shadow'];
const clamp=(v,l=0,h=1)=>Math.max(l,Math.min(h,v));
function run(p){
 if(!Array.isArray(p.samples)||p.samples.length<3||p.samples.length>240)throw Error('sample count must be 3..240');
 if(!Array.isArray(p.gains)||p.gains.length!==4||p.gains.some(v=>!Number.isFinite(v)||v<.5||v>1.5))throw Error('bounded gain array required');
 const coupling=(p.coupling??.08), eta=(p.eta??.03);
 if(!Number.isFinite(coupling)||coupling<0||coupling>.2||!Number.isFinite(eta)||eta<0||eta>.1)throw Error('coupling/learning outside bounds');
 const neurons=TYPES.map(()=>new globalThis.RippleNeuron());
 const prior=[0,0,0,0], base=[.26,.31,.24,.19];let weights=base.slice();
 const observations=[];let old=null, counts=[0,0,0,0];
 for (let i=0;i<p.samples.length;i++){
  const s=p.samples[i];
  if(!s||!Array.isArray(s.features)||s.features.length!==4||s.features.some(v=>!Number.isFinite(v)||v<0||v>1)||!Number.isFinite(s.t_ms))throw Error('invalid bounded feature vector');
  if(old!==null&&(!(s.t_ms>old)||s.t_ms-old>500||s.t_ms-old<1))throw Error('invalid timestamp step');
  // First frame initializes clock; no fake dt or spikes.
  if(old===null){observations.push({frame:i,spikes:[0,0,0,0],rates_hz:[0,0,0,0],thresholds:[.45,.45,.45,.45],score:0,weights:weights.slice(),inputs:[0,0,0,0]});old=s.t_ms;continue;}
  const dt=(s.t_ms-old)/1000;
  const spikes=[],rates=[],thresholds=[],inputs=[];
  for(let j=0;j<4;j++){
   const lateral=(prior[(j+3)%4]+prior[(j+1)%4])/2;
   const v=clamp(s.features[j]*p.gains[j]+coupling*lateral);
   const resp=neurons[j].step([v,0,0],dt); // **exact preserved Ripple v0.1**
   inputs.push(v);spikes.push(resp.count);rates.push(resp.rate);thresholds.push(resp.theta);counts[j]+=resp.count;
  }
  // Causal, bounded gating-weight adaptation driven by signal activity, no labels.
  const attention=base.map((b,j)=>b*(.2+.8*s.features[j]));
  const sum=attention.reduce((a,b)=>a+b,0);
  const target=attention.map(v=>v/sum);
  const eta_dt=1-Math.pow(1-eta,dt/(1/24)); // time-normalized EWMA, bounded by source eta
  weights=weights.map((v,j)=>(1-eta_dt)*v+eta_dt*target[j]);
  const wsum=weights.reduce((a,b)=>a+b,0);weights=weights.map(v=>v/wsum);
  const score=clamp(s.features.reduce((a,v,j)=>a+v*weights[j],0)+.02*Math.min(4,spikes.reduce((a,v)=>a+v,0)));
  observations.push({frame:i,spikes,rates_hz:rates,thresholds,score,weights:weights.slice(),inputs});
  for(let j=0;j<4;j++)prior[j]=Math.min(1,spikes[j]);
  old=s.t_ms;
 }
 return {schema:'ripple-cluster-neuron/2.3',node_types:TYPES,spikes_per_node:counts,observations,
  original_math:'unchanged legacy/ripple-core.js; feature-to-R encoding is a new overlay',
  coordination:'bounded one-frame delayed ring coupling; EWMA normalized attention',
  physical_units:'none; all cluster inputs are normalized computational features'};
}
try{const input=JSON.parse(fs.readFileSync(0,'utf8'));process.stdout.write(JSON.stringify(run(input))+'\n');}
catch(e){process.stderr.write(String(e.stack)+'\n');process.exitCode=1;}
