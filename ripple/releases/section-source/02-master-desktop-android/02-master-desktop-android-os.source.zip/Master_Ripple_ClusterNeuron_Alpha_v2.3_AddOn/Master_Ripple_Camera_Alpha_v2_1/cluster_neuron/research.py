"""Explicitly selected device or recorded video; does not auto-enable a camera."""
from __future__ import annotations
import argparse, json
from pathlib import Path
from colony_lab.engine import decode_video
from colony_lab.research import capture_camera
from colony_lab.fixture import generate
from .engine import run_cluster

def main():
    ap=argparse.ArgumentParser(description='ClusterNeuron research runs on decoded BGR camera data.')
    g=ap.add_mutually_exclusive_group(required=True)
    g.add_argument('--demo',action='store_true',help='synthetic MJPG fixture decoded with OpenCV')
    g.add_argument('--file',type=Path,help='existing local video')
    g.add_argument('--device',type=int,help='EXPLICIT physical camera index')
    ap.add_argument('--frames',type=int,default=192)
    ap.add_argument('--genome',default='prism')
    ap.add_argument('--period',type=int,default=12)
    ap.add_argument('--workers',type=int,default=2)
    ap.add_argument('--mode',choices=['quality','economy'],default='quality')
    ap.add_argument('--out',type=Path,default=Path('cluster_results/experiment.json'))
    ap.add_argument('--trace',action='store_true')
    a=ap.parse_args()
    if not 3<=a.frames<=240:ap.error('--frames must be 3..240')
    if a.demo:
        a.file=Path('cluster_results/demo_seed13.avi')
        generate(a.file,seed=13,n=max(96,a.frames))
    if a.device is not None:
        frames,fps=capture_camera(a.device,a.frames)
        source={'mode':'direct_camera_unverified','index':a.device,'hardware_tested_here':True}
    else:
        frames,fps=decode_video(a.file,a.frames)
        import hashlib
        source={'mode':'synthetic_video_replay' if a.demo else 'video_replay_origin_unverified',
                'file':a.file.name,'sha256':hashlib.sha256(a.file.read_bytes()).hexdigest(),
                'hardware_tested_here':False}
    result=run_cluster(frames,fps,genome=a.genome,workers=a.workers,period=a.period,include_trace=a.trace,mode=a.mode)
    result['source']=source
    a.out.parent.mkdir(parents=True,exist_ok=True)
    a.out.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'output':str(a.out),'source':source,'node_events':result['node_event_counts'],
        'tasks_executed':result['tasks_executed'],'full_workload_tasks':result['full_workload_tasks'],
        'reference':result['reference']},indent=2))
if __name__=='__main__':main()
