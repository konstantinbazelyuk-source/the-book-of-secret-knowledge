# Master Ripple ClusterNeuron Alpha v2.3

**Status:** executable software Alpha. **Inherited original neuron preserved byte-for-byte.** Uses existing v2.2 numeric image-processing tasks and the v0.1 original `legacy/ripple-core.js` through Node.js. This is a composite digital processing system, **not** a biological neuron, proof of intelligence, or electromagnetic field detector.

## Start: existing camera workstation

Requires Python 3, NumPy, OpenCV (`opencv-python`), Node.js; operating system camera permissions. From extracted `Master_Ripple_Camera_Alpha_v2_1` folder:

```bash
python -m pip install -r requirements_camera.txt
python Launch_Master_Ripple_Camera.py --device 0
```

Open the localhost address. Press **Enable colony sampling**, then **Start capture**, allow camera permission if applicable. After 12+ sampled frames, choose **Quality: all-frame flow** and press **Run Cluster Neuron v2.3**. Only the local app is contacted. The camera is never opened by the Alpha cluster automatically. **This project was not physically verified with a camera in the execution environment, as no `/dev/video*` device was present.**

For an explicitly selected local video:

```bash
python Launch_Master_Ripple_Camera.py --file colony_fixtures/seed13.avi
```

A user-selected network stream is supported by inherited OpenCV camera code; stream/hardware-specific behavior is unverified.

## Standalone reproducible research

```bash
python -m cluster_neuron.research --demo --frames 192 --mode quality --trace --out cluster_results/my_run.json
python -m cluster_neuron.research --file colony_fixtures/seed13.avi --frames 192 --mode economy --out cluster_results/replay_economy.json
python -m unittest discover -s cluster_tests -v
```

**Quality mode (default):** `optical_flow` for every frame, along with per-frame `rgb`, `frame_delta`, `focus_laplacian`, `dark_fraction`; edge and texture tasks are selectively scheduled. This protects against the specifically discovered failure of using frame difference as a surrogate for optical flow.

**Economy mode (opt-in):** optical flow also becomes selectively scheduled using current frame-delta signals and bounded previous-step Ripple responses, plus periodic checks. It can miss movement even if other vision proxies show changes.

## Cluster mechanism

Four independently stateful *original* v0.1 `RippleNeuron` instances run every sample step:

| Color | Logical node | Input representation | Scientific limitation |
|---|---|---|---|
| Red | Chromatic | Positive red-minus-green normalized scene difference | Not wavelength or source radiometry |
| Blue | Motion | Normalized mean gray-frame delta | Not physical speed or flow magnitude |
| Purple | Focus | Monotonic transform of Laplacian variance | Texture-dependent focus proxy |
| Yellow | Shadow | Central fraction of dark pixels | Does not establish physical occlusion |

Every input is a **software feature encoded as `[feature,0,0]`** to the preserved Ripple optical-drive interface. These are *not* measured red-light values. The original neuron's threshold adaptation, refractory delay, membrane dynamics, and drive equation are identical to v0.1; no mutation of the source or unreviewed biological analogy is performed. Four copies each have independent state (`u`, `theta`, `rest`, `rate`). A ring connects each node to its two neighbors with a configurable bounded and **one-time-step delayed** coupling gain (default 0.08, permitted 0..0.2). This modifies inputs, **not** original core equations.

Inherited genome `prism`, `canopy`, etc. supplies a SHA-marked parent and bounded task-side encoding gains derived from the existing Master v2.0 optical/diffusion/occlusion/density parameters. Actual task priority changes with measured feature strengths via a normalized EWMA: `w_t = (1-eta_dt) w_{t-1} + eta_dt * normalized_priorities`, where `eta_dt = 1-(1-eta)^(dt/(1/24))`, `eta=0.03`. This is a bounded, causal heuristic, **not training on real-world truth or learning a new physical law**.

The final gate uses only the present and previous frames plus earlier neuron states, and cannot see future reference outcomes. Source sensor units are not mixed: the cluster accepts actual decoded camera pixels; it does not claim to use magnetic, spectroscopic, optical carrier, or electrical field channels.

## Research evaluation / negative findings

Four datasets, each 192 video frames, decoded with **real OpenCV VideoCapture**:

- The original archived synthetic scene seeded 13, 29 and 73 (same event schedule/geometry, different pixel noise). Task savings in economy: 918 tasks versus the v2.2 hybrid's 981; exhaustive 1,344. All four thresholded *numeric* reference event families were retained in these three matched synthetic conditions. In quality mode: 1,038 tasks, all covered.
- A **different generated scene** with changed movement geometry, lighting, defocus and dark-region transitions. Economy mode selected 14 of 69 exhaustive optical-flow-positive frames (20.29%); v2.2 hybrid selected 13 of 69 (18.84%). Quality mode computed flow every frame and selected all 69 of 69 positive flow frames, at a higher task count (1,072 versus v2.2 hybrid's 921; exhaustive 1,344). This is guaranteed agreement on the same numerical detector when every frame is evaluated, **not proof of scene understanding or optical-flow correctness**.
- Initial three-run timing comparison of the **economy** cluster versus the inherited hybrid showed the cluster generally **slower** despite fewer tasks because coordination, feature preprocessing and Node invocation cost CPU time. Source: `cluster_results/research_summary.json` (and individual seed reports). Timings depend on the execution machine; no performance win is claimed.

**A separate real camera recording has not been tested.** The browser controls passed an injected-mock-browser session, HTTP controls passed real loopback requests to a fake capture, and all on-disk video tests decoded actual compressed MJPG files with OpenCV. Source controls, image classification, camera focus/exposure physical response, health inference, and true 3D environmental mapping were not verified.

## Automated verification

- 36 new tests in `cluster_tests/` (32 core, 4 HTTP) pass.
- 30 existing colony tests pass.
- 35 existing camera tests pass.
- 46 inherited Master tests pass.
- **147 total passing unittest checks**, with new browser mock interactions at 390 px and 1200 px.
- The original v2.2 source archive and the internal `legacy/ripple-core.js` are unchanged; the release's file-audit manifest records checksums of all inherited paths.

## Scientific source pointers

1. Brette, R., Gerstner, W., *Adaptive exponential integrate-and-fire model as an effective description of neuronal activity*, J Neurophysiology 94 (2005), DOI: https://doi.org/10.1152/jn.00686.2005 — supporting family of models; **Ripple's specific existing equation is simpler and independently defined**.
2. Carandini/Heeger normalization overview, *Normalization Principles in Computational Neuroscience* (2019), https://doi.org/10.1093/acrefore/9780190264086.013.43 — normalization background, not equivalence to biological cognition.
3. Jacobs et al. (1991), *Adaptive Mixtures of Local Experts*, DOI https://doi.org/10.1162/neco.1991.3.1.79 — conceptual precedent for specialist modules with gating. The present Alpha uses a **hand-defined heuristic gate**, not a trained mixture-of-experts network.
4. OpenCV image filtering and optical flow documentation: https://docs.opencv.org/4.x/d4/dee/tutorial_optical_flow.html and https://docs.opencv.org/4.x/d5/db5/tutorial_laplace_operator.html

Original archives may retain different licenses; newly authored cluster files are offered under the MIT license in `cluster_neuron/LICENSE`. The existing source and legacy math have been left intact. No GitHub/public web upload was performed.
