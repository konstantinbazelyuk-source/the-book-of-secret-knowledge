"""Independent behavioral and safety regression suite for ClusterNeuron v2.3."""
from __future__ import annotations
import copy, json, math, subprocess, sys, unittest
from pathlib import Path
import cv2,numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'src'),str(ROOT/'camera_bridge')]
from cluster_neuron.engine import (run_cluster,cheap_features,genome_overlay,run_original_cluster,
    select_work,NODES,CHEAP)
from colony_lab.engine import decode_video,task_compute
from camera_bridge.core import CameraStation

class ClusterTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.frames,cls.fps=decode_video(ROOT/'colony_fixtures/seed13.avi',48)
        cls.samples,cls.cheap=cheap_features(cls.frames,cls.fps)
    def _neurons(self,gains=(1,1,1,1),coupling=.08,eta=.03):
        return run_original_cluster(self.samples,gains=list(gains),coupling=coupling,eta=eta)
    def test_01_real_four_original_neurons(self):
        r=self._neurons();self.assertEqual(len(r['node_types']),4)
        self.assertEqual(len(r['observations']),len(self.frames))
    def test_02_unmodified_math_matches_independent_js_reference(self):
        r=self._neurons(coupling=0,eta=0)
        code='''require('./legacy/ripple-core.js');const a=new globalThis.RippleNeuron();let old=null;let rows=[];for(const s of JSON.parse(require('node:fs').readFileSync(0,'utf8'))){if(old!==null){const q=a.step([s.features[0],0,0],(s.t_ms-old)/1000);rows.push([q.count,q.theta,q.rate]);}old=s.t_ms;}console.log(JSON.stringify(rows));'''
        p=subprocess.run(['node','-e',code],input=json.dumps(self.samples),cwd=ROOT,text=True,capture_output=True,check=True)
        ref=json.loads(p.stdout)
        for i,(n,theta,rate) in enumerate(ref,1):
            self.assertEqual(n,r['observations'][i]['spikes'][0])
            self.assertAlmostEqual(theta,r['observations'][i]['thresholds'][0],places=11)
            self.assertAlmostEqual(rate,r['observations'][i]['rates_hz'][0],places=11)
    def test_03_repeat_deterministic(self):
        self.assertEqual(self._neurons(),self._neurons())
    def test_04_bounded_weights(self):
        for x in self._neurons()['observations']:
            self.assertAlmostEqual(sum(x['weights']),1,places=12)
            self.assertTrue(all(0<=w<=1 for w in x['weights']))
    def test_05_invalid_gain_fails(self):
        with self.assertRaises(RuntimeError):run_original_cluster(self.samples,gains=[-1,1,1,1])
    def test_06_invalid_coupling_fails(self):
        with self.assertRaises(RuntimeError):run_original_cluster(self.samples,gains=[1]*4,coupling=.4)
    def test_07_invalid_eta_fails(self):
        with self.assertRaises(RuntimeError):run_original_cluster(self.samples,gains=[1]*4,eta=.4)
    def test_08_invalid_sample_fails(self):
        samples=copy.deepcopy(self.samples);samples[4]['features'][0]=float('nan')
        with self.assertRaises(ValueError):run_original_cluster(samples,gains=[1]*4)
    def test_09_replayed_timestamps_fails(self):
        s=copy.deepcopy(self.samples);s[4]['t_ms']=s[3]['t_ms']
        with self.assertRaises(RuntimeError):run_original_cluster(s,gains=[1]*4)
    def test_10_gene_marker_is_inherited(self):
        self.assertEqual(len(genome_overlay('prism')['marker']),64)
    def test_11_unknown_gene_rejected(self):
        with self.assertRaises(ValueError):genome_overlay('hack')
    def test_12_always_run_quality_checks(self):
        s=self._neurons();jobs,_,_=select_work(self.samples,s['observations'],self.cheap)
        for i in range(len(self.frames)):
            self.assertTrue(all((i,k) in jobs for k in CHEAP))
    def test_13_no_disallowed_work(self):
        s=self._neurons();jobs,_,_=select_work(self.samples,s['observations'],self.cheap)
        self.assertTrue(set(k for _,k in jobs)<={'rgb','frame_delta','focus_laplacian','dark_fraction','edge_density','tile_texture','optical_flow'})
    def test_14_causal_prefix_no_future_read(self):
        subset=self.samples[:24]
        a=run_original_cluster(subset,gains=[1]*4)
        b=self._neurons()
        self.assertEqual(a['observations'],b['observations'][:24])
    def test_15_causal_work_prefix(self):
        s=self._neurons()
        jobs,_,_=select_work(self.samples,s['observations'],self.cheap)
        s2=run_original_cluster(self.samples[:24],gains=[1]*4)
        jobs2,_,_=select_work(self.samples[:24],s2['observations'],self.cheap)
        self.assertEqual([x for x in jobs if x[0]<24],jobs2)
    def test_16_input_frame_does_not_mutate(self):
        f=self.frames[1].copy();run_cluster(self.frames[:12],self.fps,compare_full=False)
        self.assertTrue(np.array_equal(f,self.frames[1]))
    def test_17_cluster_is_executable_not_metadata(self):
        r=run_cluster(self.frames,self.fps,compare_full=True)
        self.assertGreater(r['tasks_executed'],len(self.frames)*4)
        self.assertEqual(r['reference']['exhaustive_tasks'],len(self.frames)*7)
    def test_18_all_monitors_every_frame(self):
        s=self._neurons();work,_,_=select_work(self.samples,s['observations'],self.cheap)
        self.assertEqual(sum(k in CHEAP for _,k in work),len(self.frames)*4)
    def test_19_negative_constant_motion(self):
        f=[self.frames[0].copy() for _ in range(24)];r=run_cluster(f,self.fps,compare_full=True)
        self.assertEqual(r['reference']['v2_3_cluster_coverage']['motion']['full_reference_positive_frames'],0)
    def test_20_invalid_frames(self):
        with self.assertRaises(ValueError):run_cluster([np.zeros((12,12,3),dtype=np.uint8)]*12,24)
    def test_21_invalid_fps(self):
        with self.assertRaises(ValueError):cheap_features(self.frames,0)
    def test_22_no_optin_station(self):
        s=CameraStation(factory=lambda _: (_ for _ in ()).throw(AssertionError('camera opened')))
        with self.assertRaises(RuntimeError):s.run_cluster_neuron()
    def test_23_source_hash_matches_v22(self):
        import zipfile,hashlib
        archive=Path('/mnt/data/Master_Ripple_Camera_Colony_Alpha_v2.2_Complete.zip')
        with zipfile.ZipFile(archive) as z:
            src=z.read('Master_Ripple_Camera_Alpha_v2_1/legacy/ripple-core.js')
        self.assertEqual(hashlib.sha256(src).digest(),hashlib.sha256((ROOT/'legacy/ripple-core.js').read_bytes()).digest())
    def test_24_spike_counter_sum(self):
        n=self._neurons()
        for j,key in enumerate(NODES):
            self.assertEqual(n['spikes_per_node'][j],sum(x['spikes'][j] for x in n['observations']))
    def test_25_genome_weights_affect_response(self):
        a=run_cluster(self.frames[:36],self.fps,genome='prism',compare_full=False)
        b=run_cluster(self.frames[:36],self.fps,genome='canopy',compare_full=False)
        self.assertNotEqual(a['genome']['gains'],b['genome']['gains'])
    def test_26_optin_fake_camera(self):
        from camera_tests.test_camera import FakeCapture
        import time
        s=CameraStation(factory=lambda _:FakeCapture())
        s.set_colony(True);s.start()
        try:
            until=time.monotonic()+3
            while s.status()['colony_buffered']<12 and time.monotonic()<until:time.sleep(.06)
            r=s.run_cluster_neuron('prism')
            self.assertGreater(r['tasks_executed'],0)
            self.assertEqual(r['source']['mode'],'live_device_unverified')
        finally:s.stop()
    def test_27_error_unknown_work_budget(self):
        with self.assertRaises(ValueError):select_work(self.samples,self._neurons()['observations'],self.cheap,period=1)
    def test_28_quality_all_frame_flow(self):
        report=run_cluster(self.frames,self.fps,compare_full=True,mode='quality')
        ref=report['reference']['v2_3_cluster_coverage']['motion']
        self.assertEqual(ref['coverage_of_full_reference'],1.0 if ref['full_reference_positive_frames'] else None)
    def test_29_economy_mode_explicit(self):
        s=self._neurons();jobs,_,_=select_work(self.samples,s['observations'],self.cheap,mode='economy')
        self.assertLess(sum(k=='optical_flow' for _,k in jobs),len(self.frames))
    def test_30_reject_bad_policy(self):
        with self.assertRaises(ValueError):run_cluster(self.frames,self.fps,mode='unlimited',compare_full=False)
    def test_31_modes_not_equivalent(self):
        a=run_cluster(self.frames,self.fps,mode='quality',compare_full=False)
        b=run_cluster(self.frames,self.fps,mode='economy',compare_full=False)
        self.assertGreater(a['tasks_executed'],b['tasks_executed'])
    def test_32_no_magnetic_claim(self):
        r=run_cluster(self.frames[:12],self.fps,compare_full=False)
        self.assertTrue(any('not direct measurements' in x for x in r['warnings']))

if __name__=='__main__':unittest.main()
