"""Real loopback HTTP tests for the opt-in cluster route."""
import json, socket,sys,threading,time,unittest,urllib.request,urllib.error
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'camera_bridge'),str(ROOT/'src')]
from camera_bridge.core import CameraStation
from camera_bridge.server import build_server
from camera_tests.test_camera import FakeCapture
class HttpClusterTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  sock=socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1];sock.close()
  cls.station=CameraStation(factory=lambda _:FakeCapture())
  cls.server=build_server(cls.station,port)
  cls.t=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.t.start()
  cls.base=f'http://127.0.0.1:{port}'
 @classmethod
 def tearDownClass(cls):
  cls.station.stop();cls.server.shutdown();cls.server.server_close();cls.t.join(timeout=5)
 def req(self,path,data=None,token=True):
  body=json.dumps(data or {}).encode()
  headers={'Content-Type':'application/json','Origin':self.base}
  if token:headers['X-Ripple-Token']=type(self.server.RequestHandlerClass).token if False else self.server.RequestHandlerClass.token
  try:
   with urllib.request.urlopen(urllib.request.Request(self.base+path,data=body,headers=headers),timeout=12) as r:return r.status,json.load(r)
  except urllib.error.HTTPError as e:return e.code,json.load(e)
 def test_01_no_token(self):
  code,data=self.req('/api/cluster/run',{'genome':'prism'},False)
  self.assertEqual(code,403)
 def test_02_no_optin(self):
  code,data=self.req('/api/cluster/run',{'genome':'prism'})
  self.assertEqual(code,409)
 def test_03_live_station_stub(self):
  self.station.set_colony(True);self.station.start()
  until=time.monotonic()+3
  while self.station.status()['colony_buffered']<12 and time.monotonic()<until:time.sleep(.06)
  code,data=self.req('/api/cluster/run',{'genome':'prism','mode':'quality'})
  self.assertEqual(code,200,data)
  self.assertEqual(data['mode'],'quality')
  self.assertEqual(data['source']['mode'],'live_device_unverified')
  self.station.stop()
 def test_04_invalid_mode_rejected(self):
  self.station.set_colony(True)
  self.station.start()
  until=time.monotonic()+3
  while self.station.status()['colony_buffered']<12 and time.monotonic()<until:time.sleep(.06)
  code,data=self.req('/api/cluster/run',{'genome':'prism','mode':'unsafe'})
  self.assertEqual(code,400,data)
  self.station.stop()
if __name__=='__main__':unittest.main()
