# Ripple Neuron Home App Changelog

## v0.4 — One-tap Android launcher (source build)

- Native Android Studio WebView host; HTTPS app-assets origin instead of downloaded `content://` URL.
- Android CAMERA runtime permission delegated to WebChromeClient video request only for trusted origin.
- Android 4-button home-screen widget (Live / Camera / Observe / Test) and long-press launcher shortcuts.
- Original v0.3 lab wrapped, additional phone bottom dock and deep link tool selection; numerical model unchanged.
- Offline CSV and JSON exports use Android's Storage Access Framework document save picker.
- PWA manifest shortcuts, offline app shell, no automatic online connection.
- Additive release, no replacement for v0.1 / v0.2 / v0.3.

### Verification

- Original numerical experiment and observer checks passed.
- Python receiver tests passed with expected authorization and schema rejection.
- Inline Chromium mobile UI smoke test passed, including experiment and mock native export bridge.
- Native Android SDK compilation and Samsung physical camera tests remain PENDING.
