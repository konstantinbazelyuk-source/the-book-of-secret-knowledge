# Ripple Neuron — One-tap Android Home App v0.4

Concept: Constantin x. Based on Ripple Neuron v0.1 mathematics and v0.3 read-only observer. This additive Android launcher does not introduce new neuron intelligence or alter the core algorithm.

## What is included

- `android/` — **native Android Studio project**, with launcher icon, *real Samsung/Android home-screen widget* containing Live / Camera / Observe / Test buttons, and long-press launcher shortcuts. **Source project only: an APK has not been built or tested on a physical phone here.**
- `web/` — browser-installable PWA with matching home-screen icon, mobile bottom dock, tools tabs and manifest shortcuts. Can run offline after HTTPS installation/cache. Camera requires permission and a secure context.
- `server/` — opt-in existing v0.3 HTTPS-compatible numerical telemetry receiver (deploy separately).
- `tests/` — v0.3 numeric / observer / receiver tests.
- `PHASE-2-PLAN.md` — independent unactivated future complex-behavior experiments.
- `.github/workflows/android-debug.yml` — GitHub Actions debug APK recipe after publishing to a repository. An action is not already running.

## Fastest route to a home-screen icon

**Native version (no hosting required):** open `android/` in Android Studio or Codex. Sync Gradle with Android SDK 35 and JDK 17, build a debug APK (`gradle :app:assembleDebug` from `android/`). Install the APK on your Samsung phone. Tap the Ripple Neuron icon to open the complete lab, or long-press the home screen → Widgets → Ripple Neuron to add a 4-button widget. No service connection or ChatGPT API is required. First camera use requests Android permission. Camera runs only while the application is in the foreground.

**Web version (no APK required):** deploy the contents of `web/` unchanged to an HTTPS host (GitHub Pages is one option), open the HTTPS site in Chrome on the phone, then choose Chrome menu → `Install app` / `Add to Home screen` as offered. Tap the icon to launch. The original `content://` downloaded HTML route is **not** the recommended camera route and may show `Permission denied`.

The embedded native app uses `WebViewAssetLoader` on `https://appassets.androidplatform.net/assets/` instead of `content://`, and explicitly mediates Android camera permission through a `WebChromeClient` that grants only video capture to its own origin. This is an engineering design to address the previous denial; it still needs an Android-device test.

## One-tap tools

- Launch icon → live model with manual color input.
- Widget **Camera** → selects optical input and requests access. No background capture.
- Widget **Observe** → read-only self-regulation diagnosis, optional local record/export.
- Widget **Test** → opens and runs the existing 120-second numerical experiment.
- **Engineering** remains accessible from the main tabs.
- The in-app mobile bottom dock also opens Live / Camera / Observe / Test.

## Export and offline/online policy

- Local offline model, camera frame-to-RGB processing and observer functions don't need Internet.
- `Export CSV` and `Export offline JSON` use Android's document-save picker in the native app and normal downloads in the PWA.
- Online telemetry remains OFF by default; the user must deploy their own HTTPS endpoint and explicitly activate transmission. No camera images are sent.
- With app backgrounded the camera is stopped; long-running hidden recording is not supported.

## Verification commands

```sh
node tests/check_phone_model.cjs
node tests/check_observer.cjs
python -m unittest discover -s tests -p 'test_*.py' -v
```

The source includes real Android manifest/widget XML, but this system has no Android SDK, so an installable APK and its runtime behavior **have not been verified**. Test on a physical Samsung after compiling. The app does not send data to ChatGPT automatically.

See `CODEX_BUILD.md` for the staged build/test checklist.
