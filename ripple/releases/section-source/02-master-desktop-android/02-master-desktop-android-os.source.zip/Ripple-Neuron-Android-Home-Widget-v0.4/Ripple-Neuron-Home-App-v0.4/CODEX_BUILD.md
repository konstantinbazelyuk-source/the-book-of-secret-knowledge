# Codex handoff — Ripple Neuron one-tap Android launcher

## Non-negotiable continuity

- Keep `web/ripple-core.js` byte-for-byte identical to v0.3 original. The actual HTML embeds the original v0.1 neuron mathematics. Do **not** modify `RippleNeuron` or `runExperiment` when fixing the launcher/camera.
- Preserve the independent read-only `observer-core.js` and optional opt-in numerical telemetry.
- Work only on packaging / Android camera permission / exports / launcher until device tests pass.
- Do not claim physical AS7341 testing, intelligence, consciousness, or an APK build before evidence exists.

## Build and test

1. Open `android/` as an Android Studio project. Install SDK 35; Java 17 and Gradle 8.7. `gradle :app:assembleDebug` (or Android Studio Build > Build APK).
2. Install on Samsung Android 16. Tap app icon: Live tab should start with manual input. Observer should update read-only; Experiment 60–80 seconds should show adaptive **0.95 Hz** vs fixed **3.40 Hz**. Confirm phone back button behavior.
3. Tap **Camera** widget button or bottom-dock Camera: ensure first permission prompt appears. Verify camera frames update RGB with stable light; denial must retain manual-mode functionality. Test STOP and app background camera release.
4. Tap `Export CSV` and `Export offline JSON`. Both must launch Android system save picker, create valid files and survive Android app process restart for recorded IndexedDB data.
5. Long press launcher → Widgets → Ripple Neuron; add widget and test Live/Camera/Observe/Test. Test 1st launch vs warm launch. Confirm other app's link doesn't execute in privileged WebView.
6. Leave online OFF. When separate receiver HTTPS is available, test explicit opt-in and token rejection; images must never leave phone.

## If Android compilation fails

Do not swap in an unrelated PWA or regenerate the neuron. Fix only the Gradle / Android wrapper code and rerun, preserving a last confirmed-good version. Report exact compiler messages. GitHub Actions `.github/workflows/android-debug.yml` can produce a debug APK after a repo exists.

## Deployment states

- v0.4 source created: yes.
- v0.4 web source numeric regression: run recorded in handoff.
- APK built on this machine: no (SDK unavailable).
- Android widget/device camera observed on hardware: no.
- HTTPS server deployed: no.
- v0.3 original source overwritten: no.
