package org.ripple.neuron;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

/** A real home screen widget; tapping launches a foreground tool, never a background camera. */
public final class RippleWidget extends AppWidgetProvider {
    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] widgetIds) {
        for (int id : widgetIds) {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_ripple);
            shortcut(context, views, R.id.widget_live, "live", id * 10 + 1);
            shortcut(context, views, R.id.widget_camera, "camera", id * 10 + 2);
            shortcut(context, views, R.id.widget_observer, "observer", id * 10 + 3);
            shortcut(context, views, R.id.widget_experiment, "experiment", id * 10 + 4);
            manager.updateAppWidget(id, views);
        }
    }
    private void shortcut(Context context, RemoteViews views, int button, String tool, int requestCode) {
        Intent intent = new Intent(context, MainActivity.class);
        intent.setAction(Intent.ACTION_VIEW);
        intent.setData(android.net.Uri.parse("ripple://" + tool));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pending = PendingIntent.getActivity(context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(button, pending);
    }
}
