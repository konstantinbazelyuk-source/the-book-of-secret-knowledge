package org.ripple.neuron;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/** Local trusted WebView host for the *unchanged* neuron algorithm and stage-1 observer. */
public final class MainActivity extends Activity {
    private static final String HOME = "https://appassets.androidplatform.net/assets/index.html";
    private static final String HOST = "appassets.androidplatform.net";
    private static final int ASK_CAMERA = 50;
    private static final int SAVE_TEXT = 51;
    private WebView browser;
    private PermissionRequest cameraRequest;
    private byte[] pendingText;
    private String pendingMime;
    private String pendingName;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        browser = new WebView(this);
        setContentView(browser);
        WebSettings s = browser.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        WebView.setWebContentsDebuggingEnabled(false);
        WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        browser.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                return loader.shouldInterceptRequest(req.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if ("https".equals(u.getScheme()) && HOST.equals(u.getHost()) && u.getPath() != null && u.getPath().startsWith("/assets/")) return false;
                // Never navigate external/unknown pages within a WebView that has a trusted JS bridge.
                if ("https".equals(u.getScheme()) && u.getHost() != null) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, u)); }
                    catch (ActivityNotFoundException ex) { Toast.makeText(MainActivity.this,"No browser available", Toast.LENGTH_SHORT).show(); }
                }
                return true;
            }
        });
        browser.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> {
                    Uri origin = request.getOrigin();
                    String[] resources = request.getResources();
                    boolean isTrusted = "https".equals(origin.getScheme()) && HOST.equals(origin.getHost());
                    boolean videoOnly = resources.length == 1 && PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resources[0]);
                    if (!isTrusted || !videoOnly || cameraRequest != null) { request.deny(); return; }
                    if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                    } else {
                        cameraRequest=request;
                        requestPermissions(new String[]{Manifest.permission.CAMERA}, ASK_CAMERA);
                    }
                });
            }
            @Override public void onPermissionRequestCanceled(PermissionRequest request) {
                if (cameraRequest == request) cameraRequest=null;
            }
        });
        // Only the local app origin can load inside the WebView. Do not add third-party frames.
        browser.addJavascriptInterface(new ExportBridge(), "RippleAndroid");
        String tool = toolFromIntent(getIntent());
        browser.loadUrl(HOME + "?native=1&tool=" + tool);
    }

    private static String toolFromIntent(Intent i) {
        String tool = i.getStringExtra("tool");
        if (tool == null && i.getData() != null && "ripple".equals(i.getData().getScheme())) tool = i.getData().getHost();
        return Arrays.asList("live", "camera", "observer", "experiment", "notes").contains(tool) ? tool : "live";
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent); setIntent(intent);
        if (browser != null) {
            String tool=toolFromIntent(intent);
            browser.evaluateJavascript("(function(){ if (typeof window.RippleOpenTool === 'function') { window.RippleOpenTool('" + tool + "'); return true; } return false; })()",
                    result -> { if ("false".equals(result)) browser.loadUrl(HOME + "?native=1&tool=" + tool); });
        }
    }

    @Override public void onRequestPermissionsResult(int code, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(code, permissions, grants);
        if (code != ASK_CAMERA || cameraRequest == null) return;
        PermissionRequest toFinish=cameraRequest;cameraRequest=null;
        if (grants.length > 0 && grants[0] == PackageManager.PERMISSION_GRANTED) toFinish.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
        else toFinish.deny();
    }

    // Files are exported only after the browser calls the bridge via the user's Export action.
    private final class ExportBridge {
        @JavascriptInterface public void saveTextFile(String fileName, String mimeType, String content) {
            if (content == null || content.length() > 10_000_000) return;
            String n = fileName == null ? "Ripple-Neuron-Data.txt" : fileName.replaceAll("[^A-Za-z0-9._-]", "_");
            String m = "application/json".equals(mimeType) ? "application/json" : "text/csv";
            byte[] bytes=content.getBytes(StandardCharsets.UTF_8);
            runOnUiThread(() -> {
                pendingName=n; pendingMime=m; pendingText=bytes;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT)
                        .addCategory(Intent.CATEGORY_OPENABLE).setType(m)
                        .putExtra(Intent.EXTRA_TITLE, n);
                try { startActivityForResult(intent, SAVE_TEXT); }
                catch (ActivityNotFoundException e) { Toast.makeText(MainActivity.this,"No save app available",Toast.LENGTH_LONG).show(); }
            });
        }
    }

    @Override protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (code == SAVE_TEXT) {
            if (result == RESULT_OK && data != null && data.getData() != null && pendingText != null) {
                try (OutputStream out=getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new IllegalStateException("Unable to open file");
                    out.write(pendingText);
                    Toast.makeText(this,"Ripple data saved",Toast.LENGTH_SHORT).show();
                } catch (Exception e) { Toast.makeText(this,"Export failed: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
            }
            pendingText=null; pendingName=null; pendingMime=null;
        }
    }

    @Override protected void onPause() { super.onPause(); if(browser!=null) browser.onPause(); }
    @Override protected void onResume() { super.onResume(); if(browser!=null) browser.onResume(); }
    @Override protected void onDestroy() {
        if (cameraRequest != null) { cameraRequest.deny(); cameraRequest=null; }
        if(browser!=null) { browser.removeJavascriptInterface("RippleAndroid");browser.destroy();browser=null; }
        super.onDestroy();
    }
}
