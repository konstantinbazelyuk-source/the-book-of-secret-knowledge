"""Restricted sandbox UI smoke test: uses inline HTML; does not test HTTPS/device camera."""
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).parent
html=(ROOT/'web/index.html').read_text()
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 context=browser.new_context(viewport={'width':390,'height':844},device_scale_factor=1,is_mobile=True,has_touch=True)
 page=context.new_page()
 errors=[]
 page.on('pageerror',lambda e: errors.append(str(e)))
 page.set_content(html,wait_until='load')
 page.add_script_tag(content=(ROOT/'web/observer-core.js').read_text())
 page.add_script_tag(content=(ROOT/'web/observer-ui.js').read_text())
 page.wait_for_timeout(1250)
 assert page.locator('#view-live').is_visible(), 'live view missing'
 assert page.locator('.quickdock').is_visible(), 'bottom quick dock missing'
 page.locator('[data-quick="observer"]').click()
 page.wait_for_timeout(1200)
 assert page.locator('#view-observer').is_visible(), 'observer selection failed'
 assert page.locator('#obs-window').inner_text(), 'observer summary area missing'
 page.locator('[data-quick="experiment"]').click()
 page.wait_for_timeout(450)
 result=page.locator('#results').inner_text()
 assert '3.40' in result and '0.95' in result, 'experiment results missing'
 page.locator('[data-quick="live"]').click()
 page.wait_for_timeout(180)
 assert page.locator('#view-live').is_visible(), 'live view failed'
 page.screenshot(path=str(ROOT/'preview-home-app.png'),full_page=False)
 page.evaluate('window.RippleAndroid={saveTextFile:(name,mime,data)=>window.__capture={name,mime,length:data.length}}')
 page.locator('#export').click()
 export=page.evaluate('window.__capture')
 assert export and export['mime']=='text/csv' and export['length']>20, 'native CSV export bridge did not fire'
 print('Experiment:',result.replace('\n',' ')[:160])
 print('Mock native bridge:',export)
 print('JavaScript page errors:',errors)
 assert not errors,'browser JS errors present'
 browser.close()
print('PASS: mobile dock, view switches, original 120s experiment, native export JS invocation')
