# Ripple Neuron v0.4 — Samsung optical equation edition

This is the **existing v0.3 Samsung adaptation extended with a measured camera-optical equation**. The neuron core is byte-identical to Ripple Neuron v0.1. The model was never mathematically based on a Pi processor; only the original implementation's proposed input hardware was Pi/Pico + AS7341.

For the complete mathematical reconstruction and the limits of the phone's camera, read **`OPTICAL_MATH.md`**.

## Use the program

- **Manual neuron (offline, no deployment):** Open `Ripple-Samsung-Open-Offline.html` in your phone's browser. Manual RGB controls and the 120 s experiment work offline. Local file security restrictions may prevent camera access.
- **Camera calibration and home-screen app:** Put `index.html`, `ripple-core.js`, `manifest.webmanifest`, `sw.js`, and `icon-*` together on an **HTTPS** static host. Open it on your Samsung in Chrome. Choose **Phone camera → Start camera**. Record the **Dark**, **Red**, **Green**, and **Blue** references under stable lighting. The **Phone-specific optical equation** updates only after it receives those measurements. Export the calibration JSON and select **Use calibrated decoder**.
- Export CSV from the controls to inspect firing events, model state and estimated rates. Optional local session persistence uses IndexedDB; capture stops when backgrounded.

The app requests a low-resolution, low-power camera video stream, not full 50 MP still photographs. Real capture performance depends on phone/browser hardware. The app cannot read your phone hardware just because it is on the same ChatGPT account.

## Verification and limitations

Run `sh tests/run_tests.sh` with Node.js, Python + Playwright and Chromium installed. The source match, numerical regression, 600 cross-talk equations, browser interface, JSON export and synthetic camera stream have passed **in the development environment**.

The real coefficients are **not** preset for a Samsung. Four physical capture references are necessary; camera automatic exposure/white balance can affect accuracy. Quantitative spectral measurements require suitable controlled instrumentation. This is a real executable on-device numerical model, coupled to camera readings when permissions and HTTPS allow, rather than evidence of physical neurons or independent cognitive function.

Files: `index.html` (HTTPS PWA), `Ripple-Samsung-Open-Offline.html` (manual/offline browser), `ripple-core.js` (unaltered original), `original-simulator.html`, installation shell (`manifest.webmanifest`, `sw.js`, `icon-*`), `SOURCE_PROVENANCE.json`, `OPTICAL_MATH.md`, tests.
