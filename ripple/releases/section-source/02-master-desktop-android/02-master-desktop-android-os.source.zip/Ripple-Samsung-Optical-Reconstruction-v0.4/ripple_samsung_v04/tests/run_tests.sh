#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
node tests/test_core.cjs
node tests/test_optical_equation.cjs
python tests/test_browser.py
python tests/test_synthetic_camera.py
