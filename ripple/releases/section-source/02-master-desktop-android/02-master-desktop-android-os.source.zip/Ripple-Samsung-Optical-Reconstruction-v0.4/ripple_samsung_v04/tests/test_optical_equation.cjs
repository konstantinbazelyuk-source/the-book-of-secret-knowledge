// Test the actual optical functions extracted from shipped HTML, not reimplemented copies.
const fs=require('fs'), vm=require('vm'), assert=require('node:assert/strict');
const html=fs.readFileSync(__dirname+'/../index.html','utf8');
const t=html.slice(html.indexOf('const vector=(a,b)=>'),html.indexOf('const capCanvas='));
const ext=html.slice(html.indexOf('const OPTICAL_WEIGHTS='),html.indexOf('function updateOpticalEquation()'));
assert(t.includes('function makeDecoder(cal)')&&ext.includes('function effectiveOpticalEquation'));
const context={};vm.createContext(context);
vm.runInContext('const bound=(x,lo,hi)=>Math.max(lo,Math.min(hi,x));\n'+t+'\n'+ext+ '\nthis.f={makeDecoder,effectiveOpticalEquation,dot};',context);
const {makeDecoder,effectiveOpticalEquation,dot}=context.f;
const dark=[8,10,12], M=[[120,14,6],[12,125,18],[9,15,130]];
const col=(j)=>dark.map((base,i)=>base+M[i][j]);
const cal={dark,red:col(0),green:col(1),blue:col(2)};
const decoder=makeDecoder(cal);assert(decoder.inv&&decoder.cond<120,'Well-conditioned synthetic calibration');
const model=effectiveOpticalEquation(decoder,dark);
for(let t=0;t<600;t++){
 const x=[.1,.12,.05].map((v,i)=>(v + (t%13)/100 + (i===1?.2:0))); // 0 <= x <= 1
 const pix=M.map((row,i)=>dark[i]+dot(row,x));
 const direct=dot([2,1.2,-1.4],x);
 const reconstructed=dot(model.pixel_weights,pix)+model.bias;
 assert(Math.abs(direct-reconstructed)<1e-10,'Optical reconstruction must preserve model drive');
}
const bad={dark:[0,0,0],red:[80,80,80],green:[81,81,81],blue:[79,79,79]};
assert(!makeDecoder(bad).inv,'Singular calibration should be rejected');
console.log('OPTICAL EQUATION PASS: 600 cross-talk reconstructions, singular reference rejection. Synthetic data only.');
