"""Browser UI test with in-page bridge to actual local API, required by this restricted browser environment.

Not a native localhost browser integration test. API and OpenCV pipeline are independently tested.
"""
import base64
import http.client
import json
import socket
import sys
import threading
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'camera_tests'));sys.path.insert(0,str(ROOT/'camera_bridge'))
from test_camera import FakeCapture
from core import CameraStation
from server import build_server
from playwright.sync_api import sync_playwright

BRIDGE_JS='''
window.fetch=async(url,options={})=>{
 const b=await window.bridgeRequest(String(url),options.method||'GET',options.body||null,options.headers||{});
 return new Response(b.bytes?Uint8Array.from(atob(b.bytes),c=>c.charCodeAt(0)):b.text,{status:b.status,headers:{'Content-Type':b.mime}});
};
const __originalAnchorClick=HTMLAnchorElement.prototype.click;
HTMLAnchorElement.prototype.click=function(){if(this.getAttribute('href')==='/api/records'){window.__downloadRequested=true;return;}return __originalAnchorClick.call(this);};
window.addEventListener('click',ev=>{
 const anchor=ev.target.closest('a');
 if(anchor && anchor.getAttribute('href')==='/api/records'){
  ev.preventDefault();window.__downloadRequested=true;
 }
},true);
const imgObserver = new MutationObserver(()=>{
 const im=document.getElementById('preview');
 if(im && (im.getAttribute('src')||'').startsWith('/api/preview.jpg')){
  window.bridgeRequest('/api/preview.jpg','GET',null,{}).then(r=>{if(r.status===200)im.src='data:image/jpeg;base64,'+r.bytes;});
 }
});
window.addEventListener('DOMContentLoaded',()=>imgObserver.observe(document.getElementById('preview'),{attributes:true,attributeFilter:['src']}));
'''

def run():
    s=socket.socket();s.bind(('127.0.0.1',0));port=s.getsockname()[1];s.close()
    station=CameraStation(factory=lambda src:FakeCapture())
    srv=build_server(station,port)
    t=threading.Thread(target=srv.serve_forever,daemon=True);t.start()
    result={'browser_transport':'in-page network-bridge (localhost navigation blocked by administrator)',
            'mock_camera':True,'real_local_api':True,'page_errors':[],'steps':{}}
    try:
        with sync_playwright() as pw:
            browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
            page=browser.new_page(viewport={'width':390,'height':820})
            page.on('pageerror',lambda e:result['page_errors'].append(str(e)))
            def bridge(source,url,method,body,headers):
                p=url.split('?',1)[0]
                connection=http.client.HTTPConnection('127.0.0.1',port,timeout=25)
                hh={'Host':f'127.0.0.1:{port}'}
                if method=='POST':
                    hh.update({'Origin':f'http://127.0.0.1:{port}','Content-Type':'application/json'})
                    if isinstance(headers,dict):hh.update(headers)
                connection.request(method,p,body=body,headers=hh)
                response=connection.getresponse();data=response.read();status=response.status;ctype=response.getheader('Content-Type','application/json');connection.close()
                if ctype.startswith('image/jpeg'):
                    return {'status':status,'bytes':base64.b64encode(data).decode(),'text':'','mime':ctype}
                return {'status':status,'text':data.decode(errors='replace'),'mime':ctype}
            page.expose_binding('bridgeRequest',bridge)
            html=(ROOT/'camera_web'/'index.html').read_text()
            html=html.replace('<script>',f'<script>{BRIDGE_JS}</script><script>',1)
            page.goto('about:blank')
            page.set_content(html,wait_until='domcontentloaded')
            page.locator('#start').wait_for()
            page.locator('#start').click()
            page.locator('#runbadge').get_by_text('CAPTURE ON').wait_for(timeout=8000)
            page.wait_for_timeout(1600)
            result['steps']['start_button']=True
            result['steps']['preview_jpeg']=page.locator('#preview').evaluate('(img)=>img.complete&&img.naturalWidth>0')
            page.locator('#roiW').fill('25');page.locator('#setroi').click()
            page.wait_for_function("document.querySelector('#log').innerText.includes('roi succeeded')",timeout=5000)
            result['steps']['roi_button']=True
            page.locator('#control').select_option('gain');page.locator('#controlValue').fill('24');page.locator('#apply').click()
            page.wait_for_function("document.querySelector('#controlResult').innerText.includes('readback_matches_request')",timeout=7000)
            result['steps']['gain_control_backend']=True
            page.locator('#probe').click()
            page.wait_for_function("document.querySelector('#controlResult').innerText.includes('validated_hardware_causal_change')",timeout=8000)
            result['steps']['pixel_probe_report']=True
            page.locator('#analyze').click()
            page.wait_for_function("document.querySelector('#result').innerText.includes('original_spikes')",timeout=16000)
            result['steps']['original_neuron_called']=True
            page.locator('#export').click()
            result['steps']['export_button']=page.evaluate('window.__downloadRequested===true')
            page.locator('#stop').click()
            page.locator('#runbadge').get_by_text('CAPTURE OFF').wait_for(timeout=7000)
            result['steps']['stop_button']=True
            page.screenshot(path=str(ROOT/'camera_results'/'station_mobile_mock.png'),full_page=True)
            browser.close()
    finally:
        station.stop();srv.shutdown();srv.server_close();t.join(timeout=2)
    result['passed']=all(result['steps'].values()) and not result['page_errors']
    (ROOT/'camera_results'/'browser_test.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    return result
if __name__=='__main__':
    if not run()['passed']:raise SystemExit(1)
