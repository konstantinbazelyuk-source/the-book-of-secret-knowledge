import http.client
import json
import os
from pathlib import Path
import socket
import sys
import tempfile
import threading
import time
import unittest
import numpy as np
import cv2
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'camera_bridge'),str(ROOT/'src')]
from core import CameraStation, frame_to_rgb
from server import build_server
from master import GuardedStream, inherited_genomes


class FakeCapture:
    def __init__(self,source=0,*,reject=False):
        self.source=source;self.closed=False;self.props={cv2.CAP_PROP_EXPOSURE:10.,cv2.CAP_PROP_FPS:30.};self.reject=reject;self.n=0
    def isOpened(self):return not self.closed
    def getBackendName(self):return 'FAKE_TEST_BACKEND'
    def release(self):self.closed=True
    def read(self):
        if self.closed:return False,None
        self.n+=1
        f=np.zeros((40,60,3),dtype=np.uint8)
        f[:,:,0]=25;f[:,:,1]=80;f[:,:,2]=(60+self.n)%255
        return True,f
    def get(self,key):return self.props.get(key,0.)
    def set(self,key,value):
        if self.reject:return False
        self.props[key]=value
        return True


def make_fixture(path,frames=36):
    writer=cv2.VideoWriter(str(path),cv2.VideoWriter_fourcc(*'MJPG'),20,(64,48))
    if not writer.isOpened():raise unittest.SkipTest('OpenCV MJPG encoder unavailable')
    for k in range(frames):
        frame=np.zeros((48,64,3),dtype=np.uint8)
        frame[:,:]=(20,20+(k*3)%200,200-(k*2)%100)
        writer.write(frame)
    writer.release()

class CameraTests(unittest.TestCase):
    def test_01_bgr_to_rgb_correct_order(self):
        frame=np.zeros((8,8,3),np.uint8);frame[:]=(10,80,220)
        rgb=frame_to_rgb(frame,(0,0,1,1))
        self.assertTrue(np.allclose(rgb,[220/255,80/255,10/255]))
    def test_02_roi_changes_input(self):
        f=np.zeros((10,10,3),np.uint8);f[:,:5]=(0,0,255);f[:,5:]=(255,0,0)
        self.assertGreater(frame_to_rgb(f,(0,0,.5,1))[0],.99)
        self.assertGreater(frame_to_rgb(f,(.5,0,.5,1))[2],.99)
    def test_03_invalid_roi_rejected(self):
        s=CameraStation(factory=lambda x:FakeCapture())
        with self.assertRaises(ValueError):s.update_roi([.8,.4,.4,.2])
    def test_04_no_automatic_capture(self):
        s=CameraStation(factory=lambda x:FakeCapture())
        self.assertFalse(s.status()['running']);self.assertEqual(s.status()['frames'],0)
    def test_05_capture_to_master_schema(self):
        s=CameraStation(factory=lambda x:FakeCapture())
        self.assertTrue(s.start()['running'])
        time.sleep(.08);s.stop()
        frames=s.events();self.assertGreaterEqual(len(frames),3)
        gate=GuardedStream()
        for f in frames:gate.accept(f)
        self.assertEqual(frames[0]['source'],'hardware_reported_unverified')
    def test_06_driver_control_true_readback(self):
        s=CameraStation(factory=lambda x:FakeCapture());s.start()
        a=s.set_control('exposure',42)
        self.assertTrue(a['backend_set_returned'])
        self.assertTrue(a['readback_matches_request'])
        self.assertFalse(a['verified_effect_on_hardware'])
        s.stop()
    def test_07_driver_control_refused(self):
        s=CameraStation(factory=lambda x:FakeCapture(reject=True));s.start()
        a=s.set_control('exposure',42)
        self.assertFalse(a['backend_set_returned'])
        self.assertFalse(a['readback_matches_request'])
        s.stop()
    def test_08_unknown_control_rejected(self):
        s=CameraStation(factory=lambda x:FakeCapture());s.start()
        with self.assertRaises(ValueError):s.set_control('run_shell',1)
        s.stop()
    def test_09_out_of_range_rejected(self):
        s=CameraStation(factory=lambda x:FakeCapture());s.start()
        with self.assertRaises(ValueError):s.set_control('gain',9000)
        s.stop()
    def test_10_stop_releases_capture(self):
        captures=[]
        def factory(x):
            c=FakeCapture();captures.append(c);return c
        s=CameraStation(factory=factory);s.start();time.sleep(.03);s.stop()
        self.assertTrue(captures[0].closed)
        self.assertFalse(s.status()['running'])
    def test_11_missing_device_refused(self):
        class Broken(FakeCapture):
            def isOpened(self):return False
        s=CameraStation(factory=lambda x:Broken());status=s.start()
        self.assertFalse(status['running']);self.assertIn('Unable to open',status['error'])
    def test_12_replay_has_distinct_provenance(self):
        s=CameraStation('foo.avi',factory=lambda x:FakeCapture())
        s.start();time.sleep(.03);s.stop()
        self.assertEqual(s.status()['origin'],'video_file_replay')
        self.assertEqual(s.events()[0]['source'],'simulated') # compatibility mapping: see provenance note
        with self.assertRaises(ValueError):s.set_control('exposure',1)
    def test_13_file_video_real_opencv_capture(self):
        with tempfile.TemporaryDirectory() as d:
            movie=Path(d)/'fixture.avi';make_fixture(movie)
            s=CameraStation(str(movie));s.start()
            deadline=time.monotonic()+4
            while s.status()['running'] and time.monotonic()<deadline:time.sleep(.04)
            if s.status()['running']:s.stop()
            self.assertEqual(s.status()['frames'],36)
            self.assertEqual(len(s.events()),36)
            self.assertEqual(s.status()['origin'],'video_file_replay')
            self.assertEqual(s.status()['width_height'],(64,48))
            self.assertIsNotNone(s.jpeg())
    def test_14_full_original_master_processing_via_camera_frames(self):
        s=CameraStation(factory=lambda x:FakeCapture())
        s.start();time.sleep(.35);s.stop()
        output=s.analyze('prism')
        self.assertEqual(output['camera_bridge']['mode'],'live_device_unverified')
        self.assertIsNotNone(output['legacy_neuron'])
        self.assertEqual(output['classification'],'hardware_reported_unverified')
        self.assertTrue(output['capability_registry']['optical_rgb']['enabled'])
        self.assertFalse(output['magnetic']['available'])
        self.assertTrue(output['camera_bridge']['frames_analyzed']>0)
    def test_15_replay_report_retains_origin(self):
        s=CameraStation('fixture.avi',factory=lambda x:FakeCapture())
        s.start();time.sleep(.07);s.stop()
        out=s.analyze('canopy')
        self.assertEqual(out['camera_bridge']['mode'],'video_file_replay')
        self.assertEqual(out['classification'],'video_file_replay_unverified')
        self.assertEqual(out['master_v2_internal_classification'],'simulated')
        self.assertIn('replay',out['camera_bridge']['replay_mapping'])
    def test_16_open_camera_twice_is_idempotent(self):
        n=[]
        def maker(x):n.append(x);return FakeCapture()
        s=CameraStation(factory=maker);s.start();s.start();s.stop()
        self.assertEqual(len(n),1)
    def test_17_strict_timestamp_increase(self):
        s=CameraStation(factory=lambda x:FakeCapture());s.start();time.sleep(.08);s.stop()
        ts=[x['t_ms'] for x in s.events()]
        self.assertTrue(all(b>a for a,b in zip(ts,ts[1:])))
    def test_18_video_frame_bad_dtype_rejected(self):
        with self.assertRaises(ValueError):frame_to_rgb(np.zeros((10,10,3),dtype=np.float64),(0,0,1,1))
    def test_19_bounded_recording(self):
        s=CameraStation(factory=lambda x:FakeCapture());s.start();time.sleep(.08);s.stop()
        self.assertLessEqual(len(s.events()),512)
    def test_32_control_pixel_probe_is_not_hardware_calibration(self):
        s=CameraStation(factory=lambda x:FakeCapture());s.start();time.sleep(.12)
        result=s.probe_control('gain',42,samples=4)
        self.assertFalse(result['validated_hardware_causal_change'])
        self.assertEqual(result['samples_after'],4)
        self.assertTrue(result['control_setting_report']['readback_matches_request'])
        s.stop()
    def test_33_control_probe_replay_rejected(self):
        s=CameraStation('file.avi',factory=lambda x:FakeCapture())
        with self.assertRaises(ValueError):s.probe_control('gain',42)
    def test_34_network_stream_provenance_separate(self):
        s=CameraStation('rtsp://login:private@127.0.0.1:8554/cam',factory=lambda x:FakeCapture())
        self.assertIn('127.0.0.1',s.status()['source'])
        self.assertNotIn('private',s.status()['source'])
        s.start();time.sleep(.035);s.stop()
        self.assertEqual(s.status()['origin'],'live_stream_unverified')
        self.assertEqual(s.events()[0]['source'],'hardware_reported_unverified')
        with self.assertRaises(ValueError):s.set_control('gain',12)

    def test_20_genome_must_be_known(self):
        with self.assertRaises(ValueError):CameraStation().analyze('imaginary-brain')

class ApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.station=CameraStation(factory=lambda x:FakeCapture())
        sock=socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1];sock.close()
        cls.server=build_server(cls.station,port)
        cls.port=cls.server.server_port
        cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start()
    @classmethod
    def tearDownClass(cls):
        cls.station.stop();cls.server.shutdown();cls.server.server_close();cls.thread.join(timeout=2)
    def request(self,method,path,payload=None,headers=None):
        c=http.client.HTTPConnection('127.0.0.1',self.port,timeout=20)
        body=json.dumps(payload).encode() if payload is not None else None
        h={'Host':f'127.0.0.1:{self.port}'}
        if headers:h.update(headers)
        if body is not None:h['Content-Type']='application/json'
        c.request(method,path,body=body,headers=h)
        r=c.getresponse();content=r.read();status=r.status;c.close()
        try:val=json.loads(content)
        except (ValueError,UnicodeError):val=content
        return status,val
    def post(self,path,data,token=None,origin=None):
        stat,body=self.request('GET','/api/status');t=body['csrf_token'] if token is None else token
        return self.request('POST',path,data,{'X-Ripple-Token':t,'Origin':origin or f'http://127.0.0.1:{self.port}'})
    def test_21_dashboard_served(self):
        st,data=self.request('GET','/');self.assertEqual(st,200);self.assertIn(b'MASTER RIPPLE',data)
    def test_22_start_api(self):
        st,body=self.post('/api/start',{});self.assertEqual(st,200);self.assertTrue(body['running'])
    def test_23_control_api(self):
        self.post('/api/start',{})
        st,body=self.post('/api/control',{'name':'gain','value':12});self.assertEqual(st,200);self.assertTrue(body['backend_set_returned'])
    def test_24_roi_api(self):
        st,body=self.post('/api/roi',{'roi':[0,.1,.2,.3]});self.assertEqual(st,200);self.assertEqual(body['roi'],[0,.1,.2,.3])
    def test_25_analysis_endpoint(self):
        self.post('/api/start',{});time.sleep(.10)
        st,body=self.post('/api/analyze',{'genome':'prism'})
        self.assertEqual(st,200);self.assertIn('legacy_neuron',body)
    def test_26_export_endpoint(self):
        self.post('/api/start',{});time.sleep(.04)
        st,body=self.request('GET','/api/records');self.assertEqual(st,200);self.assertIn(b'optical_rgb',body)
    def test_27_preview_endpoint(self):
        self.post('/api/start',{});time.sleep(.04)
        st,body=self.request('GET','/api/preview.jpg');self.assertEqual(st,200);self.assertTrue(body.startswith(b'\xff\xd8'))
    def test_28_post_without_valid_token_denied(self):
        st,body=self.post('/api/stop',{},token='wrong');self.assertEqual(st,403)
    def test_29_cross_origin_denied(self):
        st,body=self.post('/api/stop',{},origin='https://evil.invalid');self.assertEqual(st,403)
    def test_30_unsupported_control_denied(self):
        st,body=self.post('/api/control',{'name':'shell','value':0});self.assertEqual(st,400)
    def test_35_probe_endpoint(self):
        self.post('/api/start',{});time.sleep(.10)
        st,body=self.post('/api/probe',{'name':'gain','value':36})
        self.assertEqual(st,200)
        self.assertFalse(body['validated_hardware_causal_change'])

    def test_31_stop_endpoint(self):
        st,body=self.post('/api/stop',{});self.assertEqual(st,200);self.assertFalse(body['running'])

if __name__=='__main__':unittest.main(verbosity=2)
