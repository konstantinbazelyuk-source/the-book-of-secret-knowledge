"""Full subprocess integration: actual OpenCV MJPG decoder -> HTTP server -> original Master neuron."""
import json
import socket
import subprocess
import sys
import time
import urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
file=ROOT/'camera_fixtures'/'synthetic_color_target_160f.avi'
s=socket.socket();s.bind(('127.0.0.1',0));port=s.getsockname()[1];s.close()
origin=f'http://127.0.0.1:{port}'
process=subprocess.Popen([sys.executable,str(ROOT/'Launch_Master_Ripple_Camera.py'),'--file',str(file),'--port',str(port),'--no-browser'],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
report={'test':'subprocess_opencv_video_to_master','source':'generated synthetic AVI test input','url':origin}

def get(path):
    with urllib.request.urlopen(origin+path,timeout=15) as r:return r.read()

def post(path,params,token):
    req=urllib.request.Request(origin+path,data=json.dumps(params).encode(),headers={
        'Content-Type':'application/json','Origin':origin,'X-Ripple-Token':token},method='POST')
    with urllib.request.urlopen(req,timeout=20) as r:return json.load(r)

try:
    token=None
    for _ in range(50):
        if process.poll() is not None:raise RuntimeError('server exited before responding')
        try:
            first=json.loads(get('/api/status'));token=first['csrf_token'];break
        except Exception:time.sleep(.1)
    if token is None:raise RuntimeError('server failed to start')
    info=post('/api/start',{},token)
    assert info['running'],info
    print('Input started; waiting for decoder to complete',flush=True)
    for _ in range(140):
        state=json.loads(get('/api/status'))['status']
        if not state['running']:break
        time.sleep(.12)
    assert state['frames']==160,state
    assert state['origin']=='video_file_replay',state
    data=get('/api/records').decode().strip().splitlines()
    assert len(data)==160,len(data)
    first=json.loads(data[0]);assert first['source']=='simulated'
    report['decoded_frames']=len(data)
    report['first_frame_rgb']=first['values']
    report['source_origin']=state['origin']
    result=post('/api/analyze',{'genome':'prism'},token)
    assert 'legacy_neuron' in result and result['legacy_neuron']
    assert result['camera_bridge']['frames_analyzed']==128
    assert result['camera_bridge']['mode']=='video_file_replay'
    report['original_neuron_spikes']=result['legacy_neuron']['total_raw_spikes']
    report['inherited_weighted_spikes']=result['legacy_neuron']['total_weighted_spikes']
    report['passed']=True
finally:
    process.terminate()
    try:stdout,stderr=process.communicate(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill();stdout,stderr=process.communicate(timeout=5)
    report['server_stdout']=stdout.decode(errors='replace')[-2500:]
    report['server_stderr_tail']=stderr.decode(errors='replace')[-1000:]
(ROOT/'camera_results'/'process_integration.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if not k.startswith('server_')},indent=2))
