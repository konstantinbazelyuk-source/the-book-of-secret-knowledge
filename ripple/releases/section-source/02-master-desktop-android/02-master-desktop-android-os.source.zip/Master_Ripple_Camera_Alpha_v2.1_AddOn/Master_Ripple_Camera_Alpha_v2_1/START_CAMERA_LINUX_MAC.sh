#!/bin/sh
cd "$(dirname "$0")" || exit 1
python3 Launch_Master_Ripple_Camera.py --device 0
