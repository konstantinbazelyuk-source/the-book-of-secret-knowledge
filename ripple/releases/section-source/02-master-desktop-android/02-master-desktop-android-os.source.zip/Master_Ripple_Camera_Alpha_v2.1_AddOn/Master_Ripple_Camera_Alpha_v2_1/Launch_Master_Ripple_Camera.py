"""Start a real OpenCV camera program connected to frozen Master Ripple v2.0."""
from camera_bridge.server import main
if __name__=='__main__':main()
