@echo off
cd /d "%~dp0"
py -3 Launch_Master_Ripple_Camera.py --device 0
if errorlevel 1 (
 echo.
 echo If packages are missing, run: py -3 -m pip install -r requirements_camera.txt
 pause
)
