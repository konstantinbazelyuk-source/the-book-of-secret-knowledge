"""Create a clearly synthetic camera video for testing the OpenCV decoder and Ripple pipeline."""
from pathlib import Path
import cv2
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
DEST=ROOT/'camera_fixtures'/'synthetic_color_target_160f.avi'

def main():
    DEST.parent.mkdir(parents=True,exist_ok=True)
    width,height,frames=160,120,160
    out=cv2.VideoWriter(str(DEST),cv2.VideoWriter_fourcc(*'MJPG'),20,(width,height))
    if not out.isOpened():raise RuntimeError('MJPG AVI encoder unavailable')
    for t in range(frames):
        f=np.zeros((height,width,3),dtype=np.uint8)
        f[:]=(15,20,30)
        color=((35+t*3)%256, int(70+40*np.sin(t*.09)), int(105+55*np.cos(t*.07)))
        x=25+int(25*np.sin(t*.09));y=28+int(22*np.cos(t*.07))
        cv2.rectangle(f,(x,y),(x+64,y+53),color,-1)
        cv2.putText(f,'SIMULATED', (6,115),cv2.FONT_HERSHEY_SIMPLEX,.34,(150,160,175),1,cv2.LINE_AA)
        out.write(f)
    out.release()
    print('Created generated synthetic video:',DEST)
if __name__=='__main__':main()
