"""Reproducible release manifest and archives; never modifies the frozen original files."""
from __future__ import annotations
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT.parent
ORIG=OUT/'Master_Ripple_Alpha_v2_0'
FULL=OUT/'Master_Ripple_Camera_Alpha_v2.1_Complete.zip'
ADDON=OUT/'Master_Ripple_Camera_Alpha_v2.1_AddOn.zip'
SKIP={'__pycache__','.pytest_cache','.DS_Store'}
oldfiles=[p for p in ORIG.rglob('*') if p.is_file() and not (set(p.relative_to(ORIG).parts)&SKIP)]
mutations=[]
for p in oldfiles:
    q=ROOT/p.relative_to(ORIG)
    if not q.exists() or hashlib.sha256(q.read_bytes()).digest()!=hashlib.sha256(p.read_bytes()).digest():
        mutations.append(str(p.relative_to(ORIG)))
if mutations:raise RuntimeError(f'Refusing packaging: original files were changed: {mutations[:4]}')
browser=json.loads((ROOT/'camera_results/browser_test.json').read_text())
process=json.loads((ROOT/'camera_results/process_integration.json').read_text())
audit={'release':'Master Ripple Camera Alpha v2.1',
       'code_classification':'open-source live camera/recorded-video software adapter',
       'original_master_source_files_checked':len(oldfiles),
       'original_master_source_files_changed':0,
       'camera_unit_and_http_tests_passed':35,
       'preserved_master_regressions_passed':46,
       'browser_in_page_bridge_steps':len(browser['steps']),
       'browser_in_page_bridge_passed':browser['passed'],
       'browser_real_localhost_navigation_tested':False,
       'browser_real_navigation_limitation':'restricted test Chromium reports ERR_BLOCKED_BY_ADMINISTRATOR',
       'video_decoder_actual_opencv_frames':process['decoded_frames'],
       'synthetic_fixture_video_spikes_original':process['original_neuron_spikes'],
       'synthetic_fixture_video_spikes_weighted':process['inherited_weighted_spikes'],
       'usb_camera_attached_and_physically_tested':False,
       'hardware_controls_calibrated':False,
       'network_stream_physically_tested':False,
       'source_provenance_guardrail':'live device unverified vs video file replay unverified; no infrared/EM/scientific aura claims',
       'no_external_upload':True}
(ROOT/'CAMERA_RELEASE_AUDIT.json').write_text(json.dumps(audit,indent=2)+'\n')

def members(is_addon):
    for p in sorted(ROOT.rglob('*')):
        if not p.is_file() or any(part in SKIP for part in p.relative_to(ROOT).parts):continue
        relative=p.relative_to(ROOT)
        if is_addon and ((ORIG/relative).exists()):continue
        if p.name.endswith('.pyc'):continue
        yield p, relative

for path,small in ((FULL,False),(ADDON,True)):
    with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as zipf:
        for p,rel in members(small):
            zipf.write(p, arcname=f'Master_Ripple_Camera_Alpha_v2_1/{rel.as_posix()}')
    with zipfile.ZipFile(path) as zipf:
        err=zipf.testzip()
        if err is not None:raise RuntimeError(f'Corrupt ZIP {err}')
        print(path.name,zipf.testzip(),len(zipf.namelist()),path.stat().st_size,flush=True)
print(json.dumps(audit,indent=2))
