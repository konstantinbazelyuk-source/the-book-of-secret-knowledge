# Master Ripple Camera Alpha v2.1 — Start here

## Status / scientific honesty

This is a working **OpenCV software integration** for an optical camera channel. It runs the **original Master Ripple Alpha v2.0 neuron and photoreceptor** without overwriting any archived source. It is not a new AI model, verified intelligence, light-field magnetometer, calibrated spectrometer, or validated camera hardware product.

**Tested in this release:** Real OpenCV MJPG/AVI decoding and frame export; Master JS neuron execution on decoded frames; software API; UI with pixel mocks and an in-page loopback bridge; eight software control interactions; two control backend simulations (accept/reject).  **Not tested in this environment:** a physically attached USB webcam, actual exposure/gain/focus hardware changes, internet network camera interoperability, Samsung hardware camera permissions.

## Run on Windows / macOS / Linux

1. Extract the ZIP into a folder. Install **Python 3.10+** and **Node.js 18+**.
2. In that folder, install dependencies: `python -m pip install -r requirements_camera.txt` (on Windows use `py -3 -m pip ...` if `python` is unavailable).
3. Connect a USB/UVC webcam, or use your computer's integrated camera.
4. Run `python Launch_Master_Ripple_Camera.py --device 0` (Windows: `py -3 Launch_Master_Ripple_Camera.py --device 0`).
5. Open `http://127.0.0.1:8788/` if it did not open automatically. Click **Start capture**. The program does NOT turn the camera on until you click.
6. Watch the RGB readings change, adjust ROI, then click **Analyze buffered frames**. Select any inherited genome to compare the Master data pathways. Click **Stop** to release the camera.
7. Click **Export RGB JSONL** to save the exact timed observations in the original Master v2.0 typed input shape.

If camera `0` fails, try `--device 1`, check camera permissions and close other applications holding the device. **No connected camera was available in the engineering test environment.**

### Test with the included synthetic video (does not require a webcam)

`python Launch_Master_Ripple_Camera.py --file camera_fixtures/synthetic_color_target_160f.avi`

Press Start to decode all 160 generated frames over ~8 seconds. You may analyze after playback ends. The camera station labels the source **video file replay**, and it does not offer hardware controls in this mode. To avoid altering the frozen v2 schema, the adapter encodes replay samples as `simulated` at the v2 input boundary; the **top-level v2.1 result uses `video_file_replay_unverified`**, since a user-supplied video file is not necessarily synthetic. This conversion is documented explicitly rather than disguised.

### Network camera / phone as a stream (optional)

If a **trusted, user-controlled camera** already provides a working RTSP / HTTP(S) video endpoint and its encoding is supported by the local OpenCV installation:

`python Launch_Master_Ripple_Camera.py --stream 'rtsp://YOUR_CAMERA_ON_LOCAL_NETWORK/stream'`

Replace the URL with the actual endpoint given by your camera vendor; no URL can be inferred or fabricated. Only run this with streams you own or are authorized to access. Some smartphones can supply a UVC webcam or local network video feed with separately installed software; **that capability is not automatically provided by this ZIP**. Stream support is backend-dependent and has not been validated against a real camera. Remote camera settings usually must be changed through the camera's own API or application; they cannot be asserted through OpenCV without confirmation. The service binds to **127.0.0.1 only**, so it is NOT available from other devices as a hosted dashboard.

### Samsung Android phone itself

This Python/OpenCV local server is intended for a PC or a computer with suitable Python support. It does **not** install or control Samsung Camera2 directly. The **preserved Master v2.0 browser sensor page**, launched via `python Start_Master_Ripple.py` on a computer, also contains a browser-based `getUserMedia` camera path. Accessing that page **from an Android phone** typically requires a secure HTTPS origin and explicit browser permission, as the original docs explain; this release does not create an Android APK or automatically host HTTPS.

## Physical camera control panel

- Start/stop capture and optional JPEG preview of live frames.
- Select pixel ROI by normalized X/Y/width/height and observe RGB values in [0,1].
- Request backend controls: exposure, auto exposure, gain, focus, autofocus, FPS, brightness, contrast, white balance and auto-white-balance.
- See the requested value, whether `cv2.VideoCapture.set()` returned true, the value `get()` reported before and after, and whether that numeric value matched the request.
- **Test pixel response** records ROI luminance before/after a requested control adjustment. Any difference is **observed, not causally verified**; auto exposure, ambient lighting, compression, digital processing and driver behavior can confound it. Keep subject and light fixed, repeat trials, and use a reference target for real hardware validation.
- Camera backends can ignore or encode controls differently. If `set()` and `get()` disagree, the station reports that discrepancy; even agreement is not proof of a physical change.

## Real measurement limitations

The RGB sample is computed by averaging a normalized ROI in **8-bit BGR decoded frames**. It is *not* calibrated irradiance, wavelength, photon count, an instantaneous optical electric/magnetic field, or a person's aura. The original Ripple neuron receives an `optical_rgb` time series but **does not** receive gamma radiation, magnetic fields, or brain-wave measurements from this camera. Changes of camera gain/exposure can change the pixel values without physical illumination changes.

`--device` or `--stream` input is labeled `hardware_reported_unverified` at Master v2 input: the assertion is about the intended source, not independent verification of its identity, accuracy, or calibration. All recorded hardware measurements in this release should be calibrated and validated with test targets before publication as physically meaningful observations.

## Working modules and integrity

- `camera_bridge/core.py`: OpenCV frame capture, ROI mean RGB, monotonic frame time, bounded ring buffer, strict Master-schema translation, camera control requests/response audit, pixel response probe, Master analyzer.
- `camera_bridge/server.py`: opt-in localhost camera server, same-origin token-checked control endpoints, still JPEG, ROI record export.
- `camera_web/index.html`: browser dashboard with capture, controls and per-genome analysis.
- `Launch_Master_Ripple_Camera.py`: entry point.
- `camera_fixtures/`: synthetically generated camera video plus code to reproduce it.
- `camera_tests/`: mock camera, real OpenCV video, REST API and browser-in-page bridge tests.
- `camera_results/`: actual test logs and results, including provenance.
- `src/`, `legacy/`, `web/`, `docs/`, `frozen_archives/`, original launcher, tests, README: **unchanged v2.0 source**.

Commands:

```sh
python src/verify_sources.py
python -m unittest discover -s tests -p test_master.py
python -m unittest discover -s camera_tests -p test_camera.py
python camera_tests/test_process_integration.py
# Optional developer-only browser test: requires playwright and a system Chromium:
python camera_tests/test_browser.py
```

## Sources / dependency provenance

No copyrighted OpenCV source code was copied into the package. The camera bridge calls the documented **public Python APIs of installed OpenCV**. OpenCV is free and open source; refer to your installed dependency's license file.

- Official OpenCV `VideoCapture` interface: https://docs.opencv.org/5.0/main_modules/classcv_1_1VideoCapture.html
- Official OpenCV video/camera guide: https://opencv.org/reading-and-writing-videos-using-opencv/
- Linux V4L2 camera controls reference: https://docs.kernel.org/userspace-api/media/v4l/ext-ctrls-camera.html
- Linux V4L2 user controls: https://www.kernel.org/doc/html/latest/userspace-api/media/v4l/control.html

**License:** New camera adapter MIT, same as the new Master Alpha code. Preserved older archives retain their original licenses; this extension does not relicense them. No automatic upload, external monitoring, remote actuation or unattended camera starting occurs.
