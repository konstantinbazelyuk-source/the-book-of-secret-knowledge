# Master Ripple Camera Colony Alpha v2.2

Standalone full package: open `Master_Ripple_Camera_Alpha_v2_1/COLONY_START_HERE.md` and run the listed commands. Existing frozen Ripple mathematics is preserved.
