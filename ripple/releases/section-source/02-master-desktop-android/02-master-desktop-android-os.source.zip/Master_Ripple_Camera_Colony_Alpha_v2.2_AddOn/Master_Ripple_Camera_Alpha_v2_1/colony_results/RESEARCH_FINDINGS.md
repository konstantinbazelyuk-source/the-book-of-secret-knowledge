# Engineering results — Master Ripple Colony v2.2

Full workload on 192 frames × 7 tasks = **1,344 executed tasks**. For the seed-13 training replay, median of two timed runs: 1 worker **1617.797 ms**, 2 workers **1075.861 ms**, 4 workers **613.802 ms**. The same-workload outputs were numerically equivalent.

**Hybrid policy:** 981 of 1,344 tasks (72.99%), with a 100% positive-frame overlap for the four narrowly defined, exhaustive-reference detectors in this fixture. **Not a 100% general accuracy claim.** The skipped tasks might carry useful information for other tasks and other sources.

**Demand-only policy:** 739 tasks, but matched only 14.3% of the exhaustive positive blur frames. The hybrid fixes this particular coverage failure by running blur monitoring on all frames.

**Spatial colony from unchanged SpiderScan:** 17 births and 15 retirements, with 65 modeled spike events in the synthetic 192-frame run. These do not indicate autonomous intelligence.

**Negative controls:** field reconstruction, 3D distance mapping, radiation sensing and absolute optical power measurement are not possible from this ordinary monocular RGB feed without additional hardware/calibration. No sensor access occurred on the test host.

Timing and comparisons are specific to synthetic video decoded through OpenCV on this host. Holdout seed 29 changes random noise but not the scheduled event geometry. Read the original JSON files for every measured metric, and `RELEASE_AUDIT_v2_2.json` for continuity checks.
