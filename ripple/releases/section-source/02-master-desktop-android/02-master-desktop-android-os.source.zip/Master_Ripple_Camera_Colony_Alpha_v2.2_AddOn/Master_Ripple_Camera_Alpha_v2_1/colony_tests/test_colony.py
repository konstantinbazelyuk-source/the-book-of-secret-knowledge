"""Regression and provenance tests for real executable camera tasks."""
import json
import math
from pathlib import Path
import sys
import tempfile
import threading
import time
import unittest

import cv2
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT/'camera_bridge'))
from colony_lab.engine import (TASKS,execute,validate_frames,task_compute,tasks_for_frames,
    decode_video,run_experiment,verify_equal,evaluate_task_coverage)
from colony_lab.fixture import generate
from core import CameraStation
from server import build_server

class ColonyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        p=ROOT/'colony_fixtures'/'seed13.avi'
        if not p.exists():generate(p,13)
        cls.frames,cls.fps=decode_video(p,limit=48)
    def test_01_task_family_executable(self):
        self.assertEqual(len(TASKS),7)
        for name in TASKS:self.assertIsInstance(task_compute(name,self.frames[2],self.frames[1]),dict)
    def test_02_pure_original(self):
        f=self.frames[2].copy();task_compute('edge_density',f,self.frames[1]);self.assertTrue(np.array_equal(f,self.frames[2]))
    def test_03_parallel_numeric_equivalence(self):
        jobs,_=tasks_for_frames(self.frames,'full')
        one=execute(self.frames,jobs,1);more=execute(self.frames,jobs,4)
        self.assertTrue(verify_equal(one['results'],more['results']))
    def test_04_full_finite(self):
        self.assertEqual(len(tasks_for_frames(self.frames,'full')[0]),len(self.frames)*7)
    def test_05_fixed_bounded(self):
        full=len(tasks_for_frames(self.frames,'full')[0]);work,_=tasks_for_frames(self.frames,'fixed');self.assertLess(len(work),full)
    def test_06_hybrid_fewer_tasks(self):
        full=len(tasks_for_frames(self.frames,'full')[0]);work,_=tasks_for_frames(self.frames,'hybrid');self.assertLess(len(work),full)
    def test_07_hybrid_retains_quality(self):
        hybrid=set(tasks_for_frames(self.frames,'hybrid')[0]);self.assertTrue(all((i,'focus_laplacian') in hybrid for i in range(len(self.frames))))
        self.assertTrue(all((i,'dark_fraction') in hybrid for i in range(len(self.frames))))
    def test_08_no_bad_task(self):
        with self.assertRaises(ValueError):task_compute('gamma_radiation',self.frames[0],None)
    def test_09_bad_shape_rejected(self):
        with self.assertRaises(ValueError):validate_frames([np.zeros((16,16),np.uint8)]*3)
    def test_10_bad_dtype_rejected(self):
        with self.assertRaises(ValueError):validate_frames([np.zeros((16,16,3),np.float64)]*3)
    def test_11_bad_resolution_rejected(self):
        with self.assertRaises(ValueError):validate_frames([np.zeros((900,900,3),np.uint8)]*3)
    def test_12_bad_worker_count_rejected(self):
        with self.assertRaises(ValueError):execute(self.frames,[(0,'rgb')],workers=100)
    def test_13_no_camera_by_default(self):
        s=CameraStation(factory=lambda x: (_ for _ in ()).throw(RuntimeError('should never open')))
        self.assertFalse(s.status()['colony_enabled']);self.assertEqual(s.status()['colony_buffered'],0)
    def test_14_explicit_bool_only(self):
        s=CameraStation();
        with self.assertRaises(ValueError):s.set_colony('true')
    def test_15_no_colony_without_optin(self):
        s=CameraStation();
        with self.assertRaises(RuntimeError):s.run_colony()
    def test_16_enable_then_disable_clears(self):
        s=CameraStation();s.set_colony(True)
        self.assertTrue(s.status()['colony_enabled']);s.set_colony(False)
        self.assertFalse(s.status()['colony_enabled'])
    def test_17_cannot_force_original_tuning(self):
        from master import inherited_genomes
        g=inherited_genomes()['prism']
        self.assertTrue(g.marker())
    def test_18_inherited_spiderscan_actual_neuron(self):
        from colony_lab.inherited_spiderscan.legacy.colony_v04 import Colony
        c=Colony();r=c.step(self.frames[0],1/24)
        self.assertGreaterEqual(r['active_nodes'],2);self.assertGreaterEqual(len(r['records']),2)
    def test_19_tile_texture_not_density(self):
        r=task_compute('tile_texture',self.frames[0],None)
        self.assertEqual(len(r['tile_gray_stdev_8bit']),16)
    def test_20_occlusion_not_inferred(self):
        self.assertIn('central_roi_fraction_gray_below_55',task_compute('dark_fraction',self.frames[0],None))
    def test_21_source_file_unchanged(self):
        import hashlib
        old=ROOT/'legacy'/'ripple-core.js'
        import zipfile
        original_zip=ROOT.parents[1]/'Master_Ripple_Camera_Alpha_v2.1_Complete.zip'
        with zipfile.ZipFile(original_zip) as z:
            saved=z.read('Master_Ripple_Camera_Alpha_v2_1/legacy/ripple-core.js')
        self.assertEqual(hashlib.sha256(old.read_bytes()).hexdigest(),hashlib.sha256(saved).hexdigest())
    def test_22_invalid_frequency(self):
        with self.assertRaises(ValueError):run_experiment(self.frames,0,repetitions=1,include_legacy=False)
    def test_23_negative_reference_does_not_invent(self):
        same=[self.frames[0].copy() for _ in range(32)]
        r=run_experiment(same,24,workers=(1,),repetitions=1,include_legacy=False)
        self.assertEqual(r['selective_policies']['hybrid']['coverage']['motion']['selected_positive_frames'],0)
    def test_24_known_marker(self):
        meta=json.loads((ROOT/'colony_fixtures'/'seed13.json').read_text())
        self.assertEqual(meta['seed'],13)
    def test_25_research_must_be_real_task(self):
        jobs,_=tasks_for_frames(self.frames,'hybrid');r=execute(self.frames,jobs,2)
        self.assertEqual(len(r['results']),len(jobs))
    def test_26_no_physical_claim(self):
        r=run_experiment(self.frames,24,workers=(1,),repetitions=1,include_legacy=False)
        self.assertIn('not a magnetic field sensor',r['limitations'])
    def test_28_camera_station_colony_really_executes(self):
        from camera_tests.test_camera import FakeCapture
        s=CameraStation(factory=lambda _: FakeCapture())
        s.set_colony(True);s.start()
        try:
            import time
            time.sleep(.42)
            r=s.run_colony()
            self.assertGreater(r['full_workload_count'],0)
            self.assertTrue(all(r['numerical_equivalence'].values()))
            self.assertEqual(r['input_provenance'],'actual camera pixel arrays')
            self.assertIn('unverified',r['sensor_verification'])
        finally:s.stop()
    def test_29_colony_buffer_is_bounded_and_opt_in(self):
        from camera_tests.test_camera import FakeCapture
        s=CameraStation(factory=lambda _: FakeCapture());s.start()
        try:
            import time
            time.sleep(.08)
            self.assertEqual(s.status()['colony_buffered'],0)
            s.set_colony(True);time.sleep(.16)
            self.assertGreater(s.status()['colony_buffered'],0)
            s.set_colony(False)
            self.assertEqual(s.status()['colony_buffered'],0)
        finally:s.stop()
    def test_30_sample_rate_changes_in_replay(self):
        from camera_tests.test_camera import FakeCapture
        s=CameraStation(factory=lambda _:FakeCapture())
        s.set_colony(True);s.start()
        try:
            import time
            time.sleep(.05)
            self.assertAlmostEqual(s.colony_fps,15)
        finally:s.stop()
    def test_27_replay_is_replay(self):
        _,fps=decode_video(ROOT/'colony_fixtures'/'seed13.avi',24)
        self.assertAlmostEqual(fps,24,places=3)

if __name__=='__main__':unittest.main()
