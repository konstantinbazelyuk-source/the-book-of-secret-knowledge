import http.client
import json
import socket
import threading
import time
import unittest
from camera_tests.test_camera import FakeCapture
from camera_bridge.core import CameraStation
from camera_bridge.server import build_server

class ColonyHttpTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        s=socket.socket();s.bind(('127.0.0.1',0));port=s.getsockname()[1];s.close()
        cls.station=CameraStation(factory=lambda _:FakeCapture());cls.server=build_server(cls.station,port)
        cls.port=cls.server.server_port
        cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start()
    @classmethod
    def tearDownClass(cls):
        cls.station.stop();cls.server.shutdown();cls.server.server_close();cls.thread.join(timeout=2)
    def request(self,method,path,body=None,token='valid',origin='same'):
        c=http.client.HTTPConnection('127.0.0.1',self.port,timeout=25)
        h={'Host':f'127.0.0.1:{self.port}'}
        if body is not None:
            h['Content-Type']='application/json';h['Origin']=f'http://127.0.0.1:{self.port}' if origin=='same' else origin
            h['X-Ripple-Token']=self.tok if token=='valid' else token
        c.request(method,path,None if body is None else json.dumps(body),headers=h)
        r=c.getresponse();data=r.read();status=r.status;c.close()
        try:d=json.loads(data)
        except Exception:d=data
        return status,d
    def test_01_opt_in_and_execute(self):
        st,data=self.request('GET','/api/status');self.assertEqual(st,200);type(self).tok=data['csrf_token']
        st,r=self.request('POST','/api/colony/enable',{'enabled':True});self.assertEqual(st,200)
        self.station.start();time.sleep(.5)
        st,r=self.request('POST','/api/colony/run',{});
        self.assertEqual(st,200,r)
        self.assertGreater(r['full_workload_count'],0)
        self.assertTrue(all(r['numerical_equivalence'].values()))
        self.assertFalse(r['frames_are_stored_or_exported'])
    def test_02_csrf(self):
        st,_=self.request('POST','/api/colony/enable',{'enabled':False},token='fake');self.assertEqual(st,403)
    def test_03_same_origin(self):
        st,_=self.request('POST','/api/colony/enable',{'enabled':False},origin='https://evil.invalid');self.assertEqual(st,403)
    def test_04_disable(self):
        st,_=self.request('POST','/api/colony/enable',{'enabled':False});self.assertEqual(st,200)
        self.assertEqual(self.station.status()['colony_buffered'],0)
    def test_05_disabled_refused(self):
        st,_=self.request('POST','/api/colony/run',{});self.assertEqual(st,409)

if __name__=='__main__':unittest.main()
