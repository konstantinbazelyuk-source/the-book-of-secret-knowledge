# Master Ripple Camera Colony Alpha v2.2

**Runnable experimental research add-on** to Master Ripple Camera Alpha v2.1; all previous Master neuron equations and frozen archives remain unchanged. Nothing starts the camera without an explicit command and user action.

## Quick start with the standalone package

From the extracted `Master_Ripple_Camera_Alpha_v2_1` folder:

```bash
python -m pip install -r requirements_camera.txt
python -m colony_lab.research --demo --frames 192 --repeat 2 --out colony_results/my_replay_test.json
```

This generates a deterministic **synthetic** video and **really decodes it through OpenCV** before executing the seven tasks. The measured CPU processing times are hardware-specific. Use `--file /path/to/video.avi` for any local video and `--device 0 --frames 96` only if you explicitly want to test a connected physical camera. Do not claim calibrated measurements from that device.

### Existing Master camera station with colony

```bash
python Launch_Master_Ripple_Camera.py --device 0
```

Open the localhost URL printed by the program. Click **Enable colony sampling**, **Start capture**, and **Run colony tasks**. It retains at most 64 downscaled BGR frames in memory, sampling one frame per two captured frames. **Clear / disable** empties this frame buffer. The camera itself retains its original RGB acquisition independently. It does not transmit images over the internet or enable a network camera implicitly.

Or replay the synthetic recorded video in the existing station:

```bash
python Launch_Master_Ripple_Camera.py --file colony_fixtures/seed13.avi
```

Start it after first enabling colony sampling, then run the colony tasks once enough frames have accumulated. Live hardware and file replay are distinct.

## Seven executed numeric tasks

| Task | Measurement | Scientific boundary | Suggested cadence |
|---|---|---|---|
| RGB photometry | Mean display-referred RGB channels | Not radiometry/spectroscopy | Every frame |
| Frame delta | Mean absolute gray difference | Not measured m/s | Every frame |
| Edge density | Sobel gradient magnitude | Contrast not object identity | Change/periodic |
| Focus | Laplacian variance and clipped pixels | Focus proxy; texture confounds it | Every frame |
| Optical flow | Farneback mean pixels/frame | Not calibrated velocity/depth | Change/periodic |
| Dark fraction | Central area under gray threshold | Not proof of physical occlusion, mass or density | Every frame |
| Tile texture | 4x4 cell gray variation | Spatial contrast, not a mapped 3D field | Change/periodic |

The inherited SpiderScan v0.4 tile-colony source is copied byte-for-byte and executed on frames as a separate benchmark. Its neuron births and retirements are bounded and only represent **software node allocation**. The frozen v2.0 Master `BoundedColony` is still present; its task assignments are audit metadata, not task execution. All tasks in this release perform numerical work.

## Controlled comparisons

- **Full serial vs full thread pool (1, 2, 4 workers)** performs an equivalent set of all seven task types on every decoded frame. Each numeric result is compared with the serial result before timing claims.
- **Fixed periodic** computes cheap tasks every frame and the heavy tasks every eighth frame.
- **Demand** computes cheap tasks every frame and the others on large frame changes, or every eighth frame. The gate only uses current and earlier data.
- **Hybrid** computes color, frame delta, blur and dark-fraction every frame; edge, optical flow and tile texture are sampled on change or periodically. Selection overhead is separately measured and included in reported total cost.
- **Evaluation** uses exhaustive numerical task outputs as an offline reference. That reference is not shown to the online work selector. Four selected detectors are explicitly defined by thresholds; matching them is not broad scene understanding.

The holdout changes the noise seed but uses the same edit schedule and geometry. Consequently it is a narrow reproducibility test, **not an independently captured field dataset**.

## Test commands

```bash
python -m unittest discover -s colony_tests -v
python -m unittest camera_tests.test_camera -v
python -m unittest discover -s tests -p test_master.py
```

The new tests cover execution, thread output parity, workload counts, bounded resource/sensor behavior, no implicit camera permission, opt-in/clear, actual HTTP routes, CSRF, and same-origin restrictions. The existing baseline regression tests are run again. Browser button behavior is checked in Chromium on 1200×800 and 390×844 sizes with in-page *mocked API*, while API server and numerical work are separately verified using real loopback HTTP.

**Maturity:** executable software Alpha. Digital-camera hardware performance, sensor calibration, optical-field measurements and robotic actuation are unverified. Synthetic video is not a measured real-life scene.

## Scientific sources used

- OpenCV VideoCapture API: https://docs.opencv.org/4.11.0/d4/d15/group__videoio__flags__base.html
- OpenCV foreground/scene subtraction principles: https://docs.opencv.org/4.10.0/d1/dc5/tutorial_background_subtraction.html
- OpenCV optical flow tutorial: https://docs.opencv.org/4.x/d4/dee/tutorial_optical_flow.html
- OpenCV Laplacian and Sobel: https://docs.opencv.org/4.x/d5/db5/tutorial_laplace_operator.html , https://docs.opencv.org/4.x/d2/d2c/tutorial_sobel_derivatives.html

No public GitHub publication or physical hardware validation has occurred in this release. Original archived licenses remain applicable. New addon code MIT.
