#!/usr/bin/env python3
"""Ripple Colony v0.4. Spatially identified, demand-scheduled legacy neurons.
NO hardware commands; NO LLM; NO artificial understanding. CC0-1.0.
Run: python -m source.colony_v04 --image reference/... --out results/colony.json
"""
from __future__ import annotations
import json, argparse, hashlib, math, time
from pathlib import Path
from dataclasses import dataclass
from typing import Optional
import cv2
import numpy as np
from .ripple_optical_agent_LOCKED import RippleNeuron

@dataclass
class Cell:
    id:int
    frame_rgb:tuple[float,float,float]
    texture_sd:float

class Colony:
    """Stable tile identities; active neurons created/retired only at dwell gates.

    'Scaling' means number of scheduled logical neurons, NOT CPU parallelism.
    Retired neurons lose state intentionally; no hidden transfer/duplication.
    """
    def __init__(self,rows=4,cols=4,min_nodes=2,max_nodes=16,texture_threshold=22.):
        if not (1<=rows*cols<=256 and 1<=min_nodes<=max_nodes<=rows*cols):raise ValueError('invalid colony sizing')
        self.rows,self.cols=rows,cols
        self.min_nodes,self.max_nodes=min_nodes,max_nodes
        self.threshold=texture_threshold
        self.active:dict[int,RippleNeuron]={}
        self.last_records={};self.lifecycle=[];self.tick=0
        self.grow_streak=0;self.shrink_streak=0
    def cells(self,bgr:np.ndarray)->list[Cell]:
        if bgr.ndim!=3 or bgr.shape[2]!=3:raise ValueError('expected BGR image')
        h,w=bgr.shape[:2]
        if h<self.rows*4 or w<self.cols*4:raise ValueError('image too small')
        return [Cell(row*self.cols+col,
             tuple(float(v) for v in cv2.cvtColor(bgr[y0:y1,x0:x1],cv2.COLOR_BGR2RGB).mean((0,1))/255.),
             float(cv2.cvtColor(bgr[y0:y1,x0:x1],cv2.COLOR_BGR2GRAY).std()))
            for row in range(self.rows) for col in range(self.cols)
            for y0,y1,x0,x1 in [(row*h//self.rows,(row+1)*h//self.rows,col*w//self.cols,(col+1)*w//self.cols)]]
    def step(self,bgr:np.ndarray,dt:float)->dict:
        if not math.isfinite(dt) or not 0<dt<=.5:raise ValueError('dt outside locked ripple step')
        start=time.perf_counter()
        cs=self.cells(bgr)
        textured=sum(c.texture_sd>=self.threshold for c in cs)
        target=max(self.min_nodes,min(self.max_nodes,textured))
        n=len(self.active)
        # start: initial active tiles without growing beyond min nodes
        if n==0:
            for c in sorted(cs,key=lambda c:(-c.texture_sd,c.id))[:self.min_nodes]:
                self.active[c.id]=RippleNeuron()
                self.lifecycle.append({'tick':self.tick,'kind':'birth','tile':c.id,'reason':'minimum'})
        else:
            self.grow_streak=self.grow_streak+1 if target>n else 0
            self.shrink_streak=self.shrink_streak+1 if target<n else 0
            rank=sorted(cs,key=lambda c:(-c.texture_sd,c.id))
            if self.grow_streak>=2:
                for c in rank:
                    if len(self.active)>=target:break
                    if c.id not in self.active:
                        self.active[c.id]=RippleNeuron()
                        self.lifecycle.append({'tick':self.tick,'kind':'birth','tile':c.id,'reason':'sustained texture load'})
                self.grow_streak=0
            elif self.shrink_streak>=4:
                # Retire lowest activity first; tile state is NOT mapped onto a different tile
                for c in sorted(cs,key=lambda c:(c.texture_sd,c.id)):
                    if len(self.active)<=target:break
                    if c.id in self.active:
                        del self.active[c.id]
                        self.lifecycle.append({'tick':self.tick,'kind':'retire','tile':c.id,'reason':'sustained low texture'})
                self.shrink_streak=0
        cmap={c.id:c for c in cs}
        records=[]
        for ident,node in sorted(self.active.items()):
            c=cmap[ident]
            output=node.step(c.frame_rgb,dt)
            records.append({'tile':ident,'observed_rgb_normalized':[round(v,8) for v in c.frame_rgb],
                'texture_sd_8bit':round(c.texture_sd,5),'spikes':output['count'],
                'theta':round(output['theta'],7),'drive':round(output['drive'],7),
                'state_time_s':round(output['t'],5)})
        result={'tick':self.tick,'textured_tiles':textured,'target_nodes':target,
                'active_nodes':len(self.active),'tile_ids':sorted(self.active),
                'events':sum(r['spikes'] for r in records),'records':records,
                'processing_ms':round((time.perf_counter()-start)*1000,4)}
        self.tick+=1
        return result

def run_image(image:Path,out:Path,frames:int=12,fps:float=20.)->dict:
    bgr=cv2.imread(str(image),cv2.IMREAD_COLOR)
    if bgr is None:raise ValueError(f'could not decode image: {image}')
    if frames<2 or not (2<=fps<=60):raise ValueError('invalid frames or fps')
    colony=Colony()
    trace=[colony.step(bgr,1/fps) for _ in range(frames)]
    sha=hashlib.sha256(image.read_bytes()).hexdigest()
    summary={'evidence':'real numerical extraction of supplied image bytes; input origin NOT a physical scanner or drone',
        'source_sha256':sha,'image_px':list(bgr.shape[:2][::-1]),'source':str(image),
        'frames_replayed':frames,'synthetic_timing':'same still image replayed at specified 20 Hz, not measured sensor frame rate',
        'nodes_peak':max(t['active_nodes'] for t in trace), 'total_model_events':sum(t['events'] for t in trace),
        'processing_ms_median':float(np.median([t['processing_ms'] for t in trace])),
        'processing_ms_p95':float(np.percentile([t['processing_ms'] for t in trace],95)),
        'lifecycle':colony.lifecycle,'trace':trace,
        'no_controls':'no motors, printer, laser, radio, or model API controlled'}
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
    return summary

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--image',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    a=p.parse_args();s=run_image(a.image,a.out);print(json.dumps({k:v for k,v in s.items() if k not in ('trace','lifecycle')},indent=2))
