"""Synthetic scenes with known interventions; decoded by OpenCV for rigorous replay."""
from __future__ import annotations
from pathlib import Path
import json
import cv2
import numpy as np

FPS=24
N=192
W,H=160,120
INTERVENTIONS={'color_flash':[24,39], 'motion':[48,87], 'blur':[100,127], 'dark_patch':[142,175]}


def generate(path:Path,seed:int=13,n:int=N)->dict:
    if not 96<=n<=240:raise ValueError('fixture frame budget')
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    wr=cv2.VideoWriter(str(path),cv2.VideoWriter_fourcc(*'MJPG'),FPS,(W,H))
    if not wr.isOpened():raise RuntimeError('OpenCV MJPEG VideoWriter unavailable')
    rng=np.random.default_rng(seed)
    yy,xx=np.mgrid[:H,:W]
    base=np.zeros((H,W,3),np.float32)
    base[:,:,0]=68+14*np.sin(xx/11)+14*np.sin(yy/9)
    base[:,:,1]=90+15*np.sin(xx/10)+10*np.cos(yy/11)
    base[:,:,2]=102+15*np.sin(xx/13)+16*np.cos(yy/9)
    # Fine spatial texture is deliberately testable by blur/edge tasks.
    tiles=13*((xx//4+yy//4)%2)*2-13
    base+=tiles[:,:,None]
    labels={k:list(range(max(0,a),min(n,b+1))) for k,(a,b) in INTERVENTIONS.items()}
    for i in range(n):
        out=base+rng.normal(0,1.6,size=(H,W,1))
        out=np.uint8(np.clip(out,0,255))
        if 24<=i<=39:
            out[28:92,46:114]=[35,40,225] # BGR strong red central region
        if 48<=i<=87:
            center=(20+round((i-48)*3),60)
            cv2.circle(out,center,13,(230,220,20),-1)
        if 100<=i<=127:
            out=cv2.GaussianBlur(out,(17,17),6)
        if 142<=i<=175:
            out[24:96,30:130]=[12,12,12]
        if i>=180:
            # 3 Hz intensity modulation at 24 fps (above baseline, clipped to input byte range).
            out=np.uint8(np.clip(out.astype(float)+27*np.sin(2*np.pi*3*(i-180)/FPS),0,255))
        wr.write(out)
    wr.release()
    meta={'origin':'synthetically generated BGR scenes with known interventions (never physical camera)',
          'seed':seed,'expected_frame_count':n,'fps':FPS,'video_file':path.name,
          'interventions_inclusive':INTERVENTIONS,'known_frame_labels':labels,
          'notes':'MJPG compression changes exact RGB values; ground truth labels denote scheduled edits only'}
    path.with_suffix('.json').write_text(json.dumps(meta,indent=2)+'\n')
    return meta

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,default=Path('colony_fixtures/test_seed13.avi'));p.add_argument('--seed',type=int,default=13)
    args=p.parse_args();print(json.dumps(generate(args.out,args.seed),indent=2))
