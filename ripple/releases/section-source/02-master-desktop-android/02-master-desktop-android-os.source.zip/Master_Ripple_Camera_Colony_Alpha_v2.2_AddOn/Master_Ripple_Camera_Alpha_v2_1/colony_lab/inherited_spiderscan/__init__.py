# Unmodified SpiderScan v0.6 archived legacy code; retained CC0 notice in source.
