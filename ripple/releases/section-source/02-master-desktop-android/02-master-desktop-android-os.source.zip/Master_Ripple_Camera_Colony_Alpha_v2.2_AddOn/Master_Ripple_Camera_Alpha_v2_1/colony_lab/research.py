"""Runnable camera-colony suitability study; file playback or explicit hardware acquisition."""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path
import time
import cv2
import numpy as np
from .engine import decode_video,run_experiment,validate_frames
from .fixture import generate


def _ensure_parent(path):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);return path


def capture_camera(index,frames=96,resize=(160,120)):
    """Only invoked by explicit --device; neither preview nor local API secretly starts cameras."""
    if not 0<=index<=16:raise ValueError('camera index out of bound')
    if not 3<=frames<=240:raise ValueError('camera frame limit')
    cap=cv2.VideoCapture(index)
    if not cap.isOpened():raise RuntimeError('camera unavailable; camera not simulated')
    try:
        seq=[];ts=[];start=time.monotonic()
        for _ in range(frames):
            ok,frame=cap.read()
            if not ok:break
            seq.append(cv2.resize(frame,resize,interpolation=cv2.INTER_AREA))
            ts.append(time.monotonic())
        validate_frames(seq)
        diffs=np.diff(ts)
        if len(diffs)==0 or np.any(diffs<=0):raise RuntimeError('camera timing invalid')
        return seq,float(1/np.median(diffs))
    finally:cap.release()


def study_file(video,output,limit=160,repetitions=2,workers=(1,2,4),labels=None):
    frames,fps=decode_video(video,limit=limit)
    results=run_experiment(frames,fps,workers=workers,repetitions=repetitions,labels=labels)
    results['source']={'classification':'video_replay; origin as separately declared',
                       'path_basename':Path(video).name,'sha256':hashlib.sha256(Path(video).read_bytes()).hexdigest(),
                       'hardware_camera_tested':False}
    _ensure_parent(output).write_text(json.dumps(results,indent=2,allow_nan=False)+'\n')
    return results


def main():
    p=argparse.ArgumentParser(description='Run real computer vision work using actual decoded frames, not metadata-only dispatch.')
    mode=p.add_mutually_exclusive_group(required=True)
    mode.add_argument('--demo',action='store_true',help='generate and decode synthetic scenes; no device access')
    mode.add_argument('--file',type=Path,help='decode an explicitly chosen local video')
    mode.add_argument('--device',type=int,help='opt-in local camera index, requires hardware')
    p.add_argument('--out',type=Path,default=Path('colony_results/custom_camera_study.json'))
    p.add_argument('--frames',type=int,default=160)
    p.add_argument('--repeat',type=int,default=2)
    p.add_argument('--workers',nargs='+',type=int,default=[1,2,4])
    a=p.parse_args()
    labels=None
    if a.demo:
        path=Path('colony_fixtures/test_seed13.avi')
        meta=generate(path,seed=13)
        a.file=path;labels=meta['known_frame_labels']
    if a.device is not None:
        frames,fps=capture_camera(a.device,frames=a.frames)
        results=run_experiment(frames,fps,workers=tuple(a.workers),repetitions=a.repeat)
        results['source']={'classification':'hardware_reported_unverified','device_index':a.device,
                           'hardware_camera_tested':True,'hardware_calibrated':False}
        _ensure_parent(a.out).write_text(json.dumps(results,indent=2,allow_nan=False)+'\n')
    else:results=study_file(a.file,a.out,limit=a.frames,repetitions=a.repeat,workers=tuple(a.workers),labels=labels)
    print(json.dumps({'output':str(a.out),'frames':results['frame_count'],
         'tasks':results['full_workload_count'],'correctness':results['numerical_equivalence'],
         'timing_ms':{k:v['median_ms'] for k,v in results['full_workload_timing'].items()},
         'demand_task_fraction':results['selective_policies']['demand']['fraction_of_exhaustive']},indent=2))

if __name__=='__main__':main()
