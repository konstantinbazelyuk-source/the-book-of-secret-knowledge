"""Auditable CPU camera tasks and actual threaded dispatch for Ripple v2.2.

All numerical values below come from pixels, not magnetic fields, photons, absolute
irradiance, object distance, mental state, or physical density. Individual computer
vision tasks are standard algorithms; no originality is claimed for those algorithms.
"""
from __future__ import annotations
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
import hashlib
import json
import math
import statistics
import time
from pathlib import Path
from typing import Sequence

import cv2
import numpy as np

TASKS = ('rgb', 'frame_delta', 'edge_density', 'focus_laplacian', 'optical_flow', 'dark_fraction', 'tile_texture')
HEAVY = ('edge_density', 'focus_laplacian', 'optical_flow', 'dark_fraction', 'tile_texture')
SCHEMA = 'ripple-camera-colony-task/2.2'
MAX_FRAMES = 240
MAX_PIXELS = 640 * 480


def validate_frames(frames: Sequence[np.ndarray], *, minimum=3):
    if not minimum <= len(frames) <= MAX_FRAMES:
        raise ValueError(f'require {minimum} to {MAX_FRAMES} frames')
    shapes = set()
    for f in frames:
        if not isinstance(f, np.ndarray) or f.dtype != np.uint8 or f.ndim != 3 or f.shape[2] != 3:
            raise ValueError('only 8-bit three-channel BGR frames supported')
        h,w=f.shape[:2]
        if not (16<=h and 16<=w and h*w<=MAX_PIXELS):
            raise ValueError('frame dimensions exceed bounded limits')
        shapes.add(f.shape)
    if len(shapes) != 1:
        raise ValueError('frame sizes must be identical; resample before analysis')


def to_gray(frame):
    return cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)


def task_compute(kind: str, frame:np.ndarray, previous:np.ndarray|None)->dict:
    """Pure numeric task: outputs fixed, engineering-defined proxies."""
    if kind not in TASKS:
        raise ValueError('unsupported task kind')
    if kind=='rgb':
        result=(frame.mean(axis=(0,1))[::-1]/255).tolist()
        return {'rgb': [float(x) for x in result],
                'luminance_display_proxy': float(.2126*result[0]+.7152*result[1]+.0722*result[2])}
    gray=to_gray(frame)
    if kind=='frame_delta':
        val=0. if previous is None else float(cv2.absdiff(gray,to_gray(previous)).mean()/255.)
        return {'mean_gray_delta_normalized':val}
    if kind=='edge_density':
        gx=cv2.Sobel(gray,cv2.CV_32F,1,0,ksize=3);gy=cv2.Sobel(gray,cv2.CV_32F,0,1,ksize=3)
        return {'sobel_gradient_mean_8bit_per_pixel':float(cv2.magnitude(gx,gy).mean())}
    if kind=='focus_laplacian':
        v=float(cv2.Laplacian(gray,cv2.CV_32F).var())
        return {'laplacian_variance_proxy':v,'fraction_clipped':float(np.count_nonzero((gray<=3)|(gray>=252))/gray.size)}
    if kind=='optical_flow':
        if previous is None:return {'farneback_mean_pixels_per_frame':0.}
        flow=cv2.calcOpticalFlowFarneback(to_gray(previous),gray,None,.5,2,15,2,5,1.2,0)
        mag=cv2.magnitude(flow[:,:,0],flow[:,:,1])
        return {'farneback_mean_pixels_per_frame':float(mag.mean())}
    if kind=='dark_fraction':
        # This is not a physical occlusion or density measurement.
        h,w=gray.shape;roi=gray[h//4:3*h//4,w//4:3*w//4]
        return {'central_roi_fraction_gray_below_55':float(np.mean(roi<55))}
    # tile texture (stable 4x4 spatial grid, no inferred distances)
    h,w=gray.shape;tiles=[]
    for yy in range(4):
        for xx in range(4):
            region=gray[yy*h//4:(yy+1)*h//4, xx*w//4:(xx+1)*w//4]
            tiles.append(float(region.std()))
    return {'tile_gray_stdev_8bit':tiles,'high_texture_tiles_22':sum(x>=22 for x in tiles)}


def tasks_for_frames(frames, policy='full', threshold=.008, period=8):
    """Online-causal work selection (frame i sees only i and i-1)."""
    if policy not in ('full','fixed','demand','hybrid'):raise ValueError('unknown policy')
    if not (0 <= threshold <= 1 and 2 <= period <= 64):raise ValueError('invalid demand policy')
    work=[]; trigger=[]
    for i,f in enumerate(frames):
        prev=frames[i-1] if i else None
        cheap=task_compute('frame_delta',f,prev)['mean_gray_delta_normalized']
        probe = policy=='full' or (i%period==0 if policy=='fixed' else (i%period==0 or cheap>=threshold))
        trigger.append({'frame':i,'delta':cheap,'sampled_heavy':bool(probe)})
        for kind in TASKS:
            always = kind in ('rgb','frame_delta') or (policy=='hybrid' and kind in ('focus_laplacian','dark_fraction'))
            if always or probe:
                work.append((i,kind))
    return work,trigger


def execute(frames,work,workers=1):
    if not (1<=workers<=8):raise ValueError('1..8 workers')
    start=time.perf_counter()
    # Explicitly do actual computations (rather than merely writing dispatch metadata).
    def one(arg):
        i,kind=arg
        t0=time.perf_counter()
        data=task_compute(kind,frames[i],frames[i-1] if i else None)
        return (i,kind,data,(time.perf_counter()-t0)*1000)
    if workers==1:
        output=[one(arg) for arg in work]
    else:
        with ThreadPoolExecutor(max_workers=workers,thread_name_prefix='ripple-colony') as pool:
            output=list(pool.map(one,work))
    duration=(time.perf_counter()-start)*1000
    timings=[o[3] for o in output]
    return {'results':{(i,k):v for i,k,v,_ in output},
            'latency_ms':duration,'task_cpu_or_wall_ms_sum':sum(timings),
            'task_count':len(work),'task_p95_ms':float(np.percentile(timings,95)) if timings else 0.}


def verify_equal(a:dict,b:dict,atol=1e-5):
    if a.keys()!=b.keys():return False
    for key in a:
        if a[key].keys()!=b[key].keys():return False
        for sub in a[key]:
            if not np.allclose(a[key][sub],b[key][sub],atol=atol,rtol=1e-6):return False
    return True


def evaluate_task_coverage(full:dict, partial:dict, labels:dict[str,list[int]]|None=None):
    # Evaluation-only reference uses all-frame results. Not used to choose tasks.
    labels=labels or {}
    check={
        'color_flash': ('rgb',lambda r: r['rgb'][0]>r['rgb'][1]+.16),
        'motion': ('optical_flow',lambda r: r['farneback_mean_pixels_per_frame']>.075),
        'blur': ('focus_laplacian',lambda r: r['laplacian_variance_proxy']<100),
        'dark_patch': ('dark_fraction',lambda r: r['central_roi_fraction_gray_below_55']>.30),
    }
    events={}
    for name,(kind,pred) in check.items():
        reference={i for (i,k),r in full.items() if k==kind and pred(r)}
        actual={i for (i,k),r in partial.items() if k==kind and pred(r)}
        # Compare same physical proxy to full computation, not to semantic scene truth.
        tp=len(reference&actual)
        relevant=set(labels.get(name,[]))
        events[name]={'full_reference_positive_frames':len(reference),'selected_positive_frames':len(actual),
                      'coverage_of_full_reference': round(tp/len(reference),5) if reference else None,
                      'known_fixture_label_frames':len(relevant),
                      'label_positive_frames_observed':len(actual&relevant)}
    return events


def run_experiment(frames, fps:float, *, workers=(1,2,4), labels=None,threshold=.008,
                   repetitions=2,include_legacy=True)->dict:
    validate_frames(frames)
    if not (math.isfinite(fps) and 1<=fps<=120):raise ValueError('valid fps required')
    if not 1<=repetitions<=4:raise ValueError('bounded repetitions 1..4')
    # OpenCV can create its own worker pool. Fix this to 1 to make Python pool comparisons interpretable.
    original_threads=cv2.getNumThreads()
    cv2.setNumThreads(1)
    try:
        t_select=time.perf_counter()
        work_full,full_trigger=tasks_for_frames(frames,'full')
        sel_full_ms=(time.perf_counter()-t_select)*1000
        t_select=time.perf_counter()
        work_fixed,fixed_trigger=tasks_for_frames(frames,'fixed')
        sel_fixed_ms=(time.perf_counter()-t_select)*1000
        t_select=time.perf_counter()
        work_demand,demand_trigger=tasks_for_frames(frames,'demand',threshold=threshold)
        sel_demand_ms=(time.perf_counter()-t_select)*1000
        t_select=time.perf_counter()
        work_hybrid,hybrid_trigger=tasks_for_frames(frames,'hybrid',threshold=threshold)
        sel_hybrid_ms=(time.perf_counter()-t_select)*1000
        baseline=execute(frames,work_full,1)
        # Correctness controls are separate from timing trials.
        checks={}
        for wc in sorted(set(workers)):
            alt=execute(frames,work_full,wc)
            checks[str(wc)]=verify_equal(baseline['results'],alt['results'])
        if not all(checks.values()):raise AssertionError('parallel results mismatch')
        timings={}
        for wc in sorted(set(workers)):
            records=[]
            for _ in range(repetitions):records.append(execute(frames,work_full,wc)['latency_ms'])
            timings[str(wc)]={'milliseconds': [round(t,3) for t in records],
                              'median_ms':round(float(statistics.median(records)),3),
                              'throughput_tasks_per_second':round(len(work_full)/(statistics.median(records)/1000),2)}
        fixed=execute(frames,work_fixed,1)
        demand=execute(frames,work_demand,1)
        hybrid=execute(frames,work_hybrid,1)
        selected={name:{'task_count':res['task_count'],'total_full_task_count':len(work_full),
                          'fraction_of_exhaustive':round(res['task_count']/len(work_full),4),
                          'observed_compute_ms':round(res['latency_ms'],3),
                          'selection_overhead_ms':round({'fixed':sel_fixed_ms,'demand':sel_demand_ms,'hybrid':sel_hybrid_ms}[name],3),
                          'observed_total_ms':round(res['latency_ms']+({'fixed':sel_fixed_ms,'demand':sel_demand_ms,'hybrid':sel_hybrid_ms}[name]),3),
                          'coverage':evaluate_task_coverage(baseline['results'],res['results'],labels)}
                  for name,res in [('fixed',fixed),('demand',demand),('hybrid',hybrid)]}
        freq=frequency_from_luminance(baseline['results'],fps)
        legacy=None
        if include_legacy:
            # Run unmodified archived SpiderScan tile-colony implementation.
            from .inherited_spiderscan.legacy.colony_v04 import Colony
            spatial=Colony(rows=4,cols=4,min_nodes=2,max_nodes=16)
            tr=[spatial.step(f,1/fps) for f in frames]
            legacy={'frames':len(tr),'min_nodes':min(x['active_nodes'] for x in tr),
                    'max_nodes':max(x['active_nodes'] for x in tr),
                    'spikes':sum(x['events'] for x in tr),
                    'born':sum(e['kind']=='birth' for e in spatial.lifecycle),
                    'retired':sum(e['kind']=='retire' for e in spatial.lifecycle),
                    'lifecycle':spatial.lifecycle[:100],
                    'median_step_ms':round(float(statistics.median(x['processing_ms'] for x in tr)),4),
                    'definition':'unmodified SpiderScan v0.4 archived code, run on actual BGR pixels; synthetic input if fixture'}
        return {'schema':'ripple-camera-colony-study/2.2','classification':'calculated_from_decoded_pixels',
                'frame_count':len(frames),'resolution':[int(frames[0].shape[1]),int(frames[0].shape[0])],
                'fps_supplied':fps,'task_list':list(TASKS),'units':'display-referred pixel proxies',
                'full_workload_count':len(work_full),'full_baseline_first_ms':round(baseline['latency_ms'],3),
                'full_selection_overhead_ms':round(sel_full_ms,3),
                'numerical_equivalence':checks, 'full_workload_timing':timings,
                'selective_policies':selected,'demand_trigger_count':sum(t['sampled_heavy'] for t in demand_trigger),
                'fixed_trigger_count':sum(t['sampled_heavy'] for t in fixed_trigger),
                'hybrid_trigger_count':sum(t['sampled_heavy'] for t in hybrid_trigger),
                'first_12_trigger_records':demand_trigger[:12],
                'temporal_frequency':freq,'inherited_spiderscan_colony':legacy,
                'limitations':['not a magnetic field sensor','no depth from monocular frames',
                    'motion units pixels/frame not m/s','dark_fraction is not measured occlusion or matter density',
                    'hardware properties unverified','timings depend on CPU and source workload']}
    finally:cv2.setNumThreads(original_threads)


def frequency_from_luminance(full:dict, fps:float):
    x=np.asarray([r['luminance_display_proxy'] for (i,k),r in sorted(full.items()) if k=='rgb'],dtype=float)
    if len(x)<24:return {'valid':False,'reason':'insufficient samples'}
    detr=x-np.mean(x)
    y=np.abs(np.fft.rfft(detr*np.hanning(len(detr))))
    hz=np.fft.rfftfreq(len(x),1./fps)
    if len(y)<3:return {'valid':False,'reason':'insufficient frequency bins'}
    y[0]=0
    k=int(np.argmax(y[1:]))+1
    return {'valid':True,'peak_hz':round(float(hz[k]),5),'bin_resolution_hz':round(float(fps/len(x)),5),
            'nyquist_hz':fps/2,'interpretation':'dominant sampled display-luminance modulation; no visible-light carrier frequency'}


def decode_video(path:Path,limit=160,resize=(160,120)):
    path=Path(path)
    if not path.is_file():raise FileNotFoundError(str(path))
    if not 3<=limit<=MAX_FRAMES:raise ValueError('invalid frame count')
    cap=cv2.VideoCapture(str(path))
    if not cap.isOpened():raise RuntimeError('OpenCV could not open input video')
    try:
        fps=float(cap.get(cv2.CAP_PROP_FPS))
        if not math.isfinite(fps) or fps<=0:raise RuntimeError('recorded video lacks reliable FPS')
        frames=[]
        for i in range(limit):
            ok,frame=cap.read()
            if not ok:break
            frames.append(cv2.resize(frame,resize,interpolation=cv2.INTER_AREA))
        validate_frames(frames)
        return frames,fps
    finally:cap.release()
