"""Opt-in, measurable camera colony experiments. No invented sensor data."""
