"""Loopback-only camera dashboard with opt-in capture and bounded control API."""
from __future__ import annotations
import argparse
import json
import math
import os
from pathlib import Path
import secrets
import socket
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from core import CameraStation

ROOT=Path(__file__).resolve().parents[1]
MAX_POST=6000

class CameraHandler(SimpleHTTPRequestHandler):
    station:CameraStation
    token:str
    def __init__(self,*args,**kwargs):
        super().__init__(*args,directory=str(ROOT/'camera_web'),**kwargs)
    def _json(self,status,data):
        payload=json.dumps(data,allow_nan=False).encode()
        self.send_response(status)
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Content-Length',str(len(payload)))
        self.end_headers();self.wfile.write(payload)
    def _error(self,status,reason):self._json(status,{'error':str(reason)})
    def _host_ok(self):
        host=self.headers.get('Host','').lower()
        return host in {f'127.0.0.1:{self.server.server_port}',f'localhost:{self.server.server_port}'}
    def _origin_ok(self):
        origin=self.headers.get('Origin','')
        return origin in {f'http://127.0.0.1:{self.server.server_port}',f'http://localhost:{self.server.server_port}'}
    def do_GET(self):
        if not self._host_ok():return self._error(403,'Loopback host required')
        path=urlparse(self.path).path
        try:
            if path=='/api/status':
                return self._json(200,{'status':self.station.status(),'csrf_token':self.token})
            if path=='/api/preview.jpg':
                data=self.station.jpeg()
                if data is None:return self._error(404,'No current camera frame')
                self.send_response(200);self.send_header('Content-Type','image/jpeg');self.send_header('Cache-Control','no-store')
                self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data);return
            if path=='/api/records':
                records=self.station.events()
                payload=(''.join(json.dumps(r,allow_nan=False)+'\n' for r in records)).encode()
                self.send_response(200);self.send_header('Content-Type','application/x-ndjson')
                self.send_header('Content-Disposition','attachment; filename="master_ripple_camera_capture.jsonl"')
                self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(payload)))
                self.end_headers();self.wfile.write(payload);return
            if path in {'/','/index.html'}:
                self.path='/index.html'
            elif path.startswith('/api/'):
                return self._error(404,'Unknown API')
            return super().do_GET()
        except (BrokenPipeError,ConnectionResetError):return
    def do_POST(self):
        if not self._host_ok() or not self._origin_ok():return self._error(403,'Same-origin request required')
        if self.headers.get('X-Ripple-Token','') != self.token:return self._error(403,'Missing session token')
        if self.headers.get('Content-Type','').split(';')[0].strip()!='application/json':return self._error(415,'JSON required')
        try:
            n=int(self.headers.get('Content-Length','-1'))
            if n<0 or n>MAX_POST:return self._error(413,'Request too large')
            body=json.loads(self.rfile.read(n))
            if not isinstance(body,dict):return self._error(400,'JSON object required')
            path=urlparse(self.path).path
            if path=='/api/start':out=self.station.start()
            elif path=='/api/stop':out=self.station.stop()
            elif path=='/api/roi':out=self.station.update_roi(body.get('roi'))
            elif path=='/api/probe':out=self.station.probe_control(body.get('name'),body.get('value'))
            elif path=='/api/control':out=self.station.set_control(body.get('name'),body.get('value'))
            elif path=='/api/analyze':out=self.station.analyze(body.get('genome','prism'))
            elif path=='/api/colony/enable':out=self.station.set_colony(body.get('enabled'))
            elif path=='/api/colony/run':out=self.station.run_colony()
            else:return self._error(404,'Unknown operation')
            return self._json(200,out)
        except (ValueError,TypeError) as exc:return self._error(400,str(exc))
        except RuntimeError as exc:return self._error(409,str(exc))
        except (BrokenPipeError,ConnectionResetError):return
        except Exception as exc:return self._error(500,f'{type(exc).__name__}: {exc}')
    def log_message(self,fmt,*args):
        if not self.path.startswith('/api/preview'):super().log_message(fmt,*args)


def build_server(station:CameraStation,port=8788):
    if not 1024<=port<=65535:raise ValueError('unsafe port')
    token=secrets.token_urlsafe(32)
    Handler=type('SessionCameraHandler',(CameraHandler,),{'station':station,'token':token})
    server=ThreadingHTTPServer(('127.0.0.1',port),Handler)
    server.daemon_threads=True
    return server


def main():
    ap=argparse.ArgumentParser(description='Ripple Camera Station (OpenCV video input; opt-in).')
    group=ap.add_mutually_exclusive_group()
    group.add_argument('--device',type=int,default=0,help='Local webcam index (default 0)')
    group.add_argument('--file',help='Explicit local video file, replay mode only')
    group.add_argument('--stream',help='Explicit trusted RTSP/HTTP(S) camera stream URL; backend-dependent; may contain private credentials')
    ap.add_argument('--port',type=int,default=8788)
    ap.add_argument('--no-browser',action='store_true')
    args=ap.parse_args()
    src=args.device
    if args.file is not None:
        src=str(Path(args.file).resolve())
        if not Path(src).is_file():ap.error('video file does not exist')
    if args.stream is not None:
        uri=urlparse(args.stream)
        if uri.scheme.lower() not in {'rtsp','http','https'} or not uri.hostname:
            ap.error('stream must have rtsp://, http://, or https:// and a hostname')
        src=args.stream
    station=CameraStation(src)
    server=build_server(station,args.port)
    url=f'http://127.0.0.1:{server.server_port}/'
    print(f'Master Ripple Camera Station: {url}\nSource: {station.source_label}\nLocal-only; click Start to acquire.',flush=True)
    if not args.no_browser:
        import webbrowser
        webbrowser.open(url)
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:
        station.stop();server.shutdown();server.server_close()

if __name__=='__main__':main()
