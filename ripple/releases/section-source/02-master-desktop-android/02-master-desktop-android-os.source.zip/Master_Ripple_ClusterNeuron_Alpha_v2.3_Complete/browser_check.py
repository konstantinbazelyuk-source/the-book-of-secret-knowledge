from pathlib import Path
import json
from playwright.sync_api import sync_playwright
ROOT=Path('/mnt/data/Master_Ripple_ClusterNeuron_Alpha_v2_3/Master_Ripple_Camera_Alpha_v2_1')
html=(ROOT/'camera_web/index.html').read_text().replace('<head>','<head><base href="http://127.0.0.1:8788/">',1)
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for w,h,tag in [(390,844,'mobile'),(1200,800,'desktop')]:
  page=b.new_page(viewport={'width':w,'height':h})
  logs=[];calls=[]
  page.on('pageerror',lambda x:logs.append(str(x)))
  def route(req):
   url=req.request.url
   if url.endswith('/api/status'):
    payload={'status':{'running':False,'source':'synthetic preview only','backend':'mocked',
         'frames':0,'observed_fps_estimate':None,'width_height':None,'last_rgb':None,
         'available_genomes':['prism','canopy'],'supports_set_requests':False,'buffered':0,'message':'Stopped.'},'csrf_token':'testtoken'}
    return req.fulfill(status=200,body=json.dumps(payload),headers={'Content-Type':'application/json'})
   if url.endswith('/api/cluster/run'):
    calls.append(json.loads(req.request.post_data))
    payload={'source':{'mode':'synthetic_mock'},'genome':{'name':'prism'},'mode':calls[-1]['mode'],
          'recommendation':'mocked UI only','node_event_counts':{'chromatic':1,'motion':2,'focus':1,'shadow':0},
          'final_attention_weights':{'chromatic':.25,'motion':.32,'focus':.24,'shadow':.19},
          'tasks_executed':47,'full_workload_tasks':70,'reference':{},'warnings':[]}
    return req.fulfill(status=200,body=json.dumps(payload),headers={'Content-Type':'application/json'})
   return req.fulfill(status=404,body='{}',headers={'Content-Type':'application/json'})
  page.route('http://127.0.0.1:8788/**',route)
  page.set_content(html,wait_until='load');page.wait_for_timeout(250)
  page.locator('#clusterMode').select_option('economy')
  page.locator('#clusterRun').click()
  page.wait_for_function("document.querySelector('#clusterResult').textContent.includes('task_count')",timeout=8000)
  assert calls and calls[0]['mode']=='economy',calls
  assert 'Cluster' in page.locator('#clusterRun').inner_text()
  assert not logs,logs
  page.screenshot(path=str(ROOT/f'cluster_results/station_{tag}_mock.png'),full_page=True)
  print(tag,'controls working; API calls',calls,'js_errors',logs)
  page.close()
 b.close()
