from pathlib import Path
import hashlib,json,os,zipfile
root=Path('/mnt/data/Master_Ripple_ClusterNeuron_Alpha_v2_3')
pr=root/'Master_Ripple_Camera_Alpha_v2_1'
original=Path('/mnt/data/Master_Ripple_Camera_Colony_Alpha_v2.2_Complete.zip')
sha=lambda b:hashlib.sha256(b).hexdigest()
with zipfile.ZipFile(original) as z:
  old={name:z.read(name) for name in z.namelist() if not name.endswith('/') and name.startswith('Master_Ripple_Camera_Alpha_v2_1/')}
modified=[];unchanged=[];missing=[]
for name,data in old.items():
 f=root/name
 if not f.exists():missing.append(name)
 elif sha(f.read_bytes())==sha(data):unchanged.append(name)
 else:modified.append({'path':name,'before_sha256':sha(data),'after_sha256':sha(f.read_bytes())})
assert not missing,missing
assert set(x['path'].split('Master_Ripple_Camera_Alpha_v2_1/')[1] for x in modified)=={'camera_bridge/core.py','camera_bridge/server.py','camera_web/index.html'},modified
legacy='Master_Ripple_Camera_Alpha_v2_1/legacy/ripple-core.js'
assert sha((root/legacy).read_bytes())==sha(old[legacy])
audit={'schema':'ripple-cluster-audit/2.3','base':str(original.name),'source_verification':{'source_files_in_archive':len(old),'byte_identical':len(unchanged),'changed':len(modified),'removed':len(missing),'modified':modified},
 'preserved_original_neuron_sha256':sha((root/legacy).read_bytes()),'node_count':4,
 'new_module':'cluster_neuron/cluster.cjs and engine.py','verified_inherited_test_count':111,'verified_new_test_count':36,'browser_mock_checks':'mobile + desktop; no live physical-camera browser tested',
 'camera_device_present_in_environment':False,'experimental_source':'synthetic MJPEG decoded by OpenCV',
 'physical_accuracy_claim':False,'publication_status':'local downloadable ZIP only'}
(pr/'CLUSTER_SOURCE_AUDIT.json').write_text(json.dumps(audit,indent=2)+'\n')
# research summary; structured numeric data (not assertions)
records=[]
for case in ['seed13','seed29','seed73','different_geometry']:
 for mode in ['economy','quality']:
  f=pr/'cluster_results'/f'{case}_{mode}_report.json'
  r=json.loads(f.read_text())
  records.append({'scene':case,'mode':mode,'processed_tasks':r['tasks_executed'],'original_v2_2_hybrid_tasks':r['reference']['v2_2_hybrid_tasks'],
                  'exhaustive_tasks':r['full_workload_tasks'],'flow_ref_positives':r['reference']['v2_3_cluster_coverage']['motion']['full_reference_positive_frames'],
                  'flow_selected_positives':r['reference']['v2_3_cluster_coverage']['motion']['selected_positive_frames'],
                  'flow_coverage':r['reference']['v2_3_cluster_coverage']['motion']['coverage_of_full_reference'],
                  'spikes':r['node_event_counts']})
(pr/'cluster_results'/'comparison_summary.json').write_text(json.dumps({'source':'synthetic video and calculated algorithms','runs':records},indent=2)+'\n')
# independent hashes of preserved files and new authored source
checks={str(p.relative_to(root)):sha(p.read_bytes()) for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc' and p.name!='CLUSTER_SHA256SUMS.txt'}
(pr/'CLUSTER_SHA256SUMS.txt').write_text('\n'.join(f'{h}  {name}' for name,h in sorted(checks.items()))+'\n')
# full package root, skip temporary large report and fixtures? include them yes, but pycache excluded
full=Path('/mnt/data/Master_Ripple_ClusterNeuron_Alpha_v2.3_Complete.zip')
addon=Path('/mnt/data/Master_Ripple_ClusterNeuron_Alpha_v2.3_AddOn.zip')
add_files=set(x['path'] for x in modified)
add_files.update(str(p.relative_to(root)) for p in (pr/'cluster_neuron').rglob('*') if p.is_file() and '__pycache__' not in p.parts)
add_files.update(str(p.relative_to(root)) for p in (pr/'cluster_tests').rglob('*') if p.is_file() and '__pycache__' not in p.parts)
add_files.update('Master_Ripple_Camera_Alpha_v2_1/'+n for n in ('CLUSTER_START_HERE.md','CLUSTER_SOURCE_AUDIT.json','CLUSTER_SHA256SUMS.txt'))
add_files.update(str(p.relative_to(root)) for p in (pr/'cluster_results').rglob('*') if p.is_file() and p.suffix not in ('.avi','.json') and '__pycache__' not in p.parts)
add_files.add('Master_Ripple_Camera_Alpha_v2_1/cluster_results/comparison_summary.json')
for target,filenames in [(full,sorted(checks.keys())+['Master_Ripple_Camera_Alpha_v2_1/CLUSTER_SHA256SUMS.txt']), (addon,sorted(add_files))]:
 with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for n in filenames:
   assert (root/n).is_file(),n
   z.write(root/n,n)
 with zipfile.ZipFile(target) as z:
  invalid=z.testzip()
  assert invalid is None,invalid
  assert z.read(legacy)==old[legacy] if target==full else True
 print(target.name,'size_MB',round(target.stat().st_size/1e6,2),'entries',len(filenames),'passed ZIP CRC')
print('SOURCE AUDIT',audit['source_verification'])
print('ORIGINAL',audit['preserved_original_neuron_sha256'])
