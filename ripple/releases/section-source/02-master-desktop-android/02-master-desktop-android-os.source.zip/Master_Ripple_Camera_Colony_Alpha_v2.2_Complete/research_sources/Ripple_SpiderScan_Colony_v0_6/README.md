# RIPPLE SPIDERSCAN COLONY v0.6

**Ground-only, eight-legged digital system with functioning vision and range software, persistent 16x16 chunk map, preserved Ripple neuron core, wireless-ready telemetry transmitter, receiver, and read-only browser map. No flight subsystem.**

## What is physically true / what is not

- **Built and run here:** Python program, persisted SQLite data, PNG optical analysis using archived photographic pixels, kinematic calculations, authenticated TCP transmitter/receiver using loopback, map export, browser server, tests, 3D editable parametric SCAD and printer-fit STL.
- **Existing published third-party:** Octobot's MIT licensed chassis/leg STEP, 24 servo PCB KiCad with fabrication data, browser kinematics workbench; Raspberry Pi Global Shutter Camera and VL53L1X optical modules.
- **Not built:** actual octopod, servo hardware, physical wiring, regulator/load checks, physical scanning, Wi-Fi RF range trials or live external telemetry. Do not say this is a finished commissioned robot. The printed mount is an *unfitted* engineering sample.
- **Independently unverified:** mechanical mating geometry, motor torque margin, total payload mass, working camera focus, ground-scale calibration, driving positions and ToF-induced occupancy inference. Scope is **ground only**; no rotors, ESCs, or flight firmware.

## Quick offline run

Install Python 3.11+ with `numpy`, `opencv-python`, and `pytest` (Pi OS recommends `python3-opencv`, `python3-picamera2` via apt). In the project folder:

```bash
python -m pip install -r requirements.txt
python -m pytest -q tests
python -m spidercolony.cli demo --out results/demo --image fixtures/archived_photo_NOT_HARDWARE.png
```

`results/demo/report.json` contains evidence flags, numerical quality metrics, neuron activity and a queued transmitter event. Map is correctly EMPTY because the fixture has no external pose and no verified physical input.

## Live transmitter proof (two terminals on one computer)

Set an actual unpredictable 32+ byte secret in both terminals (do not reuse this testing example outside a local demo).

Terminal 1:
```bash
export SPIDER_TELEMETRY_KEY='REPLACE-WITH-AT-LEAST-32-RANDOM-CHARACTERS'
python -m spidercolony.cli receiver --host 127.0.0.1 --port 8765 --db results/base.sqlite
```

Terminal 2:
```bash
export SPIDER_TELEMETRY_KEY='REPLACE-WITH-AT-LEAST-32-RANDOM-CHARACTERS'
python -m spidercolony.cli transmit --out results/demo --host 127.0.0.1 --port 8765
python -m spidercolony.monitor --db results/base.sqlite --host 127.0.0.1 --port 8076
```

Open `http://127.0.0.1:8076`. Telemetry is sent in authenticated length-prefixed JSON packets and ACKed. Sender persists unACKed reports across restart. Receiver deduplicates `(robot,session,seq)` and stores received map deltas in SQLite. Monotonic `seq` is not a full cryptographic anti-replay system across session restarts; signed timestamp limits and duplicate rejection protect the normal operation envelope. TLS protects all connections outside loopback (requires a real CA-trusted cert/server key). Plain TCP over a LAN is deliberately disallowed. No remote motor commands are accepted.

## True physical sensor capture on Raspberry Pi (UNTESTED on physical hardware here)

Connect Raspberry Pi CSI camera and two VL53L1X breakout boards through TCA9548A; see `docs/INTERFACES_AND_POWER.md`. On configured Raspberry Pi OS with `picamera2`, `adafruit-blinka`, `adafruit-circuitpython-tca9548a`, `adafruit-circuitpython-vl53l1x`, run:

```bash
python -m spidercolony.cli capture-hardware --out captures/session001
```

This reads actual pixels and ranges and queues metadata. Do **not** provide `--pose-json` until you have independently calibrated/measured `x_mm`, `y_mm`, and `yaw_deg`. The mapping path enforces fresh and valid range readings and refuses map insertion from replayed/user-labeled hardware JSON. If the range data is missing or stale, it records a STOP advisory, **not** servo control.

## Software architecture

`legacy/ripple_optical_agent_LOCKED.py` has not been modified. Original fixed channel weights `D=2R + 1.2G -1.4B`, exponential leaky integration, spike crossings, refractory, and bounded adaptive threshold are preserved. `src/ground_colony.py` manages independent, persistent tile identities and adds/retire nodes by texture demand. This is **resource scheduling and neuron-like signal processing, not trained intelligence, and not CPU multiprocessing**.

`spidercolony/chunkmap.py` is **inspired by Minecraft chunk regions** but does not copy proprietary code or use Anvil format. Each 16x16 region is separately zlib-compressed in SQLite; grid IDs remain stable for negative coordinates and across restarts. A ToF cone reports an uncertain bearing; its apparent end position can be wrong laterally by approximately `distance*tan(FOV/2)` (27 degree nominal full FOV). Occupancy grid cells are **hypotheses for inspection only, not navigation safe-space certificates**. No autonomous pose/SLAM is implemented. `ros_like_export` is numeric row-major map data, not a native ROS message.

`spidercolony/kinematics.py` provides a proposed 3DOF-per-leg closed-form IK/forward-kinematics digital model and analytic wave support schedule. It **does not drive servos** and the link lengths are proposed, not reverse-engineered measurements of Octobot. Hardware control remains with separate manufacturer/Octobot firmware and independent electrical emergency stop. See `docs/REAL_BUILD_ACCEPTANCE.md`.

## Published references and integrations

- Octobot chassis STEP, 24-servo controller board, inverse kinematics: https://github.com/Deivid-Negoita/octobot ; see original MIT license. Their firmware lives separately; verify compatibility before any control work.
- Raspberry Pi Global Shutter Camera, board 38x38x19.8 mm, 34 g, Sony IMX296: https://www.raspberrypi.com/products/raspberry-pi-global-shutter-camera/
- Picamera2 official guide; unusual `RGB888` B-G-R byte order: https://datasheets.raspberrypi.com/camera/picamera2-manual.pdf
- ST VL53L1X 940nm Class 1 time-of-flight, 27 degree typical FOV, up to 4m: https://www.st.com/en/imaging-and-photonics-solutions/vl53l1x.html
- Raspberry Pi 4 5V/3A power: https://datasheets.raspberrypi.com/rpi4/raspberry-pi-4-datasheet.pdf
- ROS2 `OccupancyGrid` row-major cell layout: https://github.com/ros2/common_interfaces/blob/rolling/nav_msgs/msg/OccupancyGrid.msg
- Historical FBI photography guidance: https://leb.fbi.gov/file-repository/archives/july-1984.pdf ; scaled measurement and oblique illumination, not robotics schematics.
- Minecraft section/region concept: https://minecraft.wiki/w/Chunk_format ; concept only.
- Optional future Meta SAM2 segmentation: https://github.com/facebookresearch/sam2 (separate GPU resources needed; not integrated or claimed measured). Google mapping stacks and Grok may be future optional external analyzers, **not called or represented as tested here**.

## Manufacturing files

- `cad/SpiderScan_v06_FULL_DIGITAL_ASSEMBLY_CONCEPT.scad` is an original 8-legged 24-DOF posed reference model, **not the upstream mechanical chassis**.
- `cad/transmitter_pi_mount_FITCHECK.scad` and `.stl` are the proposed Raspberry Pi transmitter carrier, 101x72 mm base, mount holes with required fit measurement.
- `cad/scanner_head_v05_FITCHECK.scad` preserves the earlier fit-check scanner tray.
- `docs/BUILD_PARTS_REGISTER.csv` and `docs/REAL_BUILD_ACCEPTANCE.md` specify purchased components and block uncertified fabrication.
- `docs/PCB_AND_MECHANICAL_HANDOFF.md` lists the upstream KiCad/STEP source, structural evidence and supplier RFQ requirements; **no files have been outsourced or ordered**.

## Intellectual property / attribution

New original v0.6 files are released under CC0-1.0. Prior Ripple materials are preserved; check their notices. Octobot MIT-licensed design is **referenced**, not redistributed in this archive. For commercial manufacturing check source BOM distributor matches, licenses, electronic compliance, and regional radio rules independently.

## Continuous acquisition and transmission (physical Pi deployment; UNTESTED hardware)

On a robot Pi with working CSI and I2C ToF interfaces:

```bash
python -m spidercolony.live_pi --out captures/live001 --interval-s 0.2 --max-frames 0 --save-every 10
```

In another process, with correct key, CA and receiver IP:

```bash
export SPIDER_TELEMETRY_KEY='YOUR_RANDOM_SHARED_SECRET'
python -m spidercolony.live_tx --out captures/live001 --host 192.0.2.10 --port 8765 --ca-cert /path/to/trusted-ca.pem
```

The receiver on the separate base station must be started with its TLS server certificate and private key (`python -m spidercolony.cli receiver --host 0.0.0.0 --cert /path/to/server.pem --private-key /path/to/server-key.pem`). The sample address `192.0.2.10` is a documentation IP, **not an actual base station**. Long gaps >0.5 seconds reset the modelled colony state and are tagged in reports rather than silently pretending uninterrupted neuronal time. Both programs remain observer-only; the receiver cannot send actuator commands.
