#!/bin/sh
set -eu
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo 'Node.js 20 or newer is required: https://nodejs.org/' >&2
  exit 1
fi
exec node src/cli.mjs serve
