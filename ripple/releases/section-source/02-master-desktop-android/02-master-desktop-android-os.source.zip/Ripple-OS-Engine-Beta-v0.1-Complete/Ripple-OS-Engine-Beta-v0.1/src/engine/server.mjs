import http from 'node:http';import {readFileSync} from 'node:fs';
import {randomBytes,timingSafeEqual} from 'node:crypto';import {EngineError} from './guards.mjs';
import {RippleOS} from './runtime.mjs';
const html=readFileSync(new URL('../../web/index.html',import.meta.url));
function equalToken(input,token){if(typeof input!=='string')return false;const a=Buffer.from(input),b=Buffer.from(token);return a.length===b.length&&timingSafeEqual(a,b);}
function send(res,status,obj){res.writeHead(status,{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff','access-control-allow-origin':'null'});res.end(JSON.stringify(obj));}
export async function createServer({runtime=new RippleOS(),host='127.0.0.1',port=8765,token=randomBytes(24).toString('base64url'),observerToken=randomBytes(24).toString('base64url'),researcherToken=randomBytes(24).toString('base64url')}={}){
 if(host!=='127.0.0.1'&&host!=='::1'&&host!=='localhost')throw Error('remote binding disabled; use an authenticated reverse proxy after a security review');
 if([token,observerToken,researcherToken].some(t=>typeof t!=='string'||t.length<24)||new Set([token,observerToken,researcherToken]).size!==3)throw Error('role tokens must be unique and >=24 chars');
 const server=http.createServer(async(req,res)=>{
  try{
   const url=new URL(req.url,'http://localhost');
   if(req.method==='GET'&&(url.pathname==='/'||url.pathname==='/index.html')){
    res.writeHead(200,{'content-type':'text/html; charset=utf-8','cache-control':'no-store','content-security-policy':"default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; base-uri 'none'; frame-ancestors 'none'",'x-content-type-options':'nosniff','x-frame-options':'DENY'});res.end(html);return;
   }
   const supplied=(req.headers.authorization||'').startsWith('Bearer ')?req.headers.authorization.slice(7):'';
   const subject=equalToken(supplied,token)?'owner':equalToken(supplied,researcherToken)?'researcher':equalToken(supplied,observerToken)?'observer':null;
   if(!subject){send(res,401,{error:'AUTH_REQUIRED'});return;}
   if(req.method==='GET'&&url.pathname==='/api/status'){send(res,200,runtime.status());return;}
   if(req.method==='GET'&&url.pathname==='/api/services'){send(res,200,{services:runtime.status().services});return;}
   if(req.method==='POST'&&url.pathname==='/api/task'){
    let size=0,body='';for await(const c of req){size+=c.length;if(size>12000)throw new EngineError('BUDGET','request body too large',413);body+=c;}
    let data;try{data=JSON.parse(body)}catch{throw new EngineError('SCHEMA','request JSON invalid');}
    // Separate observer/researcher/owner keys can be configured by a host in future;
    // this local owner-only endpoint does not infer privileges from request JSON.
    const out=await runtime.submit(data,subject);send(res,200,out);return;
   }
   send(res,404,{error:'NOT_FOUND'});
  }catch(e){send(res,e.status??500,{error:e.code||'SERVICE_ERROR',message:e.status&&e.status<500?e.message:'Operation failed'});}
 });
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,host,resolve);});
 return {server,token,observerToken,researcherToken,address:server.address(),close:()=>new Promise((resolve,reject)=>server.close(e=>e?reject(e):resolve()))};
}
