import fs from 'node:fs';import path from 'node:path';import {createHash} from 'node:crypto';
import {AuditJournal,atomicJSON} from './journal.mjs';
import {BoundedScheduler} from './scheduler.mjs';
import {RuntimeEventBus} from './events.mjs';
import {EngineError,assert,plainObject,safeRGB,boundedNumber} from './guards.mjs';
import {DocumentForest} from '../../parents/Ripple-Digital-Assessment-Alpha-v1.5/src/assessment.mjs';
import {DaughterTripletNeuron} from '../../parents/Ripple-Daughter-Triplet-v3.1/src/triplet-neuron.mjs';
import {DaughterWorld} from '../../parents/Ripple-Daughter-Triplet-v3.1/src/daughter-world.mjs';
import {executeRecipe,listFormulas} from '../../parents/Ripple-Mathematics-Compiler-v2.1.1/src/formula-compiler.mjs';
import {pack4} from '../../parents/Ripple-Daughter-Triplet-v3.1/vault/beta/legacy/quaternary-core.mjs';
const root=new URL('../../',import.meta.url);
const readJSON=rel=>JSON.parse(fs.readFileSync(new URL(rel,root),'utf8'));
const CORPUS=readJSON('parents/Ripple-Digital-Assessment-Alpha-v1.5/data/corpus.json');
const TRAINED=readJSON('parents/Ripple-Digital-Assessment-Alpha-v1.5/data/trained_policy.json');
const services=Object.freeze({
 'system.status':'status.read','system.services':'status.read','system.audit':'audit.read','system.events':'event.read','evidence.evaluate':'evidence.read',
 'evidence.assess':'evidence.read','evidence.rank':'evidence.read','evidence.feedback':'learning.write',
 'neuron.step':'neuron.compute','neuron.reset':'neuron.compute','optics.attenuate':'math.compute','optics.formula':'math.compute',
 'colony.create':'colony.simulate','colony.step':'colony.simulate','colony.record':'colony.simulate','sensor.ingest':'sensor.ingest'
});
const SUBJECTS=Object.freeze({
 observer:['status.read','evidence.read','event.read'],
 researcher:['status.read','audit.read','event.read','evidence.read','neuron.compute','math.compute','colony.simulate','sensor.ingest'],
 owner:['status.read','audit.read','event.read','evidence.read','neuron.compute','math.compute','colony.simulate','sensor.ingest','learning.write']
});
const num=(x,a,b,key)=>boundedNumber(x,a,b,key);
function only(payload,keys){assert(Object.keys(payload).every(k=>keys.includes(k)),'SCHEMA','unsupported payload field');}
function stableHash(value){return createHash('sha256').update(JSON.stringify(value)).digest('hex');}
export class RippleOS{
 constructor({dataDir=path.join(process.cwd(),'runtime-data'),queueCapacity=128}={}){
  this.dataDir=dataDir;this.journal=new AuditJournal(dataDir);
  this.router=new DocumentForest(CORPUS);
  const policy=path.join(dataDir,'policy.json');this.policyPath=policy;
  this.router.restore(fs.existsSync(policy)?JSON.parse(fs.readFileSync(policy,'utf8')):TRAINED);
  this.neuron=new DaughterTripletNeuron();this.world=null;this.bus=new RuntimeEventBus();
  this.bootedAt=new Date().toISOString();this.work=0;
  this.scheduler=new BoundedScheduler({capacity:queueCapacity,authorize:(subject,service)=>this.authorize(subject,service),execute:t=>this.execute(t)});
  for(const id of this.journal.ids)this.scheduler.seen.add(id);
 }
 authorize(subject,service){assert(Object.hasOwn(services,service),'NO_SERVICE','unknown service '+service,404);
  assert(Object.hasOwn(SUBJECTS,subject),'SUBJECT','unknown subject',403);
  assert(SUBJECTS[subject].includes(services[service]),'DENIED','subject '+subject+' lacks '+services[service],403);
 }
 status(){return{engine:'Ripple OS Engine',version:'0.1.0-beta.1',class:'application-level service runtime, NOT operating system kernel',uptimeSince:this.bootedAt,services:Object.keys(services),subjects:Object.keys(SUBJECTS),scheduler:this.scheduler.stats(),learningUpdates:this.router.updates,eventBus:this.bus.stats(),neuronTime:this.neuron.t,world:this.world?.summary()??null,journal:{records:this.journal.seq,head:this.journal.prev},data:'local process, no external services called',evidence:'implemented services are real software; optical/colony inputs are synthetic unless independently measured'};}
 async submit(task,subject='observer'){return this.scheduler.submit(task,subject);}
 async execute(t){const started=performance.now();let result,success=false,error;
  try{
   switch(t.service){
    case 'system.status':result=this.status();break;
    case 'system.services':result=Object.entries(services).map(([name,capability])=>({name,capability}));break;
    case 'system.events':{only(t.payload,['limit']);result=this.bus.recent(t.payload.limit??20);break;}
    case 'evidence.evaluate':{only(t.payload,[]);const {scoreSet}=await import('../../parents/Ripple-Digital-Assessment-Alpha-v1.5/src/assessment.mjs');const test=CORPUS.queries.filter(q=>q.split==='test');result={split:'test',n:test.length,bm25:scoreSet(this.router,test,'bm25'),trained:scoreSet(this.router,test,'learned'),note:'IN-SAMPLE SOURCE UNIVERSE HOLDOUT: not unseen-domain understanding; feedback may change learned result'};break;}
    case 'system.audit':{
     only(t.payload,['limit']);const limit=t.payload.limit??20;num(limit,1,100,'limit');result=this.journal.latest(limit);break;}
    case 'evidence.assess':{
     only(t.payload,['query','mode','alpha']);const query=t.payload.query;
     assert(typeof query==='string'&&query.length>=2&&query.length<=500,'INPUT','query must be 2..500 chars');
     const mode=t.payload.mode??'bm25',alpha=t.payload.alpha??0;
     result=this.router.assess(query,mode,alpha);result.evidenceClass='SOURCE-ROUTING OUTPUT, not verified factual answer';break;}
    case 'evidence.rank':{
     only(t.payload,['query','mode','alpha']);const query=t.payload.query;
     assert(typeof query==='string'&&query.length>=2&&query.length<=500,'INPUT','query 2..500 characters required');
     result=this.router.rank(query,t.payload.mode??'bm25',t.payload.alpha??0).slice(0,5);break;}
    case 'evidence.feedback':{
     only(t.payload,['query','goldDoc','learningRate']);const query=t.payload.query,gold=t.payload.goldDoc;
     assert(typeof query==='string'&&query.length>=2&&query.length<=500,'INPUT','query required');
     assert(typeof gold==='string'&&this.router.ids.includes(gold),'INPUT','goldDoc must be one of existing source ids');
     const lr=t.payload.learningRate??.85;
     // Persist explicit feedback transaction before confirming. Snapshot backup prevents partial update on I/O failure.
     const prior=this.router.snapshot();try{result=this.router.learn(query,gold,lr);atomicJSON(this.policyPath,this.router.snapshot());}
     catch(e){this.router.restore(prior);throw e;}
     result={...result,evidenceClass:'USER-PROVIDED LABEL, NOT VALIDATED GROUND TRUTH'};break;}
    case 'sensor.ingest':{
     only(t.payload,['samples','sourceId','kind']);
     const {samples,sourceId,kind}=t.payload;
     assert(Array.isArray(samples)&&samples.length>=1&&samples.length<=32,'BUDGET','1..32 samples per request');
     assert(typeof sourceId==='string'&&/^[a-zA-Z0-9_.:-]{1,64}$/.test(sourceId),'INPUT','sourceId required');
     assert(['recorded-unverified','synthetic'].includes(kind),'INPUT','provenance must be explicitly declared');
     const validated=samples.map(item=>{assert(plainObject(item)&&Object.keys(item).every(k=>['rgb','dt'].includes(k)),'SCHEMA','sample schema');return{rgb:safeRGB(item.rgb),dt:num(item.dt??.05,.0001,.2,'dt')};});
     let last,spikes=0;for(const item of validated){last=this.neuron.step(item.rgb,item.dt);spikes+=last.count;}
     result={accepted:validated.length,sourceId,kind,spikes,neuronTime:this.neuron.t,latestLayers:{photoreceptor:last.layer1,dendrite:last.layer2,soma:last.layer3},evidence:kind==='recorded-unverified'?'EXTERNALLY SUPPLIED SIGNALS; independent sensor provenance not verified':'SYNTHETIC SAMPLE STREAM; no physical sensor'};break;}
    case 'neuron.step':{
     only(t.payload,['rgb','dt']);const rgb=safeRGB(t.payload.rgb),dt=num(t.payload.dt??.05,.0001,.2,'dt');
     result=this.neuron.step(rgb,dt);break;}
    case 'neuron.reset':{only(t.payload,[]);this.neuron.reset();result={reset:true,time:this.neuron.t};break;}
    case 'optics.formula':{only(t.payload,['mode','inputs']);assert(typeof t.payload.mode==='string'&&plainObject(t.payload.inputs),'INPUT','formula request invalid');result=executeRecipe({formula:'beer_lambert',mode:t.payload.mode,inputs:t.payload.inputs});break;}
    case 'optics.attenuate':{
     only(t.payload,['incident','coefficient','path']);const I=num(t.payload.incident,0,1e6,'incident'),mu=num(t.payload.coefficient,0,1e4,'coefficient'),L=num(t.payload.path,0,1e4,'path');
     const out=executeRecipe({formula:'beer_lambert',mode:'forward',inputs:{I0:I,mu,L}});
     result={transmittance:out.T,intensity:out.I,opticalDensity:out.OD10,units:'mu in m^-1 and L in m; I and I0 share intensity units',evidence:'CALCULATED, not measured',formulaVersion:'2.1.1'};break;}
    case 'colony.create':{
     only(t.payload,['seed','width','height','policy']);const seed=t.payload.seed??1731,width=t.payload.width??24,height=t.payload.height??16,policy=t.payload.policy??'hybrid-beta';
     assert(Number.isInteger(seed)&&seed>=0&&seed<=4294967295,'INPUT','seed invalid');assert(Number.isInteger(width)&&width>=8&&width<=56,'INPUT','width invalid');assert(Number.isInteger(height)&&height>=8&&height<=56,'INPUT','height invalid');
     assert(typeof policy==='string'&&['hybrid-beta','spatial','colony','optical-q','neuron-only'].includes(policy),'INPUT','unsupported policy');
     this.world=new DaughterWorld({seed,width,height,policy});result=this.world.summary();break;}
    case 'colony.step':{
     only(t.payload,['ticks']);assert(this.world,'STATE','create colony first');const ticks=t.payload.ticks??1;
     assert(Number.isInteger(ticks)&&ticks>=1&&ticks<=16,'BUDGET','colony ticks limited to 1..16 per task');
     result=this.world.run(ticks);break;}
    case 'colony.record':{only(t.payload,[]);assert(this.world,'STATE','create colony first');const record=this.world.exportRecord();
     // bound output size (trace includes bounded ticks but can exceed HTTP response budgets).
     result={summary:record.summary,paths:record.paths.map(p=>({...p,points:p.points.slice(-128)})),lineage:record.lineage.slice(-128),evidence:record.evidence,coreHash:record.coreHash};break;}
    default:throw new EngineError('NO_SERVICE','unknown service',404);
   }
   success=true;
   const topic={'neuron.step':'neuron.updated','evidence.assess':'evidence.routed','evidence.feedback':'learning.updated','colony.step':'colony.updated','colony.create':'colony.updated','optics.attenuate':'optics.calculated','sensor.ingest':'system.completed'}[t.service]||'system.completed';
   this.bus.publish(topic,{service:t.service,requestId:t.id,...(t.service==='neuron.step'?{time:result.t,spikes:result.count}:{}),...(t.service==='colony.step'?{ticks:result.ticks,coverage:result.coverage}:{}),...(t.service==='evidence.assess'?{document:result.doc,evidenceState:result.evidenceState}:{})});
   return {requestId:t.id,service:t.service,result};
  }catch(e){error=e;this.bus.publish('system.failed',{service:t.service,requestId:t.id,code:e.code||'SERVICE_ERROR'});throw e;}
  finally{
   this.work++;
   this.journal.append(success?'task.ok':'task.error',{requestId:t.id,service:t.service,subject:t.subject,requestDigest:stableHash(t.payload),durationMs:+(performance.now()-started).toFixed(3),...(error?{errorCode:error.code||'SERVICE_ERROR'}:{})});
  }
 }
}
