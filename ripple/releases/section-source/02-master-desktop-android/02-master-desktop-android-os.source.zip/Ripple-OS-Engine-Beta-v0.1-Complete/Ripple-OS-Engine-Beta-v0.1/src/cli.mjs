import {RippleOS} from './engine/runtime.mjs';import {createServer} from './engine/server.mjs';
import {mkdirSync} from 'node:fs';import path from 'node:path';import os from 'node:os';import {randomBytes} from 'node:crypto';
const command=process.argv[2]??'help';
const store=process.env.RIPPLE_DATA_DIR||path.join(process.cwd(),'runtime-data');
if(command==='help'){console.log('Ripple OS Engine commands: demo | bench | serve | verify | help');process.exit(0);}
if(command==='serve'){
 const port=Number(process.env.PORT||8765);
 if(!Number.isInteger(port)||port<0||port>65535)throw Error('invalid PORT');
 const os=new RippleOS({dataDir:store});const live=await createServer({runtime:os,port,token:process.env.RIPPLE_TOKEN||randomBytes(24).toString('base64url')});
 console.log('Ripple engine running at http://127.0.0.1:'+live.address.port+'/');
 console.log('Local owner token (do not share): '+live.token);
 console.log('Researcher token (no training updates): '+live.researcherToken);
 console.log('Observer token (read-only): '+live.observerToken);
 console.log('Only local access is enabled. Ctrl+C stops the server.');
 const stop=async()=>{await live.close();process.exit(0)};
 process.on('SIGINT',()=>void stop());process.on('SIGTERM',()=>void stop());
}else if(command==='demo'||command==='bench'||command==='verify'){
 const dir=path.join(os.tmpdir(),'ripple-os-'+process.pid+'-'+Date.now());mkdirSync(dir,{recursive:true});
 const runtime=new RippleOS({dataDir:dir,queueCapacity:512});
 const submit=(service,payload={},subject='owner')=>runtime.submit({service,payload},subject).then(x=>x.result);
 if(command==='demo'){
  const q=await submit('evidence.assess',{query:'What did the forest scouts know about shortest-path directions?'});
  const optical=await submit('optics.attenuate',{incident:1,coefficient:.35,path:2});
  const neuron=await submit('neuron.step',{rgb:[.35,.1,.1],dt:.05});
  const world=await submit('colony.create',{seed:1731,width:20,height:14});
  const after=await submit('colony.step',{ticks:12});
  console.log(JSON.stringify({evidence:{doc:q.doc,source:q.source,evidenceState:q.evidenceState},optical,neuron:{rate:neuron.rate,layer2:neuron.layer2},world:{start:world.coverage,after:after.coverage,ticks:after.ticks},kernel:runtime.scheduler.stats(),journal:runtime.journal.verify()},null,2));
 }else if(command==='bench'){
  const N=500,start=performance.now();const jobs=[];for(let i=0;i<N;i++)jobs.push(submit('optics.attenuate',{incident:1,coefficient:.35,path:2+(i%5)}));await Promise.all(jobs);
  const ms=performance.now()-start;console.log(JSON.stringify({jobs:N,elapsedMs:ms,throughputJobsPerSecond:1000*N/ms,scheduler:runtime.scheduler.stats(),evidence:'MEASURED local Node process; machine-dependent; no supercomputer'},null,2));
 }else{console.log(JSON.stringify({integrity:runtime.journal.verify(),services:runtime.status().services,version:runtime.status().version},null,2));}
}else{console.error('Unknown command '+command);process.exitCode=2;}
