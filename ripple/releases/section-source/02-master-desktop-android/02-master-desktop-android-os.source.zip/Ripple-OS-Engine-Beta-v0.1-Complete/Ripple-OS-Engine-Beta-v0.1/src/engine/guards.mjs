export class EngineError extends Error {
 constructor(code,message,status=400){super(message);this.name='EngineError';this.code=code;this.status=status;}
}
export function assert(condition,code,message,status=400){if(!condition)throw new EngineError(code,message,status);}
export function plainObject(value){return value!==null&&typeof value==='object'&&!Array.isArray(value)&&Object.getPrototypeOf(value)===Object.prototype;}
export function validateTask(task,maxBytes=8192){
 assert(plainObject(task),'SCHEMA','task must be a plain object');
 assert(Object.keys(task).every(k=>['service','payload','priority','requestId'].includes(k)),'SCHEMA','unknown task field');
 assert(typeof task.service==='string'&&/^[a-z][a-z0-9.]{2,35}$/.test(task.service),'SCHEMA','invalid service name');
 const payload=task.payload??{};
 assert(plainObject(payload),'SCHEMA','payload must be a plain object');
 const raw=JSON.stringify(payload);assert(raw&&Buffer.byteLength(raw,'utf8')<=maxBytes,'BUDGET','payload exceeds limit',413);
 const prio=task.priority??1;assert(Number.isInteger(prio)&&prio>=0&&prio<=3,'SCHEMA','priority must be 0..3');
 if(task.requestId!==undefined)assert(typeof task.requestId==='string'&&/^[a-zA-Z0-9_.:-]{1,80}$/.test(task.requestId),'SCHEMA','invalid requestId');
 return {service:task.service,payload:structuredClone(payload),priority:prio,requestId:task.requestId};
}
export const boundedNumber=(x,min,max,key)=>{assert(typeof x==='number'&&Number.isFinite(x)&&x>=min&&x<=max,'INPUT',key+' out of range');return x;};
export const safeRGB=(rgb)=>{assert(Array.isArray(rgb)&&rgb.length===3,'INPUT','RGB must have three channels');return rgb.map((n,i)=>boundedNumber(n,0,1,'RGB '+i));};
