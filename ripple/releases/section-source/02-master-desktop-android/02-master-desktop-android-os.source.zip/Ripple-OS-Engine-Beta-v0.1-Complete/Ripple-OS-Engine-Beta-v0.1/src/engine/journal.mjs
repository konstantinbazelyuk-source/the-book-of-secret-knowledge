import fs from 'node:fs';import path from 'node:path';import {createHash} from 'node:crypto';
import {assert} from './guards.mjs';
const hash=s=>createHash('sha256').update(s).digest('hex');
const genesis='0'.repeat(64);
export class AuditJournal{
 constructor(directory){fs.mkdirSync(directory,{recursive:true,mode:0o700});this.file=path.join(directory,'events.jsonl');this.rows=[];this.prev=genesis;this.seq=0;this.ids=new Set();this.verify();}
 verify(){this.rows=[];this.prev=genesis;this.seq=0;this.ids.clear();if(!fs.existsSync(this.file))return {valid:true,count:0};
  const bytes=fs.readFileSync(this.file,'utf8');if(bytes&&!bytes.endsWith('\n'))throw Error('incomplete journal line; refusing to recover silently');
  for(const [i,line]of bytes.split('\n').filter(Boolean).entries()){
   let e;try{e=JSON.parse(line)}catch{throw Error('corrupt journal JSON at line '+(i+1))}
   const {hash:stored,...data}=e;
   assert(e.seq===this.seq+1&&e.previous===this.prev,'INTEGRITY','journal sequence or ancestry mismatch at line '+(i+1));
   assert(hash(JSON.stringify(data))===stored,'INTEGRITY','journal checksum mismatch at line '+(i+1));
   this.seq=e.seq;this.prev=stored;this.rows.push(e);if(e.requestId)this.ids.add(e.requestId);
  }
  return {valid:true,count:this.seq,head:this.prev};
 }
 append(kind,details){const next=this.seq+1;const data={seq:next,previous:this.prev,at:new Date().toISOString(),kind,...details};
  const e={...data,hash:hash(JSON.stringify(data))};fs.appendFileSync(this.file,JSON.stringify(e)+'\n',{encoding:'utf8',mode:0o600});this.seq=next;this.prev=e.hash;this.rows.push(e);if(e.requestId)this.ids.add(e.requestId);return e;
 }
 latest(max=30){return this.rows.slice(-Math.max(0,Math.min(100,max))).map(x=>({...x}));}
}
export function atomicJSON(filename,value){const dir=path.dirname(filename);fs.mkdirSync(dir,{recursive:true,mode:0o700});const tmp=filename+'.tmp.'+process.pid;fs.writeFileSync(tmp,JSON.stringify(value,null,2)+'\n',{mode:0o600});fs.renameSync(tmp,filename);}
