import {randomUUID} from 'node:crypto';
import {assert,validateTask,EngineError} from './guards.mjs';
export class BoundedScheduler{
 constructor({capacity=128,execute,authorize,maxPayloadBytes=8192}={}){
  assert(Number.isInteger(capacity)&&capacity>=1&&capacity<=10000,'CONFIG','queue capacity invalid');
  this.capacity=capacity;this.execute=execute;this.authorize=authorize;this.maxPayloadBytes=maxPayloadBytes;
  this.queues=[[],[],[],[]];this.schedule=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,3];this.cursor=0;
  this.running=false;this.completed=0;this.failed=0;this.latencies=[];this.lastError=null;this.inflight=new Map();this.seen=new Set();
 }
 size(){return this.queues.reduce((n,q)=>n+q.length,0)}
 submit(task,subject='observer'){
  const t=validateTask(task,this.maxPayloadBytes);const id=t.requestId??randomUUID();
  assert(!this.seen.has(id),'DUPLICATE','requestId already used',409);
  this.authorize(subject,t.service);assert(this.size()<this.capacity,'BACKPRESSURE','queue full',429);
  this.seen.add(id);
  return new Promise((resolve,reject)=>{this.queues[t.priority].push({...t,id,subject,resolve,reject,started:performance.now()});this.inflight.set(id,t.service);this.kick();});
 }
 kick(){if(this.running)return;this.running=true;setImmediate(()=>void this.drain());}
 next(){for(let n=0;n<this.schedule.length;n++){
  const priority=this.schedule[this.cursor];this.cursor=(this.cursor+1)%this.schedule.length;
  const t=this.queues[priority].shift();if(t)return t;
 }return null;}
 async drain(){try{while(this.size()){
  const t=this.next();if(!t)break;
  try{const out=await this.execute(t);this.completed++;t.resolve(out);}
  catch(e){this.failed++;this.lastError={code:e.code||'SERVICE_ERROR',message:e.message};t.reject(e);}
  finally{this.inflight.delete(t.id);this.latencies.push(performance.now()-t.started);if(this.latencies.length>1024)this.latencies.shift();}
  await new Promise(resolve=>setImmediate(resolve));
 }}finally{this.running=false;if(this.size())this.kick();}}
 stats(){const a=[...this.latencies].sort((x,y)=>x-y);return{capacity:this.capacity,queued:this.size(),inflight:[...this.inflight.keys()].length,completed:this.completed,failed:this.failed,lastError:this.lastError,meanLatencyMs:a.length?a.reduce((s,x)=>s+x,0)/a.length:null,p95LatencyMs:a.length?a[Math.ceil(.95*a.length)-1]:null,policy:'weighted round-robin priorities 0..3, one bounded job per scheduling turn; not an OS real-time guarantee'};}
}
