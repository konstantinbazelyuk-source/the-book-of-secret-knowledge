import {assert} from './guards.mjs';
const TOPICS=Object.freeze(['neuron.updated','evidence.routed','learning.updated','colony.updated','optics.calculated','system.completed','system.failed']);
export class RuntimeEventBus {
 constructor(capacity=256){assert(Number.isInteger(capacity)&&capacity>0&&capacity<=8192,'CONFIG','event history invalid');this.capacity=capacity;this.subscribers=new Map();this.history=[];this.serial=0;this.failures=0;}
 subscribe(topic,listener){assert(TOPICS.includes(topic),'EVENT','topic not registered');assert(typeof listener==='function','EVENT','listener must be callable');
  const members=this.subscribers.get(topic)||new Set();assert(members.size<16,'BUDGET','too many event subscribers');members.add(listener);this.subscribers.set(topic,members);
  return ()=>members.delete(listener);
 }
 publish(topic,payload={}){assert(TOPICS.includes(topic),'EVENT','topic not registered');
  const event=Object.freeze({sequence:++this.serial,topic,at:new Date().toISOString(),data:Object.freeze(structuredClone(payload))});
  this.history.push(event);if(this.history.length>this.capacity)this.history.shift();
  for(const listen of this.subscribers.get(topic)||[])try{listen(event)}catch{this.failures++;}
  return event;
 }
 recent(max=20){assert(Number.isInteger(max)&&max>=1&&max<=100,'EVENT','event range 1..100');return this.history.slice(-max);}
 stats(){return{emitted:this.serial,buffered:this.history.length,capacity:this.capacity,subscriberErrors:this.failures,topics:TOPICS}};
}
