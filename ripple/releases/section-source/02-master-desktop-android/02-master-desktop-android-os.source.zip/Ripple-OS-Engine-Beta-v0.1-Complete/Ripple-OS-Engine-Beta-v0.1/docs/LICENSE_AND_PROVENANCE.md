# Rights and attribution

This is a new integration of archived Ripple research artifacts supplied through the owner's file library. Archive copies are retained under `parents/` with exact source hashes in `SOURCE_LOCKS.json`. Do not infer that all nested files or external cited literature have a universal license. The core original Ripple neuron had previously been designated CC0-1.0; this release does not silently change the licensing status of other descendants or their third-party dependencies. The new Node runtime source is supplied for study, modification and engineering tests; do not use claims of performance without retaining the evidence labels and relevant reproducibility scripts.

No third-party proprietary AI model weights, stolen code, commercial API keys, external sensor dumps or plugin credentials are distributed. No externally hosted service was created as part of this release.
