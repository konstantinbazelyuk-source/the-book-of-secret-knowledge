# Service contracts

All payloads are JSON objects and must be submitted with `POST /api/task` using `Authorization: Bearer <role token>`. Request JSON is shaped as `{"service":"optics.attenuate","payload":{"incident":1,"coefficient":0.35,"path":2},"priority":1,"requestId":"my-calculation-001"}`. Optional `requestId` is unique across process restarts for a persisted journal. Priority is 0–3 and controls weighted dispatch, not real-time guarantees.

| Service | Capability | Input | Output/evidence |
|---|---|---|---|
| `system.status` | status.read | empty | running scheduler, journal and modules |
| `system.services` | status.read | empty | service allowlist and capabilities |
| `system.audit` | audit.read | `limit` 1–100 | hash-chained audit metadata |
| `system.events` | event.read | `limit` 1–100 | recent bounded event bus history |
| `evidence.assess` | evidence.read | `query`, optional `mode` `bm25`/`learned`/`hybrid` | ranked source, passage, two-symbol address; not verified answer |
| `evidence.rank` | evidence.read | `query`, optional `mode`,`alpha` | top five source scores |
| `evidence.evaluate` | evidence.read | empty | 32-question inherited holdout evaluation; same eight source documents |
| `evidence.feedback` | learning.write | `query`,`goldDoc`, optional `learningRate` | one supervised router update and persistent snapshot; user label unverified |
| `neuron.step` | neuron.compute | `rgb` in [0,1]³, `dt` (0,.2] | actual Δ³ layer states and events; numerical model |
| `neuron.reset` | neuron.compute | empty | reinitialize state |
| `sensor.ingest` | sensor.ingest | `samples` 1–32 items of `rgb`,`dt`; `sourceId`, `kind`=`synthetic`/`recorded-unverified` | feeds actual triplet; no automatic hardware provenance |
| `optics.attenuate` | math.compute | `incident`,`coefficient`,`path` | original compiler's Beer–Lambert forward value |
| `optics.formula` | math.compute | `mode`=`forward`/`solve_mu`/`solve_L`/`rgb_forward`, and corresponding `inputs` | original restricted formula registry output |
| `colony.create` | colony.simulate | optional seeded dimensions and allowed policy | initialize synthetic DaughterWorld |
| `colony.step` | colony.simulate | `ticks` 1–16 | advance actual Daughter colony on bounded world |
| `colony.record` | colony.simulate | empty | bounded paths, lineage and synthetic summary |

The UI uses the same authenticated service endpoint and prints no credentials by itself. All endpoint content is local. Relative source paths and SHA256 locks are in `SOURCE_LOCKS.json`.
