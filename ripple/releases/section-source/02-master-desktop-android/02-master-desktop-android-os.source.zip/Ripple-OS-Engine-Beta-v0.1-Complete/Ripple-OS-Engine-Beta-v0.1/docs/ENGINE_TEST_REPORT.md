# Executed engineering report — Ripple OS Engine 0.1.0-beta.1

## Status

**Executed locally; no public cloud deployment.** Parent files were imported directly from materialized prior Ripple release ZIPs, preserved byte-for-byte, then hash-locked in `SOURCE_LOCKS.json`.

| Verification | Observed outcome | Evidence class |
|---|---:|---|
| New engine/scheduler/bus/auth/persistence/static-console checks | 23/23 passed | Executed software tests |
| Preserved Daughter Δ³ parent tests | 19/19 passed | Executed parent regression |
| Preserved Assessment v1.5 parent tests | 11/11 passed | Executed parent regression |
| Preserved math compiler + photometry tests | 19/19 passed | Executed parent regression |
| **Total executed tests** | **72/72 passed** | Automated software regression |
| Parent source inventory | 79 files hash locked and checked | Calculated SHA-256 |
| Original Ripple v0.1 core | `dba6639b7902f0c702d15fff588524629f3754cfd72d7b704f22a76b78960ee3` unchanged | Calculated SHA-256 |
| BM25 inherited 32-question holdout | 23/32 correct, top-3 30/32 | Measured model output against inherited labeled sample |
| Trained assessor inherited 32-question holdout | 13/32 correct | Measured model output against inherited labeled sample |
| HTTP Bearer auth, three roles | Allowed/denied as designed | Executed server tests |
| Direct Daughter test | Three real model layers advanced by 0.05 model seconds | Calculated model state |
| Daughter colony seeded replay | Two fresh engine instances produced equal summaries and paths | Simulated, compared |
| Explicit feedback after restart | Numerical weights restored; duplicate requestId rejected | Executed persistence test |
| Audit chain corruption | Startup refused corrupted journal | Executed guardrail test |
| 500 simple optical jobs × 5 runs | 2500 completed, 0 failed | Measured process runtime |
| Browser UI interaction (full Chromium) | **Not verified: browser navigation blocked by administrator** | Unverified GUI |
| Static HTML/JS syntax | Parsed; expected selectors and IDs checked | Executed source checks |
| Physical camera, GPS, quantum or biological capability | **Not tested or integrated** | No observations |

## Performance

The five *separately started* runs of 500 guarded Beer–Lambert calculations each produced a median of **16,703 simple jobs/second** (range **14,477–16,852** jobs/sec). These jobs are small synchronous math operations. The benchmark is strongly machine- and workload-dependent, uses a single Node process, and does not measure cognition, training throughput, colony speed, latency under real users, supercomputer speed or actual hardware interrupt scheduling. See `results/runtime-benchmark.json` for all observations.

## Demonstrated complete sequence

`node src/cli.mjs demo` executed the preserved source router, compiled optical attenuation `I0=1,mu=.35,L=2` resulting in `0.4965853037914095`, a Daughter neuron step with finite P/D/S states, and a Daughter colony from zero mapped cells to six discovered cells after 12 synthetic ticks. The service queue committed five entries and revalidated its journal chain. See `results/demo.json`.

## Negative results and incomplete verification

1. **No automatic learning:** the inherited learned document router remains worse than the BM25 baseline on the 32-document-routing questions (13 vs 23 correct), so BM25 is the default. User-applied labels can teach the policy but are not independently verified.
2. **Not a security sandbox:** the engine runs inside the same OS process; allowlisting prevents supported remote tasks from executing arbitrary programs but does not isolate untrusted executable plugins or protect against host compromise.
3. **No task durability:** pending jobs and running world/neuron states are not automatically restored after process crash. Only the explicit learned policy and audit log persist across restart.
4. **No real sensor observation:** `sensor.ingest` receives caller-supplied normalized RGB arrays. The `recorded-unverified` provenance label explicitly disallows claiming physically calibrated measurements.
5. **No cloud service:** public deployment needs additional security and transactional persistence engineering.
6. **Browser UI navigation in this test environment was blocked** with `net::ERR_BLOCKED_BY_ADMINISTRATOR` for both localhost and local files. The HTML and embedded JavaScript were source-validated and the underlying HTTP requests were directly tested, but screenshots/physical interaction have not been claimed as verified.

## Reproduction commands

```bash
npm test
npm run parents
node src/cli.mjs demo
node src/cli.mjs bench
node src/cli.mjs serve
```

Node.js >=20; no external npm packages.
