# Engineering architecture — Ripple OS v0.1.0-beta.1

## Runtime architecture

```mermaid
flowchart TD
 A[Local browser or Node client] -->|Bearer role token| B[HTTP boundary: loopback only]
 B --> C[Validation and capability checks]
 C --> D[Bounded weighted round-robin scheduler]
 D --> E[Service registry]
 E --> F[Assessment v1.5]
 E --> G[Daughter Triplet v3.1]
 E --> H[Seeded DaughterWorld]
 E --> I[Math compiler v2.1.1]
 F --> J[Persistent supervised weights]
 E --> K[Typed event bus]
 E --> L[Hashed audit journal]
```

The scheduler is application **cooperative** processing over `setImmediate`, one validated bounded job per turn. Weight ordering for priorities 0,1,2,3 is 8:4:2:1; task labels are not OS process priorities, and there is no preemption of a running CPU-bound service. Queue capacity is 128 by default; at-capacity submissions fail explicitly with HTTP 429. Failed tasks remain visible via scheduler metrics and hash-chained audit metadata.

## Data boundaries

1. Every task is a restricted JSON object with `service`, `payload`, optional `priority` and `requestId`. Unknown fields are refused.
2. Exact service names are allowlisted; no user-defined code or dynamic plugin import is allowed.
3. The caller's verified token maps to observer, researcher, or owner capabilities; the service's capability is checked *before* enqueue.
4. Services call actual parent source modules. The router only selects existing evidence; it does not fabricate citations or generate factual narrative.
5. Typed runtime events publish summary metadata, without raw question bodies or access tokens. Events live only in a bounded memory buffer.
6. Explicit owner feedback saves a versioned numerical-weight snapshot to a local file using temp-and-rename. The local journal stores service, status, duration and hash of the request payload.
7. On startup the journal chain is checked and policy restored. World/neuron transient states are intentionally reset on restart; crash recovery of pending work requires a future transactional queue.

## Which parts are improved by the engine?

Previously the programs were mostly standalone demonstrations. This runtime adds actual orchestration, access boundaries, common observability, a persistent learned-policy adapter, structured input validation and an authenticated local endpoint. **No increase in neural intelligence is inferred** from the architectural integration.

## Safety and limits

- **Not a system OS**: runs as a conventional Node process under Windows/macOS/Linux. It does not control CPU privilege modes, virtual memory, drivers or interrupts.
- **Not WASI**: adopts an allowlist/capability *pattern*, but does not sandbox independently supplied JavaScript at the CPU or process boundary.
- **Not physically calibrated**: imported recorded RGB is externally supplied and explicitly marked unverified.
- **Not a durable task broker**: in-memory queue is lost on abrupt shutdown. Source inputs and explicit policy snapshots are on disk.
- **Not a cloud deployment**: no public host, DNS or server-side user account is configured. See `SECURITY_AND_DEPLOYMENT.md` before attaching a reverse proxy.

## Backlog for the next verified gate

- A SQLite WAL backed durable task store with transactionally committed task/feedback boundaries.
- Child-process/Worker isolation for heavy plugin workloads and hard timeouts.
- A governed external data connector with explicit contracts and calibrated sensor metadata.
- Observability under a longer soak test, memory ceilings, crash-injection and recovery trials.
- A separate validation study comparing against a reference workflow with held-out source domains.

Do not present these backlog items as implemented.
