import test from 'node:test';import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';import {createHash} from 'node:crypto';
const base=new URL('../',import.meta.url);
const locks=JSON.parse(readFileSync(new URL('../SOURCE_LOCKS.json',import.meta.url),'utf8'));
test('all preserved parent modules match recorded source hash locks',()=>{
 assert.ok(locks.files.length>=60);
 for(const f of locks.files){const b=readFileSync(new URL(f.path,base)),hash=createHash('sha256').update(b).digest('hex');assert.equal(hash,f.sha256,f.path);assert.equal(b.length,f.bytes,f.path)}
});
test('original v0.1 neuron is retained unchanged',()=>{
 const src=readFileSync(new URL('../parents/Ripple-Daughter-Triplet-v3.1/vault/parent-ripple-v0.1.js',import.meta.url));
 assert.equal(createHash('sha256').update(src).digest('hex'),'dba6639b7902f0c702d15fff588524629f3754cfd72d7b704f22a76b78960ee3');
});
