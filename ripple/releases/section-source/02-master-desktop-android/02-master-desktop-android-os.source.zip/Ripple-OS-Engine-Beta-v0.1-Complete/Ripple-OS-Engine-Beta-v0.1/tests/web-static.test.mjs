import test from 'node:test';import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';import {Script} from 'node:vm';
const html=readFileSync(new URL('../web/index.html',import.meta.url),'utf8');
test('offline console contains one instance of each required control',()=>{
 const ids=[...html.matchAll(/\bid="([a-zA-Z][a-zA-Z0-9-]*)"/g)].map(x=>x[1]);
 assert.equal(new Set(ids).size,ids.length);
 for(const name of ['token','connect','conn','ask','question','gold','learn','verifylabel','evaluate','step','neuron','create','advance','world','attenuate','optical','status','refresh','audit','events'])assert.ok(ids.includes(name),name);
});
test('browser UI script parses as ordinary JavaScript without external dependencies',()=>{
 const blocks=[...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(x=>x[1]);assert.equal(blocks.length,1);assert.doesNotThrow(()=>new Script(blocks[0]));
 assert.ok(!/<script[^>]*src=/.test(html));
});
