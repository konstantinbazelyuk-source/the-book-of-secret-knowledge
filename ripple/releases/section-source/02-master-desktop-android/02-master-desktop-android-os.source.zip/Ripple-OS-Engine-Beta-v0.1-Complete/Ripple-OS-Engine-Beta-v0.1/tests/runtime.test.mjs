import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {RippleOS} from '../src/engine/runtime.mjs';
import {BoundedScheduler} from '../src/engine/scheduler.mjs';
import {AuditJournal} from '../src/engine/journal.mjs';
import {createServer} from '../src/engine/server.mjs';
const local=()=>fs.mkdtempSync(path.join(os.tmpdir(),'ripple-os-test-'));
function make(){return new RippleOS({dataDir:local()})}
const run=(r,service,payload={},who='owner',opts={})=>r.submit({service,payload,...opts},who).then(x=>x.result);

test('boot creates real registry and imports preserved learned policy',()=>{
 const r=make();assert.equal(r.status().version,'0.1.0-beta.1');assert.equal(r.router.ids.length,8);assert.ok(r.router.updates>0);
 assert.ok(r.status().services.includes('colony.create'));
});
test('BM25 selected baseline retrieves a real source passage with lineage',async()=>{
 const r=make();const out=await run(r,'evidence.assess',{query:'How did forest scouts learn the direction code?'},'observer');
 assert.ok(out.source.startsWith('Ripple-'));assert.ok(out.path.length===3);assert.equal(out.symbols.length,2);
 assert.ok(out.evidenceClass.includes('not verified factual answer'));
});
test('Daughter neuron returns 3 actual layers, allowed states and exact time',async()=>{
 const r=make(),res=await run(r,'neuron.step',{rgb:[.4,.1,.1],dt:.05},'researcher');
 assert.ok(res.layer1.filtered.length===3);assert.ok(Number.isFinite(res.layer2.dendrite));
 assert.ok(Number.isFinite(res.layer3.soma));assert.equal(res.t,.05);
});
test('Beer Lambert returns correct calculated transmittance and units',async()=>{
 const r=make(),a=await run(r,'optics.attenuate',{incident:1,coefficient:.35,path:2},'researcher');
 assert.ok(Math.abs(a.intensity-.4965853037914095)<1e-14);
 assert.ok(Math.abs(a.opticalDensity-.3040061373322762)<1e-14);
});
test('Daughter colony preserves seed replay and agent tracking',async()=>{
 const a=make(),b=make();for(const r of [a,b]){
  await run(r,'colony.create',{seed:1731,width:20,height:14},'researcher');
  await run(r,'colony.step',{ticks:8},'researcher');
 }
 const ar=await run(a,'colony.record',{},'researcher'),br=await run(b,'colony.record',{},'researcher');
 assert.equal(ar.summary.ticks,8);assert.deepEqual(ar.summary,br.summary);assert.deepEqual(ar.paths,br.paths);
 assert.equal(ar.evidence,'synthetic');
});
test('roles enforce explicit capabilities',async()=>{
 const r=make();await assert.rejects(()=>run(r,'neuron.reset',{},'observer'),e=>e.code==='DENIED');
 await assert.rejects(()=>run(r,'evidence.feedback',{query:'forest map',goldDoc:'forest_map'},'researcher'),e=>e.code==='DENIED');
 const z=await run(r,'system.services',{},'observer');assert.ok(z.find(x=>x.name==='evidence.feedback').capability==='learning.write');
});
test('all service inputs are bounded and arbitrary source execution impossible',async()=>{
 const r=make();await assert.rejects(()=>run(r,'system.shell',{command:'rm -rf /'}),e=>e.code==='NO_SERVICE');
 await assert.rejects(()=>run(r,'neuron.step',{rgb:[Infinity,0,0]}),e=>e.code==='INPUT');
 await assert.rejects(()=>run(r,'neuron.step',{rgb:[.5,0,0],dt:1}),e=>e.code==='INPUT');
 await run(r,'colony.create',{seed:5,width:8,height:8});
 await assert.rejects(()=>run(r,'colony.step',{ticks:500}),e=>e.code==='BUDGET');
 await assert.rejects(()=>run(r,'optics.attenuate',{incident:1,coefficient:-1,path:2}),e=>e.code==='INPUT');
 await assert.rejects(()=>run(r,'evidence.assess',{query:'a'.repeat(501)}),e=>e.code==='INPUT');
 assert.equal(r.scheduler.stats().failed>=3,true);
});
test('explicit feedback updates only numerical policy, persists across process restart',async()=>{
 const dataDir=local(),r=new RippleOS({dataDir});const before=r.router.updates;
 const ans=await run(r,'evidence.feedback',{query:'contrast scout forest symbols',goldDoc:'forest_signals'},'owner',{requestId:'feedback-one'});
 assert.equal(ans.round,before+1);
 const again=new RippleOS({dataDir});assert.equal(again.router.updates,before+1);
 await assert.rejects(()=>run(again,'evidence.feedback',{query:'contrast scout forest symbols',goldDoc:'forest_signals'},'owner',{requestId:'feedback-one'}),e=>e.code==='DUPLICATE');
});
test('audit append-only journal verifies chain across reload',async()=>{
 const dataDir=local(),r=new RippleOS({dataDir});
 await run(r,'optics.attenuate',{incident:.7,coefficient:2,path:1});
 await run(r,'system.status');const again=new RippleOS({dataDir});
 assert.equal(again.journal.verify().count,2);assert.equal(again.journal.latest(1)[0].kind,'task.ok');
});
test('edited journal is detected and startup fails closed',async()=>{
 const dataDir=local(),r=new RippleOS({dataDir});await run(r,'neuron.reset');
 const file=path.join(dataDir,'events.jsonl');const s=fs.readFileSync(file,'utf8');fs.writeFileSync(file,s.replace('neuron.reset','neuron.steps'));
 assert.throws(()=>new RippleOS({dataDir}),/mismatch/);
});
test('queue refuses overflow, duplicate ids, and oversized payloads',async()=>{
 const scheduler=new BoundedScheduler({capacity:2,execute:async t=>t.id,authorize:()=>{}});
 const a=scheduler.submit({service:'test.service',payload:{},requestId:'x'});
 const b=scheduler.submit({service:'test.service',payload:{},requestId:'y'});
 assert.throws(()=>scheduler.submit({service:'test.service',payload:{},requestId:'z'}),e=>e.code==='BACKPRESSURE');
 assert.throws(()=>scheduler.submit({service:'test.service',payload:{},requestId:'x'}),e=>e.code==='DUPLICATE');
 assert.throws(()=>scheduler.submit({service:'test.service',payload:{text:'a'.repeat(8200)}}),e=>e.code==='BUDGET');
 await Promise.all([a,b]);assert.equal(scheduler.stats().completed,2);
});
test('weighted scheduler eventually services low-priority queued work',async()=>{
 const order=[];const s=new BoundedScheduler({capacity:50,authorize:()=>{},execute:async t=>{order.push(t.id);return t.id}});
 const pending=[];for(let i=0;i<20;i++)pending.push(s.submit({service:'test.service',requestId:'high-'+i,priority:0}));
 pending.push(s.submit({service:'test.service',requestId:'low',priority:3}));
 await Promise.all(pending);assert.ok(order.indexOf('low')>=0);assert.ok(order.indexOf('low')<20);
});
test('owner-only HTTP API requires token, supports real service and forbids code endpoint',async()=>{
 const runtime=make();const srv=await createServer({runtime,port:0,token:'a'.repeat(26)});
 try{const base='http://127.0.0.1:'+srv.address.port;
  let res=await fetch(base+'/api/status');assert.equal(res.status,401);
  res=await fetch(base+'/api/status',{headers:{authorization:'Bearer '+'a'.repeat(26)}});assert.equal(res.status,200);
  let d=await res.json();assert.ok(d.services.includes('evidence.assess'));
  res=await fetch(base+'/api/services',{headers:{authorization:'Bearer '+'a'.repeat(26)}});d=await res.json();assert.ok(d.services.includes('neuron.step'));
  res=await fetch(base+'/api/task',{method:'POST',headers:{authorization:'Bearer '+'a'.repeat(26),'content-type':'application/json'},body:JSON.stringify({service:'optics.attenuate',payload:{incident:1,coefficient:.35,path:2}})});
  assert.equal(res.status,200);d=await res.json();assert.ok(Math.abs(d.result.intensity-.4965853)<1e-6);
  res=await fetch(base+'/api/task',{method:'POST',headers:{authorization:'Bearer '+'a'.repeat(26),'content-type':'application/json'},body:JSON.stringify({service:'system.exec',payload:{command:'ls'}})});assert.equal(res.status,404);
  res=await fetch(base);assert.equal(res.status,200);assert.ok((await res.text()).includes('Ripple OS Engine'));
 }finally{await srv.close()}
});
test('event bus routes typed service events and exposes bounded read-only recent history',async()=>{
 const r=make(),received=[];const unsub=r.bus.subscribe('neuron.updated',e=>received.push(e));
 await run(r,'neuron.step',{rgb:[.3,.1,.2],dt:.05});
 await run(r,'evidence.assess',{query:'forest direction signals'});
 const events=await run(r,'system.events',{limit:8},'observer');
 assert.equal(received.length,1);assert.ok(events.some(e=>e.topic==='neuron.updated'));assert.ok(events.some(e=>e.topic==='evidence.routed'));
 assert.ok(events.every(e=>!JSON.stringify(e).includes('forest direction signals')));
 unsub();await run(r,'neuron.step',{rgb:[.3,.1,.2],dt:.05});assert.equal(received.length,1);
});
test('unchanged assessment holdout benchmark remains 23 of 32 BM25 and 13 learned',async()=>{
 const r=make();const result=await run(r,'evidence.evaluate',{},'observer');
 assert.equal(result.n,32);assert.equal(result.bm25.correct,23);assert.equal(result.trained.correct,13);assert.equal(result.bm25.top3,30);
});
test('three independent bearer roles enforce API authorization separately',async()=>{
 const runtime=make();const srv=await createServer({runtime,port:0,token:'a'.repeat(26),observerToken:'b'.repeat(26),researcherToken:'c'.repeat(26)});
 try{const base='http://127.0.0.1:'+srv.address.port+'/api/task',call=async(t,service,payload={})=>fetch(base,{method:'POST',headers:{authorization:'Bearer '+t,'content-type':'application/json'},body:JSON.stringify({service,payload})});
  let r=await call('b'.repeat(26),'neuron.step',{rgb:[.1,0,0],dt:.05});assert.equal(r.status,403);
  r=await call('c'.repeat(26),'neuron.step',{rgb:[.1,0,0],dt:.05});assert.equal(r.status,200);
  r=await call('c'.repeat(26),'evidence.feedback',{query:'forest code',goldDoc:'forest_signals'});assert.equal(r.status,403);
  r=await call('a'.repeat(26),'evidence.feedback',{query:'forest code',goldDoc:'forest_signals'});assert.equal(r.status,200);
 }finally{await srv.close()}
});
test('typed recorded-data ingestion drives the actual Daughter neuron without claiming sensor validation',async()=>{
 const r=make();const res=await run(r,'sensor.ingest',{sourceId:'recorded-webcam-trial',kind:'recorded-unverified',samples:[{rgb:[.2,.4,.1],dt:.05},{rgb:[.3,.6,.1],dt:.05}]},'researcher');
 assert.equal(res.accepted,2);assert.equal(res.neuronTime,.1);assert.ok(res.evidence.includes('not verified'));
 assert.ok(Number.isFinite(res.latestLayers.soma.rate));
});
test('sensor ingestion fully validates batch before changing neuron state',async()=>{
 const r=make();await assert.rejects(()=>run(r,'sensor.ingest',{sourceId:'trial',kind:'measured',samples:[{rgb:[.1,.2,.3]}]},'researcher'),e=>e.code==='INPUT');
 await assert.rejects(()=>run(r,'sensor.ingest',{sourceId:'trial',kind:'synthetic',samples:[{rgb:[.1,.2,.3]},{rgb:[.1,99,.3]}]},'researcher'),e=>e.code==='INPUT');
 assert.equal(r.neuron.t,0);
});
test('original mathematics compiler inverse formula accessible as a bounded runtime service',async()=>{
 const r=make();const i=await run(r,'optics.formula',{mode:'solve_mu',inputs:{I0:1,I:Math.exp(-.7),L:2}},'researcher');
 assert.ok(Math.abs(i.mu-.35)<1e-13);
 await assert.rejects(()=>run(r,'optics.formula',{mode:'solve_mu',inputs:{I0:1,I:2,L:2}},'researcher'),/cannot exceed/);
});
