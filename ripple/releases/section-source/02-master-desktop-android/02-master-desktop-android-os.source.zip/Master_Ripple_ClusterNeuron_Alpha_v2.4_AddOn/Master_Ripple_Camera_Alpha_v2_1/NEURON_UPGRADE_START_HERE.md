# Ripple ClusterNeuron Alpha v2.4 — parent-neuron upgrade laboratory

**Scope**: a tested, separately versioned addition to Master Ripple ClusterNeuron v2.3. v2.3's original core and schedulers remain present. Camera frame processing is real OpenCV code; supplied recordings are **computer-generated** and do not verify a physical webcam.

## What was reused, not rewritten

- `legacy/ripple-core.js`: original v0.1 baseline, untouched (called by inherited `cluster_neuron/cluster.cjs`).
- `neuron_upgrade/parents/daughter/vault/delta/delta-neuron.mjs`: original Ripple Delta v3.0 algorithm, imported intact from Daughter v3.1's frozen Delta vault; **feedforward disabled** per previous numerical evidence, not a source edit.
- `neuron_upgrade/parents/daughter/src/triplet-neuron.mjs`: original Ripple Daughter v3.1 three-stage optical-soma source, imported intact.
- `neuron_upgrade/parents/daughter/vault/delta/photometry.mjs`: original Delta v3.0 radiometric utility used by both JS parents.
- `neuron_upgrade/parents/charlie/charlie_core/neuron.py`: original Charlie v2.0 conductance-based Python neuron, imported intact.
- Both input encoding and v2.3 attention/scheduling mechanisms are carried forward. In **Charlie** mode, delayed neighbor events are delivered via Charlie's actual inherited `exc_pulses` internal conductance input, scaled by a bounded gain. In Delta/Daughter, the one-frame delayed communication is encoded into the R slot as in v2.3; it is not physical red light.

The parent source hashes are stored in `neuron_upgrade/SOURCE_HASHES.json` and archived source packages remain in `frozen_archives/` of the complete release. The parent archives may impose individual license notices; do not assume every inherited component carries the new MIT license.

## Operating with a camera or replay

Requirements: Python 3.10+, NumPy, OpenCV, Node.js 18+; a modern browser for the workstation. From this exact extracted directory:

```sh
python -m pip install -r requirements_camera.txt
python Launch_Master_Ripple_Camera.py --device 0
```

On Windows use `python` or `py` as installed. The local website is `http://127.0.0.1:8788/`. Click **Enable colony sampling**, click **Start capture**, accumulate at least 12 frames, choose the **v2.4 neuron type** (original, Delta, Daughter, Charlie, Mixed), select **Quality** or **Economy**, and press **Run upgraded cluster v2.4**. Stop the camera when done. This retains local-only HTTP, session-token checks and explicit opt-in sampling. The program does not send camera data to a cloud service.

To test without a camera, use a known generated replay rather than claiming live sensing:

```sh
python Launch_Master_Ripple_Camera.py --file colony_fixtures/seed13.avi
```

The camera may finish playback before you click; enabling sampling **before** capture is necessary.

## Independent research and repeatability

```sh
python -m unittest discover -s neuron_upgrade/tests -p 'test*.py' -q
python -m neuron_upgrade.benchmark --frames 96 --repeats 2
python neuron_upgrade/browser_smoke.py  # optional: requires Playwright and Chromium
```

`neuron_upgrade/results/benchmark.csv` stores each selected task count, spike count, per-variant control latency, and event coverage. It uses **three decoded synthetic video fixtures** and identical input samples for all five variants. Optical-flow, color, blur, and darkness outputs are each computed once exhaustively; the variant gate's selected reference outputs are evaluated without repeating full OpenCV work for every candidate. Runtime latency is the neuron-forward-pass wall time only, **not** end-to-end camera FPS.

## Numerical interpretation

- The upgraded parents are **more sophisticated models**, not automatically improved detectors. On changed-geometry 96-frame synthetic replay, all five modes retained 36/36 optical-flow reference-positive frames in **Quality**, whereas **Economy** retained 9–10/36. Quality must be the default when missed motion is unacceptable.
- On this same fixture, the four independently preserved parents yield different total neuron event counts: Original 31, Delta 28, Daughter 30, Mixed 29, Charlie 24. Counts do not establish superior reasoning, optical measurement or semantic recognition.
- Node.js-based models pay a process-startup overhead, whereas Charlie executes in-process in Python; do **not** infer neuron computational superiority from these cross-runtime timings. No speed win is claimed.
- The inherited source code has research validation only. None of these models was fitted to true optically calibrated signals or tested on a physical camera in this environment.

## Research basis

- Brette & Gerstner (2005), adaptive exponential integrate-and-fire models, doi:10.1152/jn.00686.2005. This supports using richer temporal neuron dynamics; Delta/Daughter/Charlie are **user-engineered variants**, not identical implementations of AdEx.
- Original parents' own mathematical comparisons in their archived documentation, especially `docs/COMPARISON_AND_EVIDENCE.md`, which recorded conditions where Delta was more accurate and conditions where it was not.
- OpenCV's documented camera decoding, Laplacian variance, and Farneback optical flow algorithms.

### Not demonstrated

Physical camera connection in this host; intrinsic intelligence, biological neuron equivalence, electromagnetic magnetic-field detection from RGB pixels, new spiritual field sensing, guaranteed AI accuracy increase, or universal reduction in computation.
