"""Master Ripple Camera Alpha v2.1 — OpenCV device/file capture to strictly typed v2 input.

No automatic camera start. No file/URL sourcing through the web API. No physical calibration claims.
"""
from __future__ import annotations
import copy
import io
import json
import math
import sys
import threading
import time
from urllib.parse import urlparse
from collections import deque
from pathlib import Path
from typing import Callable

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from master import GuardedStream, analyze_master, inherited_genomes, SCHEMA, SENSOR_UNITS  # noqa: E402
from verify_sources import verify_sources  # noqa: E402

PROPS = {
    'exposure': ('CAP_PROP_EXPOSURE', -20, 10000),
    'auto_exposure': ('CAP_PROP_AUTO_EXPOSURE', 0, 4),
    'gain': ('CAP_PROP_GAIN', 0, 255),
    'brightness': ('CAP_PROP_BRIGHTNESS', -255, 255),
    'contrast': ('CAP_PROP_CONTRAST', 0, 255),
    'focus': ('CAP_PROP_FOCUS', 0, 500),
    'autofocus': ('CAP_PROP_AUTOFOCUS', 0, 1),
    'fps': ('CAP_PROP_FPS', 1, 120),
    'white_balance': ('CAP_PROP_WB_TEMPERATURE', 1500, 10000),
    'auto_white_balance': ('CAP_PROP_AUTO_WB', 0, 1),
}
MAX_RECORDS = 512
MAX_FRAMES_ANALYSIS = 128


def frame_to_rgb(frame: np.ndarray, roi: tuple[float, float, float, float]) -> list[float]:
    if not isinstance(frame, np.ndarray) or frame.ndim != 3 or frame.shape[2] != 3 or frame.dtype != np.uint8:
        raise ValueError('expected 8-bit BGR camera frame (3 channels)')
    if not all(math.isfinite(v) and 0 <= v <= 1 for v in roi) or len(roi) != 4:
        raise ValueError('invalid normalized ROI')
    x,y,w,h = roi
    if w <= 0 or h <= 0 or x+w > 1.0000001 or y+h > 1.0000001:
        raise ValueError('ROI exceeds frame')
    height,width = frame.shape[:2]
    x0=min(width-1, int(x*width)); y0=min(height-1, int(y*height))
    x1=max(x0+1, min(width,math.ceil((x+w)*width)))
    y1=max(y0+1, min(height,math.ceil((y+h)*height)))
    mean_bgr=frame[y0:y1,x0:x1].mean(axis=(0,1))
    out=[float(v/255) for v in mean_bgr[::-1]]
    if not all(0 <= v <= 1 for v in out):raise ValueError('nonfinite frame channels')
    return out


class CameraStation:
    def __init__(self, source: int | str=0, *, factory: Callable | None=None, display_source: str | None=None):
        self.source = source
        self.device_mode = isinstance(source,int)
        self.stream_mode = isinstance(source,str) and urlparse(source).scheme.lower() in {'rtsp','http','https'}
        self.live_mode = self.device_mode or self.stream_mode
        self.source_label = display_source or (f'camera_index:{source}' if self.device_mode else (f'network_stream:{urlparse(source).hostname}' if self.stream_mode else f'video_file:{Path(source).name}'))
        self._factory = factory or (lambda src:cv2.VideoCapture(src))
        self.lock=threading.RLock()
        self.capture=None
        self.running=False
        self.thread=None
        self.start_t=0.
        self.latest_frame=None
        self.latest_jpeg=None
        self.last_rgb=None
        self.roi=(.35,.35,.3,.3)
        self.records=deque(maxlen=MAX_RECORDS)
        self.total_frames=0
        self.read_failures=0
        self.error=None
        self.status_message='Stopped. Camera permission is requested by your operating system when you start.'
        self.control_audit=[]
        self.last_props={}
        self.backend='unopened'
        self.frame_shape=None
        self.last_frame_t=None
        self.actual_fps=None
        self._stop=threading.Event()
        self.colony_enabled=False
        self.colony_frames=deque(maxlen=64)
        self.colony_fps=24.0

    def _opened(self):
        return self.capture is not None and self.capture.isOpened()

    def start(self):
        with self.lock:
            if self.running:return self.status()
            self._stop.clear()
            try:
                cap=self._factory(self.source)
                if not cap or not cap.isOpened():
                    if cap:cap.release()
                    self.error='Unable to open capture source; check connection, permissions, and camera index.'
                    self.status_message='Camera unavailable';return self.status()
                self.capture=cap
                self.backend=cap.getBackendName() if hasattr(cap,'getBackendName') else 'unknown_backend'
                self.error=None
                self.running=True
                self.start_t=time.monotonic()
                self.last_frame_t=None
                self.total_frames=0
                self.read_failures=0
                self.records.clear()
                self.colony_frames.clear()
                self.latest_jpeg=None
                self.last_rgb=None
                self.last_props={}
                self.status_message='Capturing frames; RGB values are uncalibrated display-referred pixels.'
                self.thread=threading.Thread(target=self._loop,name='RippleCameraCapture',daemon=True)
                self.thread.start()
                return self.status()
            except Exception as exc:
                self.error=f'Capture open failed: {type(exc).__name__}: {exc}'
                self.running=False
                return self.status()

    def _loop(self):
        try:
            while not self._stop.is_set():
                with self.lock:
                    if not self._opened():break
                    ok,frame=self.capture.read()
                    if not ok or frame is None or getattr(frame,'size',0)==0:
                        self.read_failures+=1
                        if not self.live_mode:
                            self.status_message='Video file ended.'
                            break
                        if self.read_failures>=5:
                            self.error='Device stopped returning frames (disconnect or driver failure).'
                            break
                        frame=None
                    if frame is not None:
                        self.read_failures=0
                        now=time.monotonic()
                        elapsed_ms=max(.001,(now-self.start_t)*1000)
                        if self.records and elapsed_ms<=self.records[-1]['t_ms']:
                            elapsed_ms=self.records[-1]['t_ms']+.001
                        try:
                            rgb=frame_to_rgb(frame,self.roi)
                        except ValueError as exc:
                            self.error=f'Unexpected camera format: {exc}';break
                        self.last_rgb=rgb
                        self.frame_shape=(int(frame.shape[1]),int(frame.shape[0]))
                        self.total_frames+=1
                        if self.colony_enabled and self.total_frames%2==0:
                            self.colony_frames.append(cv2.resize(frame,(160,120),interpolation=cv2.INTER_AREA).copy())
                            self.colony_fps=(float(cap_fps) if (cap_fps:=self.capture.get(cv2.CAP_PROP_FPS)) and math.isfinite(cap_fps) and cap_fps>0 else 24.0)/2
                        if self.last_frame_t is not None:
                            dt=max(1e-4,now-self.last_frame_t)
                            hz=1/dt
                            self.actual_fps=hz if self.actual_fps is None else .8*self.actual_fps+.2*hz
                        self.last_frame_t=now
                        self.records.append({'schema':SCHEMA,'kind':'optical_rgb',
                                             'source':'hardware_reported_unverified' if self.live_mode else 'simulated',
                                             't_ms':elapsed_ms,'unit':SENSOR_UNITS['optical_rgb'],'values':rgb})
                        okjpg,encoded=cv2.imencode('.jpg',frame,[int(cv2.IMWRITE_JPEG_QUALITY),78])
                        if okjpg:self.latest_jpeg=bytes(encoded)
                # Avoid spinning fast when reading a prerecorded file or non-blocking driver.
                if frame is None:
                    time.sleep(.05)
                elif not self.live_mode:
                    with self.lock:
                        file_rate=float(self.capture.get(cv2.CAP_PROP_FPS)) if self._opened() else 0
                    time.sleep(1/min(max(file_rate,1),30))
                else:
                    time.sleep(.01)
        finally:
            with self.lock:
                if self.capture is not None:
                    self.capture.release()
                    self.capture=None
                self.running=False

    def stop(self):
        with self.lock:
            self._stop.set()
            thread=self.thread
        if thread and thread is not threading.current_thread():thread.join(timeout=3)
        with self.lock:
            if self.running:
                self.status_message='Stop requested; waiting for driver to return.'
            else:self.status_message='Stopped.'
            return self.status()

    def update_roi(self, values):
        if not isinstance(values,list) or len(values)!=4:raise ValueError('ROI must contain four values')
        v=tuple(float(x) for x in values)
        if not all(math.isfinite(x) and 0<=x<=1 for x in v) or v[2]<.02 or v[3]<.02 or v[0]+v[2]>1 or v[1]+v[3]>1:
            raise ValueError('ROI must be within [0,1] with width/height >=0.02')
        with self.lock:self.roi=v
        return self.status()

    def set_control(self,name,value):
        if name not in PROPS:raise ValueError('unknown camera control')
        if not self.device_mode:raise ValueError('replay files do not accept hardware controls')
        if not isinstance(value,(int,float)) or isinstance(value,bool) or not math.isfinite(value):raise ValueError('control must be finite number')
        prop_name,lo,hi=PROPS[name]
        if not lo<=value<=hi:raise ValueError(f'control outside recommended API range [{lo},{hi}]')
        with self.lock:
            if not self.running or not self._opened():raise RuntimeError('start camera before applying controls')
            property_id=getattr(cv2,prop_name,None)
            if property_id is None:raise ValueError(f'OpenCV backend lacks {prop_name}')
            before=float(self.capture.get(property_id))
            accepted=bool(self.capture.set(property_id,float(value)))
            after=float(self.capture.get(property_id))
            audit={'control':name,'requested':float(value),'backend_set_returned':accepted,
                   'before_readback':before if math.isfinite(before) else None,
                   'after_readback':after if math.isfinite(after) else None,
                   'readback_matches_request':bool(math.isfinite(after) and math.isclose(after,value,rel_tol=.02,abs_tol=.05)),
                   'verified_effect_on_hardware':False,
                   'note':'set and get are API/driver reports; effectiveness needs a controlled physical test'}
            self.control_audit.append(audit)
            self.control_audit=self.control_audit[-50:]
            return audit

    def probe_control(self,name,value,samples=8,timeout_s=4.0):
        """Request a setting and quantify any subsequent *observed* pixel shift.

        This is not a calibration or evidence of causal hardware response: lighting,
        auto-exposure, driver buffering and object motion remain confounders.
        """
        if not self.device_mode:raise ValueError('pixel-response probe only for directly connected cameras')
        if not isinstance(samples,int) or not 4<=samples<=16:raise ValueError('samples must be 4–16')
        with self.lock:
            if not self.running or len(self.records)<samples:raise RuntimeError('need active camera and more baseline frames')
            before=np.asarray([r['values'] for r in list(self.records)[-samples:]],dtype=float)
            last_seen=self.total_frames
        setting=self.set_control(name,value)
        after=[]
        end=time.monotonic()+timeout_s
        while len(after)<samples and time.monotonic()<end:
            with self.lock:
                if self.total_frames>last_seen and self.last_rgb is not None:
                    after.append(list(self.last_rgb));last_seen=self.total_frames
                if not self.running:break
            time.sleep(.01)
        if len(after)<samples:raise RuntimeError('not enough post-control frames from device')
        a=np.asarray(after,float)
        lum=np.array([.2126,.7152,.0722])
        before_mean=float((before@lum).mean())
        after_mean=float((a@lum).mean())
        change=after_mean-before_mean
        return {'control_setting_report':setting,'before_roi_luminance':before_mean,
                'after_roi_luminance':after_mean,'signed_delta':change,
                'samples_before':len(before),'samples_after':len(after),
                'pixel_response_detected_at_0_01':abs(change)>=.01,
                'validated_hardware_causal_change':False,
                'interpretation':'Observed pixel difference only. Fixed illumination, control of auto-exposure/white balance and independent repetition needed for causal interpretation.'}

    def status(self):
        with self.lock:
            return {'running':self.running,'source':self.source_label,'origin':'live_device_unverified' if self.device_mode else ('live_stream_unverified' if self.stream_mode else 'video_file_replay'),
                    'camera_hardware_verified':False,'backend':self.backend,'frames':self.total_frames,
                    'buffered':len(self.records),'last_rgb':self.last_rgb,'roi':list(self.roi),
                    'width_height':self.frame_shape,'observed_fps_estimate':round(self.actual_fps,2) if self.actual_fps else None,
                    'error':self.error,'message':self.status_message,'latest_controls':self.control_audit[-5:],
                    'supports_set_requests':self.device_mode,'available_genomes':list(inherited_genomes()),
                    'colony_enabled':self.colony_enabled,'colony_buffered':len(self.colony_frames)}


    def set_colony(self,enabled:bool):
        if type(enabled) is not bool:raise ValueError('enabled must be a boolean')
        with self.lock:
            self.colony_enabled=enabled
            self.colony_frames.clear()
            return self.status()

    def run_colony(self):
        with self.lock:
            if not self.colony_enabled:raise RuntimeError('enable local colony sampling first')
            frames=[f.copy() for f in self.colony_frames]
            fps=self.colony_fps
        if len(frames)<12:raise RuntimeError('need at least 12 sampled frames; start capture and try again')
        from colony_lab.engine import run_experiment
        report=run_experiment(frames,fps,workers=(1,2),repetitions=1)
        report['input_provenance']='actual camera pixel arrays' if self.live_mode else 'recorded video frame pixel arrays'
        report['sensor_verification']='camera device unverified' if self.live_mode else 'video replay, not a camera hardware test'
        report['frames_are_stored_or_exported']=False
        return report

    def run_cluster_neuron(self, genome='prism', mode='quality'):
        """Opt-in existing camera colony buffer only; no implicit device access."""
        with self.lock:
            if not self.colony_enabled:
                raise RuntimeError('enable colony sampling first')
            frames=[frame.copy() for frame in self.colony_frames]
            fps=self.colony_fps
        if len(frames)<12:
            raise RuntimeError('at least 12 stored frames are needed')
        from cluster_neuron.engine import run_cluster
        report=run_cluster(frames,fps,genome=genome,workers=2,compare_full=True,mode=mode)
        report['source']={'mode':'live_device_unverified' if self.live_mode else 'video_replay',
                          'source_label':self.source_label,'hardware_calibrated':False,
                          'opt_in_sampling':True,'frames_exported':False}
        return report

    def run_upgrade_neuron(self, genome='prism', mode='quality', variant='mixed'):
        """Optional upgraded neuron; inherits the camera buffer opt-in and safety gate."""
        if variant not in ('original','delta','daughter','mixed','charlie'):
            raise ValueError('unknown neuron variant')
        with self.lock:
            if not self.colony_enabled: raise RuntimeError('enable local colony sampling first')
            frames=[f.copy() for f in self.colony_frames]
            fps=self.colony_fps
        if len(frames)<12: raise RuntimeError('at least 12 stored frames are needed')
        from neuron_upgrade.engine import run_upgrade
        report=run_upgrade(frames,fps,genome=genome,mode=mode,variant=variant,workers=2,compare_full=False)
        report['source']={'mode':'live_device_unverified' if self.live_mode else 'video_replay',
                          'source_label':self.source_label,'hardware_calibrated':False,
                          'opt_in_sampling':True,'frames_exported':False}
        return report

    def jpeg(self):
        with self.lock:return self.latest_jpeg

    def events(self):
        with self.lock:return [copy.deepcopy(item) for item in self.records]

    def analyze(self,genome='prism'):
        registry=inherited_genomes()
        if genome not in registry:raise ValueError('unknown genome')
        data=self.events()[-MAX_FRAMES_ANALYSIS:]
        if not data:raise ValueError('no camera frames recorded; press Start first')
        if not verify_sources(include_archives=False)['passed']:raise RuntimeError('original Master source integrity check failed')
        guard=GuardedStream()
        for frame in data:guard.accept(frame)
        result=analyze_master(data,registry[genome])
        # Critical qualification: v2 accepts only simulated or hardware_reported_unverified.
        # File replay is never misrepresented as live capture.
        result['camera_bridge']={'source':self.source_label,'mode':'live_device_unverified' if self.device_mode else ('live_stream_unverified' if self.stream_mode else 'video_file_replay'),
                                 'frames_analyzed':len(data),'raw_rgb_unit':'uncalibrated_camera_BGR8_ROI_to_RGB01',
                                 'camera_control_validation':'backend API report only; no bench verification',
                                 'replay_mapping':'v2 legacy schema uses simulated for video replay; file content is not necessarily synthetic' if not self.live_mode else None}
        if not self.live_mode:
            # Preserve the legacy Master input contract, but correct classification
            # in the camera-extension response so prerecorded data is NOT misdescribed.
            result['master_v2_internal_classification']='simulated'
            result['classification']='video_file_replay_unverified'
        return result
