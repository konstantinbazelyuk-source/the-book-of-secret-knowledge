"""Comparisons on identical file-decoded synthetic video, with warmup and repetitions.
Not camera hardware validation; not calibrated physical accuracy or cognition.
"""
from __future__ import annotations
import argparse,csv,json,statistics,time
import cv2
from pathlib import Path
from colony_lab.engine import decode_video,execute,TASKS,evaluate_task_coverage
from cluster_neuron.engine import cheap_features,select_work
from neuron_upgrade.engine import MODES,run_variant

ROOT=Path(__file__).resolve().parents[1]
SOURCES={'seed13':'colony_fixtures/seed13.avi','seed29':'colony_fixtures/holdout_seed29.avi','changed_geometry':'cluster_results/holdout_geometry.avi'}
def run(frame_count=96,repeats=3):
 if not 12<=frame_count<=192 or not 1<=repeats<=7:raise ValueError('bounded benchmark inputs')
 cv2.setNumThreads(1)  # Prevent repeated OpenCV pool startup in offline comparison.
 rows=[];series=[]
 for label,path in SOURCES.items():
  frames,fps=decode_video(ROOT/path,frame_count)
  samples,cheap=cheap_features(frames,fps)
  print('scene',label,'frames',len(frames),'fps',fps,flush=True)
  reference=execute(frames,[(i,k) for i in range(len(frames)) for k in TASKS],workers=1)['results']
  for variant in MODES:
   # timed portion: forward pass only, identical inputs and settings.
   run_variant(samples,variant=variant)
   times=[]
   for _ in range(repeats):
    t0=time.perf_counter();n=run_variant(samples,variant=variant);times.append(1000*(time.perf_counter()-t0))
   for mode in ['quality','economy']:
    work,audit,reasons=select_work(samples,n['observations'],cheap,mode=mode)
    # Counterfactual replay uses the SAME already executed exhaustive numerical results.
    # Task counts are schedule proposals; no misleading repeated task-speed claim.
    outcomes={key:reference[key] for key in work}
    coverage=evaluate_task_coverage(reference,outcomes)
    row={'scene':label,'frames':len(frames),'variant':variant,'mode':mode,
      'median_neuron_ms':round(statistics.median(times),3),'tasks':len(work),
      'neuron_events':sum(n['spikes_per_node']),
      'motion_reference':coverage['motion']['full_reference_positive_frames'],
      'motion_sampled':coverage['motion']['selected_positive_frames'],
      'blur_reference':coverage['blur']['full_reference_positive_frames'],
      'blur_sampled':coverage['blur']['selected_positive_frames'],
      'color_reference':coverage['color_flash']['full_reference_positive_frames'],
      'color_sampled':coverage['color_flash']['selected_positive_frames'],
      'dark_reference':coverage['dark_patch']['full_reference_positive_frames'],
      'dark_sampled':coverage['dark_patch']['selected_positive_frames']}
    rows.append(row)
    if mode=='quality':series.append({'scene':label,'variant':variant,'spikes_by_node':n['spikes_per_node']})
 out=ROOT/'neuron_upgrade/results';out.mkdir(exist_ok=True)
 with (out/'benchmark.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
 (out/'benchmark.json').write_text(json.dumps({'classification':'synthetic_video_decoded_with_real_OpenCV','repeats':repeats,
  'rows':rows,'neuron_series':series,'caveats':['video simulated source, OpenCV really decoded it',
 'quality guarantees motion computation on every frame; that reference coverage is structural',
 'neuron timings exclude frame feature extraction and heavy-task calculations',
 'task coverage uses counterfactual selection of actually computed exhaustive outputs, not repeated selective task execution',
 'no hyperparameter tuning against independent hardware tests']},indent=2))
 print('output rows',len(rows),flush=True)
 return rows
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--frames',type=int,default=96);a.add_argument('--repeats',type=int,default=3);args=a.parse_args();run(args.frames,args.repeats)
