# Four-sense specialist neuron upgrade (v2.4)

See [`../NEURON_UPGRADE_START_HERE.md`](../NEURON_UPGRADE_START_HERE.md) for operations, scientific validation, and limitations.

`bridge.mjs` imports the original, unaltered Delta v3.0 and Daughter v3.1 implementations. `engine.py` invokes the original Charlie v2.0 Python code, preserving internal excitatory recurrent pulses, or delegates to the untouched v2.3 original. `benchmark.py` runs identical decoded camera-feature sequences with explicit policies and summary records. All five variants work via local API at `/api/cluster/v24/run` following existing opt-in rules.
