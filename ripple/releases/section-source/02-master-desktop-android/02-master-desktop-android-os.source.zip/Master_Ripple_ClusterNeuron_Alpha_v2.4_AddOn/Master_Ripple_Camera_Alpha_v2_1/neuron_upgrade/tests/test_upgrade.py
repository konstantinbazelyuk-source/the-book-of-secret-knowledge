import hashlib,json,math,subprocess,sys,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT),str(ROOT/'src')]
from neuron_upgrade.engine import run_variant,run_upgrade,MODES
from cluster_neuron.engine import cheap_features,run_original_cluster
from colony_lab.engine import decode_video

class UpgradeTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.frames,cls.fps=decode_video(ROOT/'colony_fixtures/seed13.avi',24)
  cls.samples,_=cheap_features(cls.frames,cls.fps)
 def test_01_parents_present(self):
  for p in ('daughter/src/triplet-neuron.mjs','daughter/vault/delta/delta-neuron.mjs','daughter/vault/delta/photometry.mjs','charlie/charlie_core/neuron.py'):
   self.assertTrue((ROOT/'neuron_upgrade/parents'/p).exists())
 def test_02_modes(self):self.assertEqual(set(MODES),{'original','delta','daughter','mixed','charlie'})
 def test_03_original_parity(self):
  self.assertEqual(run_variant(self.samples,variant='original'),run_original_cluster(self.samples,gains=[1]*4))
 def test_04_parent_source_integrity(self):
  # Hash once from frozen upstream ZIPs; this test is against the source manifest.
  manifest=json.loads((ROOT/'neuron_upgrade/SOURCE_HASHES.json').read_text())
  for name,expected in manifest.items():
   self.assertEqual(hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),expected)
 def test_05_all_actual_neurons(self):
  for mode in MODES:
   o=run_variant(self.samples,variant=mode)
   self.assertEqual(len(o['observations']),24)
   self.assertEqual(len(o['spikes_per_node']),4)
 def test_06_deterministic(self):
  for variant in MODES:
   self.assertEqual(run_variant(self.samples,variant=variant),run_variant(self.samples,variant=variant))
 def test_07_weight_bounds(self):
  for variant in MODES:
   for row in run_variant(self.samples,variant=variant)['observations']:
    self.assertAlmostEqual(sum(row['weights']),1,places=10)
    self.assertTrue(all(0<=x<=1 for x in row['weights']))
 def test_08_causal_prefix(self):
  for variant in MODES:
   a=run_variant(self.samples[:12],variant=variant)['observations']
   b=run_variant(self.samples,variant=variant)['observations']
   self.assertEqual(a,b[:12])
 def test_09_unknown_variant_rejected(self):
  with self.assertRaises(ValueError):run_variant(self.samples,variant='hallucinated')
 def test_10_invalid_sensor_rejected(self):
  s=json.loads(json.dumps(self.samples));s[5]['features'][0]=2
  with self.assertRaises(ValueError):run_variant(s,variant='daughter')
 def test_11_nan_rejected(self):
  s=json.loads(json.dumps(self.samples));s[4]['features'][0]=float('nan')
  with self.assertRaises(ValueError):run_variant(s,variant='delta')
 def test_12_timestamps_rejected(self):
  s=json.loads(json.dumps(self.samples));s[9]['t_ms']=s[8]['t_ms']
  with self.assertRaises(ValueError):run_variant(s,variant='mixed')
 def test_13_reject_invalid_gains(self):
  with self.assertRaises(ValueError):run_variant(self.samples,variant='mixed',gains=[1,2,1,1])
 def test_14_reject_unbounded_coupling(self):
  with self.assertRaises(ValueError):run_variant(self.samples,variant='mixed',coupling=1)
 def test_15_reject_unbounded_eta(self):
  with self.assertRaises(ValueError):run_variant(self.samples,variant='mixed',eta=1)
 def test_16_duration_guard(self):
  s=json.loads(json.dumps(self.samples));s[1]['t_ms']=350
  with self.assertRaises(ValueError):run_variant(s,variant='delta')
 def test_17_original_frame_not_mutated(self):
  snap=self.frames[4].copy();run_upgrade(self.frames,self.fps,variant='mixed',compare_full=False)
  import numpy as np
  self.assertTrue(np.array_equal(snap,self.frames[4]))
 def test_18_quality_full_flow(self):
  for mode in MODES:
   r=run_upgrade(self.frames,self.fps,variant=mode,mode='quality',compare_full=False)
   self.assertGreaterEqual(r['tasks_executed'],len(self.frames)*5)
   self.assertEqual(r['full_task_count'],len(self.frames)*7)
 def test_19_comparative_coverage(self):
  for mode in ['original','mixed']:
   r=run_upgrade(self.frames,self.fps,variant=mode,mode='quality',compare_full=True)
   cov=r['reference']['positive_coverage']
   self.assertIsNotNone(cov)
 def test_20_station_opt_in(self):
  from camera_bridge.core import CameraStation
  station=CameraStation(0)
  with self.assertRaisesRegex(RuntimeError,'enable local colony'):
   station.run_upgrade_neuron()
 def test_21_station_variant_guard(self):
  from camera_bridge.core import CameraStation
  station=CameraStation(0)
  with self.assertRaises(ValueError):station.run_upgrade_neuron(variant='unsupported')
 def test_22_camera_server_route(self):
  s=(ROOT/'camera_bridge/server.py').read_text()
  h=(ROOT/'camera_web/index.html').read_text()
  self.assertIn("'/api/cluster/v24/run'",s)
  self.assertIn('upgradeRun',h)
 def test_23_against_parent_equal(self):
  # Source paths integrated without rewriting the prior source files.
  manifest=json.loads((ROOT/'neuron_upgrade/INTEGRATION_AUDIT.json').read_text())
  self.assertEqual(len(manifest['changed_files']),3)
 def test_24_causal_spike_step(self):
  # Construct a step sequence and require a bounded response, not a particular spike count.
  s=[{'t_ms':i*40,'features':[0,0,0,0] if i<8 else [1,1,1,1]} for i in range(35)]
  for mode in MODES:
   n=run_variant(s,variant=mode)
   self.assertTrue(all(isinstance(x,int) and x>=0 for x in n['spikes_per_node']))
 def test_25_no_unauthorized_side_effects(self):
  # There is no new outbound network API or camera-start call in the bridge.
  text=(ROOT/'neuron_upgrade/bridge.mjs').read_text()
  self.assertNotIn('fetch(',text)
  self.assertNotIn('exec(',text)
 def test_26_validated_real_frame_values(self):
  self.assertTrue(all(all(0<=v<=1 for v in x['features']) for x in self.samples))

if __name__=='__main__':unittest.main()
