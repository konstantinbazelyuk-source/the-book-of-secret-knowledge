"""Injected mocked API for browser widget control only; HTTP verified separately."""
from pathlib import Path
import json
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1]
html=(R/'camera_web/index.html').read_text()
shim="""<script>
window.fetch=async (url, opt={})=>{let name=String(url);
 if(name.includes('/api/status'))return new Response(JSON.stringify({csrf_token:'mock',status:{running:false,source:'fixture',backend:'mock',buffered:30,colony_enabled:true,colony_buffered:30,frames:0,available_genomes:['prism']}}),{status:200});
 if(name.includes('/api/cluster/v24/run'))return new Response(JSON.stringify({source:{mode:'synthetic'},variant:JSON.parse(opt.body).variant,mode:'quality',node_kinds:['daughter','delta','daughter','delta'],event_counts:{motion:2},tasks_executed:22,full_task_count:28,elapsed_ms:12,guardrails:[]}),{status:200});
 return new Response('{}',{status:200});
};
</script>"""
html=html.replace('<script>',shim+'<script>',1)
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':390,'height':844});errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto('about:blank');page.set_content(html)
 page.locator('#upgradeVariant').select_option('mixed')
 page.locator('#upgradeRun').click()
 page.wait_for_function("document.querySelector('#upgradeResult').textContent.includes('mixed')",timeout=6000)
 assert 'daughter' in page.locator('#upgradeResult').inner_text()
 assert not errors,errors
 page.screenshot(path=str(R/'neuron_upgrade/results/mobile_controls_mock.png'),full_page=True)
 print(json.dumps({'passed':True,'variant_selector':True,'run_button':True,'mock_api_result':True,'source':'injected browser API, not live hardware','page_errors':errors}))
 browser.close()
