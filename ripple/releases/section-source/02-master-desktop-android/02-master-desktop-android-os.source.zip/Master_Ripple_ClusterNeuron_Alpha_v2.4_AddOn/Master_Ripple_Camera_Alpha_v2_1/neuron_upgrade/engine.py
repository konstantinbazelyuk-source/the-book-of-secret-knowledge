"""Master Ripple v2.4: comparative specialist neural cores, zero changes to v2.3 sources.

Actual OpenCV pixels go through inherited numerics. Signals *to neural models* are
synthetic normalized feature encodings, not laboratory light intensity measurements.
"""
from __future__ import annotations
import hashlib,json,math,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'src'),str(ROOT/'neuron_upgrade/parents/charlie')]
from cluster_neuron.engine import cheap_features,genome_overlay,select_work,CHEAP,NODES,run_original_cluster
from colony_lab.engine import TASKS,execute,evaluate_task_coverage,tasks_for_frames
from charlie_core.neuron import CharlieNeuron,CoreParameters

MODES=('original','delta','daughter','mixed','charlie')
def _check(samples,gains,coupling,eta):
    if not 3<=len(samples)<=240:raise ValueError('3..240 samples required')
    if len(gains)!=4 or any(not math.isfinite(v) or not .5<=v<=1.5 for v in gains):raise ValueError('gains invalid')
    if not 0<=coupling<=.2 or not 0<=eta<=.1 or not all(math.isfinite(x) for x in [coupling,eta]):raise ValueError('parameters out of bounds')
    old=None
    for s in samples:
        if len(s['features'])!=4 or any(not math.isfinite(v) or not 0<=v<=1 for v in s['features']):raise ValueError('bad features')
        t=s['t_ms']
        if not math.isfinite(t) or old is not None and not 1<=t-old<=200:raise ValueError('invalid time delta')
        old=t

def run_variant(samples,*,variant='mixed',gains=(1.,)*4,coupling=.08,eta=.03):
    if variant not in MODES:raise ValueError('unknown neuron variant')
    _check(samples,gains,coupling,eta)
    if variant=='original':return run_original_cluster(samples,gains=list(gains),coupling=coupling,eta=eta)
    if variant=='charlie':return _run_charlie(samples,gains,coupling,eta)
    p=subprocess.run(['node',str(ROOT/'neuron_upgrade/bridge.mjs')],cwd=ROOT,
        input=json.dumps({'samples':samples,'variant':variant,'gains':list(gains),'coupling':coupling,'eta':eta},allow_nan=False),
        capture_output=True,text=True,timeout=40)
    if p.returncode:raise RuntimeError('parent-neuron runtime: '+p.stderr[-900:])
    return json.loads(p.stdout)

def _run_charlie(samples,gains,coupling,eta):
    neurons=[CharlieNeuron(params=CoreParameters(recurrent_exc_pulse=coupling)) for _ in range(4)]
    base=[.26,.31,.24,.19];weights=base[:];prior=[0,0,0,0];observations=[];counts=[0]*4;old=None
    for i,s in enumerate(samples):
        if old is None:
            observations.append({'frame':i,'spikes':[0]*4,'rates_hz':[0]*4,'thresholds':[.45]*4,'score':0,'weights':weights[:],'inputs':[0]*4});old=s['t_ms'];continue
        dt=(s['t_ms']-old)/1000;spikes=[];rates=[];thresholds=[];inputs=[]
        for j in range(4):
            signal=max(0.,min(1.,s['features'][j]*gains[j]))
            # Uses Charlie's genuine inherited synaptic event pathway (one-step delayed).
            pulses=min(2,int(prior[(j+3)%4])+int(prior[(j+1)%4]))
            r=neurons[j].step([signal,0,0],dt,exc_pulses=pulses)
            inputs.append(signal);spikes.append(r['count']);rates.append(r['rate_hz']);thresholds.append(r['theta']);counts[j]+=r['count']
        target=[b*(.2+.8*f) for b,f in zip(base,s['features'])];z=sum(target);target=[v/z for v in target]
        edt=1-(1-eta)**(dt/(1/24))
        weights=[(1-edt)*a+edt*b for a,b in zip(weights,target)];z=sum(weights);weights=[v/z for v in weights]
        score=max(0,min(1,sum(f*w for f,w in zip(s['features'],weights))+.02*min(4,sum(spikes))))
        observations.append({'frame':i,'spikes':spikes,'rates_hz':rates,'thresholds':thresholds,'score':score,'weights':weights[:],'inputs':inputs})
        prior=[min(1,x) for x in spikes];old=s['t_ms']
    return {'variant':'charlie','neuron_kinds':['charlie']*4,'node_types':list(NODES),'spikes_per_node':counts,'observations':observations,
            'provenance':'unchanged Charlie v2.0; virtual feature-to-R input plus one-step delayed inherited excitatory conductance pulses'}

def run_upgrade(frames,fps,*,variant='mixed',mode='quality',genome='prism',workers=2,compare_full=True,include_trace=False):
    if variant not in MODES:raise ValueError('unknown variant')
    if mode not in ('quality','economy'):raise ValueError('unknown mode')
    t0=time.perf_counter();samples,cheap=cheap_features(frames,fps);g=genome_overlay(genome)
    neural=run_variant(samples,variant=variant,gains=g['gains'])
    work,audit,reasons=select_work(samples,neural['observations'],cheap,mode=mode)
    heavywork=[x for x in work if x[1] not in CHEAP]
    out=execute(frames,heavywork,workers=workers)
    observed=dict(cheap);observed.update(out['results'])
    reference=None
    if compare_full:
        full=execute(frames,[(i,k) for i in range(len(frames)) for k in TASKS],workers=1)
        hybrid_work,_=tasks_for_frames(frames,'hybrid')
        reference={'exhaustive_count':len(full['results']),'positive_coverage':evaluate_task_coverage(full['results'],observed),
                   'v2_2_hybrid_task_count':len(hybrid_work)}
    record={'schema':'ripple-neuron-upgrade/2.4','variant':variant,'mode':mode,'genome':g['name'],
       'source_type':'decoded_camera_frames_replay_or_unverified_live_explicitly_declared',
       'node_kinds':neural.get('neuron_kinds',['original']*4),'event_counts':dict(zip(NODES,neural['spikes_per_node'])),
       'final_attention_weights':dict(zip(NODES,neural['observations'][-1]['weights'])),
       'frame_count':len(frames),'tasks_executed':len(work),'full_task_count':len(frames)*len(TASKS),
       'heavy_task_count':len(heavywork),'dispatch_reasons':reasons,'elapsed_ms':round((time.perf_counter()-t0)*1000,3),
       'reference':reference,'guardrails':['quality always includes optical flow','focus and darkness every frame',
             'no actuator output','candidate neuron variants do not replace parent sources',
             'neuron R-only input is a software feature encoding, not literal optical color']}
    if include_trace:
        record['trace']=[{'frame':i,'spikes':n['spikes'],'weights':n['weights'],'score':n['score'],
                          'features':s['features'],'schedule':audit[i]} for i,(s,n) in enumerate(zip(samples,neural['observations']))]
    record['schedule_sha256']=hashlib.sha256(json.dumps(work,sort_keys=True).encode()).hexdigest()
    return record
