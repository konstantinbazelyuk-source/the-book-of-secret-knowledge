import json,socket,sys,threading,time,unittest,urllib.request,urllib.error
from pathlib import Path
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R),str(R/'src')]
from camera_bridge.server import build_server
from camera_bridge.core import CameraStation
from camera_tests.test_camera import FakeCapture
class HTTPUpgradeTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  s=socket.socket();s.bind(('127.0.0.1',0));port=s.getsockname()[1];s.close()
  cls.station=CameraStation(factory=lambda _:FakeCapture())
  cls.server=build_server(cls.station,port);cls.worker=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.worker.start()
  cls.base=f'http://127.0.0.1:{port}'
 @classmethod
 def tearDownClass(cls):
  cls.station.stop();cls.server.shutdown();cls.server.server_close();cls.worker.join(timeout=3)
 def call(self,kwargs,token=True):
  head={'Content-Type':'application/json','Origin':self.base}
  if token:head['X-Ripple-Token']=self.server.RequestHandlerClass.token
  try:
   req=urllib.request.Request(self.base+'/api/cluster/v24/run',json.dumps(kwargs).encode(),headers=head,method='POST')
   with urllib.request.urlopen(req,timeout=20) as r:return r.status,json.load(r)
  except urllib.error.HTTPError as e:return e.code,json.load(e)
 def test_01_no_token(self):self.assertEqual(self.call({'variant':'mixed'},False)[0],403)
 def test_02_no_opt_in(self):self.assertEqual(self.call({'variant':'mixed'})[0],409)
 def test_03_invalid_variant(self):self.assertEqual(self.call({'variant':'totally_new'})[0],400)
 def test_04_valid_node_process(self):
  self.station.set_colony(True);self.station.start()
  end=time.monotonic()+4
  while self.station.status()['colony_buffered']<12 and time.monotonic()<end:time.sleep(.08)
  status,result=self.call({'variant':'daughter','mode':'quality','genome':'prism'})
  self.assertEqual(status,200,result)
  self.assertEqual(result['variant'],'daughter');self.assertTrue(result['source']['opt_in_sampling']);self.station.stop()
if __name__=='__main__':unittest.main()
