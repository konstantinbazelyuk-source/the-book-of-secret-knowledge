/* Ripple ClusterNeuron Alpha v2.4. Imports UNCHANGED Delta and Daughter source.
   Input is a 4-dimensional camera-derived feature encoding, NOT optical RGB to the models.
   No external file/network writes; bounded, causal, no dynamic evaluation. */
import fs from 'node:fs';
import {createRequire} from 'node:module';
import {DeltaRippleNeuron} from './parents/daughter/vault/delta/delta-neuron.mjs';
import {DaughterTripletNeuron} from './parents/daughter/src/triplet-neuron.mjs';
const require=createRequire(import.meta.url);
require('../legacy/ripple-core.js');
const clip=(v,l=0,h=1)=>Math.max(l,Math.min(v,h));
const TYPES=['chromatic','motion','focus','shadow'];
const OPTIONS={
 delta:{feedforward:false},
 mixed:{feedforward:false}
};
function run(p){
 if(!['delta','daughter','mixed'].includes(p.variant))throw new Error('Unknown neuron variant');
 if(!Array.isArray(p.samples)||p.samples.length<3||p.samples.length>240)throw Error('samples 3..240');
 if(!Array.isArray(p.gains)||p.gains.length!==4||p.gains.some(x=>!Number.isFinite(x)||x<.5||x>1.5))throw Error('invalid gains');
 const coupling=p.coupling??.08, eta=p.eta??.03;
 if(!Number.isFinite(coupling)||coupling<0||coupling>.2||!Number.isFinite(eta)||eta<0||eta>.1)throw Error('invalid coupling/eta');
 const kinds=p.variant==='mixed'?['daughter','delta','daughter','delta']:Array(4).fill(p.variant);
 const neurons=kinds.map(k=>k==='delta'?new DeltaRippleNeuron({feedforward:false}):new DaughterTripletNeuron());
 const prior=[0,0,0,0],base=[.26,.31,.24,.19],counts=[0,0,0,0];let weights=base.slice(), old=null;
 let observations=[];
 for(let i=0;i<p.samples.length;i++){
  const sample=p.samples[i];
  if(!sample||!Array.isArray(sample.features)||sample.features.length!==4||sample.features.some(v=>!Number.isFinite(v)||v<0||v>1)||!Number.isFinite(sample.t_ms))throw Error('invalid input');
  if(old!==null&&(sample.t_ms<=old||sample.t_ms-old<1||sample.t_ms-old>200))throw Error('timestamps outside limits');
  if(old===null){observations.push({frame:i,spikes:[0,0,0,0],rates_hz:[0,0,0,0],thresholds:[.45,.45,.45,.45],score:0,weights:weights.slice(),inputs:[0,0,0,0]});old=sample.t_ms;continue;}
  const dt=(sample.t_ms-old)/1000;
  let spikes=[],rates=[],thresholds=[],inputs=[];
  for(let j=0;j<4;j++){
   const delayed=(prior[(j+3)%4]+prior[(j+1)%4])/2;
   const v=clip(sample.features[j]*p.gains[j]+coupling*delayed);
   // All models receive identical virtual [feature,0,0] encoding, with distinct dynamics.
   const resp=neurons[j].step([v,0,0],dt);
   inputs.push(v);spikes.push(resp.count);rates.push(resp.rate);thresholds.push(resp.theta);
   counts[j]+=resp.count;
  }
  const attention=base.map((b,j)=>b*(.2+.8*sample.features[j]));
  const den=attention.reduce((a,b)=>a+b,0);
  const target=attention.map(v=>v/den);
  const etaDt=1-Math.pow(1-eta,dt/(1/24));
  weights=weights.map((v,j)=>(1-etaDt)*v+etaDt*target[j]);
  const wsum=weights.reduce((a,b)=>a+b,0);weights=weights.map(v=>v/wsum);
  const score=clip(sample.features.reduce((a,v,j)=>a+v*weights[j],0)+.02*Math.min(4,spikes.reduce((a,b)=>a+b,0)));
  observations.push({frame:i,spikes,rates_hz:rates,thresholds,score,weights:weights.slice(),inputs});
  for(let j=0;j<4;j++)prior[j]=Math.min(1,spikes[j]);
  old=sample.t_ms;
 }
 return {variant:p.variant,node_types:TYPES,neuron_kinds:kinds,spikes_per_node:counts,observations,
  provenance:'inherited source untouched; abstract camera-feature-to-R virtual encoding'};
}
try{process.stdout.write(JSON.stringify(run(JSON.parse(fs.readFileSync(0,'utf8'))))+'\n');}
catch(e){process.stderr.write(String(e.stack)+'\n');process.exitCode=1;}
