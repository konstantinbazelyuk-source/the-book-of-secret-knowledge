# Ripple Neuron — Samsung Android edition v0.3.0

**Built from the actual original Ripple Neuron v0.1 simulator (2026-10-13), not from a generic replacement neuron.**

Port target: Samsung Android phone; the current chat's device identifier is `SM-A176U`, associated with the Galaxy A17 5G. This program uses standards available in Android Chromium-based browsers. No phone was attached to the development/test machine, so native hardware validation is still outstanding.

## Start on your Samsung now

### Offline manual mode

Copy `Ripple-Samsung-Open-Offline.html` to your phone. Open it with **Chrome** or another browser that can run local HTML/JavaScript. Manual RGB drive, threshold regulation, event visualization, and the 120-second numerical experiment run without a server. Some phone file managers preview HTML as text or block scripts, and camera/local IndexedDB features may be restricted on `file://` URLs.

### Full camera + installable version

1. Extract the ZIP and deploy `index.html`, `manifest.webmanifest`, `sw.js`, `icon-192.png`, `icon-512.png`, `icon.svg`, and `ripple-core.js` **together** to an HTTPS static web host (for example, GitHub Pages or Netlify). No server-side code or API account is needed.
2. Open the HTTPS app URL using Chrome on the Samsung. Choose **Phone camera → Start camera → Allow**.
3. The central camera sampling target measures real RGB pixel values (not spectral channels). Change the colored target and watch input/drive, rate, threshold, and event count respond.
4. Choose Chrome menu **Install app** or **Add to Home screen**, when offered. Once first loaded over HTTPS, the service worker makes the app shell available offline. The camera still requires permissions and an active foreground page.
5. Use **Save session** to store the numerical model state, measurements and settings locally in IndexedDB. **Restore** loads it paused with manual input; the camera never restarts without a new tap. **Export CSV** creates a portable numeric measurement log.

This version has not been publicly deployed and is not an Android APK. An installable PWA is still a real executable app on supported Android browsers; it is not an Android native background service.

## Migration map

| Original Raspberry Pi / Pico path | Samsung Android port |
|---|---|
| Raspberry Pi Pico microcontroller | Android browser JavaScript engine on phone CPU |
| AS7341 eight-band light sensor | Rear-camera region-of-interest RGB pixel averages (three processed channels) |
| Calibrated physical RGB emitter | Manual RGB sliders or an external colored visual target |
| Pico onboard LED for neural event | UI pulse indicator; optional vibration when supported |
| USB serial output | On-screen metrics, numeric CSV export and optional local saved session |
| Threshold adaptation and LIF core | **Exactly preserved from original model source** |

## Original mathematical core

- Drive: `D = 2R + 1.2G - 1.4B`; inputs normalized to [0,1].
- Leaky state: `0.5 * du/dt = -u + D` using original exact exponential integration.
- Threshold crossing events with reset `u = 0`, refractory interval `0.1 s`.
- Rate time constant `5 s`, threshold adaptation gain `0.08`, target `1 Hz` default.
- Threshold constrained `[0.15,2.5]`.
- Source copied byte-for-byte into the `ripple-core.js` model body and into `index.html`, with provenance recorded in `SOURCE_PROVENANCE.json`.

The port **does not** change any of these mathematical model implementation lines. Camera sample cadence only changes how frequently new RGB frames are read; model stepping remains 20 Hz while active.

## Real operational features

- Real three-channel camera pixel extraction through Android's camera permission API in Chrome secure context.
- Manual normalized RGB input (works offline), camera-frame calibration with four references and matrix quality checks.
- Original numerical experiment and editable feedback target.
- Adaptive or fixed threshold, live rate/state plots, event indicator, vibration when browser supports it.
- 5, 10, ~15 frame-per-second camera sampling options for battery/performance tradeoffs.
- Local session save, restore, delete (IndexedDB; requires a browser context that enables it), 30-second periodic autosave while the app stays active, CSV export.
- Background visibility stops camera capture and prevents advancing the neuron model; return does not automatically reactivate capture.
- PWA shell cached for offline use after installing/loading over HTTPS; no external libraries, credentials or outbound APIs.

## Test log and limitations

**Verified in development environment**

- `node tests/test_core.cjs`: passes core byte match, experiment count 2400 steps, inhibitory blue, threshold bound, fixed vs adaptive, invalid dt rejection.
- Numerical original comparison in 60–80 s bright window: adaptive 0.95 events/s; fixed threshold 3.40 events/s. These are **simulated numeric** results.
- `python tests/test_browser.py`: passes HTML loading into Chromium's in-memory document, time evolution, pause, reset, experiment UI, sampling control, no JS exceptions; narrow 390 px viewport has no horizontal overflow.
- `python tests/test_synthetic_camera.py`: passes browser media stream driven by an artificial 180/25/10 RGB test canvas, feeding normalized camera-input values and allowing the original neuron to step; safe camera stop.

**Not yet verified**

- No physical Samsung camera, power consumption, temperature, accurate spectral calibration, or camera performance measurement performed.
- Android PWA install and offline cache and IndexedDB persistence not end-to-end tested in the development browser because browser navigation to local test URLs was blocked by the test environment. Code paths are implemented and need actual HTTPS and device testing.
- Three camera color channels are processed RGB pixels, not a replacement for the AS7341's eight independent spectral bands or a measurement of light electric/magnetic fields.
- Neural model events are algorithmic state transitions driven by measured/synthetic input. They are not evidence of biological neurons or general intelligence.

## Files

- `Ripple-Samsung-Open-Offline.html`: **single-file manual-first app**, best direct first test on Samsung.
- `index.html`: PWA app, identical main code (with offline caching assets via HTTPS).
- `manifest.webmanifest`, `sw.js`, `icon.svg`, `icon-*.png`: installable app shell.
- `ripple-core.js`: explicitly separated unchanged original neuron core for audit/reuse.
- `original-simulator.html`: preserved original source for comparison.
- `SOURCE_PROVENANCE.json`: original simulator and model block checksums.
- `tests/`: runnable verification scripts, synthetic browser camera test and development preview screenshot.

## License and continuity

Original Ripple Neuron v0.1 was released CC0-1.0. The original math and control algorithm remain the authoritative locked kernel; v0.3 adds only phone runtime, state storage, UI and installability. The other Ripple/Charlie/Delta/Daughter research branches are intentionally not merged into this **original Ripple** device port.
