#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
node tests/test_core.cjs
python tests/test_browser.py
python tests/test_synthetic_camera.py
