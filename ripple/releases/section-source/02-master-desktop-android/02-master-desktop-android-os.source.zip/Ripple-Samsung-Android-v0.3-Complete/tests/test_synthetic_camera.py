"""Browser camera bridge with synthetic canvas stream (not phone hardware)."""
from pathlib import Path
from playwright.sync_api import sync_playwright
html=Path(__file__).resolve().parent.parent.joinpath('index.html').read_text()
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--autoplay-policy=no-user-gesture-required'])
 page=browser.new_page(viewport={'width':390,'height':844});errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content(html)
 page.evaluate('''() => {
   const canvas=document.createElement('canvas');canvas.width=canvas.height=120;
   const ctx=canvas.getContext('2d');ctx.fillStyle='rgb(180,25,10)';ctx.fillRect(0,0,120,120);
   const stream=canvas.captureStream(10);
   Object.defineProperty(navigator,'mediaDevices',{configurable:true,value:{getUserMedia:async()=>stream}});
 }''')
 page.locator('#camera-mode').click();page.locator('#start-camera').click();page.wait_for_timeout(1400)
 assert 'Camera active' in page.locator('#camera-status').inner_text()
 data=page.evaluate('({valid:app.valid,camX:app.camX,total:app.total,t:app.model.t})')
 assert data['valid'] is True and data['t']>0
 for received,raw in zip(data['camX'],[180,25,10]):assert abs(received-raw/255)<.02
 page.locator('#stop-camera').click(); assert not page.evaluate('app.stream')
 assert not errors,errors
 print('SYNTHETIC CAMERA PASS: video RGB -> normalized 3-channel input -> original model steps -> safe stop.')
 browser.close()
