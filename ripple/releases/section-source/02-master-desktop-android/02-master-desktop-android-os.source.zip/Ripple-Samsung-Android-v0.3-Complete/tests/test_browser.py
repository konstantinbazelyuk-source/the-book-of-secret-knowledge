from playwright.sync_api import sync_playwright
from pathlib import Path
html=Path('/mnt/data/ripple_samsung_v03/index.html').read_text()
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--use-fake-ui-for-media-stream','--use-fake-device-for-media-stream'])
 context=browser.new_context(viewport={'width':390,'height':844},device_scale_factor=2)
 page=context.new_page(); errors=[]
 page.on('pageerror',lambda e: errors.append(str(e)))
 # Navigation is blocked by this testing environment; rendering an in-memory document is available.
 page.set_content(html,wait_until='load')
 print('title:',page.title(),'device:',page.locator('#device-status').inner_text())
 assert 'SAMSUNG / v0.3' in page.locator('header').inner_text()
 page.wait_for_timeout(700)
 assert float(page.locator('#elapsed').inner_text().split()[0])>0
 page.locator('#pause').click();before=page.evaluate('app.model.t');page.wait_for_timeout(350);assert page.evaluate('app.model.t')==before
 page.locator('#reset').click();assert page.locator('#events').inner_text()=='0'
 page.locator('[data-view="experiment"]').click()
 page.locator('#run-experiment').click()
 assert page.locator('#experiment-csv').is_enabled()
 page.locator('[data-view="live"]').click()
 page.locator('#sample-rate').select_option('200'); assert page.locator('#sample-rate').input_value()=='200'
 page.screenshot(path='/mnt/data/ripple_samsung_v03/tests/samsung-preview.png',full_page=True)
 assert not errors,errors
 print('BROWSER PASS: layout, time evolution, pause, reset, original experiment, sampling control, zero JS exceptions')
 print('document size',page.evaluate('({w:document.documentElement.scrollWidth,inner:window.innerWidth})'))
 browser.close()
