# Master Ripple — complete inspected capability map

**Evidence rule:** only running code is labeled integrated. The user's archived modules are not silently assumed to be electrically, physically or architecturally compatible with one another. This audit covers the 12 recovered distributable archives and the v1.1–1.3 Alpha source directory, **not every Ripple idea ever discussed**.

| Source / capability | Master status | Concrete behavior and boundary |
|---|---|---|
| Ripple v0.1 original leaky-integrate-and-fire | **Integrated/executed** | Original JS class and frozen reference unchanged; identical-input 400-step Python parity test. |
| Ripple photoreceptor v0.6 | **Integrated/executed** | Original log/transient preprocessing in separate weighted path, raw neuron still separately calculated. |
| Ripple-Q v0.7 | **Integrated/executed** | Original 4-symbol encoder, bounded program VM and temporal frequency analyzer. Missing sensors throw unavailable. |
| Ripple digital genes / v1.2 HybridLineage | **Inherited/executed** | Four original + five earlier selected hybrids; 9 SHA-256-marked external Master weight profiles; finite, inactive candidate generation. |
| Ripple Alpha v1.0 diffusion and occlusion | **Available via explicitly requested legacy regression** | Executes preserved `run_one`, with no new monochrome research. Synthetic, no physical diffusion claim. |
| Ripple Alpha density | **Available via legacy regression** | Normalized synthetic density modulation. Not actual mass/atomic density. |
| Ripple Mycelium v0.3 and Digital Evolution v0.5 | **Adapted concept and archive** | Bounded colony, event-based routing and budget. Original advanced graph search/specialist experiments preserved, not claimed integrated in their full original implementations. |
| FieldSphere eight-vector magnetic data | **Integrated schema/read-only replay** | µT stays µT, no compass-to-pixel conversion; hardware absent. Full CAD and original host code preserved separately. |
| Optional browser phone magnetometer / light / accelerometer | **Implemented acquisition pathway, mock-tested** | Only when browser exposes APIs and user permission allows it; real mobile hardware unverified. |
| Sensor Bridge v0.2 optical/scanner | **Original archived** | Prior image comparison, flow and virtual drone fixtures retained. This release does not operate a scanner. |
| SpiderScan Ground v0.5 and Colony v0.6 | **2D range mapping adapted; originals archived** | Bounded log-odds ray occupancy map. Original mobility/physical ToF/servo and radio hardware not integrated or tested. |
| Ripple Spectrum v0.1 | **Archived original** | Optical modulation & magnetic synthetic maps. Not a working measured EM-carrier sensor in Master. |
| Ripple Heterodyne v0.1 | **Archived original** | Manufacturable CAD and synthetic optical beat experiments only; no physical coherent laser beat recorded. |
| Kokoro/Lumina/Ripple v0.4 | **Archived optional sibling** | An external avatar/image renderer. Not activated as AI or motor actuator in Master. |
| Physical FieldSphere / mobile body / 3D game engine | **Proposed hardware/visual ports** | Design files are preserved, no build or device test; geometry not inferred from an uncalibrated magnetic array. |
| Sensor-triggered JS code changes | **Quarantined by design** | Only frozen, pre-audited module functions run. No remote JS execution, eval, host command access, or unrestricted mutation. |

## New sensor inputs and gate rules

Every input is a typed, unit-bearing record with monotonically increasing time per channel, declared source class and validated data shape. A source stating `hardware_reported_unverified` is not a certified measurement. No implicit hardware enablement. Failure is explicit, not synthetic substitution. The physically heterogeneous sources contribute only dimensionless bounded *dispatch priority*, with auditable hand-chosen per-unit change thresholds. Do not interpret this as estimating a latent universal field.

## Color genome meaning

Hex color is a label. The actual inheritance consists of bounded `optical_gain`, `sensory_weights`, `diffusion_gain`, `occlusion_gain`, `density_gain` and `worker_limit`, plus parent marker. The Master profile does **not** claim these parameters are synaptic learned weights, physical DNA, or an evolved species. New child weights are mathematically generated configurations and remain **inactive** without independent comparison.
