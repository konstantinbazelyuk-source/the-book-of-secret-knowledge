# From software Alpha to a physically validated measurement

1. **Camera baseline**: acquire on a stationary phone under controlled illumination with exposure/white balance fixed when feasible; export local JSONL and repeat 5 trials per condition. Validate that frame timing meets the original neuron dt ≤ .5 s. Compare to a calibrated reference photodiode if claiming irradiance, otherwise report normalized RGB only.
2. **Magnetic array**: collect real 8×3 µT FieldSphere readings with timestamp, per-sensor board ID, calibrated orientation, bias and soft-iron correction, and field-strength calibration standards. Determine uncertainty and drift. Uncalibrated sensor magnitude cannot reveal an unknown 3D interior field uniquely.
3. **Temporal frequency**: regular sampling, Nyquist and anti-alias filters must match the intended bandwidth. Ripple-Q estimates fluctuations of recorded scalar values, never visible-light carrier oscillation.
4. **Range map**: supply a genuinely measured range and separately validated sensor pose to a known reference object. A behind-object cell must remain unknown; review map error against ground truth before any navigation claim.
5. **Optical heterodyne**: first demonstrate a known calibrated mirror velocity with a coherent reference beam and stable detection, with optical safety controls. No direct light-magnetic-field measurement is implied.
6. **Mutation and integrated behavior**: compare fixed profiles versus proposed child on predeclared train/test conditions and independent replay; do not publish superiority claims from a single favorable synthetic run. Independent measurement changes may be statistically significant without being intelligent.

This release does not take these actions, and is not connected to actual hardware here.
