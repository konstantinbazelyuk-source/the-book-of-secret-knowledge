# Research basis and critical distinctions

These are **actual published sources**, not citations fabricated for this release. They support known methods; they do not independently validate this Master Ripple implementation.

1. **Leaky integrate-and-fire membrane model.** Paninski et al., *Spike Train Probability Models for Stimulus-Driven Leaky Integrate-and-Fire Neurons*, equations in Methods §2.1: https://pmc.ncbi.nlm.nih.gov/articles/PMC2715549/ . The equations justify a basic neuron model, not human consciousness.
2. **Numerical diffusion and explicit stability.** Langtangen & Linge, *Finite Difference Computing with PDEs*, Diffusion Equations, DOI 10.1007/978-3-319-55456-3_3: https://link.springer.com/chapter/10.1007/978-3-319-55456-3_3 . Master preserves earlier bounded finite-volume simulation, not a claim about real physical diffusion coefficients.
3. **Occupancy grid mapping.** Alberto Elfes (1989), *Using Occupancy Grids for Mobile Robot Perception and Navigation*, IEEE Computer, DOI 10.1109/2.30720: https://ieeexplore.ieee.org/document/30720/ . The new range-ray mapper is a simpler bounded illustrative log-odds approach, not a full verified localization/SLAM system.
4. **Multiobjective genetic search.** Kalyanmoy Deb, Amrit Pratap, Sameer Agarwal, T. Meyarivan (2002), *A Fast and Elitist Multiobjective Genetic Algorithm: NSGA-II*, IEEE Trans. Evolutionary Computation, DOI 10.1109/4235.996017: https://doi.org/10.1109/4235.996017 . Earlier Alpha Pareto-inspired selection is distinct from this exact published algorithm; Master **inherits earlier selected candidates**, does not assert an NSGA-II reimplementation.
5. **NIST metrological traceability.** https://www.nist.gov/calibrations/traceability . An unbroken calibration chain and uncertainty documentation are needed for traceable real measurements; self-reported sensor data do not meet that requirement.
6. **NIST characterization/uncertainty.** Ehrlich, *Traceability Considerations for the Characterization and Use of Measuring Systems*: https://www.nist.gov/publications/traceability-considerations-characterization-and-use-measuring-systems-0 .
7. **Magnetic sensor hardware capability.** STMicroelectronics LIS2MDL current-product data: https://www.st.com/en/mems-and-sensors/lis2mdl.html . A datasheet is not hardware verification of a constructed FieldSphere or of its calibration.
8. **Sampling/Nyquist distinction.** NIST archival publication references the Nyquist criterion: https://nvlpubs.nist.gov/nistpubs/jres/095/4/V95-4.pdf . Ripple-Q temporal sampled-wave estimates do not represent optical electromagnetic carrier oscillations.

## Trace categories

- **Measured software execution:** 44/44 tests, 27/27 legacy Alpha tests, 11/11 original Ripple-Q tests, hash comparisons, headless mocked UI behavior.
- **Calculated from modeled data:** event frequency, sensor magnitude summaries, SHA-256 markers, inverse occupancy log-odds grid, selected candidate mutations.
- **Simulated:** colors, digital-genome physical analogies, spatial/density fields, synthetic RGB/magnetic/motion/lux fixtures, particle/diffusion dynamics.
- **Hardware-reported but unverified:** anything sent by a browser camera/magnetometer or user JSONL without independent calibration and known sensor metadata.
- **Proposed:** calibrated multi-magnetometer geometry, real interferometry modules, live robot actuation, optical-carrier field inference, general intelligence improvements.
