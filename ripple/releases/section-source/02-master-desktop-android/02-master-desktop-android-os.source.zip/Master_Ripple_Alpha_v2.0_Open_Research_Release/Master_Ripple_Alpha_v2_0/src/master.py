"""Master Ripple Alpha v2.0: verified, bounded orchestrator of legacy components.
No autonomous intelligence, no hardware control, no physical calibration claims.
"""
from __future__ import annotations
import hashlib, json, math, subprocess, sys
from collections import deque
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any
import numpy as np
from occupancy import OccupancyGrid
from verify_sources import verify_sources
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'legacy'))
from ripple_alpha import SPECIES, Conditions, run_one, LegacyRippleNeuron
from tracegate import analyze_magnetic, analyze_optical

SCHEMA='ripple-master/2.0'
MAX_EVENTS=4096
SOURCE_TYPES={'simulated','hardware_reported_unverified'}
SENSOR_UNITS={'optical_rgb':'normalized_rgb_roi','magnetometer':'microtesla','accelerometer':'m/s2','ambient_light':'lux','magnetometer_xyz':'microtesla','range_ray':'meters_and_radians'}

def sha(obj):
    return hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

def finite_num(x):
    return isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x)

def clamp(x,low,high):return max(low,min(high,x))

@dataclass(frozen=True)
class WeightGenome:
    """External feature/routing weights. Never alter locked LIF numerical parameters."""
    name:str
    parent:str|None
    color:str
    optical_gain:tuple[float,float,float]
    sensory_weights:tuple[float,float,float,float] # optical / magnetic / motion / lux
    diffusion_gain:float
    occlusion_gain:float
    density_gain:float
    worker_limit:int=4
    routing:str='roundrobin'
    def __post_init__(self):
        if not self.name or len(self.name)>80:raise ValueError('bad name')
        if len(self.color)!=7 or not self.color.startswith('#') or any(x not in '0123456789abcdefABCDEF' for x in self.color[1:]):raise ValueError('bad color')
        if len(self.optical_gain)!=3 or any(not finite_num(v) or not .35<=v<=1.5 for v in self.optical_gain):raise ValueError('optical gain bound')
        if len(self.sensory_weights)!=4 or any(not finite_num(v) or not 0<=v<=1 for v in self.sensory_weights) or abs(sum(self.sensory_weights)-1)>1e-8:raise ValueError('weights must sum to one')
        if any(not finite_num(v) or not 0<=v<=1 for v in (self.diffusion_gain,self.occlusion_gain,self.density_gain)):raise ValueError('overlay bounds')
        if not 1<=self.worker_limit<=8 or self.routing not in {'roundrobin','leastload'}:raise ValueError('routing / worker budget')
    def marker(self):
        return sha({'schema':'ripple-master-weights/1',**self.__dict__})


def inherited_genomes()->dict[str,WeightGenome]:
    """Mechanical translation of archived five selected hybrid species; no newly optimized fitness."""
    r=json.loads((ROOT/'legacy'/'hybridlineage.json').read_text())
    weights=(.55,.25,.13,.07)
    registry={}
    for entry in r['selected']:
        s=entry['species'];color=s['color'];base=tuple(map(float,s['rgb_gain']))
        item=WeightGenome(name=s['name'],parent=entry['marker'],color=color,
            optical_gain=base,sensory_weights=weights,
            diffusion_gain=float(clamp(s['diffusion_gain']/.28,0,1)),
            occlusion_gain=float(clamp(s['occlusion_gain']/1.6,0,1)),
            density_gain=.5,worker_limit=4)
        registry[item.name]=item
    for species in SPECIES:
        registry[species.name]=WeightGenome(name=species.name,parent=species.marker(),color=species.color,optical_gain=species.rgb_gain,
            sensory_weights=weights,diffusion_gain=clamp(species.diffusion_gain/.28,0,1),
            occlusion_gain=clamp(species.occlusion_gain/1.6,0,1),density_gain=.5)
    return registry


def propose_weight_child(parent:WeightGenome,frames:list[dict])->dict:
    """Sensor-triggered, capped DIGITAL weight *candidate* only.
    Never autoreleases, executes code, changes photonics, or edits original neuron.
    """
    gate=GuardedStream();valid=[gate.accept(f) for f in frames]
    optical=[x for x in valid if x['kind']=='optical_rgb']
    mags=[x for x in valid if x['kind'] in ('magnetometer','magnetometer_xyz')]
    if len(optical)<24 and len(mags)<24:raise ValueError('not enough verified-format data for a proposal')
    if len(optical)>=24:
        a=np.asarray([x['values'] for x in optical],float)
        target=int(np.argmax(np.std(a,axis=0)))
        gains=list(parent.optical_gain)
        gains[target]=round(float(clamp(gains[target]+.02,.35,1.5)),6)
        child=replace(parent,name=parent.name+'-rgb-child',parent=parent.marker(),optical_gain=tuple(gains))
        decision={'gene':'optical_gain','channel':target,'delta_proposed':round(gains[target]-parent.optical_gain[target],6)}
    else:
        arr=np.asarray(parent.sensory_weights,float)
        delta=min(.02,arr[0]);arr[0]-=delta;arr[1]+=delta
        child=replace(parent,name=parent.name+'-mag-child',parent=parent.marker(),sensory_weights=tuple(float(v) for v in arr))
        decision={'gene':'sensory_weights','delta_from_optical_to_magnetic':float(delta)}
    return {'classification':'candidate_not_activated','parent_marker':parent.marker(),
            'child_marker':child.marker(),'decision':decision,'child':child.__dict__,
            'evidence':'finite sensor data channel selection, not independent performance improvement',
            'source_status':sorted(set(x['source'] for x in valid)),
            'guardrails':['delta <= .02','no mutation of original LIF equations','no automatic activation','no code execution']}


class GuardedStream:
    """Strict per-kind data validation. The word 'hardware' is self-reported, NOT evidence."""
    def __init__(self):self.last={};self.mode={};self.count=0
    def accept(self,rec:dict)->dict:
        if self.count>=MAX_EVENTS:raise ValueError('frame budget')
        if not isinstance(rec,dict) or rec.get('schema')!=SCHEMA:raise ValueError('frame schema')
        kind=rec.get('kind'); provenance=rec.get('source');ts=rec.get('t_ms');values=rec.get('values')
        if kind not in SENSOR_UNITS or provenance not in SOURCE_TYPES:raise ValueError('unknown sensor or source')
        if rec.get('unit')!=SENSOR_UNITS[kind]:raise ValueError('sensor unit mismatch')
        if not finite_num(ts) or ts<0 or (kind in self.last and ts<=self.last[kind]):raise ValueError('timestamp ordering')
        if kind in self.mode and provenance!=self.mode[kind]:raise ValueError('mixed reported hardware and simulated data')
        if kind=='optical_rgb':
            if not isinstance(values,list) or len(values)!=3 or any(not finite_num(x) or not 0<=x<=1 for x in values):raise ValueError('invalid RGB')
            values=[float(v) for v in values]
        elif kind=='magnetometer_xyz':
            a=np.asarray(values,dtype=float)
            if a.shape!=(3,) or not np.isfinite(a).all() or np.max(np.abs(a))>5000:raise ValueError('invalid xyz µT')
            values=a.tolist()
        elif kind=='range_ray':
            if not isinstance(values,dict) or set(values)!={'x_m','y_m','angle_rad','range_m','max_range_m'}:raise ValueError('range schema')
            if any(not finite_num(v) for v in values.values()):raise ValueError('nonfinite range data')
            # Validate with the same bounded physical ray model, without mutating real state.
            OccupancyGrid().ray(**values)
        elif kind=='magnetometer':
            a=np.asarray(values,dtype=float)
            if a.shape!=(8,3) or not np.isfinite(a).all() or np.max(np.abs(a))>5000:raise ValueError('invalid magnetic 8x3 µT')
            values=a.tolist()
        else:
            if not finite_num(values) or (kind=='ambient_light' and values<0) or abs(values)>1e7:raise ValueError('invalid scalar')
            values=float(values)
        self.last[kind]=float(ts);self.mode[kind]=provenance;self.count+=1
        return {'schema':SCHEMA,'kind':kind,'source':provenance,'t_ms':float(ts),'unit':rec['unit'],'values':values}

def read_frames(path:Path):
    if path.stat().st_size>6_000_000:raise ValueError('input file too large')
    g=GuardedStream();out=[]
    for line in path.read_text().splitlines():
        if not line.strip():continue
        out.append(g.accept(json.loads(line)))
    if not out:raise ValueError('empty stream')
    return out

class BoundedColony:
    def __init__(self,genome:WeightGenome):
        self.genome=genome;self.workers=[{'id':f'ripple-{i:02d}','processed':0} for i in range(genome.worker_limit)];self.queue=deque(maxlen=1024);self.cursor=0;self.history=[]
    def submit(self,task):
        if len(self.queue)>=1024:raise ValueError('colony queue capacity')
        self.queue.append(task)
    def work(self,limit=1):
        if not 0<=limit<=64:raise ValueError('dispatch budget')
        events=[]
        for _ in range(min(limit,len(self.queue))):
            if self.genome.routing=='roundrobin':idx=self.cursor%len(self.workers);self.cursor+=1
            else:idx=min(range(len(self.workers)),key=lambda i:(self.workers[i]['processed'],i))
            task=self.queue.popleft();self.workers[idx]['processed']+=1
            # Audit metadata, not external execution. No code or actuators in tasks.
            events.append({'worker':self.workers[idx]['id'],'task':task['kind'],'seq':task['seq']})
        self.history.extend(events)
        return events

class AdaptiveSensoryWeights:
    """Bounded EWMA of data-quality scores, not learning physical laws or intelligence."""
    KINDS=['optical_rgb','magnetometer','accelerometer','ambient_light']
    def __init__(self,genome):self.base=np.asarray(genome.sensory_weights,float);self.weights=self.base.copy();self.history=[]
    def step(self,avail:dict,quality:dict,eta=.035):
        if not 0<=eta<=.1:raise ValueError('learning rate')
        vals=np.asarray([max(0.,min(1.,quality.get(k,0.))) if avail.get(k,False) else 0. for k in self.KINDS],float)
        if np.any(vals):
            target=self.base*vals;target=target/target.sum()
            self.weights=(1-eta)*self.weights+eta*target
            self.weights=np.maximum(self.weights,0.);self.weights/=self.weights.sum()
        self.history.append([float(v) for v in self.weights]);return dict(zip(self.KINDS,self.weights.tolist()))


def js_optical(frames:list[dict],use_photoreceptor:bool=True,gains=(1.,1.,1.)):
    """Execute preserved JS source with exact local fixed runner; never evaluate incoming code."""
    payload={'frames':[{'rgb':r['values'],'t_ms':r['t_ms']} for r in frames], 'photoreceptor':use_photoreceptor, 'gains':list(gains)}
    p=subprocess.run(['node',str(ROOT/'src'/'js_signal_runner.cjs')],input=json.dumps(payload),text=True,capture_output=True,timeout=30)
    if p.returncode:raise RuntimeError(p.stderr[-2500:])
    return json.loads(p.stdout)


def temporal_frequency(samples,timestamps):
    """Reuse the actual v0.7 time-sampled DFT; it is NOT a light carrier measurement."""
    if len(samples)<24:return {'valid':False,'reason':'under 24 samples'}
    p=subprocess.run(['node',str(ROOT/'src'/'frequency_runner.mjs')],input=json.dumps({'samples':samples,'timestamps':timestamps}),text=True,capture_output=True,timeout=20)
    if p.returncode:raise RuntimeError(p.stderr[-1200:])
    return json.loads(p.stdout)


def analyze_master(frames,genome:WeightGenome,photoreceptor=True)->dict:
    gate=GuardedStream();validated=[gate.accept(f) for f in frames]
    optical=[x for x in validated if x['kind']=='optical_rgb']
    magnetic=[x for x in validated if x['kind']=='magnetometer']
    motion=[x for x in validated if x['kind']=='accelerometer']
    lux=[x for x in validated if x['kind']=='ambient_light']
    magxyz=[x for x in validated if x['kind']=='magnetometer_xyz']
    rays=[x for x in validated if x['kind']=='range_ray']
    js=js_optical(optical,photoreceptor,genome.optical_gain) if optical else None
    # The master never maps µT to RGB and never invents unavailable senses.
    mag={'available':bool(magnetic),'unit':'microtesla','coordinate_frame':'uncalibrated_sensor_local_axes',
       'field_reconstruction':'not_performed','quality':'not_physically_calibrated'}
    if magnetic:
        arr=np.asarray([m['values'] for m in magnetic],float)
        mag['mean_magnitude_per_sensor_uT']=np.linalg.norm(arr,axis=2).mean(axis=0).tolist()
        mag['time_samples']=len(arr)
        mag['max_sensor_value_uT']=float(np.max(np.abs(arr)))
        mag['temporal_modulation']=temporal_frequency(np.linalg.norm(arr[:,0,:],axis=1).tolist(),[r['t_ms'] for r in magnetic])
    grid=OccupancyGrid()
    for sample in rays:grid.ray(**sample['values'])
    colony=BoundedColony(genome)
    controller=AdaptiveSensoryWeights(genome)
    # Structural quality = timing/data validity only, NOT a hardware reliability certificate.
    def structural_quality(seq):
        if not seq:return 0.
        if len(seq)<2:return .7
        ints=np.diff([s['t_ms'] for s in seq]);cv=float(np.std(ints)/np.mean(ints))
        return float(clamp(1-cv,0,1))
    quality={'optical_rgb':structural_quality(optical),'magnetometer':structural_quality(magnetic),
             'accelerometer':structural_quality(motion),'ambient_light':structural_quality(lux)}
    quality['magnetometer']=max(quality['magnetometer'],structural_quality(magxyz))
    # Each physical channel creates events IN ITS OWN UNITS before a dimensionless
    # engineering dispatch score is calculated. Do not fuse µT with RGB/lux.
    event_candidates=[]
    if js:
        for i,e in enumerate(js['steps']):
            if e['spikes_weighted']>0:event_candidates.append({'kind':'weighted_optical_spike','seq':i,'score':.9*float(genome.sensory_weights[0])})
            if e['symbol_code'] in (0,3):event_candidates.append({'kind':'quaternary_transition','seq':i,'score':.6*float(genome.sensory_weights[0])})
    def derived_changes(seq,index,extract,threshold,label):
        prev=None
        for i,rec in enumerate(seq):
            x=extract(rec['values'])
            if prev is not None:
                salience=clamp(float(np.linalg.norm(np.asarray(x)-np.asarray(prev)))/threshold,0,1)
                if salience>=.25:
                    event_candidates.append({'kind':label,'seq':i,'score':salience*float(genome.sensory_weights[index])})
            prev=x
    derived_changes(magnetic,1,lambda v:np.asarray(v)[0],.5,'magnetic_local_change_uT')
    derived_changes(magxyz,1,lambda v:v,.5,'single_magnetometer_change_uT')
    derived_changes(motion,2,lambda v:v,.1,'accelerometer_change_m_s2')
    derived_changes(lux,3,lambda v:v,2.,'lux_change')
    # Deterministic, finite event budget; a salience is a scheduling heuristic only.
    event_candidates.sort(key=lambda x:(-x['score'],x['seq'],x['kind']))
    candidate_count=len(event_candidates)
    for item in event_candidates[:1024]:colony.submit(item)
    dispatched=colony.work(64)
    availability={k:bool({'optical_rgb':optical,'magnetometer':magnetic,'accelerometer':motion,'ambient_light':lux,'magnetometer_xyz':magxyz,'range_ray':rays}[k]) for k in SENSOR_UNITS}
    weight_availability=dict(availability);weight_availability['magnetometer']=bool(magnetic or magxyz)
    for _ in range(min(80,len(validated))):controller.step(weight_availability,quality)
    provenance={k:sorted(set(rec['source'] for rec in validated if rec['kind']==k)) for k in SENSOR_UNITS}
    return {'schema':'ripple-master-alpha-result/2', 'mode':'offline_recorded_input',
      'classification':'simulated' if all(v=='simulated' for x in validated for v in [x['source']]) else 'hardware_reported_unverified',
      'actual_hardware_validated':False,'genome':genome.name,'genome_marker':genome.marker(),
      'capability_registry':{k:{'enabled':availability[k], 'source':provenance[k] if availability[k] else [],'unit':SENSOR_UNITS[k]} for k in SENSOR_UNITS},
      'legacy_neuron':js,'optical_temporal_modulation':temporal_frequency([sum(x['values'])/3 for x in optical],[x['t_ms'] for x in optical]) if optical else {'valid':False,'reason':'sensor unavailable'},'magnetic':mag,'motion':{'available':bool(motion),'count':len(motion),'unit':'m/s2'},
      'ambient_light':{'available':bool(lux),'count':len(lux),'unit':'lux'},
      'magnetometer_xyz':{'available':bool(magxyz),'count':len(magxyz),'coordinate_frame':'reported_local_axes','reconstruction':False},
      'spatial_map':grid.summarize() if rays else {'available':False,'reason':'no range rays with sensor pose supplied'},
      'colony':{'workers':len(colony.workers),'queued':len(colony.queue),'dispatched':len(dispatched),'total_workload':sum(w['processed'] for w in colony.workers), 'candidates':candidate_count,
                  'dropped_due_capacity':max(0,candidate_count-1024),'events':dispatched,
                  'score_definition':'dimensionless normalized change threshold × fixed inherited scheduling weight; NOT estimated scientific importance'},
      'weight_state':{'initial':list(genome.sensory_weights),'final':controller.weights.tolist(),
          'method':'bounded EWMA of per-channel timestamp regularity (structural quality), not hardware accuracy or trained model'},
      'rules':['no cross-unit fusion','no calibration claim','no automatic hardware access','no executable mutations','no monochrome research continuation']}


def spatial_legacy(genome:WeightGenome,seed=41):
    # Original study re-run without additional monochrome research, only conservation sanity for selected source.
    lookup={s.name:s for s in SPECIES};name=genome.name
    if name in lookup:species=lookup[name]
    else:
        records=json.loads((ROOT/'legacy'/'hybridlineage.json').read_text())['selected']
        entry=next(x for x in records if x['name']==name)
        from ripple_alpha import Species
        d=entry['species'];species=Species(d['name'],d['color'],tuple(d['rgb_gain']),d['diffusion_gain'],d['occlusion_gain'],d['absorption'])
    experiment=run_one(species,Conditions(n=16,steps=20,dt=.08,seed=seed,dim=2),record_frames=False)
    return {'classification':'synthetic','genome':name,'legacy_summary':{k:v for k,v in experiment.items() if k!='trace' and k!='snapshots'},
      'note':'Unmodified legacy 2D model regression. No new monochrome study; results are synthetic.'}


def main():
    import argparse
    a=argparse.ArgumentParser(description='Offline Master Ripple Alpha 2.0; no network or sensor permissions')
    a.add_argument('--input',default=str(ROOT/'fixtures'/'master_mixed_simulated.jsonl'))
    a.add_argument('--genome',default='prism')
    a.add_argument('--output',default=str(ROOT/'results'/'master_demo.json'))
    a.add_argument('--no-photoreceptor',action='store_true')
    a.add_argument('--spatial-regression',action='store_true')
    a.add_argument('--propose-child',action='store_true')
    args=a.parse_args()
    if not verify_sources(include_archives=False)['passed']:raise SystemExit('Frozen source lock integrity check failed; refusing to execute')
    reg=inherited_genomes()
    if args.genome not in reg:raise SystemExit(f'Unknown genome. Available: {list(reg)}')
    records=read_frames(Path(args.input))
    out=analyze_master(records,reg[args.genome],not args.no_photoreceptor)
    if args.propose_child:out['proposed_child']=propose_weight_child(reg[args.genome],records)
    if args.spatial_regression:out['spatial_legacy_regression']=spatial_legacy(reg[args.genome])['legacy_summary']['metrics']
    path=Path(args.output);path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'output':str(path),'genome':args.genome,'frames':sum(x['enabled'] for x in out['capability_registry'].values()),
        'spikes_raw':out['legacy_neuron']['total_raw_spikes'] if out['legacy_neuron'] else None,'colony_dispatched':out['colony']['dispatched'],'classification':out['classification']}))

if __name__=='__main__':main()
