"""Reproducible-file-content release packer. ZIP timestamps are normalized."""
from pathlib import Path
import hashlib,json,os,sys,zipfile
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT.parent/'Master_Ripple_Alpha_v2.0_Open_Research_Release.zip'
IGNORED={'__pycache__','.pytest_cache','.DS_Store'}
FILES=[]
for p in sorted(ROOT.rglob('*')):
 if p.is_file() and not any(part in IGNORED for part in p.parts) and p.name not in ('SHA256SUMS.txt','RELEASE_AUDIT.json'):
  FILES.append(p)
manifest=[{'file':str(f.relative_to(ROOT)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size} for f in FILES]
(ROOT/'SHA256SUMS.txt').write_text(''.join(f"{x['sha256']}  {x['file']}\n" for x in manifest))
logs={}
for f in ['results/tests_master_46.log','results/tests_inherited_v13.log','results/tests_original_quaternary.log']:
 txt=(ROOT/f).read_text();import re
 passes=re.findall(r'(?:Ran (\d+) tests|# pass (\d+))',txt)
 logs[f]=passes[-1] if passes else []
audit={'schema':'ripple-master-release-audit/1','stage':'research Alpha','software_tests_new':46,
 'software_tests_inherited_alpha_v13':27,'software_tests_original_quaternary':11,
 'tested_sum':84,'software_comparison_trials':72,'inherited_genomes':9,
 'full_archive_packages':12,'frozen_source_archive_files_verified':21,
 'camera_browser_sandbox_mocked':True,'physical_hardware_tested':False,
 'source_files_sha256':len(manifest),'run_logs':logs,
 'known_limits':['not trained general AI','no physical scanner validation','no cloud runtime or sensor inference','external motor and avatar services archived only','no public deployment','camera permissions not physically tested'],
 'release_validation':'Source and archive hash audit performed, clean extract pending'}
(ROOT/'RELEASE_AUDIT.json').write_text(json.dumps(audit,indent=2)+'\n')
paths=FILES+[ROOT/'SHA256SUMS.txt',ROOT/'RELEASE_AUDIT.json']
with zipfile.ZipFile(OUT,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in paths:
  rel=str(p.relative_to(ROOT));name='Master_Ripple_Alpha_v2_0/'+rel
  info=zipfile.ZipInfo(name,date_time=(2026,10,13,22,0,0));info.external_attr=(0o644<<16)
  info.compress_type=zipfile.ZIP_DEFLATED
  z.writestr(info,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=6)
with zipfile.ZipFile(OUT) as z:
 bad=z.testzip()
 assert bad is None,bad
 for obj in manifest:
  data=z.read('Master_Ripple_Alpha_v2_0/'+obj['file'])
  assert hashlib.sha256(data).hexdigest()==obj['sha256'],obj['file']
print(json.dumps({'zip_path':str(OUT),'zip_bytes':OUT.stat().st_size,'files_in_zip':len(paths),'source_files':len(manifest),
 'zip_sha256':hashlib.sha256(OUT.read_bytes()).hexdigest(),'all_file_hashes_verified':True},indent=2))
