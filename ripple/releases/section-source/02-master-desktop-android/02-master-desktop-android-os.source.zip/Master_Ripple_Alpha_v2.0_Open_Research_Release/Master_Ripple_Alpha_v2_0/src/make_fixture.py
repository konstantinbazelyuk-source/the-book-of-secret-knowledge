from pathlib import Path
import json,math,numpy as np
ROOT=Path(__file__).resolve().parents[1]
rng=np.random.default_rng(20261013)
rows=[]
for i in range(120):
    t=float(i*50)
    red=float(np.clip(.35+(.30 if 40<=i<80 else 0)+.02*math.sin(i*.13),0,1))
    green=float(np.clip(.25+.05*math.sin(i*.04),0,1))
    blue=float(np.clip(.15+.04*math.cos(i*.08),0,1))
    rows.append({'schema':'ripple-master/2.0','kind':'optical_rgb','source':'simulated','t_ms':t,'unit':'normalized_rgb_roi','values':[red,green,blue]})
    # 8 independent local frame vectors; no valid pose or field reconstruction.
    magnet=[[(24+.6*math.sin(i*.08+j),-12+.5*math.cos(i*.06+j),43+.25*math.sin(i*.1))][0] for j in range(8)]
    rows.append({'schema':'ripple-master/2.0','kind':'magnetometer','source':'simulated','t_ms':t,'unit':'microtesla','values':magnet})
    rows.append({'schema':'ripple-master/2.0','kind':'accelerometer','source':'simulated','t_ms':t,'unit':'m/s2','values':float(.1*math.sin(i*.2))})
    rows.append({'schema':'ripple-master/2.0','kind':'ambient_light','source':'simulated','t_ms':t,'unit':'lux','values':float(100+10*math.cos(i*.15))})
p=ROOT/'fixtures'/'master_mixed_simulated.jsonl'
p.write_text(''.join(json.dumps(r,separators=(',',':'),allow_nan=False)+'\n' for r in rows))
print('wrote',len(rows),'synthetic sensor records')
