import fs from 'node:fs';
import {temporalFrequencyHz} from '../legacy/quaternary-core.mjs';
let payload=JSON.parse(fs.readFileSync(0,'utf8'));
if(!Array.isArray(payload.samples)||!Array.isArray(payload.timestamps)||payload.samples.length>4096)throw Error('bad samples');
console.log(JSON.stringify(temporalFrequencyHz(payload.samples,payload.timestamps)));
