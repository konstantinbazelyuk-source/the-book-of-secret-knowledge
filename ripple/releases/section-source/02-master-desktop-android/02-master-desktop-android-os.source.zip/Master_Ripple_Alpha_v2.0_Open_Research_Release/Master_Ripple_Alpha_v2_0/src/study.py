"""Original-neuron-versus-master comparisons on controlled synthetic input. No fitness ranking."""
from pathlib import Path
import sys,json,math,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from master import analyze_master, inherited_genomes, SCHEMA

def fixture(seed):
    rng=np.random.default_rng(seed);rows=[]
    for i in range(125):
        t=i*50
        red=np.clip(.20+(.5 if 34<=i<88 else .05)+.035*rng.normal(),0,1)
        green=np.clip(.22+.04*math.sin(i*.075)+.02*rng.normal(),0,1)
        blue=np.clip(.18+.04*math.cos(i*.06)+.02*rng.normal(),0,1)
        r={'schema':SCHEMA,'kind':'optical_rgb','source':'simulated','t_ms':t,'unit':'normalized_rgb_roi','values':[float(red),float(green),float(blue)]}
        rows.append(r)
    return rows

def main():
    registry=inherited_genomes();seeds={'development':[11,17],'independent_checks':[509,521]}
    rows=[]
    for group,ss in seeds.items():
        for seed in ss:
            frames=fixture(seed)
            for g in registry.values():
                for enabled in (False,True):
                    x=analyze_master(frames,g,enabled)
                    trace=x['legacy_neuron']
                    rows.append({'status':'simulated','seed_group':group,'seed':seed,'genome':g.name,'parent':g.parent,
                        'light_overlay':enabled,'baseline_spikes':trace['total_raw_spikes'],
                        'weighted_spikes':trace['total_weighted_spikes'],
                        'quaternary_changes':sum(s['symbol_code'] in (0,3) for s in trace['steps']),
                        'colony_events_dispatched':x['colony']['dispatched']})
    assert len(rows)==len(registry)*2*4
    raw=json.dumps({'schema':'ripple-master-comparison/1','classification':'synthetic','source':'deterministic generated normalized RGB',
        'interpretation':'Event differences measure changed numerical response only, not improved intelligence or physical accuracy.',
        'source_seeds':seeds,'trials':rows},indent=2)
    (ROOT/'results'/'gene_comparison.json').write_text(raw+'\n')
    import csv
    with (ROOT/'results'/'gene_comparison.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    import matplotlib;matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    reg=list(registry.values());fig,ax=plt.subplots(figsize=(12,5.4))
    for g in reg:
        rec=[r for r in rows if r['genome']==g.name and r['seed_group']=='independent_checks' and r['light_overlay']]
        x=[r['seed'] for r in rec];y=[r['weighted_spikes'] for r in rec]
        ax.scatter(x,y,color=g.color,s=80,alpha=.9,label=g.name)
        ax.plot(x,y,color=g.color,alpha=.35)
    base=[r for r in rows if r['genome']=='prism' and r['seed_group']=='independent_checks' and r['light_overlay']]
    ax.plot([r['seed'] for r in base],[r['baseline_spikes'] for r in base],color='#111111',ls='--',lw=2,label='original neuron (unchanged)')
    ax.set_xticks([509,521]);ax.set_xlabel('Independent synthetic input seed');ax.set_ylabel('Calculated event count in fixed 6.25-second input');ax.set_title('Master Ripple: inherited overlays versus original neuron\nNot performance or intelligence ranking')
    ax.grid(alpha=.2);ax.legend(ncol=5,loc='upper center',bbox_to_anchor=(.5,-.14),fontsize=8);fig.tight_layout()
    fig.savefig(ROOT/'results'/'gene_comparison.png',dpi=175,bbox_inches='tight');plt.close(fig)
    print(json.dumps({'trials':len(rows),'genomes':len(registry),'seeds':seeds,
        'baseline_holdout_counts':sorted({r['baseline_spikes'] for r in rows if r['seed_group']=='independent_checks'}),
        'weighted_holdout_range':[min(r['weighted_spikes'] for r in rows if r['seed_group']=='independent_checks'),max(r['weighted_spikes'] for r in rows if r['seed_group']=='independent_checks')]},indent=2))
if __name__=='__main__':main()
