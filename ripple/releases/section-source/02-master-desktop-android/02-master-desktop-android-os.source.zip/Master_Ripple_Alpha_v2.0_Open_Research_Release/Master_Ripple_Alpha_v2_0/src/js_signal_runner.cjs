/* Calls the original frozen Ripple class and v0.6 photoreceptor; QUAD v0.7 via native ESM.
   No dynamic eval and no user code execution. Command input JSON only. */
'use strict';
const fs=require('node:fs');
const path=require('node:path');
require('../legacy/ripple-core.js');
const {Photoreceptor}=require('../legacy/photoreceptor-v06.js');
async function run(){
 const {QuadVM,pack4,unpack4}=await import('../legacy/quaternary-core.mjs');
 const p=JSON.parse(fs.readFileSync(0,'utf8'));
 if(!Array.isArray(p.frames)||p.frames.length>4096)throw Error('frame limit');
 const neuron=new globalThis.RippleNeuron(), preNeuron=new globalThis.RippleNeuron(),photo=new Photoreceptor();
 const gains=Array.isArray(p.gains)&&p.gains.length===3?p.gains:[1,1,1];
 if(gains.some(v=>!Number.isFinite(v)||v<.35||v>1.5))throw Error('invalid inherited overlay');
 const vm=new QuadVM('Drive events');const seq=[];let old=null,total_raw_spikes=0,total_photo_spikes=0;
 for(const f of p.frames){
  const t=Number(f.t_ms),rgb=f.rgb;
  if(!Number.isFinite(t)||!Array.isArray(rgb)||rgb.length!==3||rgb.some(x=>!Number.isFinite(x)||x<0||x>1))throw Error('invalid optical sample');
  if(old!==null){
   const dt=(t-old)/1000;if(!(dt>0&&dt<=.5))throw Error('timing beyond neuron guard');
   const raw=neuron.step(rgb,dt);
   const processed=p.photoreceptor?photo.step(rgb,dt).output:rgb;
   const inherited=processed.map((v,i)=>Math.max(0,Math.min(1,v*gains[i])));
   const filtered=preNeuron.step(inherited,dt);
   const encoded=vm.run({rgb,drive:raw.drive});
   total_raw_spikes+=raw.count;total_photo_spikes+=filtered.count;
   seq.push({t_ms:t,spikes_raw:raw.count,spikes_weighted:filtered.count,drive:raw.drive,theta_raw:raw.theta,
    symbol_code:encoded.code,symbol_bits:encoded.bits,processed_rgb:processed, inherited_rgb:inherited});
  }old=t;
 }
 const test=pack4([0,1,2,3]);if(JSON.stringify(unpack4(test))!==JSON.stringify([0,1,2,3]))throw Error('quaternary coding failed');
 console.log(JSON.stringify({method:'original JS RippleNeuron v0.1 + photoreceptor v0.6 + Ripple-Q v0.7',total_raw_spikes,total_weighted_spikes:total_photo_spikes,steps:seq,packed_test_byte:test,
 limitations:'RGB normalized pixel proxy; not magnetic µT, consciousness or optical carrier'}));
}
run().catch(e=>{console.error(e.stack);process.exitCode=1});
