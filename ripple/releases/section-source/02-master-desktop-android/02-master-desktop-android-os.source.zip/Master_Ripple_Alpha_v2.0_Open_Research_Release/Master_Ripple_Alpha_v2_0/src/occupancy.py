"""Bounded 2D log-odds occupancy mapping from reported range rays.
Implements a conventional inverse range-sensor model, not proof of spatial accuracy.
Sensor origin and ray angle MUST be supplied. Behind range hit remains unknown.
"""
import math
import numpy as np

class OccupancyGrid:
    def __init__(self, side=64, resolution_m=.1):
        if not 16<=side<=128 or not .02<=resolution_m<=1:raise ValueError('grid budget')
        self.n=side;self.res=resolution_m;self.logodds=np.zeros((side,side),float);self.updates=0
    def ray(self,x_m,y_m,angle_rad,range_m,max_range_m):
        v=[x_m,y_m,angle_rad,range_m,max_range_m]
        if not all(isinstance(z,(int,float)) and not isinstance(z,bool) and math.isfinite(z) for z in v):raise ValueError('nonfinite ray')
        if not 0<=range_m<=max_range_m<=12:raise ValueError('range constraints')
        if abs(x_m)>6 or abs(y_m)>6:raise ValueError('pose outside bounds')
        count=max(1,int(math.ceil(range_m/self.res*2)))
        # Sensor reports a hit only if distance < declared maximum; no reflected target otherwise.
        hit=range_m<max_range_m-1e-6
        points=[]
        for i in range(count+1):
            dist=range_m*i/count
            xx=x_m+dist*math.cos(angle_rad);yy=y_m+dist*math.sin(angle_rad)
            gx=int(math.floor(xx/self.res+self.n/2));gy=int(math.floor(yy/self.res+self.n/2))
            if not (0<=gx<self.n and 0<=gy<self.n):continue
            if not points or points[-1]!=(gy,gx):points.append((gy,gx))
        free=points[:-1] if hit else points
        for p in free:self.logodds[p]=float(np.clip(self.logodds[p]-.40,-3.5,3.5))
        if hit and points:self.logodds[points[-1]]=float(np.clip(self.logodds[points[-1]]+.85,-3.5,3.5))
        self.updates+=1
    def probability(self):return 1/(1+np.exp(-self.logodds))
    def summarize(self):
        p=self.probability()
        return {'classification':'derived_from_reported_range','grid_size':[self.n,self.n],'resolution_m':self.res,'rays':self.updates,
                'inferred_occupied_cells':int((p>.6).sum()),'inferred_free_cells':int((p<.4).sum()),'unknown_cells':int(((p>=.4)&(p<=.6)).sum()),
                'limitations':'Unknown beyond observed rays. Accuracy depends on external range and pose calibration. No robot control.'}
