"""Fail-closed byte-preservation audit for frozen code and prior archive snapshots."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[1]
def verify_sources(include_archives=True):
    lock=json.loads((ROOT/'docs'/'FROZEN_SOURCE_LOCK.json').read_text())['files']
    results=[]
    for name,digest in lock.items():
        p=ROOT/name;actual=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else 'MISSING'
        results.append({'file':name,'okay':actual==digest,'observed_sha256':actual})
    if include_archives:
        archives=json.loads((ROOT/'docs'/'FROZEN_ARCHIVES.json').read_text())['archives']
        for item in archives:
            p=ROOT/'frozen_archives'/item['name']
            actual=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else 'MISSING'
            results.append({'file':'frozen_archives/'+item['name'],'okay':actual==item['sha256'], 'observed_sha256':actual})
    return {'passed':all(x['okay'] for x in results),'count':len(results),'results':results}
if __name__=='__main__':
    report=verify_sources()
    print(json.dumps({'passed':report['passed'],'count':report['count'],'failures':[x for x in report['results'] if not x['okay']]},indent=2))
    if not report['passed']:raise SystemExit(1)
