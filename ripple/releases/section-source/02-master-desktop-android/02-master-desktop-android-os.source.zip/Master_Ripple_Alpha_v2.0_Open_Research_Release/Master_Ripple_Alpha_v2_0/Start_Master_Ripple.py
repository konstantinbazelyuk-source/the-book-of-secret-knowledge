"""Serve the Alpha workstation locally. Close with Ctrl+C. Camera requires permission."""
from pathlib import Path
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
import os,webbrowser
root=Path(__file__).resolve().parent
os.chdir(root)
url='http://127.0.0.1:8787/web/index.html'
print(url,flush=True)
webbrowser.open(url)
ThreadingHTTPServer(('127.0.0.1',8787),SimpleHTTPRequestHandler).serve_forever()
