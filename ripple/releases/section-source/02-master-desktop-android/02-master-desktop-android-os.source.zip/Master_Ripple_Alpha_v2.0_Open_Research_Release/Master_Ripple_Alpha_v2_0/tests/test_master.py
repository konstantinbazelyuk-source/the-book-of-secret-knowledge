import hashlib, json, math, os, subprocess, sys, tempfile, unittest
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
sys.path.insert(0,str(ROOT/'legacy'))
from master import (WeightGenome,inherited_genomes,GuardedStream, read_frames,propose_weight_child,
    BoundedColony, AdaptiveSensoryWeights, analyze_master, js_optical,spatial_legacy,SCHEMA)
from occupancy import OccupancyGrid
from ripple_alpha import flux_laplacian,LegacyRippleNeuron,Species,SPECIES,Conditions,run_one

class MasterChecks(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.reg=inherited_genomes();cls.gen=cls.reg['prism']
  cls.frames=read_frames(ROOT/'fixtures'/'master_mixed_simulated.jsonl')
  cls.output=analyze_master(cls.frames,cls.gen)
 def test_01_frozen_v03_checksum(self):self.assertEqual(hashlib.sha256((ROOT/'legacy'/'ripple_v03_reference.js').read_bytes()).hexdigest(),'d75d4208e92f19623b127615bd52b4002e85d2c0a59b76471764b55a24294210')
 def test_02_genome_count(self):self.assertEqual(len(self.reg),9)
 def test_03_inherited_parent_provenance(self):self.assertTrue(all(len(g.parent)==64 for g in self.reg.values()))
 def test_04_genome_markers_deterministic(self):self.assertEqual(self.gen.marker(),self.gen.marker())
 def test_05_reject_gain_invalid(self):
  with self.assertRaises(ValueError):WeightGenome('x','parent','#123456',(100,1,1),(.55,.25,.13,.07),.2,.3,.4)
 def test_06_reject_unormalized_weights(self):
  with self.assertRaises(ValueError):WeightGenome('x','parent','#123456',(1,1,1),(.3,.4,.3,.3),.2,.3,.4)
 def test_07_reject_excess_workers(self):
  with self.assertRaises(ValueError):WeightGenome('x','parent','#123456',(1,1,1),(.55,.25,.13,.07),.2,.3,.4,100)
 def test_08_no_fabricated_magnetism(self):
  optical=self.frames[::4];out=analyze_master(optical,self.gen)
  self.assertFalse(out['capability_registry']['magnetometer']['enabled'])
  self.assertFalse(out['magnetic']['available'])
 def test_09_correct_units(self):
  x=dict(self.frames[0]);x['unit']='microtesla'
  with self.assertRaises(ValueError):GuardedStream().accept(x)
 def test_10_mixing_hardware_simulated_rejected(self):
  g=GuardedStream();a=dict(self.frames[0]);b=dict(self.frames[4]);b['source']='hardware_reported_unverified';g.accept(a)
  with self.assertRaises(ValueError):g.accept(b)
 def test_11_no_timestamp_reuse(self):
  g=GuardedStream();g.accept(self.frames[0])
  with self.assertRaises(ValueError):g.accept(self.frames[0])
 def test_12_reject_nan_optical(self):
  a=dict(self.frames[0]);a['values']=[math.nan,.3,.1]
  with self.assertRaises(ValueError):GuardedStream().accept(a)
 def test_13_reject_wrong_field_array(self):
  a=dict(self.frames[1]);a['values']=[[1,2,3]]
  with self.assertRaises(ValueError):GuardedStream().accept(a)
 def test_14_magnetic_not_light(self):
  self.assertEqual(self.output['magnetic']['unit'],'microtesla')
  self.assertEqual(self.output['legacy_neuron']['method'],'original JS RippleNeuron v0.1 + photoreceptor v0.6 + Ripple-Q v0.7')
 def test_15_sensor_count(self):self.assertEqual(sum(x['enabled'] for x in self.output['capability_registry'].values()),4)
 def test_16_one_frame_starts_no_spike(self):
  out=analyze_master([self.frames[0]],self.gen)
  self.assertEqual(out['legacy_neuron']['total_raw_spikes'],0)
 def test_17_original_vs_weighted_diverge(self):self.assertNotEqual(self.output['legacy_neuron']['total_raw_spikes'],self.output['legacy_neuron']['total_weighted_spikes'])
 def test_18_dispatched_tasks_are_audit_only(self):
  self.assertGreater(self.output['colony']['dispatched'],0)
  self.assertTrue(all(set(e)=={'worker','task','seq'} for e in self.output['colony']['events']))
 def test_19_colony_capacity(self):
  c=BoundedColony(self.gen)
  for i in range(1024):c.submit({'kind':'test','seq':i})
  with self.assertRaises(ValueError):c.submit({'kind':'overflow','seq':0})
 def test_20_colony_roundrobin(self):
  c=BoundedColony(self.gen)
  for i in range(7):c.submit({'kind':'task','seq':i})
  self.assertEqual([r['worker'] for r in c.work(7)],['ripple-00','ripple-01','ripple-02','ripple-03','ripple-00','ripple-01','ripple-02'])
 def test_21_fixed_budget_adaptation(self):
  ctrl=AdaptiveSensoryWeights(self.gen)
  for i in range(1000):ctrl.step({'optical_rgb':True},{'optical_rgb':.9})
  self.assertTrue(np.isclose(sum(ctrl.weights),1));self.assertTrue(np.isfinite(ctrl.weights).all())
 def test_22_missing_sensor_no_weight_change(self):
  ctrl=AdaptiveSensoryWeights(self.gen);before=ctrl.weights.copy();ctrl.step({},{});np.testing.assert_array_equal(before,ctrl.weights)
 def test_23_original_js_port_drive_and_events_parity(self):
  stimuli=[[0.5+.4*math.sin(i*.077),.15+.15*math.cos(i*.013),.2] for i in range(400)]
  stimuli=[[max(0,min(1,c)) for c in x] for x in stimuli]
  n=LegacyRippleNeuron();py=[n.step(x,.05) for x in stimuli]
  code="require('./legacy/ripple-core.js');const xs=JSON.parse(require('fs').readFileSync(0,'utf8'));let n=new globalThis.RippleNeuron; console.log(JSON.stringify(xs.map(x=>n.step(x,.05))));"
  p=subprocess.run(['node','-e',code],input=json.dumps(stimuli),text=True,capture_output=True,cwd=ROOT,check=True,timeout=20)
  js=json.loads(p.stdout)
  for a,b in zip(js,py):
   self.assertEqual(a['count'],b['count'])
   for key in ['theta','u','rate','drive']:
    self.assertAlmostEqual(a[key],b[key],places=10)
 def test_24_quad_original_full_byte_roundtrip(self):
  code="import('./legacy/quaternary-core.mjs').then(m=>{for(let i=0;i<256;i++){if(m.pack4(m.unpack4(i))!==i)throw Error('fail')}console.log('256')})"
  p=subprocess.run(['node','-e',code],text=True,capture_output=True,cwd=ROOT,check=True,timeout=20)
  self.assertEqual(p.stdout.strip(),'256')
 def test_25_quad_sensor_unavailable(self):
  code="import('./legacy/quaternary-core.mjs').then(m=>{try{new m.QuadVM('Magnetic field').run({drive:1});process.exit(1)}catch(e){console.log('missing sensor rejected')}})"
  p=subprocess.run(['node','-e',code],text=True,capture_output=True,cwd=ROOT,check=True)
  self.assertIn('missing sensor rejected',p.stdout)
 def test_26_conservative_diffusion(self):
  r=np.random.default_rng(7);u=r.random((32,32));block=np.zeros((32,32),bool);block[11:23,15]=True;d=np.ones((32,32))*.2
  f=flux_laplacian(u,block,d);self.assertLess(abs(float(f.sum())),1e-11)
 def test_27_spatial_source_is_original(self):self.assertEqual(spatial_legacy(self.gen)['classification'],'synthetic')
 def test_28_grid_observed_hit(self):
  g=OccupancyGrid();g.ray(0,0,0,1,3);self.assertGreater(g.summarize()['inferred_occupied_cells'],0)
 def test_29_behind_obstacle_unknown(self):
  g=OccupancyGrid();g.ray(0,0,0,1,3);self.assertAlmostEqual(g.probability()[32,48],.5)
 def test_30_no_hit_ray(self):
  g=OccupancyGrid();g.ray(0,0,0,3,3);self.assertEqual(g.summarize()['inferred_occupied_cells'],0)
 def test_31_pose_missing_rejected(self):
  g=OccupancyGrid()
  with self.assertRaises(TypeError):g.ray(1,2,3,4)
 def test_32_invalid_range(self):
  g=OccupancyGrid()
  with self.assertRaises(ValueError):g.ray(0,0,0,20,10)
 def test_33_deterministic_run(self):
  a=analyze_master(self.frames,self.gen);b=analyze_master(self.frames,self.gen)
  self.assertEqual(json.dumps(a,sort_keys=True),json.dumps(b,sort_keys=True))
 def test_34_no_unauthorized_exec(self):
  with self.assertRaises(ValueError):GuardedStream().accept({'schema':SCHEMA,'kind':'execute_javascript','source':'simulated','unit':'code','values':'rm -rf','t_ms':0})
 def test_35_real_hardware_is_not_certified(self):
  x=dict(self.frames[0]);x['source']='hardware_reported_unverified'
  out=analyze_master([x],self.gen)
  self.assertFalse(out['actual_hardware_validated']);self.assertEqual(out['classification'],'hardware_reported_unverified')
 def test_36_stamped_sensor_xyz(self):
  v={'schema':SCHEMA,'source':'hardware_reported_unverified','kind':'magnetometer_xyz','unit':'microtesla','t_ms':1,'values':[1,2,3]}
  self.assertEqual(GuardedStream().accept(v)['values'],[1.,2.,3.])
 def test_37_range_schema(self):
  v={'schema':SCHEMA,'source':'simulated','kind':'range_ray','unit':'meters_and_radians','t_ms':1,'values':dict(x_m=0,y_m=0,angle_rad=0,range_m=1,max_range_m=3)}
  self.assertEqual(GuardedStream().accept(v)['values']['range_m'],1)
 def test_38_sensor_ray_integration(self):
  v={'schema':SCHEMA,'source':'simulated','kind':'range_ray','unit':'meters_and_radians','t_ms':1,'values':dict(x_m=0,y_m=0,angle_rad=0,range_m=1,max_range_m=3)}
  self.assertEqual(analyze_master([v],self.gen)['spatial_map']['rays'],1)

 def test_39_mutation_proposal_holds_parent(self):
  o=propose_weight_child(self.gen,self.frames)
  self.assertEqual(o['parent_marker'],self.gen.marker())
  self.assertNotEqual(o['child_marker'],self.gen.marker())
  self.assertEqual(o['classification'],'candidate_not_activated')
 def test_40_mutation_proposal_deterministic(self):
  self.assertEqual(propose_weight_child(self.gen,self.frames),propose_weight_child(self.gen,self.frames))
 def test_41_no_mutation_without_data(self):
  with self.assertRaises(ValueError):propose_weight_child(self.gen,[self.frames[0]])
 def test_42_mutation_does_not_change_neuron(self):
  before=hashlib.sha256((ROOT/'legacy'/'ripple-core.js').read_bytes()).hexdigest()
  propose_weight_child(self.gen,self.frames)
  self.assertEqual(hashlib.sha256((ROOT/'legacy'/'ripple-core.js').read_bytes()).hexdigest(),before)
 def test_43_frequency_nyquist_consistency(self):
  f=self.output['magnetic']['temporal_modulation'];self.assertLessEqual(f['hz'],f['nyquistHz'])
 def test_44_bad_spatial_no_density_direct(self):
  with self.assertRaises(ValueError):run_one(SPECIES[0],Conditions(n=8))

 def test_45_single_magnetometer_updates_weight_availability(self):
  r=[{'schema':SCHEMA,'source':'simulated','kind':'magnetometer_xyz','unit':'microtesla','t_ms':1+i*100,'values':[1+i*.02,2.,3.]} for i in range(30)]
  x=analyze_master(r,self.gen)
  self.assertTrue(x['capability_registry']['magnetometer_xyz']['enabled'])
  self.assertFalse(x['capability_registry']['magnetometer']['enabled'])
  self.assertGreater(x['weight_state']['final'][1],x['weight_state']['initial'][1])
 def test_46_frozen_integrity_report(self):
  from verify_sources import verify_sources
  audit=verify_sources();self.assertEqual(audit['count'],21);self.assertTrue(audit['passed'])

if __name__=='__main__':unittest.main()
