"""Sandbox browser check: URL navigation is blocked, so run identical source inline on about:blank.
Mocked camera pixels test UI behavior, not permission/hardware integration. Report limits explicitly."""
import json,pathlib,re
from playwright.sync_api import sync_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1]
web=(ROOT/'web'/'index.html').read_text()
core=(ROOT/'legacy'/'ripple-core.js').read_text()
photo=(ROOT/'legacy'/'photoreceptor-v06.js').read_text()
quad=(ROOT/'legacy'/'quaternary-core.mjs').read_text()
quad=re.sub(r'^export\s+', '',quad,flags=re.MULTILINE)+'\nglobalThis.__QuadVM=QuadVM;\n'
main=web.split('<script type="module">')[1].split('</script>')[0]
main=main.replace("import {QuadVM} from '../legacy/quaternary-core.mjs';", "const QuadVM=globalThis.__QuadVM;")
html=web.split('<script src="../legacy/ripple-core.js"></script>')[0] + '<script>'+core+'</script><script>'+photo+'</script><script>'+quad+'</script><script type="module">'+main+'</script></body></html>'
registry=json.loads((ROOT/'web'/'genomes.json').read_text())
errors=[]
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 mobile=browser.new_context(viewport={'width':390,'height':844},accept_downloads=True)
 page=mobile.new_page();page.on('pageerror',lambda e:errors.append(str(e)))
 page.evaluate('profiles => {window.fetch=async()=>({json:async()=>profiles});}', registry)
 page.set_content(html,wait_until='load');page.wait_for_timeout(400)
 assert page.locator('#genome option').count()==9,(page.locator('#events').inner_text(),errors)
 assert page.locator('#status').inner_text().startswith('Idle')
 page.locator('#genome').select_option('canopy')
 assert page.locator('#marker').inner_text().strip('…')
 # Browser driver lacks real hardware; stub the permission and frame input explicitly.
 page.evaluate('''() => {
  Object.defineProperty(navigator,'mediaDevices',{configurable:true,value:{getUserMedia:async()=>({getTracks:()=>[{stop:()=>{}}]})}});
  Object.defineProperty(HTMLMediaElement.prototype,'srcObject',{configurable:true,get(){return this._mockStream},set(v){this._mockStream=v}});
  HTMLMediaElement.prototype.play=async function() {};
  Object.defineProperty(HTMLMediaElement.prototype,'readyState',{configurable:true,get:()=>4});
  const orig=CanvasRenderingContext2D.prototype.getImageData;
  CanvasRenderingContext2D.prototype.getImageData=function(x,y,w,h){const a=new Uint8ClampedArray(w*h*4);for(let i=0;i<a.length;i+=4){a[i]=120;a[i+1]=80;a[i+2]=40;a[i+3]=255}return {data:a}};
 }''')
 page.locator('#start').click();page.wait_for_timeout(600)
 assert 'Recording' in page.locator('#status').inner_text(),page.locator('#events').inner_text()
 n=int(page.locator('#count').inner_text());assert n>1,n
 assert page.locator('#drive').inner_text()!='—',page.locator('#events').inner_text()
 assert page.locator('#symbol').inner_text()!='—',page.locator('#events').inner_text()
 with page.expect_download() as dl:page.locator('#export').click()
 saved=dl.value.path();assert saved and pathlib.Path(saved).stat().st_size>100
 page.screenshot(path=str(ROOT/'results'/'master_dashboard_mobile.png'),full_page=True)
 page.locator('#stop').click();assert 'Stopped' in page.locator('#status').inner_text()
 desktop=browser.new_context(viewport={'width':1240,'height':900})
 pg=desktop.new_page();pg.on('pageerror',lambda e:errors.append(str(e)))
 pg.evaluate('profiles=>{window.fetch=async()=>({json:async()=>profiles});}',registry)
 pg.set_content(html,wait_until='load');pg.screenshot(path=str(ROOT/'results'/'master_dashboard_desktop.png'),full_page=True)
 assert len(errors)==0,errors
 report={'browser':'Chromium headless with inlined original JS sources due to sandbox navigation block','mode':'DOM/camera-input mock; NOT physical test',
     'genomes_loaded':9,'mocked_records':n,'module_behavior':'original LIF, photoreceptor, QuadVM executed in browser',
     'download_ok':True,'stop_button_ok':True,'js_errors':errors,
     'NOT_tested':['real camera permissions','network/localhost serving','actual Samsung camera','physical magnetometer/ambient light/IMU','live hardware quality']}
 (ROOT/'results'/'browser_smoke.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report,indent=2));browser.close()
