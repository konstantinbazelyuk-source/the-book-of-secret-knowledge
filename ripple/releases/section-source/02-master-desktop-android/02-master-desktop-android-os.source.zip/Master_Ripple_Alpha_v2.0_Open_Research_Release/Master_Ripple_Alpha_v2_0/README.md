# MASTER RIPPLE ALPHA v2.0 — Unified, Bounded Research Engine

**Status:** runnable software Alpha. **Not:** autonomous general intelligence, a trained foundation model, a physically calibrated 3D electromagnetic scanner, a robot with tested motors, or proof of consciousness/aura detection.

**Core principle:** preserve the approved source **byte-for-byte** while running its existing capabilities behind typed, audited adapters. Source concept: Constantin x. New work is MIT-licensed. Archived components retain their original, sometimes different licenses.

## What actually works

- **Original Ripple neuron (v0.1 / frozen source):** the exact archived JavaScript class is executed, with its leaky integration, refractory period, feedback and spike events. Its Python translation passed a 400-sample numerical comparison against the actual original JavaScript. Original core *never* gets a modified weight.
- **Ripple photoreceptor v0.6:** real archived logarithmic light preprocessor executes on normalized RGB. It is an **external pathway**; raw Ripple spikes remain separately visible.
- **Ripple-Q v0.7:** real archived four-symbol data computer/16-opcode restricted program engine produces `-1`, `-0`, `0`, `1` states; it never runs unrestricted JavaScript. Signed zero is a symbolic encoding, not four floating-point binary zeros.
- **Digital ancestry & external weights:** 4 archived color species plus 5 selected archived v1.2 hybrid profiles are loaded with exact lineage markers. Gains, source-preference weights, budget and spatial-parameter annotations become **separate Master genome records**, hashed using SHA-256. The 9 profiles are not scientific winners.
- **Sensory gateway:** two magnetic-vector shapes (`8 x 3` and `3`), RGB, motion, lux, and pose-tagged range rays; each with explicit units, monotonic timestamps and stated acquisition provenance. Invalid/missing channels are unavailable, not filled with fake data.
- **Web optical sense:** user-triggered webcam capture from a browser (permission required) plus opt-in phone motion and browser-exposed magnetometer/lux sensors where available. Local export as `.jsonl`. The code has been browser-tested with mocked pixels; no real camera/magnetometer was tested here.
- **Finite temporal modulation:** the **unchanged Ripple-Q v0.7 DFT** calculates regular-sampled frequency, up to Nyquist. It estimates fluctuations in sampled sensor values, not optical carrier or human electromagnetic frequencies.
- **Spatial model:** the *original* v1.0 conservative diffusion + occlusion + density model runs with `--spatial-regression`, and a new log-odds range-ray occupancy grid provides read-only 2D spatial mapping when sensor pose and ranges are explicitly supplied. A synthetic map is not verified navigation.
- **Colony:** finite 1–8 workers, deterministic queue and internal event dispatch. Tasks remain audit events; **no command execution, robot actuation, unapproved cloud action, or autonomous external JS**.
- **Bounded mutation:** if at least 24 valid same-type sensor observations exist, a new candidate can be proposed by a capped step in an external color gain or sensory-priority weight. The original neuron stays unchanged. Candidate weights **are not auto-applied**.
- **Source archive:** 12 unchanged ZIP packages, hashed and integrity checked; active source files separately SHA-256 locked.

## Start the computer/browser sense station

Run from the unzipped folder with **Python 3.10+**:

```bash
python Start_Master_Ripple.py
```

Open the printed `http://127.0.0.1:8787/web/index.html` address, select a genome and click **Start camera**. The program requests a camera permission only when you click. A generic-sensor magnetometer, ambient-light sensor, and motion events may be unavailable due to browser/device permissions.

**Android:** The browser application must be served from an **HTTPS origin**, or from a supported secure local context, for camera permission. Opening HTML from an Android file viewer is not sufficient. No Android APK or remote site has been built by this release.

## Offline analytical engine

Requires Python, NumPy and Node.js 18+ (the original JS engine is actually executed). Matplotlib is optional for producing plots.

```bash
python -m pip install numpy matplotlib
python src/verify_sources.py
python src/master.py --input fixtures/master_mixed_simulated.jsonl --genome prism --propose-child --spatial-regression
python src/master.py --genome tidal-50-mutant --no-photoreceptor --output results/alternate.json
python src/study.py
python -m unittest discover -s tests -p test_master.py -v
python tests/browser_smoke.py
```

### Input schema

One JSON object per line:

```json
{"schema":"ripple-master/2.0","kind":"optical_rgb","source":"simulated","t_ms":100,"unit":"normalized_rgb_roi","values":[0.3,0.2,0.1]}
```

Other types:

| kind | unit | values | What it really represents |
|---|---|---|---|
| `optical_rgb` | `normalized_rgb_roi` | `[R,G,B]` in `[0,1]` | sensor/browser camera pixel channel averages, uncalibrated |
| `magnetometer` | `microtesla` | `8 x 3` finite vectors | FieldSphere geometry data *in local axes* unless externally calibrated |
| `magnetometer_xyz` | `microtesla` | `[x,y,z]` | one magnetometer, e.g. browser if supported |
| `accelerometer` | `m/s2` | finite scalar | measured (or reported) acceleration magnitude |
| `ambient_light` | `lux` | nonnegative scalar | reported illuminance |
| `range_ray` | `meters_and_radians` | `{x_m,y_m,angle_rad,range_m,max_range_m}` | range with assumed sensor pose; missing pose is rejected |

`source` must be `simulated` or `hardware_reported_unverified`. Self-reported hardware status does **not** certify calibration, instrument existence or data provenance. Mixed simulated and hardware records for the *same* channel within one run are rejected. Different channels may have different source statuses and are separately labeled. Historical formats remain usable through their **preserved** original tools.

## Scientific methods and hard limits

The neuron follows the approved `D = 2R + 1.2G − 1.4B`, `0.5 du/dt = −u + D`, 0.1 second refractory interval, and original bounded feedback. These are **source invariants**; none of the Master's learned-style overlays rewrite them.

The numerical diffusion model is a synthetic conservative grid with no-flux edges and explicit time-step bounds. Density is a **synthetic normalized field**, not inferred physical mass density. Occlusion represents baffles/masks and never reconstructs unseen spaces.

The range-ray map is a conventional bounded Bayesian-log-odds-style inverse sensor model with declared tuning parameters. Its cells describe inferred occupancy from rays only, not a verified 3D reconstruction or an accurately mapped real environment.

Sensory reliability updates are bounded normalization of **timestamp regularity**, not learned physical truth. Unit-specific changes can trigger dimensionless internal dispatch priorities only after their own explicitly chosen thresholds. Those thresholds are research engineering preferences; they are not calibrated sensitivity limits.

## Research and test results (executed)

- **Master regressions:** 46/46 passing, including a 400-sample original JS/Python numeric parity test, genotype checksum, unit rejection, 8x3/3x1 magnetometer guards, missing sensor refusal, 256-byte reversible quaternary packing, conservative diffusion, bounded colony, and log-odds occlusion.
- **Preserved Alpha v1.3 regressions:** 27/27 passing from its original source tree.
- **Preserved Ripple-Q v0.7 regressions:** 11/11 passing from clean extracted historical ZIP.
- **Controlled comparisons:** 9 inherited Master configurations × 2 external photoreceptor conditions × 4 independent synthetic input seeds = 72 runs; two comparison seeds held out from the new *study script's* development seeds. They have not been physically measured and are not proof of universal superiority. Original LIF had 15 events on both independent seeds; weighted profiles had 11–17.
- **Mixed synthetic record:** 120 time samples each for RGB, eight-channel magnetism, motion, lux; 16 original LIF events and 15 prism-weighted LIF events; colony 64 dispatched internal audit tasks under its event budget. This simulation does **not** contain live sensor readings.
- **Browser UI:** headless Chromium with *mocked video pixels and inlined original JS*. Local navigation is blocked in the execution sandbox, so HTTPS/localhost integration was not validated there. UI renders at mobile and desktop widths and controlled export/stop worked in the mock.
- **Frozen source integrity:** 9 source/ledger SHA-256 checks + 12 original-archive SHA-256 and ZIP-integrity checks passed.

## Scope exclusions

No automatic public deployment, model training, external system execution, real magnetic-field validation, physiological diagnosis, consciousness detection, optical-carrier sensing or aura detection. New monochrome research was deliberately **not reopened**: only the approved earlier spatial model is used for compatibility regressions.

## Source code and provenance

- `src/master.py`, `src/occupancy.py`, `src/study.py`: new Master additions.
- `src/js_signal_runner.cjs`: calls archived JavaScript LIF, photoreceptor and QuadVM.
- `src/frequency_runner.mjs`: calls archived Ripple-Q temporal-frequency code.
- `web/index.html` + `web/genomes.json`: local webcam interface with optional supported sensors.
- `legacy/`: exact selected prior sources, their checksums in `docs/FROZEN_SOURCE_LOCK.json`.
- `frozen_archives/`: original ZIPs (not globally licensed as MIT), with archive hashes in `docs/FROZEN_ARCHIVES.json`.
- `results/`: reproducible real software test output and synthetic study data; `docs/` describes the limits.

## Scientific references

See `docs/SCIENTIFIC_BASIS.md`. Scientific methods are not represented as newly discovered physical phenomena. This project's novel contribution is its particular **transparent, bounded integration** of the user's prior Ripple experiments into a single auditable software workbench.
