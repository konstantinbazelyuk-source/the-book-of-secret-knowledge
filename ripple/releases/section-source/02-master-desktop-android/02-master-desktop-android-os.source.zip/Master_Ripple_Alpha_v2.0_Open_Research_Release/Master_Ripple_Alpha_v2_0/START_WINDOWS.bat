@echo off
cd /d "%~dp0"
py Start_Master_Ripple.py
pause
