const fs=require('fs');const vm=require('vm');const path=require('path');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'web/Charlie_Colony_Thought_Replay.html'),'utf8');
const src=html.match(/<script>([\s\S]*?)<\/script>/i)?.[1];if(!src)throw Error('embedded JS not found');
const els={};
const document={getElementById(id){if(!els[id])els[id]={innerHTML:'',textContent:'',className:'',disabled:false,callbacks:{},addEventListener(ev,fn){this.callbacks[ev]=fn}};return els[id]}};
vm.runInNewContext(src,{document,console},{timeout:3000});
if(els['position'].textContent!=='Step 1/4')throw Error('wrong initial step');
if(els['decision'].textContent!=='REQUEST_NEW_SCAN')throw Error('wrong initial action');
if(!els['thought'].innerHTML.includes('Observe')){} // uppercase is irrelevant, content is actually lowercase.
els['next'].callbacks.click();if(els['decision'].textContent!=='MOVE_RIGHT_SIMULATED')throw Error('wrong second action');
els['next'].callbacks.click();if(els['decision'].textContent!=='REQUEST_NEW_SCAN')throw Error('wrong third action');
els['next'].callbacks.click();if(els['decision'].textContent!=='MOVE_RIGHT_SIMULATED'||!els['next'].disabled)throw Error('wrong final action');
els['prev'].callbacks.click();if(els['decision'].textContent!=='REQUEST_NEW_SCAN')throw Error('wrong back action');
if(!els['benchmark'].innerHTML.includes('193'))throw Error('balanced study data missing');
console.log('OFFLINE VIEWER JS SMOKE: PASS, 4-step stepping, counterfactuals and benchmark data loaded');
