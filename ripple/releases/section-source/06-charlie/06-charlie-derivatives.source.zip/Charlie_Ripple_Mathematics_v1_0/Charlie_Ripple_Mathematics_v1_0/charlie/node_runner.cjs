'use strict';
// Run actual frozen JavaScript code, never generated/evaled policy contents.
const fs=require('node:fs'), vm=require('node:vm'),path=require('node:path');
const base=path.join(__dirname,'..','legacy');
vm.runInThisContext(fs.readFileSync(path.join(base,'ripple-core.js'),'utf8'),{filename:'legacy/ripple-core.js'});
const {Photoreceptor}=require(path.join(base,'photoreceptor-v06.js'));
const input=JSON.parse(fs.readFileSync(0,'utf8'));
if(!['raw','photoreceptor'].includes(input.mode))throw Error('invalid optical mode');
if(!Array.isArray(input.samples)||input.samples.length>10000)throw Error('samples cap');
const count=8;
const nodes=Array.from({length:count},()=>new globalThis.RippleNeuron());
const light=Array.from({length:count},()=>new Photoreceptor());
const spikes=Array(count).fill(0),edges=[],thresholds=[];
for(let j=0;j<input.samples.length;j++){
  const s=input.samples[j];
  if(s.provenance!=='simulated'||s.unit!=='normalized_rgb'||s.calibrated!==false)throw Error('source/units/calibration contract violated');
  if(!Number.isFinite(s.dt)||s.dt<=0||s.dt>.5||!Array.isArray(s.tiles)||s.tiles.length!==8)throw Error('invalid clock/tiles');
  for(let i=0;i<count;i++){
    const x=s.tiles[i];if(!Array.isArray(x)||x.length!==3||x.some(z=>!Number.isFinite(z)||z<0||z>1))throw Error('not normalized');
    const transformed=input.mode==='raw'?x:light[i].step(x,s.dt).output;
    const out=nodes[i].step(transformed,s.dt);
    spikes[i]+=out.count;
    if(out.count)edges.push({sample:j,node:i,count:out.count,t:out.t});
  }
  if(j%20===0)thresholds.push({t:nodes[0].t,theta:nodes[0].theta,rate:nodes[0].rate});
}
const result={mode:input.mode,frames:input.samples.length,logical_neurons:8,spikes,final_theta:nodes.map(n=>n.theta),total_spikes:spikes.reduce((a,b)=>a+b,0),events:edges,thresholds,original_js_executed:true,calibrated_hardware:false};
process.stdout.write(JSON.stringify(result));
