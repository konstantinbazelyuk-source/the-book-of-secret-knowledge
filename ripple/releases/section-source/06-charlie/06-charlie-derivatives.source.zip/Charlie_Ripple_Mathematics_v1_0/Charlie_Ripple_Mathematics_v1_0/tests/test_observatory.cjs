// JavaScript smoke test with simulated DOM, not an actual browser rendering test.
const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');
const html=fs.readFileSync(path.join(__dirname,'..','Formula_Observatory.html'),'utf8');
const match=html.match(/<script>([\s\S]*?)<\/script>/);
assert(match,'script embedded');
class E{constructor(id){this.id=id;this.children=[];this.value='';this.textContent='';this.listeners={};this.className=''}
 append(...xs){this.children.push(...xs)}
 replaceChildren(...xs){this.children=xs}
 addEventListener(n,fn){this.listeners[n]=fn}
}
const ids=new Map();const document={getElementById:id=>{if(!ids.has(id))ids.set(id,new E(id));return ids.get(id)},createElement:t=>new E(t)};
vm.runInNewContext(match[1],{document,console});
assert.equal(+ids.get('statf').textContent,56);
assert.equal(ids.get('list').children.length,56);
ids.get('family').value='motor';ids.get('family').listeners.input();
assert.equal(ids.get('list').children.length,6);
ids.get('query').value='nonexistent-signal';ids.get('query').listeners.input();
assert.equal(ids.get('list').children.length,1);
console.log('Observatory JavaScript smoke: 56 records / motor filter 6 / no-match feedback PASS');
