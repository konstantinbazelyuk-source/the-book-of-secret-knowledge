const fs=require('node:fs');const vm=require('node:vm');const assert=require('node:assert/strict');
const html=fs.readFileSync('web/Charlie_Daughter_Delta_Colony_Replay.html','utf8');
const m=/<script>([\s\S]*?)<\/script>/.exec(html);assert.ok(m,'inline replay required');
const nodes={};const context={document:{getElementById(id){if(!nodes[id])nodes[id]={innerHTML:'',textContent:'',value:0,max:0,style:{},getContext(){return {clearRect(){},setLineDash(){},beginPath(){},moveTo(){},lineTo(){},stroke(){}}},addEventListener(){}};return nodes[id];}},setInterval(){return 1},clearInterval(){},console};
vm.runInNewContext(m[1],context,{timeout:2000});
assert.match(nodes.time.textContent,/Frame 0/);nodes.next.onclick();assert.match(nodes.time.textContent,/Frame 1/);nodes.back.onclick();assert.match(nodes.time.textContent,/Frame 0/);nodes.play.onclick();nodes.play.onclick();
assert.ok(nodes.summary.textContent.includes('full 12/12'));
console.log('PASS: replay script parsed and exercised with synthetic DOM; actual browser visual rendering not tested.');
