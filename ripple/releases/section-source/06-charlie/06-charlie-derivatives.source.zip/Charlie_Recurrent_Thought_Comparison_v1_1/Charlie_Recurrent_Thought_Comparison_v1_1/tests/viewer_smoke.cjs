const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'../web/Charlie_Dynamic_Replay.html'),'utf8');
const data=html.match(/<script id="state-data" type="application\/json">([\s\S]*?)<\/script>/)?.[1];
assert(data,'embedded state');const parsed=JSON.parse(data);assert.equal(parsed.representative.length,76);
let code=html.match(/<script>\s*([\s\S]*?)<\/script>/)?.[1];assert(code,'viewer JavaScript');
const store={};function mk(name){return store[name]??= {textContent:'',value:'0',children:[],appendChild(o){this.children.push(o)},getContext(){return {fillRect(){},beginPath(){},moveTo(){},lineTo(){},stroke(){},fillText(){},setLineDash(){}}}};}
mk('state-data').textContent=data;
for(const id of ['plot','step','idx','back','next','play','pause','action','time','left','right','spikes','abl','reason','metrics','case','comparison'])mk(id);
const doc={getElementById:mk,createElement(){return {textContent:'',value:'',children:[],appendChild(o){this.children.push(o)}}}};
const context={document:doc, console,setInterval(fn){return fn},clearInterval(){}};
vm.runInNewContext(code,context,{timeout:4000});
assert.equal(mk('idx').textContent,1);assert(/REQUEST/.test(mk('action').textContent));
mk('next').onclick();assert.equal(mk('idx').textContent,2);
mk('step').oninput({target:{value:'63'}});assert.equal(mk('idx').textContent,64);
assert(mk('comparison').textContent.includes('ChatGPT'));
assert.equal(mk('metrics').children.length,4);
console.log('Offline viewer: embedded data valid, controls and canvas draw smoke PASS');
