"""Ripple v1.3 ProvenanceLab: classify generated monochrome states by INITIAL observability.

Replicates frozen v1.0 external field simulation exactly, checking output parity to
avoid attributing pre-existing monochrome transport to gene mutation.
"""
from __future__ import annotations
import dataclasses,itertools,json,math,hashlib,csv
from pathlib import Path
import numpy as np
from ripple_alpha import (
 SPECIES, Species, Conditions, LegacyRippleNeuron,check_conditions,make_world,
 flux_laplacian,monochrome_candidates,entropy_ratio,observe_field,run_one)
ROOT=Path(__file__).resolve().parents[1]


def trace_one(sp:Species,c:Conditions,verify=True):
    d=sp.diffusion_gain if c.diffusion else 0.
    check_conditions(c,d)
    field,density,blocked,nodes=make_world(c)
    neurons=[LegacyRippleNeuron() for _ in nodes]
    initial_total,initial_ent,initial_dom=entropy_ratio(field)
    initial_eligible=(initial_total>=.045)&(~blocked)
    initial_mono=monochrome_candidates(field,blocked)
    streak=np.zeros(blocked.shape,dtype=np.uint16)
    emerged=np.zeros(blocked.shape,dtype=bool)
    fire=0;loss_after_emergence=0
    snapshots=[];start=float(field.sum());first_step=None
    for t in range(c.steps):
        concentration=density if c.density else np.zeros_like(density)
        effective_diff=np.full(blocked.shape,d,dtype=float)*(1-.42*concentration)
        if c.occlusion:
            grid=np.indices(blocked.shape)[0]
            shadow=(grid>c.n*.51)&(np.indices(blocked.shape)[1]>.08*c.n)&(np.indices(blocked.shape)[1]<.83*c.n)
            attenuation=np.where(shadow,.993**sp.occlusion_gain,1.)
        else:
            attenuation=np.ones(blocked.shape)
        nxt=np.empty_like(field)
        for k in range(3):
            flow=flux_laplacian(field[k],blocked,effective_diff)
            absorb=np.maximum(0.,1.-c.dt*(sp.absorption*(1+.5*concentration)))
            nxt[k]=np.clip((field[k]+c.dt*flow)*absorb*attenuation,0,1)
            nxt[k][blocked]=0.
        field=nxt
        cand=monochrome_candidates(field,blocked)
        streak=np.where(cand&(~initial_mono),np.minimum(streak.astype(np.int32)+1,65535),0).astype(np.uint16)
        births=(streak>=5)&(~emerged)
        if births.any() and first_step is None:first_step=t
        emerged|=births
        for neuron,obs in zip(neurons,observe_field(field,nodes,sp.rgb_gain)):
            fire+=neuron.step(obs,c.dt)['count']
        if not np.isfinite(field).all() or field.min()<0:raise ArithmeticError('out of physical software bounds')
        if t in (0,c.steps//2,c.steps-1):snapshots.append({'step':t,'candidates':int(cand.sum()),'new_persistent_so_far':int(emerged.sum())})
    final_cand=monochrome_candidates(field,blocked)
    active_final=int(((field.sum(axis=0)>.045)&(~blocked)).sum())
    obj={
        'species':sp.name,'species_marker':sp.marker(),
        **dataclasses.asdict(c),'classification':'synthetic','new_persistent_ever':int(emerged.sum()),
        'new_from_initially_subthreshold':int((emerged&(~initial_eligible)).sum()),
        'new_from_initially_visible_polychromatic':int((emerged&initial_eligible&(~initial_mono)).sum()),
        'new_from_initially_visible_monochromatic':int((emerged&initial_mono).sum()),
        'new_still_monochromatic_at_end':int((emerged&final_cand).sum()),
        'new_no_longer_monochromatic_at_end':int((emerged&(~final_cand)).sum()),
        'initial_visible_cells':int(initial_eligible.sum()),'final_visible_cells':active_final,
        'initial_monochrome_cells':int(initial_mono.sum()),'first_new_monochrome_step':first_step,
        'neuron_events':int(fire),'final_intensity':float(field.sum()),
        'intensity_retained':float(field.sum()/start),'snapshot_metrics':snapshots}
    if obj['new_from_initially_subthreshold']+obj['new_from_initially_visible_polychromatic']!=obj['new_persistent_ever']:
        raise AssertionError('new event attribution not exhaustive')
    if obj['new_still_monochromatic_at_end']+obj['new_no_longer_monochromatic_at_end']!=obj['new_persistent_ever']:
        raise AssertionError('new event survival accounting not exhaustive')
    if verify:
        legacy=run_one(sp,c)['metrics']
        check_ints=(('monochrome_persistent_cells','new_persistent_ever'),('active_cells_final','final_visible_cells'),('events','neuron_events'))
        for k,new in check_ints:
            if legacy[k]!=obj[new]:raise AssertionError(f'baseline parity failed: {k}: {legacy[k]} != {obj[new]}')
        if not math.isclose(legacy['final_intensity'],obj['final_intensity'],abs_tol=1e-8,rel_tol=1e-9):
            raise AssertionError('baseline intensity mismatch')
    return obj

def study():
    rows=[]
    for dim in (2,3):
        n,steps=(22,40) if dim==2 else (12,22)
        for s in SPECIES:
            for seed in (41,43):
                for d,o,r in itertools.product((False,True),repeat=3):
                    rows.append(trace_one(s,Conditions(n=n,steps=steps,seed=seed,dim=dim,diffusion=d,occlusion=o,density=r),verify=True))
    grouped=[]
    for dim in (2,3):
        for d,o,r in itertools.product((False,True),repeat=3):
            selected=[x for x in rows if (x['dim'],x['diffusion'],x['occlusion'],x['density'])==(dim,d,o,r)]
            grouped.append({'dim':dim,'diffusion':d,'occlusion':o,'density':r,'trials':len(selected),
               **{'mean_'+k:float(np.mean([x[k] for x in selected])) for k in (
               'new_persistent_ever','new_from_initially_subthreshold','new_from_initially_visible_polychromatic',
               'new_still_monochromatic_at_end','new_no_longer_monochromatic_at_end','final_visible_cells')}})
    return {'schema':'ripple-provenancelab-study/3','classification':'synthetic',
            'experiment_count':len(rows),'groups':grouped,'records':rows,
            'clarifications':['monochrome status is calculated from relative synthetic RGB channels, not a new genotype',
              'initially subthreshold can contain tiny nonzero Gaussian field values',
              'first persistence does not imply persistence through end','diffusion dependence measured in this model only',
              'no external world, optical field or human aura measurement']}

def main():
    r=study();out=ROOT/'results';out.mkdir(exist_ok=True)
    (out/'provenance_study.json').write_text(json.dumps(r,indent=2,allow_nan=False)+'\n')
    with (out/'provenance_grouped.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(r['groups'][0]));w.writeheader();w.writerows(r['groups'])
    fields=['dim','species','seed','diffusion','occlusion','density','new_persistent_ever','new_from_initially_subthreshold','new_from_initially_visible_polychromatic','new_still_monochromatic_at_end','new_no_longer_monochromatic_at_end','neuron_events','intensity_retained']
    with (out/'provenance_trials.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows({k:x[k] for k in fields} for x in r['records'])
    for g in r['groups']:
        print('3D' if g['dim']==3 else '2D','diff',g['diffusion'],'occ',g['occlusion'],'den',g['density'],
            'new',round(g['mean_new_persistent_ever'],3),'previously subthreshold',round(g['mean_new_from_initially_subthreshold'],3))
    print('Baseline parity verified for',len(r['records']),'independent runs.')
if __name__=='__main__':main()
