# Browser verification

Version 1.3 dashboard was exercised at 410px mobile viewport using installed Chromium and Playwright. Inline HTML was loaded using about:blank and set_content because sandbox policy blocks navigating to file://. Tabs/selected gene/field summaries rendered; no JavaScript page errors were observed. This is a **headless browser test**, not a test of a real Android device or of network hosting.
