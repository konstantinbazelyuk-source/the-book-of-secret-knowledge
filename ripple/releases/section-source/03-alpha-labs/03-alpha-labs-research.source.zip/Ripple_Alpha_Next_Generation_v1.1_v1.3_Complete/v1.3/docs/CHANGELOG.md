# v1.3 changes
Includes earlier modules without behavior change; adds 128-run traced spatial emergence and survival classification with baseline parity, chart, and offline dashboard.
