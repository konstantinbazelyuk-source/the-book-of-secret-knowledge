from pathlib import Path
import sys,unittest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from provenancelab import *
class TestProvenance(unittest.TestCase):
 def test_core_parity(self):
  for s in SPECIES:
   for d in [False,True]:
    trace_one(s,Conditions(n=12,steps=12,seed=9,diffusion=d),verify=True)
 def test_subthreshold_split(self):
  r=trace_one(SPECIES[1],Conditions(n=22,steps=40,seed=41));self.assertEqual(
   r['new_persistent_ever'],r['new_from_initially_subthreshold']+r['new_from_initially_visible_polychromatic'])
 def test_initially_mono_never_new(self):
  r=trace_one(SPECIES[1],Conditions(n=22,steps=40,seed=41))
  self.assertEqual(r['new_from_initially_visible_monochromatic'],0)
 def test_diffusion_zero_no_new(self):
  r=trace_one(SPECIES[1],Conditions(n=22,steps=40,seed=41,diffusion=False))
  self.assertEqual(r['new_persistent_ever'],0)
 def test_3d_parity(self):
  r=trace_one(SPECIES[2],Conditions(n=12,steps=22,seed=41,dim=3),verify=True)
  self.assertEqual(r['dim'],3)
 def test_disappearance_account(self):
  r=trace_one(SPECIES[3],Conditions(n=22,steps=40,seed=43),verify=True)
  self.assertEqual(r['new_persistent_ever'],r['new_still_monochromatic_at_end']+r['new_no_longer_monochromatic_at_end'])
if __name__=='__main__':unittest.main()
