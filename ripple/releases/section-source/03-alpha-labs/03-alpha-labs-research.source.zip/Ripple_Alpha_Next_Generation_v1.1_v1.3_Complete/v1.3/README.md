# Ripple Alpha v1.3 — ProvenanceLab

**Execution status:** runnable Alpha research, not a physical prototype. Contains v1.1 TraceGate and v1.2 HybridLineage as working, unchanged preceding modules.

This version replicates the v1.0 environment update with a separate provenance tracer. The tracer checks **exact output parity** against the original `run_one` model for all 128 study runs and classifies newly persistent monochrome states into:

- Locations whose initial total channel signal was **below the original 0.045 threshold**, even if their Gaussian field was not exactly zero.
- Locations initially **visible and non-monochrome**.
- States that were new and remained monochrome at the final step, versus states that later stopped being monochrome.

All runs retain the original entropy <0.40, dominant fraction >0.87, minimum intensity 0.045, and five-consecutive-step candidate threshold. Neither genotype nor original neuron is updated by the spatial label.

### New experiments

4 species × 2 random seeds (41,43) × 2 dimensions (2D and 3D) × 2 diffusion × 2 occlusion × 2 density = **128 runs**. Model size is 22×22 for 2D, and 12×12×12 for 3D. These are independently repeatable **synthetic** experiments and cannot be directly compared to the old v1.0 grid-size/step protocol.

### Reproduce

```sh
python -m pip install numpy matplotlib
python src/tracegate.py mag examples/fieldsphere_synthetic_coil.jsonl
python src/hybridlineage.py
python src/provenancelab.py
python -m unittest discover -s tests -v
```

Open **`Ripple-Next-Alpha-Dashboard.html`** to inspect the data completely offline. No external calls, hardware control or trained AI models are used.

### Results and negative findings

- Of **1,511** newly persistent monochrome observations across all trials, **1,511** originated at locations initially below threshold; **zero** began as visible multicolored locations.
- **Eight** of those 1,511 no longer met the monochrome condition at the final step, showing why `ever_persistent` and `still_at_end` must be different metrics.
- No physical magnetism, radiation or optical field was measured. No novel intelligence, natural language reasoning, biological mutation, or consciousness was demonstrated. This software is a transparent mechanism experiment, not a claim about an aura.

### What should come next

A conditional v1.4 could ingest independently calibrated **hardware** vectors and optical intensities with uncertainty and explicit sampling metadata. That stage must be tested against known coil waveforms and optical sources before any physical reconstruction is claimed. It is not part of this release.

## License
New Alpha-stage extensions: MIT license in `LICENSE`. Archived older files retain their own terms.
