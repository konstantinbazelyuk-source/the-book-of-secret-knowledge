# Ripple Alpha v1.1 — TraceGate

**Execution status:** runnable Alpha-stage read-only acquisition and quality-gate software. **No new physical measurements.**

The archived FieldSphere sample is simulated, not a real magnetic measurement. Original Ripple v1.0 class and original v0.1 JS neuron are copied byte-for-byte and verified. This version adds:

- Unit-safe, provenance-checked **8 × 3 magnetic vector** intake in µT; cannot infer field inside the sphere or the light magnetic carrier.
- Optional external hard/soft-iron and orientation calibration matrices with shape, invertibility and orthonormality checks. Configuration statements are **not independently verified calibration certificates**.
- Independent **RGB optical ROI** channel integrated with the original, unchanged Ripple neuron.
- Rejection of mixed measured/synthetic labels, nonfinite data, non-monotone timestamps and out-of-range readings. Explicit flags for irregular sampling, low sample counts and uncalibrated vectors.

## Run (Python 3.10+)

```sh
python -m pip install numpy
python src/tracegate.py mag examples/fieldsphere_synthetic_coil.jsonl --output results/magnetic_demo.json
python src/tracegate.py optical examples/synthetic_optical.jsonl --output results/optical_demo.json
python -m unittest discover -s tests -v
```

`kind=hardware` is always reported as `hardware_reported_unverified`: labeling a file is not a physical measurement or calibration. No camera images, network data or device actions are collected automatically.

## Prior files

The original v1.0 source is `src/ripple_alpha.py`; the original JS is `frozen/ripple_v03_reference.js` and `preserved/ripple_v03_reference.js`. Full prior archives are maintained in the original v1.0 ZIP, not replaced. No original equations are changed.

## License
New Alpha-stage extensions: MIT license in `LICENSE`. Archived older files retain their own terms.
