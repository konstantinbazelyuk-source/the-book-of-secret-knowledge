import unittest,json,tempfile,sys,subprocess,hashlib,shutil
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from ripple_alpha import LegacyRippleNeuron
class CoreParity(unittest.TestCase):
 def test_original_unchanged(self):
  self.assertEqual(hashlib.sha256((ROOT/'frozen'/'ripple_v03_reference.js').read_bytes()).hexdigest(),"d75d4208e92f19623b127615bd52b4002e85d2c0a59b76471764b55a24294210")
 @unittest.skipUnless(shutil.which('node'), 'Node is needed for independent JS parity')
 def test_original_js_python_agreement(self):
  rng=np.random.default_rng(20261014)
  examples=[(rng.uniform(-.2,1.2,3).tolist(),float(rng.uniform(.02,.2))) for _ in range(128)]
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'x.json';p.write_text(json.dumps(examples))
   got=json.loads(subprocess.check_output(['node',str(ROOT/'src'/'parity_runner.cjs'),str(p)],text=True))
  n=LegacyRippleNeuron()
  for (rgb,dt),record in zip(examples,got):
   my=n.step(rgb,dt)
   for k in ['u','t','theta','rate','drive']:
    self.assertAlmostEqual(my[k],record[k],delta=3e-9)
   self.assertEqual(my['count'],record['count'])
if __name__=='__main__':unittest.main()
