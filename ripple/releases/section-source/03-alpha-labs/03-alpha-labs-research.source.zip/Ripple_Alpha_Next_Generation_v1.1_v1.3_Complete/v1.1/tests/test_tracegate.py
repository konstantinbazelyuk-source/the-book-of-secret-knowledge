import json,tempfile,sys,unittest
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parents[1];sys.path.insert(0,str(HERE/'src'))
from tracegate import *
from ripple_alpha import SPECIES,LegacyRippleNeuron
class TraceGateTest(unittest.TestCase):
 def mk(self,kind='simulated',field='mag_uT',n=35):
  d=tempfile.TemporaryDirectory();p=Path(d.name)/'x.jsonl'; data=[]
  for k in range(n):
   vals=(np.ones((8,3))*[12,-6,40]).tolist() if field=='mag_uT' else [0.3,0.6,0.1]
   data.append(dict(kind=kind,t_ms=k*100.,**{field:vals}))
  p.write_text('\n'.join(json.dumps(x) for x in data));return d,p
 def test_mag_full(self):
  d,p=self.mk();r=analyze_magnetic(p);self.assertEqual(r['classification'],'simulated');self.assertIn('calibration_unavailable',r['quality_flags']);self.assertNotIn('interior_field',r);d.cleanup()
 def test_optical_original(self):
  d,p=self.mk(field='rgb_roi');r=analyze_optical(p);self.assertGreaterEqual(r['legacy_neuron_events'],0);self.assertEqual(r['unit'],'normalized_RGB_ROI');d.cleanup()
 def test_hardware_is_not_verified(self):
  d,p=self.mk(kind='hardware');r=analyze_magnetic(p);self.assertEqual(r['classification'],'hardware_reported_unverified');d.cleanup()
 def test_mixed_rejected(self):
  d,p=self.mk();lines=p.read_text().splitlines();x=json.loads(lines[-1]);x['kind']='hardware';lines[-1]=json.dumps(x);p.write_text('\n'.join(lines))
  with self.assertRaises(ValueError):analyze_magnetic(p)
  d.cleanup()
 def test_missing_rejected(self):
  d,p=self.mk();x=json.loads(p.read_text().splitlines()[0]);x['mag_uT'][0][0]=None;p.write_text(json.dumps(x))
  with self.assertRaises((ValueError,TypeError)):analyze_magnetic(p)
  d.cleanup()
 def test_unsorted_time_rejected(self):
  d,p=self.mk();lines=p.read_text().splitlines();x=json.loads(lines[-1]);x['t_ms']=0;lines[-1]=json.dumps(x);p.write_text('\n'.join(lines))
  with self.assertRaises(ValueError):analyze_magnetic(p)
  d.cleanup()
 def test_saturation_rejected(self):
  d,p=self.mk();x=json.loads(p.read_text().splitlines()[0]);x['mag_uT'][0][0]=5001;p.write_text(json.dumps(x))
  with self.assertRaises(ValueError):analyze_magnetic(p)
  d.cleanup()
 def test_calibration_rotation_guard(self):
  d,p=self.mk();c=Path(d.name)/'cal.json';c.write_text(json.dumps({'schema':'ripple-magnetic-calibration/1','bias_uT':np.zeros((8,3)).tolist(),'softiron_inverse':np.tile(np.eye(3),(8,1,1)).tolist(),'sensor_to_world':np.tile(np.eye(3),(8,1,1)).tolist(),'evidence':'synthetic identity'}))
  r=analyze_magnetic(p,c);self.assertNotIn('calibration_unavailable',r['quality_flags'])
  obj=json.loads(c.read_text());obj['sensor_to_world'][0][0][0]=2;c.write_text(json.dumps(obj))
  with self.assertRaises(ValueError):analyze_magnetic(p,c)
  d.cleanup()
 def test_original_equation_preserved(self):
  n=LegacyRippleNeuron();self.assertAlmostEqual(n.step([1,.5,.1],.08)['drive'],2+1.2*.5-1.4*.1)
 def test_distinct_species(self):self.assertEqual(len({s.marker() for s in SPECIES}),4)
if __name__=='__main__':unittest.main()
