# Relevant established foundations (not claimed as novel inventions)

- Laumanns, Thiele, Deb & Zitzler (2002), epsilon-dominance, convergence and diversity in multiobjective optimization. https://pubmed.ncbi.nlm.nih.gov/12227996/
- Pang et al. (2016), three-axis magnetometer calibration/disturbance correction. https://doi.org/10.1016/j.measurement.2016.06.056
- Analog Devices EngineerZone, hard/soft iron correction and orientation calibration: https://ez.analog.com/mems/a/documents/do19172/faq-hard-soft-iron-correction-for-magnetometer-measurements
- Frozen Ripple v0.5 MATHEMATICAL_CODEX.md from the user's earlier archive; original derivative formulas retained unchanged.

No claim of inventing Pareto optimization, magnetometer calibration, finite-volume diffusion, or optical heterodyne physics. All improvements here are local software research extensions.
