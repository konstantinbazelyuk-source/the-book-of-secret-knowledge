# Evidence and claims register

**Direct measurements**: source-file hash checks, runtime tests, computation outputs, generated archives and measured execution results from this computer.

**Calculated from given simulation**: model concentration, relative entropy, diffusion cell count, numerical sensor vector magnitude, mutation lineage and comparisons.

**Simulated**: all magnetometer logs supplied here, all RGB light stimulus series, density, diffusion and spatial event counts.

**Unverified external reporting**: any future `kind=hardware` text cannot establish whether a real sensor was used, calibrated or located where claimed.

**Not established**: AI reasoning or autonomy gains, new physical field effects, aura imaging, conscious agency, photon field oscillation measurement, gamma/beta/theta detection, proof of causation outside the numerical model, genuine genome creation or machine learning of weights.

The sensor module intentionally uses separate µT magnetic vectors and normalized RGB fields. A label or plotted color is not a physical calibration. The original neuron and past archives are frozen. No device permissions, camera capture, cloud compute, software outsourcing or online deployment was performed in these executions.
