# v1.1 changes
Added TraceGate (unit-safe magnetic and optical channels) and new calibration/quality tests. No original edits.
