"""Ripple Alpha v1.1 TraceGate: provenance-aware read-only sensor pipeline.

Does not translate magnetic microtesla readings into camera RGB or interior field maps.
Does not authorize hardware control. Source classification is not a measurement certificate.
"""
from __future__ import annotations
import hashlib, json, math
from pathlib import Path
import numpy as np
from ripple_alpha import LegacyRippleNeuron

MAX_FRAMES=4096
MAX_FILE_BYTES=6_000_000

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def _rows(path, kindset, expected):
    path=Path(path)
    if path.stat().st_size>MAX_FILE_BYTES: raise ValueError('file size limit')
    lines=path.read_text().splitlines()
    if not (1<=len(lines)<=MAX_FRAMES): raise ValueError('frame count limit')
    rows=[];mode=None;last=-math.inf
    for ix,line in enumerate(lines,1):
        if not line.strip():continue
        rec=json.loads(line)
        if rec.get('kind') not in kindset:raise ValueError(f'line {ix}: acquisition kind unavailable')
        if mode is None:mode=rec['kind']
        if mode!=rec['kind']:raise ValueError('cannot mix reported hardware and simulated acquisition')
        t=rec.get('t_ms')
        if not isinstance(t,(int,float)) or isinstance(t,bool) or not math.isfinite(t) or t<=last:
            raise ValueError('timestamp not finite and increasing')
        last=t
        data=np.asarray(rec.get(expected),dtype=float)
        if not np.all(np.isfinite(data)):raise ValueError('missing or nonfinite reading: not converted to zero')
        rows.append((float(t),data))
    if not rows:raise ValueError('no data')
    return mode,np.asarray([r[0] for r in rows]),np.stack([r[1] for r in rows])

def calibration_from_json(path):
    """External affine calibration and orientation. Never estimated from a single sample."""
    obj=json.loads(Path(path).read_text())
    if obj.get('schema')!='ripple-magnetic-calibration/1':raise ValueError('calibration schema')
    bias=np.asarray(obj.get('bias_uT'),float)
    mat=np.asarray(obj.get('softiron_inverse'),float)
    rot=np.asarray(obj.get('sensor_to_world'),float)
    if bias.shape!=(8,3) or mat.shape!=(8,3,3) or rot.shape!=(8,3,3):raise ValueError('calibration shapes')
    if not (np.isfinite(bias).all() and np.isfinite(mat).all() and np.isfinite(rot).all()):raise ValueError('nonfinite calibration')
    for i in range(8):
        if np.linalg.det(mat[i])<=.01 or np.linalg.cond(mat[i])>100:raise ValueError('ill-conditioned calibration')
        if not np.allclose(rot[i].T@rot[i],np.eye(3),atol=1e-5) or not np.isclose(np.linalg.det(rot[i]),1.,atol=1e-5):
            raise ValueError('rotation is not a valid orientation')
    return {'bias':bias,'soft':mat,'rot':rot,'sha256':digest(path),
            'statement':obj.get('evidence','no external validation statement supplied')}

def analyze_magnetic(path,calibration=None):
    mode,ts,x=_rows(path,{'simulated','hardware'},'mag_uT')
    if x.shape[1:]!=(8,3):raise ValueError('expected 8 x 3 magnetic vectors per sample')
    if np.any(np.abs(x)>5000):raise ValueError('outside nominal sensor range, no clipping')
    intervals=np.diff(ts)
    dt_cv=float(np.std(intervals)/np.mean(intervals)) if len(intervals) else None
    quality=[]
    if len(ts)<24:quality.append('insufficient_samples_for_variance_estimate')
    if dt_cv is not None and dt_cv>.1:quality.append('irregular_sampling_over_10_percent')
    if calibration:
        cal=calibration_from_json(calibration)
        xc=np.einsum('nij,tnj->tni',cal['soft'],x-cal['bias'])
        xc=np.einsum('nij,tnj->tni',cal['rot'],xc)
        view='calibration_applied_reported_world_axes'
    else:
        cal=None;xc=x.copy();view='raw_local_sensor_axes_not_globally_comparable';quality.append('calibration_unavailable')
    variance=np.std(xc,axis=0,ddof=1) if len(ts)>1 else np.full((8,3),np.nan)
    report={'schema':'ripple-tracegate-magnetic/1','classification':('simulated' if mode=='simulated' else 'hardware_reported_unverified'),
      'input_sha256':digest(path),'sensor_count':8,'frame_count':len(ts),'unit':'microtesla',
      'median_delta_ms':float(np.median(intervals)) if len(intervals) else None,
      'timing_cv':dt_cv,'status':'quality_restricted' if quality else 'processed_calibration_metadata_unverified',
      'quality_flags':quality,'coordinate_frame':view,
      'mean_magnitude_uT':np.linalg.norm(xc,axis=2).mean(axis=0).tolist(),
      'component_sd_uT':variance.tolist() if len(ts)>1 else None,
      'calibration_sha256':cal['sha256'] if cal else None,
      'calibration_evidence_statement_unverified':cal['statement'] if cal else None,
      'not_inferred':['interior_3d_field','aura','light_magnetic_component','brain_state','calibration_validity']}
    return report

def analyze_optical(path):
    mode,ts,x=_rows(path,{'simulated','hardware'},'rgb_roi')
    if x.shape[1:]!=(3,):raise ValueError('optical input must have 3 RGB ROI floats')
    if np.any((x<0)|(x>1)):raise ValueError('RGB outside normalized [0,1]')
    intervals=np.diff(ts)
    quality=[]
    if len(ts)<2:quality.append('insufficient_frames')
    if len(intervals) and float(np.std(intervals)/np.mean(intervals))>.1:quality.append('irregular_timing')
    if len(intervals) and np.any(intervals>500):quality.append('dt_over_neuron_limit')
    neuron=LegacyRippleNeuron(); events=0
    for i in range(1,len(ts)):
        dt=float(intervals[i-1]/1000.)
        if dt<=0 or dt>.5:continue
        events+=neuron.step(x[i],dt)['count']
    return {'schema':'ripple-tracegate-optical/1','classification':'simulated' if mode=='simulated' else 'hardware_reported_unverified',
      'input_sha256':digest(path),'frame_count':len(ts),'unit':'normalized_RGB_ROI','legacy_neuron_events':events,
      'mean_rgb':x.mean(axis=0).tolist(),'quality_flags':quality,
      'note':'Recorded/claimed RGB is display-referred uncalibrated; original Ripple neuron equations unchanged. Optical data never substitute for magnetic vectors.'}

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('kind',choices=['mag','optical']);p.add_argument('input');p.add_argument('--calibration');p.add_argument('--output')
    a=p.parse_args()
    result=analyze_magnetic(a.input,a.calibration) if a.kind=='mag' else analyze_optical(a.input)
    out=json.dumps(result,indent=2,allow_nan=False)+'\n'
    if a.output:Path(a.output).write_text(out)
    print(out)
