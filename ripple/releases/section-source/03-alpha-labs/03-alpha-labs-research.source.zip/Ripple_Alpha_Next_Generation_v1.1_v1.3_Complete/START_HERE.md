# Ripple Alpha — Next Research Versions (v1.1, v1.2, v1.3)

Each `v1.x/` is a self-contained Alpha research release. Begin with `v1.3/Ripple-Next-Alpha-Dashboard.html`, then `v1.3/README.md` to run the source.

- v1.1 `TraceGate`: physically typed, read-only magnetometer/optical intake and calibration guardrails.
- v1.2 `HybridLineage`: 18 finite synthetic crossover/mutation candidates, 5 selected Pareto-front variants with holdout evaluation.
- v1.3 `ProvenanceLab`: 128 traced ablation runs, source parity, newly persistent monochrome attribution and survival.

`PREVIOUS_APPROVED_ARCHIVE/` holds the **exact unchanged v1.0 ZIP** with the earlier frozen Ripple archives. Past versions are not modified.

No physical fields were measured, no consciousness or intelligence gains were demonstrated, no network/cloud outsourcing or live system deployment was performed. All new code is MIT. Archived sources retain their previous license.

Run within a version directory:

```sh
python -m pip install numpy
python -m unittest discover -s tests -v
python src/provenancelab.py  # v1.3 only
```
