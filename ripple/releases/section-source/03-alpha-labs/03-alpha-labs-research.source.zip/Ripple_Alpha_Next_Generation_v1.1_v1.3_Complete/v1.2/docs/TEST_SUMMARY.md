# Extracted-package execution audit

- Test result: **21 automated Python tests passed** after extracting the standalone ZIP into a new temporary directory.
- All shipped files: SHA-256 manifest matched the extracted files.
- ZIP CRC verification: passed.
- Frozen JS original digest: `d75d4208e92f19623b127615bd52b4002e85d2c0a59b76471764b55a24294210`.
- Cross-language parity: 128 numeric input steps per extraction tested against the byte-identical JavaScript original (with Node installed).
- Measured hardware trials: **zero**. Only simulated data files are supplied.
