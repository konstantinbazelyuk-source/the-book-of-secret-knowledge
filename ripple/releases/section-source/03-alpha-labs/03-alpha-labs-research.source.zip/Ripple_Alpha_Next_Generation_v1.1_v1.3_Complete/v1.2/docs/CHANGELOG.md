# v1.2 changes
Includes v1.1 without behavior change; adds finite lineage hybridization and training/holdout multiobjective selection. No original edits.
