"""v1.2 HybridLineage: finite traceable crossover, mutation, multiobjective diversity.
This is synthetic algorithmic exploration, not self-evolving AI or biological genes.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict, replace
import hashlib,itertools,json,math
from pathlib import Path
import numpy as np
from ripple_alpha import SPECIES,Species,Conditions,run_one

ROOT=Path(__file__).resolve().parents[1]
PAIRS=list(itertools.combinations(range(4),2))
COLOR_NAMES={('prism','canopy'):'tidal',('prism','ember'):'aurora',('prism','violet'):'arc',('canopy','ember'):'mossfire',('canopy','violet'):'twilight',('ember','violet'):'cinder'}
LIMITS={'diffusion_gain':(.04,.28),'occlusion_gain':(.35,1.6),'absorption':(.006,.06)}

def sha(record):
    return hashlib.sha256(json.dumps(record,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

def color_mix(a,b,w):
    def rgb(s):return np.array([int(s[i:i+2],16) for i in (1,3,5)])
    c=np.rint(w*rgb(a)+(1-w)*rgb(b)).astype(int)
    return '#'+''.join(f'{int(v):02x}' for v in c)

def inherited_parent_registry():
    lines=json.loads((ROOT/'preserved'/'alpha_v1_lineage.json').read_text())
    original={s.name:s for s in SPECIES}
    registry={}
    for lineage in lines:
        entry=lineage['ledger'][-1]; d=entry['species']; name=d['name']
        if name not in original:raise ValueError('unexpected inherited species')
        value=Species(name=d['name'],color=d['color'],rgb_gain=tuple(d['rgb_gain']),diffusion_gain=d['diffusion_gain'],occlusion_gain=d['occlusion_gain'],absorption=d['absorption'])
        if entry['marker'] != lineage['final_head']:raise ValueError('broken legacy lineage marker')
        registry[name]={'species':value,'head':entry['marker'],'original_species_marker':original[name].marker()}
    if set(registry)!={s.name for s in SPECIES}:raise ValueError('missing archived lineages')
    return registry

def spawn(parent_a,parent_b,wa:float,mutate_field=None,delta=0.,edition='1'):
    if not 0<=wa<=1:raise ValueError('crossover weight out of bounds')
    a,b=parent_a['species'],parent_b['species']
    name=COLOR_NAMES.get((a.name,b.name),f'{a.name}-{b.name}')
    vals={k:float(wa*getattr(a,k)+(1-wa)*getattr(b,k)) for k in LIMITS}
    if mutate_field is not None:
        if mutate_field not in LIMITS:raise ValueError('unknown mutation gene')
        lo,hi=LIMITS[mutate_field]
        vals[mutate_field]=float(np.clip(vals[mutate_field]+delta,lo,hi))
    g=tuple(float(np.clip(wa*x+(1-wa)*y,.4,1.4)) for x,y in zip(a.rgb_gain,b.rgb_gain))
    label=f'{name}-{int(round(wa*100)):02d}-{edition}'
    child=Species(label,color_mix(a.color,b.color,wa),g,**vals)
    record={'schema':'ripple-alpha-hybrid/2','parents':[parent_a['head'],parent_b['head']],
            'weight_parent_a':wa,'mutation_field':mutate_field,'mutation_delta':delta,
            'species':asdict(child)}
    return {'record':record,'marker':sha(record),'species':child}

def make_cohort():
    parents=inherited_parent_registry(); gen=[]
    for i,j in PAIRS:
        a,b=SPECIES[i].name,SPECIES[j].name
        for w in (.35,.65):
            gen.append(spawn(parents[a],parents[b],w,edition='crossover'))
        field=['diffusion_gain','occlusion_gain','absorption'][(i+j)%3]
        sign=1 if (i+j)%2 else -1
        gen.append(spawn(parents[a],parents[b],.5,field,sign*.025,edition='mutant'))
    return gen

def phenotype(s:Species,seeds=(11,17),grid=22,steps=40,dim=2):
    means=[]
    for seed in seeds:
        m=run_one(s,Conditions(n=grid,steps=steps,seed=seed,diffusion=True,occlusion=True,density=True,dim=dim))['metrics']
        means.append([m['active_cells_final']/(grid**dim),m['intensity_retained'],
             m['monochrome_persistent_cells']/max(m['active_cells_final'],1),
             (m['spectral_entropy_final'] or 0.)])
    avg=np.mean(means,axis=0)
    return {'coverage':float(avg[0]),'retention':float(avg[1]),
            'monochrome_fraction':float(avg[2]),'spectral_entropy':float(avg[3])}

def dominates(a,b):
    keys=('coverage','retention','monochrome_fraction','spectral_entropy')
    return all(a[k]>=b[k]-1e-14 for k in keys) and any(a[k]>b[k]+1e-14 for k in keys)

def distance(a,b):
    # Fixed phenotypic scales, engineering preference; not a physics-derived metric.
    scales={'coverage':.1,'retention':.1,'monochrome_fraction':.1,'spectral_entropy':.02}
    return float(math.sqrt(sum(((a[k]-b[k])/v)**2 for k,v in scales.items())))

def experiment(limit=8):
    if limit<1 or limit>12:raise ValueError('archive hard cap')
    baselines=inherited_parent_registry()
    base_scores={k:phenotype(v['species']) for k,v in baselines.items()}
    cohort=make_cohort();records=[]
    for c in cohort:
        p=phenotype(c['species'])
        # Novelty against nearest *archived parent*, not a performance or consciousness metric.
        nearest=min(distance(p, base) for base in base_scores.values())
        records.append({'name':c['species'].name,'species':asdict(c['species']),
                'marker':c['marker'],'record':c['record'],'training':p,'novelty_vs_parent_set':nearest})
    frontier=[r for r in records if not any(q['marker']!=r['marker'] and dominates(q['training'],r['training']) for q in records)]
    frontier.sort(key=lambda x:(-x['novelty_vs_parent_set'],x['name']))
    selected=frontier[:limit]
    for r in selected:
        s=Species(**{**r['species'],'rgb_gain':tuple(r['species']['rgb_gain'])})
        r['holdout']=phenotype(s,seeds=(41,43),grid=22,steps=40)
        a,b=r['record']['parents']
        parent_keys=[k for k,v in baselines.items() if v['head'] in (a,b)]
        r['comparison_parent_names']=parent_keys
        r['parent_holdout']={k:phenotype(baselines[k]['species'],seeds=(41,43),grid=22,steps=40) for k in parent_keys}
        r['holdout_dominates_both_parents']=all(dominates(r['holdout'],p) for p in r['parent_holdout'].values())
    return {'schema':'ripple-hybridlineage-study/2','classification':'simulated',
        'legacy_source_sha256':hashlib.sha256((ROOT/'src'/'ripple_alpha.py').read_bytes()).hexdigest(),
        'candidate_count':len(records),'nondominated_training_count':len(frontier),
        'selected_count':len(selected),'selected':selected,
        'all_candidates':[{'name':r['name'],'marker':r['marker'],'training':r['training'],'novelty_vs_parent_set':r['novelty_vs_parent_set']} for r in records],
        'baseline_parent_train':base_scores,
        'protocol':{'training_seeds':[11,17],'holdout_seeds':[41,43],
           'grid':22,'steps':40,'dim':2,'selection':'training-only Pareto frontier then nearest-parent novelty; finite cap',
           'objectives':'experimental trade-offs; more monochrome is NOT intrinsically better',
           'prohibited_claims':['intelligence increase','autonomous evolution','physical genes','hardware measurements']}}

def main():
    result=experiment()
    (ROOT/'results').mkdir(exist_ok=True)
    (ROOT/'results'/'hybridlineage.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    for s in result['selected']:
        print(s['name'],f"novelty={s['novelty_vs_parent_set']:.3f}",
               'holdout_dominates_both='+str(s['holdout_dominates_both_parents']))
    print('Candidates',result['candidate_count'],'training Pareto',result['nondominated_training_count'],'selected',result['selected_count'])
if __name__=='__main__':main()
