import sys,unittest,dataclasses
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from hybridlineage import *
class TestHybrid(unittest.TestCase):
 def test_parent_registry(self):self.assertEqual(set(inherited_parent_registry()),{'prism','canopy','ember','violet'})
 def test_cohort(self):
  xs=make_cohort();self.assertEqual(len(xs),18);self.assertEqual(len({c['marker'] for c in xs}),18)
 def test_gene_limits(self):
  for c in make_cohort():
   for k,(lo,hi) in LIMITS.items():self.assertTrue(lo<=getattr(c['species'],k)<=hi)
 def test_markers_trace_parent(self):
  parents={x['head'] for x in inherited_parent_registry().values()}
  for child in make_cohort():
   self.assertEqual(child['marker'],sha(child['record']))
   self.assertTrue(set(child['record']['parents'])<=parents)
 def test_determinism(self):self.assertEqual([v['marker'] for v in make_cohort()],[v['marker'] for v in make_cohort()])
 def test_bad_crossover(self):
  p=list(inherited_parent_registry().values())
  with self.assertRaises(ValueError):spawn(p[0],p[1],1.1)
  with self.assertRaises(ValueError):spawn(p[0],p[1],.5,'unknown',3)
 def test_dominance(self):
  good=dict(coverage=.8,retention=.9,monochrome_fraction=.2,spectral_entropy=.1)
  worse=dict(coverage=.7,retention=.8,monochrome_fraction=.2,spectral_entropy=.1)
  self.assertTrue(dominates(good,worse));self.assertFalse(dominates(worse,good))
 def test_repro_phenotype(self):
  s=make_cohort()[0]['species']
  self.assertEqual(phenotype(s,seeds=(2,),grid=12,steps=12),phenotype(s,seeds=(2,),grid=12,steps=12))
 def test_output_holdout(self):
  r=experiment(limit=2);self.assertEqual(r['candidate_count'],18)
  for s in r['selected']:
   self.assertIn('holdout',s)
   self.assertEqual(s['marker'],sha(s['record']))
if __name__=='__main__':unittest.main()
