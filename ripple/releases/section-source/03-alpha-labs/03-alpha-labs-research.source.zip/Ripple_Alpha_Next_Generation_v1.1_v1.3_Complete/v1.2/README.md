# Ripple Alpha v1.2 — HybridLineage

**Execution status:** runnable alpha research on synthetic parameter sets. Contains v1.1 TraceGate unmodified.

This version takes the **four saved final v1.0 lineages** (Prism, Canopy, Ember and Violet), creates **18 explicitly documented hybrid configurations**, and evaluates their synthetic spatial phenotypes. Every hybrid has its parent version markers, crossover weight, optional bounded mutation, canonical parameter snapshot, RGB color identifier and SHA-256 lineage marker. The marker is an integrity fingerprint, **not** an authorization signature.

**Selection is training-only:** training seeds 11/17, a four-objective non-dominated frontier and novelty score with declared arbitrary scales. Fixed holdout seeds 41/43 are evaluated **after** selection. The archive never claims to optimize or create intelligence. The aims are behavioral variation and ancestry inspection, not worker speed. It does not directly mutate weights or the original neuron equations.

### Reproduce

```sh
python -m pip install numpy matplotlib
python src/hybridlineage.py
python src/tracegate.py mag examples/fieldsphere_synthetic_coil.jsonl
python -m unittest discover -s tests -v
```

See `results/hybridlineage.json` and `results/hybrid_diversity.png`. **Negative result:** no selected hybrid dominated both of its parents on all four holdout metrics in this completed run. This is expected and honest; the algorithm studies distinct paths.

## License
New Alpha-stage extensions: MIT license in `LICENSE`. Archived older files retain their own terms.
