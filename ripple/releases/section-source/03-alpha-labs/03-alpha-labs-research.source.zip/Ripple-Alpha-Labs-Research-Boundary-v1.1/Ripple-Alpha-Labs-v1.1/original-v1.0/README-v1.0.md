# Ripple Alpha Labs v1.0.0 — executable optical/colony research laboratory

Original Ripple concept: Constantin x. This package preserves prior source materials and adds an **Alpha execution laboratory** with tests, explicit evidence labels, and an experiment registry. It is not an AS7341 bench validation, AI model, biological organism, calibrated spectrometer, mass-density meter, or new quantum device.

## Open immediately, no Codex

- Open **`Ripple-Alpha-Labs-v1.0.html`** in a modern browser (self-contained: no imports, network calls, accounts, or installer). The default alpha is synthetic, so the phone's restricted `content://` camera permission is not relevant to this simulation.
- The complete folder can alternatively run `python serve.py` and open `http://localhost:8769`. No packages required.
- **Run Alpha** advances the simulation; **+20 steps** gives exact reproducible batches; **Reset seed** recreates all starting fields and genomes.
- Tabs: Field Lab, Gene Species, Algorithm Trials, Evidence & Guardrails, Version Vault. The vault works only in the **full ZIP** after extraction.
- **Select gray descendant** is a finite, explicitly GOAL-DIRECTED genome color-selection experiment (not spontaneous biology). It is gated until at least 60 simulation steps. It records rejected and accepted candidates with ancestry. An initial Neutral reference is included deliberately and never counts as emergence.
- The **density** stage remains disabled until at least 60 steps **and** either a qualifying descendant was selected or a sustained gray *field* event was detected. Density means NUMERICAL OCCUPANCY only.
- **Run controlled comparison** executes four simulated conditions at an identical seed; **Export full experiment JSON** includes lineage, individual paths, quaternary states, color fields, and evidence type.

## Locked / current / optional / obsolete

**LOCKED:** `Ripple-Neuron-Quaternary-v0.7/web/ripple-core.js` (SHA-256 `dba6639b7902f0c702d15fff588524629f3754cfd72d7b704f22a76b78960ee3`); it preserves the v0.1 LIF equations `D=2R+1.2G−1.4B`, threshold bounds, reset, and refractory period. The original 120-model-second simulated brightness step yields 0.95 adaptive vs. 3.40 fixed events/model-s in the perturbation window. `quaternary-core.mjs` is preserved and imported for 2-bit/-1,-0,0,1 symbol packing. The original Mycelium sources and other archived releases in `vault/` are NOT edited or silently merged. Other Mycelium `ripple-genome/1` markers are SHA-256 records and remain separate.

**CURRENT Alpha:** Flux-conserving finite-volume RGB field, barrier-respecting edge permeability, optional crowding/occupancy-corrected flux, seeded digital lineages, 2D numerical path tracking, conserved transport test, and measured *simulation* outcomes. This is an integration **of the original neuron kernel and v0.7 encoding**, NOT execution of every archived subsystem simultaneously.

**OPTIONAL STUDIES:** Goal-directed color-neutralization mutation and finite 4-condition comparison; field monochrome detector. The optional Mycelium hybrid-fast control method and colony specializations remain archived/inactive. No naive PI mode was substituted for the original controller.

**NOT IMPLEMENTED:** Physical opacity, electrical-field/aura/concentration measurement, autonomous AI decision-making, biological mutation or atomic density, external model API calls, real robotics, durable cloud distribution, photon measurement, true reaction-diffusion Turing instability, and actual parallel supercomputing. No scientific novelty or performance superiority is asserted.

## New named Alpha algorithms

`FD-1` Pairwise conservative RGB transport on a 2D square graph. Each undirected edge `(i,j)` applies **equal-and-opposite** flux to its endpoints for each color channel:

`Δc_i = α_ij(c_j − c_i)`, `Δc_j = −Δc_i`, where `α_ij = Δt·D·(1-max(o_i,o_j))/(1+κ·(n_i+n_j)/2)`.

Here `o` is a synthetic permeability mask, `n` numerical agent occupancy. When `o=1`, no flux crosses that edge. No source/sink and no clamping imply conserved sum of per-channel field values, tested. `Δt=0.16`, `0≤D≤0.42` with conservative guardrail `4DΔt≤0.25`; a 2D 4-neighbor explicit diffusion scheme requires a stability condition. This particular bound is more conservative than ordinary positivity bound `4DΔt≤1`.

`OC-1` Occlusion as no-through-flux wall plus a deliberately open corridor; NOT optical tomography or distance inferred from RGB.

`DN-1` Density modifies transport by a bounded crowding denominator. This is a synthetic occupancy hypothesis. It does NOT estimate physical density from light. Phase gate enforces user-specified order (observe initial colored lineages, detect/select a monochrome event, then introduce density).

`Q-1` Quaternary state from each species' field history. Symbols `-1`, `-0`, `0`, `1` occupy 2 bits each (the minus zero is a symbolic inhibited state, not IEEE-754 signed zero). Encoding uses v0.7's frozen `pack4` and `toBits`.

`MONO-1` Two distinct outcomes are tracked: (1) a **field event** where >=15% of illuminated traversable cells meet normalized chroma `≤0.055` for eight consecutive model steps with minimum brightness 0.06; and (2) a **genome event** where average channel weight >0.055 and `(max(w)-min(w))/(sum(w)+ε)≤0.08`. A pre-seeded Neutral control is not a descendant. A selected descendant does not indicate environmental spontaneous emergence.

`GEN-1` Bounded finite color-gene search with immutable typed records (schema `ripple-alpha-gene/1`), selected parents, seeded candidate perturbations, rank by normalized channel chroma, max 30 rounds, 6 candidate mutations per round, ancestry audit. ID is FNV-1a for convenience, NOT the existing Mycelium's SHA-256 canonical genome marker. No eval, dynamic imports from data, external commands, generated code execution, or unbounded recursion.

## Evidence levels and acceptance

- **Source-recovered:** original project materials from conversation attachments and the user's Library are in `vault/`, checked with SHA-256 in `verified/source-manifest.json`.
- **Verified numerical:** pinned original core checksum, 0.95/3.40 legacy comparison, conservation/no-flux, random-seed replay, cap/validation failure tests, 2-bit reversible packing, separation of field and selected-genome monochrome results, input bounds, original kernel unchanged. Run `node tests/test.mjs`.
- **Simulated experimental:** `node tests/study.mjs` runs five seeds × four modes × 240 steps, with predeclared train 11/17 and holdout 41/43/47. Raw results are in `verified/comparison.csv` / JSON, not measurements.
- **Browser UI executed:** Chromium checked phone-width 393px and desktop-width 1280px; +20 step, phase guard, descendant selection, density unlock, 4-mode comparison, lineage table and zero page errors. Screenshots in `verified/`.
- **Not validated:** camera light, physical occlusion, physical mass/density, optoelectronic hardware, power/performance on the user's Samsung, or actual external AI synthesis. The Alpha UI uses no camera and no remote telemetry.

## Research and rationale

- Turing, *The Chemical Basis of Morphogenesis* (1952): https://doi.org/10.1098/rstb.1952.0012. Reaction-diffusion mathematics motivates differentiated source/transport questions, but **this lab does not implement the actual coupled-reaction instability**.
- Tyson, *Revisiting Turing’s Chemical Basis of Morphogenesis* (2026): https://doi.org/10.1007/s11538-026-01629-z. Describes stability/pattern questions; no claims of solved spontaneous morphogenesis here.
- Image luminance fundamentals: https://scikit-image.org/docs/stable/api/skimage.color — later sensor calibration requires a camera profile, fixed white balance and exposure.
- User's unchanged `vault/MATHEMATICAL_CODEX.md` (Mycelium v0.5), `vault/research/MATHEMATICS.md` (Mycelium v0.3), and original v0.1 sensor brief are the project-specific mathematical sources.

## Suggested independent verification / sourcing

Run the conserved-flux test and cross-check against a serial finite-volume implementation; use a fixed light scene and controlled camera gain/white balance to test optical color model as a distinct stage. Use measured AS7341/phone camera data and repeat validation with blinded stimulus labels. Outsourcing invitations can target numerics/optics researchers with exported input logs, specific falsifiable hypotheses, licensing details, and the version manifest. Do not send private camera videos or user financial data as a requirement.

## Continuity & release notes

This is a **new separate Alpha laboratory**, not an update or deployment of the live `ripple-neuron-phone.floot.app` web app, which remains untouched. Files are additive and stored under one ZIP. `vault/` stores historical sources unchanged. Version-specific source presence does not imply runtime integration. Work is freely inspectable locally; verify third-party licenses before redistributing further. Source manifest includes exact byte counts and hashes.
