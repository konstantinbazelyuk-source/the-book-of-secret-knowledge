# Ripple Alpha Labs v1.1 — Research Boundary Alpha

**Status:** Executable numerical research Alpha; offline results dashboard; physical-camera capture program and strict reference validator. **Not a hardware-verified optical-density sensor, self-learning AI, biologically evolving organism, or real supercomputer study.** Original Ripple neuron v0.1 and v1.0 Alpha engine remain byte-for-byte unchanged.

## Open / run without accounts

- `Ripple-Alpha-Research-v1.1.html`: self-contained offline clickable research dashboard showing ACTUALLY COMPUTED study results and sample gene trajectories. Selecting controls examines saved results; the dashboard does **not** invent new data.
- `original-v1.0/Ripple-Alpha-Labs-v1.0.html`: original unmodified interactive field and gene simulator, for reference and comparison.
- To independently recompute all v1.1 numerical studies, install Node.js 22+ and run from this directory: `node research/run-study.mjs`, then `node research/extra-study.mjs`, then `node research/traces.mjs`, `python build_viewer.py`. These are normal local commands; no Codex required.
- Test: `node tests/regression-v1.mjs`, `node tests/research-tests.mjs`, `node tests/viewer-static.mjs`.
- Camera (on a real computer): optional OpenCV Python capture tool, see `docs/PHYSICAL-CALIBRATION-SOP.md`. No genuine camera samples were captured for this release.

## Fully completed numerical research boundary

1. **Monochrome lineage isolation:** Tested 4 policies across 4 chromatic initial genomes and 192 separate holdout seeds (768 trials/policy). Compared neutral vs gray-biased mutation under random inheritance and explicit chroma selection, using 30 generations and 6 candidate evaluations/gen. Statistics include Wilson 95% score intervals, deterministic sampling, paired bootstrap contrasts and full trial-level CSV. Additional perturbation/amplitude study covers 12 settings with 192 cases each.
2. **Field emergence:** 32 holdout seeds × 4 transport/occlusion/occupancy modes = 128 independent, 240-step synthetic runs. No sustained gray field event under existing threshold. A controlled test revealed the v1.0 event label `field_monochrome_emerged` fires for pre-existing gray fields. An independent audit detects absent→present persistence instead and rejects already-gray starts; old v1.0 engine remains unchanged.
3. **Density:** Independently implemented *cell-centric* finite-volume solver and cross-checked against pairwise original model in 36 randomized 19×17 RGB grids. Tested conservation, no negative/overshoot, decreasing squared norm, pulse-response law under prescribed synthetic occupancies, and recovery of a coefficient from synthetic self-consistent data. Did not calibrate real matter density or derive optical extinction.
4. **Reality application:** A strict computer-webcam capture script for repeated blocked/clear/sample RGB region readings, requirement for operator-confirmed exposure/white-balance locks, camera metadata schema and a fail-closed validator. No physical measurements are bundled or fabricated. Requires a real camera and independently controlled lighting. Results would still be *camera-relative* light estimates, not calibrated spectral absorbance.

## Evidence taxonomy

- **Source-verified:** v0.1 core SHA-256 `dba6639b7902f0c702d15fff588524629f3754cfd72d7b704f22a76b78960ee3`; v1.0 `engine.mjs` SHA-256 `18edf5b35b5c0958cf6b16d3c23ca89077f1d19d75fbe9c1cabd1e9ff20d23c7`. They remain unchanged here.
- **Verified calculations:** independent solver agreement, core regression, invariant tests, deterministic repetition and guardrail failure cases.
- **Simulated outcomes:** all genome hit rates, color convergence and field events, synthetic numerical occupancy, noise/scale sensitivity.
- **Not measured:** light scattering, physical density, photon counts, visible-light spectroscopy, biological mutation, real camera performance, or intelligent autonomy.

Read `docs/RESEARCH_REPORT.md`, `docs/PHYSICAL-CALIBRATION-SOP.md`, and `docs/EVIDENCE-GATES.md` for calculations, limitations and falsifiable bench acceptance gates. These documents provide citations to established numerical analysis, CIE image color metrics, and NIST calibration guidance.

## Continuity scope

This v1.1 is a new research Alpha. It does NOT change the public phone web app. No archived artifact was overwritten. All original v1.0 alpha source and original v0.1 kernel code are preserved separately. The new named algorithms `GEN-BIAS-AUDIT-1`, `MONO-TRANSITION-1`, and `DN-REF-CHECK-1` are incremental research procedures, not automatically self-generating software or untested physical technology.
