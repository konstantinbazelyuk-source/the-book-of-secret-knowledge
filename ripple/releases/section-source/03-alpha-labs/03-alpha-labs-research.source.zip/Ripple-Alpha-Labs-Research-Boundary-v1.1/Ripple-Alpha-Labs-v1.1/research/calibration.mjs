/** Camera data ingest — fails closed if measured provenance unsupported. */
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const srgb=x=>{x=clamp(x/255,0,1);return x<=.04045?x/12.92:((x+.055)/1.055)**2.4};
export function validateCameraSession(session){
 const errors=[];
 if(!session||typeof session!=='object'||session.provenance!=='MEASURED')errors.push('provenance must be MEASURED');
 const m=session?.camera||{};
 if(!m.device_id||!m.capture_utc||!m.geometry_id||!m.illumination_id||!m.roi_id)errors.push('camera ID, UTC time, geometry, illumination and ROI required');
 if(!Number.isFinite(m.exposure_ms)||m.exposure_ms<=0||!Number.isFinite(m.iso)||m.iso<=0||!m.white_balance_id)errors.push('numeric fixed exposure time and ISO plus white-balance ID required');
 if(m.exposure_locked!==true||m.white_balance_locked!==true)errors.push('physical calibration blocked: exposure and white balance must be confirmed locked');
 const records=session?.frames;
 if(!Array.isArray(records)||records.length<12)errors.push('minimum 12 captured frames; at least 4 each: dark, clear, sample');
 const buckets={dark:[],clear:[],sample:[]};
 if(Array.isArray(records))for(const f of records){
  if(!buckets[f.kind]){errors.push('unknown frame type');continue}
  if(!Array.isArray(f.rgb)||f.rgb.length!==3||!f.rgb.every(v=>Number.isFinite(v)&&v>=0&&v<=255)){errors.push('invalid RGB sample');continue}
  if(f.geometry_id!==m.geometry_id||f.roi_id!==m.roi_id||f.illumination_id!==m.illumination_id)errors.push('geometry, ROI or illumination changed');
  if(f.exposure_ms!==m.exposure_ms||f.iso!==m.iso||f.white_balance_id!==m.white_balance_id)errors.push('camera exposure/ISO/WB metadata changed');
  buckets[f.kind].push(f.rgb);
 }
 for(const x of Object.keys(buckets))if(buckets[x].length<4)errors.push('need four replicates for '+x);
 if(errors.length)return {valid:false,evidence:'INVALID',errors};
 const average=(arr,i)=>arr.reduce((s,x)=>s+x[i],0)/arr.length;
 const results=[];for(let channel=0;channel<3;channel++){
  const dark=average(buckets.dark,channel),clear=average(buckets.clear,channel),sample=average(buckets.sample,channel);
  if(clear-dark<30)errors.push('channel '+channel+' reference contrast under 30 camera counts');
  if(Math.max(...buckets.clear.map(x=>x[channel]),...buckets.sample.map(x=>x[channel]))>=245)errors.push('channel '+channel+' is close to clipping');
  const linearAverage=(key)=>buckets[key].reduce((s,x)=>s+srgb(x[channel]),0)/buckets[key].length;
  const d=linearAverage('dark'),c=linearAverage('clear'),s=linearAverage('sample');const T=(s-d)/(c-d);
  if(!Number.isFinite(T)||T<=0||T>1.05)errors.push('channel '+channel+' outside [0,1.05] relative transmittance; calibration invalid');
  const linearT=clamp(T,1e-8,1),sigma=(arr)=>{const avg=average(arr,channel);return Math.sqrt(arr.reduce((z,x)=>z+(x[channel]-avg)**2,0)/(arr.length-1))};
  results.push({channel:['R','G','B'][channel],transmittance:linearT,relativeOpticalDensity:-Math.log10(linearT),darkMeanCode:dark,clearMeanCode:clear,sampleMeanCode:sample,replicateSDCode:{dark:sigma(buckets.dark),clear:sigma(buckets.clear),sample:sigma(buckets.sample)}});
 }
 // Between-replicate stability check, 2% of mean span + 2 sensor levels tolerance.
 for(let channel=0;channel<3;channel++){
  const span=average(buckets.clear,channel)-average(buckets.dark,channel);
  const drift=(arr)=>Math.max(...arr.map(row=>row[channel]))-Math.min(...arr.map(row=>row[channel]));
  if(['dark','clear','sample'].some(kind=>drift(buckets[kind])>2+.02*span))errors.push('channel '+channel+' unstable across replicates');
 }
 return {valid:errors.length===0,evidence:errors.length?'INVALID':'CAMERA RGB MEASURED; RELATIVE TRANSMITTANCE ESTIMATED',errors,channels:errors.length?[]:results,limits:'Approximate sRGB-to-linear transform; camera RGB is not radiometrically calibrated or spectrally resolved. Metadata self-reported by capture session; physical traceability not established.'};
}
export const cameraTemplate={provenance:'MEASURED',camera:{device_id:'',capture_utc:'',geometry_id:'',illumination_id:'',roi_id:'',exposure_locked:false,white_balance_locked:false,exposure_ms:null,iso:null,white_balance_id:''},frames:[]};
