/** Alpha v1.1 preregistered lineage comparison. SIMULATED computer science only. */
import {bases,makeGenome,genomeGray,rng,AlphaLab,monochrome} from '../engine.mjs';
const chroma=g=>(Math.max(...g.weights)-Math.min(...g.weights))/(g.weights.reduce((s,v)=>s+v,0)+1e-5);
const clip=x=>Math.max(0,Math.min(1,x));
export const DESIGN=Object.freeze({seedTrain:[3,7,13,19,29,31,37,53,59,61,67,71],seedHoldout:Array.from({length:192},(_,i)=>1009+i*17),parents:['Crimson','Emerald','Cobalt','Amber'],generations:30,candidatesPerGeneration:6,grayThreshold:.08,policies:['neutral_random','biased_random','neutral_selected','biased_selected'],preregistered:true});
// This experiment records ALL candidate generation policy so 'spontaneous' does NOT
// imply biology or no programmed bias. In v1.0 mutateGenome applies a grayward drift.
function candidate(parent,r,pressure){
 const w=[...parent.weights],i=Math.floor(r()*3),mean=w.reduce((s,v)=>s+v,0)/3;
 w[i]=clip(w[i]*(1-pressure)+mean*pressure+(r()-.5)*.05);
 return makeGenome({label:parent.label+'*',weights:w,mobility:clip(parent.mobility+(r()-.5)*.08),memory:parent.memory,diffusion:parent.diffusion,crowding:parent.crowding,parent:parent.id,generation:parent.generation+1,kind:'mutation'});
}
export function runLineage(parent,seed,policy,detail=false){
 if(!DESIGN.policies.includes(policy))throw Error('Unregistered mutation policy');
 if(genomeGray(parent))throw Error('Gray reference is not valid chromatic lineage parent');
 const r=rng(seed),selected=policy.endsWith('selected'),pressure=policy.startsWith('biased')?.65:0;
 let g=parent,firstHit=null,minC=chroma(parent),ledger=[];
 const frozenStart=g.id;
 for(let generation=1;generation<=DESIGN.generations;generation++){
  // Matched budget: always 6 candidate evaluations per generation. Selected
  // branches choose least chromatic; random branches sample uniformly.
  const offspring=Array.from({length:DESIGN.candidatesPerGeneration},()=>candidate(g,r,pressure));
  const chosenIndex=selected?offspring.reduce((best,x,i,a)=>chroma(x)<chroma(a[best])?i:best,0):Math.floor(r()*offspring.length);
  const chosen=offspring[chosenIndex];
  // Selection uses the lowest chroma candidate, even if the best is worse than
  // its parent; this removes the hidden elitism present in v1.0 search.
  g=chosen;minC=Math.min(minC,chroma(g));
  if(firstHit===null&&genomeGray(g))firstHit=generation;
  if(detail)ledger.push({generation,id:g.id,parent:g.parent,weights:g.weights,chroma:chroma(g),hit:genomeGray(g),candidateChroma:offspring.map(chroma),chosenIndex,selection:policy});
 }
 return{parent:parent.label,parentId:frozenStart,seed,policy,firstHit,terminalHit:genomeGray(g),everHit:firstHit!==null,lastChroma:chroma(g),bestChroma:minC,lastId:g.id,ledger:detail?ledger:undefined,evidence:'SIMULATED'};
}
const hashSeed=(base,parentIndex)=>((base^((parentIndex+1)*0x9e3779b9))>>>0);
export function wilson(k,n,z=1.96){const p=k/n,z2=z*z,d=1+z2/n,c=(p+z2/(2*n))/d,h=z*Math.sqrt((p*(1-p)+z2/(4*n))/n)/d;return{rate:p,lo:Math.max(0,c-h),hi:Math.min(1,c+h),n,k};}
function mean(a){return a.reduce((s,x)=>s+x,0)/a.length;}
export function lineageStudy(seeds=DESIGN.seedHoldout,detail=false){
 const parents=bases.filter(b=>DESIGN.parents.includes(b.label)),cases=[];
 for(let pi=0;pi<parents.length;pi++)for(const seed of seeds){
  const fixed=hashSeed(seed,pi);
  for(const policy of DESIGN.policies)cases.push(runLineage(parents[pi],fixed,policy,detail&&seed===seeds[0]));
 }
 const groups={};for(const policy of DESIGN.policies){const g=cases.filter(x=>x.policy===policy);groups[policy]={ever:wilson(g.filter(x=>x.everHit).length,g.length),terminal:wilson(g.filter(x=>x.terminalHit).length,g.length),meanFinalChroma:mean(g.map(x=>x.lastChroma)),medianFirstHit:g.filter(x=>x.firstHit!==null).map(x=>x.firstHit).sort((a,b)=>a-b)[Math.floor(g.filter(x=>x.firstHit!==null).length/2)]??null};}
 const comparisons=[];
 for(const [a,b] of [['biased_random','neutral_random'],['neutral_selected','neutral_random'],['biased_selected','biased_random'],['biased_selected','neutral_selected']]){
  const A=cases.filter(x=>x.policy===a),B=cases.filter(x=>x.policy===b); // same parent/seed iteration order
  const differences=A.map((x,i)=>Number(x.everHit)-Number(B[i].everHit));
  const boot=rng(0x735291),sims=[];
  for(let k=0;k<1600;k++){let v=0;for(let j=0;j<differences.length;j++)v+=differences[Math.floor(boot()*differences.length)];sims.push(v/differences.length)}
  sims.sort((x,y)=>x-y);
  comparisons.push({a,b,difference:mean(differences),pairedBootstrapCI95:[sims[39],sims[1559]],n:A.length});
 }
 return{schema:'ripple-alpha-lineage-study/1.1',evidence:'SIMULATED',protocol:DESIGN,nCases:cases.length,groups,comparisons,perParent:Object.fromEntries(parents.map(p=>[p.label,Object.fromEntries(DESIGN.policies.map(mode=>{const x=cases.filter(z=>z.parent===p.label&&z.policy===mode);return[mode,wilson(x.filter(z=>z.everHit).length,x.length)]}))])),cases};
}
export function fieldStudy(seeds=Array.from({length:32},(_,i)=>1009+i*17),steps=240){
 const modes=['baseline','occlusion','density','combined'],rows=[];
 for(const seed of seeds)for(const mode of modes){
  const lab=new AlphaLab({seed,width:20,height:16,diffusion:.32,occlusion:mode==='occlusion'||mode==='combined',density:mode==='density'||mode==='combined'});
  lab.run(steps);
  const r=lab.report();const history=r.trajectory;
  rows.push({seed,mode,steps,event:r.events.some(e=>e.type==='field_monochrome_emerged'),maxFraction:Math.max(...history.map(h=>h.monochromeFraction)),endFraction:r.monochrome,peakBrightness:Math.max(...history.map(h=>h.brightCells)),firstEventStep:r.events.find(e=>e.type==='field_monochrome_emerged')?.t??null,evidence:'SIMULATED'});
 }
 const grouped=Object.fromEntries(modes.map(m=>{const xs=rows.filter(x=>x.mode===m);return[m,{sustained:wilson(xs.filter(x=>x.event).length,xs.length),maxFraction:Math.max(...xs.map(x=>x.maxFraction)),meanPeakFraction:mean(xs.map(x=>x.maxFraction))}]}));
 return{schema:'ripple-alpha-field-study/1.1',evidence:'SIMULATED',seeds,steps,grid:[20,16],modes,grouped,rows,notes:'Field equality can be passive RGB source mixing, not digital-genome mutation. No monochrome descendant is injected in this experiment.'};
}
