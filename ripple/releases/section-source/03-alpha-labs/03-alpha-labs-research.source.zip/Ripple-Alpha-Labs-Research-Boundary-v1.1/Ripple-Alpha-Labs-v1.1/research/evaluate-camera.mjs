import {readFileSync,writeFileSync} from 'node:fs';import {validateCameraSession} from './calibration.mjs';
const path=process.argv[2];if(!path){console.error('Usage: node research/evaluate-camera.mjs my-real-capture.json [output.json]');process.exit(2)}
let session;try{session=JSON.parse(readFileSync(path,'utf8'))}catch(e){console.error('Cannot parse measurement file',e.message);process.exit(2)}
const out=validateCameraSession(session);
if(process.argv[3])writeFileSync(process.argv[3],JSON.stringify(out,null,2));
console.log(JSON.stringify(out,null,2));if(!out.valid)process.exitCode=1;
