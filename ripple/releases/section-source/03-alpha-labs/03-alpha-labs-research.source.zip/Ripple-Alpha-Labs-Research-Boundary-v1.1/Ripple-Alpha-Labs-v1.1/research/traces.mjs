import{writeFileSync}from'node:fs';import{bases}from'../engine.mjs';import{runLineage,DESIGN}from'./lineage.mjs';
const traces=[];for(let i=0;i<4;i++){for(const policy of DESIGN.policies)traces.push({...runLineage(bases[i],(DESIGN.seedHoldout[0]^((i+1)*0x9e3779b9))>>>0,policy,true),rootWeights:[...bases[i].weights]});}
writeFileSync('results/lineage-traces.json',JSON.stringify({evidence:'SIMULATED',basis:'ONE pre-declared first holdout seed per parent and per policy',traces},null,2));
console.log('Wrote',traces.length,'sampled complete ancestry traces; each has',DESIGN.generations,'generations');
