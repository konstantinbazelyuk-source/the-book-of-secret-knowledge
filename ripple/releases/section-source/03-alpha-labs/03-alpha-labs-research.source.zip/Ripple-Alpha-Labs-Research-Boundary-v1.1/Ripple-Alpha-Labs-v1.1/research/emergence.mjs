/** Independent alpha event audit. A persistent gray field is not automatically emergent. */
import{AlphaLab,monochrome,constants}from'../engine.mjs';
export class MonochromeAudit{
 constructor({hold=8,threshold=.15,minPriorAbsent=4}={}){this.hold=hold;this.threshold=threshold;this.minPriorAbsent=minPriorAbsent;this.priorAbsent=0;this.postPresent=0;this.state='initial';this.trigger=null;this.history=[];}
 observe(fraction,tick,{isStartingObservation=false}={}){
  if(!Number.isFinite(fraction)||fraction<0||fraction>1)throw Error('invalid gray fraction');
  const brightGray=fraction>=this.threshold;
  if(this.state==='initial'){
   this.state=brightGray?'preexisting_reference':'awaiting_transition';
   // A preexisting already-gray field is a control, not emergence.
  }
  if(this.state==='preexisting_reference'){
   if(!brightGray){this.priorAbsent++;if(this.priorAbsent>=this.minPriorAbsent){this.state='awaiting_transition';this.postPresent=0;}}
   else this.priorAbsent=0;
  }else if(this.state==='awaiting_transition'){
   if(!brightGray){this.priorAbsent++;this.postPresent=0;}
   else if(this.priorAbsent>=this.minPriorAbsent){this.postPresent++;if(this.postPresent>=this.hold){this.state='transition_detected';this.trigger=tick;}}
  }
  this.history.push({tick,fraction,state:this.state});
  return{state:this.state,transitionObserved:this.trigger!==null,trigger:this.trigger};
 }
}
export function positiveControls(){
 // Original named event is a persistence test: document false-emergence result.
 const legacy=new AlphaLab({seed:111});legacy.f.fill(.3);legacy.run(12);
 const falseOldEvent=legacy.events.some(e=>e.type==='field_monochrome_emerged');
 const auditPre=new MonochromeAudit();for(let i=0;i<12;i++)auditPre.observe(legacy.trajectory[i].monochromeFraction,i+1);
 const auditForced=new MonochromeAudit();const forced=[...Array(7).fill(0),...Array(12).fill(.55)];
 forced.forEach((x,i)=>auditForced.observe(x,i+1));
 const auditDark=new MonochromeAudit();[...Array(9).fill(0),...Array(9).fill(.05)].forEach((x,i)=>auditDark.observe(x,i+1));
 return{legacyReportsEmergenceForPreseededGray:falseOldEvent,auditedPreexistingTransition:auditPre.trigger!==null,auditedForcedSyntheticTransition:auditForced.trigger!==null,forcedTrigger: auditForced.trigger,negativeControlTransition:auditDark.trigger!==null,evidence:'SYNTHETIC CONTROL',interpretation:'The old detector reports 8-step persistence; it does not establish emergence from an initially non-gray field. Revised event audit requires documented absent-to-present transition.'};
}
