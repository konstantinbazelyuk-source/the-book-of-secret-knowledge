#!/usr/bin/env python3
"""Capture physical RGB ROI samples from a computer webcam for Ripple Alpha Labs.
No camera is available in the ChatGPT build environment: operator must run locally.
This program DOES NOT alter camera exposure/white-balance: use manual camera controls.
The output labels measurements as local, operator-declared metadata, not certified optics.
"""
import argparse,json,datetime,sys,os
try: import cv2
except ImportError:
 print('OpenCV required: pip install opencv-python',file=sys.stderr);sys.exit(2)

def main():
 p=argparse.ArgumentParser(description='Capture dark/clear/sample references for Ripple Alpha Lab')
 p.add_argument('--camera',type=int,default=0)
 p.add_argument('--output',default='ripple-measured-camera-session.json')
 p.add_argument('--geometry',required=True,help='ID for unchanged camera/source/object geometry')
 p.add_argument('--illumination',required=True,help='ID for constant physical light configuration')
 p.add_argument('--roi',default='central_20pct')
 p.add_argument('--exposure-ms',type=float,required=True,help='observed manually fixed exposure time')
 p.add_argument('--iso',type=float,required=True,help='observed manually fixed ISO')
 p.add_argument('--white-balance',required=True,help='manual white balance preset/temp')
 p.add_argument('--confirm-manual-exposure',action='store_true')
 p.add_argument('--confirm-manual-white-balance',action='store_true')
 args=p.parse_args()
 if not(args.confirm_manual_exposure and args.confirm_manual_white_balance):p.error('must confirm both exposure and white balance manually locked; do not guess')
 cap=cv2.VideoCapture(args.camera)
 if not cap.isOpened():raise RuntimeError('Camera unavailable; no data file was written.')
 sample={"provenance":"MEASURED","instrumentation":"Webcam central ROI, BGR8 camera image converted to RGB8; browser-equivalent proxy only", "camera":{
  "device_id":"webcam:"+str(args.camera),"capture_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"geometry_id":args.geometry,"illumination_id":args.illumination,"roi_id":args.roi,
  "exposure_locked":True,"white_balance_locked":True,"exposure_ms":args.exposure_ms,"iso":args.iso,"white_balance_id":args.white_balance},"frames":[]}
 try:
  print('Controls: d = dark/blocked light, c = clear/unobstructed, s = sample material, q = quit. Press 5 times per type.');print('Keep the SAME ROI, geometry, illumination, lens, focus, manual ISO/exposure and white balance.')
  while True:
   ok,frame=cap.read()
   if not ok:raise RuntimeError('camera frame read failed')
   h,w=frame.shape[:2];side=max(8,int(min(h,w)*.2));x=(w-side)//2;y=(h-side)//2
   cropped=frame[y:y+side,x:x+side];view=frame.copy();cv2.rectangle(view,(x,y),(x+side,y+side),(0,255,0),2)
   label=' | '.join(f'{kind}:{sum(1 for f in sample["frames"] if f["kind"]==kind)}' for kind in ['dark','clear','sample']);cv2.putText(view,label,(15,26),cv2.FONT_HERSHEY_SIMPLEX,.7,(0,255,255),2)
   cv2.imshow('Ripple physical RGB reference capture',view);key=cv2.waitKey(1)&0xff
   if key==ord('q'):break
   if key in [ord('d'),ord('c'),ord('s')]:
    kind={ord('d'):'dark',ord('c'):'clear',ord('s'):'sample'}[key]
    # cv2 frame is BGR. Use image pixels exactly as captured, not inferred photons.
    import numpy as np
    rgb=cropped.reshape(-1,3).mean(axis=0)[::-1].tolist()
    sample['frames'].append({'kind':kind,'rgb':[round(float(v),3) for v in rgb],'geometry_id':args.geometry,'roi_id':args.roi,'illumination_id':args.illumination,'exposure_ms':args.exposure_ms,'iso':args.iso,'white_balance_id':args.white_balance,'capture_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()});print(kind, sample['frames'][-1]['rgb'])
 finally:cap.release();cv2.destroyAllWindows()
 counts={kind:sum(f['kind']==kind for f in sample['frames']) for kind in ['dark','clear','sample']}
 if any(v<4 for v in counts.values()):
  print('Insufficient real frames:',counts,'No data file written.',file=sys.stderr);return 1
 with open(args.output,'w',encoding='utf8') as f:json.dump(sample,f,indent=2)
 print('Camera session captured. Operator-declared lock metadata requires independent verification. Saved',args.output)
 return 0
if __name__=='__main__':raise SystemExit(main())
