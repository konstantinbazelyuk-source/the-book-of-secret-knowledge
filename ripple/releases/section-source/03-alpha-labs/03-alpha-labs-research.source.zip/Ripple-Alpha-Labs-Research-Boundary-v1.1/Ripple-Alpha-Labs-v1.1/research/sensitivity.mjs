/** Sensitivity: no-hit under one mutation amplitude is not a universal impossibility. */
import{bases,rng,makeGenome,genomeGray}from'../engine.mjs';
const clamp=v=>Math.max(0,Math.min(1,v));
const score=g=>(Math.max(...g.weights)-Math.min(...g.weights))/(g.weights.reduce((s,v)=>s+v,0)+1e-5);
export function sensitivityStudy(){
 const results=[],parents=bases.filter(g=>g.label!=='Neutral reference');
 for(const width of [.05,.15,.3])for(const generations of [30,60])for(const selected of [false,true]){
  let hits=0,meanFinal=0,trials=0;
  for(let p=0;p<parents.length;p++)for(let trial=0;trial<48;trial++){
   const rnd=rng((9383+p*7357+trial*1579)>>>0);let cur=parents[p],ever=false;
   for(let j=0;j<generations;j++){
    const c=[];
    for(let k=0;k<6;k++){
     const w=[...cur.weights],index=Math.floor(rnd()*3);
     w[index]=clamp(w[index]+(rnd()-.5)*width);
     c.push(makeGenome({label:'neutral',weights:w,mobility:cur.mobility,memory:cur.memory,diffusion:cur.diffusion,crowding:cur.crowding,parent:cur.id,generation:cur.generation+1,kind:'mutation'}));
    }
    const next=selected?c.reduce((a,b)=>score(a)<score(b)?a:b):c[Math.floor(rnd()*c.length)];cur=next;if(genomeGray(cur))ever=true;
   }
   hits+=Number(ever);meanFinal+=score(cur);trials++;
  }
  results.push({mutationStepWidth:width,generations,selection:selected?'minimize_chroma':'random',n:trials,hits,rate:hits/trials,meanFinalChroma:meanFinal/trials,evidence:'SIMULATED'});
 }
 return {schema:'ripple-alpha-sensitivity/1.1',evidence:'SIMULATED',results,warning:'Fixed neutral random-coordinate mutation is not an unbiased sampling distribution over all possible RGB genomes; zero hits in these finite budgets is not proof of impossibility.'};
}
