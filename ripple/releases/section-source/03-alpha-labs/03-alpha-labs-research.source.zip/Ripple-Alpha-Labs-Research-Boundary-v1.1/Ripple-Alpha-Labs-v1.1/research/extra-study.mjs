import{writeFileSync,readFileSync}from'node:fs';
import{positiveControls}from'./emergence.mjs';import{sensitivityStudy}from'./sensitivity.mjs';
const controls=positiveControls(),sensitivity=sensitivityStudy();
writeFileSync('results/positive-controls.json',JSON.stringify(controls,null,2));writeFileSync('results/sensitivity.json',JSON.stringify(sensitivity,null,2));
const data=JSON.parse(readFileSync('results/summary.json','utf8'));data.positiveControls=controls;data.sensitivity=sensitivity.results;writeFileSync('results/summary.json',JSON.stringify(data,null,2));
console.log(JSON.stringify(controls,null,2));for(const x of sensitivity.results)console.log(x.mutationStepWidth,x.generations,x.selection,x.hits+'/'+x.n,(x.rate*100).toFixed(1)+'%');
