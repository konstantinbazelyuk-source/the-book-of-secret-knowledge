/** Independent numerical density / diffusion cross-validation.
 * Passive scalar transport under occupancy-dependent permeability is a SIMULATED
 * phenomenological closure, not optical mass-density estimation. */
import {diffusionStep,rng} from '../engine.mjs';
export function referenceSolver(field,w,h,D,dt,mask=null,occupancy=null,kappa=0){
 const next=new Float64Array(field.length);
 // Independent cell-centric implementation (not pairwise flux in original)
 for(let y=0;y<h;y++)for(let x=0;x<w;x++)for(let channel=0;channel<3;channel++){
  const i=y*w+x,at=i*3+channel;let v=field[at];
  for(const [dx,dy] of [[-1,0],[1,0],[0,-1],[0,1]]){
   const nx=x+dx,ny=y+dy;if(nx<0||nx>=w||ny<0||ny>=h)continue;
   const j=ny*w+nx,maskFactor=1-Math.max(mask?.[i]??0,mask?.[j]??0),crowd=(occupancy?.[i]??0)+(occupancy?.[j]??0);
   const a=D*dt*maskFactor/(1+kappa*crowd/2);
   v+=a*(field[j*3+channel]-field[at]);
  }
  next[at]=v;
 }
 return next;
}
const sum=x=>Array.from(x).reduce((s,v)=>s+v,0),square=x=>Array.from(x).reduce((s,v)=>s+v*v,0);
export function densityStudy(){
 const D=.32,dt=.16,kappa=.9,w=19,h=17,n=w*h,seed=47113,r=rng(seed),tests=[];
 let maxDisagreement=0,maxMassError=0,maxIncreaseVariance=0,maxRangeViolation=0;
 for(let rep=0;rep<36;rep++){
  const field=Float64Array.from({length:n*3},()=>r());
  const mask=Float64Array.from({length:n},()=>r()<.07?1:0);
  const occ=Float64Array.from({length:n},()=>Math.floor(r()*7));
  const a=diffusionStep(field,w,h,D,dt,mask,occ,kappa);
  const b=referenceSolver(field,w,h,D,dt,mask,occ,kappa);
  const err=Math.max(...a.map((x,i)=>Math.abs(x-b[i])));
  const mass=Math.abs(sum(field)-sum(a)),variance=Math.max(0,square(a)-square(field));
  const mini=Math.min(...field),maxi=Math.max(...field),violation=Math.max(0,mini-Math.min(...a),Math.max(...a)-maxi);
  maxDisagreement=Math.max(maxDisagreement,err);maxMassError=Math.max(maxMassError,mass);maxIncreaseVariance=Math.max(maxIncreaseVariance,variance);maxRangeViolation=Math.max(maxRangeViolation,violation);
  tests.push({rep,independentSolverMaxAbsError:err,massAbsError:mass,energyIncrease:variance,maximumPrincipleViolation:violation});
 }
 // Isolated mass pulse: interior single site, uniform numerical occupancy.
 // From initial isolated cell, neighbor = D*dt/(1+kappa*n).
 const pulse=Array(n*3).fill(0),centerX=9,centerY=8,center=centerY*w+centerX;pulse[3*center]=1;
 const table=[];
 for(const occupancy of [0,1,3,6,10]){
  const dens=new Float64Array(n).fill(occupancy),a=diffusionStep(pulse,w,h,D,dt,null,dens,kappa);
  const observedNeighbor=a[3*(center+1)];const predicted=D*dt/(1+kappa*occupancy);
  table.push({occupancy,observedNeighbor,predictedNeighbor:predicted,absDifference:Math.abs(observedNeighbor-predicted),ratioToZero:observedNeighbor/(D*dt),interpretation:'SYNTHETIC numeric cell occupancy'});
 }
 // Separate hypothesis from physical calibration: infer kappa using synthetic noiseless known pulse positions.
 const known=.9,samples=[0,1,2,3,5,7].map(q=>({occupancy:q,neighbor:D*dt/(1+known*q)}));
 let best=null;for(let v=0;v<=2000;v++){const k=v/1000;const mse=samples.reduce((s,x)=>s+(D*dt/(1+k*x.occupancy)-x.neighbor)**2,0)/samples.length;if(!best||mse<best.mse)best={kappa:k,mse}}
 return {schema:'ripple-alpha-density-study/1.1',evidence:'SIMULATED',params:{D,dt,kappa,grid:[w,h],seed},crossValidation:{runs:tests.length,maxIndependentSolverError:maxDisagreement,maxMassError,maxEnergyIncrease:maxIncreaseVariance,maxMaximumPrincipleViolation:maxRangeViolation},pulse:table,syntheticParameterRecovery:{knownKappa:known,fit:best,warning:'Fitting data generated from the same mathematical form does not validate kappa against physical occupancy.'},tests};
}
