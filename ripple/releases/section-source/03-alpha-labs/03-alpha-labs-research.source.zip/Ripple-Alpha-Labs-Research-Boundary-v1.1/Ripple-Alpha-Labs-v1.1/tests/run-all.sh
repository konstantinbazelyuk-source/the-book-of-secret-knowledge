#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
node tests/regression-v1.mjs > results/v1-regression-run.txt
node research/run-study.mjs > results/numerical-run.txt
node research/extra-study.mjs > results/sensitivity-run.txt
node research/traces.mjs > results/trace-run.txt
python build_viewer.py > results/build-viewer-run.txt
node tests/research-tests.mjs > results/research-tests-run.txt
node tests/viewer-static.mjs > results/viewer-static-run.txt
printf 'All numerical/validation tests passed. Physical camera not connected; no real observations claimed.\n'
