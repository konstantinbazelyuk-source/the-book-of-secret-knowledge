# Evidence and research-stage gates

| Gate | Required evidence | v1.1 status |
|---|---|---|
| SOURCE | Core SHA and original Alpha engine SHA match pinned versions | PASS, source verification |
| LINEAGE | Repeated seeded trials, neutral mutation control, directional mutation control, selection control, full ancestries | PASS, simulation |
| MONOCHROME | preexisting-gray control must NOT count as emergence, absent→present gray is recorded | PASS, isolated software audit; prior detector interpretation invalid |
| FIELD | preregistered parameter grid, 8-step persistence, no injected gray species, independent seeds | PASS, zero events at tested modes |
| DENSITY | two independent solver forms agree, source-free conservation, no overshoot, monotonic smoothing | PASS, numerical consistency |
| OPTICAL | actual fixed-condition camera samples, unclipped dark/clear/sample, camera-specific corrections, repeatability | NOT MEASURED; scripts supplied |
| PHYSICAL-DENSITY | known independent mass/volume/medium composition, constitutive relationship, external verification | NOT MEASURED; no supported claim |
| INTELLIGENCE | predefined task performance, learning rule, unseen test conditions, no circular scoring | NOT STUDIED; not part of this research boundary |

**Do not merge a synthetic success with physical evidence.** Label numerical calculations and simulated randomized outcomes separately, and do not report sensor specifications or real-world measurements from unconnected hardware. Archive all failed runs and reject wrong-provenance inputs. The 1.1 experimental studies are additive to v1.0; the old files and embedded continuous Alpha simulator are frozen.
