# Physical optical calibration SOP — implementation ready, bench measurements pending

**Goal:** Test whether stable real camera RGB signals can track relative transmission through a fixed optical sample, while separating the results from Ripple's digital colony-density variable.

## Prerequisites

- Computer, functioning USB/webcam (not a remote connector), Python 3.10+ and OpenCV: `pip install opencv-python`.
- Fixed rigid geometry, opaque dark blocker, unobstructed clear path, repeatable test material in the same aperture, stable diffuse/backlit white source (prefer non-PWM or known stable DC), neutral target if available.
- Manually lock exposure time, ISO, white balance, focus (through camera software/driver); verify locking in actual hardware controls. Do NOT label automatic exposure as locked. Script cannot guarantee these controls itself.
- Record ambient lighting, distances, measured thickness/path length if available. Ambient stray light and reflections limit any absorption interpretation.
- **No laser required**. Avoid shining lasers into cameras or eyes.

## Measurements, not simulations

1. Open a fixed webcam feed with `python research/capture_webcam.py --geometry RIG-A --illumination LED-STABLE-A --exposure-ms <ACTUAL> --iso <ACTUAL> --white-balance <ACTUAL-PRESET> --confirm-manual-exposure --confirm-manual-white-balance` from inside the project folder. Replace every placeholder by recorded hardware settings.
2. Keys `d`, `c`, `s` record one camera ROI frame each: `d` obstructed light (dark); `c` clear unobstructed path; `s` same aperture with sample. Acquire at least 5 each, alternating the groups or repeating blocks to check drift. Press `q` to save. Script refuses incomplete input.
3. Analyze: `node research/evaluate-camera.mjs ripple-measured-camera-session.json ripple-camera-calibration.json`. It rejects metadata changes, clipped readings, insufficient repeated samples or excessive within-block variation.
4. **Report only camera-relative RGB transmittance** after dark correction and approximate sRGB inverse; do not say measured wavelength-dependent optical density or material density. Instrument camera processing cannot be removed by mathematical inversion without characterization.
5. Repeat on at least 3 days and with the order sample/clear counterbalanced, then compare against a calibrated optical instrument with uncertainty. A cheap reproducible DIY demonstration remains uncalibrated until an instrument of known uncertainty is used.

## Meaning of the variables

- `T_RGB`: camera relative transmittance estimate, dimensionless; depends on device spectral sensitivity and image pipeline.
- `OD_RGB=-log10(T_RGB)`: derived camera-relative pseudo-optical-density; not spectral regular transmittance.
- `rho`: physical material mass density is NOT produced by this instrument or any other RGB-only value without independent composition, geometry, and constitutive model.
- `occupancy`: synthetic lattice agent count used by the numerical diffusion model; neither `rho` nor `OD_RGB`.

## Falsifiable acceptance gate for a *camera proxy*, not metrology-grade absorption

- ≥5 frames in each dark/clear/sample group; all channels dynamic range clear-dark ≥30 code values, none ≥245.
- Camera ISO/exposure/WB metadata stable within each capture, setup IDs unaltered, ROI fixed, no camera motion.
- Replicate range for each channel ≤2+0.02*(clear-dark) code values; this threshold is an **engineering acceptance proposal**, not a universal standard.
- Reproducible means on three independently repeated sessions; report estimated uncertainties and bias on a held-out measured neutral-density reference.
- If unmet, reject measured optical result; report problem, instrument capability and needed fix.

## Device capability caveat

Media capture APIs provide `getCapabilities()`/`getSettings()` but don't ensure the presence of exposureMode, whiteBalanceMode, etc. for every browser. A camera may report an active constraint different from one requested. MDN: https://developer.mozilla.org/en-US/docs/Web/API/Media_Capture_and_Streams_API/Constraints. For traceable optical readings consult NIST calibration services https://www.nist.gov/programs-projects/traceability-molecular-spectrophotometry.
