# Ripple Alpha Labs v1.1 — completed research boundary

**Date:** 2026-10-13/14 (UTC container execution); scope: deterministic DIGITAL simulations, **not** physical measurements. Original author/project: Ripple, user-originated. The purpose is to isolate causes of numerical grayscale convergence, test the v1.0 density computation, and create a scientifically defensible webcam calibration workflow.

## RQ1. Can a monochrome digital genome emerge without explicit grayscale selection?

### Audit of the actual v1.0 mutation code

In `engine.mjs`, `mutateGenome` perturbs one of three RGB weights by:

    w[i] <- clip( w[i]*(1-p) + mean(w)*p + U(-0.025,0.025), 0, 1)

When `p>0`, each mutation pulls one channel toward its current RGB mean. That is already a built-in **monochromatizing inductive bias**, even when parents are inherited randomly. `searchMonochromeGenome` additionally selects the least-chromatic of six candidates per generation. The existing code is not truly unbiased mutation.

### Alpha v1.1 preregistered protocol

- Chromatic root genomes: Crimson, Emerald, Cobalt and Amber, excluding already-gray Neutral reference.
- Mutation policies: `neutral_random` (p=0, random inheritance); `biased_random` (p=.65, random inheritance); `neutral_selected` (p=0, least-chromatic selection); `biased_selected` (p=.65, least-chromatic selection).
- Every condition: 30 generations, six candidate evaluations per generation, jitter uniformly distributed over ±0.025 in the mutated channel, exactly one mutated channel per candidate.
- All candidate budgets held constant; selection in v1.1 does not include v1.0's extra elitist reject-if-worse rule.
- Predefined exploratory/training seeds: 12; untouched holdout seeds: 192, crossed with 4 parent genomes = 768 policy trials.
- Monochrome condition: mean RGB weight >0.055 and `(max(R,G,B)-min(R,G,B))/(R+G+B+1e-5) <= 0.08`.
- A `hit` is an event occurring at least once within 30 generations. Separately record terminal (generation-30) monochrome rate. The per-trial digital ancestry carries parent IDs. All results are **SIMULATED**.

### Holdout results

| Policy | Ever monochrome / 768 | Percent | 95% Wilson interval | End chroma (mean) |
|---|---:|---:|---:|---:|
| Neutral mutation, random inheritance | 0 | 0.00% | 0–0.50% | 0.7150 |
| Gray-biased mutation, random inheritance | 767 | 99.87% | 99.27–99.98% | 0.0241 |
| Neutral mutation, chroma-selection | 0 | 0.00% | 0–0.50% | 0.3711 |
| Gray-biased mutation, chroma-selection | 768 | 100.00% | 99.50–100% | 0.0054 |

Every high-rate gray-biased result is explained by the specified channel-mixing rule. The few random/selected differences are small relative to the highly favorable directional mutation. `biased_random` terminal hits: **757/768** (some transiently hit then departed); `biased_selected` terminal hits: **768/768**. The numerical coverage statement applies ONLY to this deterministic synthetic sampling space; Wilson intervals are descriptive Monte Carlo sampling intervals, not real-population or biological confidence.

**Sensitivity counterexample:** Using neutral (p=0) channel jitter with wider width and/or longer lineages, `neutral_selected` recorded 47/192 monochrome events at width=0.05 and 60 generations, 190/192 at width=0.15 and 30 generations, 192/192 at width=0.30 and 30 generations. Random inheritance at width=0.30 and 60 generations recorded 19/192. Therefore a zero at one radius/generation budget is NOT evidence of theoretical impossibility. Records: `results/sensitivity.json`.

**Conclusion:** Our initial v1.0 observation of gray descendants was not proof of emergent untargeted gray biology or intelligence. It primarily tests a programmed grayward mutation operator. To test genuine undirected outcomes, specify the mutation distribution and evaluate its range and selection procedure separately. The Alpha now does so.

## RQ2. Does the existing RGB field create sustained grayscale through diffusion, occlusion or occupancy?

A separate numerical experiment ran 32 independently seeded simulations for each of four modes: baseline, occlusion, occupancy-corrected diffusion, and combined. `20×16` grid, 240 time steps, v1.0 engine unchanged, original monochrome field criterion: >=15% of sufficiently bright traversable cells (`mean channel brightness >=0.06`) with normalized chroma ≤0.055 for eight consecutive steps. **0/32** in each mode met this criterion, **0/128** total. The sole meaning is no event under these tests. It is not evidence that passive RGB mixing or gray generation is impossible at other geometry, diffusion, duration or intensity conditions.

### Critical detection failure in earlier Alpha

The v1.0 event `field_monochrome_emerged` actually means **eight consecutive samples above threshold**. A field pre-filled with a gray RGB value `(0.3,0.3,0.3)` produces a reported 'emerged' event at step 8 *even though it started gray*. We reproduced this directly in the unchanged engine. This is a false **interpretation**, not necessarily a numerical bug in the persistence calculation.

New `MONO-TRANSITION-1`: record baseline and require a documented non-gray interval (at least 4 observations) followed by at least 8 consecutive above-threshold observations before labeling a *transition*. This new audit rejected the pre-existing-gray positive field and correctly registered a deliberately forced synthetic gray transition at step 15. A subthreshold negative control remained unflagged. The old engine/source is still locked and preserved; scientific results use the independent audit.

A recorded numerical gray transition can still come from pre-programmed source mixtures, threshold choices, field initialization, or injected color conversion. It is not proof of autonomous biological mutation.

## RQ3. Is density-corrected diffusion computationally valid and physically verified?

The v1.0 pairwise finite-volume update on edge i,j is:

    flux_ij^c = (dt*D)/(1+kappa*(n_i+n_j)/2) * (field_j^c - field_i^c)

An equal and opposite flux is applied to the pair. `n_i` denotes **numerical simulated colony occupancy**. No atom, mass density, or physical attenuation is measured.

The v1.1 independently implemented **cell-centric** 4-neighbor solver sums contributions to each cell without shared pairwise flux updates. Testing 36 randomized 19×17 grids with fixed occupancy, masks and RGB gave:

| Test | Observed maximum |
|---|---:|
| Absolute pairwise-vs-cell-centric solver difference | 2.220446049250313e-16 |
| Source-free total RGB mass drift | 9.094947017729282e-13 |
| Squared field norm increase | 0 |
| Maximum-principle excursions | 0 |

The uniform-occupancy isolated impulse (D=.32, dt=.16, kappa=.9) predicts immediate neighbor transfer `0.0512/(1+0.9*n)`; the tested original solver reproduced the result exactly at n=0,1,3,6,10, including n=6 transfer **0.0080** (84.375% smaller than zero occupancy). Recovering `kappa=0.9` from data *generated using kappa=0.9* is only a synthetic unit test—circular as physical validation.

**Important confound:** In the full `AlphaLab`, turning on density also changes agent movement via a density-penalty term. Therefore the prior average-agent-signal comparison does NOT isolate the transport parameter. The v1.1 isolated transport tests remove agent motion to cross-check the flux algorithm. It is computationally sound under the tested bounded settings; its constitutive link from real-world density to diffusion remains an **untested hypothesis**.

Established numerical basis: discrete diffusion on graphs and maximum principles; see Hošek & Volek, Applied Mathematics and Computation 361 (2019) 630–644, https://doi.org/10.1016/j.amc.2019.06.014.

## RQ4. Can we calibrate a real camera to validate opacity or density?

**No real camera input was supplied or captured in this task.** A physically measured optical result is therefore unavailable. To make future testing falsifiable, v1.1 supplies `research/capture_webcam.py` and `research/evaluate-camera.mjs`.

The capture program records webcam-image RGB values, frame kind, UTC timestamp, ROI ID, geometry/illumination ID and user-confirmed fixed manual exposure, ISO and white-balance. Captures >=4 replicates per dark (blocked), clear (unobstructed), and sample (test target) configuration. The verifier rejects incomplete or clipped frames, uncontrolled camera metadata, weak dark/clear separation, and unstable replicates. If valid, it calculates a display-referred three-channel reference ratio (optionally sRGB-inverted) and approximate relative optical density `-log10(T)`. It does **not** invent wavelength-resolved light attenuation from the three broadband RGB channels; camera gamma, lens flare, reflections and spectral sensitivity remain confounds. For physical transmittance verification, use calibrated optical density/transmittance standards or independent photodiode/spectrophotometer measurements.

NIST guidance: spectrophotometry requires geometry and spectral control; reference materials ensure traceability only for specified wavelength and transfer conditions. https://www.nist.gov/programs-projects/traceability-molecular-spectrophotometry and https://www.nist.gov/programs-projects/spectrophotometry. Camera constraints are platform-specific; MDN https://developer.mozilla.org/en-US/docs/Web/API/Media_Capture_and_Streams_API/Constraints.

**No measured scattering or physical density conclusion is drawn.** Real optical density, volumetric mass density, and image edge density are separate measurands; do not substitute one for another.

## Scientific acceptance conclusions

- ACCEPT the source-verified mathematical modules and independently reproduced numerical invariants.
- ACCEPT `gray-selected descendant` and `gray-biased random descendant` as **digital software classifications**, not spontaneous physical mutation.
- ACCEPT the new detector as a stricter **synthetic transition audit**, not proof of biological emergence.
- ACCEPT synthetic occupancy slowing the *model equation*; DO NOT claim a material-density effect until calibrated empirical data supports an identifiable coefficient.
- REJECT physical transmittance/density claims until actual hardware frames, controls, uncertainty estimates, repeat runs, and independent optics instruments are provided.

Full trial data, protocols, and checksums are saved beside this report. The v1.0 engine and v0.1 neuron are unchanged.
