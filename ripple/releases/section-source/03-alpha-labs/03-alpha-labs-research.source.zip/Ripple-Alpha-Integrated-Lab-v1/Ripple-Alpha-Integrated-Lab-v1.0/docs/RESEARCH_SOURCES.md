# Open technical references and attribution

Verified public technical sources, consulted during Alpha design (2026-10-13):

- EPFL, Neuronal Dynamics, LIF neuron reference: https://neuronaldynamics.epfl.ch/online/Ch1.S3.html — mathematical basis of original neuron, not evidence that this project discovered the LIF model.
- MIT Center for Bits and Atoms finite differences: https://compute.cba.mit.edu/classes/864.26/NMM/FiniteDifferences.html — forward explicit diffusive update and time-step stability analysis.
- Beer–Lambert approximation review: https://pmc.ncbi.nlm.nih.gov/articles/PMC8553265/ — exponential optical attenuation and limits, including scattering concerns.
- Luanti official Lua modding API: https://api.luanti.org/ — prospective engine interface only; no Luanti runtime tested in this release.
- Mesa agent-based modeling documentation: https://mesa.readthedocs.io/stable/index.html — comparative open spatial ABM architecture; not imported, not executed in this package.
- PyTorch reproducibility notes: https://docs.pytorch.org/docs/stable/notes/randomness.html — caveat about deterministic seeds and cross-platform reproducibility; no PyTorch dependency is used in Alpha.
- NIST SHA-256 standard FIPS 180-4: https://csrc.nist.gov/pubs/fips/180-4/upd1/final — cryptographic hash for deterministic integrity markers, not encryption or authentication.

Source modules were recovered from the user's own project files and library, and archived verbatim. Any open reference above informs the mathematical method; code here is new or already present in the project and is not represented as copied code from the websites.
