# Ripple version and source continuity catalog

The following original files were copied byte-for-byte from the user project/library and were not modified. An archived file is **not** necessarily an active feature.

- `legacy/colony_v05_LOCKED.js` — SHA256 `a1de9781bc73a107b28113a628b7c6bb6f226cdca079838c9d8be1f76bc07fd9`
- `legacy/constraint_study_v04_LOCKED.py` — SHA256 `f83e61e2f34b2cb135e648be475171e1cecb9396379e5b6c802335eeab519f34`
- `legacy/feedback_sweep_v03_LOCKED.js` — SHA256 `a5b85a6bbe4cc9514bbe6491336b6db597dfbdd666471e9a9c3cc09abc16c190`
- `legacy/genome_v05_LOCKED.js` — SHA256 `743892a4036ce16222af437630ffd3c966a7da69a0da3eb7de1292723e232ea1`
- `legacy/kokoro_ripple_python_LOCKED.py` — SHA256 `46531a6222a2d29848e93408e431884281c0e44b91ea5195cddf5a4c270eefd9`
- `legacy/neuron_integration_v04_LOCKED.js` — SHA256 `ac8f714f0e6f7c52a5dc06215b68f38e956b1a3550d423d49ac44f4a144cc670`
- `legacy/optical_hybrid_v04_LOCKED.js` — SHA256 `6ff345906686b9825a829c0c870bcfe1cc42edb98762a9505d268bf938dd0adf`
- `legacy/optical_study_v04_LOCKED.py` — SHA256 `05a330095abb9f0d6046ff4fe04fc98c0b87920ad7636fed65f528dc3ea6c7ab`
- `legacy/parallel_colony_v02_LOCKED.js` — SHA256 `c21bb32f01876ce7bb4a0d7e5f798edef5097f72b8d01513797cd93868cea3d6`
- `legacy/photoreceptor_v06_LOCKED.js` — SHA256 `a55ec7ec8582504ea6257b886bc03624da92d799ea2608fba68f5c50b3828986`
- `legacy/quaternary_v07_LOCKED.mjs` — SHA256 `9c1879f6bc024e564e5e25b0294ac62b34d67aafffe26f9ddfae52675d66f695`
- `legacy/ripple_colony_v01_LOCKED.js` — SHA256 `d75d4208e92f19623b127615bd52b4002e85d2c0a59b76471764b55a24294210`
- `legacy/ripple_mycelium_v05_LOCKED.js` — SHA256 `d75d4208e92f19623b127615bd52b4002e85d2c0a59b76471764b55a24294210`
- `legacy/ripple_photoreceptor_v06_LOCKED.js` — SHA256 `dba6639b7902f0c702d15fff588524629f3754cfd72d7b704f22a76b78960ee3`
- `legacy/specialist_colony_v03_LOCKED.js` — SHA256 `0880c9089fd8bbc740c2b18b080061a52d91a80c9b902772a515efdf5656ffbb`
- `legacy/specialist_math_v03_LOCKED.js` — SHA256 `50395902abd2bd4375c80ad049e24fac7929ed820c90eb1bea64ead10649ae7e`
- `legacy/spiderscan_optical_agent_LOCKED.py` — SHA256 `7f2f611cd8f1717c3d3dcae745dbd41efc37e24315d93878231db52eaf614f77`
- `legacy/world_v05_LOCKED.js` — SHA256 `af2954473634a635a9ac884a5c9115215e3f3cb4ebf21f02663e2bbc3b00bcbf`

## Active and tested

- **Original v0.5 neuron**: imported into `src/alpha_engine.js` for actual simulated pulse-gated coverage.
- **Photoreceptor v0.6**: `Photoreceptor`, `absorb`, and `opacityCal` exercised by actual integration tests; its global-export neuron is executed in an isolated JS context. Not yet called automatically on Alpha world cells.
- **Quaternary v0.7**: actual symbol codec, bounded VM and frame features exercised by integration tests. Not controlling new colony growth.
- **v0.1–v0.5, Kokoro, SpiderScan**: archived from source; separate runtime integration deliberately withheld to avoid conflating incompatible interfaces or implying operational hardware.

## Other project resources located in the Library

`Ripple_Neuron_Open_Prototype`, sensor bridge, heterodyne CAD, field sphere, phone widget, installable app, ground SpiderScan, and Kokoro mesh may be independently used in later stages. Their binary/electronic prototypes are not active in this numerical lab. No user repository or existing projects were rewritten.

## Executable v0.5 reference bundle

The original `src/colony.js`, `genome.js`, `world.js`, `domains.js`, `specialist_math_reference.js`, and `ripple_core_reference.js` were copied **byte-for-byte** to `legacy/v05_executable/`. The original v0.5 `Colony` can execute independently and is exercised by `tests/legacy_v05.test.js`. This is an executable regression anchor, not a refactor of the historical code.

`data/version_registry.json` is the definitive source-status registry (active / executable adapter / archived). It distinguishes source presence from actual combined use and includes SHA-256 checksums.
