from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
url=(root/'Ripple-Alpha-Integrated-Lab-v1.0.html').resolve().as_uri()
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox','--disable-dev-shm-usage'])
 for name, width, height in [('desktop',1280,900),('mobile',390,844)]:
  page=browser.new_page(viewport={'width':width,'height':height}, device_scale_factor=1)
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto('about:blank');page.set_content((root/'Ripple-Alpha-Integrated-Lab-v1.0.html').read_text(),wait_until='load',timeout=20000)
  page.wait_for_timeout(250)
  assert page.locator('#trialCount').inner_text()=='180'
  assert page.locator('#geneCount').inner_text()=='15'
  assert page.locator('#agent option').count()>0
  assert not errors,errors
  page.select_option('#dim','3d');page.select_option('#variant','diffusion');page.select_option('#mode','isometric');page.locator('#tick').fill('12');page.select_option('#environment','gray');page.locator('#play').click()
  assert 'PHASE B' in page.locator('#phase').inner_text()
  assert 'generation' in page.locator('#details').inner_text()
  assert not errors,errors
  assert page.evaluate('document.documentElement.scrollWidth <= innerWidth+1'), 'horizontal overflow'
  path=root/'charts'/('alpha_lab_'+name+'.png');page.screenshot(path=str(path),full_page=True)
  print(name,'passed',page.locator('#obs').inner_text(),'screenshot',path)
  page.close()
 browser.close()
