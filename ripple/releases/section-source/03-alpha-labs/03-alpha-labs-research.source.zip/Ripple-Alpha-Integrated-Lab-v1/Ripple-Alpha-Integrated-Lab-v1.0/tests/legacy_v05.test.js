const test=require('node:test'),assert=require('node:assert/strict');
const {Colony}=require('../legacy/v05_executable/colony.js');
const {BASE,encode,decode}=require('../legacy/v05_executable/genome.js');
const {makeWorld}=require('../legacy/v05_executable/world.js');
test('preserved v0.5 source runs standalone under its own original dispatch policy',()=>{const c=new Colony(BASE,{seed:2,dim:2,profile:'stream',horizon:8,dt:.1});const r=c.run();assert.ok(r.mapped>0&&r.mapped<r.cells);assert.equal(r.cells,100);assert.equal(c.verify(),true);});
test('preserved v0.5 genome codec round-trips',()=>{const e=encode(BASE);assert.deepEqual(decode(e),BASE);});
test('original v0.5 3d world is 147-voxel schema',()=>{const w=makeWorld(3,4);assert.equal(w.cells.length,147);});
