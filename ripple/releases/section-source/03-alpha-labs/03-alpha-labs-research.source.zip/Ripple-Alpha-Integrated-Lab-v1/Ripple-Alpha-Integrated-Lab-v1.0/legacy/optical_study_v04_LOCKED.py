"""Ripple optical input study, synthetic signals only. CC0-1.0.
The synthetic response matrix is NOT an AS7341 calibration or measured sensor data.
"""
from __future__ import annotations
import argparse, json, math, pathlib
import numpy as np
from scipy.optimize import nnls

ROOT=pathlib.Path(__file__).resolve().parents[1]
A=np.array([[1.00,.24,.09],[.18,1.00,.20],[.10,.23,1.00],[.51,.46,.56]],float)
FS=256; N=512; DEPTH=.48
FREQ=np.array([7.,11.,17.])
TS=np.arange(N)/FS

def synthetic_case(seed:int,case:str):
    rng=np.random.default_rng(seed)
    strength=rng.uniform(.0,.92,3)
    phase=np.zeros(3)
    ambient=rng.uniform(.03,.12,4)
    flicker=.07; noise=.025; drift=0.; saturation=2.6
    used_A=A.copy(); intruder=0.
    if case=='ambient_flicker': ambient+=rng.uniform(.16,.42,4);flicker=.38;noise=.06;drift=.15
    if case=='weak_light':strength=rng.uniform(0,.11,3);ambient+=.25;flicker=.23;noise=.07;drift=.10
    if case=='phase_shift':phase=rng.uniform(-1.4,1.4,3);ambient+=.10;noise=.05
    if case=='saturation': strength=rng.uniform(.6,1.,3);ambient+=.24;flicker=.28;noise=.04;saturation=1.25
    if case=='interference': ambient+=.25; noise=.065;intruder=.38
    if case=='calibration_drift':used_A=A+rng.normal(0,.095,(4,3));used_A=np.clip(used_A,.02,1.5);ambient+=.08;noise=.05
    if case=='dark': strength=np.zeros(3);ambient+=rng.uniform(.12,.35,4);noise=.055;flicker=.3;drift=.1
    # LED intensity modulation at 7,11,17 Hz, then spectral mixing by an intentionally synthetic response matrix.
    carrier=1+DEPTH*np.sin(2*np.pi*TS[:,None]*FREQ+phase)
    y=carrier@(used_A*strength).T + ambient
    y+=flicker*np.sin(2*np.pi*50*TS+0.5)[:,None]
    y+=drift*(TS/2)[:,None]
    if intruder:
        y+=intruder*np.sin(2*np.pi*11.25*TS+.4)[:,None]*np.array([.52,.47,.46,.36])[None,:]
    y+=rng.normal(0,noise,y.shape)
    over=(y>=saturation).mean()
    y=np.clip(y,0,saturation)
    return dict(truth=strength, y=y, ambient=ambient, noise=noise, over=float(over), phase=phase, response=used_A)

def decode(case:dict):
    y=case['y']; ambient=case['ambient']; noise=case['noise']
    # Baseline: uncalibrated RGB=first three channel means; typically cross talk + unknown ambient.
    raw=np.clip(y[:,:3].mean(axis=0),0,1)
    # Calibrated, dark-reference-corrected DC model. It cannot correct drift or wrong spectral response matrix.
    dc,_=nnls(A,np.mean(y,axis=0)-ambient)
    # Synchronous lock-in quadrature, allowing unknown carrier phase.
    amps=[];phase=[];residual=[]
    for f in FREQ:
        s=np.sin(2*np.pi*f*TS);c=np.cos(2*np.pi*f*TS)
        I=(2/N)*(s@y); Q=(2/N)*(c@y)
        # shared phase recovered by projecting the channel vector onto the known spectral signature
        col=A[:,len(amps)]
        coeff_i=float(np.dot(I,col)/np.dot(col,col))
        coeff_q=float(np.dot(Q,col)/np.dot(col,col))
        amp=math.hypot(coeff_i,coeff_q)/DEPTH
        # conservative noise-floor test, but the ambient interference can invalidate it.
        noise_se=(noise*math.sqrt(2/N))/(DEPTH*math.sqrt(float(col@col)))
        if amp < 3*noise_se:amp=0.
        amps.append(amp)
        phase.append(math.atan2(coeff_q,coeff_i))
        residual.append(float(np.linalg.norm(I-coeff_i*col)+np.linalg.norm(Q-coeff_q*col)))
    lockin=np.clip(np.array(amps),0,1)
    # Rejected frames do not automatically become trustworthy; downstream must explicitly handle them.
    return dict(raw=raw, calibrated_dc=np.clip(dc,0,1), lockin=lockin,
                residual=sum(residual), saturation=case['over'],phase=np.array(phase))

def run(n_per_case:int=90,seed:int=1943):
    regimes=['clean','ambient_flicker','weak_light','phase_shift','saturation','interference','calibration_drift','dark']
    rows=[]; traces=[]
    for i,scenario in enumerate(regimes):
        for k in range(n_per_case):
            sample=synthetic_case(seed+i*100000+k,scenario)
            d=decode(sample)
            truth=sample['truth']; vectors={m:d[m] for m in ('raw','calibrated_dc','lockin')}
            row=dict(scenario=scenario,index=k,seed=seed+i*100000+k,truth=truth.tolist(),
                     saturation=sample['over'],residual=d['residual'])
            for method,v in vectors.items():
                row[method]=v.tolist();row[method+'_mae']=float(np.mean(np.abs(v-truth)))
                row[method+'_drive_error']=float(abs(np.array([2,1.2,-1.4])@(v-truth)))
                row[method+'_false_detect']=bool(np.max(v)>.08 and scenario=='dark')
            rows.append(row)
            traces.append({key:row[key] for key in ('scenario','truth','raw','calibrated_dc','lockin','saturation','residual')})
    summary={}
    for group in ['ALL']+regimes:
        subset=[r for r in rows if group=='ALL' or r['scenario']==group]
        summary[group]={m:{'n':len(subset), 'mae':float(np.mean([r[m+'_mae'] for r in subset])),
                           'p90':float(np.quantile([r[m+'_mae'] for r in subset],.9)),
                           'drive_mae':float(np.mean([r[m+'_drive_error'] for r in subset])),
                           'dark_false_fraction':float(np.mean([r[m+'_false_detect'] for r in subset])) if group=='dark' else None}
                           for m in ('raw','calibrated_dc','lockin')}
    # separate sequence for neuron cross-validation: chronological blocks in reproducible mixed regimes.
    sequence=[]
    for step in range(1200):
        block=(step//150)%len(regimes)
        record=traces[block*n_per_case + (step*17+step//7)%n_per_case]
        sequence.append(record)
    out=ROOT/'data';out.mkdir(exist_ok=True)
    (out/'optical_trials.json').write_text(json.dumps(rows,indent=1))
    (out/'optical_summary.json').write_text(json.dumps(summary,indent=2))
    (out/'neuron_sequence.json').write_text(json.dumps(sequence))
    print('OPTICAL_STUDY',json.dumps({'trials':len(rows),'summary':summary},indent=2))
    return rows, summary

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--per-regime',type=int,default=90);args=p.parse_args()
    run(args.per_regime)
