"""Independent, stdlib-only Python port of preserved Ripple Neuron v0.1.
Keep JS source unmodified. This port exists to instrument original Python Kokoro.
Events are mathematical constructs, not biological/optical measurements.
"""
import math


def bound(x, low, high):
    return max(low, min(high, x))


class RippleNeuron:
    def __init__(self, theta=0.45, adaptive=True, target=1.0):
        self.theta = theta
        self.adaptive = adaptive
        self.target = target
        self.tau_v = 0.5
        self.tau_r = 5.0
        self.refractory = 0.1
        self.eta = 0.08
        self.lo = 0.15
        self.hi = 2.5
        self.t = 0.0
        self.u = 0.0
        self.rate = 0.0
        self.rest = 0.0

    def step(self, x, dt):
        if len(x) != 3 or any(not math.isfinite(v) for v in x) or not math.isfinite(dt) or not (0 < dt <= 0.5):
            raise ValueError('Invalid input or elapsed time')
        r,g,b = [bound(v,0,1) for v in x]
        drive = 2*r + 1.2*g - 1.4*b
        start = self.t
        events=[]
        elapsed=0.0
        while elapsed < dt-1e-12:
            left=dt-elapsed
            if self.rest > 1e-12:
                held=min(left,self.rest)
                self.rest=max(0.0,self.rest-held)
                self.u=0.0
                elapsed+=held
                continue
            crossing=math.inf
            if self.u>=self.theta:
                crossing=0.0
            elif drive>self.theta:
                crossing=self.tau_v*math.log((drive-self.u)/(drive-self.theta))
            if crossing<=left+1e-12:
                elapsed+=max(0.0,min(left,crossing))
                events.append(start+elapsed)
                self.u=0.0
                self.rest=self.refractory
            else:
                self.u=max(0.0,drive+(self.u-drive)*math.exp(-left/self.tau_v))
                elapsed=dt
        decay=math.exp(-dt/self.tau_r)
        integral=self.rate*self.tau_r*(1-decay)
        self.rate*=decay
        for event in events:
            d=math.exp(-(start+dt-event)/self.tau_r)
            self.rate+=d/self.tau_r
            integral+=1-d
        if self.adaptive:
            self.theta=bound(self.theta+self.eta*(integral-self.target*dt),self.lo,self.hi)
        self.t=start+dt
        return {'t':self.t,'u':self.u,'theta':self.theta,'rate':self.rate,'drive':drive,'count':len(events),'events':events}
