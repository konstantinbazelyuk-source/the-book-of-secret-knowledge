'use strict';
const math=require('./specialist_math_reference');
function domainTask(type,obs){const [r,g,b]=obs.corrected;
 if(type==='learning')return math.lossGradient([{x:[1,r,g],y:r+.1>g?1:0},{x:[1,g,b],y:g+.1>b?1:0}],[0,.2,-.2]);
 if(type==='product')return math.productStats([{quantity:obs.resource,unitPriceCents:1299,unitCostCents:499,stock:4},{quantity:1,unitPriceCents:150,unitCostCents:70,stock:1}]);
 if(type==='study'){const i=String(obs.cell),e=[{id:i+'a',value:r,variance:.08},{id:i+'b',value:g,variance:.10},{id:i+'a',value:r+.1,variance:.08}];return math.studyCombine([e]);}
 throw Error('unsupported computation domain');}
function serialize(x){return JSON.stringify(x);}
module.exports={domainTask,serialize};
