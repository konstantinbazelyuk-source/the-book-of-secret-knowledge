'use strict';
// Non-invasive optional adapter: repairs v0.3 reporting inconsistency only.
// The underlying ControlledNeuron and original RippleNeuron are unchanged.
const {ControlledNeuron}=require('../baseline/feedback_sweep');
class ReportCorrectedHybrid {
  constructor(target=1){this.inner=new ControlledNeuron('hybrid-fast',target);}
  step(inputs,dt){const before=this.inner.n.theta;const out=this.inner.step(inputs,dt);
    return {...out,thetaBefore:before,theta:this.inner.n.theta,thetaAfter:this.inner.n.theta};}
}
module.exports={ReportCorrectedHybrid};
