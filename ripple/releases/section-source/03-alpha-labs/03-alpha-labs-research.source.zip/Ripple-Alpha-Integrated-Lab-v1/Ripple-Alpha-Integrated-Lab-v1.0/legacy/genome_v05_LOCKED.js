'use strict';
const crypto=require('node:crypto');
const MODES={growth:['single','fixed4','reactive','capacity','economy','hybrid'],routing:['roundrobin','leastload','spatial','affinity','learned'],graph:['tree','ring','mesh'],role:['general','mixed'],feedback:['original']};
const BOUNDS={spawnThreshold:[1,12],retireDelay:[3,40],maxWorkers:[1,12],hopPreference:[.1,2],energyPenalty:[0,2]};
const BASE=Object.freeze({growth:'hybrid',routing:'leastload',graph:'tree',role:'general',feedback:'original',spawnThreshold:5,retireDelay:12,maxWorkers:8,hopPreference:.5,energyPenalty:.18});
function canonical(o){if(Array.isArray(o))return '['+o.map(canonical).join(',')+']';if(o&&typeof o==='object')return '{'+Object.keys(o).sort().map(k=>JSON.stringify(k)+':'+canonical(o[k])).join(',')+'}';return JSON.stringify(o);}
function sha(o){return crypto.createHash('sha256').update(typeof o==='string'?o:canonical(o)).digest('hex');}
function validate(g){if(!g||typeof g!=='object')throw Error('genome expected');for(const k of Object.keys(g))if(!(k in BASE))throw Error('unknown gene '+k);for(const [k,v] of Object.entries(MODES)){if(!v.includes(g[k]))throw Error('bad enum '+k);}for(const [k,b] of Object.entries(BOUNDS)){if(!Number.isFinite(g[k])||g[k]<b[0]||g[k]>b[1])throw Error('bad numeric '+k);}
 if(!Number.isInteger(g.maxWorkers))throw Error('bad maxWorkers integer');return true;}
function encode(g,parent=null){validate(g);const payload={schema:'ripple-genome/1',genes:Object.fromEntries(Object.keys(BASE).map(k=>[k,g[k]])),parent:parent||null};return {...payload,marker:sha(payload)};}
function decode(m){if(m.schema!=='ripple-genome/1'||typeof m.marker!=='string'||m.marker!==sha({schema:m.schema,genes:m.genes,parent:m.parent}))throw Error('marker mismatch');validate(m.genes);return {...m.genes};}
function seeded(seed){let s=seed>>>0;return ()=>{s^=s<<13;s^=s>>>17;s^=s<<5;return (s>>>0)/4294967296;};}
function mutate(parent,rng){const g={...parent}, keys=[...Object.keys(MODES).filter(k=>k!=='feedback'),...Object.keys(BOUNDS).filter(k=>k!=='maxWorkers')];const key=keys[Math.floor(rng()*keys.length)];if(key in MODES){const options=MODES[key].filter(x=>x!==g[key]);g[key]=options[Math.floor(rng()*options.length)];}
 else {const [a,b]=BOUNDS[key], span=b-a;const change=(rng()<.5?-1:1)*Math.max(.1,span*.15);g[key]=Math.round(Math.min(b,Math.max(a,g[key]+change))*100)/100;}
 validate(g);return g;}
class Ledger{constructor(){this.items=[];}append(type,payload){const prev=this.items.length?this.items.at(-1).hash:'GENESIS';const entry={index:this.items.length,type,payload,prev};const record={...entry,hash:sha(entry)};this.items.push(record);return record;}verify(){let prev='GENESIS';for(let i=0;i<this.items.length;i++){const x=this.items[i];if(x.index!==i||x.prev!==prev||x.hash!==sha({index:x.index,type:x.type,payload:x.payload,prev:x.prev}))return false;prev=x.hash;}return true;}}
module.exports={MODES,BOUNDS,BASE,canonical,sha,encode,decode,seeded,mutate,Ledger,validate};
