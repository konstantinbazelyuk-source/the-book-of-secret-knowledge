'use strict';
const {RippleNeuron}=require('./ripple_core_reference');
const {BASE,encode,validate,Ledger,sha}=require('./genome');
const {makeWorld,observation,arrivals}=require('./world');
const {domainTask}=require('./domains');
const TYPES=['learning','product','study'];
function quantile(v,q){if(!v.length)return null;const a=[...v].sort((a,b)=>a-b);return a[Math.max(0,Math.ceil(a.length*q)-1)];}
class Colony{
 constructor(genome=BASE,{dim=2,seed=1,profile='burst',service='parity',horizon=160,dt=.1,hopDelay=.2}={}){
  validate(genome);if(!['burst','shift','stream'].includes(profile)||!['parity','advantage','reverse'].includes(service))throw Error('bad experiment');
  if(!Number.isFinite(horizon)||horizon<1||dt<=0||dt>.5)throw Error('bad sim time');
  this.g={...genome};this.config={dim,seed,profile,service,horizon,dt,hopDelay};this.world=makeWorld(dim,seed);this.pending=arrivals(this.world,profile);this.pending.sort((a,b)=>a.arrival-b.arrival||a.id-b.id);
  this.time=0;this.nodes=[];this.next=0;this.jobs=new Map();this.completed=[];this.record=new Map();this.births=0;this.deaths=0;
  this.messages=0;this.hops=0;this.workSeconds=0;this.events=0;this.lastBirth=-100;this.lastDeath=-100;this.quietSince=null;this.retries=0;
  this.bandit={};this.rr=0;this.ledger=new Ledger();this.ledger.append('genome',encode(this.g));this.ledger.append('world',{hash:this.world.worldHash,dim,seed});this.spawn('general');
  if(this.g.growth==='fixed4')while(this.nodes.length<Math.min(4,this.g.maxWorkers))this.spawn('general');
 }
 spawn(role='general'){
  if(this.nodes.length>=this.g.maxWorkers)return null;
  const parent=this.nodes.length?this.nodes.at(-1).id:null;
  const w={id:this.next++,parent,role,n:new RippleNeuron(),queue:[],active:null,left:0,done:0,events:0,started:this.time};
  this.nodes.push(w);this.births++;return w;
 }
 edges(){const n=this.nodes.length;let edges=Array.from({length:n},()=>[]);const link=(a,b)=>{if(a===b)return;edges[a].push(b);edges[b].push(a);};
  if(this.g.graph==='mesh'){for(let i=0;i<n;i++)for(let j=i+1;j<n;j++)link(i,j);}
  if(this.g.graph==='ring'){for(let i=1;i<n;i++)link(i-1,i);if(n>2)link(n-1,0);}
  if(this.g.graph==='tree'){for(let i=1;i<n;i++)link(i,Math.floor((i-1)/2));}
  return edges;
 }
 distance(index){const edges=this.edges();const seen=new Set([0]),q=[[0,0]];while(q.length){const [k,d]=q.shift();if(k===index)return d;for(const j of edges[k])if(!seen.has(j)){seen.add(j);q.push([j,d+1]);}}throw Error('disconnected');}
 cost(w,task){if(this.config.service==='parity')return 1;if(this.config.service==='reverse')return w.role==='general'?1:w.role===task.type?2:3;return w.role===task.type?1:w.role==='general'?2:3;}
 load(w){return (w.active?w.left:0)+w.queue.reduce((a,t)=>a+this.cost(w,t),0);}
 select(task){if(this.g.routing==='roundrobin')return this.nodes[(this.rr++)%this.nodes.length];
  const [sx,sy,sz]=this.world.size;const cell=this.world.cells[task.cell];
  const ranks=this.nodes.map((w,i)=>{
   let v=this.load(w),delay=this.distance(i)*this.config.hopDelay;
   if(this.g.routing==='spatial')v+=(Math.abs((cell.x/sx)*(this.g.maxWorkers-1)-i)*.35)+(sz>1?Math.abs(cell.z-sz/2)*.04:0);
   if(this.g.routing==='affinity')v+=this.cost(w,task)*.7;
   if(this.g.routing==='learned'){const e=this.bandit[w.role+':'+task.type];v+=e?e.mean*.8:1.5;}
   return {w,score:v+delay*this.g.hopPreference};});
  ranks.sort((a,b)=>a.score-b.score||a.w.id-b.w.id);return ranks[0].w;
 }
 assign(task){const w=this.select(task),index=this.nodes.indexOf(w),hops=this.distance(index);task.ready=this.time+hops*this.config.hopDelay;
  w.queue.push(task);this.messages+=index!==0?1:0;this.hops+=hops;
 }
 dispatch(){while(this.pending.length&&this.pending[0].arrival<=this.time+1e-8){const t=this.pending.shift();this.jobs.set(t.id,{...t});this.assign(t);}}
 backlog(){return this.nodes.reduce((n,w)=>n+this.load(w),0);}
 scale(){if(['single','fixed4'].includes(this.g.growth))return;
  const q=this.backlog(),oldest=Math.max(0,...this.nodes.flatMap(w=>[...(w.active?[w.active]:[]),...w.queue]).map(t=>this.time-t.arrival));
  const rate=Math.max(.3,this.nodes.reduce((n,w)=>n+Math.max(.3,w.n.rate),0)/this.nodes.length);
  let desired=1;
  if(this.g.growth==='reactive')desired=Math.ceil(q/(this.g.spawnThreshold*(1+this.g.energyPenalty)));
  if(this.g.growth==='capacity')desired=Math.ceil(q/(this.g.spawnThreshold*rate*(1+this.g.energyPenalty)));
  if(this.g.growth==='economy')desired=oldest>16?Math.ceil(q/(this.g.spawnThreshold*1.6*(1+this.g.energyPenalty))):Math.ceil(q/(this.g.spawnThreshold*3*(1+this.g.energyPenalty)));
  if(this.g.growth==='hybrid')desired=oldest>8?Math.ceil(q/(this.g.spawnThreshold*.85*(1+this.g.energyPenalty))):Math.ceil(q/(this.g.spawnThreshold*1.8*(1+this.g.energyPenalty)));
  desired=Math.max(1,Math.min(this.g.maxWorkers,desired));
  if(desired>this.nodes.length&&this.time-this.lastBirth>=1){let num=Math.min(2,desired-this.nodes.length);for(let i=0;i<num;i++){
   let role='general';if(this.g.role==='mixed'){const counts=Object.fromEntries(TYPES.map(x=>[x,0]));for(const w of this.nodes){if(w.active)counts[w.active.type]+=1;for(const t of w.queue)counts[t.type]+=1;}role=TYPES.toSorted((a,b)=>counts[b]-counts[a])[0];}
   const nw=this.spawn(role);if(nw){ // transfer only pending work, never a running task
    const donor=this.nodes.filter(w=>w.id!==nw.id).toSorted((a,b)=>this.load(b)-this.load(a))[0];
    const count=Math.floor(donor.queue.length/2);for(let k=0;k<count;k++){
      const task=donor.queue.pop();this.assign(task);
    }
   }
  }this.lastBirth=this.time;}
  if(desired<this.nodes.length&&q<=this.nodes.length){if(this.quietSince===null)this.quietSince=this.time;
   if(this.time-this.quietSince>=this.g.retireDelay&&this.time-this.lastDeath>=4){const cand=this.nodes.filter(w=>w.id!==0&&!w.active&&!w.queue.length).toSorted((a,b)=>b.id-a.id)[0];
    if(cand){this.nodes.splice(this.nodes.indexOf(cand),1);this.deaths++;this.lastDeath=this.time;}}
  }else this.quietSince=null;
 }
 step(){const dt=this.config.dt;this.time=+(this.time+dt).toFixed(7);this.dispatch();
  if(Math.abs(this.time-Math.round(this.time))<dt/2)this.scale();this.workSeconds+=this.nodes.length*dt;
  for(const w of this.nodes){if(!w.active){const next=w.queue.findIndex(t=>t.ready<=this.time+1e-8);if(next>=0){w.active=w.queue.splice(next,1)[0];w.left=this.cost(w,w.active);}}
   const result=w.n.step(w.active?[.35,0,0]:[0,0,0],dt);w.events+=result.count;this.events+=result.count;
   for(let pulse=0;pulse<result.count&&w.active;pulse++){w.left--;if(w.left>0)continue;
    const task=w.active;w.active=null;const cell=this.world.cells[task.cell];const obs=observation(cell,this.config.seed,task.attempt);
    if(obs.clipped){if(task.attempt>=2)throw Error('retries exhausted');task.attempt++;this.retries++;this.assign(task);continue;}
    const expected=observation(cell,this.config.seed,task.attempt);if(JSON.stringify(obs)!==JSON.stringify(expected))throw Error('sensor nondeterminism');
    const computed=domainTask(task.type,obs);if(!computed||typeof computed!=='object')throw Error('domain work missing');obs.domain=computed;
    if(this.record.has(task.id))throw Error('double completion');this.record.set(task.id,obs);this.jobs.delete(task.id);this.completed.push({id:task.id,type:task.type,latency:+(this.time-task.arrival).toFixed(6),doneAt:this.time,worker:w.id,observed:obs});
    const key=w.role+':'+task.type;const b=this.bandit[key];const c=this.cost(w,task);this.bandit[key]={mean:b?.mean*.75+.25*c||c,n:(b?.n||0)+1};w.done++;
    this.ledger.append('observation',{task:task.id,cell:task.cell,attempt:task.attempt,result:sha(obs)});
   }
  }
 }
 run(){const steps=Math.round(this.config.horizon/this.config.dt);for(let i=0;i<steps;i++)this.step();this.verify();return this.report();}
 verify(){if(!this.ledger.verify())throw Error('ledger damage');const ids=new Set(this.completed.map(x=>x.id));if(ids.size!==this.completed.length)throw Error('duplicate IDs');const outstanding=this.nodes.reduce((n,w)=>n+w.queue.length+(w.active?1:0),0);
  if(this.jobs.size!==outstanding)throw Error('unaccounted dispatched tasks');
  if(this.completed.length+this.jobs.size+this.pending.length!==this.world.cells.length)throw Error('lost tasks');
  if(this.nodes.length<1||this.nodes.length>this.g.maxWorkers)throw Error('population bound');
  for(const {id,observed} of this.completed){const cell=this.world.cells[id];if(observed.cell!==id||observed.occupancy!==cell.blocked||observed.resource!==cell.resource||JSON.stringify(observed.domain)!==JSON.stringify(domainTask(this.completed.find(x=>x.id===id).type,observed)))throw Error('bad mapped data');}
  return true;}
 report(){const done=this.completed;const coverage=done.length/this.world.cells.length;const errors=done.reduce((n,x)=>n+Math.abs(x.observed.corrected[0]-this.world.cells[x.id].spectral[0]),0);
  return {genome:encode(this.g).marker.slice(0,16),dim:this.config.dim,profile:this.config.profile,service:this.config.service,seed:this.config.seed,
   cells:this.world.cells.length,mapped:done.length,coverage:+coverage.toFixed(5),p95:quantile(done.map(c=>c.latency),.95),meanLatency:done.length?+(done.reduce((n,c)=>n+c.latency,0)/done.length).toFixed(4):null,
   workerSeconds:+this.workSeconds.toFixed(2),maxWorkers:this.g.maxWorkers,created:this.births,retired:this.deaths,remaining:this.nodes.length,retries:this.retries,hops:this.hops,
   meanAbsSpectralError:done.length?+(errors/done.length).toFixed(6):null,hashOfOutput:sha([...this.record].sort((a,b)=>a[0]-b[0])),ledgerHead:this.ledger.items.at(-1).hash};}
}
module.exports={Colony,quantile};
