'use strict';
// No changes to original kernel; optional v0.3 controller is also imported unchanged.
const fs=require('node:fs'), path=require('node:path');
const {RippleNeuron}=require('./ripple_core_reference');
const {ControlledNeuron}=require('../baseline/feedback_sweep');
const ROOT=path.resolve(__dirname,'..');
const W=[2,1.2,-1.4];
const DR=x=>x.reduce((s,v,i)=>s+v*W[i],0);
function simulate(method,controller='original'){
 const frames=JSON.parse(fs.readFileSync(path.join(ROOT,'data/neuron_sequence.json')));
 const n=controller==='original'?new RippleNeuron():new ControlledNeuron(controller,1);
 let counts=0,windows=[],w=0,skipped=0,errors=[],truthDrive=[],actualDrive=[];
 for(let i=0;i<frames.length;i++){
  const row=frames[i],invalid=method==='fused'&&row.fused_method==='invalid';
  const input=invalid?[0,0,0]:row[method];
  // Lost sensor evidence is not synthetic 'darkness': during dropouts we leak membrane
  // under zero input and temporarily disable feedback adjustment (fail-safe abstention).
  let wasAdaptive;
  if(invalid){skipped++;wasAdaptive=controller==='original'?n.adaptive:n.n.adaptive;
    if(controller==='original')n.adaptive=false;else n.n.adaptive=false;
  }
  const out=n.step(input,.05);counts+=out.count;w+=out.count;
  if(invalid){if(controller==='original')n.adaptive=wasAdaptive;else n.n.adaptive=wasAdaptive;}
  if((i+1)%40===0){windows.push(w);w=0;}
  const trueD=DR(row.truth),estimatedD=DR(input);
  errors.push(Math.abs(trueD-estimatedD));truthDrive.push(trueD);actualDrive.push(estimatedD);
 }
 return {method,controller,events:counts,missingFrames:skipped,
  meanDriveError:errors.reduce((a,b)=>a+b,0)/errors.length,
  windows, finalTheta: controller==='original'?n.theta:n.n.theta, finalRate:controller==='original'?n.rate:n.n.rate};
}
function main(){
 const results=[];
 for(const controller of ['original','hybrid-fast'])for(const decoder of ['truth','raw','calibrated_dc','lockin','fused'])results.push(simulate(decoder,controller));
 for(const controller of ['original','hybrid-fast']){
  const ideal=results.find(x=>x.method==='truth'&&x.controller===controller);
  for(const r of results.filter(x=>x.controller===controller)){
   r.windowCountMAE=r.windows.reduce((s,v,i)=>s+Math.abs(v-ideal.windows[i]),0)/r.windows.length;
   r.eventCountError=Math.abs(r.events-ideal.events);
  }
 }
 fs.writeFileSync(path.join(ROOT,'data/neuron_integration.json'),JSON.stringify(results,null,2));
 console.log(JSON.stringify(results,null,2));
}
if(require.main===module)main();module.exports={simulate,DR};
