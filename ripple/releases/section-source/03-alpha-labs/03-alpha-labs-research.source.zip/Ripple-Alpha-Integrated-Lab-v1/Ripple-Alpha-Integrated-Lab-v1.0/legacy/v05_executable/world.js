'use strict';
const {seeded,sha}=require('./genome');
function assertDim(dim){if(![2,3].includes(dim))throw Error('dimension must be 2 or 3');}
function makeWorld(dim=2,seed=1){assertDim(dim);const size=dim===2?[10,10,1]:[7,7,3];const rng=seeded((seed*2654435761)>>>0);const cells=[];
 for(let z=0;z<size[2];z++)for(let y=0;y<size[1];y++)for(let x=0;x<size[0];x++){
  const blocked=rng()<.14+(dim===3&&z===2?.06:0);
  const resource=Math.floor(rng()*7)*(blocked?0:1);
  const spectral=[.12+.65*rng(),.09+.76*rng(),.08+.71*rng()];
  cells.push({id:cells.length,x,y,z,blocked,resource,spectral});
 }
 return {schema:'ripple-world/1',dim,size,seed,cells,worldHash:sha(cells)};}
function observation(cell,seed,attempt=0){ // virtual sensor: deterministic and repeatable, NOT measured light
 const rng=seeded(((seed*1315423911)^(cell.id*2654435761)^((attempt+1)*2246822519))>>>0);
 const noise=()=> (rng()-.5)*.06;
 const raw=cell.spectral.map(x=>Math.max(0,x+noise()));
 const clipped=attempt===0 && cell.id%17===0;
 if(clipped)raw[0]=1; // injected saturation: do not trust the reading
 const gain=attempt===0?1:.6;
 const channels=raw.map(x=>Math.round(Math.min(1,x*gain)*10000)/10000);
 const corrected=channels.map(x=>Math.min(1,x/gain));
 const blockedEstimate=cell.blocked; // sim API provides ground-truth occupancy, explicitly NOT inferred from optics
 return {cell:cell.id,position:[cell.x,cell.y,cell.z],channels,corrected,clipped:clipped&&attempt===0,occupancy:blockedEstimate,
 resource:cell.resource,drive:+(2*corrected[0]+1.2*corrected[1]-1.4*corrected[2]).toFixed(5),attempt};}
function arrivals(world,profile){const c=world.cells,n=c.length;return c.map((cell,i)=>{
  let t=0;
  if(profile==='burst')t=(i%5)*.2+(Math.floor(i/5)%2)*28;
  if(profile==='shift')t=i%3===0?3:i%3===1?27:58;
  if(profile==='stream')t=i*.57;
  return {id:i,type:['learning','product','study'][i%3],cell:cell.id,arrival:t,attempt:0};
 });}
function objMesh(world, observed=null){const cells=observed?world.cells.filter(c=>observed.has(c.id)):world.cells;
 const vertices=[],faces=[];const vv=[[0,0,0],[1,0,0],[1,1,0],[0,1,0],[0,0,1],[1,0,1],[1,1,1],[0,1,1]];
 for(const cell of cells){if(!cell.blocked)continue;const start=vertices.length;for(const a of vv)vertices.push(`v ${cell.x+a[0]} ${cell.y+a[1]} ${cell.z+a[2]}`);const tris=[[1,2,3],[1,3,4],[5,6,7],[5,7,8],[1,2,6],[1,6,5],[2,3,7],[2,7,6],[3,4,8],[3,8,7],[4,1,5],[4,5,8]];for(const a of tris)faces.push('f '+a.map(i=>start+i).join(' '));}
 return '# Ripple synthetic voxel obstacle mesh; OBJ triangulated cubes\n'+vertices.join('\n')+'\n'+faces.join('\n')+'\n';}
module.exports={makeWorld,observation,arrivals,objMesh};
