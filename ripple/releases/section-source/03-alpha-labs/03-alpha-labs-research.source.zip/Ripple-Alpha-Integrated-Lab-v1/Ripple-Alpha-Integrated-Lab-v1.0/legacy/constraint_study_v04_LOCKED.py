"""Finite optical symbol hypotheses with contradiction rejection. Analogy only to historical search mechanisms.
No Bombe/Colossus software or ciphertext processing is implemented.
"""
import itertools,json,pathlib
import numpy as np
from scipy.stats import chi2
from optical_study import A
ROOT=pathlib.Path(__file__).resolve().parents[1]
LEVELS=np.array([0.,.3,.6,.9])
CANDIDATES=np.array(list(itertools.product(LEVELS,repeat=3)))
PRED=CANDIDATES@A.T
CHI2_CUTOFF=float(chi2.ppf(.99,df=4))

def infer(y,sigma,reference=np.zeros(4)):
    if not np.all(np.isfinite(y)) or not (sigma>0):raise ValueError('invalid sensor vector')
    errors=np.sum(((PRED-(y-reference))/sigma)**2,axis=1)
    order=np.argsort(errors)
    if errors[order[0]]>CHI2_CUTOFF:
        return {'status':'reject','score':float(errors[order[0]]),'candidate':None,'survivors':0}
    valid=(errors<=CHI2_CUTOFF).sum()
    return {'status':'accept' if valid==1 else 'ambiguous',
            'score':float(errors[order[0]]),'candidate':int(order[0]),'survivors':int(valid)}

def run():
    rng=np.random.default_rng(1944)
    rows=[]
    for regime in ['low_noise','high_noise','uncalibrated_drift','clipped']:
        for k in range(160):
            truth_idx=int(rng.integers(len(CANDIDATES)))
            truth=CANDIDATES[truth_idx]
            sigma=.025 if regime!='high_noise' else .12
            y=A@truth+rng.normal(0,sigma,4)
            if regime=='uncalibrated_drift': y+=.16 # unmodeled background contaminates measurement
            if regime=='clipped': y=np.minimum(y,.65)
            inferred=infer(y,sigma)
            raw=np.array([LEVELS[np.argmin(abs(LEVELS-z))] for z in np.clip(y[:3],0,1)])
            rows.append({'regime':regime,'correct_truth_index':truth_idx,
                         'status':inferred['status'],'candidate':inferred['candidate'],
                         'correct_accepted':inferred['status']=='accept' and inferred['candidate']==truth_idx,
                         'any_correct':inferred['candidate']==truth_idx if inferred['candidate'] is not None else False,
                         'naive_correct':bool(np.all(raw==truth)),
                         'survivors':inferred['survivors']})
    report={}
    for group in sorted({r['regime'] for r in rows}):
        subset=[r for r in rows if r['regime']==group]
        accepted=[r for r in subset if r['status']=='accept']
        report[group]={'total':len(subset),'unique_acceptance_rate':len(accepted)/len(subset),
                       'accuracy_on_unique_accepted':sum(r['correct_accepted'] for r in accepted)/len(accepted) if accepted else None,
                       'all_correct_unique_fraction':sum(r['correct_accepted'] for r in subset)/len(subset),
                       'naive_unconditional_accuracy':sum(r['naive_correct'] for r in subset)/len(subset),
                       'rejected':sum(r['status']=='reject' for r in subset),'ambiguous':sum(r['status']=='ambiguous' for r in subset)}
    (ROOT/'data/constraint_results.json').write_text(json.dumps({'threshold':CHI2_CUTOFF,'summary':report,'rows':rows},indent=2))
    print(json.dumps(report,indent=2))
if __name__=='__main__':run()
