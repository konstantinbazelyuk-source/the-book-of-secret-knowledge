'use strict';
const fs=require('node:fs'),path=require('node:path');const {run,variants,sha}=require('./alpha_engine');const {study}=require('./genetic_study');
const dest=path.resolve(__dirname,'../data');fs.mkdirSync(dest,{recursive:true});
const rows=[],seeds=[11,17,23,29,37,43,53,61,71,83],dims=[2,3];
const overview={schema:'ripple-alpha-sweep/1',seeds,dims,variants:Object.keys(variants),steps:160,densityFrom:80,runs:0};
for(const seed of seeds)for(const dim of dims)for(const variant of Object.keys(variants)){
 const o=run({seed,dim,variant,steps:160,densityFrom:80,trackEvery:8});rows.push({seed,dim,variant,...o.summary,worldHash:o.worldHash,resultHash:o.resultHash});
 if(seed===11)fs.writeFileSync(path.join(dest,`replay_${dim}d_${variant}.json`),JSON.stringify(o));}
const genetic=[];for(const seed of [43,47,59])for(const environment of ['neutral','red','green','blue','gray'])genetic.push(study({seed,environment}));
const aggregates=Object.keys(variants).map(variant=>{const r=rows.filter(x=>x.variant===variant);const mean=k=>r.reduce((a,b)=>a+b[k],0)/r.length;return {variant,runs:r.length,coverage:mean('coverage'),workerSeconds:mean('workerSeconds'),duplicate:mean('duplicate'),created:mean('created'),monochromeCount:mean('monochromeCount'),objective:mean('objective')};}).sort((a,b)=>b.objective-a.objective);
fs.writeFileSync(path.join(dest,'all_trials.json'),JSON.stringify({overview,rows},null,2));fs.writeFileSync(path.join(dest,'aggregate.json'),JSON.stringify(aggregates,null,2));
fs.writeFileSync(path.join(dest,'genetics.json'),JSON.stringify(genetic,null,2));
fs.writeFileSync(path.join(dest,'experiment_manifest.json'),JSON.stringify({...overview,runs:rows.length,geneticStudies:genetic.length,provenanceHash:sha(rows),artificialFitness:true},null,2));
console.log(JSON.stringify({runs:rows.length,geneticStudies:genetic.length,top:aggregates.slice(0,5),monoEmergences:genetic.filter(g=>g.first.monochromatic!==null).length,grayEmergences:genetic.filter(g=>g.first.achromatic!==null).length},null,2));
