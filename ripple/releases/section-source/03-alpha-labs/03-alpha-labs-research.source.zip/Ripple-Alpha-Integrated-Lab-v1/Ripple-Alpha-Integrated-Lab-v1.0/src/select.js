'use strict';
const fs=require('node:fs'),path=require('node:path');const {sha}=require('./alpha_engine');
const dir=path.resolve(__dirname,'../data');const records=JSON.parse(fs.readFileSync(path.join(dir,'all_trials.json'))).rows;
const training=new Set([11,17,23,29,37,43]),holdout=new Set([53,61,71,83]);
const variants=[...new Set(records.map(x=>x.variant))];
const score=(variant,seeds)=>{const r=records.filter(x=>x.variant===variant&&seeds.has(x.seed));return {variant,runs:r.length,score:r.reduce((a,b)=>a+b.objective,0)/r.length,coverage:r.reduce((a,b)=>a+b.coverage,0)/r.length,workerSeconds:r.reduce((a,b)=>a+b.workerSeconds,0)/r.length};};
const ranks=variants.map(v=>score(v,training)).sort((a,b)=>b.score-a.score);const chosen=ranks[0].variant;const holdouts=variants.map(v=>score(v,holdout)).sort((a,b)=>b.score-a.score);
const chosenHoldout=holdouts.find(x=>x.variant===chosen),adaptHoldout=holdouts.find(x=>x.variant==='adaptive');
const result={schema:'ripple-alpha-model-selection/1',rule:'Pick maximum mean training objective among the nine fixed policies; evaluate once on 4 reserved seeds, each in both dimensions. No retraining after inspection.',trainingSeeds:[...training],holdoutSeeds:[...holdout],trainingRankings:ranks,holdoutRankings:holdouts,selected:chosen,selectedHoldout:chosenHoldout,adaptiveHoldout:adaptHoldout,pairedDifference:chosenHoldout.score-adaptHoldout.score,
 scope:'Synthetic deterministic seeds; no statistical generalization or physical speed advantage proven'};
result.sha256=sha(result);fs.writeFileSync(path.join(dir,'selection_holdout.json'),JSON.stringify(result,null,2));console.log(JSON.stringify({selected:chosen,holdout:chosenHoldout,baseline:adaptHoldout,pairedDifference:result.pairedDifference},null,2));
