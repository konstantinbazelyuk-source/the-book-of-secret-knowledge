from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
r=Path(__file__).resolve().parents[1]
a=json.loads((r/'data/aggregate.json').read_text())
fig,ax=plt.subplots(figsize=(10,5),layout='constrained')
ax.barh([x['variant'] for x in a[::-1]],[x['objective'] for x in a[::-1]])
ax.set_xlabel('Simulated objective (higher is better)')
ax.set_title('Ripple Alpha v1.0 — all 180 numerical map trials')
fig.savefig(r/'charts/variant_comparison.png',dpi=145)
plt.close(fig)
g=json.loads((r/'data/genetics.json').read_text())
fig,ax=plt.subplots(figsize=(10,5),layout='constrained')
for env in ['red','green','blue','gray']:
 s=next(x for x in g if x['environment']==env and x['seed']==43)
 ax.plot([h['generation'] for h in s['history']],[h['bestScore'] for h in s['history']],label=env)
ax.set(title='Artificial selection: best fitness, seed 43 (not biological intelligence)',xlabel='Generation',ylabel='Defined artificial fitness')
ax.legend()
fig.savefig(r/'charts/genetic_selection.png',dpi=145)
plt.close(fig)
print('generated two charts')
