'use strict';
/** Pure digital parameter selection study. Scores encode a stated artificial environment. */
const {genome,verifyGenome,mutate,starter,rnd,mono,sha}=require('./alpha_engine');
const channels=['red','green','blue','gray','neutral'];
function phenotype(g){const weights=g.color;const max=Math.max(...weights),min=Math.min(...weights);
 return {monochromatic:max>=.92,achromatic:max-min<=.025,dominant:['red','green','blue'][weights.indexOf(max)],purity:max,chroma:max-min};}
function fitness(g,environment){if(environment==='neutral')return .75-.4*Math.abs(g.color[0]-g.color[1]);
 if(environment==='gray')return 1-(Math.max(...g.color)-Math.min(...g.color));
 const i=['red','green','blue'].indexOf(environment);return g.color[i];}
function study({seed=43,generations=48,population=22,environment='red',elite=3}={}){
 if(!channels.includes(environment)||!Number.isInteger(population)||population<4||population>200||!Number.isInteger(generations)||generations<1||generations>500||!Number.isInteger(elite)||elite<1||elite>=population)throw Error('bad study');
 const rng=rnd(seed);let pool=[];const all=[],history=[],first={monochromatic:null,achromatic:null};
 for(let i=0;i<population;i++){const s=starter(['explorer','processor','observer','archivist'][i%4]);
  // Introduce bounded naturally varying initial colors. No starting genome meets fixation/gray threshold.
  const g=mutate(s,rng);const rec=genome(g);pool.push({rec,origin:'founder',generation:0});all.push(rec);}
 for(let gen=0;gen<=generations;gen++){
  const ordered=pool.map(p=>({...p,score:fitness(p.rec.genes,environment),phenotype:phenotype(p.rec.genes)})).sort((a,b)=>b.score-a.score||a.rec.marker.localeCompare(b.rec.marker));
  for(const p of ordered){for(const trait of ['monochromatic','achromatic'])if(p.phenotype[trait]&&first[trait]===null)first[trait]={generation:gen,marker:p.rec.marker,color:p.rec.genes.color};}
  const best=ordered[0],mean=ordered.reduce((s,p)=>s+p.score,0)/population;history.push({generation:gen,bestScore:best.score,meanScore:mean,bestMarker:best.rec.marker,bestColor:best.rec.genes.color,
   monochromaticCount:ordered.filter(p=>p.phenotype.monochromatic).length,achromaticCount:ordered.filter(p=>p.phenotype.achromatic).length});
  if(gen===generations)break;
  const newPool=ordered.slice(0,elite).map(p=>({rec:p.rec,origin:'retained',generation:gen+1}));
  while(newPool.length<population){const candidates=Array.from({length:3},()=>ordered[Math.floor(rng()*population)]).sort((a,b)=>b.score-a.score);const parent=candidates[0];
    let g=mutate(parent.rec.genes,rng);const rec=genome(g,parent.rec.marker);verifyGenome(rec);newPool.push({rec,origin:'mutation',generation:gen+1});all.push(rec);}
  pool=newPool;
 }
 const results={schema:'ripple-alpha-genetic-study/1',seed,environment,generations,population,elite,history,first,totalGenomes:all.length,
  finalBest:history.at(-1),interpretation:'Artificial fitness landscapes and software-parameter inheritance, not novel biology or spontaneous cognition.'};
 results.resultHash=sha({seed,environment,generations,population,history,first});return results;
}
module.exports={study,phenotype,fitness};
