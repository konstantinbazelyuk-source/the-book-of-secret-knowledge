# Ripple Integrated Alpha Lab v1.0

**Status: runnable ALPHA research software, not a hardware system or general artificial intelligence.** Original Ripple kernel and recovered historical modules are preserved as locked archival snapshots; the new combined architecture is experimental and independently versioned. Concept: Constantin x; engineering and reproducibility implementation assisted by AI. New original code offered CC0-1.0; preserved code retains its original licensing and provenance.

## Start now

1. Open `Ripple-Alpha-Integrated-Lab-v1.0.html` in a modern browser. It is a self-contained, offline **experiment replay and analysis console** displaying recorded, genuinely executed deterministic numerical runs. No web login, remote agent or hardware is involved.
2. With Node.js 22+, run `node --test tests/*.test.*` from the package root. Run `node src/run_trials.js` to recompute every numerical variant and genetic study, then `node src/select.js` for the predeclared training/holdout comparison. Rebuild the HTML with `python src/build_lab.py` (Python standard library only).
3. Optional desktop/mobile Chromium check: `python tests/browser_smoke.py` (requires Playwright and Chromium). It injects the self-contained HTML into `about:blank` because this host administratively blocks `file://` navigation; that is a limitation of the test route, not a normal web deployment.

No npm install or API keys are required for the simulation. `src/alpha_engine.js` and `src/genetic_study.js` provide importable JavaScript functions. `data/replay_*` holds exact time-series, positions and lineages; `data/all_trials.json` contains the complete sweep. Browser replay uses deterministic **stored computations**; it does not silently regenerate new trials when selectors change.

## Source continuity

- **Unmodified active neuron kernel:** `legacy/ripple_mycelium_v05_LOCKED.js`, SHA-256 `d75d4208e92f19623b127615bd52b4002e85d2c0a59b76471764b55a24294210`.
- **Recovered and tested adapters:** separate v0.6 photoreceptor mathematics, quaternary v0.7 encoding/VM, and preserved v0.1–v0.5 source units. A second v0.6 neuron source has a different checksum because its packaged file contains a full experiment and global export; it is not treated as byte-identical to the v0.5 module.
- **Archived, not deployed:** SpiderScan and Kokoro neuron, prior multithreading, spectral statistics, specialist colony, optical research. All archived files are untouched, and their integration status is listed in `docs/SOURCE_CATALOG.md`.
- **Not connected or executed:** real cameras, real robot legs, real 3D engines, Google accounts, crypto networks, external AI model weights, offline sensor hardware, online distributed compute. No external user project was overwritten.

## Alpha algorithms and mathematical meanings

1. **Co-located digital species:** Each worker has a normalized three-channel RGB gain gene, task role, mobility, diffusion affinity, occlusion affinity, and density sensitivity. These modify simulated input and movement, not the preserved leaky integrate-and-fire differential equation. Clones keep their own membrane state. Every genome has SHA-256 over canonical serialized genes and parent marker, with ancestry trace.
2. **Spatial nutrient flow:** A conservative finite-volume neighbor flux exchanges simulated resource across open voxels. Obstacles are impermeable. All sources, sinks, and consumed resource are separately tracked. At each diffusion-only step mass conservation is checked numerically. It is a digital diffusion process, not a fungal metabolism measurement.
3. **Occlusion and attenuation:** Hard obstacle blocks a synthetic ray; otherwise intensity follows an idealized exponential attenuation through a digital material field. Strict occlusion often starves the neuron. Ambient fallback restores some virtual input, but does not establish physically calibrated irradiance.
4. **Two explicit experimental phases:** Phase A records trajectories/lineage without density **control** and uses a homogeneous surrogate absorption medium. Phase B activates the predefined spatial density map for density-aware routing and synthetic ray extinction. It is a controlled simulation change, not a physical density observation.
5. **Bounded replication and retirement:** A rooted colony grows based on the count of unmapped voxels, only through capped internally simulated clones. No network or OS threads are spawned by the numerical runner. Hard capacity: up to 14 workers in the sweep (24 allowed at the API validator). Worker lineage is maintained after retirement.
6. **Evolution laboratory:** A separate, explicit artificial selection experiment compares 5 scoring environments × 3 seeded repeats, each with population 22 and 48 generations. The best selected candidate survives, while other candidates mutate with bounded continuous parameter edits. This is a finite heuristic genetic search, not automatically self-improving intelligence.

## Result classification

- **Calculated:** exact module hashes; finite-difference flux equations; objective values computed from completed simulation records.
- **Simulated:** coverage, pulse counts, population, world map, 2D/3D paths, channel fixation, noise-free optical attenuation, genome selection.
- **Measured (software execution evidence):** automated source/unit/integration tests, execution wall time only if logged, Chromium desktop/mobile UI operation. No calibrated optical or hardware performance measurement exists.
- **Proposed/not demonstrated:** external platform integrations, real physical density, live mapping intelligence, autonomous scientific research, trained machine perception.

## Reproducing and interpretation

Full results: `data/all_trials.json`, `data/aggregate.json`, `data/genetics.json`, `data/experiment_manifest.json`. Architecture objective is the **arbitrarily defined** `1000*coverage - 1.1*workerSeconds - 0.04*duplicates - 1.4*births`; it penalizes reserved work occupancy, not measured electricity or execution wall time. The same synthetic world seed and dimensionality are used across architectures. Results should not be extrapolated to other task distributions without re-evaluation.

The present tests show **no universal winner**. The corrected sweep favors diffusion over ordinary adaptive scaling by a small objective margin. Strict-occlusion and all-mechanism-at-once policies frequently underperform because optical attenuation suppresses firing. Keep both failed variants for regression rather than presenting complexity as intelligence.

## Scope, safety and no false intelligence

The lab is bounded, deterministic, isolated, and local. It does not use external APIs or autonomous code execution, contact people, log into services, alter game worlds, perform cryptomining, change LLM weights, or claim sentience. Gene labels are typed numbers; SHA-256 is integrity checking and does not provide authentication without a trusted checksum, key/signature or external trusted record. Genetic algorithms can select overfitted mathematical scoring functions. Negative results are mandatory and archived.

See `docs/MATHEMATICS_AND_GUARDRAILS.md`, `docs/SOURCE_CATALOG.md`, `docs/VARIANT_LEDGER.md` and `docs/RESEARCH_SOURCES.md`.

## Selection guardrail, actual result

Run `node src/select.js` to repeat the held-out comparison. Six world seeds select the highest mean objective (`adaptive`, 563.17). On the four reserved seeds, `diffusion` obtained 592.46 whereas `adaptive` obtained 541.55. This is **not** permission to choose `diffusion` retroactively and call the result validated; it is evidence that architecture rankings vary by test distribution. The conservative default for follow-on Alpha work is the training-selected adaptive worker while both policies remain in independent evaluation.

## Additional outputs

- `data/version_registry.json`: archived source recognition with integration status.
- `data/selection_holdout.json`: training-selected versus reserved-seed results.
- `charts/alpha_lab_desktop.png`, `charts/alpha_lab_mobile.png`: actual Chromium screenshots of the offline lab running through its `about:blank` injection test route.
- `charts/variant_comparison.png`, `charts/genetic_selection.png`: numerical graphs (synthetic simulations).
- `legacy/v05_executable/`: unchanged, runnable v0.5 source bundle with its own test.
