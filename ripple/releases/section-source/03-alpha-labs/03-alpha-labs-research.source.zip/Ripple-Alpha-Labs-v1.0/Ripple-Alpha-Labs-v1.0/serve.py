from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import os
os.chdir(Path(__file__).resolve().parent)
print('Ripple Alpha Labs at http://localhost:8769 — no external telemetry')
ThreadingHTTPServer(('127.0.0.1',8769),SimpleHTTPRequestHandler).serve_forever()
