# Ripple FieldSphere v0.1: fabrication, wiring, field validation

## Precise engineering scope
This is an **8-location magnetic vector measurement rig**, using **eight LIS2MDL MEMS magnetometers** at corners of a cube inscribed in a sphere (R = sqrt(3) * 90 = 155.8846 mm) with **12 curved rails** that bulge outward toward a spherical outline. It is not an arbitrary-resolution 3-D magnetic field tomograph. Optional four diametric LED/OPT101 optical links record transmitted optical intensity only. Ordinary optical beams do **not** measure magnetic field in air. The first build intentionally has **no lasers**.

## CAD manufacture
- `cad/fieldsphere.scad`: parameterized, editable engineering design.
- Print 8 hub STLs: `hub_{ppp,ppm,pmp,pmm,mpp,mpm,mmp,mmm}.stl`, **one each**. Signs are signs of the assembled vertex x,y,z, not alternate performance grades.
- Print each `rail_{pp,pm,mp,mm}.stl` **three times** (12 curved rails). These represent curve direction signs in the *local* rail coordinate frame. Rails print with their long dimension on the build plate, preferably with supports/tune overhang as your slicer shows. Check the local assembly rendering for orientation.
- Eight `sensor_test_caddy.stl` are optional PCB platforms: ensure hole spacing matches YOUR board before printing. Nylon tape/zip ties acceptable for early alignment.
- Print 4 LED sleeves, 4 receiver sleeves **only if adding optics**. Sleeves require fit validation; do not force an oversized printed part through a hub.
- Print 1 coil bobbin for calibration. Coil radius must be **measured** after winding; 25mm is a nominal design parameter and the body is approximately 50mm in diameter.
- `strut.stl` is a straight, cubical-frame alternative only, not the intended curved sphere.
- Print parameters to start: 0.20mm layers, 4 perimeters, 30-40% infill for joints, 10% or more for rails. Printer calibration and hole shrinkage vary; print ONE hub and ONE rail first. The nominal rail side is 11.8mm and socket width 12.35mm, for 0.55mm total clearance. Check real fit and adjust the parametric design.
- Each side spans 180mm center-to-center. Outer assembly dimension is approximately 220-230mm; the diameter through opposed nodes is about 312mm (not the same as the bounding-box width).
- Use **nylon/plastic fasteners**, non-ferrous adhesives, nonmagnetic support surfaces. Some stainless steels are magnetic; test fasteners with a magnet. Keep steel desks, large ferromagnetic parts, and powered cables away.

## Assembly orientations (CRITICAL)
Vertex coordinates (mm), ordered identically to firmware/analysis records:

| Mux channel | x | y | z | Hub STL | Optical role |
|---:|---:|---:|---:|---|---|
| 0 | -90 | -90 | -90 | hub_mmm | Detector (paired with node 7) |
| 1 | -90 | -90 | +90 | hub_mmp | Detector (paired with node 6) |
| 2 | -90 | +90 | -90 | hub_mpm | Detector (paired with node 5) |
| 3 | -90 | +90 | +90 | hub_mpp | Detector (paired with node 4) |
| 4 | +90 | -90 | -90 | hub_pmm | Emitter toward node 3 |
| 5 | +90 | -90 | +90 | hub_pmp | Emitter toward node 2 |
| 6 | +90 | +90 | -90 | hub_ppm | Emitter toward node 1 |
| 7 | +90 | +90 | +90 | hub_ppp | Emitter toward node 0 |

Optical channels are 0: source node 4 -> detector node 3; 1: node 5 -> node 2; 2: node 6 -> node 1; 3: node 7 -> node 0. This ordering matches GPIO10..13 and ADS A0..A3. Optical rays from corner to opposite corner cross the center and **an inserted calibration coil may block them**; optical tests are separate from magnetic coil tests.

The CAD places optical radial apertures at the node centers. The **physical magnetic sensing die must not be presumed located at the nominal vertex coordinate** simply because the plastic hub is. Record its actual center and three board axes. A sensor board placed at a different orientation cannot be plotted as a global XYZ arrow until its 3x3 rotation is measured. Bare magnitude readings remain interpretable without orientation but can have local biases.

## Electrical connection

```
PICO GP4 (I2C0 SDA) -> PCA9548A  SDA
PICO GP5 (I2C0 SCL) -> PCA9548A  SCL
PICO 3V3             -> MUX VIN and ADS1115 VDD
PICO GND             -> COMMON GND for mux / ADC / OPT101
MUX channel 0        -> LIS2MDL vertex 0: -90,-90,-90
MUX channel 1        -> LIS2MDL vertex 1: -90,-90,+90
MUX channel 2        -> LIS2MDL vertex 2: -90,+90,-90
MUX channel 3        -> LIS2MDL vertex 3: -90,+90,+90
MUX channel 4        -> LIS2MDL vertex 4: +90,-90,-90
MUX channel 5        -> LIS2MDL vertex 5: +90,-90,+90
MUX channel 6        -> LIS2MDL vertex 6: +90,+90,-90
MUX channel 7        -> LIS2MDL vertex 7: +90,+90,+90
ADS1115 SDA/SCL      -> upstream Pico SDA/SCL (NOT to mux channel)
ADS1115 ADDR         -> GND: I2C address 0x48
ADS1115 A0..A3       -> OPTIONAL OPT101 outputs 0..3 (max <=3.3V)
PICO GP10..GP13      -> OPTIONAL each one LED through series resistor to GND
```

Boards may have on-board level shifters/regulators: wire **actual breakout `VIN`, not bare IC pins**. 3.3V is mandatory on RP2040 GPIOs. **Use a resistor with EACH LED**, typical 470Ω to start, and keep total LED current within official RP2040 GPIO limits. OPT101 pinout and circuit must be taken from TI datasheet and the actual breakout schematic; the four analog lines are input signals, not direct bare photodiode connections. Beware photodiode amplifier saturation; lower optical illumination, shield stray light, or increase optical attenuation if voltages pin near a rail. Optics are DC intensity gates, **not heterodyne**.

### Buildable OPT101 optical-receiver reference circuit (OPTIONAL, 4 copies)
Per **TI OPT101 PDIP/SOP top-view pinout** (read TI datasheet before soldering): pin 1 `VS` → +3.3V; pin 3 `-V` → ground; pin 8 `COMMON` → ground; pin 4 `1MΩ feedback` → pin 5 `OUTPUT`; pin 5 → ADS1115 A0/A1/A2/A3 through a 1kΩ series protection resistor. Pin 2 (`-IN`) and pins 6/7 (NC) left disconnected. Place a 0.1µF ceramic decoupling capacitor between 1 and 3 at the chip. Use one IC per perfboard with its photodiode face aligned behind the receiver sleeve's 3.2mm aperture. The 8-pin pinout and basic feedback configuration come from [TI datasheet Figure 21](https://www.ti.com/lit/ds/symlink/opt101.pdf). These are **proposed engineering connections, not bench-tested circuitry**. ADC sees 0–3.3 V; if output approaches supply rails, decrease incident optical intensity. A 470Ω LED resistor gives nominal (3.3−2.0)/470 ≈ 2.8mA when the LED is on, subject to real forward-voltage variation. Use LED drivers if controller sourcing limits are exceeded; the code enables just one emitter at a time.

No coil power from a Pico GPIO. The coil is powered by a separate DC supply with a current limit and independent polarity reversal. Never short the supply or energize the coil unattended. Start at low current and check coil winding temperature.

## Field test: COIL REVERSAL, not an aura claim
1. Disconnect optional LEDs. Place rig on a nonmagnetic surface, away from phones, magnets and strong mains-powered devices. Keep the test electronics at a fixed distance.
2. Record which breakout axis aligns with the laboratory +X,+Y,+Z axes for every node. Measure the **actual sensor DIE** position, not merely the hub center. Fix orientation and bias against a calibrated reference if absolute fidelity is required. The provided orientation template is **not** calibration.
3. Wind nominal 100 turns on the coil bobbin, measure its effective radius, note the coil axis and set **the coil normal along +X**. Its **nominal radius in software is 25mm**; alter software if the actual radius differs. Place the center at the sphere center (0,0,0).
4. Run baseline at I=0A for 10s, then +0.2A (positive defined by right-hand coil normal +X) for 10s, then -0.2A for 10s. Control polarity and measure current with an ammeter. Obtain 50+ frames in each condition where feasible. Do not move the coil or magnetometers between captures.
5. Compute half-difference: `B_coil = (mean(B at +I) - mean(B at -I)) / 2`, cancels stable field offsets. Confirm approximately odd-in-current response and measured magnitude above noise; test repeatability after remount.
6. For **calibrated board axes** and actual probe coordinates, compare against numerical Biot-Savart model; **the package nominal model assumes ideal locations and perfect 100-turn circular coil at 25mm radius**. Simulated ideal magnitude at each nominal site is about **1.48 µT** at 0.2 A. That is a calculation, not a measured sensitivity specification.
7. Controls: (a) coil power disconnected, (b) reversed current, (c) coil displaced and repeat, (d) optical LED on/off cross-talk test. Unexpected fields may be metal, circuit currents, thermal drift, board offsets, orientation errors or ambient disturbances, not new phenomena.
8. **Acceptance for a documented prototype:** 8 LIS2MDL boards enumerate; baseline drift and noise are logged; polarity reversal changes sign; measurement reproducibility and alignment error are reported; optical channels produce reproducible on/off difference if installed. No invented accuracy threshold: quantify repeatability empirically.

## Acquisition
1. Install MicroPython on Pi Pico; copy `firmware/main.py` to Pico via Thonny or mpremote. The eight magnetometers MUST be present by default; firmware refuses silent missing channels. Optional ADS absent => `optical_delta_V=null`.
2. The Pico emits JSON lines over USB CDC. On your computer: `python -m pip install pyserial numpy matplotlib`.
3. Example baseline: `python host/capture_serial.py --port /dev/ttyACM0 --state zero --seconds 10 --output logs/rig.jsonl` (Windows port might be COM3).
4. Repeat plus and minus with correct measured coil current. The operator manually tags coil state; firmware does not know current direction.
5. `python host/fieldsphere.py analyze --input logs/rig.jsonl --output docs/live_readout.png` plots magnitude and site positions. **Global vector arrows and comparison with theoretical coil direction are withheld for physical data until `--orientation-json <calibrated-file.json>` is supplied**. Scale and hard-iron correction remain user responsibilities.
6. For bench simulation only: `python host/fieldsphere.py simulate --output data/synthetic_coil_run.jsonl` then analyze. This data is always labelled SIMULATED.

## Magnetic field vs optics vs radiation
Magnetic channel: LIS2MDL measures quasi-static / low-rate *magnetic flux density B* [µT]. An 8-sensor sequential sampler does **not** measure the magnetic part of a 460 THz laser carrier and cannot resolve high-frequency EM fields or RF radiation. Optical channel: ordinary visible LED ray transmission *relative voltage*, sensitive to obstruction or variations of light, not magnetic field. Gamma-ray and beta-particle radiation require separate appropriate ionizing-radiation detectors. Brain rhythms theta/beta/gamma require EEG/MEG instrumentation, not inferred from beam paths. "Aura" graphics are only stylized maps of measured effects unless validated and scientifically defined.

## Source documents
- ST LIS2MDL datasheet: https://www.st.com/resource/en/datasheet/lis2mdl.pdf
- ST LIS2MDL register library: https://github.com/STMicroelectronics/lis2mdl-pid
- Adafruit LIS2MDL breakout: https://www.adafruit.com/product/4488
- PCA9548A breakout: https://www.adafruit.com/product/5626
- TI TCA9548A specifications: https://www.ti.com/product/TCA9548A
- ADS1115 breakout: https://www.adafruit.com/product/1085
- OPT101 datasheet: https://www.ti.com/product/OPT101
- Pi Pico specifications: https://datasheets.raspberrypi.com/pico/pico-datasheet.pdf
