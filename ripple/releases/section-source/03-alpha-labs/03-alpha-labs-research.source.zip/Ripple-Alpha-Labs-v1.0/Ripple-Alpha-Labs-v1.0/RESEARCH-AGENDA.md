# Evidence-first Alpha research agenda

1. **Conservation and stability**: test FD-1 vs conventional 2D explicit finite-volume 5-point stencil under unchanged CFL. Falsify by nonzero mass-error beyond floating tolerance with no sources/sinks. Check space and time step convergence.
2. **Colored digital lineages**: compare deterministic routing with uniform random walkers under identical seeded illumination. Report per-agent path, speed (grid-cells/model-step), time on target and event count. No intelligent-behavior inference without relevant baselines.
3. **Monochrome**: compare seeded neutral control, goal-directed gray selection, and a no-selection, no-neutral-control condition. Signal mixing alone may not cause a qualifying field event; when it does not, report zero.
4. **Density stage**: compare density-on/off at same initial state using a paired replay, not only four separate full-start experiments. Define density as **occupancy per cell** until externally calibrated physics supports otherwise.
5. **Occlusion**: test both impermeable and partial-edge masks, known simulated ground truth vs predicted RGB field; reserve a fixed unknown scene for holdout testing.
6. **Future models**: only after acceptance, test a true Gray-Scott reaction–diffusion system and explicit reaction stability bounds as a separate optional experiment (not mislabeled optical photon flow). Evaluate concentration invariants appropriate to that reaction chemistry.
7. **Sensors**: acquire measured RGB/AS7341 data with fixed exposure, dark/clear calibration, temperature and timebase, and quantification of noise/clipping. Do not call image contrast or density atomic density.
8. **Colony**: adapt, do not rewrite, Mycelium v0.3/v0.5's own genome and routing benchmarks. Run equivalent CPU-budget baselines before claiming speedups or intelligence.
9. **Release**: strict evidence categories MEASURED / CALCULATED / SIMULATED / PROPOSED in every exported artifact, exact checksum and regression gates, version tags, source citations.
