
(()=>{
/** Ripple Alpha Labs v1.0 — standalone, deterministic, synthetic research engine.
 * Research metadata is NOT a physical measurement or claim of intelligence.
 * Locked v0.1 core and v0.7 symbol codec are imported unchanged.
 */


const RippleNeuron=globalThis.RippleNeuron;

const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const assert=(x,msg)=>{if(!x)throw new Error('Alpha Lab guardrail: '+msg)};
const stable=(o)=>JSON.stringify(o,Object.keys(o).sort());
function hash(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return (h>>>0).toString(16).padStart(8,'0')}
const constants=Object.freeze({width:36,height:24,dt:.16,signalDMax:.42,cflMax:.25,maxSteps:1200,maxSpecies:24,maxPath:300,seed:17413,monochromeChroma:.055,minBrightness:.06,monochromeHold:8});
function rng(seed){let s=seed>>>0;return ()=>((s=Math.imul(1664525,s)+1013904223|0)>>>0)/4294967296}
// Alpha genome is NOT biological or the existing mycelium ripple-genome/1 (SHA-256) schema.
const ALLOWED=new Set(['label','weights','mobility','memory','diffusion','crowding','parent','generation','kind']);
function makeGenome(g){
  assert(g&&typeof g==='object'&&!Array.isArray(g),'genome object required');
  for(const key of Object.keys(g))assert(ALLOWED.has(key),'unknown genome key '+key);
  const norm={schema:'ripple-alpha-gene/1',label:String(g.label||'unnamed').slice(0,48),weights:g.weights?.slice()||[1,1,1],mobility:g.mobility??.65,memory:g.memory??.7,diffusion:g.diffusion??.25,crowding:g.crowding??.4,parent:g.parent??null,generation:g.generation??0,kind:g.kind??'general'};
  assert(norm.weights.length===3&&norm.weights.every(x=>Number.isFinite(x)&&x>=0&&x<=1),'RGB weights must be finite in [0,1]');
  assert(norm.weights.reduce((a,b)=>a+b,0)>.01,'all-zero genome cannot be active');
  for(const key of ['mobility','memory','diffusion','crowding'])assert(Number.isFinite(norm[key])&&norm[key]>=0&&norm[key]<=1,'out of range '+key);
  assert(Number.isInteger(norm.generation)&&norm.generation>=0&&norm.generation<=64,'invalid lineage generation');
  assert(norm.parent===null||typeof norm.parent==='string'&&/^[0-9a-f]{8}$/.test(norm.parent),'invalid parent id');
  assert(['general','routed','mutation'].includes(norm.kind),'unknown gene kind');
  const id=hash(JSON.stringify(norm));
  return Object.freeze({...norm,weights:Object.freeze(norm.weights),id});
}
function mutateGenome(parent,seed,pressure=.4){
  assert(parent?.schema==='ripple-alpha-gene/1','valid parent required');
  const r=rng(seed),w=[...parent.weights],i=Math.floor(r()*3);
  // Unbiased jitter blended toward gray: a finite, named hypothesis; no self-modifying code.
  const mean=w.reduce((a,b)=>a+b,0)/3;
  w[i]=clamp(w[i]*(1-pressure)+mean*pressure+(r()-.5)*.05,0,1);
  return makeGenome({label:parent.label+'*',weights:w,mobility:clamp(parent.mobility+(r()-.5)*.08,0,1),memory:parent.memory,diffusion:parent.diffusion,crowding:parent.crowding,parent:parent.id,generation:parent.generation+1,kind:'mutation'});
}
function genomeGray(g,eps=.08){const w=g.weights,sum=w.reduce((a,b)=>a+b,0);return sum/3>.055&&(Math.max(...w)-Math.min(...w))/(sum+.00001)<=eps}
function searchMonochromeGenome(initial,seed=99,generations=30){
 assert(initial?.schema==='ripple-alpha-gene/1','initial digital genome');
 assert(Number.isInteger(generations)&&generations>=1&&generations<=48,'finite search limit');
 const rand=rng(seed);let parent=initial;
 const chroma=g=>(Math.max(...g.weights)-Math.min(...g.weights))/(g.weights.reduce((a,b)=>a+b,0)+.00001);
 const ledger=[{generation:parent.generation,id:parent.id,parent:parent.parent,chroma:chroma(parent),selected:true}];
 for(let i=0;i<generations&&!genomeGray(parent);i++){
  const choices=Array.from({length:6},()=>mutateGenome(parent,Math.floor(rand()*4294967295),.65));
  choices.sort((a,b)=>chroma(a)-chroma(b));
  const proposed=choices[0],oldChroma=chroma(parent),newChroma=chroma(proposed);
  const accept=newChroma<oldChroma;ledger.push({generation:proposed.generation,id:proposed.id,parent:proposed.parent,chroma:newChroma,selected:accept});
  if(accept)parent=proposed;
 }
 return {source:'FINITE SEEDED DIGITAL SEARCH; goal-directed selection, not spontaneous biology',initial:initial.id,result:parent,monochrome:genomeGray(parent),ledger};
}
const bases=Object.freeze([
 makeGenome({label:'Crimson',weights:[1,.08,.08],mobility:.65,memory:.7,diffusion:.28,kind:'routed'}),
 makeGenome({label:'Emerald',weights:[.08,1,.08],mobility:.67,memory:.65,diffusion:.34,kind:'routed'}),
 makeGenome({label:'Cobalt',weights:[.08,.08,1],mobility:.73,memory:.68,diffusion:.32,kind:'routed'}),
 makeGenome({label:'Amber',weights:[.78,.7,.1],mobility:.66,memory:.67,diffusion:.3,kind:'routed'}),
 makeGenome({label:'Neutral reference',weights:[.62,.62,.62],mobility:.65,memory:.7,diffusion:.3,kind:'general'})
]);
const IDX=(x,y,w)=>y*w+x;
function neighPairs(w,h){const pairs=[];for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=IDX(x,y,w);if(x+1<w)pairs.push([i,i+1]);if(y+1<h)pairs.push([i,i+w]);}return pairs;}
const pairsCache=new Map();
const pairs=(w,h)=>{const k=w+'x'+h;if(!pairsCache.has(k))pairsCache.set(k,neighPairs(w,h));return pairsCache.get(k)};
function diffusionStep(field,w,h,D,dt,occlusion=null,density=null,crowding=0){
  assert(w>=2&&h>=2&&field.length===w*h*3,'grid shape');
  assert(D>=0&&D<=constants.signalDMax&&dt>0&&dt<=.25&&4*D*dt<=constants.cflMax,'explicit diffusion stability guardrail');
  const out=field.slice();
  for(const [i,j] of pairs(w,h)){
    const oi=occlusion?occlusion[i]:0,oj=occlusion?occlusion[j]:0;
    if(oi===1||oj===1)continue;
    const barrier=1-Math.max(oi,oj);
    const dens=density?(density[i]+density[j])/2:0;
    const coef=D*dt*barrier/(1+Math.max(0,crowding)*dens);
    for(let c=0;c<3;c++){
      const a=3*i+c,b=3*j+c,flux=coef*(field[b]-field[a]);out[a]+=flux;out[b]-=flux;
    }
  }
  return out;
}
function fourState(v,delta,deadband=.012){
 assert(Number.isFinite(v)&&Number.isFinite(delta),'nonfinite quaternary signals');
 const code=delta< -deadband?0:v<.12?1:delta>deadband?3:2;
 return {symbol:toSymbol(code),bits:toBits(code),code};
}
function monochrome(pixel,hold=8,threshold=.055,minBrightness=.06){
 const sum=pixel[0]+pixel[1]+pixel[2],bright=sum/3;
 const chroma=(Math.max(...pixel)-Math.min(...pixel))/(sum+.00001);
 return {gray:bright>=minBrightness&&chroma<=threshold,chroma,bright,holdRequired:hold};
}
function color(g){const w=g.weights,max=Math.max(...w,.001);return w.map(x=>Math.round(35+215*x/max))}
class AlphaLab{
 constructor(options={}){
  const w=options.width??constants.width,h=options.height??constants.height,seed=options.seed??constants.seed;
  assert(Number.isInteger(w)&&w>=10&&w<=72&&Number.isInteger(h)&&h>=10&&h<=60,'bounded spatial grid');
  assert(Number.isInteger(seed)&&seed>=0&&seed<=2**32-1,'seed');
  this.w=w;this.h=h;this.n=w*h;this.seed=seed;this.rand=rng(seed);this.tick=0;
  this.config={diffusion:options.diffusion??.32,occlusion:options.occlusion??true,density:options.density??false,reactive:options.reactive??false};
  assert(this.config.diffusion>=0&&this.config.diffusion<=constants.signalDMax,'diffusion bound');
  this.f=new Float64Array(this.n*3);this.prev=new Float64Array(this.n*3);this.mask=new Float64Array(this.n);
  this.density=new Float64Array(this.n);this.pairs=pairs(w,h);this.events=[];this.trajectory=[];this.monochromeHistory=[];
  this.agents=[];this.genomeRegistry=new Map();this.log=[];this.searchLedgers=[];
  if(this.config.occlusion){const x=Math.floor(w*.48);for(let y=1;y<h-1;y++)if(y<Math.floor(h*.38)||y>Math.floor(h*.62))this.mask[IDX(x,y,w)]=1;}
  this.seedSources();(options.genomes??bases).forEach(g=>this.addSpecies(g));
 }
 seedSources(){
  const sites=[[Math.floor(this.w*.13),Math.floor(this.h*.32),0],[Math.floor(this.w*.88),Math.floor(this.h*.66),1],[Math.floor(this.w*.62),Math.floor(this.h*.20),2]];
  for(const [x,y,c] of sites){const i=IDX(x,y,this.w);this.f[3*i+c]=.93;}
 }
 addSpecies(g){
  const genome=g.schema==='ripple-alpha-gene/1'?g:makeGenome(g);
  assert(this.agents.length<constants.maxSpecies,'species cap 24');
  assert(!this.genomeRegistry.has(genome.id),'duplicate genome ID');
  this.genomeRegistry.set(genome.id,genome);
  const pos={x:Math.floor(this.w*.20+this.rand()*this.w*.60),y:Math.floor(this.h*.2+this.rand()*this.h*.6)};
  if(this.mask[IDX(pos.x,pos.y,this.w)]===1)pos.x=clamp(pos.x-1,0,this.w-1);
  const a={genome,id:genome.id,x:pos.x,y:pos.y,path:[{x:pos.x,y:pos.y,t:this.tick}],rate:0,fires:0,detected:0,state:'0',lastSignal:0,lastTemporal:0,neuron:new RippleNeuron(),chromatic:!genomeGray(genome),color:color(genome),fitness:0,avg:0};
  this.agents.push(a);this.events.push({t:this.tick,type:'species_created',id:a.id,parent:genome.parent,classification:a.chromatic?'chromatic':'genome_monochrome'});return a;
 }
 nearby(a){const all=[[1,0],[-1,0],[0,1],[0,-1],[0,0]];return all.map(([dx,dy])=>({x:clamp(a.x+dx,0,this.w-1),y:clamp(a.y+dy,0,this.h-1)})).filter(p=>this.mask[IDX(p.x,p.y,this.w)]<1)}
 observation(x,y,g){const i=IDX(x,y,this.w),v=[this.f[i*3],this.f[i*3+1],this.f[i*3+2]];return v.reduce((s,x,k)=>s+x*g.weights[k],0)/(g.weights.reduce((a,b)=>a+b,0));}
 tickOnce(){
  assert(this.tick<constants.maxSteps,'step cap');
  const dt=constants.dt;
  const old=this.f;
  // Inject bounded deterministic sources: no external sensor claims.
  const sites=[[Math.floor(this.w*.13),Math.floor(this.h*.32),0],[Math.floor(this.w*.88),Math.floor(this.h*.66),1],[Math.floor(this.w*.62),Math.floor(this.h*.20),2]];
  for(const [x,y,c] of sites){const i=IDX(x,y,this.w);old[i*3+c]=clamp(old[i*3+c]+.035,0,1.5)}
  // density is explicitly numerical occupancy; no inference of atomic matter.
  this.density.fill(0);
  for(const a of this.agents)this.density[IDX(a.x,a.y,this.w)]+=1;
  this.prev=this.f.slice();
  const before=old.reduce((s,v)=>s+v,0);
  this.f=diffusionStep(old,this.w,this.h,this.config.diffusion,dt,this.mask,this.config.density?this.density:null,.9);
  if(this.config.reactive){
    // Optional bounded field-decay model, not classical reaction-diffusion chemistry.
    for(let i=0;i<this.f.length;i++)this.f[i]*=(1-.0008*dt);
  }
  for(let i=0;i<this.f.length;i++)this.f[i]=clamp(this.f[i],0,1.5);
  const after=this.f.reduce((s,v)=>s+v,0);
  for(const a of this.agents){
    const g=a.genome,choices=this.nearby(a),prevScore=a.lastSignal;
    let selected=choices[0],best=-Infinity;
    for(const p of choices){const signal=this.observation(p.x,p.y,g);
      const penalty=this.config.density?.065*this.density[IDX(p.x,p.y,this.w)]*g.crowding:0;
      const memory=p.x===a.x&&p.y===a.y?g.memory*.007:0;
      const value=signal-penalty+memory+(this.rand()-.5)*(.012*g.mobility);
      if(value>best){best=value;selected=p;}
    }
    if(this.rand()<g.mobility){a.x=selected.x;a.y=selected.y;}
    const i=IDX(a.x,a.y,this.w),rgb=[this.f[3*i],this.f[3*i+1],this.f[3*i+2]];
    const obs=this.observation(a.x,a.y,g);const delta=obs-prevScore;
    a.lastTemporal=delta;a.lastSignal=obs;
    const q=fourState(obs,delta);a.state=q.symbol;
    // Feeding ORIGINAL v0.1 core with normalized field RGB, not changing its equations.
    const neuronInput=rgb.map((v,c)=>clamp(v*g.weights[c],0,1));
    const result=a.neuron.step(neuronInput,dt);a.rate=result.rate;a.fires+=result.count;
    a.fitness+=obs;a.avg=a.fitness/(this.tick+1);
    a.path.push({x:a.x,y:a.y,t:this.tick+1,state:a.state});if(a.path.length>constants.maxPath)a.path.shift();
  }
  this.tick++;
  let mon=0,bright=0;
  for(let i=0;i<this.n;i++){
    if(this.mask[i]===1)continue;
    const rgb=[this.f[i*3],this.f[i*3+1],this.f[i*3+2]];
    const m=monochrome(rgb);if(m.gray)mon++;if(m.bright>=constants.minBrightness)bright++;
  }
  const state=mon>0?mon/Math.max(1,bright):0;
  this.monochromeHistory.push(state);
  if(this.monochromeHistory.length>constants.monochromeHold)this.monochromeHistory.shift();
  const sustained=this.monochromeHistory.length===constants.monochromeHold&&this.monochromeHistory.every(x=>x>.15);
  if(sustained&&!this.events.some(e=>e.type==='field_monochrome_emerged'))this.events.push({t:this.tick,type:'field_monochrome_emerged',fraction:state,criterion:'15% of bright traversable cells for 8 consecutive steps'});
  this.trajectory.push({step:this.tick,monochromeFraction:state,brightCells:bright,massAfter:after,massBefore:before,densityActive:this.config.density,agents:this.agents.length});
  return this.trajectory[this.trajectory.length-1];
 }
 run(steps=240){assert(Number.isInteger(steps)&&steps>0&&steps<=constants.maxSteps-this.tick,'run step bounds');for(let i=0;i<steps;i++)this.tickOnce();return this.report()}
 introduceMonochrome(parentId,seed=this.seed+this.tick){
   assert(this.tick>=60,'complete initial baseline before targeted gene selection');
   const parent=this.genomeRegistry.get(parentId);assert(parent,'parent genome missing');
   const study=searchMonochromeGenome(parent,seed,30);
   this.searchLedgers.push(study);
   this.events.push({t:this.tick,type:'goal_directed_mono_search',parent:parentId,result:study.result.id,monochrome:study.monochrome,objective:'minimize chroma, synthetic, deliberately selected'});
   if(study.monochrome&&!this.genomeRegistry.has(study.result.id))this.addSpecies(study.result);
   return study;
 }
 breed(count=3,pressure=.4){assert(Number.isInteger(count)&&count>0&&count<=6,'offspring count must be 1..6');
  const candidates=this.agents.slice().sort((a,b)=>b.avg-a.avg).slice(0,count);
  const produced=[];for(const p of candidates){const g=mutateGenome(p.genome,Math.floor(this.rand()*4294967295),pressure);if(this.genomeRegistry.has(g.id))continue;produced.push(this.addSpecies(g).id)}return produced;
 }
 report(){const genomes=[...this.genomeRegistry.values()];const latest=this.trajectory.at(-1)||{monochromeFraction:0,brightCells:0};const byAgent=this.agents.map(a=>({id:a.id,name:a.genome.label,parent:a.genome.parent,generation:a.genome.generation,color:a.color,genomeGray:!a.chromatic,x:a.x,y:a.y,rate:a.rate,fires:a.fires,score:a.avg,path:a.path}));
  const seq=byAgent.slice(0,4).map(a=>this.agents.find(x=>x.id===a.id)?.state??'0');
  const states=seq.map(x=>({'-1':0,'-0':1,'0':2,'1':3})[x]);
  return {schema:'ripple-alpha-report/1',evidence:'SIMULATED',seed:this.seed,tick:this.tick,config:{...this.config},lockedCore:'v0.1 imported unchanged',viewport:[this.w,this.h],agents:byAgent,events:this.events,searchLedgers:this.searchLedgers,monochrome:latest.monochromeFraction,brightCells:latest.brightCells,quaternary:{symbols:seq,bits:states.map(toBits),byte:pack4(states)},trajectory:this.trajectory,genomes};
 }
 frame(){return{width:this.w,height:this.h,field:Array.from(this.f),occlusion:Array.from(this.mask),density:Array.from(this.density),agents:this.agents.map(a=>({x:a.x,y:a.y,id:a.id,color:a.color,path:a.path}))}}
}
function runStudy(opts={}){const result=[];for(const mode of ['baseline','occlusion','density','combined']){
 const env={seed:opts.seed??17413,diffusion:opts.diffusion??.32,occlusion:mode==='occlusion'||mode==='combined',density:mode==='density'||mode==='combined'};
 const lab=new AlphaLab(env);lab.run(opts.steps??220);const r=lab.report();result.push({mode,seed:env.seed,steps:r.tick,monochrome:r.monochrome,avgSignal:r.agents.reduce((a,x)=>a+x.score,0)/r.agents.length,totalFires:r.agents.reduce((a,x)=>a+x.fires,0),evidence:'SIMULATED'});
 }return result;}

window.RippleAlpha={AlphaLab,runStudy,bases,genomeGray,constants};
})();
