
const LABELS=["-1","-0","0","1"]; const BITS=["00","01","10","11"]; const toSymbol=n=>LABELS[n]; const toBits=n=>BITS[n]; const pack4=a=>a.reduce((p,c)=>(p<<2)|c,0); const unpack4=b=>[6,4,2,0].map(s=>(b>>s)&3);
