
/* Ripple Alpha Labs v1.0 UI — depends on frozen globalThis.RippleAlpha. */
(()=>{
 'use strict';
 const {AlphaLab,runStudy,bases,genomeGray,constants}=window.RippleAlpha;
 const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
 let lab=new AlphaLab({seed:17413,occlusion:true,diffusion:.32}),running=false,timer=null,searchResult=null,study=null,selected=null,historyPaused=false;
 const el=(tag,classes,text)=>{const e=document.createElement(tag);if(classes)e.className=classes;if(text!==undefined)e.textContent=text;return e};
 const span=(s)=>el('span','',s);
 const nfmt=(n,d=2)=>Number(n).toFixed(d);
 function launch(){running=!running;$('#play').textContent=running?'Pause':'Run Alpha';$('#play').dataset.active=String(running);if(timer)clearInterval(timer);if(running)timer=setInterval(()=>{if(document.hidden)return;if(lab.tick>=constants.maxSteps){launch();return;}try{for(let k=0;k<2;k++)lab.tickOnce();render()}catch(e){launch();showError(e)}},70);}
 function showError(err){$('#status').textContent='GUARDRAIL: '+(err?.message||err);$('#status').classList.add('danger')}
 function reset(){if(running)launch();const seed=parseInt($('#seed').value,10);try{lab=new AlphaLab({seed,occlusion:$('#occlusion').checked,diffusion:parseFloat($('#diffuse').value)});searchResult=null;selected=null;study=null;$('#searchOutcome').textContent='No lineage search has run yet.';$('#density').checked=false;render();}catch(e){showError(e)}}
 function tab(name){$$('.navbtn').forEach(e=>{e.classList.toggle('active',e.dataset.tab===name);e.setAttribute('aria-selected',String(e.dataset.tab===name))});$$('section.screen').forEach(e=>{e.hidden=e.dataset.screen!==name});render()}
 function densityUnlocked(){return lab.tick>=60&&(lab.events.some(e=>e.type==='goal_directed_mono_search'&&e.monochrome)||lab.events.some(e=>e.type==='field_monochrome_emerged'))}
 function redraw(){
  const cv=$('#field'),p=cv.getContext('2d'),w=lab.w,h=lab.h;
  const image=p.createImageData(w,h),data=image.data;
  for(let i=0;i<lab.n;i++){
   const intensity=(c)=>Math.pow(Math.min(1,lab.f[3*i+c]/.30),.7);
   const black=lab.mask[i]===1;
   data[4*i]=black?12:Math.floor(18+237*intensity(0));
   data[4*i+1]=black?23:Math.floor(25+223*intensity(1));
   data[4*i+2]=black?35:Math.floor(41+209*intensity(2));
   if(lab.config.density&&lab.density[i]){
    data[4*i]=Math.floor(Math.min(255,data[4*i]+lab.density[i]*16));
    data[4*i+1]=Math.floor(Math.min(255,data[4*i+1]+lab.density[i]*12));
   }
   data[4*i+3]=255;
  }
  const temp=$('#pixels'),ctx=temp.getContext('2d');temp.width=w;temp.height=h;ctx.putImageData(image,0,0);
  cv.width=Math.round(cv.clientWidth*devicePixelRatio);cv.height=Math.round((cv.clientWidth*h/w)*devicePixelRatio);p.clearRect(0,0,cv.width,cv.height);p.imageSmoothingEnabled=false;p.drawImage(temp,0,0,cv.width,cv.height);
  const cellW=cv.width/w,cellH=cv.height/h;
  for(const a of lab.agents){
   const c='rgb('+a.color.join(',')+')';p.strokeStyle=c;p.lineWidth=Math.max(1.8,cellW*.12);
   const path=a.path;if(path.length>1){p.beginPath();p.moveTo((path[0].x+.5)*cellW,(path[0].y+.5)*cellH);
    for(const at of path.slice(1))p.lineTo((at.x+.5)*cellW,(at.y+.5)*cellH);p.stroke();}
   p.fillStyle=c;p.strokeStyle='#0f2130';p.lineWidth=Math.max(2,cellW*.14);p.beginPath();p.arc((a.x+.5)*cellW,(a.y+.5)*cellH,Math.max(3,cellW*.3),0,Math.PI*2);p.fill();p.stroke();
  }
 }
 function render(){
   $('#stepValue').textContent=lab.tick;$('#speciesValue').textContent=lab.agents.length;
   const r=lab.report(),f=r.monochrome;$('#monoValue').textContent=(100*f).toFixed(1)+'%';
   $('#spikesValue').textContent=r.agents.reduce((s,a)=>s+a.fires,0);
   $('#quad').textContent=r.quaternary.symbols.join(' | ');
   $('#bits').textContent=r.quaternary.bits.join(' ');
   $('#modeValue').textContent=(lab.config.density?'Density active':'Density locked / inactive');
   $('#density').disabled=!densityUnlocked();$('#densityGate').textContent=densityUnlocked()?'Allowed: ≥60 steps and confirmed simulated mono event or selected descendant.':'Locked: complete ≥60 baseline steps, then verify monochrome lineage or sustained field event.';
   $('#monoEvent').textContent=lab.events.some(e=>e.type==='field_monochrome_emerged')?'Sustained FIELD gray-emergence event recorded.':'No sustained field monochrome event yet.';
   $('#status').classList.remove('danger');$('#status').textContent='SIMULATED · v0.1 original neuron imported · alpha algorithms isolated · deterministic seed '+lab.seed;
   $('#diffuseValue').textContent=nfmt(lab.config.diffusion,2);
   redraw();renderSpecies();renderLineage();renderEvents();renderStudy();
 }
 function renderSpecies(){const t=$('#speciesTable');t.replaceChildren();for(const a of lab.agents){const g=a.genome;
   const tr=el('tr');tr.classList.toggle('selected',selected===a.id);
   const gene=el('td');gene.append(el('span','swatch'),span(g.label));gene.querySelector('.swatch').style.background='rgb('+a.color.join(',')+')';
   for(const cell of [gene,span(g.id),span(g.generation),span(a.state),span(nfmt(a.avg,3)),span(a.fires),span(a.chromatic?'Chromatic':'Gray genotype')]){let td=cell.tagName==='TD'?cell:el('td');if(td!==cell)td.append(cell);tr.append(td)}
   tr.onclick=()=>{selected=a.id;$('#selection').textContent=g.label+' · '+g.id+' · ancestry '+(g.parent||'root')+' · weights '+g.weights.map(v=>v.toFixed(3)).join(' / ');renderSpecies()};t.append(tr);
 }}
 function renderLineage(){const t=$('#lineageRows');t.replaceChildren();for(const a of lab.agents){const g=a.genome,tr=el('tr');[g.label,g.id,g.parent||'ROOT',String(g.generation),g.weights.map(v=>nfmt(v,2)).join(' / '),genomeGray(g)?'Yes':'No'].forEach(x=>tr.append(el('td','',x)));t.append(tr)}}
 function renderEvents(){const t=$('#events');t.replaceChildren();for(const evt of lab.events.slice(-24).reverse()){
 const row=el('div','event');row.append(el('time','',String(evt.t).padStart(4,'0')),el('div','',evt.type+' • '+(evt.id||evt.result||evt.parent||'field')));t.append(row);
 }}
 function renderStudy(){const root=$('#comparison');root.replaceChildren();if(!study){root.append(el('div','minor','Comparison not executed. Click Run controlled comparison.'));return}
 const table=el('table','resTable');const head=el('tr');['Condition','Mean sampled field','Model events','Field gray %'].forEach(x=>head.append(el('th','',x)));table.append(head);
 for(const a of study){const tr=el('tr');[a.mode,nfmt(a.avgSignal,4),String(a.totalFires),(100*a.monochrome).toFixed(1)+'%'].forEach(x=>tr.append(el('td','',x)));table.append(tr)}root.append(table);
 }
 function download(name,object){const blob=new Blob([JSON.stringify(object,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1200)}
 function simulate(){try{if(running)launch();lab.run(60);render()}catch(e){showError(e)}}
 $('#play').onclick=launch;$('#advance').onclick=()=>{try{if(running)launch();lab.run(20);render()}catch(e){showError(e)}};
 $('#reset').onclick=reset;$('#birth').onclick=()=>{try{lab.breed(3);render()}catch(e){showError(e)}};
 $('#search').onclick=()=>{try{const a=lab.agents.find(a=>a.genome.label==='Amber')||lab.agents[3];searchResult=lab.introduceMonochrome(a.id);$('#searchOutcome').textContent=(searchResult.monochrome?'A selected monochrome-criterion descendant was produced. ':'No qualifying descendant within the search limit. ')+`Recorded ${searchResult.ledger.length} lineage decisions; goal-directed selection is not spontaneous emergence.`;render()}catch(e){showError(e)}};
 $('#occlusion').onchange=ev=>{lab.config.occlusion=ev.target.checked;if(!ev.target.checked)lab.mask.fill(0);else{const x=Math.floor(lab.w*.48);for(let y=1;y<lab.h-1;y++)if(y<Math.floor(lab.h*.38)||y>Math.floor(lab.h*.62))lab.mask[y*lab.w+x]=1;}render()};
 $('#density').onchange=ev=>{if(!densityUnlocked()){ev.target.checked=false;return}lab.config.density=ev.target.checked;lab.events.push({t:lab.tick,type:'density_stage_change',enabled:lab.config.density});render()};
 $('#diffuse').oninput=ev=>{const d=Number(ev.target.value);lab.config.diffusion=d;$('#diffuseValue').textContent=d.toFixed(2)};
 $('#compare').onclick=()=>{try{study=runStudy({seed:lab.seed,steps:220,diffusion:lab.config.diffusion});render();}catch(e){showError(e)}};
 $('#export').onclick=()=>download('Ripple-Alpha-Report-v1.0.json',{report:lab.report(),study,monochromeSearch:searchResult,field:lab.frame(),provenance:'SIMULATED — not a measured camera experiment'});
 $('#saveField').onclick=()=>{const a=document.createElement('a');a.href=$('#field').toDataURL('image/png');a.download='Ripple-Alpha-Field-'+lab.tick+'.png';a.click()};
 $('#archiveNote').onclick=()=>tab('vault');
 $$('.navbtn').forEach(x=>x.onclick=()=>tab(x.dataset.tab));
 // Canvas selection readout is a local simulation, not a live camera reading.
 $('#field').onclick=ev=>{const b=$('#field').getBoundingClientRect(),x=Math.max(0,Math.min(lab.w-1,Math.floor((ev.clientX-b.left)/b.width*lab.w))),y=Math.max(0,Math.min(lab.h-1,Math.floor((ev.clientY-b.top)/b.height*lab.h)));
 const i=(y*lab.w+x)*3,v=[lab.f[i],lab.f[i+1],lab.f[i+2]];$('#pixelInfo').textContent=`SIMULATED cell (${x}, ${y}) • R ${nfmt(v[0],3)} · G ${nfmt(v[1],3)} · B ${nfmt(v[2],3)} · occupancy ${lab.density[y*lab.w+x]} · obstacle ${lab.mask[y*lab.w+x]}`};
 addEventListener('resize',render);
 document.addEventListener('visibilitychange',()=>{if(document.hidden&&running)launch()});
 render();
})();

