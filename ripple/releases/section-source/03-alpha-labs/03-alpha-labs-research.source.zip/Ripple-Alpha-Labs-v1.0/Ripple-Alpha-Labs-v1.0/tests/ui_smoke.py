"""Optional scripted UI smoke test. Requires playwright and local Chromium.
The app itself needs no Python package and no web connection.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parent.parent
html=(root/'index.html').read_text()
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
    page=browser.new_page(viewport={'width':393,'height':852},device_scale_factor=1)
    errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_content(html,wait_until='commit',timeout=7000)
    page.locator('#advance').click()
    assert page.locator('#stepValue').inner_text()=='20'
    page.locator('#search').click()
    assert 'GUARDRAIL' in page.locator('#status').inner_text()
    page.locator('#advance').click();page.locator('#advance').click()
    page.locator('#search').click()
    assert 'selected monochrome-criterion descendant' in page.locator('#searchOutcome').inner_text()
    assert page.locator('#density').is_enabled()
    page.locator('#density').check();page.locator('#advance').click()
    page.locator('button[data-tab="comparisons"]').click();page.locator('#compare').click()
    assert page.locator('#comparison tr').count()==5
    page.locator('button[data-tab="genes"]').click()
    assert page.locator('#speciesTable tr').count()>=6
    page.locator('button[data-tab="lab"]').click()
    page.screenshot(path=str(root/'verified/phone.png'),full_page=True)
    page.set_viewport_size({'width':1280,'height':800})
    page.screenshot(path=str(root/'verified/desktop.png'),full_page=True)
    assert not errors,errors
    browser.close()
print('PASS alpha lab browser smoke: responsive mobile/desktop, phases, archive interaction, 4-mode study, zero page errors')
