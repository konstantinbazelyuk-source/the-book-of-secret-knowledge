import{writeFileSync}from'node:fs';
import{runStudy,AlphaLab,bases,searchMonochromeGenome,constants}from'../engine.mjs';
const rows=[];
for(const seed of [11,17,41,43,47])for(const r of runStudy({seed,steps:240,diffusion:.32}))rows.push({...r,split:seed===11||seed===17?'training':'holdout'});
const selected=bases.map(g=>({origin:g.label,study:searchMonochromeGenome(g,17413,30)}));
const conservation=new AlphaLab({seed:41,occlusion:true});conservation.run(240);
const report={schema:'ripple-alpha-study/1',evidence:'SIMULATED ONLY',metadata:{seeds:[11,17,41,43,47],steps:240,version:'1.0.0',reusedLockedCore:'v0.1',density:'synthetic agent count per cell',monochrome:'not physical genetics'},comparison:rows,graySelection:selected.map(x=>({origin:x.origin,monochrome:x.study.monochrome,weights:x.study.result.weights,generations:x.study.ledger.length,ledger:x.study.ledger})),events:conservation.events,parameters:constants};
writeFileSync('verified/multi-seed-study.json',JSON.stringify(report,null,2));
writeFileSync('verified/comparison.csv','split,seed,mode,steps,monochrome,avgSignal,totalFires,evidence\n'+rows.map(x=>[x.split,x.seed,x.mode,x.steps,x.monochrome,x.avgSignal,x.totalFires,x.evidence].join(',')).join('\n'));
console.log('SIMULATED',rows.length,'comparison cases and',selected.length,'gene selection trajectories');
for(const mode of ['baseline','occlusion','density','combined']){
 const xs=rows.filter(r=>r.mode===mode&&r.split==='holdout');
 console.log(mode, 'meanHoldoutSignal',(xs.reduce((s,x)=>s+x.avgSignal,0)/xs.length).toFixed(6),'meanModelEvents',(xs.reduce((s,x)=>s+x.totalFires,0)/xs.length).toFixed(1),'meanGrayFraction',(xs.reduce((s,x)=>s+x.monochrome,0)/xs.length).toFixed(4));
}
