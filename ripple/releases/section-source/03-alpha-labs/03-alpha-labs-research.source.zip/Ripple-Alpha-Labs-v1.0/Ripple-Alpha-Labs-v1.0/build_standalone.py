from pathlib import Path
r=Path(__file__).resolve().parent
html=(r/'index-template.html').read_text().replace('/*CORE_PLACEHOLDER*/',(r/'Ripple-Neuron-Quaternary-v0.7/web/ripple-core.js').read_text())
q='const LABELS=["-1","-0","0","1"]; const BITS=["00","01","10","11"]; const toSymbol=n=>LABELS[n]; const toBits=n=>BITS[n]; const pack4=a=>a.reduce((p,c)=>(p<<2)|c,0); const unpack4=b=>[6,4,2,0].map(s=>(b>>s)&3);'
html=html.replace('/*QUATERNARY_PLACEHOLDER*/',q)
engine=(r/'engine.mjs').read_text().replace("import './Ripple-Neuron-Quaternary-v0.7/web/ripple-core.js';",'').replace("import {toBits, toSymbol, pack4, unpack4} from './Ripple-Neuron-Quaternary-v0.7/web/quaternary-core.mjs';",'').replace('export {RippleNeuron,pack4,unpack4,toBits,toSymbol};','').replace('export const ','const ').replace('export function ','function ').replace('export class ','class ')
html=html.replace('/*ENGINE_PLACEHOLDER*/','(()=>{\n'+engine+'\nwindow.RippleAlpha={AlphaLab,runStudy,bases,genomeGray,constants};\n})();')
html=html.replace('window.RippleAlpha={AlphaLab,runStudy,bases,genomeGray,constants};\n</script>','</script>')
html=html.replace('/*UI_PLACEHOLDER*/',(r/'ui.js').read_text())
(r/'index.html').write_text(html)
(r/'Ripple-Alpha-Labs-v1.0.html').write_text(html)
print('Built byte-identical interactive standalone HTML',len(html))
