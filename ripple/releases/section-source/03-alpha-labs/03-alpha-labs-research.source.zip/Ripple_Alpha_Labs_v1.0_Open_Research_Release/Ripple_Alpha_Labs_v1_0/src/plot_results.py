"""Visualizations only of already-executed synthetic numeric simulations."""
from ripple_alpha import *
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap


def main():
    target=ROOT/'results';target.mkdir(exist_ok=True)
    fig,axs=plt.subplots(2,4,figsize=(15,8),constrained_layout=True)
    for col,species in enumerate(SPECIES):
        c=Conditions(n=56,steps=110,seed=41,dim=2,occlusion=True,diffusion=True,density=True)
        run=run_one(species,c,record_frames=True)
        first=run['frames'][0];last=run['frames'][109]
        for row,field in enumerate((first,last)):
            rgba=np.moveaxis(field,0,-1) * np.asarray(species.rgb_gain)
            rgba=np.clip(rgba * 1.65,0,1)
            axs[row,col].imshow(np.clip(rgba,0,1),interpolation='nearest')
            axs[row,col].imshow(np.ma.masked_where(~run['obstacle'],run['obstacle']),cmap=ListedColormap(['#828788']),alpha=.75)
            axs[row,col].set(title=species.name+(' · initial' if row==0 else ' · final'),xticks=[],yticks=[])
            axs[row,col].title.set_color(species.color)
    fig.suptitle('RIPPLE ALPHA / SYNTHETIC RGB-CONCENTRATION CHANNELS · diffusion + occlusion + density',fontsize=13)
    fig.savefig(target/'species_lab.png',dpi=160);plt.close(fig)

    fig,axes=plt.subplots(1,2,figsize=(12,4),constrained_layout=True)
    for s in SPECIES:
        c=Conditions(n=40,steps=100,seed=43)
        d=run_one(s,c)
        times=[x['sim_s'] for x in d['trace']]
        axes[0].plot(times,[x['total_intensity'] for x in d['trace']],label=s.name,color=s.color)
        axes[1].plot(times,[x['monochrome_new_persistent'] for x in d['trace']],label=s.name,color=s.color)
    axes[0].set(xlabel='Simulation seconds',ylabel='Total synthetic intensity',title='Field transport and absorption')
    axes[1].set(xlabel='Simulation seconds',ylabel='Persistent newly monochrome cells',title='Monochrome state emergence definition')
    axes[0].legend();axes[1].legend()
    fig.savefig(target/'paths.png',dpi=160);plt.close(fig)

if __name__=='__main__':main()
