from ripple_alpha import *
from pathlib import Path
import html,json

root=ROOT
runs={}
for s in SPECIES:
    runs[s.name]={}
    for stage,params in [('Diffusion only',dict(diffusion=True,occlusion=False,density=False)),
                         ('Diffusion + occlusion',dict(diffusion=True,occlusion=True,density=False)),
                         ('Diffusion + occlusion + density',dict(diffusion=True,occlusion=True,density=True))]:
        r=run_one(s,Conditions(steps=100,n=44,seed=41,**params))
        runs[s.name][stage]={'metrics':r['metrics'],'trace':r['trace']}
lineages=json.loads((ROOT/'results'/'lineage.json').read_text())
all_trials=json.loads((ROOT/'results'/'summary.json').read_text())
data=json.dumps({'runs':runs,'lineages':lineages,'trials':all_trials},separators=(',',':'))
page=r'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Ripple Alpha Research Labs · v1.0</title>
<style>
:root{color-scheme:dark;--bg:#070e17;--tile:#12202b;--line:#284454;--ink:#e8eef5;--muted:#a0b4c2;--cyan:#54dddc;--warning:#e3b36a}*{box-sizing:border-box}
body{margin:0;font:15px system-ui,Segoe UI,sans-serif;background:radial-gradient(ellipse at 50% 0,#173244 0,var(--bg) 70%);color:var(--ink)}
main{max-width:1210px;margin:auto;padding:22px}h1{font-size:clamp(28px,4vw,45px);letter-spacing:-.025em;margin:8px 0}h2{font-size:18px;margin:0 0 12px}
p,small{color:var(--muted);line-height:1.5}p{max-width:90ch}.kicker{font-size:12px;color:var(--cyan);letter-spacing:.16em;font-weight:750}
.notice{padding:13px 17px;border-radius:9px;border:1px solid #5b5042;background:#22201d;color:#f7d9a7;margin:20px 0}
.panel{background:linear-gradient(160deg,#132832,#0e1a26);border:1px solid var(--line);border-radius:14px;padding:17px;margin:12px 0}
.controls{display:flex;gap:15px;flex-wrap:wrap}label{display:flex;flex-direction:column;gap:6px;color:var(--muted);font-size:12px}
select{padding:9px 14px;background:#142832;color:var(--ink);border-radius:8px;border:1px solid #427386;font:inherit}
.dashboard{display:grid;grid-template-columns:2fr 1fr;gap:12px}.stats{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.stat{border:1px solid var(--line);background:#0a1b24;padding:14px;border-radius:9px}.stat strong{font-size:23px;display:block;font-variant-numeric:tabular-nums}.stat span{font-size:11px;color:var(--muted)}
canvas{width:100%;height:320px;background:#091622;border:1px solid #20394b;border-radius:9px}
.pills{display:flex;gap:9px;flex-wrap:wrap;margin:12px 0}.pill{border:1px solid #375869;background:#112431;padding:6px 9px;border-radius:20px;font-size:12px;color:#bad2dc}
img{width:100%;border-radius:8px;max-height:640px;object-fit:contain}pre{background:#091722;color:#a2e6d2;border:1px solid #244a4d;border-radius:8px;padding:15px;max-height:260px;overflow:auto;white-space:pre-wrap;font-size:12px}
a{color:#8ee4dc}.fine{font-size:12px;color:var(--muted)}
@media(max-width:760px){main{padding:12px}.dashboard{grid-template-columns:1fr}canvas{height:270px}}
</style></head><body><main><div class="kicker">RIPPLE / ALPHA 1.0 / ISOLATED EXPERIMENT LAB</div>
<h1>Ripple Alpha Research Labs</h1><p>Four digital species · original leaky-integrate-and-fire neurons · sensor provenance bridge · 2D/3D simulated environments · staged diffusion, occlusion and density experiments.</p>
<div class="notice"><b>SIMULATED STUDIES ONLY.</b> The graphs are generated from executed numerical models. The magnetometer example is also simulated. No hardware field measurement, consciousness, biological genetics or self-improving intelligence has been demonstrated.</div>
<section class="panel"><div class="controls"><label>Gene species<select id="species"><option value="prism">Prism / cyan</option><option value="canopy">Canopy / green</option><option value="ember">Ember / amber</option><option value="violet">Violet / purple</option></select></label>
<label>Research phase<select id="stage"><option>Diffusion only</option><option>Diffusion + occlusion</option><option selected>Diffusion + occlusion + density</option></select></label>
<label>Signal graph<select id="metric"><option value="monochrome_new_persistent">Persistently monochrome cells</option><option value="total_intensity">Synthetic field intensity</option><option value="neuron_events_cumulative">Accumulated neuron events</option><option value="active_cells">Active grid cells</option></select></label></div></section>
<div class="dashboard"><section class="panel"><h2>Single variant path / 100 simulated steps</h2><canvas id="plot" width="760" height="320" aria-label="Simulated metric over time"></canvas><p class="fine">Monochrome detector: normalized 3-channel spectral entropy &lt; 0.40, dominant share &gt; 0.87, total &gt; 0.045; five consecutive frames, excluding initially qualified cells.</p></section>
<section class="panel"><h2>Run inspection</h2><div class="stats"><div class="stat"><strong id="events">—</strong><span>Neuron firing events</span></div><div class="stat"><strong id="mono">—</strong><span>New monochrome cells</span></div><div class="stat"><strong id="retained">—</strong><span>Intensity retained</span></div><div class="stat"><strong id="active">—</strong><span>Active field cells</span></div></div><p class="fine" id="tag"></p><p class="fine">Environmental channels are dimensionless simulations. Magnetic sensor µT data are not converted to RGB.</p></section></div>
<section class="panel"><h2>Path and structure snapshots</h2><p>Each panel depicts simulated red, green and blue concentration channels, not wavelengths physically recorded by Ripple.</p><img src="results/species_lab.png" alt="Four simulated digital-species field maps, each with initial and final states"></section>
<section class="panel"><h2>Finite overlay selection / lineage audit</h2><p>The audit records changes to <em>new overlay parameters only</em>. It does not edit v0.1 neuron equations or existing v0.5 genomes. Objective and holdout values reflect a user-defined simulation metric, not a measure of intelligence.</p><pre id="lineage"></pre></section>
<section class="panel"><h2>Source of truth</h2><div class="pills"><span class="pill">Archived Ripple v0.3 and v0.5 unchanged</span><span class="pill">64 2D trials</span><span class="pill">64 3D trials</span><span class="pill">16-probe/field? NO · 8 legacy neuron replicas</span><span class="pill">Hardware: NOT VALIDATED</span></div><p class="fine">Offline dashboard; no cloud services, analytics, device permissions or network requests. Inspect docs/EXPERIMENT_PROTOCOL.md and results/ for reproducibility.</p></section></main>
<script>const DATA=___DATA___;
const el=id=>document.getElementById(id);
function draw(){const s=el('species').value,stage=el('stage').value,key=el('metric').value,run=DATA.runs[s][stage],m=run.metrics,trace=run.trace;
el('events').textContent=m.events;el('mono').textContent=m.monochrome_persistent_cells;el('retained').textContent=(100*m.intensity_retained).toFixed(1)+'%';el('active').textContent=m.active_cells_final;
el('tag').textContent=`Species marker: ${m.marker.slice(0,22)}… / classification: ${m.classification}`;
const c=el('plot'),ctx=c.getContext('2d'),w=c.width,h=c.height;ctx.clearRect(0,0,w,h);ctx.fillStyle='#081a25';ctx.fillRect(0,0,w,h);
const vals=trace.map(r=>r[key]);const max=Math.max(1,...vals)*1.1,min=0,l=55,t=18,r=w-18,b=h-36;
ctx.strokeStyle='#365161';ctx.lineWidth=1;ctx.font='12px system-ui';ctx.fillStyle='#97b8c4';for(let i=0;i<=4;i++){const y=b-(b-t)*i/4;ctx.beginPath();ctx.moveTo(l,y);ctx.lineTo(r,y);ctx.stroke();ctx.fillText((max*i/4).toFixed(key==='total_intensity'?1:0),4,y+4);}
const palette={prism:'#38dff2',canopy:'#6fe7a7',ember:'#efae60',violet:'#ad8cfd'};ctx.strokeStyle=palette[s];ctx.lineWidth=2.5;ctx.beginPath();vals.forEach((v,i)=>{const x=l+(r-l)*i/(vals.length-1),y=b-(b-t)*(v-min)/(max-min);i?ctx.lineTo(x,y):ctx.moveTo(x,y)});ctx.stroke();ctx.fillStyle='#bed1d9';ctx.fillText('0',l,b+18);ctx.fillText((trace.at(-1).sim_s).toFixed(1)+' simulation s',r-100,b+18);
const ln=DATA.lineages.find(x=>x.ledger[0].species.name===s);
el('lineage').textContent=JSON.stringify({training_baseline:ln.ledger[0].train_score,training_selected:ln.ledger.at(-1).train_score,holdout_before:ln.holdout_original_score,holdout_after:ln.holdout_selected_score,ancestry:ln.ledger.map(x=>({generation:x.generation,mutation:x.mutation,marker:x.marker.slice(0,24),parent:x.parent?.slice(0,24)}))},null,2);
}
for(const x of ['species','stage','metric'])el(x).addEventListener('change',draw);draw();</script></body></html>'''
page=page.replace('___DATA___',data)
page=page.replace('<span class="pill">16-probe/field? NO · 8 legacy neuron replicas</span>','<span class="pill">8 replicated legacy neuron instances per trial</span>')
(root/'Ripple-Alpha-Lab.html').write_text(page)
print('Wrote dashboard',len(page),'bytes')
