"""Ripple Alpha Labs v1.0: deterministic, non-physical multi-variant field experiments.
This module is an additive LAB ONLY. It does not patch original Ripple sources.
"""
from __future__ import annotations
import csv, dataclasses, hashlib, json, math
from pathlib import Path
from typing import Any
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
SOURCE = 'synthetic_grid'
DEFAULT_SEED = 20261013


def bounded(x, low, high):
    return max(low, min(high, x))


class LegacyRippleNeuron:
    """Reviewed Python port of frozen JS class. Original JS in frozen/ripple_v03_reference.js.
    Formula, limits, timing, and feedback are unchanged. Cross-language parity tested.
    """
    def __init__(self, theta=.45, adaptive=True, target=1.0):
        self.theta=float(theta); self.adaptive=adaptive; self.target=float(target)
        self.tauV=.5;self.tauR=5.;self.refractory=.1;self.eta=.08
        self.lo=.15;self.hi=2.5;self.t=0.;self.u=0.;self.rate=0.;self.rest=0.

    def step(self, x, dt):
        if len(x)!=3 or not all(math.isfinite(float(v)) for v in x) or not math.isfinite(dt) or dt<=0 or dt>.5:
            raise ValueError('Invalid input or elapsed time')
        x=[bounded(float(v),0.,1.) for v in x]
        drive=2*x[0]+1.2*x[1]-1.4*x[2]
        start=self.t;events=[];elapsed=0.
        while elapsed < dt-1e-12:
            left=dt-elapsed
            if self.rest>1e-12:
                held=min(left,self.rest); self.rest=max(0.,self.rest-held);self.u=0.
                elapsed+=held;continue
            crossing=math.inf
            if self.u>=self.theta:crossing=0.
            elif drive>self.theta:crossing=self.tauV*math.log((drive-self.u)/(drive-self.theta))
            if crossing<=left+1e-12:
                elapsed+=max(0.,min(left,crossing));events.append(start+elapsed)
                self.u=0.;self.rest=self.refractory
            else:
                self.u=max(0.,drive+(self.u-drive)*math.exp(-left/self.tauV));elapsed=dt
        decay=math.exp(-dt/self.tauR);integral=self.rate*self.tauR*(1-decay)
        self.rate*=decay
        for event in events:
            d=math.exp(-(start+dt-event)/self.tauR)
            self.rate+=d/self.tauR;integral+=1-d
        if self.adaptive:
            self.theta=bounded(self.theta+self.eta*(integral-self.target*dt),self.lo,self.hi)
        self.t=start+dt
        return dict(t=self.t,u=self.u,theta=self.theta,rate=self.rate,drive=drive,count=len(events),events=events)


@dataclasses.dataclass(frozen=True)
class Species:
    """Gene-species = deliberately assigned experiment configuration, NOT biological DNA."""
    name: str
    color: str
    rgb_gain: tuple[float,float,float]
    diffusion_gain: float
    occlusion_gain: float
    absorption: float

    def marker(self):
        record={'schema':'ripple-alpha-species/1',**dataclasses.asdict(self)}
        return hashlib.sha256(json.dumps(record,sort_keys=True,separators=(',',':')).encode()).hexdigest()


SPECIES=(
    Species('prism', '#38dff2', (1.05,.95,.70), .16, .80, .024),
    Species('canopy', '#6fe7a7', (.74,1.10,.78), .20, .95, .018),
    Species('ember', '#efae60', (1.13,.77,.52), .10, 1.12, .030),
    Species('violet', '#ad8cfd', (.76,.83,1.14), .13, 1.04, .020),
)

@dataclasses.dataclass(frozen=True)
class Conditions:
    n: int=40
    steps: int=75
    dt: float=.08
    seed: int=DEFAULT_SEED
    diffusion: bool=True
    occlusion: bool=True
    density: bool=True
    dim: int=2


def check_conditions(c: Conditions, d):
    if c.dim not in (2,3) or c.n<10 or c.n>72 or c.steps<2 or c.steps>500:
        raise ValueError('Resource guard: invalid dimensions or experiment size')
    if not math.isfinite(c.dt) or c.dt<=0 or c.dt>.5:
        raise ValueError('Time guard: bad dt')
    if d<0 or 2*c.dim*d*c.dt>0.85:
        # conservative bound below von Neumann explicit constant-coefficient limit
        raise ValueError('Diffusion timestep guard violated')


def make_world(c: Conditions):
    rng=np.random.default_rng(c.seed)
    shape=(c.n,)*c.dim
    coord=np.indices(shape,dtype=float)
    x,y=coord[0],coord[1]
    z=coord[2] if c.dim==3 else np.zeros(shape)
    obstacle=np.zeros(shape,dtype=bool)
    # centered baffle with opening. Never treat unknown spaces as observed occupancy.
    obstacle[(x>=c.n*.47)&(x<=c.n*.51)&(y>=c.n*.08)&(y<=c.n*.83)&((z<c.n*.88) if c.dim==3 else True)]=True
    # Synthetic number density: bounded field distinct from physical mass density.
    density=np.clip(.42+.20*np.sin(y/c.n*2*np.pi)+.16*rng.standard_normal(shape),0,1)
    field=np.zeros((3,)+shape,dtype=float)
    for channel, (cx,cy,cz) in enumerate(((.19,.20,.30),(.75,.30,.50),(.29,.82,.70))):
        q=(x-c.n*cx)**2+(y-c.n*cy)**2 + ((z-c.n*cz)**2 if c.dim==3 else 0)
        field[channel]=.68*np.exp(-q/(2*(.085*c.n)**2))
    field[:,obstacle]=0.
    # 8 fixed sensing positions. No movement or intelligence presumed.
    nodes=[]
    for j in range(8):
        phase=2*math.pi*j/8
        xx=int(bounded(round(c.n*(.5+.32*math.cos(phase))),0,c.n-1))
        yy=int(bounded(round(c.n*(.5+.32*math.sin(phase))),0,c.n-1))
        zz=(int(c.n*(.27 if j%2 else .73)),) if c.dim==3 else ()
        pos=(xx,yy)+zz
        if obstacle[pos]:pos=(min(c.n-1,xx+3),yy)+zz
        nodes.append(pos)
    return field,density,obstacle,tuple(nodes)


def flux_laplacian(a, blocked, effective_diffusivity):
    """Conservative finite-volume flux (no passage through obstacle, zero-flux edges).
    Conductance between neighbors = avg per-cell diffusivity. Sum pair-fluxes.
    """
    flow=np.zeros_like(a)
    dim=a.ndim
    for axis in range(dim):
        src=[slice(None)]*dim;dst=[slice(None)]*dim
        src[axis]=slice(0,-1);dst[axis]=slice(1,None)
        src=tuple(src);dst=tuple(dst)
        conduct=.5*(effective_diffusivity[src]+effective_diffusivity[dst])
        valid=~(blocked[src]|blocked[dst])
        flux=conduct*valid*(a[dst]-a[src])
        flow[src]+=flux;flow[dst]-=flux
    return flow


def entropy_ratio(three: np.ndarray):
    """Local spectral Shannon entropy normalized to [0,1], with dark masked."""
    total=three.sum(axis=0)
    shares=three/np.maximum(total,1e-15)
    ent=-np.sum(np.where(shares>0,shares*np.log(np.maximum(shares,1e-15)),0.),axis=0)/math.log(3)
    return total, ent, np.max(shares,axis=0)


def monochrome_candidates(field, obstacle, threshold=.40, dominance=.87, floor=.045):
    total, entropy, dominant=entropy_ratio(field)
    return (total>=floor)&(entropy<threshold)&(dominant>=dominance)&(~obstacle)


def observe_field(field, nodes, gains):
    """Reinterpret numeric THREE-CHANNEL SYNTHETIC environment as RGB for v0.1 inputs.
    This does NOT convert magnetometer microtesla into light color.
    """
    return [np.clip(np.asarray([field[k][p]*gains[k] for k in range(3)]),0,1).tolist() for p in nodes]


def run_one(sp: Species, c: Conditions, record_frames=False):
    d=sp.diffusion_gain if c.diffusion else 0.
    check_conditions(c,d)
    field,density,blocked,nodes=make_world(c)
    neurons=[LegacyRippleNeuron() for _ in nodes]
    old_candidates=monochrome_candidates(field,blocked)
    # persistent definition: 5 consecutive evaluations of a newly mono cell
    streak=np.zeros(blocked.shape,dtype=np.uint16)
    emerged=np.zeros(blocked.shape,dtype=bool)
    trace=[];snapshots={};fire=0;first_mono=None
    initial_intensity=float(field.sum())
    for t in range(c.steps):
        concentration=density if c.density else np.zeros_like(density)
        effective_diff=np.full(blocked.shape,d,dtype=float)*(1-.42*concentration)
        # Exposure attenuation applies only in synthetic scenario; walls are masks.
        if c.occlusion:
            # baffle casts a simple right-side rectangular synthetic shadow.
            grid=np.indices(blocked.shape)[0]
            shadow=(grid>c.n*.51)&(np.indices(blocked.shape)[1]>.08*c.n)&(np.indices(blocked.shape)[1]<.83*c.n)
            attenuation=np.where(shadow, .993**sp.occlusion_gain,1.)
        else:
            attenuation=np.ones(blocked.shape)
        next_field=np.empty_like(field)
        for k in range(3):
            field_k=field[k]
            flow=flux_laplacian(field_k,blocked,effective_diff)
            # weak bounded synthetic absorption and optical shadowing
            absorb=np.maximum(0.,1.-c.dt*(sp.absorption*(1+.5*concentration)))
            next_field[k]=np.clip((field_k+c.dt*flow)*absorb*attenuation,0,1)
            next_field[k][blocked]=0.
        field=next_field
        candidates=monochrome_candidates(field,blocked)
        streak=np.where(candidates&(~old_candidates),np.minimum(streak.astype(np.int32)+1,65535),0).astype(np.uint16)
        new_ones=(streak>=5)&(~emerged)
        if np.any(new_ones) and first_mono is None:first_mono=t
        emerged |= new_ones
        observations=observe_field(field,nodes,sp.rgb_gain)
        for neuron,obs in zip(neurons,observations):
            fire+=neuron.step(obs,c.dt)['count']
        total,ent,_=entropy_ratio(field)
        valid=(total>.045)&(~blocked)
        trace.append({'step':t,'sim_s':round((t+1)*c.dt,4),
                      'active_cells':int(valid.sum()),
                      'monochrome_present':int(candidates.sum()),
                      'monochrome_new_persistent':int(emerged.sum()),
                      'mean_entropy':float(ent[valid].mean()) if np.any(valid) else None,
                      'mean_density':float(concentration[~blocked].mean()),
                      'neuron_events_cumulative':fire,
                      'total_intensity':float(field.sum())})
        if record_frames and t in (0,c.steps//3,2*c.steps//3,c.steps-1):
            snapshots[t]=field.copy()
        if not np.all(np.isfinite(field)) or np.min(field)<-1e-10:
            raise ArithmeticError('Nonfinite or negative field; abort')
    active=trace[-1]['active_cells']
    metrics={'species':sp.name,'color':sp.color,'marker':sp.marker(),
             **dataclasses.asdict(c), 'classification':SOURCE,
             'events':fire,'monochrome_persistent_cells':int(emerged.sum()),
             'monochrome_first_step':first_mono,
             'spectral_entropy_final':trace[-1]['mean_entropy'],
             'active_cells_final':active,
             'final_intensity':trace[-1]['total_intensity'],
             'initial_intensity':initial_intensity,
             'intensity_retained':trace[-1]['total_intensity']/initial_intensity}
    return {'metrics':metrics,'trace':trace,'frames':snapshots,'obstacle':blocked,'density':density}


def factorial(steps=75,n=40,seeds=(41,43),dim=2):
    """4 color-species x 2^3 ablations x seeds = 64 seeded synthetic studies."""
    output=[]
    for sp in SPECIES:
        for seed in seeds:
            for diff in (False,True):
                for occ in (False,True):
                    for dense in (False,True):
                        c=Conditions(n=n,steps=steps,seed=seed,diffusion=diff,occlusion=occ,density=dense,dim=dim)
                        output.append(run_one(sp,c)['metrics'])
    return output


def write_results(rows, outdir):
    outdir=Path(outdir);outdir.mkdir(parents=True,exist_ok=True)
    with (outdir/'factorial.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    (outdir/'factorial.json').write_text(json.dumps(rows,indent=2,allow_nan=False)+'\n')
    summary={}
    for s in SPECIES:
        items=[r for r in rows if r['species']==s.name]
        summary[s.name]={'trials':len(items),'mean_events':float(np.mean([x['events'] for x in items])),
                          'mean_retention':float(np.mean([x['intensity_retained'] for x in items])),
                          'mean_persistent_monochrome':float(np.mean([x['monochrome_persistent_cells'] for x in items]))}
    (outdir/'summary.json').write_text(json.dumps({'classification':'simulated','species':summary,'trials':len(rows)},indent=2)+'\n')
    return summary


def ingest_fieldsphere(path):
    """Read-only validation bridge: exact 8x3 data, provenance maintained.
    Magnetic µT stays magnetic µT. Never silently transduce to optical RGB.
    Hardware-reported rows are not independently verified measurements.
    """
    records=[]
    last=-float('inf')
    for line_no,line in enumerate(Path(path).read_text().splitlines(),1):
        if not line.strip():continue
        obj=json.loads(line)
        kind=obj.get('kind')
        if kind not in ('simulated','hardware'):raise ValueError('Unknown acquisition kind')
        v=np.asarray(obj.get('mag_uT'),dtype=float)
        if v.shape!=(8,3) or not np.all(np.isfinite(v)):
            raise ValueError('Invalid magnetic vectors on line '+str(line_no))
        ts=obj.get('t_ms')
        if not isinstance(ts,(int,float)) or not math.isfinite(ts) or ts<=last:
            raise ValueError('Nonmonotonic timestamp on line '+str(line_no))
        last=ts
        records.append((kind, v))
    if not records:raise ValueError('No measurements')
    labels=set(k for k,v in records)
    if len(labels)!=1:raise ValueError('Reject mixture of hardware and synthetic records')
    stack=np.stack([v for _,v in records])
    return {'status':'simulation' if labels=={'simulated'} else 'hardware_reported_unverified',
            'frames':len(records),'unit':'microtesla',
            'per_sensor_mean_magnitude_uT':np.linalg.norm(stack,axis=2).mean(axis=0).tolist(),
            'source_sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest(),
            'note':'No orientation, hard/soft-iron, or zero-field calibration inferred. Not a 3D interior reconstruction.'}


def verify_archive():
    p=ROOT/'frozen'/'ripple_v03_reference.js'
    return {'reference_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
            'frozen_v03_sha256':hashlib.sha256((ROOT/'frozen'/'Ripple-Mycelium-Mathematics-Lab-v0.3.html').read_bytes()).hexdigest(),
            'frozen_v05_sha256':hashlib.sha256((ROOT/'frozen'/'Ripple-Digital-World-Lab-v0.5.html').read_bytes()).hexdigest()}
