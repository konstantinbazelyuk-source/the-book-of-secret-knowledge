"""Bounded, auditable, optional Alpha overlay tuning. NOT autonomous biology/intelligence.
Does not alter original Ripple genome scheme; defines separate ripple-alpha-overlay/1.
"""
from __future__ import annotations
import dataclasses,hashlib,json
from pathlib import Path
import numpy as np
from ripple_alpha import SPECIES,Species,Conditions,run_one,ROOT

ALLOWED={'diffusion_gain':(.04,.28),'occlusion_gain':(.35,1.6),'absorption':(.006,.06)}


def marker(record):
    return hashlib.sha256(json.dumps(record,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def mutate(base:Species, rng):
    field=list(ALLOWED)[int(rng.integers(0,len(ALLOWED)))]
    low,high=ALLOWED[field]
    delta=float(rng.choice([-1,1]))*(high-low)*.16
    new=float(np.clip(getattr(base,field)+delta,low,high))
    return dataclasses.replace(base,**{field:new}),field


def score(sp:Species,seeds=(11,17),steps=50,n=28):
    parts=[]
    for seed in seeds:
        metrics=run_one(sp,Conditions(n=n,steps=steps,seed=seed,diffusion=True,occlusion=True,density=True))['metrics']
        entropy=metrics['spectral_entropy_final'] or 0
        coverage=metrics['active_cells_final']/(n*n)
        # Experimenter-selected utility, not an intelligence score or universal optimum.
        value=.5*coverage+.4*entropy+.1*metrics['intensity_retained']
        parts.append(float(value))
    return float(np.mean(parts))


def lineage(sp=SPECIES[0],generations=3,candidates=6,seed=211):
    if generations<1 or generations>20 or candidates<1 or candidates>32:
        raise ValueError('Finite tuning budget violated')
    rng=np.random.default_rng(seed)
    current=sp
    records=[]
    starting=score(current)
    head=marker({'schema':'ripple-alpha-overlay/1','origin':current.marker(),'parent':None})
    records.append({'generation':0,'parent':None,'marker':head,'species':dataclasses.asdict(current),
                    'train_score':starting,'accepted':True,'mutation':'none'})
    for g in range(1,generations+1):
        variants=[]
        for ix in range(candidates):
            candidate,field=mutate(current,rng)
            val=score(candidate)
            variants.append((val,ix,candidate,field))
        best=max(variants,key=lambda x:(x[0],-x[1]))
        accepted=best[0]>score(current)+1e-12
        chosen=best[2] if accepted else current
        body={'schema':'ripple-alpha-overlay/1','generation':g,'parent':head,
              'species':dataclasses.asdict(chosen),'mutated_field':best[3] if accepted else 'none'}
        new_head=marker(body)
        records.append({'generation':g,'parent':head,'marker':new_head,'species':dataclasses.asdict(chosen),
                        'train_score':score(chosen),'accepted':accepted,'mutation':best[3] if accepted else 'none',
                        'candidates_evaluated':candidates})
        head=new_head;current=chosen
    return {'schema':'ripple-alpha-overlay-lineage/1','classification':'finite_seeded_optimization',
            'objective':'0.5 active_cell_fraction + 0.4 mean_local_spectral_entropy + 0.1 intensity_retained',
            'train_seeds':[11,17],'holdout_seeds':[41,43],
            'holdout_original_score':score(sp,(41,43)),
            'holdout_selected_score':score(current,(41,43)),
            'ledger':records,'final_head':head,
            'note':'Only overlay parameters mutated; no original Ripple neuron or v0.5 genomes were modified.'}


def main():
    output=[]
    for i,sp in enumerate(SPECIES):
        output.append(lineage(sp,generations=3,candidates=6,seed=211+i))
    d=ROOT/'results';d.mkdir(exist_ok=True)
    (d/'lineage.json').write_text(json.dumps(output,indent=2)+'\n')
    for r in output:
        print(r['ledger'][0]['species']['name'], 'train',r['ledger'][0]['train_score'],'→',r['ledger'][-1]['train_score'],
              'holdout',r['holdout_original_score'],'→',r['holdout_selected_score'])

if __name__=='__main__':main()
