"""Runs a complete, documented Alpha experiment without network or hardware commands."""
import argparse,json,sys
from pathlib import Path
from ripple_alpha import *


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--output',default=str(ROOT/'results'))
    p.add_argument('--grid',type=int,default=40)
    p.add_argument('--steps',type=int,default=75)
    p.add_argument('--dim',type=int,default=2,choices=(2,3))
    p.add_argument('--fieldsphere',default=str(ROOT/'examples'/'fieldsphere_synthetic_coil.jsonl'))
    args=p.parse_args()
    output=Path(args.output).resolve()
    rows=factorial(n=args.grid,steps=args.steps,dim=args.dim)
    summary=write_results(rows,output)
    bridge=ingest_fieldsphere(args.fieldsphere)
    (output/'fieldsphere_input_summary.json').write_text(json.dumps(bridge,indent=2)+'\n')
    (output/'SOURCE_HASHES.json').write_text(json.dumps(verify_archive(),indent=2)+'\n')
    print(json.dumps({'classification':'SIMULATED Alpha experiments',
                      'trials':len(rows),'summary':summary,
                      'fieldsphere_status':bridge['status'],'folder':str(output)},indent=2))

if __name__=='__main__':main()
