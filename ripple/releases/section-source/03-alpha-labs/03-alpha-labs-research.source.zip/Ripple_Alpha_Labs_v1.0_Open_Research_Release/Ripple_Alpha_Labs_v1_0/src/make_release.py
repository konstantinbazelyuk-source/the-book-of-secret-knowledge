"""Make a reproducible integrity/source ledger and a deterministic public-use ZIP."""
from pathlib import Path
import hashlib,json,zipfile
from ripple_alpha import ROOT,SPECIES,run_one,Conditions,verify_archive
import numpy as np

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
 sources=[]
 for p in sorted((ROOT/'frozen').rglob('*')):
  if p.is_file():sources.append({'path':p.relative_to(ROOT).as_posix(), 'bytes':p.stat().st_size,'sha256':sha(p)})
 (ROOT/'docs'/'FROZEN_SOURCE_MANIFEST.json').write_text(json.dumps({'classification':'archived_references','count':len(sources),'files':sources},indent=2)+'\n')
 sums={'canonical_neuron_sha256':sha(ROOT/'frozen'/'ripple_v03_reference.js'),
       'archived_sources':len(sources),'approved_reference_expected':'d75d4208e92f19623b127615bd52b4002e85d2c0a59b76471764b55a24294210',
       'full_factorial_2d_trials':len(json.loads((ROOT/'results'/'factorial.json').read_text())),
       'full_factorial_3d_trials':len(json.loads((ROOT/'results'/'3d'/'factorial.json').read_text())),
       'species':list(s.name for s in SPECIES),
       'lineage_count':len(json.loads((ROOT/'results'/'lineage.json').read_text())),
       'field_inputs':'simulated FieldSphere sample only',
       'hardware_testing':'NOT PERFORMED',
       'software_regression_checks':18,
       'browser_smoke':'1280px + 390px, 4 species x 3 stages passed',
       'claims_not_supported':['physical field capture','interior magnetometry reconstruction','biological genes','consciousness','general intelligence gain']}
 (ROOT/'docs'/'ALPHA_RELEASE_AUDIT.json').write_text(json.dumps(sums,indent=2)+'\n')
 if sums['canonical_neuron_sha256']!=sums['approved_reference_expected']:
  raise ValueError('Original source checksum regression')
 lines=[]
 for p in sorted(ROOT.rglob('*')):
  if p.is_file() and '__pycache__' not in str(p) and 'SHA256SUMS' not in p.name and not p.name.startswith('._'):
   lines.append(f'{sha(p)}  {p.relative_to(ROOT).as_posix()}')
 (ROOT/'SHA256SUMS.txt').write_text('\n'.join(lines)+'\n')
 out=ROOT.parent/'Ripple_Alpha_Labs_v1.0_Open_Research_Release.zip'
 with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as z:
  for p in sorted(ROOT.rglob('*')):
   if p.is_file() and '__pycache__' not in str(p):
    rel=p.relative_to(ROOT.parent).as_posix()
    z.write(p,rel)
 with zipfile.ZipFile(out) as z:
  errors=z.testzip()
  if errors:raise IOError('ZIP corruption: '+str(errors))
  print('Release file',out,'size',out.stat().st_size,'entries',len(z.namelist()))
 print(json.dumps(sums,indent=2))

if __name__=='__main__':main()
