// Independent runner: imports the reference extracted byte-for-byte from previous Ripple v0.3 lab.
'use strict';
const {RippleNeuron}=require('../frozen/ripple_v03_reference.js');
const steps=JSON.parse(require('fs').readFileSync(process.argv[2],'utf8'));
let n=new RippleNeuron();let outs=steps.map(([rgb,dt])=>n.step(rgb,dt));
process.stdout.write(JSON.stringify(outs));
