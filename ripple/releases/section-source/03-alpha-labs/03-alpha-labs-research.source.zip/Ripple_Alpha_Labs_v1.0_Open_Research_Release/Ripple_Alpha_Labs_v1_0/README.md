# Ripple Alpha Research Labs v1.0

**Public-use research software | concept: Constantin x | offline, reproducible, non-physical simulation**

This is an **Alpha-stage integrated research lab**, not a claim of a physically verified instrument or artificial intelligence. It combines *archived* approved Ripple sources, a separate new spatial environment model, 8 instances of an unchanged-mathematics Ripple neuron, color-coded digital *species* configurations, independent FieldSphere dataset ingestion, finite optimization of **overlay** parameters, and explicit source provenance. The original packages are immutable copies under `frozen/`.

## Start without installing anything

Open **`Ripple-Alpha-Lab.html`** in a web browser. This is a self-contained read-only dashboard of already-executed **synthetic** runs. Species and stages can be selected. It makes no network requests and does not control sensors or actuators.

## Run the actual Alpha algorithms

Requires Python 3.10+ and NumPy. Matplotlib is optional for regenerated figures. Node.js is used **only** by the independently checked original JS/Python parity test. No cloud API is needed.

```sh
python -m pip install numpy matplotlib
python src/cli.py --output results --grid 40 --steps 75 --dim 2
python src/cli.py --output results/3d --grid 16 --steps 26 --dim 3
python src/evolution.py
python src/plot_results.py
python src/make_dashboard.py
python -m unittest discover -s tests -v
```

The CLI runs a 64-condition study: 4 color-coded variants × 2 seeds × 2 diffusion states × 2 occlusion states × 2 density states. The two commands create **64 2D trials plus 64 3D trials**. Everything saved to `results/` is explicitly tagged simulated. `src/evolution.py` separately makes a bounded three-generation, six-candidate-per-generation overlay-parameter search on **training seeds 11/17**, then independently reports scores on **holdout seeds 41/43**. It never modifies original neuron parameters or v0.5 genetics.

## Preserved invariants

The actual archived reference `frozen/ripple_v03_reference.js` has SHA-256:

`d75d4208e92f19623b127615bd52b4002e85d2c0a59b76471764b55a24294210`

This file was extracted *byte-for-byte* from the actual user's `Ripple-Digital-Evolution-v0.5.zip` archive. Its comments state it preserves the original v0.1 simulation except the module export and source header. The additional Python class `LegacyRippleNeuron` implements exactly these *existing* laws:

- `D = 2 R + 1.2 G - 1.4 B`, each channel limited to [0,1].
- `tauV = 0.5s`, `tauR = 5s`, `refractory = 0.1s`.
- Initial threshold `0.45`, threshold limits `[0.15, 2.50]`, adaptation gain `0.08`, target `1 event/s`.
- Event/reset and analytic integration timing as implemented in the frozen original.

The automated regression includes direct comparison with Node.js executing the frozen real JavaScript class for **400 seeded varied-input steps**. No changes were made to the original archive files.

## What a gene species means

Four **digital configuration templates** called `prism`, `canopy`, `ember`, `violet` control *external simulated* channel gain, diffusion coefficient, occlusion sensitivity and absorption. Hex colors are visualization identifiers. A marker is SHA-256 of the canonical parameter record and therefore useful for integrity/lineage tracking. It is **not** real DNA, biological mutation, or a cryptographic signature of authority.

A **monochrome emergence candidate** is a numerical field-state condition with normalized three-channel Shannon entropy < 0.40, dominant share > 0.87 and total intensity > 0.045, not obstructed and not already monochrome at initial time. It must satisfy the definition for **5 consecutive numerical frames** before it is logged. The term “gene emergence” is shorthand for *a modelled state*, not a change in genotype; genome mutation is recorded separately by `src/evolution.py`.

## Physics and software classification

- **Measured:** no new field measurements. Internal runtime test success is measured software behavior; optical/magnetic source data in the included FieldSphere sample are **simulated**, not physically captured.
- **Simulated:** three-channel scalar fields and their transport, obstacles, synthetic density proxy, optical shadow masks, firing rates, selection paths, 2D/3D virtual grids.
- **Calculated:** Shannon entropy, SHA-256 digests, finite-volume transport flux, test statistics, comparator scores, and field-provenance summaries.
- **Proposed:** future live acquisition, magnetic-vector orientation calibration, optical channel calibration, and physically verified spatial reconstruction.

Magnetic µT readings are **not** converted into RGB light intensity. The FieldSphere bridge is a read-only provenance-preserving parallel input, not a purported opto-magnetic law or aura detector. Eight magnetometers around a sphere do not uniquely determine the entire unknown field inside it without physical priors and calibration.

## Engineering boundaries

Finite size/step/time and explicit diffusion stability guards; validate numeric sensor shape/finite timestamps; reject mixed synthetic/hardware logs; no network, command execution, device control or autonomous mutation beyond fixed budgets; observe-only signals; all output files produced under the CLI-specified directory.

## Contents

- `Ripple-Alpha-Lab.html`: self-contained, interactive, offline Alpha results viewer.
- `src/ripple_alpha.py`: tested field dynamics, experimental guardrails, neuron Python adapter, FieldSphere input validation.
- `src/evolution.py`: finite, seeded hyperparameter/overlay experiment and lineage checksums.
- `src/cli.py`, `src/plot_results.py`, `src/make_dashboard.py`: reproduction scripts.
- `tests/test_alpha.py`: real code-execution regressions and adversarial input tests.
- `results/`: genuine output files from simulation runs, the 2D/3D trial datasets, plots and lineage ledger.
- `frozen/`: archived previous sources and unchanged selected project ZIPs (including CAD/manufacturing files where included).
- `docs/EXPERIMENT_PROTOCOL.md`, `docs/RESEARCH_SOURCES.md`, `docs/INTEGRATION_LEDGER.md`, `docs/GUARDRAILS.md`, `docs/NEGATIVE_RESULTS.md`: validation and scope details.

## License and attribution

New Alpha code and documentation: MIT license, see `LICENSE`. Earlier source archives keep their own original terms; nothing here relicenses them. The original Ripple-Neuron project was distributed as CC0-1.0. Concept attribution: Constantin x; added Alpha lab is a derivative research implementation.
