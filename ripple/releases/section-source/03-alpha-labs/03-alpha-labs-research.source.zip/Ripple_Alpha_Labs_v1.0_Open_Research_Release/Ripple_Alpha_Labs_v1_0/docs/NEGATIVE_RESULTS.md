# Negative results and limits (recorded without spin)

- **No real physical sensor was attached** in this Alpha. The magnetic JSONL is a previous *synthetic* coil-reversal recording. The bridge checks provenance and computes magnitudes only; cannot infer a field at arbitrary 3D points.
- **Visible-light magnetic oscillation is not directly measured.** A LIS2MDL observes much slower magnetic fields. Optical heterodyne requires a physically aligned and validated interferometer, absent here.
- **No consciousness, aura, new intelligence or biological mutation** was measured. “Gene”, “monochrome” and “species” are artificial mathematical labels.
- **A colored field image cannot validate density, diffraction, optical coherence, reflectance or phase.** The Alpha densities are dimensionless synthetic occupancy/resource numbers. Transport/occlusion terms are a controlled heuristic, not a Maxwell solver.
- **Higher optimization score is not intelligence gain.** Current utility rewards active grid coverage/entropy/retention; decreasing decay naturally improves score. This is a chosen research preference and may not transfer to real hardware or other tasks. No large-sample statistical conclusion is justified by two seeds.
- **The v0.5 scheduler does not operate the Alpha neurons as a distributed worker pool.** It is archived as a separate baseline. The Alpha actively instantiates eight standalone baseline neurons per virtual trial; service/routing integration requires further unit testing and a named performance objective.
- **3D is a voxel numerical study, not reconstructed tomography.** The 3D grid is populated by known synthetic sources and obstacles, not inferred from FieldSphere's eight surface readings.
