# Source and outsourcing ledger: research methods actually used

The Alpha implementation was written and executed locally; no external AI (Grok, Meta, Google) ran any trials in this release. Public algorithms were studied as method references, **not copied wholesale** into the preserved core.

1. **Original Ripple archived project**: local `frozen/archives/Ripple-Neuron-GitHub-Repository-All-Versions.zip`, original source baseline; preserved without live app edits.
2. **Ripple Cybernetic Mycelium v0.3**, `frozen/archives/Ripple-Cybernetic-Mycelium-v0.3.zip`: source of original core and feedback comparison; preserved.
3. **Ripple Digital Evolution v0.5**, `frozen/archives/Ripple-Digital-Evolution-v0.5.zip`: original v0.5 source, digital genome marker and controlled optimizer, isolated from new overlay variants. Exactly hashed canonical JS reference `frozen/ripple_v03_reference.js`.
4. **Ripple Quaternary v0.7**, `frozen/archives/Ripple-Neuron-Quaternary-v0.7.zip`: four-symbol quantizer, safe VM, sampling constraints; archived, not rewritten or merged without regression gate.
5. **Ripple Sensor Bridge v0.2**, `frozen/archives/Ripple_Sensor_Bridge_v0_2.zip`: provenance/reference sensor adapter; archived, no claimed direct hardware integration.
6. **Ripple FieldSphere v0.1** (included original ZIP): `frozen/archives/Ripple_FieldSphere_v0.1_Open_Source_Manufacturing.zip`; field data schema source and mechanical CAD, originally simulated only.
7. **Ripple Spectrum v0.1** (included original ZIP): `frozen/archives/Ripple_Spectrum_v0.1_Prototype.zip`; optical modulation/magnetic frequency studies, no detector coupled here.
8. **Ripple Heterodyne v0.1** (included original ZIP): `frozen/archives/Ripple_Heterodyne_v0.1_CAD_Manufacturing_Prototype.zip`; optical bench CAD, no hardware signal observed here.
9. **John E. Pearson (1993), _Complex Patterns in a Simple System_**: reaction–diffusion pattern emergence, arXiv https://arxiv.org/abs/patt-sol/9304003. Inspiration for controlled pattern studies. The Alpha does **not** implement the Gray–Scott chemical reaction equations, only conservative scalar transport and bounded decay.
10. **Gray–Scott literature**, model `dU/dt=D_u∇²U−UV²+F(1−U)`, `dV/dt=D_v∇²V+UV²−(F+k)V`: https://link.springer.com/article/10.1007/s11071-026-12479-8. Kept as a **proposed** future physics/model-comparison branch, rather than falsely claiming it was implemented.
11. **SciPy image processing method reference** for existing well-tested interpolation/convolution implementations: https://docs.scipy.org/doc/scipy/reference/generated/scipy.ndimage.gaussian_filter.html. The Alpha implements its own small finite-volume transport; does not require SciPy.

External citations must not be used to assert real physical Alpha sensor measurements. All deliverables are locally executable and have their own tests.
