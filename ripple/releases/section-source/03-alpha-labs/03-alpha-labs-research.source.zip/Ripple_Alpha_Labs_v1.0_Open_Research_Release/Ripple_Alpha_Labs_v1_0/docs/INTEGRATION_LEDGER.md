# Ripple family continuity and Alpha integration ledger

The aim is to preserve existing work, add an **Alpha study** in a separate area, and allow later staged integration only after measured validation.

| Source or mechanism | Bucket | Implementation status | Allowed interpretation |
|---|---|---|---|
| Original v0.1 LIF RGB neuron, JS source recovered from v0.5 | LOCKED | Original byte-identical to archive; Python port cross-language regression | Actual executed math, not a physical neuron |
| Archived Mycelium v0.3 and Digital Evolution v0.5 | LOCKED | Frozen original sources and complete zipped archives; not republished as new | Provenance/reference for scheduler, genetic configs |
| Quaternary v0.7 | LOCKED | Source archive included; no quaternary VM wired into Alpha | Proven research branch, integration deferred |
| Sensor Bridge v0.2 | LOCKED | Original archive preserved | Optional future adapter; no sensor online |
| FieldSphere v0.1 | LOCKED | Original CAD+source ZIP preserved; synthetic JSONL read via strict adapter | Sample fields at probes, not interior tomography |
| Spectrum and Heterodyne v0.1 | LOCKED | Both original packages preserved, including CAD | Reference engineering sources only |
| Alpha three-channel field diffusion | CURRENT | Executable, conservative numeric transport | Synthetic scalar transport, not optical Maxwell wave |
| Alpha occlusion baffle | CURRENT | Executable bounded shadow proxy | Scenario parameter, not fully ray-traced geometry |
| Alpha density | CURRENT | Normalized synthetic concentration/occupancy proxy | NOT mass or photon density |
| Four color-coded digital overlays | CURRENT | Immutable parameter records with SHA markers | Digital species labels only |
| Monochrome persistent-state detector | CURRENT | Quantified normalized entropy + dominance + persistence | Phenomenological state, no mutation |
| Bounded overlay mutation/selection | CURRENT | Finite six-candidate, three-generation search; train/holdout | Explicit optimization objective, not autonomous intelligence |
| Calibrated optical phase interferometry | OPTIONAL / FUTURE | CAD/reference only | Needs a real laser/photodiode and bench validation |
| Calibrated magnetometry in a complete FieldSphere | OPTIONAL / FUTURE | No instrument assembled, no test current measured | Needs sensor orientation, offsets, uncertainty, geometry |
| Adaptive colony routing v0.5 live integration | OPTIONAL / FUTURE | Kept separate intentionally | Requires A/B worker studies, must preserve original |
| Claims of biological DNA, aura, consciousness, quantum computation | OUTSIDE CLAIM SCOPE | No supporting experiment | Must not be promoted to verified measurements |

## Z → A / A → Z continuity checks

**Backtrack:** Before merging future versions, compare requested change against the canonical original neuron, earlier research results and negative results, and the known physical limitations. Never derive a claim solely from a new graph.

**Forward:** Run baseline JS parity, new unit tests, read-only dashboard browser checks, controlled factorial experiments, holdout evaluation and source manifest audit. Compare first with the locked control, then with the altered variant. No live code or hardware controls are edited by this archive release.

## Dependency graph

`Locked source archives -> canonical neuron JS -> parity-verified Python observer -> synthetic RGB field labs -> 8 fixed neuron replicas -> staged metrics/plots`

`FieldSphere synthetic archive -> JSONL shape/provenance validation -> magnetic µT summary` (parallel; no RGB conversion).

`Digital overlay marker -> bounded parameter mutation -> audit ledger -> train-seed utility -> independent holdout utility`

Actual sensor integration requires additional calibrated input contracts and should not be reverse inferred from the number of software tests.
