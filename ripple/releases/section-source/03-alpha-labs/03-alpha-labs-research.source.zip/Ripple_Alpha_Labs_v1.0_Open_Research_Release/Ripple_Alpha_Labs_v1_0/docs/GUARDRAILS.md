# Guardrails and acceptance gates

1. Source preservation: v0.3/v0.5, original multi-version repo, v0.7, Sensor Bridge, and instrument archives are copied, never patched. `frozen/ripple_v03_reference.js` must hash to `d75d4208e92f19623b127615bd52b4002e85d2c0a59b76471764b55a24294210`.
2. Physical truth: every model observation has a classification. The included FieldSphere example is **simulated**. A `hardware` flag means only hardware-*reported* until an independent physical calibration report exists.
3. Strict sensor bounds: 8×3 finite magnetic vector shape in µT, unique source classification, strictly increasing time; no silently substituted zero vectors or reinterpretation as RGB.
4. Numeric bounds: 10–72 grid extent, 2D or 3D, 2–500 steps, 0<dt≤0.5 s, conservative explicit-flux diffusion guard, [0,1] field concentrations, reject NaNs/Infs.
5. Source-of-authority: approved original neuron equations, default parameters and v0.5 genomes remain unchanged. New `ripple-alpha-species/1` and `ripple-alpha-overlay/1` are **independent** typed records.
6. Reproducibility: common random seeds across variants and ablations; input archive hashes and outputs; train seeds 11/17 versus holdout 41/43, not chosen using holdout score.
7. Finite evolution budget: at most 20 generations and 32 candidates per generation; parameter bounds, explicit utility function, ancestry checksums. No authority to self-deploy, spend, contact external systems or promote results to ground truth.
8. Research language: synthetic spatial patterns are neither auras nor new species nor quantum coherence. Pure data transforms are not a demonstration of embodied intelligence.
9. Mechanical/optical: original CAD exists for the FieldSphere/Heterodyne; no physical build/laser operation or field calibration has been accomplished here.
10. Review gate: before new sensor-to-neuron transduction, real actuation, altered neuron equations, live website edits or public source publication, require separate evidence and project-specific scope.
