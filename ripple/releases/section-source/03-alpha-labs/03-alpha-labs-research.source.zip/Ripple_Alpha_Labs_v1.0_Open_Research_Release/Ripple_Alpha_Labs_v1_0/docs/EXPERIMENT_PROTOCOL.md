# Alpha research protocol (predefined and repeatable)

## Controlled question

For each fixed digital species, how do synthetic channel transport, a synthetic occluding baffle and a dimensionless density proxy change spatial intensity, original Ripple event counts and persistent *local* monochrome state counts? These are engineered interactions, not inferences about biology, consciousness or electromagnetic magnetic-field oscillations.

## Reproduction

- Matrix: 4 species × 2 seeds [41,43] × 2 diffusion states × 2 occlusion states × 2 density states = 64 runs in each dimension (2D: N=40, 75 steps; 3D: N=16, 26 steps).
- Single-stage comparison: 44x44 grid, seed=41, 100 steps at Δt=0.08 simulation seconds, for each species, `diffusion` → `diffusion + occlusion` → `diffusion + occlusion + density`.
- Common fixed 8 sensing locations per run, fed dimensionless three-channel **synthetic** concentration directly to **unchanged** original Ripple LIF mathematics. No magnets are treated as RGB inputs.
- Source hubs: three prescribed Gaussian scalar-channel distributions; central obstruction baffle; synthetically assigned density map, seeded per trial.
- Diffusive flux for neighboring open cells: `F_ij = (D_i+D_j)/2 * (C_j-C_i)`; boundaries and blocked cells have zero through-flux. Using each pair once ensures conservation of transported scalar when no local sinks are present. `D_i = D_species * (1-0.42*rho)` if density enabled.
- Decay: local factor `max(0, 1 - dt * absorption * (1 + rho/2))` where `rho=0` if density OFF.
- Occlusion: explicitly simplified per-step rectangular shadow factor `0.993**occlusion_gain` for locations behind the baffle, if enabled. **This is a synthetic attenuation heuristic**, not geometrical ray tracing, Maxwell-field propagation or a solution to radiative-transfer equations.
- Diffusion explicit numerical guard: `2 * dimension * D * dt <= 0.85`, chosen conservatively for the defined stencil. This guard is a software timestep check, not proof of general unconditional stability of coupled nonlinear models.
- Monochrome detector: `entropy = -Σ p_k ln(p_k) / ln(3)`, `p_k=channel_k/sum(channel)`; entropy <0.40 AND max(p)>0.87 AND intensity>0.045 AND no obstacle, with 5-step persistence; exclude points that qualified in the initial field.
- Firing events: count original Ripple-neuron events emitted when eight fixed node locations sample synthetic RGB values, no active routing or task scheduling.

## Measured versus modelled

The 400-step cross-language parity is a **software test**, not photometric calibration. FieldSphere sample is `kind: simulated`. `kind: hardware` is only *hardware-reported*, explicitly unverified. Without real sensor orientation matrices, noise estimation, independent calibration and geometric inverse constraints, do not perform global field reconstruction or claim a magnetic map in the 3D interior.

## Controlled research phases

1. Recover immutable original code, parity-test original firing dynamics.
2. Enable numerical diffusion alone, observe baseline spectrum and neuron event states.
3. Introduce synthetic occlusion while keeping seed, timing and species fixed.
4. Introduce synthetic density proxy in the same world.
5. Evaluate all 8 ablation combinations separately for confounding and interaction checks.
6. Run finite lineage overlay changes independently; objective and training/holdout split recorded.
7. Prepare **separate** real sensor collection and physical controls; do not retroactively relabel simulated data as hardware.

## Example stage result (one seed, 2D)

For `canopy`, 44x44, seed 41, 100 time steps: diffusion only = **61** persistently new monochrome locations; adding synthetic occlusion = **41**; also adding density proxy = **29**. This is **one simulation regime**. These numbers are not calibration data, biological gene activation, universal optimum or hardware measurements.

## Statistically valid next alpha steps

Introduce diverse holdout worlds, known-noise optical scenes, corrected 3D geometry mapping, uncertainty intervals and independently recorded sensor datasets. Do not infer physical electromagnetic emission or consciousness from color patterns.
