"""Browser validation with no local file:// access. Requires pip install playwright and chromium."""
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'Ripple-Alpha-Lab.html').read_text()
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for width in (1280,390):
  page=browser.new_page(viewport={'width':width,'height':800})
  errors=[]
  page.on('pageerror',lambda exc:errors.append(str(exc)))
  page.goto('about:blank')
  page.set_content(source,wait_until='load')
  assert page.title().startswith('Ripple Alpha Research Labs')
  assert int(page.locator('#events').inner_text())>=0
  for sp in ('prism','canopy','ember','violet'):
   page.select_option('#species',sp)
   for stage in ('Diffusion only','Diffusion + occlusion','Diffusion + occlusion + density'):
    page.select_option('#stage',stage)
    assert page.locator('#tag').inner_text().startswith('Species marker:')
    assert page.locator('#lineage').inner_text().startswith('{')
  assert not errors,errors
  print(f'{width}px: 4 species x 3 stages, result fields and lineage UI PASS')
  page.close()
 browser.close()
