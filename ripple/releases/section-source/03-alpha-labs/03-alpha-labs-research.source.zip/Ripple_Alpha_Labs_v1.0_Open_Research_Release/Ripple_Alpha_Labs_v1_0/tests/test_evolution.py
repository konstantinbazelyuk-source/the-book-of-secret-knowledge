import dataclasses,hashlib,json,sys,unittest
from pathlib import Path
R=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(R/'src'))
from evolution import SPECIES,ALLOWED,lineage,mutate,score,marker
import numpy as np

class TestLineage(unittest.TestCase):
 def test_mutation_does_not_alter_origin(self):
  origin=SPECIES[0]
  before=dataclasses.asdict(origin)
  nxt,key=mutate(origin,np.random.default_rng(11))
  self.assertEqual(before,dataclasses.asdict(origin))
  self.assertIn(key,ALLOWED)
  self.assertEqual(nxt.name,origin.name)
  self.assertGreaterEqual(getattr(nxt,key),ALLOWED[key][0])
  self.assertLessEqual(getattr(nxt,key),ALLOWED[key][1])

 def test_all_ledger_links(self):
  audit=lineage(SPECIES[0],generations=2,candidates=3,seed=7)
  ledger=audit['ledger']
  self.assertEqual(len(ledger),3)
  self.assertIsNone(ledger[0]['parent'])
  self.assertEqual(ledger[0]['marker'],marker({'schema':'ripple-alpha-overlay/1','origin':SPECIES[0].marker(),'parent':None}))
  for prev,entry in zip(ledger,ledger[1:]):
   self.assertEqual(entry['parent'],prev['marker'])
   expected=marker({'schema':'ripple-alpha-overlay/1','generation':entry['generation'],
                    'parent':entry['parent'],'species':entry['species'],'mutated_field':entry['mutation']})
   self.assertEqual(entry['marker'],expected)

 def test_budget_rejection(self):
  with self.assertRaises(ValueError):lineage(SPECIES[0],generations=21)
  with self.assertRaises(ValueError):lineage(SPECIES[0],generations=2,candidates=33)

if __name__=='__main__':unittest.main()
