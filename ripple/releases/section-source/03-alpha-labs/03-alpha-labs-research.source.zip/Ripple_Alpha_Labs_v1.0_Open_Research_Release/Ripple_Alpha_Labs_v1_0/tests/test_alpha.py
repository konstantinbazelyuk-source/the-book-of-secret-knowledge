import hashlib,json,math,os,subprocess,sys,unittest
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from ripple_alpha import *

class TestAlpha(unittest.TestCase):
    def test_frozen_unmodified(self):
        source=ROOT/'frozen'/'ripple_v03_reference.js'
        self.assertIn('D = ', 'D = ')
        self.assertIn('2*x[0]+1.2*x[1]-1.4*x[2]',source.read_text())
        self.assertIn('const bound=',source.read_text())
        self.assertGreater((ROOT/'frozen'/'Ripple-Digital-World-Lab-v0.5.html').stat().st_size,200_000)

    def test_default_dark_no_firing(self):
        n=LegacyRippleNeuron()
        self.assertEqual(sum(n.step([0,0,0],.08)['count'] for _ in range(500)),0)

    def test_legacy_limits(self):
        n=LegacyRippleNeuron()
        with self.assertRaises(ValueError):n.step([0,0],.1)
        with self.assertRaises(ValueError):n.step([float('nan'),0,1],.1)
        with self.assertRaises(ValueError):n.step([1,1,1],.51)
        with self.assertRaises(ValueError):n.step([0,0,0],0)

    def test_js_parity_400_steps(self):
        rng=np.random.default_rng(77)
        samples=[(rng.uniform(-.1,1.1,3).tolist(), float(rng.uniform(.025,.20))) for _ in range(400)]
        file=ROOT/'results'/'_parity_inputs.json';file.parent.mkdir(exist_ok=True)
        file.write_text(json.dumps(samples))
        r=subprocess.run(['node',str(ROOT/'src'/'parity_runner.cjs'),str(file)],capture_output=True,text=True,check=True)
        from_js=json.loads(r.stdout)
        n=LegacyRippleNeuron()
        for sample, actual in zip(samples,from_js):
            got=n.step(*sample)
            for key in ('t','u','theta','rate','drive'):
                self.assertAlmostEqual(got[key],actual[key],delta=2e-9,msg=key)
            self.assertEqual(got['count'],actual['count'])
            self.assertEqual(len(got['events']),len(actual['events']))

    def test_diffusion_conserves_without_sources(self):
        a=np.zeros((15,15));a[7,7]=1
        blocked=np.zeros_like(a,dtype=bool);blocked[8,:]=True
        flux=flux_laplacian(a,blocked,np.full_like(a,.2))
        self.assertAlmostEqual(flux.sum(),0,places=12)
        self.assertEqual(flux[9:, :].sum(),0)

    def test_guardrails(self):
        with self.assertRaises(ValueError):check_conditions(Conditions(n=800),.2)
        with self.assertRaises(ValueError):check_conditions(Conditions(dt=9),.2)
        with self.assertRaises(ValueError):check_conditions(Conditions(dim=3,dt=.5),3.)

    def test_species_signatures_stable_distinct(self):
        marks=[s.marker() for s in SPECIES]
        self.assertEqual(len(set(marks)),len(SPECIES))
        self.assertTrue(all(len(m)==64 for m in marks))
        with self.assertRaises(dataclasses.FrozenInstanceError):SPECIES[0].name='hacked'

    def test_density_diffusion_ablation(self):
        baseline=run_one(SPECIES[0],Conditions(n=20,steps=15,seed=1,density=False))['metrics']
        changed=run_one(SPECIES[0],Conditions(n=20,steps=15,seed=1,density=True))['metrics']
        self.assertNotEqual(baseline['final_intensity'],changed['final_intensity'])

    def test_occlusion_ablation(self):
        settings=Conditions(n=20,steps=15,seed=1,occlusion=False)
        a=run_one(SPECIES[0],settings)['metrics']['final_intensity']
        b=run_one(SPECIES[0],dataclasses.replace(settings,occlusion=True))['metrics']['final_intensity']
        self.assertLess(b,a)

    def test_diffusion_ablation(self):
        c=Conditions(n=20,steps=20,seed=2,diffusion=False)
        a=run_one(SPECIES[0],c)['metrics']['active_cells_final']
        b=run_one(SPECIES[0],dataclasses.replace(c,diffusion=True))['metrics']['active_cells_final']
        self.assertTrue(isinstance(a,int) and isinstance(b,int))
        self.assertNotEqual(run_one(SPECIES[0],c)['metrics']['final_intensity'],run_one(SPECIES[0],dataclasses.replace(c,diffusion=True))['metrics']['final_intensity'])

    def test_3d_run(self):
        r=run_one(SPECIES[1],Conditions(dim=3,n=12,steps=9,seed=1))
        self.assertEqual(len(r['trace']),9)
        self.assertEqual(r['frames'],{})
        self.assertEqual(r['metrics']['classification'],'synthetic_grid')

    def test_reproducible(self):
        c=Conditions(n=15,steps=15,seed=8)
        self.assertEqual(run_one(SPECIES[2],c)['metrics'],run_one(SPECIES[2],c)['metrics'])

    def test_monochrome_definition(self):
        f=np.zeros((3,5,5));f[1,:,:]=1.
        self.assertTrue(np.all(monochrome_candidates(f,np.zeros((5,5),dtype=bool))))
        for k in range(3):f[k,:,:]=1.
        self.assertFalse(np.any(monochrome_candidates(f,np.zeros((5,5),dtype=bool))))

    def test_hardware_rejected_as_synthetic_mixed(self):
        path=ROOT/'examples'/'fieldsphere_synthetic_coil.jsonl'
        o=ingest_fieldsphere(path)
        self.assertEqual(o['status'],'simulation')
        self.assertEqual(o['unit'],'microtesla')
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'mix.jsonl'
            first=json.loads(path.read_text().splitlines()[0]);last=dict(first);last.update(kind='hardware',t_ms=first['t_ms']+1000)
            p.write_text(json.dumps(first)+'\n'+json.dumps(last)+'\n')
            with self.assertRaises(ValueError):ingest_fieldsphere(p)

    def test_no_field_tomography(self):
        data=ingest_fieldsphere(ROOT/'examples'/'fieldsphere_synthetic_coil.jsonl')
        self.assertNotIn('interior_field',data)
        self.assertEqual(len(data['per_sensor_mean_magnitude_uT']),8)

if __name__=='__main__':unittest.main()
