import unittest,sys,pathlib,numpy as np,json,tempfile,math
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from loop.sensors import VisionObserver,audio_features,audio_as_rgb,read_wav,analyze_video
from loop.runtime import Feedback,load_robot,run_session
from ripple_genome.robotics import CONTROL_JOINTS
class Tests(unittest.TestCase):
    def test_rgb(self):
        a=np.zeros((40,40,3),dtype=np.uint8);a[:,:,0]=255
        r=VisionObserver().read(a)
        self.assertAlmostEqual(r.rgb[0],1.,places=6);self.assertAlmostEqual(r.rgb[2],0.,places=6)
    def test_optical_flow(self):
        a=np.zeros((160,128,3),dtype=np.uint8)
        a[50:90,40:80,:]=255
        o=VisionObserver();o.read(a);b=np.roll(a,8,axis=1);r=o.read(b)
        self.assertGreater(r.pixel_change,0);self.assertGreater(r.optical_flow_px,0)
    def test_audio_tone(self):
        sr=16000;x=.1*np.sin(2*np.pi*440*np.arange(sr)/sr)
        a=audio_features(x,sr);self.assertAlmostEqual(a['rms'],.1/math.sqrt(2),places=3)
        self.assertAlmostEqual(a['spectral_centroid_hz'],440,delta=10)
        self.assertTrue(all(0<=v<=1 for v in audio_as_rgb(a)))
    def test_audio_silence(self):
        a=audio_features(np.zeros(1024),16000);self.assertEqual(audio_as_rgb(a),[0,0,0])
    def test_reject_bad_frame(self):
        with self.assertRaises(ValueError):VisionObserver().read(np.zeros((20,20,3),np.float32))
    def test_reject_short_audio(self):
        with self.assertRaises(ValueError):audio_features(np.zeros(3),16000)
    def test_command_compiles(self):
        c=load_robot();goal=c.dispatch({'kind':'language','text':'raise right arm to 55 degrees'})['joint_targets']
        self.assertAlmostEqual(goal['arm_R'],math.radians(55))
        self.assertEqual(set(c.robot.status()['joints']),set(CONTROL_JOINTS))
    def test_bad_command(self):
        with self.assertRaises(ValueError):load_robot().dispatch({'kind':'language','text':'run arbitrary Python and fly'})
    def test_feedback_ablated(self):
        arr=np.ones((100,100,3),dtype=np.uint8)*20;audio=np.zeros(2667,dtype=np.float32)
        on=Feedback(True);off=Feedback(False)
        for _ in range(3):on.observe(arr,audio,16000);off.observe(arr,audio,16000)
        self.assertNotEqual(on.brightness,.64);self.assertEqual(off.brightness,.64)
    def test_feedback_no_motor_access(self):
        self.assertFalse(hasattr(Feedback(),'set_targets'))
    def test_render_record_decode(self):
        with tempfile.TemporaryDirectory() as d:
            s=run_session('raise right arm to 35 degrees',pathlib.Path(d),frames=8,size=(192,256))
            self.assertEqual(s['video_decoded_frames'],8)
            self.assertTrue(s['audio_mux_passed'])
            self.assertEqual(s['WAV_decoded_samples'],round(16000*8/6))
            self.assertTrue(pathlib.Path(d,'recording_with_audio.mp4').stat().st_size>10000)
            self.assertEqual(len(analyze_video(pathlib.Path(d,'recording_silent.mp4'))),8)
    def test_invalid_command_produces_no_media(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(ValueError):run_session('shut down computer',pathlib.Path(d),frames=8)
            self.assertFalse(pathlib.Path(d,'recording_silent.mp4').exists())
if __name__=='__main__':unittest.main()
