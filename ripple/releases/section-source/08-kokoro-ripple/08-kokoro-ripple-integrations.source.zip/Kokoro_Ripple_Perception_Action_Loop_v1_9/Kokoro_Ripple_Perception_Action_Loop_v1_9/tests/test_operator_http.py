import unittest,pathlib,sys,subprocess,time,socket,json,urllib.request,urllib.error
ROOT=pathlib.Path(__file__).resolve().parents[1]
class Operator(unittest.TestCase):
    def test_actual_http_and_media(self):
        s=socket.socket();s.bind(('127.0.0.1',0));port=s.getsockname()[1];s.close()
        proc=subprocess.Popen([sys.executable,str(ROOT/'tools/operator_server.py'),'--port',str(port)],cwd=ROOT,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        base=f'http://127.0.0.1:{port}'
        def get(path):return urllib.request.urlopen(base+path,timeout=12)
        def post(data,headers=None):
            h={'Content-Type':'application/json'};h.update(headers or {})
            return urllib.request.urlopen(urllib.request.Request(base+'/api/start',json.dumps(data).encode(),headers=h,method='POST'),timeout=8)
        try:
            for _ in range(70):
                try:
                    if get('/').status==200:break
                except Exception:time.sleep(.1)
            else:self.fail('service did not launch')
            with self.assertRaises(urllib.error.HTTPError) as e:post({'instruction':'run bash','frames':8})
            self.assertEqual(e.exception.code,422)
            with self.assertRaises(urllib.error.HTTPError) as e:post({'instruction':'reset pose','frames':8},{'Origin':'https://untrusted.example'})
            self.assertEqual(e.exception.code,403)
            self.assertEqual(post({'instruction':'raise right arm to 35 degrees','frames':8}).status,202)
            for _ in range(90):
                state=json.load(get('/api/status'))
                if state['status']!='running':break
                time.sleep(.1)
            self.assertEqual(state['status'],'complete',state)
            self.assertEqual(len(json.load(get('/timeline.json'))),8)
            self.assertGreater(len(get('/recording.mp4').read()),10000)
            self.assertGreater(len(get('/rgb.png').read()),100)
            self.assertTrue(state['summary']['audio_mux_passed'])
        finally:
            proc.terminate()
            try:proc.wait(timeout=5)
            except subprocess.TimeoutExpired:proc.kill()
