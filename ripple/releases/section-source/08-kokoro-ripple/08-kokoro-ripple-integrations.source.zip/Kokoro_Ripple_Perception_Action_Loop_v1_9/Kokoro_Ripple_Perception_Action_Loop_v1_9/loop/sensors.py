"""Quantities extracted from actual raster pixels and audio samples.

No semantic vision, speech recognition, or biological sensing is asserted.
Measurements are display-referred 8-bit RGB, not calibrated irradiance.
"""
from __future__ import annotations
import math, wave
import cv2
import numpy as np
from dataclasses import dataclass
from pathlib import Path


def check_frame(frame):
    if not isinstance(frame,np.ndarray) or frame.dtype != np.uint8 or frame.ndim != 3 or frame.shape[2] != 3 or frame.shape[0]<16 or frame.shape[1]<16:
        raise ValueError('expected HxWx3 uint8 RGB frame')
    return frame


@dataclass
class VisionReading:
    rgb: list
    luminance: float
    pixel_change: float
    optical_flow_px: float | None
    def as_record(self):
        return {'rgb_normalized':self.rgb,'luminance':self.luminance,
                'frame_difference':self.pixel_change,'optical_flow_px_per_frame':self.optical_flow_px,
                'classification':'measured from displayed/decoded RGB pixels'}


class VisionObserver:
    def __init__(self):
        self.last_gray=None;self.last_small=None
    def read(self,rgb):
        frame=check_frame(rgb)
        means=(frame.astype(np.float32).mean(axis=(0,1))/255).tolist()
        gray=cv2.cvtColor(frame,cv2.COLOR_RGB2GRAY)
        small=cv2.resize(gray,(64,80),interpolation=cv2.INTER_AREA)
        delta=0.0; flow=None
        if self.last_small is not None:
            delta=float(np.abs(small.astype(np.float32)-self.last_small.astype(np.float32)).mean()/255)
            field=cv2.calcOpticalFlowFarneback(self.last_small,small,None,.5,2,13,2,5,1.1,0)
            flow=float(np.linalg.norm(field,axis=-1).mean())
        self.last_small=small
        lum=float(.2126*means[0]+.7152*means[1]+.0722*means[2])
        return VisionReading(means,lum,delta,flow)


def audio_features(samples,sr):
    a=np.asarray(samples,dtype=np.float64)
    if a.ndim!=1 or a.size<64 or a.size>1_000_000 or not np.isfinite(a).all() or not 8000<=sr<=192000:
        raise ValueError('invalid bounded mono audio segment')
    rms=float(np.sqrt(np.mean(a*a)))
    window=np.hanning(a.size)
    magnitude=np.abs(np.fft.rfft(a*window))
    bins=np.fft.rfftfreq(a.size,1/sr)
    centroid=float((bins*magnitude).sum()/magnitude.sum()) if magnitude.sum()>1e-12 else 0.0
    return {'rms':rms,'spectral_centroid_hz':centroid,'sample_rate_hz':int(sr),
            'classification':'measured from supplied digital PCM samples (not speech recognition)'}


def audio_as_rgb(features):
    """Defined numerical encoding; these are NOT actual colors or wavelengths."""
    nyquist=features['sample_rate_hz']/2
    return [min(1.,features['rms']*8),min(1.,features['spectral_centroid_hz']/nyquist*6),
            min(1.,features['spectral_centroid_hz']/nyquist)]


def read_wav(path):
    with wave.open(str(path),'rb') as f:
        if f.getnchannels()!=1 or f.getsampwidth()!=2:
            raise ValueError('only mono 16bit PCM WAV supported')
        sr=f.getframerate();data=f.readframes(f.getnframes())
    return np.frombuffer(data,dtype='<i2').astype('float32')/32768.,sr


def analyze_video(path,max_frames=300,downsample=1):
    cap=cv2.VideoCapture(str(path))
    if not cap.isOpened():raise ValueError('video unavailable')
    fps=float(cap.get(cv2.CAP_PROP_FPS));obs=VisionObserver();records=[]
    i=0
    try:
        while i<max_frames*downsample:
            ok,bgr=cap.read()
            if not ok:break
            if i%downsample==0:
                r=obs.read(cv2.cvtColor(bgr,cv2.COLOR_BGR2RGB)).as_record()
                r['frame']=i;r['time_s']=i/fps if fps>0 else None;records.append(r)
            i+=1
    finally:cap.release()
    if not records:raise ValueError('no decoded video frames')
    return records
