"""Closed RGB/audio-to-Ripple-to-Lumina LIGHT feedback, independent virtual motor.

Explicit boundary: servo closes on simulated joint state, not recovered video pose.
External video/audio can be analyzed, but does not confer image understanding.
"""
from __future__ import annotations
import csv, hashlib, io, json, math, pathlib, subprocess, sys, time, wave
import cv2,numpy as np
from .sensors import VisionObserver,audio_features,audio_as_rgb,analyze_video,read_wav
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'upstream'))
from ripple_core_v0_5 import RippleNeuron
from vtk_renderer import Renderer
from ripple_genome.colony import Overseer
from ripple_genome.genetics import Genome
from ripple_genome.robotics import VirtualRobot,CONTROL_JOINTS,DT


def hashfile(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        while (c:=f.read(1024*1024)):h.update(c)
    return h.hexdigest()


def load_robot():
    path=ROOT/'results/selected_genomes.json';x=json.loads(path.read_text())
    genomes={j:Genome.from_record(x[j]) for j in CONTROL_JOINTS}
    coordinator=Overseer(max_workers=4)
    coordinator.robot=VirtualRobot(genomes)
    return coordinator


class Feedback:
    def __init__(self,enabled=True):
        self.vision=VisionObserver();self.v_neuron=RippleNeuron();self.a_neuron=RippleNeuron()
        self.enabled=enabled;self.brightness=.64;self.last=None
    def observe(self,frame,audio,rate):
        v=self.vision.read(frame);a=audio_features(audio,rate)
        dt=1/6  # model sample interval fixed when used at 6 fps
        # Actual RGB from raster pixels goes into original neuron.
        v_pulse=self.v_neuron.step([float(np.clip(v.rgb[0]*1.5+.7*v.pixel_change,0,1)),
            float(np.clip(v.rgb[1]*1.1,0,1)),float(np.clip(v.rgb[2]*.8,0,1))],dt)
        # Sound-to-RGB encoding is intentionally typed, not described as optical sensing.
        a_pulse=self.a_neuron.step(audio_as_rgb(a),dt)
        before=self.brightness
        # Only rendered lighting, never motor commands. Predictable bounded negative feedback.
        if self.enabled:
            correction=float(np.clip(1.5*(.16-v.luminance),-.032,.032))
            event_mod=.004*int(v_pulse['count']>0)-.003*int(a_pulse['count']>0)
            self.brightness=float(np.clip(self.brightness+correction+event_mod,.38,.9))
        self.last={'vision':v.as_record(),'audio':a,'audio_encoding_rgb':audio_as_rgb(a),
                   'ripple_vision_events':v_pulse['count'],'ripple_audio_events':a_pulse['count'],
                   'ripple_vision_threshold':v_pulse['theta'],'ripple_audio_threshold':a_pulse['theta'],
                   'lighting_before':before,'lighting_next':self.brightness,
                   'feedback_action':'bounded rendering light only' if self.enabled else 'disabled'}
        return self.last


def tone_chunk(position,velocity,start_t,seconds,sample_rate=16000):
    """Generated SONIFICATION—not a spoken voice or recorded environment."""
    ns=round((start_t+seconds)*sample_rate)-round(start_t*sample_rate);t=(start_t+np.arange(ns)/sample_rate)
    hz=260.+90.*float(np.clip(position,-.5,1.5));amplitude=.07+.1*min(1.,abs(velocity))
    # phase within chunk can reset: not speech and not a frequency-lock guarantee.
    return np.asarray(amplitude*np.sin(2*np.pi*hz*t),dtype=np.float32)


def video_writer(path,size,fps):
    for codec in ('mp4v','avc1'):
        w=cv2.VideoWriter(str(path),cv2.VideoWriter_fourcc(*codec),fps,size)
        if w.isOpened():return w,codec
        w.release()
    raise RuntimeError('no video encoding backend')


def save_wav(path,samples,sr):
    a=np.clip(np.concatenate(samples),-1,1)
    with wave.open(str(path),'wb') as f:
        f.setnchannels(1);f.setsampwidth(2);f.setframerate(sr)
        f.writeframes((a*32767).astype('<i2').tobytes())


def run_session(instruction='raise right arm to 55 degrees',out=None,frames=30,fps=6,
                feedback_enabled=True,size=(240,320)):
    if not (8<=frames<=120 and fps==6):raise ValueError('this validated controller supports 8..120 frames at 6 FPS')
    if not (128<=size[0]<=640 and 160<=size[1]<=800):raise ValueError('invalid render size')
    out=pathlib.Path(out or ROOT/'results/session');out.mkdir(parents=True,exist_ok=True)
    overseer=load_robot();goals=overseer.dispatch({'kind':'language','text':instruction})['joint_targets']
    overseer.robot.set_targets(goals)
    video=out/'recording_silent.mp4';wav=out/'sonification.wav';writer,codec=video_writer(video,size,fps)
    renderer=Renderer(size=size);feedback=Feedback(feedback_enabled);traces=[];audio_chunks=[]
    start=time.perf_counter();samples_per_frame=round(16000/fps)
    try:
        for k in range(frames):
            for _ in range(round((1/fps)/DT)):
                overseer.robot.step(DT)
            robot=overseer.robot.status();j=robot['joints']
            angles={q:j[q]['position'] for q in CONTROL_JOINTS}
            rgb=[35,165,229]
            frame=renderer.frame(k/fps,{'mode':'idle','joint_overrides':angles,'gene_rgb':rgb,
                'heart':feedback.brightness,'density':.18,'scan':.12,'bloom':.23,'yaw':.42})
            arr=np.asarray(frame.convert('RGB'))
            writer.write(cv2.cvtColor(arr,cv2.COLOR_RGB2BGR))
            chunk=tone_chunk(j['arm_R']['position'],j['arm_R']['velocity'],k/fps,1/fps)
            # Sample counts follow rounded timestamps to avoid accumulated audio drift.
            audio_chunks.append(chunk)
            rec=feedback.observe(arr,chunk,16000)
            traces.append({'frame':k,'t_s':k/fps,'commanded_targets':goals,'pose_from_virtual_servo':angles,
                          'observation':rec,'source':'real raster RGB / generated audio samples / simulated motor state'})
    finally:writer.release()
    save_wav(wav,audio_chunks,16000)
    # Actual real media file round-trip. Measure decoded pixels, not just pre-encode buffer.
    decoded=analyze_video(video,max_frames=frames)
    if len(decoded)!=frames:raise RuntimeError(f'video decode returned {len(decoded)} of {frames} frames')
    # Validate PCM decode of the generated waveform.
    wav_data,sr=read_wav(wav)
    if not np.any(wav_data):raise RuntimeError('WAV silent or invalid')
    mux=out/'recording_with_audio.mp4';mux_ok=False;mux_error=None
    try:
        proc=subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(video),'-i',str(wav),'-c:v','copy','-c:a','aac','-shortest',str(mux)],capture_output=True,text=True,timeout=25)
        mux_ok=proc.returncode==0 and mux.is_file() and mux.stat().st_size>0
        if not mux_ok:mux_error=proc.stderr[-500:]
    except (FileNotFoundError,subprocess.TimeoutExpired) as exc:mux_error=str(exc)
    (out/'timeline.json').write_text(json.dumps(traces,indent=2,allow_nan=False))
    visual_event_total=sum(x['observation']['ripple_vision_events'] for x in traces)
    audio_event_total=sum(x['observation']['ripple_audio_events'] for x in traces)
    summary={'instruction':instruction,'source':'limited deterministic grammar, not Kokoro trained LLM',
             'frame_count':frames,'fps':fps,'robot':'original v1.8 simulated servo',
             'render':'actual 3D VTK/EGL skinning and PNG-to-video encoding',
             'real_rgb_observation':'measured rendered and decoded 8bit display pixels',
             'audio':'actual WAV, synthetically sonified joint state, not a real microphone or TTS voice',
             'observer_control':'feedback changes NEXT FRAME luminous brightness; does not command joints',
             'feedback_enabled':feedback_enabled,'vision_ripple_events':visual_event_total,
             'audio_ripple_events':audio_event_total,'luminance_first':traces[0]['observation']['vision']['luminance'],
             'luminance_last':traces[-1]['observation']['vision']['luminance'],
             'final_light_setting':feedback.brightness,'mean_frame_change':float(np.mean([x['observation']['vision']['frame_difference'] for x in traces])),
             'mean_optical_flow_px_per_frame':float(np.mean([x['observation']['vision']['optical_flow_px_per_frame'] for x in traces if x['observation']['vision']['optical_flow_px_per_frame'] is not None])),
             'video_decoded_frames':len(decoded),'WAV_decoded_samples':len(wav_data),'sample_rate_hz':sr,
             'video_codec':codec,'audio_mux_passed':mux_ok,'audio_mux_error':mux_error,
             'wall_time_s':time.perf_counter()-start,
             'sha256':{'video':hashfile(video),'wav':hashfile(wav),**({'muxed_video':hashfile(mux)} if mux_ok else {})},
             'trained_ai_connected':False,'camera_or_microphone_used':False}
    (out/'summary.json').write_text(json.dumps(summary,indent=2))
    # Render an observed RGB strip based on recorded pixels (not synthetic visual art).
    from PIL import Image,ImageDraw
    strip=Image.new('RGB',(frames*5,72),'#111827');draw=ImageDraw.Draw(strip)
    for i,r in enumerate(decoded):
        col=tuple(int(np.clip(v*255,0,255)) for v in r['rgb_normalized'])
        draw.rectangle((i*5,0,(i+1)*5-1,45),fill=col)
        yy=int(68-40*r['frame_difference']);draw.line((i*5,yy,(i+1)*5,yy),fill='#f8b36b')
    strip.save(out/'observed_RGB_timeline.png')
    return summary
