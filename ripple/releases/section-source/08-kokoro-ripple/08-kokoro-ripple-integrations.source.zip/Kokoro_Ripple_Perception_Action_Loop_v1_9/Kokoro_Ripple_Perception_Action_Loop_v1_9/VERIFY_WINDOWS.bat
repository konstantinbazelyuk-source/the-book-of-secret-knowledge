@echo off
cd /d "%~dp0"
python -m unittest discover -s tests -v
python verify_release.py
pause
