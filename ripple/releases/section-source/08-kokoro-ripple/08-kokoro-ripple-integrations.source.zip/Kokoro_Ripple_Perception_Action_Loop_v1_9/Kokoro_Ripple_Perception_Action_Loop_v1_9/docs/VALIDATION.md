# Reproducible measured trial and negative results

## Source

Source release: archived `Kokoro_Ripple_Genome_Robotics_Alpha_v1_8.zip` from the user's conversation, SHA-256 in `upstream_release.sha256`. This release copies its `ripple_genome`, `upstream` functional Python/JS, `assets` GLB and selected genome JSON unchanged; no original code edits.

## Confirmed executable run

- **Unit tests:** 58 passing (`45` inherited v1.8 + `13` new, including a real local HTTP test).
- **Renderer:** real VTK-EGL 3D rasterization of the original skinned GLB representation using the inherited renderer; camera-independent graphics is not claimed.
- **Recording:** OpenCV creates MP4, signed 16-bit PCM WAV sonifies the virtual arm position/velocity, and FFmpeg muxes audio + video in MP4.
- **Roundtrip:** OpenCV decodes back all 24/24 frames; WAV roundtrips to 64,000 samples at 16 kHz for 4 seconds. External analysis extracts embedded audio from MP4 using FFmpeg.
- **Original Ripple:** vision and audio feature channels each call the preserved Ripple v0.1 neuron code. In the 24-frame trial: 5 visual and 13 audio software events. No biological / quantum / optical sensor claim.
- **Live operator:** HTTP 200 UI, 422 unsafe command, 403 cross-origin request, 202 accepted safe instruction, 200 video and RGB timeline. One job at a time on 127.0.0.1 only.
- **Ablation:** A 24-frame feedback-on/off comparison had 23 different encoded frames. Mean absolute per-channel pixel difference 0.14096/255. See `results/comparison_feedback.json`.

## Negative results and limits

- Luminous parameter rose to 0.90 saturation; the requested mean luminance of 0.16 was not reached (feedback-on final 0.14638). Thus the light controller is a **real connected actuator but NOT a tuned successful brightness regulator**.
- The two recorded videos have identical generated WAVs; audio synthesizer does not listen to the rendered video and cannot recognize speech.
- Pose-from-pixel estimation and motor correction based on visual evidence are **not implemented**. The preexisting motor controller closes a feedback loop only on virtual joint state.
- No real camera, microphone, trained Kokoro checkpoint, real Blender execution, external LLM or robot controls have been exercised.
- Timing represents *simulated 6-fps frame time and 50-Hz virtual-servo clock*. It is not a hard-real-time system; wall-clock rendering speed depends on host.
- The audio encoder uses declarative frequency/energy features packed into RGB-sized numerical inputs. These are not color wavelengths or cross-modal conscious states.
- 3D framing/post-effects are executed, but they do not establish advanced avatar model generation or animation comprehension.
