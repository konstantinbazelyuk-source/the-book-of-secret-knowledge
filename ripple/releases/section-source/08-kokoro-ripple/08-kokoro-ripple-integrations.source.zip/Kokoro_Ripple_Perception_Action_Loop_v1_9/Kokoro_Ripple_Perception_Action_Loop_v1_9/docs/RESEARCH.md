# Research used and reuse boundaries

- **OpenCV dense optical flow (Farneback):** https://docs.opencv.org/4.7.0/dc/d6b/group__video__track.html . Used in `loop/sensors.py` to estimate image displacement between actual raster frames. Not a learned skeletal estimator.
- **Librosa RMS definition:** https://librosa.org/doc/0.11.0/generated/librosa.feature.rms.html . The scalar RMS formula is implemented directly in NumPy; Librosa is not installed or bundled.
- **FFmpeg official media filters and tools:** https://ffmpeg.org/ffmpeg-filters.html . Used via local installed executable for audiovisual multiplexing / PCM extraction. No online upload.
- **ROS 2 joint trajectory controller:** https://control.ros.org/kilted/doc/ros2_controllers/joint_trajectory_controller/doc/userdoc.html . Reference for the separate, time-indexed command vs feedback interface. This release does not invoke ROS 2 or physical hardware.
- **Google MediaPipe PoseLandmarker:** https://ai.google.dev/edge/api/mediapipe/python/mp/tasks/vision/PoseLandmarker . Candidate for future confidence-tagged pose observations; not implemented or used, no pretrained model loaded.
- **Blender Python rendering:** https://docs.blender.org/api/main/bpy.ops.render.html . Candidate Blender scene bridge. Blender is not installed here; VTK/EGL is the executed 3D engine.

Existing Kokoro/Ripple source is copied without changes from the user-provided v1.8 release. Original project-specific license statements remain in force. No Google, Meta, xAI, OpenAI, Unity, Godot or other proprietary model source has been copied into this package. Research techniques were implemented from mathematical API contracts.
