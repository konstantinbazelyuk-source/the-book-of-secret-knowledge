# Actual mathematical interfaces and implementation boundary

## Control graph

```
Typed user instruction (fixed reviewed grammar; trained Kokoro Core unavailable)
  → approved target joint vector q*(t) [radians]
  → previous v1.8 Genome Motor / Ripple LIF / VirtualJointPlant
  → q(t), dq(t) [simulated, not physically measured]
  → VTK 3D skinned renderer R(mesh, q(t), lighting L(t))
  → framebuffer RGB I(t)
  → encode MP4, audio WAV (audio = synthetic kinematic sonification)
  → OpenCV pixel / motion observer; PCM+FFT audio observer
  → typed signal channels; preserved v0.1 Ripple LIF
  → bounded low-authority light adaptation L(t+1)
  → next 3D frame
```

### Formal stages

Instruction compilation: `grammar: text → {joint_id: angle_radians}`. The grammar is deliberately narrow; not general semantic understanding.

**Motor dynamics**: fixed reviewed controller and virtual plant inherited directly from v1.8, at numerical `DT=0.02` s. The renderer updates at 6 frames/s. Real measured joint angles from a camera or robot do **not** enter this model.

Rasterization: `I_t = Render(M, q_t, L_t, camera, exposure)` where `M` is skinned 3D mesh and `L_t` is a bounded heart illumination parameter.

Video measurements for a frame with H×W display-referred RGB pixels:

`rbar_t = (1 / 255HW) × sum_{x,y} R_t(x,y)`; likewise `gbar`, `bbar`.

`Ybar_t = 0.2126 rbar_t + 0.7152 gbar_t + 0.0722 bbar_t` (display-luminance *proxy*, not absolute photometric luminance).

`Δ_t = mean_pixels(|gray(I_t) - gray(I_{t-1})|) / 255` on a fixed downscaled grid. Dense Farneback optical flow estimates inter-frame image displacement; motion or exposure can affect this and it does not identify specific joints.

Audio observation for N decoded samples `s_i`:

`RMS = sqrt(mean(s_i^2))`; `centroid = sum_f f|S(f)| / sum_f |S(f)|`. This is audio feature extraction, **not listening or speech understanding**.

Two explicitly separated populations receive dimensionless 3-channel signals:

`x_vision = clamp([1.5*rbar + 0.7*Δ, 1.1*gbar, 0.8*bbar],0,1)`;

`x_audio = clamp([8*RMS, 6*centroid/Nyquist, centroid/Nyquist],0,1)`.

**Audio-to-RGB is a declared numerical encoding.** Its second/third components are NOT measured green/blue photons or physiological cross-modal responses.

Both are fed to the preserved v0.1 Ripple leaky integrate-and-fire neuron:

`D = 2R + 1.2G − 1.4B`; `τ_v du/dt = -u + D`; threshold crossing causes events, reset and refractory. Original coefficients are unchanged.

Causal feedback **only to the next rendered frame**:

`L_{t+1} = clip(L_t + clip(1.5*(0.16 - Ybar_t), -0.032, 0.032) + 0.004*1{visual_event} - 0.003*1{audio_event}, 0.38,0.90)`.

This is a deliberately simple bounded actuator for rendered lighting. It cannot override joint constraints and did not converge to 0.16 luminance in the recorded trial. We do not interpret that as a successful vision-based motor controller.

### What remains to connect the true loop

1. A **reliable observation model** `pose_estimator(I_t,camera calibration)→ (q_hat, confidence)` independent of virtual-servo joint state (e.g., an approved calibrated synthetic silhouette/landmark channel, and later a validated learned pose model). Without it RGB cannot identify a 3D joint angle reliably due to occlusion, viewpoint and lighting.
2. A **perceptual controller** `controller(q*−q_hat, confidence)→ bounded joint action`, with holdout trials under changed camera, occlusion and dynamic loads; failure to observe must trigger safe abstention.
3. Production-grade speech/audio bridge: ASR with transcription confidence, timestamps, speaker/privacy handling, and trained Kokoro's own authorization layer. Current file contains only frequency/energy analysis.
4. Streaming synchronization, bounded queues and deadlines. Current service generates finite recordings on localhost and does not guarantee real-time behavior.
5. Real Blender rig/edit/export process or dedicated real-time game renderer attached through a versioned RPC protocol, with independent skeletal transform validation and asset lineage.
6. Verified closed-loop motor safety using real-time joint state and physical hardware only if robot control is explicitly required. Exported URDF is currently kinematic only, not a physically calibrated robot.
7. Training, validation, persistence and rollback of any promoted multi-sensor motor policy. No genetic mutation of safety limits or silent checkpoint edits.
