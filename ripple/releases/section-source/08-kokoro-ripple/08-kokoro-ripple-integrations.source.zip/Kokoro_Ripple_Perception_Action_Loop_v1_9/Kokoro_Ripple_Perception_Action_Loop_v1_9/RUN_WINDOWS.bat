@echo off
cd /d "%~dp0"
python -m pip install -r requirements.txt
where ffmpeg >nul 2>&1
if errorlevel 1 echo FFmpeg not found: install FFmpeg to add audio to the MP4 file.
python tools\operator_server.py --port 8774
pause
