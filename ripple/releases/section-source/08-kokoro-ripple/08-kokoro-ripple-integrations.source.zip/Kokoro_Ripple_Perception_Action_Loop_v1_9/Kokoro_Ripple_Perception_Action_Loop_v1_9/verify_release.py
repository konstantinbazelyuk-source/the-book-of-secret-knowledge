"""Check source copying against the v1.8 uploaded archive and local ZIP manifest.

This is file integrity only, not proof of authorship or capability.
"""
import json,hashlib,pathlib,sys
BASE=pathlib.Path(__file__).resolve().parent
MANIFEST=BASE/'INTEGRITY_MANIFEST.json'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def verify():
    x=json.loads(MANIFEST.read_text());missing=[];changed=[]
    for name,h in x['files'].items():
        p=BASE/name
        if not p.exists():missing.append(name)
        elif sha(p)!=h:changed.append(name)
    report={'checked_files':len(x['files']),'missing_files':missing,'changed_files':changed,'passed':not(missing or changed),
            'scope':'packaged bytes unchanged since manifest creation; no claims of runtime behavior'}
    print(json.dumps(report,indent=2));return 0 if report['passed'] else 1
if __name__=='__main__':sys.exit(verify())
