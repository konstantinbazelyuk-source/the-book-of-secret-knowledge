import sys, pathlib,argparse,json
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from loop.runtime import run_session
p=argparse.ArgumentParser(description='Local Kokoro visual/audio loop, simulated joints and actual 3D rendering')
p.add_argument('--instruction',default='raise right arm to 55 degrees')
p.add_argument('--frames',type=int,default=30)
p.add_argument('--out',default=str(ROOT/'results/session'))
p.add_argument('--feedback-off',action='store_true')
a=p.parse_args()
print(json.dumps(run_session(a.instruction,a.out,a.frames,feedback_enabled=not a.feedback_off),indent=2))
