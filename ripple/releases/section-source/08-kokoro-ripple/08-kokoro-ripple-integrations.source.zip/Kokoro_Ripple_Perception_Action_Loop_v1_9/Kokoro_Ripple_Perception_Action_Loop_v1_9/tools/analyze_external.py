"""Inspect real decoded pixels + optionally PCM audio in a supplied recording.

Never interpret a sound as speech or RGB as pose semantics. No dynamic code execution.
"""
import sys,pathlib,argparse,json,numpy as np,subprocess,tempfile
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from loop.sensors import analyze_video,read_wav,audio_features,audio_as_rgb
from upstream.ripple_core_v0_5 import RippleNeuron
p=argparse.ArgumentParser();p.add_argument('--video',required=True);p.add_argument('--wav');p.add_argument('--audio-from-video',action='store_true');p.add_argument('--out',default='external_observation.json');a=p.parse_args()
if a.wav and a.audio_from_video:p.error('choose --wav or --audio-from-video, not both')
video=analyze_video(a.video,max_frames=300);neuron=RippleNeuron()
for i,r in enumerate(video):
    x=r['rgb_normalized']
    dt=(r['time_s']-video[i-1]['time_s']) if i>0 and r['time_s'] is not None and video[i-1]['time_s'] is not None else None
    if dt is None or not .001<=dt<=.5:
        r['ripple']={'status':'unavailable','reason':'valid per-frame timestamps required'}
    else:r['ripple']={'status':'computed','events':neuron.step(x,float(dt))['count']}
res={'frames':len(video),'video':str(a.video),'observations':video,'audio':None,
     'provenance':'decoded pixels in the supplied video and digital audio samples; no speech recognition, semantic vision or camera measurement'}

def do_audio(path):
    s,sr=read_wav(path)
    duration=min(1.,len(s)/sr)
    return {'features':audio_features(s[:max(64,round(duration*sr))],sr),'rgb_encoding':audio_as_rgb(audio_features(s[:max(64,round(duration*sr))],sr)),
            'source':str(a.wav) if a.wav else 'PCM extracted from supplied video by FFmpeg'}
if a.wav:res['audio']=do_audio(a.wav)
elif a.audio_from_video:
    with tempfile.TemporaryDirectory() as d:
        temp=pathlib.Path(d)/'audio.wav'
        result=subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',a.video,'-vn','-ac','1','-ar','16000','-c:a','pcm_s16le',str(temp)],capture_output=True,text=True,timeout=20)
        if result.returncode==0 and temp.exists():res['audio']=do_audio(temp)
        else:res['audio']={'status':'unavailable','reason':'no decodable audio track'}
pathlib.Path(a.out).write_text(json.dumps(res,indent=2,allow_nan=False))
print(json.dumps({'frames':len(video),'audio_supplied':res['audio'] is not None,'output':a.out}))
