"""Local-only operator for asynchronous batch audiovisual render + Ripple observation.

NOT a network-exposed automation or Blender process. One render job at a time.
"""
from __future__ import annotations
import json,pathlib,sys,threading,time,urllib.parse
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from loop.runtime import run_session
PAGE='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Kokoro · Perception–Action Loop</title><style>body{font:16px system-ui;background:#111926;color:#edf2f9;margin:0 auto;max-width:960px;padding:22px}input,button{font:inherit;padding:12px;border-radius:8px;background:#26394a;color:white;border:1px solid #56758f}input{width:64%;min-width:240px}button{cursor:pointer}video{width:100%;max-width:570px;background:#000;border-radius:10px}pre{white-space:pre-wrap;background:#172536;padding:14px;overflow-wrap:anywhere}.muted{color:#a5b9ca}img{width:100%;max-width:570px}</style></head><body><h1>Kokoro · Render → Record → Ripple</h1><p class="muted">Real 3D raster and encoded audio/video. Avatar joints use a digital actuator. No connected language model, camera, microphone or physical robot.</p><p>Enter a supported instruction such as <code>raise right arm to 55 degrees</code> or <code>turn head left 12 degrees</code>.</p><input id="cmd" value="raise right arm to 55 degrees"/><button id="go">Run</button><p id="status">Waiting</p><video id="video" controls playsinline></video><h2>Recorded RGB trace</h2><img id="rgb" alt="RGB samples measured from decoded video frames"/><h2>Measurements</h2><pre id="data"></pre><script>const s=document.getElementById('status'),d=document.getElementById('data'),v=document.getElementById('video'),im=document.getElementById('rgb');document.getElementById('go').onclick=async()=>{s.textContent='Starting';try{const r=await fetch('/api/start',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({instruction:document.getElementById('cmd').value,frames:24})});const j=await r.json();if(!r.ok)throw Error(j.error);watch()}catch(e){s.textContent=e.message}};async function watch(){const j=await(await fetch('/api/status')).json();s.textContent=j.status+(j.error?' — '+j.error:'');if(j.status==='running'){setTimeout(watch,300);return}if(j.status==='complete'){v.src='/recording.mp4?t='+Date.now();im.src='/rgb.png?t='+Date.now();d.textContent=JSON.stringify(j.summary,null,2)}};</script></body></html>'''
class App:
    def __init__(self):self.lock=threading.Lock();self.status='idle';self.error=None;self.summary=None;self.out=ROOT/'results/live_session'
    def start(self,body):
        if not isinstance(body,dict) or set(body)!={'instruction','frames'}:raise ValueError('expected instruction and frames only')
        instr=body['instruction'];frames=body['frames']
        if not isinstance(instr,str) or not 1<=len(instr)<=200 or type(frames)!=int or not 8<=frames<=90:
            raise ValueError('invalid instruction or bounded frame count')
        with self.lock:
            if self.status=='running':raise RuntimeError('render already running')
            # Prevalidate with the real grammar before allocating render work.
            from loop.runtime import load_robot
            worker=load_robot();worker.dispatch({'kind':'language','text':instr})
            self.status='running';self.error=None;self.summary=None
        def execute():
            try:
                s=run_session(instr,self.out,frames)
                with self.lock:self.summary=s;self.status='complete'
            except Exception as e:
                with self.lock:self.error=type(e).__name__+': '+str(e);self.status='error'
        threading.Thread(target=execute,daemon=True).start()
class Handler(BaseHTTPRequestHandler):
    def reply(self,b,status=200,ctype='application/json'):
        if not isinstance(b,bytes):b=json.dumps(b).encode()
        self.send_response(status);self.send_header('Content-Type',ctype);self.send_header('Content-Length',str(len(b)))
        self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'unsafe-inline' 'self'; style-src 'unsafe-inline' 'self'; img-src 'self'; media-src 'self'; connect-src 'self'")
        self.end_headers();self.wfile.write(b)
    def do_GET(self):
        a=self.server.app;path=self.path.split('?')[0]
        if path=='/':return self.reply(PAGE.encode(),ctype='text/html; charset=utf-8')
        if path=='/api/status':
            with a.lock:return self.reply({'status':a.status,'error':a.error,'summary':a.summary})
        files={'/recording.mp4':'recording_with_audio.mp4','/rgb.png':'observed_RGB_timeline.png','/timeline.json':'timeline.json'}
        if path in files and a.status=='complete':
            p=a.out/files[path]
            if p.is_file():return self.reply(p.read_bytes(),ctype={'/recording.mp4':'video/mp4','/rgb.png':'image/png','/timeline.json':'application/json'}[path])
        return self.reply({'error':'not found'},404)
    def do_POST(self):
        if self.path!='/api/start':return self.reply({'error':'not found'},404)
        # Reject cross-origin browser form submissions to this loopback service.
        origin=self.headers.get('Origin')
        accepted={'http://127.0.0.1:'+str(self.server.server_port),'http://localhost:'+str(self.server.server_port)}
        if origin and origin not in accepted:return self.reply({'error':'cross-origin operator request rejected'},403)
        if self.headers.get('Content-Type','').split(';')[0].strip()!='application/json':return self.reply({'error':'application/json required'},415)
        try:
            n=int(self.headers.get('Content-Length','0'))
            if not 0<n<=1024:raise ValueError('bad request length')
            x=json.loads(self.rfile.read(n));self.server.app.start(x)
            return self.reply({'status':'running'},202)
        except (ValueError,TypeError,KeyError) as e:return self.reply({'error':str(e)},422)
        except RuntimeError as e:return self.reply({'error':str(e)},409)
    def log_message(self,*args):pass

def serve(port=8774):
    import argparse
    h=ThreadingHTTPServer(('127.0.0.1',port),Handler);h.app=App()
    print('Kokoro visual-audio loop on http://127.0.0.1:'+str(h.server_port),flush=True)
    try:h.serve_forever()
    finally:h.server_close()
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8774);a=p.parse_args();serve(a.port)
