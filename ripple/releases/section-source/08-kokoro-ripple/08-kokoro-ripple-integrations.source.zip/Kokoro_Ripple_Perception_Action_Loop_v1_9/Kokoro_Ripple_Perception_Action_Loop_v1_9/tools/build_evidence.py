import sys,pathlib,cv2,json,numpy as np
from PIL import Image,ImageDraw,ImageFont
ROOT=pathlib.Path(__file__).resolve().parents[1];out=ROOT/'results';a=json.loads((out/'session_enabled/summary.json').read_text());b=json.loads((out/'session_disabled/summary.json').read_text())
tr_a=json.loads((out/'session_enabled/timeline.json').read_text());tr_b=json.loads((out/'session_disabled/timeline.json').read_text())
cap_a=cv2.VideoCapture(str(out/'session_enabled/recording_silent.mp4'));cap_b=cv2.VideoCapture(str(out/'session_disabled/recording_silent.mp4'))
imgs=[]
for cap in [cap_a,cap_b]:
    cap.set(cv2.CAP_PROP_POS_FRAMES,14)
    ok,f=cap.read();assert ok
    imgs.append(Image.fromarray(cv2.cvtColor(f,cv2.COLOR_BGR2RGB)).resize((360,480)))
    cap.release()
canvas=Image.new('RGB',(790,580),'#111927');d=ImageDraw.Draw(canvas)
canvas.paste(imgs[0],(22,53));canvas.paste(imgs[1],(408,53))
d.text((25,20),'Recorded: feedback enabled',fill='#edf2fa');d.text((411,20),'Recorded: feedback disabled',fill='#edf2fa')
d.text((26,547),'Independent 3D renders, same virtual motor, different feedback lighting.',fill='#abc4d9')
canvas.save(out/'actual_loop_render_comparison.png')
# Actual time series (no fabricated lines, directly from recorded numerical observations)
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
n=min(len(tr_a),len(tr_b));t=np.arange(n)/6
fig,axes=plt.subplots(2,1,figsize=(9.2,5.8),sharex=True)
axes[0].plot(t,[q['observation']['vision']['luminance'] for q in tr_a[:n]],label='RGB luminance, feedback on')
axes[0].plot(t,[q['observation']['vision']['luminance'] for q in tr_b[:n]],label='RGB luminance, feedback off')
axes[0].axhline(.16,label='requested test luminance (not achieved)',linestyle='--')
axes[0].legend(fontsize=8);axes[0].set_ylabel('Mean pixel luminance [0,1]')
axes[1].plot(t,[q['observation']['lighting_next'] for q in tr_a[:n]],label='Feedback-enabled luminous parameter')
axes[1].plot(t,[q['observation']['lighting_next'] for q in tr_b[:n]],label='Feedback-disabled luminous parameter')
axes[1].set_xlabel('Simulated seconds');axes[1].set_ylabel('Luminous parameter [0,1]');axes[1].legend(fontsize=8)
fig.tight_layout();fig.savefig(out/'measured_feedback_time_series.png',dpi=145)
print(json.dumps({'outputs':['actual_loop_render_comparison.png','measured_feedback_time_series.png'],'enabled_last_mean_lum':a['luminance_last'],'disabled_last_mean_lum':b['luminance_last'],'nominal_target':.16,'target_reached':abs(a['luminance_last']-.16)<.005},indent=2))
