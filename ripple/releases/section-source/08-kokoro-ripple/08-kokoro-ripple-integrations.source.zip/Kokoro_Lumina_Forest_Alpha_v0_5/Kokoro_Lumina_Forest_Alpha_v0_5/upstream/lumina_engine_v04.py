"""Lumina temporal controller; original Ripple v0.1 math stays in copied baseline module.
Visual data is only derived from specified numeric packets or explicitly tagged demo controls.
Affective/sentience interpretation is intentionally excluded.
"""
from __future__ import annotations
from dataclasses import dataclass,asdict
import math
from typing import Optional
from baseline.kokoro_mesh.ripple_python import RippleNeuron
from .quaternary import QuadEncoder

class PacketError(ValueError):pass

def bounded(v,name,lo=0.0,hi=1.0):
    if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or v<lo or v>hi:
        raise PacketError(f'{name} must be a finite number in [{lo}, {hi}]')
    return float(v)

def smooth(current,target,dt,tau):
    # Exponential smoothing is invariant to frame subdivision at constant target.
    return current+(target-current)*(1-math.exp(-dt/tau))

@dataclass(frozen=True)
class FramePacket:
    schema:str
    visual_source:str
    avatar_asset:str
    simulated:bool
    elapsed_s:float
    expression:str
    pose:str
    yaw:float
    gaze_x:float
    gaze_y:float
    blink:float
    mouth:float
    breath:float
    bob:float
    shimmer:float
    pulse:float
    ripple_rate:float
    ripple_threshold:float
    ripple_drive:float
    event_count:int
    overdrive:float
    fps_cap:int
    scene_epoch:int
    ripple_q_code:int
    ripple_q_symbol:str
    weapon_mode:str
    foot_mode:str
    heart_power:float

EXPRESSIONS={'neutral','focused','curious','relaxed','happy','sad','surprised'}
POSES={'idle','listening','speaking','thinking','rest'}
SOURCES={'synthetic-demo','kokoro-reported','human-control','replay'}

class LuminaEngine:
    def __init__(self, seed:int=17, fps_cap:int=30, avatar_asset:str='placeholder'):
        if isinstance(seed,bool) or not isinstance(seed,int) or seed<0 or seed>2**32-1:raise PacketError('seed must be a uint32')
        if fps_cap not in (10,15,24,30,60):raise PacketError('supported fps_cap: 10/15/24/30/60')
        self.neuron=RippleNeuron()
        self.quad=QuadEncoder()
        self.t=0.;self.seed=seed;self.fps_cap=fps_cap
        self.asset=avatar_asset
        self.mouth=self.gaze_x=self.gaze_y=self.yaw=self.shimmer=self.pulse=0.0
        self.overdrive=0.0;self.blink=0.;self.blink_due=2.5;self.blink_start=-10.;self._rng=seed or 1
        self.events=0;self.epoch=0;self.expr='neutral';self.pose='idle'
        self.weapon_mode='stowed';self.foot_mode='compact';self.heart_power=0.
        self.source='synthetic-demo'
        self.drive=0.;self.rate=0.;self.theta=.45
        self.simulated=True

    def _rand(self):
        self._rng=(1664525*self._rng+1013904223)&0xffffffff
        return self._rng/4294967296.

    def validate(self,packet):
        if not isinstance(packet,dict):raise PacketError('packet must be a JSON object')
        allowed={'schema','source','ripple_rgb','look_x','look_y','speech_amplitude','expression','pose','overdrive','scene_epoch','weapon_mode','foot_mode','heart_power'}
        if set(packet)-allowed:raise PacketError('unexpected packet fields')
        if packet.get('schema')!='lumina.control.v1':raise PacketError('schema must be lumina.control.v1')
        if packet.get('source') not in SOURCES:raise PacketError('source must be explicit')
        cleaned=dict(packet)
        if 'ripple_rgb' in packet:
            raw=packet['ripple_rgb']
            if not isinstance(raw,(list,tuple)) or len(raw)!=3:raise PacketError('ripple_rgb must contain 3 bounded values')
            cleaned['ripple_rgb']=[bounded(v,'ripple_rgb') for v in raw]
        for k in ('speech_amplitude','overdrive','heart_power'):
            if k in packet:cleaned[k]=bounded(packet[k],k)
        for k in ('look_x','look_y'):
            if k in packet:cleaned[k]=bounded(packet[k],k,-1,1)
        if 'expression' in packet and packet['expression'] not in EXPRESSIONS:raise PacketError('unknown expression')
        if 'pose' in packet and packet['pose'] not in POSES:raise PacketError('unknown pose')
        if 'weapon_mode' in packet and packet['weapon_mode'] not in ('stowed','gun','sword'):raise PacketError('unknown weapon_mode')
        if 'foot_mode' in packet and packet['foot_mode'] not in ('compact','heels'):raise PacketError('unknown foot_mode')
        if 'scene_epoch' in packet and (not isinstance(packet['scene_epoch'],int) or isinstance(packet['scene_epoch'],bool) or packet['scene_epoch']<0):raise PacketError('invalid scene_epoch')
        return cleaned

    def advance(self,dt:float,packet:Optional[dict]=None)->FramePacket:
        if not isinstance(dt,(int,float)) or isinstance(dt,bool) or not math.isfinite(dt) or not 0<dt<=.5:raise PacketError('dt must be finite 0..0.5 seconds')
        dt=float(dt);packet=self.validate(packet) if packet is not None else None
        # No supplied signal means no measured signal, and no inferred cognition.
        rgb=[0.,0.,0.]
        if packet is not None:
            self.source=packet['source'];self.simulated=self.source in ('synthetic-demo','replay')
            rgb=packet.get('ripple_rgb',rgb)
            self.expr=packet.get('expression',self.expr)
            self.pose=packet.get('pose',self.pose)
            self.weapon_mode=packet.get('weapon_mode',self.weapon_mode)
            self.foot_mode=packet.get('foot_mode',self.foot_mode)
            self.heart_power=smooth(self.heart_power,packet.get('heart_power',0.),dt,.4)
            self.epoch=packet.get('scene_epoch',self.epoch)
            self.overdrive=smooth(self.overdrive,packet.get('overdrive',0.),dt,.5)
            gx=packet.get('look_x',0.);gy=packet.get('look_y',0.);mouth=packet.get('speech_amplitude',0.)
        else:
            self.source='synthetic-demo';self.simulated=True
            gx=gy=mouth=0.
            self.overdrive=smooth(self.overdrive,0,dt,.5)
            self.heart_power=smooth(self.heart_power,0,dt,.4)
        prev=self.t; self.t+=dt
        r=self.neuron.step(rgb,dt)
        q=self.quad.step(r['drive'])
        self.drive=r['drive'];self.rate=r['rate'];self.theta=r['theta'];self.events+=r['count']
        self.gaze_x=smooth(self.gaze_x,gx,dt,.17)
        self.gaze_y=smooth(self.gaze_y,gy,dt,.17)
        self.yaw=smooth(self.yaw,gx*.23,dt,.32)
        self.mouth=smooth(self.mouth,mouth,dt,.11)
        self.shimmer=smooth(self.shimmer,min(1.,r['rate']/3.),dt,.45)
        self.pulse=smooth(self.pulse,1. if r['count']>0 else 0.,dt,.22)
        # Bounded Blink oscillator; deterministic, periodic sampled curves. No mood claims.
        if self.t>=self.blink_due:
            self.blink_start=self.blink_due
            self.blink_due=self.t+2.0+2.5*self._rand()
        blink_phase=self.t-self.blink_start
        self.blink=max(0.,1.-abs(blink_phase-.13)/.13) if 0<=blink_phase<=.26 else 0.
        # Frame-rate-independent synthetic breath and posture. Not a physical measurement.
        breath=.5+.5*math.sin(2*math.pi*self.t/4.2)
        bob=.35*math.sin(2*math.pi*self.t/4.2)+.25*math.sin(2*math.pi*self.t/8.6)
        # Local frame budget advice; high overdrive dims effects rather than overdriving hardware.
        shimmer=self.shimmer*(1-.75*self.overdrive)
        return FramePacket('lumina.frame.v1',self.source,self.asset,self.simulated,round(self.t,4),self.expr,self.pose,
            round(self.yaw,5),round(self.gaze_x,5),round(self.gaze_y,5),round(self.blink,5),
            round(self.mouth,5),round(breath,5),round(bob,5),round(shimmer,5),round(self.pulse,5),
            round(r['rate'],6),round(r['theta'],6),round(r['drive'],6),r['count'],round(self.overdrive,5),self.fps_cap,self.epoch,q['code'],q['symbol'],self.weapon_mode,self.foot_mode,round(self.heart_power,5))

    def state(self):
        return asdict(self.advance(1e-7))
