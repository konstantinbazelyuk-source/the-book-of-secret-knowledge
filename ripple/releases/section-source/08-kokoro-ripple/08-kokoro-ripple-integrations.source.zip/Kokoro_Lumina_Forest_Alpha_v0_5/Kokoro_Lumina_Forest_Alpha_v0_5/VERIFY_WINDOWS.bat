@echo off
cd /d "%~dp0"
py -3 -m unittest discover -s tests -p test_forest.py -v
pause
