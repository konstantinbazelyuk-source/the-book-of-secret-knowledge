# Kokoro / Lumina Forest — Rigging Alpha v0.5

**Executable research-grade Alpha · 2026-10-13 · Original project preserved.**

This release implements an offline, continuous **8-piece 2D art rig** animated by a bounded **Ripple Forest**, combining **exact source copies of original Ripple v0.1 equations and Ripple-Q v0.7**, four chromatic signal profiles, a time-aware 2D diffusion field, an occlusion compositor, bounded image-particle density, and **Motion / Chromatic / Light masters overseen by a regulator**.

**Visual identity warning:** the included *Adelita Kokoro: Synthetic Heart Android* picture is **EARLY CONCEPT ART, NOT Kokoro's currently approved appearance**. It is author-owned reference artwork, not canonical. The 8 masks were hand-estimated from the old poster; this technical rig cannot invent hidden limb/backside pixels or a high-quality production deformable model.

## 1. Run right now without installation

- Open **`Kokoro_Lumina_Forest_Offline_Alpha.html`** (or Windows `START_WINDOWS.bat`) in a modern browser. The 8 study art textures, both project-owned JS neuron cores and the full front end are embedded directly in one self-contained file. **No AI API, Internet, model weights, paid subscription, server or account required.**
- Use sliders for numeric input / density / diffusion / occlusion / head movement / heart glow. Capture PNG or record WebM if the browser supports it.
- Every apparent activation is **simulated or human-controlled**. No avatar response is interpreted as consciousness, emotion or model intelligence. The controls do not execute a language model.

## 2. Real continuous Python PNG writer (optional)

Install dependencies in an ordinary Python 3.10+ virtual environment:

```bash
python -m pip install -r requirements-headless.txt
python -m alpha.continuous --out results/live --seconds 20 --fps 10
# --seconds 0 keeps writing the latest image until Ctrl+C; 20 FPS hard cap
python -m alpha --out results/your_animation.gif --frames 36 --fps 12
```

It continuously writes `results/live/latest.png`, `latest_state.json`, then `run_summary.json` on shutdown. The writer is only active while the process runs; it does **not** install a service or preserve cloud sessions.

## 3. Mesh and Core connections

The compatible board is `alpha.mesh_bridge.LuminaForestBoard`. It plugs into **Kokoro Mesh v0.3** using:

```python
from kokoro_mesh.runtime import Mesh
from alpha.mesh_bridge import LuminaForestBoard
mesh = Mesh(external={'lumina': LuminaForestBoard()})
```

Supply `lumina_forest_control` explicitly inside an otherwise ordinary Mesh request. If missing, this adapter returns `status=unavailable`. If present, it returns a typed control packet, with `rendered=False`; the browser/Python raster program performs actual rendering separately. **No trained Kokoro checkpoint, original daughterboard implementation, Lumina model weights, or sentient agent is loaded.** The previous ZIPs are retained under `upstream/` and are not rewritten.

Example controls:

```json
{"source":"human-control","rgb":[0.3,0.5,0.15],"look_x":0.25,"look_y":0.0,"speech":0.2,"heart":0.7,"drive_load":0.2,"density":0.7,"diffusion":0.6,"occlusion":0.9,"pose":"idle","scene_epoch":1}
```

An arbitrary client can type `source=kokoro-reported`, but that only creates a self-report claim, **not verified telemetry**. A future Kokoro connector must supply authentication and real observed state if it wishes to claim observational evidence.

## 4. Exactly what is an Alpha feature vs not

**Actual working code:** CPU affine cutout bone pivots; 2D nonlinear hair remap; browser sprite-slice hair deformation; painter's-layer occlusion; numerical field diffusion; four Ripple neuron profile clones with original drive/integration equation; Ripple-Q mapping; explicit source validation; intensity and particle limits; original asset hash verification; PNG/GIF/WebM export (WebM browser-dependent); browser offline animation and JavaScript image update; numerical Mesh adapter.

**Not accomplished:** anatomically correct full-skeletal skin weights, 3D VRM creation, photorealistic reconstruction of parts hidden in poster, accurate face expression shapes, properly rigged dynamic heels/weapon transformations, physical light measurements, machine learning, or genuine intelligent self-regulation by Kokoro. These require new art/model data, external sensors and/or a trained checkpoint with measurable evaluation.

**"Monochrome genes"**: a profile has at least 85% of measured *software event-rate mass* for **at least 2 continuous simulated seconds**, with combined rate above 0.15/sec. The 50 general signal scenarios did not show such sustained dominance; a separate deliberately selected synthetic input DOES trigger the code and is covered by a unit test. This term is metaphorical, not biology.

**"Diffusion"**: 2D 5-point Laplacian explicit scheme with clamped nonnegative values and zero-flux grid boundaries; `alpha = 1.2*diffusion*dt/substeps`, with `alpha <= 0.20`, conservatively under the ideal 0.25 von Neumann bound for 2D, h=1. Includes decay and event injection. This is numerical signal diffusion, not photons actually diffusing through air.

**"Occlusion"**: ordered layers plus attenuation of foreground scanlines by derived silhouette alpha. Not 3D geometry depth inference or physically accurate self-shadowing.

**"Density"**: a finite number of software particles (max 120), no physical mass or measured density.

## 5. Testing

`python -m unittest discover -s tests -p test_forest.py -v` (the integration test securely extracts the included unmodified v0.3 archive into a temporary directory).

- 21 Python unit tests (original hashes, Mesh adapter, generated PNG pixels, source classification, safety limits, diffusion numerical stability and dt behavior, live writer, positive/negative monochrome calibration).
- 50 synthetic scenario sweeps * 160 steps = **8,000 model steps**, 50 encoded real PNGs (see `results/50_scenario_report.json`); no automatic claim of 50 independent model versions.
- Actual Chromium desktop and mobile viewport tests, with loaded 8/8 textures, pixel updates, pause/resume and no JavaScript errors (`results/browser_checks.json`). The Chromium test uses the inlined HTML because local navigation is blocked by the sandbox.
- 2.20-second headless live process test generated 22 successive PNG images at measured 10 image writes/sec; this is host-specific, no guarantee about user's CPU/GPU.
- Independent cloud Floot test confirmed 2D no-flux Laplacian mass conservation to about 4.4e-16 floating-point error. The entire ZIP has **not** been deployed in that cloud runtime.

## 6. Policy, security and rights

- Original art and core source material: user-supplied; preserved without changes; never relabeled as public domain.
- No APIs are automatically called; no keys, network, browser camera or hidden data collection.
- Numeric inputs and outputs are strictly bounded; original model checkpoints stay untouched.
- Source references below in `docs/SOURCING_AND_DESIGN.md`; the program reimplements known techniques and does not copy external proprietary engines, code, model weights or game assets.
- This package is for author-controlled development and should not be silently installed or publicly uploaded.
