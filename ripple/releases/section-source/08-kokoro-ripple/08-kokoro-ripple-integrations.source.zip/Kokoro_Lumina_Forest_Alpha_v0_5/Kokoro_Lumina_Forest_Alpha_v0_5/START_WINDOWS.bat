@echo off
cd /d "%~dp0"
start "" "Kokoro_Lumina_Forest_Offline_Alpha.html"
