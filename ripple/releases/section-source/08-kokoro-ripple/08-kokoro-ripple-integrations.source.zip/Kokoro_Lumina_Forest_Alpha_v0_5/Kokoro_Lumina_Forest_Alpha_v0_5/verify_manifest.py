from pathlib import Path
import hashlib,sys
root=Path(__file__).resolve().parent
manifest=root/'MANIFEST.sha256'
if not manifest.exists():raise SystemExit('missing manifest')
errors=[];n=0
for line in manifest.read_text().splitlines():
 if not line.strip():continue
 digest,name=line.split('  ',1)
 target=root/name
 if not target.is_file() or hashlib.sha256(target.read_bytes()).hexdigest()!=digest:errors.append(name)
 n+=1
print(f'Files checked: {n}; mismatches: {len(errors)}')
if errors:raise SystemExit('mismatched:\n'+'\n'.join(errors))
