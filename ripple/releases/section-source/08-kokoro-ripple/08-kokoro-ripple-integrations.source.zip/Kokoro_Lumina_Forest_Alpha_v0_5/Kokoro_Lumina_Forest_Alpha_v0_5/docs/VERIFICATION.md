# Verification status — Alpha 0.5

**MEASURED:** 21 Python unit checks, headless raster encodes, browser canvas pixel changes, two viewport screenshots, live PNG writer frame timestamps, CPU encode wall-clock. All measured against this container's CPU, not user's computer.

**NUMERICALLY SIMULATED:** 8,000 virtual neuron and visual-control steps across 50 predeclared patterns; 4 gene-profile event rate series; diffusion, glow, occlusion and particle count. The signals are mathematical/generated controls, not recorded neural, optical or emotional information.

**CLOUD:** The connected Floot Linux VM executed an independent 24x24 pure-JavaScript diffusion operator for 80 steps with alpha=0.18. Initial mass 1.0, final 1.0000000000000004, error 4.44e-16. This independently supports the conservation property of the stencil *without decay/injection*. This was **not deployment or full v0.5 package execution**.

**NO CLAIMS:** No trained Kokoro neural network executed, no original full daughterboards installed, no 3D VRM, no actual optoelectronics, no sentient personality, no true multi-node networking, no claimed measured speedup by fictional colonies.

**Art review:** visual work is a cutout STUDY of superseded character concept art. Bright white edge wedges remain in some hand/leg polygon mattes because source image includes bright floor; no algorithm can establish correct pixels hidden under the original art. This limitation is surfaced in UI and docs rather than claiming automatic production-quality segmentation.

**Performance files:** `results/50_scenario_report.json`, `results/50_scenarios.csv`, `results/browser_checks.json`, `results/live/run_summary.json`. The optimized Python CPU backend uses OpenCV; JS browser uses Canvas2D rather than a GPU skinning shader.
