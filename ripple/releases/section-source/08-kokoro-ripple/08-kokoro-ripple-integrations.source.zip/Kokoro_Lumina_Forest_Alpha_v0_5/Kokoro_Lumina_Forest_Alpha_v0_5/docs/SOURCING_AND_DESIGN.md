# Engineering sources and adoption decisions — 2026-10-13

These are primary technical references consulted for **algorithms or integration patterns**. External libraries and copyrighted game/character assets were NOT copied into this release. The working code was implemented separately using project-owned Ripple programs plus standard Python/OpenCV and browser Canvas2D APIs.

| Open reference | Engineering principle | Decision |
|---|---|---|
| [Godot 2D skeletons](https://docs.godotengine.org/en/4.1/tutorials/animation/2d_skeletons.html) | Split art into polygons with UV coordinates, bones, per-vertex weights | Use real cutout pieces now; full weight-painted mesh requires approved layered art |
| [Unity 2D Sprite Skin](https://docs.unity.cn/Packages/com.unity.2d.animation%4016.0/manual/SpriteSkin.html) | Bone-transformed sprite skinning, CPU/GPU tradeoffs | CPU study masks first; profiler decides future GPU choice |
| [PixiJS 8 Mesh](https://pixijs.com/8.x/guides/components/scene-objects/mesh) | WebGL/WebGPU mesh geometry and UV/indices | Optional future GPU optimization once authored atlas/mesh is ready; not included or claimed running |
| [pixiv three-vrm](https://pixiv.github.io/three-vrm/packages/three-vrm/examples/) | VRM humanoid bones, expression, lookat and animation | Alternative for complete approved 3D character. MIT library available; no real VRM asset connected or rendered |
| [ROS 2 tf2](https://github.com/ros2/ros2_documentation/blob/rolling/source/ROS-Framework/interfaces/About-Tf2/About-Tf2.rst) | Coordinate frames in a time-dependent transform tree | Use clear image-coordinate pivot frames and time-based control; not a ROS 2 node |
| [BehaviorTree.CPP Fallback](https://behaviortree.dev/docs/nodes-library/FallbackNode/) | Bounded task priority and fallback | Fail closed on missing controls; overseer does not autonomously switch to unapproved generators |
| [Godot polygon bone weights](https://docs.godotengine.org/en/4.2/classes/class_polygon2d.html) | Weight association from a skeleton to a textured polygon | Future weight-map editing workflow for artist-supplied layers |
| [Reaction–diffusion discretization](https://www.mysimulator.uk/content/articles/gray-scott-reaction-diffusion.html) | Explicit 5-point Laplacian and timestep stability | Only diffusion operator included; no claim of full Gray–Scott reaction system |

## Design reviews and constraints

1. **Preservation gate**: source poster, v0.1 original JavaScript, v0.7 original ES module, Python reference port, v0.3 Mesh archive, v0.4 Lumina archive preserved byte-for-byte under `upstream/` and `assets/`.
2. **Rigging choice**: approximate explicit masks over false automatic semantic segmentation. The existing source is poster art showing front and back/insets and text, not a layered character asset. Manual masks create a *real, but rough* alpha cutout rig; each bone pivot moves its part independently. Transparent masks and seam quality remain author-review issues.
3. **Motion choice**: periodic bounded displacement and gaze-controlled head pivot with no inferred sentiments. Browser hair divided into slices; CPU hair uses inverse-mapping spatial warp.
4. **Chromatic mapping**: 4 clones of unchanged original v0.1 equation, with input-channel routing and repeatable RGB labels. Color means channel identity only; it has no intrinsic psychological/spiritual semantics.
5. **Diffusion / density / occlusion**: separate bounded display algorithms, not sensor science. Dataset provenance is carried in the control packet.
6. **Forest control**: Chromatic, Motion and Light masters run through one deterministic local coordinator; these are modular software services in one process, NOT physical robots or separate AI agents. Do not confuse cloning numerical state with real parallel speedup.
7. **Production upgrade**: once current canonical art exists, prepare face, eyes, mouth, left/right arms, torso, hair front/back, legs and heels as independent transparent layers and art-specific anchors; then integrate rig weights in Godot/Blender or a registered VRM model. Run motion regression and silhouette overlap tests before release.

## Mathematical boundary

For each profile, original `RippleNeuron.step(rgb, dt)` is called on mapped 0..1 channels. The original weights are unchanged: `D=2R+1.2G-1.4B`, `0.5 du/dt=-u+D`. Four profiles each preserve threshold adaptation and refractory logic. The color output is a normalized rate-weighted blend of engineering color labels; no photo spectral power or real light field is measured.

The diffusion step for grid `u` with `h=1` is `u_next=u + alpha * (u_left + u_right + u_up + u_down - 4u)` followed by bounded decay and optional activation injection. The geometric raster uses affine cutout pivots, `cv2.remap` for hair, layer-alpha composition, and finite particles. No diffusion neural network or generative image model is used.
