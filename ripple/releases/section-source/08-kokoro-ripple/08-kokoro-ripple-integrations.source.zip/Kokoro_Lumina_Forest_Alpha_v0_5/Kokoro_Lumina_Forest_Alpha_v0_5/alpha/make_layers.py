"""Explicit human-reviewed polygon study extraction. Neither automatic character recognition nor a canonical design."""
from __future__ import annotations
import hashlib,json
from pathlib import Path
import cv2,numpy as np
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'assets/Adelita_Kokoro_reference_ORIGINAL.png'
# Polygon coordinates in the 1122x1402 poster; artist-reviewable study masks.
PARTS={
'hair_back':{'z':0,'pivot':[550,260],'poly':[(583,9),(627,8),(661,34),(682,87),(662,173),(673,257),(655,380),(634,516),(601,653),(555,735),(510,731),(474,692),(450,712),(418,698),(375,639),(388,569),(399,458),(434,363),(477,247),(478,159),(515,65)]},
'left_leg':{'z':1,'pivot':[598,608],'poly':[(579,545),(638,525),(688,596),(712,768),(701,883),(728,1010),(759,1172),(763,1276),(728,1344),(683,1326),(651,1276),(638,1110),(579,1012),(550,930),(522,798),(519,692)]},
'right_leg':{'z':2,'pivot':[727,619],'poly':[(667,530),(737,548),(785,662),(817,782),(834,905),(878,1036),(903,1160),(932,1240),(922,1312),(868,1329),(829,1298),(806,1193),(756,1054),(719,937),(685,786),(647,631)]},
'hair_front':{'z':6,'pivot':[598,130],'poly':[(571,12),(615,8),(652,32),(673,85),(657,140),(653,206),(639,259),(615,304),(579,318),(555,254),(529,197),(506,133),(526,56)]},
'body':{'z':3,'pivot':[652,485],'poly':[(573,230),(638,209),(691,224),(728,265),(741,342),(746,409),(747,480),(779,548),(760,624),(730,681),(681,674),(633,649),(597,607),(561,569),(539,484),(552,412),(545,349)]},
'far_arm':{'z':4,'pivot':[578,272],'poly':[(180,207),(226,178),(258,218),(296,221),(356,232),(422,235),(490,215),(552,213),(593,219),(612,264),(585,297),(530,295),(474,283),(422,290),(360,293),(313,287),(270,295),(235,328),(200,319),(188,282),(175,260)]},
'near_arm':{'z':5,'pivot':[731,391],'poly':[(714,339),(753,359),(768,401),(771,458),(795,510),(797,574),(818,653),(838,731),(808,748),(784,716),(765,659),(750,598),(707,540),(688,487),(683,419)]},
'head':{'z':7,'pivot':[600,130],'poly':[(566,26),(619,17),(661,43),(672,88),(660,132),(685,165),(678,194),(650,231),(602,246),(560,222),(535,179),(520,123),(526,72)]},
}

def generate():
    raw=SRC.read_bytes();im=cv2.imread(str(SRC),cv2.IMREAD_COLOR)
    if im is None or im.shape[:2]!=(1402,1122):raise ValueError('Reference geometry changed: do not auto-fit masks')
    out=ROOT/'assets/rig_layers';out.mkdir(parents=True,exist_ok=True)
    scene=[]
    for name,info in PARTS.items():
        points=np.array(info['poly'],dtype=np.int32)
        x,y,w,h=cv2.boundingRect(points);margin=16;x=max(0,x-margin);y=max(0,y-margin);w=min(im.shape[1]-x,w+2*margin);h=min(im.shape[0]-y,h+2*margin)
        mask=np.zeros(im.shape[:2],np.uint8);cv2.fillPoly(mask,[points],255)
        # Soft-edge matte; semantic edges are not automatically known.
        mask=cv2.GaussianBlur(mask,(5,5),0)
        rgba=cv2.cvtColor(im[y:y+h,x:x+w],cv2.COLOR_BGR2BGRA)
        rgba[:,:,3]=mask[y:y+h,x:x+w]
        file=out/(name+'.png');cv2.imwrite(str(file),rgba)
        entry={'id':name,'z':info['z'],'pivot':info['pivot'],'x':x,'y':y,'w':w,'h':h,'file':'assets/rig_layers/'+name+'.png',
            'pixel_sha256':hashlib.sha256(file.read_bytes()).hexdigest(), 'mask':'manually specified approximate polygon; alpha edges feathered'}
        scene.append(entry)
    data={'schema':'lumina.rig.v1','character':'Adelita concept study — NOT canonical current Kokoro appearance','source_asset':'assets/Adelita_Kokoro_reference_ORIGINAL.png','source_sha256':hashlib.sha256(raw).hexdigest(),'coordinate_size':[1122,1402],'layers':sorted(scene,key=lambda p:p['z']),'scale_reference_only':True,
    'warnings':['The poster is old concept artwork, not the current canonical appearance.','Layers are approximate hand-authored polygon masks, not a learned or high-fidelity character segmentation.','Articulated motion can reveal missing occluded body regions; those pixels cannot be reconstructed from this poster.']}
    (out/'rig.json').write_text(json.dumps(data,indent=2))
    return data
if __name__=='__main__':print(json.dumps({'layers':len(generate()['layers'])}))
