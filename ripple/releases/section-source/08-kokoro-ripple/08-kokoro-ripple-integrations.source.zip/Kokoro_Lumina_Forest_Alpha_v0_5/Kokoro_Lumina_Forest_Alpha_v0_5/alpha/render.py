"""CPU rasterization of an eight-piece articulated art rig and spatial hologram field.
Cutout transformations are real image warps; original poster bytes never change.
Requires numpy, opencv-python, Pillow (only for GIF export).
"""
from __future__ import annotations
import json,math,hashlib,time
from pathlib import Path
import cv2,numpy as np
from .forest import Overseer,demo_packet
ROOT=Path(__file__).resolve().parents[1]

class RigRenderer:
    def __init__(self,size=(448,560),root=ROOT):
        w,h=size
        if not (256<=w<=1000 and 320<=h<=1200) or abs(w/h-1122/1402)>.03:
            raise ValueError('size must approximately match original poster aspect ratio, within safe bounds')
        self.w=w;self.h=h;self.root=Path(root)
        self.scale=min(w/1122,h/1402)
        rig=json.loads((self.root/'assets/rig_layers/rig.json').read_text())
        source=(self.root/rig['source_asset']).read_bytes()
        if hashlib.sha256(source).hexdigest()!=rig['source_sha256']:raise ValueError('Original reference sha256 mismatch')
        self.layers=[]
        for L in rig['layers']:
            filepath=self.root/L['file'];contents=filepath.read_bytes()
            if hashlib.sha256(contents).hexdigest()!=L['pixel_sha256']:raise ValueError('Rig layer asset changed')
            asset=cv2.imdecode(np.frombuffer(contents,np.uint8),cv2.IMREAD_UNCHANGED)
            if asset is None or asset.ndim!=3 or asset.shape[2]!=4:raise ValueError('Not a transparent PNG layer')
            scaled=cv2.resize(asset,(max(1,round(asset.shape[1]*self.scale)),max(1,round(asset.shape[0]*self.scale))),interpolation=cv2.INTER_AREA)
            self.layers.append((L,scaled))
        self._grid={}
        self._yy,self._xx=np.indices((self.h,self.w),dtype=np.float32)

    @staticmethod
    def over(dst,piece):
        alpha=piece[:,:,3:4].astype(np.float32)/255
        dst[:]=np.uint8(np.clip(piece[:,:,:3].astype(np.float32)*alpha + dst.astype(np.float32)*(1-alpha),0,255))

    def background(self,t):
        y=self._yy/self.h;x=self._xx/self.w
        lum=np.clip(1-y*.38+.07*np.sin(2*np.pi*(x*.8+y*.4+t*.04)),0,1)
        out=np.empty((self.h,self.w,3),np.uint8)
        out[:,:,0]=np.uint8(42*lum+6);out[:,:,1]=np.uint8(28*lum+9);out[:,:,2]=np.uint8(17*lum+7)
        return out

    def _warp_layer(self,meta,layer,pose,t):
        part=layer
        # Vertex-like bounded nonlinear deformation for soft hair (sampled inverse map)
        # and torso breath; these are true pixel-remapping calculations.
        if meta['id'] in ('hair_back','hair_front','body'):
            hh,ww=part.shape[:2]
            key=(hh,ww)
            if key not in self._grid:self._grid[key]=np.indices((hh,ww),dtype=np.float32)
            yy,xx=self._grid[key]
            name=meta['id']
            amp=self.scale*(6 if name=='hair_back' else 2.5 if name=='hair_front' else .8)
            yrel=yy/max(1,hh)
            shift=amp*np.sin(5*yrel+t*1.3)*yrel
            # source x = destination x - requested local displacement
            part=cv2.remap(part,(xx-shift).astype(np.float32),yy,cv2.INTER_LINEAR,borderMode=cv2.BORDER_CONSTANT,borderValue=(0,0,0,0))
        s=self.scale;angle=float(pose['angle']);pivot=meta['pivot'];x=meta['x'];y=meta['y']
        m=cv2.getRotationMatrix2D(((pivot[0]-x)*s,(pivot[1]-y)*s),angle,1.)
        m[0,2]+=(x+float(pose['dx']))*s
        m[1,2]+=(y+float(pose['dy']))*s
        return cv2.warpAffine(part,m,(self.w,self.h),flags=cv2.INTER_LINEAR,
                              borderMode=cv2.BORDER_CONSTANT,borderValue=(0,0,0,0))

    def image(self,state,forest):
        if state.get('schema')!='lumina.forest.alpha.v1':raise ValueError('Require actual forest state packet')
        t=state['elapsed_s'];out=self.background(t)
        effects=state['effects'];chromatic=state['chromatic']
        # Diffusion grid is a mathematically calculated state, not physically simulated photons.
        intensity=cv2.resize(forest.light.field,(self.w,self.h),interpolation=cv2.INTER_CUBIC)
        glow=np.clip(intensity*120*effects['heart_intensity'],0,65).astype(np.uint8)
        blend=state['chromatic']['blend_rgb']
        for channel in range(3):
            out[:,:,channel]=np.clip(out[:,:,channel].astype(np.int16)+(glow.astype(np.int16)*blend[2-channel]//255),0,255).astype(np.uint8)
        # A light-density particle field (bounded); source positions deterministic
        count=effects['particle_count']
        for k in range(count):
            x=int((.5+.47*math.sin(k*1.137+t*(.08+.001*(k%5))))*self.w)
            y=int((.5+.47*math.sin(k*2.019-t*(.10+.003*(k%7))))*self.h)
            cv2.circle(out,(x,y),1+(k%3==0),(int(69+29*effects['density']),int(89+75*effects['density']),155),-1,cv2.LINE_AA)
        silhouette=np.zeros((self.h,self.w),np.uint8)
        # Painter's algorithm defines character self-occlusion, not real scene depth reconstruction.
        for meta,rgba in self.layers:
            warped=self._warp_layer(meta,rgba,state['rig'][meta['id']],t)
            silhouette=np.maximum(silhouette,warped[:,:,3]);self.over(out,warped)
        # Foreground hologram overlays with actual alpha occlusion.
        # Where occlusion increases, attenuate scanner lines on character silhouettes.
        occ=effects['occlusion']
        y=int((t*.12%1)*self.h)
        scan=np.zeros_like(out)
        cv2.line(scan,(0,y),(self.w-1,y),(130,230,160),1,cv2.LINE_AA)
        vis=(.18*(1-occ*(silhouette.astype(np.float32)/255)))[:,:,None]
        out=np.uint8(np.clip(out.astype(np.float32)+scan.astype(np.float32)*vis,0,255))
        # Observably luminous heart energy derived from numeric control, NOT self-reported emotion.
        hx,hy=int(699*self.scale),int(266*self.scale)
        if 0<=hx<self.w and 0<=hy<self.h:
            halo=np.zeros_like(out);rad=max(2,int(self.scale*(13+18*effects['heart_intensity'])))
            cv2.circle(halo,(hx,hy),rad,(130,135,255),-1,cv2.LINE_AA)
            halo=cv2.GaussianBlur(halo,(0,0),max(2,rad/2))
            out=np.uint8(np.clip(out.astype(np.float32)+halo.astype(np.float32)*(.13+.16*effects['heart_intensity']),0,255))
        # Corner calibration line indicates engineering study, not canonical model.
        cv2.putText(out,'LUMINA / RIG STUDY ALPHA 0.5',(9,max(17,int(self.h*.037))),cv2.FONT_HERSHEY_SIMPLEX,.35,(165,219,223),1,cv2.LINE_AA)
        cv2.putText(out,'SIMULATED CONTROL' if state['synthetic'] else 'EXPLICIT EXTERNAL CONTROL',
                    (9,self.h-12),cv2.FONT_HERSHEY_SIMPLEX,.37,(140,180,195),1,cv2.LINE_AA)
        return out

def render_frames(output,frames=36,fps=12,size=(448,560),gif=False):
    if not (1<=frames<=360 and 1<=fps<=30):raise ValueError('frame count and rate bounded')
    out=Path(output);out.parent.mkdir(parents=True,exist_ok=True)
    overseer=Overseer();renderer=RigRenderer(size=size)
    png=[];measure=[];last=None
    for i in range(frames):
        t0=time.perf_counter();state=overseer.step(1/fps,demo_packet(i/fps))
        raster=renderer.image(state,overseer)
        ok,buf=cv2.imencode('.png',raster)
        if not ok:raise RuntimeError('PNG encoding failed')
        png.append(bytes(buf));last=state
        measure.append((time.perf_counter()-t0)*1000)
    if gif:
        from PIL import Image
        import io
        imgs=[Image.open(io.BytesIO(x)).convert('RGB') for x in png]
        imgs[0].save(out,save_all=True,append_images=imgs[1:],duration=int(1000/fps),loop=0,optimize=False)
    else:
        out.write_bytes(png[-1])
    return {'output':str(out),'frames':frames,'fps_simulated':fps,'median_frame_ms_measured':round(float(np.median(measure)),3),
        'frame_ms_p95_measured':round(float(np.percentile(measure,95)),3),'last_state':last}
