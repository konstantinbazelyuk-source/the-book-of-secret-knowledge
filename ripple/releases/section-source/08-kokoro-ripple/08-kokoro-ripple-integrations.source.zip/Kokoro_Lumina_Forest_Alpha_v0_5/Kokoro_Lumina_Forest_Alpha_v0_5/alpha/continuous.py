"""Bounded headless current-frame writer. No daemon installed; Ctrl+C stops.
Atomic rename avoids half-written image and state artifacts.
"""
from __future__ import annotations
import argparse,json,os,time
from pathlib import Path
from .forest import Overseer,demo_packet
from .render import RigRenderer
import cv2

def run(out='results/live',seconds=2.0,fps=10,size=(448,560),limit=10000):
    if not 1<=fps<=20:raise ValueError('headless limit 1-20 frames/sec')
    if not 0<=seconds<=7200:raise ValueError('duration 0 (until interrupted) or <=2h')
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    forest=Overseer();rig=RigRenderer(size=size)
    start=time.perf_counter();next_tick=start;count=0;wall=[]
    try:
        while count<limit and (seconds==0 or time.perf_counter()-start<seconds):
            now=time.perf_counter()
            if now<next_tick:time.sleep(min(.025,next_tick-now));continue
            t0=time.perf_counter();state=forest.step(1/fps,demo_packet(forest.time))
            ok,buf=cv2.imencode('.png',rig.image(state,forest))
            if not ok:raise RuntimeError('encoder failure')
            staging=out/'latest.png.tmp';staging.write_bytes(bytes(buf));os.replace(staging,out/'latest.png')
            data={'classification':'SIMULATED controls / MEASURED wall clock','frame_index':count+1,
                  'simulated_time_s':state['elapsed_s'],'source':state['source'],'state':state}
            tmp=out/'latest_state.json.tmp';tmp.write_text(json.dumps(data));os.replace(tmp,out/'latest_state.json')
            wall.append((time.perf_counter()-t0)*1000);count+=1;next_tick+=1/fps
            # If machine falls behind, skip missed deadlines, not steps of simulation time.
            if time.perf_counter()-next_tick>1/fps:next_tick=time.perf_counter()
    except KeyboardInterrupt:pass
    elapsed=time.perf_counter()-start
    result={'frames':count,'wall_s_measured':round(elapsed,4),'observed_frame_writes_per_s':round(count/max(.001,elapsed),3),
            'simulation_fps_requested':fps,'median_compute_ms_measured':round(sorted(wall)[len(wall)//2],3) if wall else None,
            'state_source':'synthetic-demo','background_service_installed':False}
    (out/'run_summary.json').write_text(json.dumps(result,indent=2))
    return result
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',default='results/live');p.add_argument('--seconds',type=float,default=2);p.add_argument('--fps',type=int,default=10);a=p.parse_args();print(json.dumps(run(a.out,a.seconds,a.fps),indent=2))
