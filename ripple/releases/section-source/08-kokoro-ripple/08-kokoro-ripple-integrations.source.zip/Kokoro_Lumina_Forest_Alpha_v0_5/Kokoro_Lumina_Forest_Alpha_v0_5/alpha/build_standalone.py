"""Bundle offline HTML as a single file with original project-owned neuron source and PNG study layers."""
import base64,json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def build():
    markup=(ROOT/'web/index.html').read_text()
    manifest=json.loads((ROOT/'assets/rig_layers/rig.json').read_text())
    for layer in manifest['layers']:
        data=(ROOT/layer['file']).read_bytes()
        layer['file']='data:image/png;base64,'+base64.b64encode(data).decode('ascii')
    scripts={
        '../upstream/ripple_core_v0_1.js':(ROOT/'upstream/ripple_core_v0_1.js').read_text(),
        '../upstream/quaternary-port-v04.js':(ROOT/'upstream/quaternary-port-v04.js').read_text(),
        'rig_data.js':'window.LUMINA_RIG='+json.dumps(manifest,separators=(',',':'))+';',
        'rig_app.js':(ROOT/'web/rig_app.js').read_text(),
    }
    for src,code in scripts.items():
        old=f'<script src="{src}"></script>'
        if old not in markup:raise ValueError('missing script tag '+src)
        markup=markup.replace(old,'<script>\n'+code.replace('</script>','<\\/script>')+'\n</script>')
    orig=(ROOT/'assets/Adelita_Kokoro_reference_ORIGINAL.png').read_bytes()
    markup=markup.replace('../assets/Adelita_Kokoro_reference_ORIGINAL.png','data:image/png;base64,'+base64.b64encode(orig).decode('ascii'))
    path=ROOT/'Kokoro_Lumina_Forest_Offline_Alpha.html';path.write_text(markup)
    return path
if __name__=='__main__':print(build())
