from .render import render_frames
import argparse,json
p=argparse.ArgumentParser(description='Lumina forest 2D study rig / Alpha 0.5')
p.add_argument('--out',default='results/alpha_preview.gif')
p.add_argument('--frames',type=int,default=36)
p.add_argument('--fps',type=int,default=12)
p.add_argument('--width',type=int,default=448)
p.add_argument('--height',type=int,default=560)
a=p.parse_args()
print(json.dumps(render_frames(a.out,a.frames,a.fps,(a.width,a.height),a.out.endswith('.gif')),indent=2))
