(()=>{'use strict';
const $=id=>document.getElementById(id);const canvas=$('scene'),ctx=canvas.getContext('2d',{alpha:false});
const S=canvas.width/1122,SP=['ember','verdant','azure','violet'],COL=['#fa7589','#69efb7','#67b7ff','#c389f6'],MAP=[[0,1,2],[1,2,0],[2,0,1],[1,0,2]];
const rig=window.LUMINA_RIG;
if(!rig||rig.schema!=='lumina.rig.v1')throw new Error('Missing rig metadata');
const images={},particles=Array.from({length:120},(_,i)=>({x:.5+.48*Math.sin(i*1.137),y:.5+.48*Math.sin(i*2.019)}));
for(const layer of rig.layers){const im=new Image();im.onload=()=>{images[layer.id]=im;checkLoaded()};im.onerror=()=>{$('status').textContent='Missing layer: '+layer.id};im.src=layer.file;}
function checkLoaded(){if(Object.keys(images).length===rig.layers.length)$('status').textContent='8/8 ART LAYERS LOADED · FOREST RUNNING';}
let nodes=SP.map(()=>new RippleNeuron()),quad=new RippleQPort(),t=0,last=null,playing=true,frames=0,frameT=0,fps=0,total=0,monochromeCount=0,monochromeDuration=0,drawCount=0,counts=[0,0,0,0],rate=[0,0,0,0],dom=0,q=2,recorder=null;
let field=new Float32Array(48*48);field[24*48+24]=1;
const controls=['look','density','diffusion','occlusion','heart','drive','speech'];const val=name=>Number($(name).value);
for(const id of controls)$(id).addEventListener('input',()=>{$(id+'V').textContent=Number($(id).value).toFixed(2)});
function update(dt){t+=dt;const input=[Math.max(0,Math.min(1,val('drive')+.12*Math.sin(t*.8))),.25+.06*Math.cos(t*.6),.12];
 for(let i=0;i<4;i++){let r=nodes[i].step(MAP[i].map(k=>input[k]),dt);counts[i]+=r.count;rate[i]=r.rate;total+=r.count;if(i===0)q=quad.step(r.drive);}
 const sum=rate.reduce((a,b)=>a+b,0),ratios=rate.map(r=>sum>0?r/sum:0);dom=Math.max(...ratios);monochromeCount=dom>=.85&&sum>=.15?monochromeCount+1:0;monochromeDuration=dom>=.85&&sum>=.15?monochromeDuration+dt:0;
 const wanted=1.2*val('diffusion')*dt,steps=Math.max(1,Math.ceil(wanted/.20)),alpha=wanted/steps;for(let step=0;step<steps;step++){const src=new Float32Array(field);for(let y=0;y<48;y++)for(let x=0;x<48;x++){
 const at=(x,y)=>src[Math.min(47,Math.max(0,y))*48+Math.min(47,Math.max(0,x))],i=y*48+x;
 field[i]=Math.max(0,Math.min(1,(src[i]+alpha*(at(x+1,y)+at(x-1,y)+at(x,y+1)+at(x,y-1)-4*src[i]))));}}for(let i=0;i<field.length;i++)field[i]*=Math.max(0,1-.15*dt);
 if(counts[0]>0){field[24*48+24]=Math.min(1,field[24*48+24]+.12);counts[0]=0;}
}
function bone(id){const look=val('look');const p={head:[3.5*Math.sin(t*.65)+look*4,look*5,0],hair_back:[2.5*Math.sin(t*.52),4*Math.sin(t*.72),0],hair_front:[.8*Math.sin(t*.62),look,0],body:[.65*Math.sin(t*.9),0,2*Math.sin(t*2*Math.PI/4.2)],far_arm:[-1.5*Math.sin(t*.65)-.25,0,0],near_arm:[2.8*Math.sin(t*.65),0,0],left_leg:[.5*Math.sin(t*.4),0,0],right_leg:[-.5*Math.sin(t*.4),0,0]};return p[id];}
function layerDraw(l){const im=images[l.id];if(!im)return;const [ang,dx,dy]=bone(l.id),[px,py]=l.pivot;
 ctx.save();ctx.translate((px+dx)*S,(py+dy)*S);ctx.rotate(ang*Math.PI/180);ctx.translate(-px*S,-py*S);
 const destX=l.x*S,destY=l.y*S,destW=l.w*S,destH=l.h*S;
 if(l.id.startsWith('hair_')){
  const slices=18;for(let j=0;j<slices;j++){
   const ya=j*im.height/slices,yb=(j+1)*im.height/slices;
   const shift=(l.id==='hair_back'?6:2.5)*S*Math.sin(5*(j/slices)+t*1.3)*j/slices;
   ctx.drawImage(im,0,ya,im.width,yb-ya,destX+shift,destY+ya/im.height*destH,destW,(yb-ya)/im.height*destH+.2);
  }
 }else ctx.drawImage(im,destX,destY,destW,destH);
 ctx.restore();
 if($('skeletal').checked){ctx.beginPath();ctx.arc(px*S,py*S,4,0,Math.PI*2);ctx.fillStyle='#89f8e5';ctx.fill()}
}
function draw(){const W=canvas.width,H=canvas.height,oc=val('occlusion'),den=val('density'),heart=val('heart');
 const gr=ctx.createLinearGradient(0,0,120,H);gr.addColorStop(0,'#182737');gr.addColorStop(1,'#0a1223');ctx.fillStyle=gr;ctx.fillRect(0,0,W,H);
 // Draw actual diffused grid over background with measured numerical field.
 ctx.save();ctx.globalCompositeOperation='screen';for(let y=0;y<48;y++)for(let x=0;x<48;x++){const v=field[y*48+x];if(v<.008)continue;const su=rate.reduce((a,b)=>a+b,0);const geneColor=[75,197,218].map((fallback,c)=>su>1e-8?Math.round(rate.reduce((acc,z,k)=>acc+z*parseInt(COL[k].slice(1+2*c,3+2*c),16),0)/su):fallback);ctx.fillStyle=`rgba(${geneColor[0]},${geneColor[1]},${geneColor[2]},${Math.min(.22,v*.35)})`;ctx.fillRect(x*W/48,y*H/48,W/48+1,H/48+1)}ctx.restore();
 const partCount=Math.floor(120*den*(.3+.7*heart));ctx.fillStyle='rgba(130,228,214,.42)';
 for(let k=0;k<partCount;k++){const x=(.5+.47*Math.sin(k*1.137+t*(.08+.001*(k%5))))*W,y=(.5+.47*Math.sin(k*2.019-t*(.10+.003*(k%7))))*H;ctx.fillRect(x,y,1.2,1.2)}
 for(const l of rig.layers)layerDraw(l);
 ctx.globalAlpha=.32*(1-oc*.7);ctx.strokeStyle='#8adada';ctx.lineWidth=1;const y=(t*.12%1)*H;ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke();ctx.globalAlpha=1;
 const hx=699*S,hy=266*S,r=14*S+heart*27*S;let glow=ctx.createRadialGradient(hx,hy,1,hx,hy,r);glow.addColorStop(0,`rgba(255,125,166,${heart*.52})`);glow.addColorStop(1,'rgba(255,125,166,0)');ctx.fillStyle=glow;ctx.beginPath();ctx.arc(hx,hy,r,0,2*Math.PI);ctx.fill();
 ctx.fillStyle='#b1d9e0';ctx.font='13px monospace';ctx.fillText('LUMINA / RIG ALPHA 0.5',15,25);ctx.font='11px monospace';ctx.fillStyle='#eac793';ctx.fillText('SYNTHETIC / MANUAL CONTROL — NOT COGNITION',15,H-15);
}
function telemetry(){const max=rate.reduce((m,v,i)=>v>rate[m]?i:m,0);$('mono').textContent=monochromeDuration>=2?'Monochrome detected in computed rates: '+SP[max]:'Monochrome: not detected';$('events').textContent=total;$('q').textContent=['−1','−0','0','+1'][q];$('elapsed').textContent=t.toFixed(1);$('fps').textContent=String(fps);const genes=$('genes');genes.innerHTML=SP.map((g,i)=>`<div class="row"><small>${g}</small><div class="meter-color"><span style="background:${COL[i]};width:${Math.min(100,rate[i]*40)}%"></span></div><small>${rate[i].toFixed(2)} Hz</small></div>`).join('');}
function loop(ts){if(last===null){last=ts;frameT=ts;}const delta=Math.max(.001,Math.min(.05,(ts-last)/1000));last=ts;if(playing){update(delta);draw();frames++;drawCount++}if(ts-frameT>=900){fps=Math.round(frames*1000/(ts-frameT));frames=0;frameT=ts;telemetry();}requestAnimationFrame(loop)}
$('pause').onclick=()=>{playing=!playing;$('pause').textContent=playing?'Pause':'Resume'};
$('reset').onclick=()=>{nodes=SP.map(()=>new RippleNeuron());quad=new RippleQPort();field=new Float32Array(48*48);field[24*48+24]=1;counts=[0,0,0,0];rate=[0,0,0,0];t=0;total=0;monochromeCount=0;monochromeDuration=0;drawCount=0;q=2;draw();telemetry()};
$('snapshot').onclick=()=>{const a=document.createElement('a');a.download='kokoro-lumina-alpha.png';a.href=canvas.toDataURL('image/png');a.click()};
$('record').onclick=()=>{if(recorder){recorder.stop();return;}if(!canvas.captureStream||typeof MediaRecorder==='undefined'){alert('Recording unsupported; PNG export available');return;}const stream=canvas.captureStream(20),chunks=[];try{recorder=new MediaRecorder(stream,{mimeType:MediaRecorder.isTypeSupported('video/webm;codecs=vp8')?'video/webm;codecs=vp8':'video/webm'});recorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data)};recorder.onstop=()=>{const a=document.createElement('a'),url=URL.createObjectURL(new Blob(chunks,{type:'video/webm'}));a.download='kokoro-lumina-alpha.webm';a.href=url;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);stream.getTracks().forEach(x=>x.stop());recorder=null;$('record').textContent='Record WebM'};recorder.start(250);$('record').textContent='Stop recording';}catch(e){recorder=null;stream.getTracks().forEach(x=>x.stop());alert(String(e))}};
document.addEventListener('visibilitychange',()=>{if(document.hidden){playing=false;$('pause').textContent='Resume'}});requestAnimationFrame(loop);
window.__luminaForestDebug=()=>({t,drawFrames:drawCount,synthetic:true,loadedLayers:Object.keys(images).length,alpha:Math.min(.20,1.2*val('diffusion')*.05),events:total,monochromeCount,modelConnected:false});
})();
