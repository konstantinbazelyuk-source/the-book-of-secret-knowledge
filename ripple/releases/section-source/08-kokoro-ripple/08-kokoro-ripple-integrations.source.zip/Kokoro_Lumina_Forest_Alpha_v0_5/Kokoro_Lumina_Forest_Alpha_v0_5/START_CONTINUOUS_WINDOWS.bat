@echo off
cd /d "%~dp0"
py -3 -m alpha.continuous --out results\live --seconds 0 --fps 10
pause
