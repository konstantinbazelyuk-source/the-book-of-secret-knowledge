"""50 predeclared deterministic ALPHA scenarios, not 50 independently designed model versions."""
from __future__ import annotations
import csv,hashlib,json,math,statistics,sys,time
from pathlib import Path
import numpy as np,cv2
from matplotlib import pyplot as plt
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from alpha.forest import Overseer,demo_packet,GENES
from alpha.render import RigRenderer

def run():
 out=ROOT/'results';out.mkdir(exist_ok=True);r=RigRenderer((320,400))
 records=[];trace=[];errors=[];variant_examples=[]
 for k in range(50):
  forest=Overseer(max_particles=80,seed=k)
  # Independent scenario inputs for changing luminance, density, occlusion, diffusion and frame step.
  dt=[.025,.05,.075,.10][k%4];timeseries=[];state=None
  for i in range(160):
   t=i*dt
   p=demo_packet(t)
   p['rgb']=[max(0.,min(1.,.5+.45*math.sin(.21*k+t*.87))),
             max(0.,min(1.,.30+.25*math.cos(.19*k+t*.41))),
             max(0.,min(1.,.30+.28*math.sin(.12*k+t*.52)))]
   p['density']=(k%11)/10;p['diffusion']=(k%9)/8;p['occlusion']=(k%7)/6
   p['heart']=(k%6)/5;p['look_x']=math.sin(t+1)*.8
   p['scene_epoch']=k
   try:state=forest.step(dt,p)
   except Exception as exc:errors.append({'scenario':k,'step':i,'type':type(exc).__name__});break
   ch=state['chromatic']
   values=[ch['profiles'][g]['rate'] for g in GENES]
   if not all(math.isfinite(x) for x in values):errors.append({'scenario':k,'reason':'nonfinite values'})
   if not all(.15<=ch['profiles'][g]['theta']<=2.50 for g in GENES):errors.append({'scenario':k,'reason':'bad threshold'})
   if not .0<=state['light_field']['grid_max']<=1.0:errors.append({'scenario':k,'reason':'bad density'})
   if k in (0,10,25,49) and i%8==0:trace.append({'scenario':k,'t':round(t,3),**{g:round(ch['profiles'][g]['rate'],5) for g in GENES}})
   timeseries.append(ch['monochrome_emergent'])
  if state is None:continue
  tic=time.perf_counter();img=r.image(state,forest)
  success,encoded=cv2.imencode('.png',img)
  if not success:errors.append({'scenario':k,'reason':'encode failure'});continue
  filehash=hashlib.sha256(bytes(encoded)).hexdigest()
  elapsed=(time.perf_counter()-tic)*1000
  records.append({'scenario':k,'dt':dt,'sample_count':160,'synthetic':True,'rendered':True,
                  'render_png_sha256':filehash,'compute_ms_measured':round(elapsed,3),
                  'monochrome_steps':sum(timeseries),'occlusion':p['occlusion'],
                  'density':p['density'],'diffusion':p['diffusion'],'particles':state['effects']['particle_count'],
                  'mean_spatial_density':round(state['light_field']['mean_density'],8)})
  if k in (0,10,25,49):cv2.imwrite(str(out/f'scenario_{k:02d}.png'),img)
 with (out/'50_scenarios.csv').open('w',newline='') as fp:
  writer=csv.DictWriter(fp,fieldnames=list(records[0]));writer.writeheader();writer.writerows(records)
 with (out/'color_gene_trajectories.csv').open('w',newline='') as fp:
  writer=csv.DictWriter(fp,fieldnames=['scenario','t',*GENES]);writer.writeheader();writer.writerows(trace)
 plt.figure(figsize=(11,4.5))
 selected=[v for v in trace if v['scenario']==25]
 for name in GENES:
  plt.plot([v['t'] for v in selected],[v[name] for v in selected],label=name,color='#'+''.join(f'{x:02x}' for x in GENES[name]['color']))
 plt.title('Synthetic Ripple gene-profile event-rate trajectories | scenario 25')
 plt.xlabel('Simulated time (s)');plt.ylabel('Estimated events/s (computed)')
 plt.legend(ncol=4);plt.grid(alpha=.2);plt.tight_layout();plt.savefig(out/'gene_trajectories.png',dpi=140);plt.close()
 report={'classification':'NUMERICALLY SIMULATED signals; measured CPU render times','scenario_count':len(records),'steps':sum(v['sample_count'] for v in records),
   'rendered_pngs':len(records),'all_passed':len(errors)==0 and len(records)==50,
   'failures':errors,'median_render_ms_measured':round(statistics.median(v['compute_ms_measured'] for v in records),3),
   'p95_render_ms_measured':round(float(np.percentile([v['compute_ms_measured'] for v in records],95)),3),
   'monochrome_scenarios':sum(v['monochrome_steps']>0 for v in records),
   'limitations':'50 variations of one Alpha implementation, not 50 complete model-training iterations. CPU host-specific; no trained Kokoro LLM.'}
 (out/'50_scenario_report.json').write_text(json.dumps(report,indent=2))
 if not report['all_passed']:raise RuntimeError(str(report))
 print(json.dumps(report,indent=2))
if __name__=='__main__':run()
