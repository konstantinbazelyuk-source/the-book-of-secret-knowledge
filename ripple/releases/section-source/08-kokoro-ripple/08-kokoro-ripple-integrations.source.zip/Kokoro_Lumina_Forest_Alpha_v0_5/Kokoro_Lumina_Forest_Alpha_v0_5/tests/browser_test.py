import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
R=Path(__file__).resolve().parents[1]
async def run():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  page=await browser.new_page(viewport={'width':1250,'height':880});errors=[]
  page.on('pageerror',lambda err:errors.append(str(err)))
  await page.set_content((R/'Kokoro_Lumina_Forest_Offline_Alpha.html').read_text(),wait_until='domcontentloaded')
  await page.wait_for_timeout(2200)
  before=await page.evaluate('window.__luminaForestDebug()')
  assert before['loadedLayers']==8,before
  assert before['t']>.2,before
  assert not errors,errors
  screen_before=await page.locator('#scene').evaluate('e=>e.toDataURL("image/png")')
  await page.screenshot(path=str(R/'results/browser_desktop.png'))
  await page.locator('#look').fill('1')
  await page.locator('#density').fill('0')
  await page.wait_for_timeout(250)
  screen_after=await page.locator('#scene').evaluate('e=>e.toDataURL("image/png")')
  assert screen_after!=screen_before
  await page.locator('#pause').click()
  a=await page.evaluate('window.__luminaForestDebug().t')
  await page.wait_for_timeout(400)
  b=await page.evaluate('window.__luminaForestDebug().t')
  assert a==b,(a,b)
  await page.locator('#pause').click()
  await page.wait_for_timeout(160)
  assert (await page.evaluate('window.__luminaForestDebug().t'))>b
  await page.set_viewport_size({'width':390,'height':844})
  await page.wait_for_timeout(100)
  await page.screenshot(path=str(R/'results/browser_mobile.png'))
  result={'passed':True,'browser':'headless Chromium','desktop':{'width':1250,'height':880},'mobile':{'width':390,'height':844},'first_debug':before,
          'pixel_change':screen_after!=screen_before,'pause_held':True,'resume_advanced':True,'errors':errors,
          'backend_integration_tested':False,'human_avatar_identity_verified':False}
  (R/'results/browser_checks.json').write_text(json.dumps(result,indent=2))
  print(json.dumps(result,indent=2))
  await browser.close()
if __name__=='__main__':asyncio.run(run())
