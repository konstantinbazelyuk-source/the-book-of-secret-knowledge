from __future__ import annotations
import asyncio,hashlib,json,math,sys,tempfile,unittest,zipfile
from pathlib import Path
import cv2,numpy as np
R=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(R))
from alpha.forest import Overseer,ColorColony,DiffusionMaster,MotionMaster,control,demo_packet,GENES
from alpha.render import RigRenderer,render_frames
from alpha.mesh_bridge import LuminaForestBoard
from alpha.ripple_core import RippleNeuron
from alpha.continuous import run

class ForestTests(unittest.TestCase):
 def test_source_hash(self):
  with zipfile.ZipFile(R/'upstream/Kokoro_Lumina_Ripple_v0_4.zip') as z:
   base='Kokoro_Lumina_Ripple_v0_4/'
   self.assertEqual((R/'upstream/ripple_core_v0_1.js').read_bytes(),z.read(base+'baseline/ripple_core_v0_1.js'))
   self.assertEqual((R/'upstream/ripple_q_v0_7.mjs').read_bytes(),z.read(base+'sources/ripple_q_v0_7.mjs'))
   self.assertEqual((R/'alpha/ripple_core.py').read_bytes(),z.read(base+'baseline/kokoro_mesh/ripple_python.py'))
 def test_original_art_untouched(self):
  with zipfile.ZipFile(R/'upstream/Kokoro_Lumina_Ripple_v0_4.zip') as z:
   self.assertEqual((R/'assets/Adelita_Kokoro_reference_ORIGINAL.png').read_bytes(),z.read('Kokoro_Lumina_Ripple_v0_4/assets/Adelita_Kokoro_reference.png'))
 def test_original_neuron_event(self):
  n=RippleNeuron();r=n.step([.9,0,0],.05)
  self.assertGreater(r['drive'],1);self.assertTrue(math.isfinite(r['rate']))
 def test_malformed_rejected(self):
  for x in [None,{}, {'source':'synthetic-demo','rgb':[1,2,3]}, {'source':'synthetic-demo','rgb':[1,0,0],'other':True},
            {'source':'synthetic-demo','rgb':[float('nan'),0,0]}, {'source':'synthetic-demo','rgb':[True,0,0]}]:
   with self.assertRaises(ValueError):control(x)
 def test_sources_labeled(self):
  x=demo_packet(0.0);r=Overseer().step(.05,x)
  self.assertTrue(r['synthetic']);self.assertEqual(r['source'],'synthetic-demo')
  x['source']='kokoro-reported';r=Overseer().step(.05,x);self.assertFalse(r['synthetic']);self.assertEqual(r['source_claim'],'external-report-unverified')
 def test_time_validation(self):
  for dt in [float('nan'),float('inf'),-.01,0,.6]:
   with self.assertRaises(ValueError):Overseer().step(dt,demo_packet(0))
 def test_four_gene_colors(self):self.assertEqual(len(GENES),4)
 def test_bounded_threshold(self):
  forest=Overseer()
  for i in range(450):
   s=forest.step(.05,demo_packet(i*.05))
   for r in s['chromatic']['profiles'].values():self.assertTrue(.15<=r['theta']<=2.5)
 def test_positive_monochrome_calibration(self):
  f=ColorColony()
  states=[f.step([.25,0,.25],.05) for _ in range(220)]
  self.assertTrue(any(x['monochrome_emergent'] for x in states))
  self.assertEqual(states[-1]['dominant'],'azure')
 def test_no_monochrome_darkness(self):
  f=ColorColony()
  for _ in range(60):
   s=f.step([0,0,0],.05);self.assertFalse(s['monochrome_emergent'])
 def test_diffusion_zero(self):
  f=DiffusionMaster();p=control(demo_packet(0));p['diffusion']=0;p['heart']=0
  first=f.field.copy();f.step(.05,p,0)
  # decay legitimately applies in an otherwise stationary field
  self.assertLess(float(f.field.sum()),float(first.sum()))
 def test_diffusion_stability(self):
  f=DiffusionMaster();p=control(demo_packet(0));p['diffusion']=1
  for _ in range(500):
   z=f.step(.5,p,1);self.assertLessEqual(z['explicit_alpha'],.20+1e-9)
  self.assertTrue(np.isfinite(f.field).all());self.assertTrue(((f.field>=0)&(f.field<=1)).all())
 def test_diffusion_dt_dependency(self):
  a=DiffusionMaster();b=DiffusionMaster();p=control(demo_packet(0))
  a.step(.1,p,0);b.step(.05,p,0);b.step(.05,p,0)
  self.assertLess(float(np.abs(a.field-b.field).mean()),.001)
 def test_density_bounds(self):
  f=Overseer(max_particles=40)
  for v in [0,.1,.5,1.]:
   p=demo_packet(v);p['density']=v;p['heart']=1
   s=f.step(.05,p);self.assertTrue(0<=s['effects']['particle_count']<=40)
 def test_motion_limits(self):
  f=Overseer()
  for i in range(200):
   p=demo_packet(i);p['look_x']=(-1 if i%2 else 1)
   s=f.step(.05,p)
   for name,value in s['rig'].items():
    if isinstance(value,dict):self.assertTrue(-10<=value['angle']<=10)
 def test_mask_count(self):
  rig=json.loads((R/'assets/rig_layers/rig.json').read_text());self.assertEqual(len(rig['layers']),8)
  for l in rig['layers']:
   self.assertEqual(hashlib.sha256((R/l['file']).read_bytes()).hexdigest(),l['pixel_sha256'])
 def test_real_render(self):
  f=Overseer();r=RigRenderer((320,400));s=f.step(.05,demo_packet(0))
  image=r.image(s,f);self.assertEqual(image.shape,(400,320,3));self.assertGreater(int(image.max()),100)
 def test_changed_pose_changes_pixels(self):
  f=Overseer();r=RigRenderer((320,400));a=r.image(f.step(.05,demo_packet(0)),f)
  b=r.image(f.step(.05,demo_packet(1)),f)
  self.assertGreater(float(np.mean(np.abs(a.astype(np.float32)-b.astype(np.float32)))),.1)
 def test_reference_mesh_bridge(self):
  # Independently test exact archived upstream Mesh rather than a presumed /mnt/data path.
  with tempfile.TemporaryDirectory() as temp:
   with zipfile.ZipFile(R/'upstream/Kokoro_Mesh_Ripple_v0_3.zip') as z:
    if any('..' in Path(n).parts for n in z.namelist()):raise ValueError('unsafe zip entry')
    z.extractall(temp)
   base=str(Path(temp)/'Kokoro_Mesh_Ripple_v0_3')
   sys.path.insert(0,base)
   try:
    from kokoro_mesh.runtime import Mesh
    c={'identity':'Kokoro','revision':1}
    request={'user_text':'Render controls only','continuity_capsule':c,'lumina_forest_control':demo_packet(0)}
    out=asyncio.run(Mesh(external={'lumina':LuminaForestBoard()},max_concurrency=2).run(request))
    self.assertEqual(out['boards']['lumina']['status'],'available')
    self.assertFalse(out['boards']['lumina']['rendered'])
    self.assertEqual(out['boards']['lumina']['state']['source'],'synthetic-demo')
   finally:sys.path.remove(base)
 def test_empty_mesh_bridge(self):
  out=asyncio.run(LuminaForestBoard().run({}));self.assertEqual(out['status'],'unavailable')
 def test_continuous_writer(self):
  with tempfile.TemporaryDirectory() as path:
   result=run(path,.35,8,size=(320,400))
   self.assertGreaterEqual(result['frames'],2)
   self.assertTrue((Path(path)/'latest.png').exists())
   self.assertTrue((Path(path)/'latest_state.json').exists())
   self.assertEqual(json.loads((Path(path)/'latest_state.json').read_text())['source'],'synthetic-demo')

if __name__=='__main__':unittest.main()
