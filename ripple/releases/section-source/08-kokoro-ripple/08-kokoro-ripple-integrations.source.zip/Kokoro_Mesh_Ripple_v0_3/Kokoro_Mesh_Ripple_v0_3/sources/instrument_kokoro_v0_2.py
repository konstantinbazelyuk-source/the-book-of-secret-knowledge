"""Read-only instrumentation for Python Kokoro generation.
Usage in your OWN code:
    with TraceRecorder('kokoro_trace.jsonl') as trace:
        with trace.measure_request(queue_depth=0):
            answer=kokoro.generate(prompt)  # YOUR real Kokoro generator
            trace.report_tokens(actual_generated_token_count)
        # Optionally use trace.sample(...) when monitoring a long-lived model
This module does not train, load, or infer with a model by itself.
"""
import contextlib
import json
import os
import sys
import time
from pathlib import Path


def rss_bytes():
    try:
        # Linux process memory (current resident set size), not GPU VRAM.
        with open('/proc/self/statm',encoding='ascii') as f:
            pages=int(f.readline().split()[1])
        return pages*os.sysconf('SC_PAGE_SIZE')
    except (OSError,ValueError,AttributeError,IndexError):
        return None


class TraceRecorder:
    def __init__(self, output):
        self.path=Path(output)
        self.file=None
        self.start_ns=None
        self.token_total=0
        self.queue_depth=0
        self.frame_candidate_count=None
        self.source_checked_total=None
        self.source_conflict_total=None
        self.heartspace_arousal=None
        self.oneiric_idle_fraction=None

    def __enter__(self):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        self.file=self.path.open('w',encoding='utf8')
        self.start_ns=time.perf_counter_ns()
        self.sample()
        return self

    def __exit__(self,*args):
        try:self.sample()
        finally:self.file.close()

    def report_tokens(self, actual_count):
        if not isinstance(actual_count,int) or actual_count<0:raise ValueError('count must be nonnegative integer')
        self.token_total+=actual_count

    def sample(self,**explicit):
        if self.file is None:raise RuntimeError('Not in recorder context')
        for k,v in explicit.items():
            if k not in {'queue_depth','frame_candidate_count','source_checked_total','source_conflict_total','heartspace_arousal','oneiric_idle_fraction'}:
                raise ValueError('Unknown or prohibited sensor: '+k)
            setattr(self,k,v)
        row={'origin':'observed-runtime','timestamp_s':round((time.perf_counter_ns()-self.start_ns)/1e9,9),
             'process_cpu_s':round(time.process_time_ns()/1e9,9),'queue_depth':self.queue_depth,
             'token_count_total':self.token_total}
        mem=rss_bytes()
        if mem is not None:row['rss_bytes']=mem
        for key in ['frame_candidate_count','source_checked_total','source_conflict_total','heartspace_arousal','oneiric_idle_fraction']:
            v=getattr(self,key)
            if v is not None:row[key]=v
        self.file.write(json.dumps(row,separators=(',',':'))+'\n')
        self.file.flush()
        return row

    @contextlib.contextmanager
    def measure_request(self,queue_depth=0):
        self.sample(queue_depth=queue_depth)
        try:yield
        finally:self.sample(queue_depth=0)


def measured_demo(out,seconds=3.2,step_s=0.05):
    """Real measurements of a deterministic CPU demo, explicitly NOT a Kokoro model."""
    if seconds<=0 or step_s<=0:raise ValueError('invalid duration')
    iterations=0
    with TraceRecorder(out) as trace:
        start=time.perf_counter()
        next_tick=start+step_s
        while time.perf_counter()-start<seconds:
            elapsed=time.perf_counter()-start
            phase=elapsed/seconds
            # Synthetic jobs with real CPU execution and real clock measurements.
            tasks=1 if phase<0.25 else (16 if phase<0.65 else 3)
            trace.queue_depth=tasks
            limit=time.perf_counter()+step_s*(0.15 if phase<0.25 else (0.78 if phase<0.65 else 0.3))
            while time.perf_counter()<limit:
                a=sum((j*j+13*j)%97 for j in range(400))
                iterations+=1
            wait=next_tick-time.perf_counter()
            if wait>0:time.sleep(wait)
            trace.sample()
            next_tick+=step_s
    return {'classification':'real runtime CPU/RSS/time measurements, but workload is a synthetic numerical task, not Kokoro inference',
            'seconds_requested':seconds,'actual_arithmetic_iterations':iterations,'trace_file':str(out)}


if __name__=='__main__':
    if len(sys.argv)!=2:
        raise SystemExit('Usage: python python/instrument_kokoro.py output.jsonl')
    print(json.dumps(measured_demo(sys.argv[1]),indent=2))
