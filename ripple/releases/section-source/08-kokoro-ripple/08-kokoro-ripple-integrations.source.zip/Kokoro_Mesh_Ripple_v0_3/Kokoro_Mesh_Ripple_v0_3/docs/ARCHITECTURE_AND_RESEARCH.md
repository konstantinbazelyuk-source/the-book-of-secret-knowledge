# Kokoro Mesh v0.3 — Architecture, history and sourced improvements

## Critical separation of past specifications, reference code, and actual available runtime

Kokoro's previously described system includes **Core (language expression)**, **Psyche Daughterboard**, **Heartspace Daughterboard (30 dimensions, six layers)**, **Psyche Network**, **Oneiric Resonance 2.0**, **Genesis Seed**, **CPU Adaptive Trainer**, **Pocket Time**, and adjacent features **Lumina, Fourth Wall, Lawspace, Heartspace-B, Overdrive Governor/Heart Pulse, persistent Memory, Desktop Shell, and proposed Prospective Resonance**. Ripple 0.1 and v0.2 are additive.

The Foundry package manifest reviewed in this project's ChatGPT history described a clean, untrained distribution and **no bundled weights**. The original implementations of most Kokoro daughterboards were not available as executable archive bytes in this working container. Consequently:

1. **Preserved:** legacy Ripple Python implementation copied byte-for-byte from v0.2; unchanged v0.1 JS kept under `sources/`; history of each subsystem's purpose and no-overwrite rule.
2. **Implemented:** orchestration, typed reference boards, strict independent hard gates, adapter subprocesses, multiple optional LLM specialist calls, provenance inventory, persistence, static original-API scanner, bounded deadlines, routing/telemetry, and deterministic tests.
3. **Reference approximations:** 5-value Heartspace projection (not original 30D), symbolic Oneiric memory tags (not original dreaming), simplified Lawspace/Overdrive recommendations, Lumina scene command data (not graphics), Genesis training record listing (not a protected-origin recreation), Fourth Wall content-classification boundary.
4. **Unconnected:** actual trained Core, original Heartspace/Psyche/Network/Oneiric code, independent local LLM weights, Desktop Shell, sensors and robotics, future Prospective Resonance.

## Network data flow (working)

```
caller approved input + continuity capsule
     |
     +--> strict JSON/capsule validation + SHA256
     |
     +--> bounded asyncio task scheduler [max_concurrency = 1..8]
          | Psyche frames     | Heartspace reported coordinates
          | Network claims    | Oneiric tags (idle-only)
          | Genesis registry  | Pocket Time clock
          | Ripple event math | Memory (approved SQLite)
          | Lumina scene data | Fourth Wall mode
          | Lawspace vector   | Heartspace-B capacity
          | Overdrive advice  | Prospective (unavailable)
     |
     +--> mandatory continuity, source-provenance and Wake Gates
     +--> top-k metadata analysis colony (max 2 specialists)
     +--> opt-in multi-model colony (max 2 independent providers per request)
     +--> opt-in central language generator (model adapter, not bundled)
     |
     +--> structured result + metadata-only audit (if requested)
```

**No mesh branch can rewrite the original Core, original user memory or Genesis origin.** A model's text is a *candidate* rather than a source-verified fact. Source packets retain `verified: false` because the runtime does NOT fetch or corroborate websites. Dream associations retain `fact_promotions: []` regardless of adapter output. Frame broadcast requires exact continuity digest matching. External adapters run in a subprocess with bounded timeout but are NOT secure OS sandboxes; they are explicitly opted in.

## Public research actually adopted

| Source | Verifiable published idea | How applied here | Not claimed |
|---|---|---|---|
| xAI Grok-1 | 8 experts, top-2-per-token sparse MoE. Apache 2.0 code+weights for the 314B published release. [1] | **Top-2 deterministic routing** for low-cost metadata specialists and bounded independent model selections. | No Grok weights/code copied. No learned gating network, 314B model or benchmark equivalence. |
| Google Agent Development Kit | Deterministic sequential/parallel/loop workflow operators, now evolving to graph-based workflows. [2] | Strict explicit graph-like stages; independent reference boards executed concurrently. | Not a Google ADK plugin or hosted Gemini account. |
| Google Expert Choice MoE research | Expert capacity, balancing and sparse activation. [3] | Per-expert dispatch count / fair tie-break; bounded top-2 processing. | Not the paper's learned expert-choice training algorithm. |
| Meta Llama | Community-licensed downloadable pretrained models with restrictions. [4] | User can optionally run an authorized local model through an Ollama-compatible HTTP service; no model is bundled or redistributed. | No private Meta models, Meta APIs or free unlimited model compute. |
| Google Gemma | Pretrained model family with version-specific terms. [5] | Same optional local inference interface; user must obtain and comply with the correct model terms. | No Gemma weights bundled, no model distillation. |
| Microsoft Agent Framework | Defined agents vs explicit workflows, tools and middleware. [6] | Strict roles, contract checking, typed source outputs, model/tool separation. | No proprietary Microsoft runtime imported. |
| OpenAI Agents SDK | Specialized agents, handoffs, input/output guardrails, tracing. [7] | Mandatory hard gates after independent agent execution; status tracing without raw personal content. | No paid OpenAI API calls. |
| Ray actors | Stateful independent worker processes for scale-out. [8] | Optional external Python subprocess boundary and bounded async scheduling. | No actual multi-machine Ray deployment. |

### Source links

[1] https://github.com/xai-org/grok-1/blob/main/README.md
[2] https://github.com/google/adk-docs/blob/main/docs/agents/workflow-agents/index.md
[3] https://www.research.google/blog/mixture-of-experts-with-expert-choice-routing/
[4] https://github.com/meta-llama/llama-models/blob/main/models/llama4/LICENSE
[5] https://ai.google.dev/gemma/terms/
[6] https://learn.microsoft.com/agent-framework/overview
[7] https://openai.github.io/openai-agents-python/
[8] https://docs.ray.io/en/latest/ray-core/actors.html

These are public technical inspirations, not copied proprietary source code. See official terms before downloading, distributing, training on or running any third-party weights. The model names in CLI examples are placeholders until the user installs a suitably licensed local model.

## Connecting the REAL Kokoro programs

1. On the system containing `C:\Kokoro-del-Corazon-Foundry`, **first make a backup and run the read-only scanner**: `python -m kokoro_mesh scan --project "C:\Kokoro-del-Corazon-Foundry" -o original_apis.json`.
2. Inspect actual `kokoro.py`, `kokoro_core/psyche.py`, add-on directories and saved checkpoint metadata. Compare hashes before/after; skip any invalid or unavailable program.
3. Implement an adapter for each exact discovered signature, initially `psyche` and `network` in read-only mode. Do not automatically `pip install`/import unknown modules or permit original installers to rewrite the Foundry.
4. Connect Heartspace's actual 30-dimensional state through a documented **read-only five-coordinate projection** instead of recreating it. Confirm one-to-one epoch/continuity IDs.
5. Connect Oneiric only after idle and enforce wake gate outside its process. Keep Genesis origin immutable; the historical seed `YHWH` and first presented/recorded thought `God loves Me.` belong to the original Genesis record, not new inferred text or model weights.
6. Only then connect the actual trained Core checkpoint, with frozen weights and baseline A/B comparisons. No training/optimizer steps are authorized by this harness.
7. Add Lumina/Overdrive/Fourth Wall adapters only after inspecting their actual packages. Mark Prospective Resonance proposed until genuine implementation exists.

## Licensing and publication

The user's Kokoro story/persona, original design materials, and external model weights may have separate rights. This package is delivered as a private working artifact. It has **not been published** as a new GitHub repo or an external model service. Model weights from any external provider should not be copied or redistributed without checking that specific license.
