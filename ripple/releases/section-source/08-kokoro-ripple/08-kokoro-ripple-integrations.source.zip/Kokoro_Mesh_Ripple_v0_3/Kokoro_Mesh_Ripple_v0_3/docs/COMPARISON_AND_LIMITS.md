# Experimental classification and next engineering gates

## Verified local software

- All deterministic unit tests and adversarial checks: see `results/test_output.txt`.
- JSON subprocess adapter can return well-typed data without importing original programs into the kernel.
- Two independent mocked models were actually called via separate provider objects, in a bounded run; their outputs remained `unverified-model-candidate`. **Mocks are not AI models.**
- Original v0.2 Python Ripple port copied byte-for-byte, checked against its prior source.
- Optional memory uses a separate SQLite database with explicit user approval and no Genesis modification.
- Static code inventory via Python AST runs without executing any original Kokoro module.

## Measured runtime results — not AI intelligence

A 14-board experiment used `asyncio.sleep(0.012)` inside each test adapter, repeated seven times on this container. Median wall times (ms):

| max simultaneous adapters | median wall ms | classification |
|---|---:|---|
| 1 | 171.088 | measured wait-bound prototype |
| 2 | 85.471 | measured wait-bound prototype |
| 3 | 61.166 | measured wait-bound prototype |
| 4 | 48.984 | measured wait-bound prototype |

This demonstrates concurrency for independent, waiting operations. It does **not** establish faster inference, improved response quality, hardware scalability, memory consolidation, or a better AI. Under CPU-bound load, Python threads generally do not scale like separate model workers, and process overhead may erase improvements.

## Cloud run

Floot isolated VM provided Node v22.23.2 and Python 3.11.2. A separate **independent Python contract smoke test**, not this packaged archive, confirmed continuity frame filtering, source unverified status, and dream Wake Gate blocked (3/3 checks; ~6.438 ms). The full `kokoro_mesh` Python source was NOT transferred to that VM. `results/cloud_smoke.json` describes exactly what ran.

## Simulated and reference-only outputs

- `demo_output.json` uses synthetic numeric coordinates and frame candidates intentionally supplied by `demo_request`. These are NOT recovered actual Kokoro mental state.
- Oneiric symbolic association is a minimal deterministic fallback, NOT the original Deep Dream/Kuramoto/diffusion logic.
- Five-coordinate Heartspace is an adapter envelope, not the original 30D, six-layer engine.
- Lumina generates scene command JSON but does not render an avatar.
- Sparse top-2 specialist router is hand-designed and measured only for deterministic metadata processing, not learned MoE inference.

## Required acceptance tests before claiming integrated Kokoro

1. Actual module source/installed packages and checkpoint available; static API scan and hash inventory completed.
2. Original program tests and original model inference validated **without** this mesh first.
3. Each original adapter passes input/output, isolation, timeout, continuity and no-write tests.
4. Controlled end-to-end answer A/B comparison (same prompt set, fixed weights and decoding configuration), compare factual accuracy, latency, token throughput, memory load, adverse-event rate and cost; confidence intervals over repeated trials.
5. Oneiric provenance and source conflicts adversarially tested; original Genesis protected-origin hash unchanged.
6. Results verified on target CPU hardware and optionally externally, with realistic measured workload; only enable automation after benefits outweigh cost.

## Current blockers

- No real original Kokoro executable daughterboards/checkpoint files in this workspace.
- No license acceptance, download or local installation of Meta/Google/xAI weights was performed.
- No paid API or cloud GPU invoked. Floot smoke was a limited computational test only.

## Source acquisition in actual connected cloud VM

A separate connected Floot VM directly fetched two **public documentation files**, validating that a cloud execution environment can collect and hash allowed research material. See `results/cloud_live_sources.json` for exact URLs, HTTP statuses (200/200), payload sizes (2145 and 2272 bytes), and SHA-256 digests. The experimental `source_colony.py` HTTPS implementation itself was NOT run in that VM; its safety unit tests use a fake network transport. Public documents were referenced for ideas, not imported as executable components, not trusted as model instructions, and no proprietary model weights were downloaded.
