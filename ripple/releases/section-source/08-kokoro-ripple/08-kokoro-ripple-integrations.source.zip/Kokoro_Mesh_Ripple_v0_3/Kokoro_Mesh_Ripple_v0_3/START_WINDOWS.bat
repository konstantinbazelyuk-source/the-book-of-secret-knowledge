@echo off
setlocal
cd /d "%~dp0"
python -m unittest discover -s tests -v
if errorlevel 1 exit /b 1
python -m kokoro_mesh doctor
python -m kokoro_mesh demo
pause
