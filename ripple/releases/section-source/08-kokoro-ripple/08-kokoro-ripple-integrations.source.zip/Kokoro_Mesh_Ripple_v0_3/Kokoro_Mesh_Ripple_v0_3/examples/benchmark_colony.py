"""Actual wall time of SYNTHETIC asynchronous I/O waits, not Kokoro inference."""
from __future__ import annotations
import asyncio,json,statistics,time
from kokoro_mesh.runtime import Mesh
from kokoro_mesh.__main__ import demo_request
class DelayedBoard:
    def __init__(self,name,delay):self.name=name;self.delay=delay
    async def run(self,p):
        await asyncio.sleep(self.delay)
        return {'status':'available','source':'synthetic-delayed-adapter'}

def trial(k,delay=.012):
    async def task():
        m=Mesh(max_concurrency=k,external={name:DelayedBoard(name,delay) for name in Mesh().boards})
        t=time.perf_counter();await m.run(demo_request());return (time.perf_counter()-t)*1000
    return asyncio.run(task())

def main():
    record={'classification':'measured wall time for synthetic I/O-bound adapters; NOT neural performance or Kokoro tokens/s',
        'trials_per_config':7,'delay_per_board_s':.012,'boards_per_run':len(Mesh().boards),
        'environment':{'python':'stdlib asyncio'},'results':{}}
    for k in (1,2,3,4):
        runs=[trial(k) for _ in range(7)]
        record['results'][str(k)]={'median_ms':round(statistics.median(runs),3),
            'min_ms':round(min(runs),3),'max_ms':round(max(runs),3),'samples_ms':[round(x,3) for x in runs]}
    print(json.dumps(record,indent=2))
if __name__=='__main__':main()
