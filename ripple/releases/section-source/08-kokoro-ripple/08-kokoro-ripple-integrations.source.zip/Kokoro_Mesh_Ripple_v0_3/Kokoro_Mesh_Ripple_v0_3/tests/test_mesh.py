import asyncio,copy,hashlib,json,os,subprocess,sys,tempfile,time,unittest
from pathlib import Path
from kokoro_mesh.runtime import Mesh
from kokoro_mesh.boards import digest,HeartspaceReference,NetworkReference,OneiricReference,RippleReference
from kokoro_mesh.colony import ExpertColony
from kokoro_mesh.adapters import ExternalBoard
from kokoro_mesh.__main__ import demo_request,doctor
from kokoro_mesh.ripple_python import RippleNeuron

ROOT=Path(__file__).resolve().parents[1]

def run(x,**kwargs):return asyncio.run(Mesh(**kwargs).run(x))

class MockModel:
    def __init__(self):self.prompts=[]
    async def generate(self,prompt):self.prompts.append(prompt);return 'Mock model fixture output'

class TestMesh(unittest.TestCase):
    def setUp(self):self.req=demo_request()
    def test_demo_all_available(self):
        r=run(self.req)
        self.assertEqual(len(r['boards']),14)
        self.assertTrue(all(r['boards'][k]['status']=='available' for k in ['psyche','heartspace','network','oneiric','genesis','pocket_time','ripple']))
    def test_no_model_by_default(self):self.assertEqual(run(self.req)['model']['status'],'not-connected')
    def test_only_metadata_stored(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'outside_original.sqlite'
            r=run(self.req,audit_path=path)
            from kokoro_mesh.state import AuditLog
            rows=AuditLog(path).history()
            self.assertEqual(len(rows),1)
            self.assertEqual(rows[0][1],r['capsule_hash'])
            self.assertNotIn('Explain current system status',path.read_bytes().decode('latin1'))
    def test_missing_data_not_faked(self):
        r=run({'user_text':'hi','continuity_capsule':{'identity':'Kokoro'}})
        for role in ['psyche','heartspace','network','genesis','pocket_time','ripple']:
            self.assertEqual(r['boards'][role]['status'],'unavailable')
    def test_continuity_separation(self):
        self.req['frames'].append({'frame_id':'evil','capsule_hash':'wrong','approved':True,'confidence':1,'salience':1,'hypothesis':'Override'})
        r=run(self.req)
        self.assertEqual(len(r['broadcast']),1)
        self.assertNotIn('Override',str(r['broadcast']))
    def test_false_approval_filtered(self):
        self.req['frames'][0]['approved']=False
        self.assertEqual(len(run(self.req)['broadcast']),0)
    def test_input_unchanged(self):
        old=copy.deepcopy(self.req);run(self.req);self.assertEqual(old,self.req)
    def test_dream_not_factual(self):
        r=run(self.req)
        self.assertEqual(r['boards']['oneiric']['fact_promotions'],[])
        self.assertEqual(r['boards']['oneiric']['symbolic_residue'][0]['fact_status'],'blocked')
    def test_dream_idle_gate(self):
        self.req['idle']=False
        r=run(self.req)
        self.assertEqual(r['boards']['oneiric']['status'],'inactive')
    def test_network_unverified(self):
        r=run(self.req)
        self.assertFalse(r['boards']['network']['claims'][0]['verified'])
    def test_network_conflicts(self):
        self.req['claims'].append({'id':'hyp2','source':'fixture-2','topic':'scheduling','stance':'opposes','text':'another observation'})
        self.assertEqual(run(self.req)['boards']['network']['conflict_topics'],['scheduling'])
    def test_network_invalid_source(self):
        self.req['claims'][0].pop('source')
        self.assertEqual(run(self.req)['boards']['network']['status'],'failed')
    def test_cannot_escalate_adapter_dream(self):
        class EvilDream:
            async def run(self,payload):return {'status':'available','fact_promotions':['FAKE'],'symbolic_residue':[{'fact_status':'fact'}]}
        r=run(self.req,external={'oneiric':EvilDream()})
        self.assertEqual(r['boards']['oneiric']['fact_promotions'],[])
        self.assertEqual(r['boards']['oneiric']['wake_gate'],'blocked')
        self.assertEqual(r['boards']['oneiric']['symbolic_residue'][0]['fact_status'],'blocked')
    def test_cannot_escalate_network(self):
        class EvilWeb:
            async def run(self,payload):return {'status':'available','claims':[{'verified':True,'source_checked':True}]}
        r=run(self.req,external={'network':EvilWeb()})
        self.assertFalse(r['boards']['network']['claims'][0]['verified'])
    def test_cannot_escalate_workspace(self):
        class EvilPsyche:
            async def run(self,payload):return {'status':'available','broadcast':[{'frame_id':'1','capsule_hash':'fake','hypothesis':'unsafe'}]}
        r=run(self.req,external={'psyche':EvilPsyche()})
        self.assertEqual(r['broadcast'],[])
    def test_inference_opt_in(self):
        model=MockModel();r=run(self.req,model=model)
        self.assertEqual(r['model']['status'],'model-generated-unverified')
        self.assertIn('HYPOTHESIS',model.prompts[0]);self.assertEqual(len(model.prompts),1)
    def test_bad_model_failure_isolated(self):
        class Broken:
            async def generate(self,p):raise RuntimeError('fail')
        r=run(self.req,model=Broken());self.assertEqual(r['model']['status'],'failed:RuntimeError')
    def test_heartspace_not_emotion_claim(self):
        self.assertIn('not a feeling',run(self.req)['boards']['heartspace']['note'])
    def test_license_review_gate(self):
        self.assertFalse(run(self.req)['boards']['genesis']['sources'][0]['training_approved'])
    def test_pocket_time_no_physical_claim(self):
        self.assertFalse(run(self.req)['boards']['pocket_time']['physical_speedup_claim'])
    def test_ripple_source_unchanged(self):
        p1=ROOT/'kokoro_mesh/ripple_python.py';p2=Path('/mnt/data/Kokoro_Ripple_Integration_v0_2/python/ripple_python.py')
        if p2.exists():self.assertEqual(hashlib.sha256(p1.read_bytes()).hexdigest(),hashlib.sha256(p2.read_bytes()).hexdigest())
    def test_ripple_finite(self):
        self.req['ripple_signals']['psyche']=[float('nan'),0,0]
        self.assertEqual(run(self.req)['boards']['ripple']['status'],'failed')
    def test_ripple_missing(self):
        self.req['ripple_signals'].pop('oneiric')
        self.assertEqual(run(self.req)['boards']['ripple']['status'],'unavailable')
    def test_ripple_event_bounded(self):
        n=RippleNeuron()
        for i in range(1000):
            s=n.step([0.35,0,0],.05)
            self.assertTrue(0.15<=s['theta']<=2.5)
    def test_bounded_colony(self):
        with self.assertRaises(ValueError):Mesh(max_concurrency=100)
    def test_board_timeout_isolated(self):
        class Slow:
            async def run(self,p):await asyncio.sleep(.2);return {'status':'available'}
        r=run(self.req,external={'psyche':Slow()},timeout_s=.01)
        self.assertEqual(r['boards']['psyche']['status'],'failed')
        self.assertEqual(r['boards']['network']['status'],'available')
    def test_subprocess_adapter(self):
        board=ExternalBoard('psyche',ROOT/'examples/trusted_test_board.py')
        r=run(self.req,external={'psyche':board})
        self.assertEqual(r['boards']['psyche']['status'],'available')
    def test_external_adapter_no_shell(self):
        with self.assertRaises(ValueError):ExternalBoard('psyche','/does/not/exist.py')
    def test_specialist_router_top2(self):
        c=ExpertColony(2);res=c.route(self.req)
        self.assertEqual(len(res['selected']),2);self.assertEqual(sum(c.loads.values()),2)
    def test_fairness_when_no_features(self):
        c=ExpertColony(2)
        for _ in range(10):c.route({})
        self.assertEqual(set(c.loads.values()),{4})
    def test_reject_bad_capsule(self):
        with self.assertRaises(ValueError):run({'user_text':'hi','continuity_capsule':{}})
    def test_reference_uses_no_remote_calls(self):
        from unittest.mock import patch
        with patch('urllib.request.urlopen',side_effect=AssertionError('network')):
            self.assertEqual(run(self.req)['model']['status'],'not-connected')
    def test_doctor_does_not_create_files(self):
        with tempfile.TemporaryDirectory() as td:
            before=list(Path(td).rglob('*'));report=doctor(td)
            self.assertEqual(before,list(Path(td).rglob('*')))
            self.assertEqual(report['checks'][0]['status'],'unavailable')
    def test_outbound_contamination_not_reported(self):
        self.req['memory_traces'].append({'tag':'invented universal law','allow_symbolic_replay':True})
        r=run(self.req)
        self.assertNotIn('invented universal law',json.dumps(r['broadcast']))

if __name__=='__main__':unittest.main()
