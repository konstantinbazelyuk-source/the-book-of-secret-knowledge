import asyncio,unittest
from kokoro_mesh.source_colony import SourceColony,validate_url
class SourceTests(unittest.TestCase):
    def test_reject_local(self):
        for u in ['http://example.org/a','https://localhost/a','https://127.0.0.1/a','https://example.org:8000/a','https://evil.org/a','https://joe:pwd@example.org/a']:
            with self.assertRaises(ValueError):validate_url(u,{'example.org'})
    def test_permitted_explicit(self):
        self.assertEqual(validate_url('https://example.org/test',{'example.org'})[0],'example.org')
    def test_bounded_fake_fetch(self):
        calls=[]
        def fake(url,hosts):
            calls.append(url)
            return {'status':'fetched','url':url,'verified_claims':False}
        c=SourceColony({'example.org'},limit=2,fetcher=fake)
        r=asyncio.run(c.run(['https://example.org/a','https://example.org/b']))
        self.assertEqual(len(calls),2)
        self.assertEqual(len(r['results']),2)
        self.assertFalse(r['results'][0]['verified_claims'])
    def test_no_partial_fetch_if_one_bad(self):
        calls=[]
        c=SourceColony({'example.org'},fetcher=lambda u,h:calls.append(u))
        with self.assertRaises(ValueError):asyncio.run(c.run(['https://example.org/a','https://bad.org/z']))
        self.assertEqual(calls,[])
    def test_no_unbounded_colony(self):
        with self.assertRaises(ValueError):SourceColony({'example.org'},limit=999)
