import tempfile,unittest
from pathlib import Path
from kokoro_mesh.discovery import scan
class DiscoveryTest(unittest.TestCase):
    def test_safe_static_discovery(self):
        with tempfile.TemporaryDirectory() as d:
            original=Path(d)
            (original/'kokoro.py').write_text('class Kokoro:\n def generate(self, tokens): return tokens\n\ndef train(x): return x\n',encoding='utf8')
            before=(original/'kokoro.py').read_bytes()
            result=scan(original)
            self.assertEqual(result['files_scanned'],1)
            self.assertEqual(result['files'][0]['classes'][0]['methods'],['generate'])
            self.assertEqual(before,(original/'kokoro.py').read_bytes())
    def test_discovery_does_not_execute_side_effect(self):
        with tempfile.TemporaryDirectory() as d:
            (Path(d)/'unsafe.py').write_text('from pathlib import Path\nPath("/tmp/should_not_exist_kokoro_scan").write_text("bad")\ndef a():return 1')
            result=scan(d);self.assertTrue(result['files'])
            self.assertFalse(Path('/tmp/should_not_exist_kokoro_scan').exists())
