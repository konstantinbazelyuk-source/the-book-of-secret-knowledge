import asyncio,unittest
from kokoro_mesh.model_colony import ModelColony
from kokoro_mesh.runtime import Mesh
from kokoro_mesh.__main__ import demo_request

class Mock:
    def __init__(self,name):self.name=name;self.calls=0
    async def generate(self,p):
        self.calls+=1;await asyncio.sleep(.001);return self.name+': candidate only'

class Tests(unittest.TestCase):
    def test_distinct_models_invoked(self):
        a,b=Mock('A'),Mock('B')
        req=demo_request();req['model_tasks']=['analysis','evidence']
        result=asyncio.run(Mesh(model_experts={'analysis':a,'evidence':b}).run(req))
        candidates=result['model_colony']['candidates']
        self.assertEqual([x['content'] for x in candidates],['A: candidate only','B: candidate only'])
        self.assertEqual((a.calls,b.calls),(1,1))
        self.assertEqual(result['model']['status'],'not-connected')
    def test_no_automatic_model_calls(self):
        a=Mock('A');req=demo_request()
        result=asyncio.run(Mesh(model_experts={'analysis':a}).run(req))
        self.assertEqual(a.calls,0);self.assertEqual(result['model_colony']['status'],'not-connected')
    def test_no_provider_degrades(self):
        req=demo_request();req['model_tasks']=['analysis']
        result=asyncio.run(Mesh().run(req))
        self.assertEqual(result['model_colony']['status'],'not-connected')
    def test_bounded_model_tasks(self):
        req=demo_request();req['model_tasks']=['analysis','creative','planning']
        out=asyncio.run(Mesh(model_experts={k:Mock(k) for k in ('analysis','creative','planning')}).run(req))
        self.assertEqual(len(out['model_colony']['candidates']),2)
    def test_errors_do_not_break_network(self):
        class Error:
            async def generate(self,p):raise RuntimeError('test')
        req=demo_request();req['model_tasks']=['evidence']
        out=asyncio.run(Mesh(model_experts={'evidence':Error()}).run(req))
        self.assertEqual(out['model_colony']['candidates'][0]['status'],'failed')
        self.assertEqual(out['boards']['ripple']['status'],'available')
    def test_invalid_role(self):
        with self.assertRaises(ValueError):ModelColony({'unrestricted_tools':Mock('x')})

if __name__=='__main__':unittest.main()
