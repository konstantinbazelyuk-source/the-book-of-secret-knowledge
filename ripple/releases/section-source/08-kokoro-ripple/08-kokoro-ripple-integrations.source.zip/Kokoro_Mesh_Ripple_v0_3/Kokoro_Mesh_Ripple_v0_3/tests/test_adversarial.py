import asyncio,math,unittest
from kokoro_mesh.runtime import Mesh
from kokoro_mesh.__main__ import demo_request

def call(req,**k):return asyncio.run(Mesh(**k).run(req))

class Adversarial(unittest.TestCase):
    def test_nan_capsule(self):
        with self.assertRaises(ValueError):call({'continuity_capsule':{'x':float('nan')}})
    def test_adapter_malformed_lists(self):
        class Broken:
            async def run(self,p):return {'status':'available','broadcast':None,'claims':None,'symbolic_residue':None}
        r=call(demo_request(),external={n:Broken() for n in ('psyche','network','oneiric')})
        self.assertEqual(r['broadcast'],[])
        self.assertEqual(r['boards']['oneiric']['wake_gate'],'blocked')
    def test_wrong_claim_type_isolated(self):
        request=demo_request();request['claims']=12
        self.assertEqual(call(request)['boards']['network']['status'],'failed')
    def test_bounded_concurrency_output(self):
        self.assertEqual(call(demo_request(),max_concurrency=2)['colony']['max_concurrency'],2)
    def test_bad_memory_type_ignored(self):
        request=demo_request();request['memory_traces']='not a list'
        self.assertEqual(call(request)['boards']['oneiric']['status'],'failed')
    def test_empty_or_missing_source_is_fail_closed(self):
        request=demo_request();request['claims'][0]['source']=''
        self.assertEqual(call(request)['boards']['network']['status'],'failed')

if __name__=='__main__':unittest.main()
