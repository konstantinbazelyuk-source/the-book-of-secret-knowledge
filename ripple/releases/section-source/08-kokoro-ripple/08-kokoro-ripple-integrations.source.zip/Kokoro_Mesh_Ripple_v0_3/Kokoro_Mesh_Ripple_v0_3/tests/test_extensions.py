import asyncio,tempfile,unittest
from pathlib import Path
from kokoro_mesh.runtime import Mesh
from kokoro_mesh.memory import MemoryStore
from kokoro_mesh.__main__ import demo_request

def run(x,**opts):return asyncio.run(Mesh(**opts).run(x))

class ExtensionTests(unittest.TestCase):
    def setUp(self):self.req=demo_request()
    def test_unavailable_without_original_addons(self):
        r=run(self.req)
        for name in ['lumina','lawspace','heartspace_b','overdrive','memory','prospective_resonance']:
            self.assertEqual(r['boards'][name]['status'],'unavailable')
    def test_lumina_commands_not_render(self):
        self.req['lumina_scene']={'pose':'standing','expression':'neutral'}
        v=run(self.req)['boards']['lumina'];self.assertFalse(v['rendered'])
        self.assertEqual(v['scene_commands']['pose'],'standing')
    def test_fourth_wall_fiction_boundary(self):
        self.req['content_mode']='fiction'
        r=run(self.req)['boards']['fourth_wall'];self.assertEqual(r['fiction_to_fact'],'blocked')
    def test_lawspace_dimensions(self):
        self.req['lawspace']=[.2]*10
        r=run(self.req)['boards']['lawspace'];self.assertEqual(r['dimensions'],10)
    def test_capacity_heuristic_only(self):
        self.req['capacity_state']={'load':.8,'recovery':.2,'stability':.7}
        self.assertTrue(run(self.req)['boards']['heartspace_b']['not_a_health_measurement'])
    def test_overdrive_advice_not_thermal_control(self):
        self.req['overdrive_request']={'load':1,'heat':.9,'recovery':0}
        r=run(self.req)['boards']['overdrive'];self.assertEqual(r['status_advice'],'cooldown-advised')
        self.assertFalse(r['hardware_throttling_performed'])
    def test_memory_requires_explicit_approval(self):
        with tempfile.TemporaryDirectory() as d:
            m=MemoryStore(Path(d)/'memory.db')
            with self.assertRaises(PermissionError):m.add('1','hello','self','user-stated')
            m.add('1','hello','self','user-stated',True)
            self.assertEqual(m.search('hello')[0]['id'],'1')
            self.assertEqual(m.forget('1'),1)
            self.assertEqual(m.search('hello'),[])
    def test_memory_mesh_opt_in(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'memory.db';m=MemoryStore(path)
            m.add('1','use continuity hash','self-note','user-stated',True)
            self.req['memory_query']='continuity'
            r=run(self.req,memory_path=path)
            self.assertEqual(len(r['boards']['memory']['records']),1)
    def test_memory_cannot_store_dream_type(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(ValueError):MemoryStore(Path(d)/'memory.db').add('1','a','dream','dream-fact',True)

if __name__=='__main__':unittest.main()
