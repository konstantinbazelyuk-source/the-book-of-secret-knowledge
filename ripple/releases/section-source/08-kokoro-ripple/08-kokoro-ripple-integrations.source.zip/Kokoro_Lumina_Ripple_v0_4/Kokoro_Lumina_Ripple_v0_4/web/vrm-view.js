/** Optional 3D bridge via official three.js + @pixiv/three-vrm v3. No assets bundled.
 * Requires online ESM/CDN load and a user-owned VRM. Does not change Kokoro's model weights.
 * This bridge has syntax checks only until real VRM + online WebGL environment are tested.
 */
import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {VRMLoaderPlugin,VRMUtils} from '@pixiv/three-vrm';
const cv=document.getElementById('vrm'),status=document.getElementById('status');
const renderer=new THREE.WebGLRenderer({canvas:cv,antialias:true,alpha:false,preserveDrawingBuffer:true});
renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));renderer.setClearColor(0x07121d,1);
const scene=new THREE.Scene();scene.add(new THREE.HemisphereLight(0xe6ffff,0x13293a,2));
const key=new THREE.DirectionalLight(0xa8ecff,2.4);key.position.set(2,4,5);scene.add(key);
const camera=new THREE.PerspectiveCamera(30,1,.1,100);camera.position.set(0,1.35,3.8);camera.lookAt(0,1.28,0);
const loader=new GLTFLoader();loader.register(parser=>new VRMLoaderPlugin(parser));
let loaded=null,modelURL=null,lastTime=performance.now(),frame={yaw:0,gaze_x:0,gaze_y:0,blink:0,mouth:0,bob:0,expression:'neutral',elapsed_s:0};
const resize=()=>{const w=Math.max(200,cv.clientWidth),h=Math.max(240,cv.clientHeight);renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix()};
window.addEventListener('resize',resize);resize();
function exp(key,value){if(loaded?.expressionManager){try{loaded.expressionManager.setValue(key,Math.max(0,Math.min(1,value)))}catch{}}}
document.getElementById('vrm-file').addEventListener('change',e=>{
const file=e.target.files[0];if(!file)return;
if(file.size>80*1024*1024){status.textContent='VRM exceeds 80 MB local safeguard';return;}
if(modelURL)URL.revokeObjectURL(modelURL);
modelURL=URL.createObjectURL(file);status.textContent='Parsing local VRM...';
loader.load(modelURL,gltf=>{
if(loaded)scene.remove(loaded.scene);
loaded=gltf.userData.vrm;
if(!loaded){status.textContent='VRM extension missing; plain GLB is not accepted as VRM.';return;}
if(loaded.meta?.metaVersion==='0'&&VRMUtils?.rotateVRM0)VRMUtils.rotateVRM0(loaded);
scene.add(loaded.scene);status.textContent='Loaded '+file.name+' locally (VRM asset not uploaded).';
},undefined,err=>{status.textContent='VRM load error: '+String(err).slice(0,220)});
});
try {const es=new EventSource('/api/stream');es.onmessage=e=>{try{const s=JSON.parse(e.data);if(s.schema==='lumina.frame.v1')frame=s;}catch{}};es.onerror=()=>{if(!loaded)status.textContent='Local Lumina packet stream unavailable; 3D preview remains idle.'}}catch{}
function tick(now){requestAnimationFrame(tick);let dt=Math.min(.05,(now-lastTime)/1000);lastTime=now;
if(loaded){
 const head=loaded.humanoid?.getNormalizedBoneNode('head');
 if(head){head.rotation.y=THREE.MathUtils.lerp(head.rotation.y,(frame.yaw||0),1-Math.exp(-dt/.3));head.rotation.x=THREE.MathUtils.lerp(head.rotation.x,-(frame.gaze_y||0)*.12,1-Math.exp(-dt/.3));}
 const hips=loaded.humanoid?.getNormalizedBoneNode('hips');if(hips)hips.position.y=.008*Math.sin((frame.elapsed_s||0)*Math.PI*.47);
 exp('blink',frame.blink||0);exp('aa',frame.mouth||0);exp('happy',frame.expression==='happy'?.4:0);
 exp('surprised',frame.expression==='surprised'?.5:0);exp('relaxed',frame.expression==='relaxed'?.3:0);
 loaded.update(dt);
}
renderer.render(scene,camera);
}requestAnimationFrame(tick);
document.getElementById('capture').onclick=()=>{renderer.render(scene,camera);cv.toBlob(blob=>{if(!blob)return;const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='kokoro-vrm.png';a.click();setTimeout(()=>URL.revokeObjectURL(url),1500)},'image/png')};
