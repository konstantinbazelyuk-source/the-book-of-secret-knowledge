(()=>{
'use strict';
const $=x=>document.getElementById(x),canvas=$('canvas'),c=canvas.getContext('2d',{alpha:false});
const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
const art={full:null,head:null,eyes:null,mouth:null,heart:null,gun:null,sword:null,feet:null,heels:null},urls={};
function useReference(src=document.querySelector('.reference-art img')?.src || '../assets/Adelita_Kokoro_reference.png'){const im=new Image();im.onload=()=>{art.full=im;art.head=art.eyes=art.mouth=art.heart=art.gun=art.sword=art.feet=art.heels=null;$('asset-status').textContent='Recovered Adelita Kokoro Library artwork displayed (unaltered source).';$('asset-label').textContent='AUTHORED REFERENCE POSTER · NON-RIGGED';};im.onerror=()=>{$('asset-status').textContent='Reference artwork unavailable in this view; placeholder active.'};im.src=src;}
$('use-reference').onclick=()=>useReference();
function loadArt(id,key){$(id).addEventListener('change',e=>{const file=e.target.files[0];if(!file)return;if(file.size>12*1024*1024){alert('Artwork exceeds the 12 MB local limit.');return;}if(!['image/png','image/jpeg','image/webp'].includes(file.type)){alert('Only PNG, JPG or WebP artwork can be loaded.');return;}
if(urls[key])URL.revokeObjectURL(urls[key]);const url=URL.createObjectURL(file);const img=new Image();img.onload=()=>{art[key]=img;$('asset-status').textContent='User-provided artwork: '+Object.keys(art).filter(k=>art[k]).join(', ');$('asset-label').textContent='USER-IMPORTED ART · NO REDESIGN';};img.onerror=()=>{alert('Cannot decode image');URL.revokeObjectURL(url);};img.src=url;urls[key]=url;});}
loadArt('avatar-file','full');loadArt('head-file','head');loadArt('eyes-file','eyes');loadArt('mouth-file','mouth');loadArt('heart-file','heart');loadArt('gun-file','gun');loadArt('sword-file','sword');loadArt('feet-file','feet');loadArt('heels-file','heels');
$('clear-art').addEventListener('click',()=>{Object.keys(urls).forEach(k=>{URL.revokeObjectURL(urls[k]);delete urls[k];art[k]=null;});$('asset-status').textContent='No canonical image connected.';$('asset-label').textContent='NONCANONICAL PLACEHOLDER RIG';});
const state={schema:'lumina.frame.v1',visual_source:'synthetic-demo',simulated:true,elapsed_s:0,expression:'neutral',pose:'idle',yaw:0,gaze_x:0,gaze_y:0,blink:0,mouth:0,breath:0,bob:0,shimmer:0,pulse:0,ripple_rate:0,ripple_threshold:.45,ripple_drive:0,event_count:0,overdrive:0,scene_epoch:0,weapon_mode:'stowed',foot_mode:'compact',heart_power:0};
const quad=typeof RippleQPort==='function'?new RippleQPort():null;
const neuron=typeof RippleNeuron==='function'?new RippleNeuron():null;
let t=0,blinkAt=2.8,blinkStart=-10,rand=12345,paused=false,last=null,drops=0,drawn=0,fpsT=0,fps=0,remote=false,remoteAt=0,token=null,es=null,recording=null;
const move=(v,target,dt,tau)=>v+(target-v)*(1-Math.exp(-dt/tau));
function localStep(dt){let speed=Number($('speed').value);dt*=speed;dt=Math.min(dt,.5);t+=dt;
const gaze=Number($('gaze').value),mouth=Number($('speech').value),drive=Number($('drive').value);
const rgb=[drive,.16,.08],p=neuron?neuron.step(rgb,dt):{count:0,rate:0,theta:.45,drive:0};
state.visual_source='synthetic-demo';state.simulated=true;state.elapsed_s=t;state.expression=$('expression').value;state.weapon_mode=$('weapon-mode').value;state.foot_mode=$('foot-mode').value;state.heart_power=move(state.heart_power,Number($('heart').value),dt,.4);
state.ripple_rate=p.rate;state.ripple_threshold=p.theta;state.ripple_drive=p.drive;state.event_count=p.count;state.ripple_q_code=quad?quad.step(p.drive):2;
state.gaze_x=move(state.gaze_x,gaze,dt,.2);state.gaze_y=move(state.gaze_y,0,dt,.2);state.yaw=move(state.yaw,state.gaze_x*.23,dt,.3);
state.mouth=move(state.mouth,mouth,dt,.10);state.shimmer=move(state.shimmer,clamp(p.rate/3),dt,.45);state.pulse=move(state.pulse,p.count?1:0,dt,.22);
state.breath=.5+.5*Math.sin(2*Math.PI*t/4.2);state.bob=.35*Math.sin(2*Math.PI*t/4.2)+.25*Math.sin(2*Math.PI*t/8.6);
if(t>=blinkAt){blinkStart=blinkAt;rand=(Math.imul(rand,1664525)+1013904223)>>>0;blinkAt=t+2+2.5*rand/4294967296;}
const ph=t-blinkStart;state.blink=ph>=0&&ph<=.26?Math.max(0,1-Math.abs(ph-.13)/.13):0;
$('source').textContent='SYNTHETIC DEMONSTRATION / NO AI';$('signal-label').textContent='RIPPLE: SYNTHETIC RGB DRIVE';}
async function connect(){if(location.protocol==='file:')return;
try{const r=await fetch('/api/config',{cache:'no-store'});if(!r.ok)throw Error('not connected');const config=await r.json();if(config.schema!=='lumina.config.v1')throw Error('not lumina');token=config.token;
es=new EventSource('/api/stream');es.onmessage=e=>{try{const v=JSON.parse(e.data);if(v.schema!=='lumina.frame.v1')return;const keys=['elapsed_s','expression','pose','yaw','gaze_x','gaze_y','blink','mouth','breath','bob','shimmer','pulse','ripple_rate','ripple_threshold','ripple_drive','event_count','overdrive','ripple_q_code','ripple_q_symbol','weapon_mode','foot_mode','heart_power'];for(const k of keys)if(v[k]!==undefined)state[k]=v[k];state.simulated=v.simulated;state.visual_source=v.visual_source;remoteAt=performance.now();remote=true;$('connection').textContent='LOCAL PYTHON RUNTIME';$('dot').style.background='#63e7ba';$('source').textContent=v.simulated?'SIMULATED / PYTHON ENGINE':v.visual_source.toUpperCase()+' / REPORTED';$('signal-label').textContent='RIPPLE: '+v.visual_source.toUpperCase();}catch(err){console.warn(err)}};
es.onerror=()=>{remote=false;$('connection').textContent='OFFLINE BROWSER DEMO';$('dot').style.background='#dcb579'};
}catch{remote=false;$('connection').textContent='OFFLINE BROWSER DEMO';$('dot').style.background='#dcb579'}}
function imageLayer(img,x,y,w,h,rotate=0){if(!img)return;c.save();c.translate(x,y);c.rotate(rotate);c.drawImage(img,-w/2,-h/2,w,h);c.restore()}
function draw(){const W=960,H=1120;c.save();c.clearRect(0,0,W,H);
const g=c.createLinearGradient(0,0,W,H);g.addColorStop(0,'#102e3c');g.addColorStop(.46,'#081628');g.addColorStop(1,'#070b16');c.fillStyle=g;c.fillRect(0,0,W,H);
const phase=state.elapsed_s,sh=clamp(state.shimmer||0),detail=$('detail').value;
const cx=W*.5+state.gaze_x*13,cy=H*.51+state.bob*8;
// Decorative hologram room: distinct from avatar identity, not a literal holographic projection.
c.save();c.translate(cx,cy);for(let j=0;j<3;j++){c.beginPath();c.ellipse(0,0,230+j*67,390+j*34,0,0,Math.PI*2);c.strokeStyle=`rgba(82,220,221,${.12+.04*Math.sin(phase*.7+j)})`;c.lineWidth=j===0?3:1.4;c.stroke()}c.restore();
const n=detail==='low'?32:detail==='medium'?80:152;
for(let i=0;i<n;i++){const a=i*2.39996323+phase*.024*(i%3+1),r=(i*31%415)/415;
let x=cx+Math.cos(a)*(205+240*r),y=cy+Math.sin(a*.81)*(240+440*r);
const alpha=.13+.23*(.5+.5*Math.sin(phase*1.4+i*.3));c.fillStyle=`rgba(121,239,226,${alpha})`;
c.fillRect(x,y,detail==='high'?2:1,detail==='high'?2:1)}
// Internal stand-in rig. It intentionally does not assert the official face, hair, costume, or proportions.
if(!art.full&&!art.head&&!art.eyes&&!art.mouth){
c.save();c.translate(cx,cy);c.rotate(state.yaw*.14);
let torso=c.createLinearGradient(-140,170,140,520);torso.addColorStop(0,'#25485d');torso.addColorStop(1,'#0d2039');
c.beginPath();c.moveTo(-130,210);c.quadraticCurveTo(-177,240,-170,520);c.lineTo(170,520);c.quadraticCurveTo(177,240,130,210);c.quadraticCurveTo(0,164,-130,210);c.fillStyle=torso;c.fill();c.strokeStyle='rgba(110,229,221,.55)';c.lineWidth=3;c.stroke();
c.fillStyle='#385963';c.fillRect(-34,125,68,105);
c.beginPath();c.moveTo(-115,-150);c.bezierCurveTo(-138,-330,123,-330,124,-150);c.quadraticCurveTo(146,142,78,192);c.lineTo(-80,192);c.quadraticCurveTo(-141,120,-115,-150);c.fillStyle='#183951';c.fill();c.stroke();
c.beginPath();c.ellipse(0,-41,92,147,0,0,Math.PI*2);c.fillStyle='#91b4b8';c.fill();
c.beginPath();c.moveTo(-103,-168);c.quadraticCurveTo(-55,-318,32,-263);c.quadraticCurveTo(133,-210,104,-82);c.lineTo(69,-171);c.quadraticCurveTo(-4,-88,-94,-127);c.fillStyle='#132b46';c.fill();
for(const sign of [-1,1]){let x=sign*45+state.gaze_x*12,y=-51+state.gaze_y*8;
c.beginPath();c.ellipse(x,y,20,Math.max(1,15*(1-state.blink)),0,0,Math.PI*2);c.fillStyle='#0c2437';c.fill();c.beginPath();c.ellipse(x,y,8,Math.max(1,10*(1-state.blink)),0,0,Math.PI*2);c.fillStyle='#5cd5d6';c.fill();}
const mh=3+state.mouth*24;c.beginPath();c.ellipse(0,48,16,mh,0,0,Math.PI*2);c.fillStyle='#335061';c.fill();
if(state.expression==='happy'){c.beginPath();c.arc(0,28,37,.2,Math.PI-.2);c.strokeStyle='#396078';c.lineWidth=3;c.stroke()}
c.restore();}
else { // Author-provided images; keep the pixels intact, only move the imported layers.
 const root=art.full; if(root){const ratio=root.width/root.height;let h=820,w=h*ratio;if(w>710){w=710;h=w/ratio}imageLayer(root,cx,cy+60,w,h,state.yaw*.08)}
 if(art.head)imageLayer(art.head,cx+state.yaw*21,cy-146,440,440,state.yaw*.15);
 if(art.eyes)imageLayer(art.eyes,cx+state.gaze_x*8,cy-165,300,104);
 if(art.mouth)imageLayer(art.mouth,cx,cy-63,126,94+state.mouth*24);
 if(art.heart)imageLayer(art.heart,cx,cy+150,210+state.heart_power*8,200+state.heart_power*8);
 if(state.weapon_mode==='gun'&&art.gun)imageLayer(art.gun,cx+165,cy+210,270,380);
 if(state.weapon_mode==='sword'&&art.sword)imageLayer(art.sword,cx+190,cy+165,300,490);
 if(state.foot_mode==='compact'&&art.feet)imageLayer(art.feet,cx,cy+425,420,210);
 if(state.foot_mode==='heels'&&art.heels)imageLayer(art.heels,cx,cy+425,420,210);
}
// Scanline and pulse layers overlay but never alter input image bytes.
const scans=detail==='low'?12:detail==='medium'?32:64;
for(let i=0;i<scans;i++){let y=(i*31.6+phase*16)%H;c.fillStyle=`rgba(95,205,223,${.014+.014*sh})`;c.fillRect(100,y,W-200,1)}
const pulseA=clamp(.07+.19*state.pulse+.12*sh);c.strokeStyle=`rgba(135,255,220,${pulseA})`;c.lineWidth=3;c.beginPath();c.ellipse(cx,cy+360,230+state.pulse*18,24+state.pulse*8,0,0,Math.PI*2);c.stroke();
c.fillStyle='rgba(159,219,213,.7)';c.font='16px monospace';c.textAlign='left';c.fillText('L U M I N A  /  R I P P L E',42,105);c.font='13px monospace';c.fillText('SCENE '+String(state.scene_epoch).padStart(4,'0'),42,131);
c.textAlign='right';c.fillText('NO CONSCIOUSNESS CLAIM',W-42,105);c.fillText('CONTINUOUS LOCAL AVATAR',W-42,131);c.restore();
}
function updateLabels(){let sec=state.elapsed_s;$('clock').textContent=sec.toFixed(1)+' s';$('activity').textContent=(state.ripple_rate||0).toFixed(2);$('threshold').textContent=(state.ripple_threshold||.45).toFixed(2);$('pulse').textContent=String(state.event_count||0);$('dropped').textContent=String(drops);
$('q-label').textContent='Q / '+['−1','−0','0','+1'][state.ripple_q_code??2];
$('heart-out').textContent=Number($('heart').value).toFixed(2);
$('speed-out').textContent=Number($('speed').value).toFixed(2)+'×';$('gaze-out').textContent=Number($('gaze').value).toFixed(2);$('speech-out').textContent=Number($('speech').value).toFixed(2);$('drive-out').textContent=Number($('drive').value).toFixed(2);}
function loop(ts){if(last===null){last=ts;fpsT=ts;}let dt=(ts-last)/1000;last=ts;if(dt>.2)drops++;if(!paused){if(!remote||ts-remoteAt>1250){remote=false;localStep(clamp(dt,.001,.05));$('connection').textContent='OFFLINE BROWSER DEMO';$('dot').style.background='#dcb579';}draw();drawn++;}if(ts-fpsT>1000){fps=Math.round(drawn*1000/(ts-fpsT));$('frame-rate').textContent=fps+' FPS';drawn=0;fpsT=ts;}updateLabels();requestAnimationFrame(loop)}
$('pause').onclick=()=>{paused=!paused;$('pause').textContent=paused?'Resume':'Pause'};
$('snapshot').onclick=()=>{canvas.toBlob(blob=>{if(!blob)return;const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='lumina-frame.png';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)},'image/png')};
$('record').onclick=()=>{if(recording){recording.stop();return}if(!canvas.captureStream||typeof MediaRecorder==='undefined'){alert('WebM recording unavailable in this browser. PNG export works.');return}const stream=canvas.captureStream(24);let chunks=[];try{const mime=['video/webm;codecs=vp9','video/webm;codecs=vp8','video/webm'].find(m=>MediaRecorder.isTypeSupported(m));recording=new MediaRecorder(stream,mime?{mimeType:mime}:undefined);recording.ondataavailable=e=>{if(e.data.size)chunks.push(e.data)};recording.onstop=()=>{const blob=new Blob(chunks,{type:recording.mimeType});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='lumina-animation.webm';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);recording=null;$('record').textContent='Record WebM';stream.getTracks().forEach(t=>t.stop())};recording.start(200);$('record').textContent='Stop recording';}catch(e){recording=null;alert(String(e))}};
for(const id of ['expression','speed','gaze','speech','drive','weapon-mode','foot-mode','heart'])$(id).addEventListener('input',async()=>{if(!remote||!token)return; // manually supplied values, not model-generated or sensor measured
 const packet={schema:'lumina.control.v1',source:'human-control',ripple_rgb:[Number($('drive').value),.16,.08],look_x:Number($('gaze').value),speech_amplitude:Number($('speech').value),expression:$('expression').value,pose:'idle',weapon_mode:$('weapon-mode').value,foot_mode:$('foot-mode').value,heart_power:Number($('heart').value)};
 try{await fetch('/api/packet',{method:'POST',headers:{'Content-Type':'application/json','X-Lumina-Token':token},body:JSON.stringify(packet)});}catch{}});
if(document.hidden)paused=true;document.addEventListener('visibilitychange',()=>{if(document.hidden){paused=true;$('pause').textContent='Resume'}});
connect();useReference();requestAnimationFrame(loop);
window.__luminaLoadReference=useReference;
window.__luminaDebug=()=>({state:{...state},remote,paused,assetKeys:Object.keys(art).filter(k=>!!art[k]),fps,drops});
})();
