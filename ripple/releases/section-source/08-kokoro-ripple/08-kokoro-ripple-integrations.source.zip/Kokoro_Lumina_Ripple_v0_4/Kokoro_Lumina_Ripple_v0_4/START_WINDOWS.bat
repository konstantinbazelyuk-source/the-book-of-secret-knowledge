@echo off
cd /d "%~dp0"
where python >nul 2>nul || (echo Python 3.10 or newer is required.&pause&exit /b 1)
python -m unittest discover -s tests -v || (echo Tests failed&pause&exit /b 1)
python -m kokoro_lumina server --port 8765 --open
pause
