"""Kokoro Lumina v0.4: deterministic frame-state engine and public avatar ports.
No LLM weights, unapproved character art, or claimed consciousness included.
"""
from .engine import LuminaEngine, PacketError, FramePacket
__all__=['LuminaEngine','PacketError','FramePacket']
