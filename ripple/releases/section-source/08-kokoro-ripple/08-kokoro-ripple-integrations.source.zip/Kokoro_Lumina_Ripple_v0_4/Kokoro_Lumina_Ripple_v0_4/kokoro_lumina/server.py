"""Localhost-only continuous Lumina controller/preview. No cloud uploads or recording by default."""
import json,secrets,time,threading,math
from dataclasses import asdict
from pathlib import Path
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from urllib.parse import urlparse
from .engine import LuminaEngine,PacketError

ROOT=Path(__file__).resolve().parent.parent
class LuminaServer(ThreadingHTTPServer):
    daemon_threads=True
    def __init__(self,addr):
        super().__init__(addr,LuminaHandler)
        self.engine=LuminaEngine();self.lock=threading.Lock();self.token=secrets.token_urlsafe(32)
        self.latest=None;self.received_at=0.;self.last=time.monotonic();self.mode='demo';self.started=time.monotonic()
    def tick(self):
        now=time.monotonic()
        with self.lock:
            dt=max(.001,min(.5,now-self.last));self.last=now
            if self.mode=='input' and now-self.received_at>5:
                self.latest=None;self.mode='demo' # Stale control never impersonates live AI indefinitely.
            if self.mode=='demo':
                elapsed=now-self.started
                packet={'schema':'lumina.control.v1','source':'synthetic-demo',
                'ripple_rgb':[.32+.28*(.5+.5*math.sin(elapsed*.6)),.17,.05],
                'look_x':.45*math.sin(elapsed*.37),'look_y':.2*math.sin(elapsed*.22),
                'speech_amplitude':0.,'pose':'idle','expression':'neutral'}
            else:packet=self.latest
            return asdict(self.engine.advance(dt,packet))
class LuminaHandler(BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def write_json(self,obj,status=200):
        data=json.dumps(obj,allow_nan=False).encode();self.send_response(status)
        self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff');self.send_header('Content-Length',str(len(data)))
        self.end_headers();self.wfile.write(data)
    def do_GET(self):
        path=urlparse(self.path).path
        if path in ('/','/index.html','/lumina.js','/quaternary-port.js','/vrm.html','/vrm-view.js','/style.css','/assets/Adelita_Kokoro_reference.png'):
            file=(ROOT/'assets/Adelita_Kokoro_reference.png') if path.startswith('/assets/') else ROOT/'web'/('index.html' if path in ('/','/index.html') else path.lstrip('/'))
            raw=file.read_bytes();self.send_response(200)
            self.send_header('Content-Type',{'html':'text/html; charset=utf-8','js':'text/javascript; charset=utf-8','css':'text/css; charset=utf-8','png':'image/png'}[file.suffix[1:]])
            self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw);return
        if path=='/api/config':return self.write_json({'schema':'lumina.config.v1','token':self.server.token,'mode':self.server.mode})
        if path=='/api/state':return self.write_json(self.server.tick())
        if path=='/api/stream':
            self.send_response(200);self.send_header('Content-Type','text/event-stream');self.send_header('Cache-Control','no-store')
            self.send_header('X-Accel-Buffering','no');self.end_headers()
            try:
                while True:
                    data='data: '+json.dumps(self.server.tick(),allow_nan=False)+'\n\n'
                    self.wfile.write(data.encode());self.wfile.flush();time.sleep(1/self.server.engine.fps_cap)
            except (BrokenPipeError,ConnectionResetError,ConnectionAbortedError):pass
            return
        return self.write_json({'error':'not_found'},404)
    def do_POST(self):
        if urlparse(self.path).path!='/api/packet':return self.write_json({'error':'not_found'},404)
        # Localhost binding PLUS non-simple JSON request + bearer-like anti-CSRF token.
        if self.headers.get('X-Lumina-Token')!=self.server.token or self.headers.get('Content-Type','').split(';')[0]!='application/json':
            return self.write_json({'error':'permission_denied'},403)
        host=self.headers.get('Host','')
        origin=self.headers.get('Origin')
        if origin and origin not in (f'http://{host}',):return self.write_json({'error':'origin_denied'},403)
        try:
            n=int(self.headers.get('Content-Length','0'))
            if not 2<=n<=4096:raise PacketError('invalid request size')
            packet=json.loads(self.rfile.read(n));packet=self.server.engine.validate(packet)
        except (ValueError,PacketError,UnicodeDecodeError,TypeError):return self.write_json({'error':'invalid_packet'},400)
        with self.server.lock:self.server.latest=packet;self.server.received_at=time.monotonic();self.server.mode='input'
        return self.write_json({'accepted':True,'source':packet['source'],'warning':'Reported input is not sensor verification or a trained model'})

def serve(port=8765,open_browser=False):
    server=LuminaServer(('127.0.0.1',port))
    address=f'http://127.0.0.1:{server.server_port}/'
    print('Lumina local preview:',address,flush=True)
    if open_browser:
        import webbrowser;threading.Timer(.5,lambda:webbrowser.open(address)).start()
    try:server.serve_forever(poll_interval=.1)
    finally:server.server_close()
