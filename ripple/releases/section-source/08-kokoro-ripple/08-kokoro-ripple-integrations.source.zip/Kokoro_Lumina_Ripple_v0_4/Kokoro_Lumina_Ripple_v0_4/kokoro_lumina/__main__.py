import argparse,json,sys
from dataclasses import asdict
from .engine import LuminaEngine
from .offscreen import export,export_reference
from .server import serve
from .continuous import render_loop

def main():
 p=argparse.ArgumentParser(description='Kokoro Lumina v0.4 stand-alone rendering module')
 sub=p.add_subparsers(dest='command',required=True)
 s=sub.add_parser('server');s.add_argument('--port',type=int,default=8765);s.add_argument('--open',action='store_true')
 s=sub.add_parser('export');s.add_argument('--out',required=True);s.add_argument('--frames',type=int,default=90);s.add_argument('--fps',type=int,default=24);s.add_argument('--reference',default=None)
 s=sub.add_parser('frame');s.add_argument('--input',default=None)
 s=sub.add_parser('continuous');s.add_argument('--out',default='results/live');s.add_argument('--duration',type=float,default=10);s.add_argument('--fps',type=int,default=12);s.add_argument('--packet-file',default=None)
 a=p.parse_args()
 if a.command=='server':serve(a.port,a.open)
 elif a.command=='export':print(export_reference(LuminaEngine(),a.reference,a.out,frames=a.frames,fps=a.fps) if a.reference else export(LuminaEngine(),a.out,frames=a.frames,fps=a.fps))
 elif a.command=='continuous':print(json.dumps(render_loop(output=a.out,duration_s=a.duration,fps=a.fps,packet_file=a.packet_file),indent=2))
 else:
  packet=json.loads(open(a.input).read()) if a.input else None
  print(json.dumps(asdict(LuminaEngine().advance(.05,packet)),indent=2))
if __name__=='__main__':main()
