"""Explicit drop-in Lumina port for previous Kokoro Mesh, no checkpoint mutation."""
from __future__ import annotations
from dataclasses import asdict
from .engine import LuminaEngine,PacketError

class LuminaRenderBoard:
    name='lumina'
    def __init__(self,engine=None):self.engine=engine or LuminaEngine()
    async def run(self,p):
        # Accept only explicit scene commands, never the entire Mesh prompt as numeric 'emotions'.
        x=p.get('lumina_control')
        if x is None:return {'status':'unavailable','reason':'No explicit Lumina control input; renderer remains independently idle'}
        if not isinstance(x,dict):raise PacketError('lumina_control must be an object')
        frame=self.engine.advance(.05,x)
        return {'status':'available','rendered':False,'kind':'renderable-temporal-frame','frame':asdict(frame),
                'note':'Browser or headless renderer draws frame; this adapter does not claim an image render.'}
