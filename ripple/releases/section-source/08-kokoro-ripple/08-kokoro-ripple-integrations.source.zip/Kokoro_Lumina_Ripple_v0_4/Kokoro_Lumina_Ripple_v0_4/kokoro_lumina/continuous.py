"""Bounded continuous image output to an isolated directory, independent of a browser.
No ongoing process is started unless the user runs CLI. Device CPU usage capped by FPS.
"""
from __future__ import annotations
import json,os,time,math
from dataclasses import asdict
from pathlib import Path
from .engine import LuminaEngine
from .offscreen import render_frame

def render_loop(output='results/live',duration_s=10.,fps=12,seed=17,packet_file=None,size=(480,600)):
    if not isinstance(fps,int) or isinstance(fps,bool) or not 1<=fps<=24:raise ValueError('continuous fps must be 1..24')
    if not isinstance(duration_s,(int,float)) or not math.isfinite(duration_s) or duration_s<0 or duration_s>86400:raise ValueError('duration 0..86400; 0 = until interrupted')
    out=Path(output);out.mkdir(parents=True,exist_ok=True)
    model=LuminaEngine(seed=seed,fps_cap=24)
    dt=1./fps;n=0;errors=0;durations=[];starts=time.perf_counter();end=starts+duration_s if duration_s else math.inf
    try:
        while time.perf_counter()<end:
            target=starts+n*dt
            remaining=target-time.perf_counter()
            if remaining>0:time.sleep(remaining)
            now=time.perf_counter()
            if duration_s and now>=end and n>0:break
            input_packet=None
            if packet_file:
                try:
                    path=Path(packet_file)
                    if path.stat().st_size>4096:raise ValueError('packet_file exceeds 4096 bytes')
                    input_packet=json.loads(path.read_text())
                except (OSError,ValueError,UnicodeError,json.JSONDecodeError):errors+=1
            else:
                elapsed=now-starts
                input_packet={'schema':'lumina.control.v1','source':'synthetic-demo',
                  'ripple_rgb':[.31+.23*(.5+.5*math.sin(elapsed*.7)),.16,.08],
                  'look_x':.3*math.sin(elapsed*.6),'expression':'neutral','pose':'idle'}
            try:frame=asdict(model.advance(dt,input_packet))
            except (ValueError,TypeError):
                errors+=1;frame=asdict(model.advance(dt))
            img=render_frame(frame,size)
            # Never write into Kokoro original tree by default; atomically replace generated frame only.
            path=out/'latest.png';temporary=out/'latest.partial.png'
            img.save(temporary,format='PNG');os.replace(temporary,path)
            metadata=out/'latest_state.json';tempstate=out/'latest_state.partial.json'
            tempstate.write_text(json.dumps(frame,allow_nan=False,indent=2)+'\n');os.replace(tempstate,metadata)
            durations.append(time.perf_counter()-now);n+=1
            # Avoid trying to "catch up" on a stalled CPU by generating a huge burst.
            if (time.perf_counter()-starts)>(n+1)*dt:n=int((time.perf_counter()-starts)/dt)
    except KeyboardInterrupt:pass
    elapsed=time.perf_counter()-starts
    result={'classification':'REAL headless PNG writing; source is explicit synthetic-demo or reported file input, no Kokoro model or sensor claim',
       'frames_written':len(durations),'wall_s':round(elapsed,4),'observed_png_output_rate_hz':round(len(durations)/max(elapsed,1e-9),3),
       'median_render_encode_ms':round(1000*sorted(durations)[len(durations)//2],3) if durations else None,
       'packet_errors':errors,'output':str(out.resolve())}
    (out/'run_summary.json').write_text(json.dumps(result,indent=2)+'\n')
    return result
