"""Deterministic actual raster PNG/GIF generator; optional Pillow dependency.
Draws a NONCANONICAL placeholder silhouette only until user supplies approved artwork.
"""
from __future__ import annotations
import math
from pathlib import Path

def render_frame(frame,size=(480,600)):
    try:from PIL import Image,ImageDraw,ImageFilter
    except ImportError as e:raise RuntimeError('Pillow required for offscreen PNG/GIF. pip install pillow') from e
    w,h=size
    if not(160<=w<=2000 and 160<=h<=2000):raise ValueError('resolution must be 160..2000')
    bg=Image.new('RGB',(w,h),(9,16,31));d=ImageDraw.Draw(bg,'RGBA')
    cx,cy=w//2,int(h*.42+frame['bob']*4)
    # faint bounded particle/oscillation field not interpreted as thought
    for i in range(42):
        x=int((w*(.5+.43*math.sin(i*1.618+frame['elapsed_s']*.12))))
        y=int((h*(.5+.43*math.sin(i*2.22-frame['elapsed_s']*.18))))
        d.ellipse((x-1,y-1,x+1,y+1),fill=(100,225,230,35+int(45*frame['shimmer'])))
    # Background focal rings
    d.ellipse((cx-w*.30,cy-h*.26,cx+w*.30,cy+h*.26),outline=(70,203,220,55),width=2)
    d.ellipse((cx-w*.37,cy-h*.33,cx+w*.37,cy+h*.33),outline=(70,203,220,20),width=1)
    # placeholder rig: torso, hair, face silhouette
    scale=w/480
    def p(v):return int(v*scale)
    d.ellipse((cx-p(88),cy+p(125),cx+p(88),cy+p(302)),fill=(32,61,91,240),outline=(100,230,229,130),width=max(1,p(2)))
    d.rectangle((cx-p(18),cy+p(90),cx+p(18),cy+p(153)),fill=(65,126,138,255))
    d.ellipse((cx-p(80),cy-p(120),cx+p(80),cy+p(130)),fill=(19,52,86,255),outline=(74,216,232,180),width=max(1,p(2)))
    d.ellipse((cx-p(60),cy-p(83),cx+p(60),cy+p(104)),fill=(159,205,202,255))
    # eye pupils, blink and mouth (placeholder only)
    eyeh=max(1,p(12*(1-frame['blink'])))
    for ex in (-30,30):
        x=cx+p(ex+frame['gaze_x']*6);y=cy+p(-7+frame['gaze_y']*4)
        d.ellipse((x-p(11),y-eyeh,x+p(11),y+eyeh),fill=(9,24,41,255))
        d.ellipse((x-p(4),y-p(4),x+p(4),y+p(4)),fill=(60,245,247,255))
    mh=max(1,p(2+frame['mouth']*16));d.ellipse((cx-p(10),cy+p(47)-mh,cx+p(10),cy+p(47)+mh),fill=(26,38,55,220))
    d.line((p(36),h-p(54),w-p(36),h-p(54)),fill=(120,227,233,100),width=max(1,p(2)))
    return bg

def export(engine,out,frames=90,fps=24,size=(480,600)):
    if not 1<=frames<=900 or not 1<=fps<=60:raise ValueError('invalid frames/fps')
    from dataclasses import asdict
    out=Path(out);out.parent.mkdir(parents=True,exist_ok=True)
    suffix=out.suffix.lower()
    imgs=[]
    for i in range(frames):
        # A labeled DEMO input, not a claim of live Kokoro telemetry
        t=i/fps
        packet={'schema':'lumina.control.v1','source':'synthetic-demo',
           'ripple_rgb':[.38+.25*(.5+.5*math.sin(t*2)),.20,.10],
           'look_x':.42*math.sin(t*.5),'look_y':.2*math.sin(t*.32),
           'speech_amplitude':max(0,math.sin(t*3.8))*.24,'expression':'neutral','pose':'idle'}
        frame=asdict(engine.advance(1/fps,packet));imgs.append(render_frame(frame,size))
    if suffix=='.gif':imgs[0].save(out,save_all=True,append_images=imgs[1:],duration=max(16,int(1000/fps)),loop=0,optimize=False)
    elif suffix=='.png':imgs[-1].save(out)
    else:raise ValueError('Only .png or .gif supported')
    return out

def render_reference_frame(frame,source,size=(480,600)):
    """Animate placement of user-owned original art by ~3 px; never inpaint or synthesize its pixels.
    Creates NEW composited output, preserving the original input file exactly.
    """
    from PIL import Image,ImageOps,ImageDraw
    import math
    w,h=size
    src=source if isinstance(source,Image.Image) else Image.open(source)
    src=src.convert('RGBA')
    art=ImageOps.contain(src,(w,h),method=Image.Resampling.LANCZOS)
    bg=Image.new('RGBA',(w,h),(8,17,28,255))
    dx=int(2.5*math.sin(frame['elapsed_s']*.65));dy=int(2.5*math.sin(frame['elapsed_s']*1.0))
    bg.alpha_composite(art,((w-art.width)//2+dx,(h-art.height)//2+dy))
    # Hologram overlay stays at frame perimeter, so original face/body/text aren't repainted.
    overlay=Image.new('RGBA',(w,h),(0,0,0,0));d=ImageDraw.Draw(overlay)
    pulse=max(0,min(1,float(frame.get('pulse',0))))
    a=int(38+70*pulse)
    m=max(6,int(.035*w));short=int(.08*w)
    for x,y,sx,sy in [(m,m,1,1),(w-m,m,-1,1),(m,h-m,1,-1),(w-m,h-m,-1,-1)]:
        d.line((x,y,x+sx*short,y),fill=(104,251,234,a),width=2)
        d.line((x,y,x,y+sy*short),fill=(104,251,234,a),width=2)
    y=int((frame['elapsed_s']*35)%h)
    d.line((m,y,w-m,y),fill=(90,220,216,28),width=1)
    bg=Image.alpha_composite(bg,overlay)
    return bg.convert('RGB')

def export_reference(engine,source,out,frames=48,fps=24,size=(480,600)):
    if not 1<=frames<=240 or not 1<=fps<=60:raise ValueError('bounded reference export only')
    from dataclasses import asdict
    from PIL import Image
    source=Path(source);out=Path(out);out.parent.mkdir(parents=True,exist_ok=True)
    art=Image.open(source).convert('RGBA')
    if max(art.size)>8192:raise ValueError('source exceeds size limit')
    imgs=[]
    for i in range(frames):
        t=i/fps
        packet={'schema':'lumina.control.v1','source':'synthetic-demo',
           'ripple_rgb':[.35+.2*(.5+.5*math.sin(t*.7)),.2,.1]}
        frame=asdict(engine.advance(1/fps,packet))
        imgs.append(render_reference_frame(frame,art,size))
    if out.suffix.lower()=='.png':imgs[-1].save(out)
    elif out.suffix.lower()=='.gif':imgs[0].save(out,save_all=True,append_images=imgs[1:],duration=max(16,int(1000/fps)),loop=0,optimize=False)
    else:raise ValueError('out must end with png or gif')
    return out
