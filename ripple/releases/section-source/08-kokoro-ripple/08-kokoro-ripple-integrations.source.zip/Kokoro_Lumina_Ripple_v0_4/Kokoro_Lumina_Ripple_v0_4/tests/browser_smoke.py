"""Chromium offline smoke: assets inlined because loopback navigation is sandbox-blocked."""
import asyncio,json,base64
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
async def run():
    async with async_playwright() as p:
        browser=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
        # Chromium sandbox forbids navigation to localhost; inline only our own local assets.
        html=(ROOT/'web/index.html').read_text()
        css=(ROOT/'web/style.css').read_text()
        original=(ROOT/'baseline/ripple_core_v0_1.js').read_text()
        viewer=(ROOT/'web/lumina.js').read_text()
        qport=(ROOT/'web/quaternary-port.js').read_text()
        source_data='data:image/png;base64,'+base64.b64encode((ROOT/'assets/Adelita_Kokoro_reference.png').read_bytes()).decode()
        html=html.replace('../assets/Adelita_Kokoro_reference.png',source_data)
        html=html.replace('<link rel="stylesheet" href="style.css">','<style>'+css+'</style>')
        html=html.replace('<script src="../baseline/ripple_core_v0_1.js"></script>','<script>'+original+'</script>')
        html=html.replace('<script src="quaternary-port.js"></script>','<script>'+qport+'</script>')
        html=html.replace('<script src="lumina.js"></script>','<script>'+viewer+'</script>')
        results=[]
        for width,height in [(1365,850),(390,844)]:
            context=await browser.new_context(viewport={'width':width,'height':height},device_scale_factor=1,accept_downloads=True)
            page=await context.new_page();errors=[]
            page.on('pageerror',lambda e:errors.append(str(e)))
            await page.set_content(html,wait_until='domcontentloaded')
            await page.wait_for_timeout(2500)
            d=await page.evaluate('window.__luminaDebug()')
            assert d['state']['elapsed_s']>0,d
            assert d['remote'] is False,d
            assert d['fps']>2,d
            assert not errors,errors
            assert await page.locator('canvas').evaluate('(e)=>{const d=e.getContext("2d").getImageData(450,560,1,1);return d.data[3] > 0}')
            png=ROOT/'results'/f'browser_{width}.png'
            await page.screenshot(path=str(png),full_page=True)
            if width==1365:
                # Real recovered user artwork through an in-memory data URI. No server/network navigation.
                original='data:image/png;base64,'+base64.b64encode((ROOT/'assets/Adelita_Kokoro_reference.png').read_bytes()).decode()
                await page.evaluate('(src)=>window.__luminaLoadReference(src)',original)
                await page.wait_for_timeout(450)
                assert 'full' in (await page.evaluate('window.__luminaDebug()'))['assetKeys']
                await page.screenshot(path=str(ROOT/'results'/'browser_authored_reference_1365.png'),full_page=True)
            await page.locator('#pause').click();await page.wait_for_timeout(80)
            assert (await page.locator('#pause').inner_text())=='Resume'
            await page.locator('#pause').click()
            await page.locator('#drive').evaluate("e=>{e.value='.78';e.dispatchEvent(new Event('input',{bubbles:true}))}")
            await page.wait_for_timeout(150)
            self_debug=await page.evaluate('window.__luminaDebug()')
            assert self_debug['state']['simulated'] is True,self_debug
            await page.locator('#avatar-file').set_input_files(str(ROOT/'results/lumina_placeholder_still.png'))
            await page.wait_for_timeout(130)
            assert 'full' in (await page.evaluate('window.__luminaDebug()'))['assetKeys']
            results.append({'viewport':f'{width}x{height}','browser_fps':d['fps'],'source_initial':d['state']['visual_source'],'test_mode':'inline browser assets; HTTP separately verified','png':str(png),'errors':errors,'passed':True})
            await context.close()
        await browser.close()
    (ROOT/'results'/'browser_smoke.json').write_text(json.dumps({'tests':results},indent=2)+'\n')
    print(json.dumps(results,indent=2))
if __name__=='__main__':asyncio.run(run())
