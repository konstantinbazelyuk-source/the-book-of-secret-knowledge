import json,threading,time,unittest,urllib.request,urllib.error
from kokoro_lumina.server import LuminaServer
class TestServer(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.s=LuminaServer(('127.0.0.1',0));cls.url='http://127.0.0.1:'+str(cls.s.server_port)
  cls.thread=threading.Thread(target=cls.s.serve_forever,daemon=True);cls.thread.start()
 @classmethod
 def tearDownClass(cls):cls.s.shutdown();cls.s.server_close();cls.thread.join(timeout=3)
 def get(self,path):
  with urllib.request.urlopen(self.url+path,timeout=3) as r:return json.loads(r.read().decode())
 def post(self,data,token=None,origin=None,ctype='application/json'):
  headers={'Content-Type':ctype,'X-Lumina-Token':token or 'wrong'}
  if origin:headers['Origin']=origin
  req=urllib.request.Request(self.url+'/api/packet',data=json.dumps(data).encode(),headers=headers,method='POST')
  try:
   with urllib.request.urlopen(req,timeout=3) as r:return r.status,json.loads(r.read().decode())
  except urllib.error.HTTPError as e:return e.code,json.loads(e.read().decode())
 def test_config_and_frame(self):
  a=self.get('/api/config');b=self.get('/api/state');self.assertEqual(a['schema'],'lumina.config.v1');self.assertEqual(b['schema'],'lumina.frame.v1');self.assertEqual(b['visual_source'],'synthetic-demo')
 def test_csrf(self):
  packet={'schema':'lumina.control.v1','source':'human-control','ripple_rgb':[.7,.2,.1]}
  self.assertEqual(self.post(packet)[0],403)
  self.assertEqual(self.post(packet,token=self.s.token,origin='https://evil.example')[0],403)
  self.assertEqual(self.post(packet,token=self.s.token)[0],200)
  self.assertEqual(self.get('/api/state')['visual_source'],'human-control')
 def test_serves_only_allowlisted_reference_art(self):
  with urllib.request.urlopen(self.url+'/assets/Adelita_Kokoro_reference.png',timeout=3) as r:
   self.assertEqual(r.headers.get_content_type(),'image/png')
   self.assertEqual(r.read()[:8],bytes.fromhex('89504e470d0a1a0a'))
  try:urllib.request.urlopen(self.url+'/assets/../../etc/passwd',timeout=3)
  except urllib.error.HTTPError as e:self.assertEqual(e.code,404)
  else:self.fail('path traversal should fail')
 def test_no_autonomous_inference(self):
  self.assertEqual(self.s.engine.asset,'placeholder')
  self.assertFalse(hasattr(self.s.engine,'model'))
 def test_invalid_fields(self):
  packet={'schema':'lumina.control.v1','source':'human-control','expression':'omniscient'}
  self.assertEqual(self.post(packet,token=self.s.token)[0],400)
 def test_sse(self):
  with urllib.request.urlopen(self.url+'/api/stream',timeout=4) as r:
   self.assertEqual(r.headers.get_content_type(),'text/event-stream')
   line=r.readline().decode();self.assertTrue(line.startswith('data: '))
   packet=json.loads(line[6:]);self.assertEqual(packet['schema'],'lumina.frame.v1')
if __name__=='__main__':unittest.main()
