import asyncio,hashlib,json,math,random,subprocess,sys,tempfile,unittest
from dataclasses import asdict
from pathlib import Path
from kokoro_lumina.engine import LuminaEngine,PacketError,FramePacket
from kokoro_lumina.bridge import LuminaRenderBoard
from kokoro_lumina.quaternary import QuadEncoder
from baseline.kokoro_mesh.runtime import Mesh
BASE=Path(__file__).resolve().parents[1]
class TestLumina(unittest.TestCase):
    def packet(self,**kw):return {'schema':'lumina.control.v1','source':'human-control',**kw}
    def test_direct_frame(self):
        a=LuminaEngine().advance(.05)
        self.assertEqual(a.schema,'lumina.frame.v1');self.assertTrue(a.simulated);self.assertEqual(a.ripple_drive,0)
    def test_ripple_event(self):
        e=LuminaEngine()
        a=[e.advance(.05,self.packet(ripple_rgb=[.6,.2,.1])) for i in range(250)]
        self.assertGreater(sum(x.event_count for x in a),0)
        self.assertTrue(all(.15<=x.ripple_threshold<=2.5 for x in a))
    def test_validation(self):
        cases=[{'schema':'invalid','source':'human-control'},self.packet(ripple_rgb=[math.nan,0,0]),
             self.packet(ripple_rgb=[0,0]),self.packet(ripple_rgb=[False,0,0]),
             self.packet(speech_amplitude=-1),self.packet(expression='omniscient'),
             self.packet(source='unknown'),self.packet(extra='no'),self.packet(scene_epoch=True),self.packet(weapon_mode='plasma cannon'),self.packet(foot_mode='flight'),self.packet(heart_power=1.5)]
        e=LuminaEngine()
        for p in cases:
            with self.subTest(p=p),self.assertRaises(PacketError):e.advance(.03,p)
    def test_duration(self):
        e=LuminaEngine()
        for dt in [0,-1,.51,math.nan,math.inf,True]:
            with self.subTest(dt=dt),self.assertRaises(PacketError):e.advance(dt)
    def test_seed_determinism(self):
        a=LuminaEngine(seed=13);b=LuminaEngine(seed=13)
        for i in range(200):self.assertEqual(a.advance(.05),b.advance(.05))
    def test_blink_exists(self):
        e=LuminaEngine(seed=4)
        self.assertTrue(any(e.advance(.01).blink>.01 for _ in range(1000)))
    def test_author_defined_transform_controls(self):
        e=LuminaEngine();v=e.advance(.05,self.packet(weapon_mode='gun',foot_mode='heels',heart_power=.8))
        self.assertEqual(v.weapon_mode,'gun');self.assertEqual(v.foot_mode,'heels')
        self.assertTrue(0<v.heart_power<.8)
        v=e.advance(.05,self.packet(weapon_mode='sword',foot_mode='compact',heart_power=.1))
        self.assertEqual(v.weapon_mode,'sword');self.assertEqual(v.foot_mode,'compact')

    def test_source_preservation(self):
        f=LuminaEngine().advance(.05,self.packet(source='human-control',ripple_rgb=[.2,.4,.8]))
        self.assertEqual(f.visual_source,'human-control');self.assertFalse(f.simulated)
        self.assertNotIn('consciousness',asdict(f))
    def test_state_bounded(self):
        e=LuminaEngine()
        for i in range(2000):
            a=e.advance(.05,self.packet(ripple_rgb=[1,1,0] if i<1000 else [0,0,1],look_x=(-1)**i,look_y=.3,speech_amplitude=i%3/2,overdrive=i%2))
            for k in ('mouth','shimmer','pulse','blink','overdrive','breath'):
                self.assertGreaterEqual(getattr(a,k),0);self.assertLessEqual(getattr(a,k),1.00001)
    def test_adaptive_smoothing(self):
        a=LuminaEngine();b=LuminaEngine()
        p=self.packet(look_x=1,ripple_rgb=[.3,0,0])
        for _ in range(5):fa=a.advance(.1,p)
        for _ in range(10):fb=b.advance(.05,p)
        self.assertAlmostEqual(fa.gaze_x,fb.gaze_x,places=4)
    def test_quaternary_state(self):
        q=QuadEncoder();r=[q.step(d)['code'] for d in [0,0,.4,.4,.4,0,0,0,-.4,-.4,-.4]]
        self.assertIn(3,r);self.assertIn(0,r);self.assertTrue(all(0<=x<=3 for x in r))
    def test_mesh_integration(self):
        async def run():
            mesh=Mesh(external={'lumina':LuminaRenderBoard()})
            req={'continuity_capsule':{'identity':'Kokoro'},'lumina_control':self.packet(ripple_rgb=[.4,.2,.1]),'user_text':'renderer test'}
            return await mesh.run(req)
        out=asyncio.run(run());self.assertEqual(out['boards']['lumina']['status'],'available')
        self.assertFalse(out['boards']['lumina']['rendered']);self.assertEqual(out['gates']['wake_to_facts'],'blocked')
    def test_unavailable_without_real_input(self):
        async def run():return await LuminaRenderBoard().run({})
        self.assertEqual(asyncio.run(run())['status'],'unavailable')
    def test_recovered_art_sha_preserved(self):
        src=BASE/'assets/Adelita_Kokoro_reference.png'
        assert src.exists()
        with __import__('PIL.Image',fromlist=['open']).open(src) as img:self.assertGreater(img.width,300)
        with tempfile.TemporaryDirectory() as d:
            from kokoro_lumina.offscreen import export_reference
            before=hashlib.sha256(src.read_bytes()).digest()
            out=export_reference(LuminaEngine(),src,Path(d)/'ref.png',frames=2,size=(320,400))
            self.assertTrue(out.stat().st_size>5000)
            self.assertEqual(hashlib.sha256(src.read_bytes()).digest(),before)

    def test_canonical_core_hash(self):
        a=(BASE/'baseline/ripple_core_v0_1.js').read_bytes()
        b=Path('/mnt/data/Kokoro_Mesh_Ripple_v0_3/sources/ripple_core_v0_1.js')
        if b.exists():self.assertEqual(hashlib.sha256(a).digest(),hashlib.sha256(b.read_bytes()).digest())
    def test_continuous_bounded_png(self):
        from kokoro_lumina.continuous import render_loop
        with tempfile.TemporaryDirectory() as d:
            s=render_loop(d,duration_s=.29,fps=10,size=(160,200))
            self.assertGreaterEqual(s['frames_written'],2)
            self.assertEqual(s['packet_errors'],0)
            self.assertTrue((Path(d)/'latest.png').stat().st_size>1000)
            self.assertEqual(json.loads((Path(d)/'latest_state.json').read_text())['schema'],'lumina.frame.v1')

    def test_offscreen(self):
        from kokoro_lumina.offscreen import render_frame,export
        e=LuminaEngine();f=asdict(e.advance(.05))
        img=render_frame(f,(320,400));self.assertEqual(img.size,(320,400))
        with tempfile.TemporaryDirectory() as d:
            path=export(LuminaEngine(),Path(d)/'test.gif',frames=8,fps=10,size=(320,400))
            self.assertTrue(path.stat().st_size>1000)
    def test_50_reproducible_simulated_scenarios(self):
        """50 distinct seeded cases x 240 steps; real execution, synthetic input."""
        results=[]
        for scenario in range(50):
            rng=random.Random(5000+scenario)
            e=LuminaEngine(seed=700+scenario)
            events=0;max_rate=0
            for step in range(240):
                dt=(1/60,1/30,.05)[scenario%3]
                base=(scenario%10)/12
                noise=(rng.random()-.5)*(.01+(scenario//10)*.08)
                r=max(0,min(1,base+noise+(0.28 if 80<=step<160 else 0)))
                f=e.advance(dt,self.packet(source='synthetic-demo',ripple_rgb=[r,.15+(scenario%4)*.05,.1],
                  look_x=math.sin(step/35),look_y=math.cos(step/50),speech_amplitude=.3 if step%17<5 else 0,
                  expression=('neutral','focused','curious','relaxed')[scenario%4],pose='idle',overdrive=.9 if scenario>=40 else .1))
                self.assertEqual(f.schema,'lumina.frame.v1');self.assertEqual(f.ripple_q_symbol,('-1','-0','0','1')[f.ripple_q_code])
                self.assertTrue(all(math.isfinite(x) for x in [f.mouth,f.ripple_rate,f.ripple_threshold,f.breath,f.shimmer,f.yaw]))
                self.assertTrue(.15<=f.ripple_threshold<=2.5)
                self.assertTrue(0<=f.blink<=1 and 0<=f.mouth<=1)
                events+=f.event_count;max_rate=max(max_rate,f.ripple_rate)
            results.append({'scenario':scenario+1,'seed':700+scenario,'samples':240,'dt_s':dt,
                            'total_events':events,'final_rate':round(f.ripple_rate,4),
                            'max_rate':round(max_rate,4),'final_q':f.ripple_q_code,'status':'pass'})
        (BASE/'results/50_scenario_stress.json').write_text(json.dumps({'classification':'simulated synthetic 50-case scenarios, NOT trained Kokoro, physical sensor or AI inference','results':results},indent=2)+'\n')
        self.assertEqual(len(results),50)
    def test_node_python_quaternary_parity(self):
        seq=[0,0,.3,.3,.3,0,0,0,-.6,-.6,-.6,0,0,0,.7,.7]
        py=QuadEncoder();expected=[py.step(x)['code'] for x in seq]
        js=(f"import{{QuadEncoder}}from {json.dumps((BASE/'sources/ripple_q_v0_7.mjs').as_uri())};"
            f"let q=new QuadEncoder();console.log(JSON.stringify({json.dumps(seq)}.map(x=>q.step({{drive:x}}).code)))")
        r=subprocess.run(['node','--input-type=module','-e',js],text=True,capture_output=True,timeout=5)
        self.assertEqual(r.returncode,0,r.stderr);self.assertEqual(json.loads(r.stdout),expected)

if __name__=='__main__':unittest.main()
