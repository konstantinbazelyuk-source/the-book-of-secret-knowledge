import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
async def run():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  pg=await browser.new_page(viewport={'width':1340,'height':860});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
  await pg.set_content((ROOT/'Kokoro_Lumina_Standalone_Offline.html').read_text(),wait_until='domcontentloaded')
  await pg.wait_for_timeout(1200)
  a=await pg.evaluate('window.__luminaDebug()')
  assert a['assetKeys']==['full'],a
  assert a['state']['simulated'] and a['fps']>=10,a
  size=await pg.locator('#canvas').evaluate('e=>e.toDataURL("image/png").length');assert size>5000,size
  assert not errs,errs
  (ROOT/'results/standalone_browser_smoke.json').write_text(json.dumps({'passed':True,'source':'recovered original poster','fps_short_test':a['fps'],'canvas_png_data_url_len':size,'browser_errors':errs,'network_dependency':False},indent=2)+'\n')
  print((ROOT/'results/standalone_browser_smoke.json').read_text())
  await browser.close()
if __name__=='__main__':asyncio.run(run())
