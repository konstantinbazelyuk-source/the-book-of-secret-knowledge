"""Standalone, opt-in user-curated memory; NEVER stores Oneiric symbolic residues as facts.
Database is separate from any original Kokoro database or Genesis origin store.
"""
import sqlite3,hashlib,json,time
from contextlib import closing
from pathlib import Path

class MemoryStore:
    def __init__(self,path):
        self.path=Path(path)
        self.path.parent.mkdir(parents=True,exist_ok=True)
        with closing(sqlite3.connect(self.path)) as db, db:
            db.execute('''CREATE TABLE IF NOT EXISTS entries
                 (id TEXT PRIMARY KEY, text TEXT NOT NULL, source TEXT NOT NULL,
                  classification TEXT NOT NULL, approved INTEGER NOT NULL,
                  created REAL NOT NULL, digest TEXT NOT NULL)''')
    def add(self,identity,text,source,classification,approved=False):
        if classification not in ('user-stated','sourced-claim','hypothesis','creative'):
            raise ValueError('invalid classification')
        if not isinstance(identity,str) or not identity or not isinstance(text,str) or not text or len(text)>4000:
            raise ValueError('id or text invalid')
        if not isinstance(source,str) or not source or len(source)>500:raise ValueError('source required')
        if approved is not True:raise PermissionError('Explicit approval is required to persist memory')
        sha=hashlib.sha256((identity+'\x00'+text+'\x00'+source+'\x00'+classification).encode()).hexdigest()
        with closing(sqlite3.connect(self.path)) as db, db:
            db.execute('INSERT INTO entries VALUES (?,?,?,?,?,?,?)',
                       (identity,text,source,classification,1,time.time(),sha))
        return sha
    def search(self,term,limit=8):
        if not isinstance(term,str) or len(term)>120:raise ValueError('Invalid query')
        if not 1<=limit<=30:raise ValueError('limit invalid')
        with closing(sqlite3.connect(self.path)) as db, db:
            entries=db.execute('SELECT id,text,source,classification,digest FROM entries ORDER BY created DESC LIMIT 500').fetchall()
        # Literal casefold search avoids unchecked full-text query syntax.
        return [dict(zip(('id','text','source','classification','sha256'),row)) for row in entries
                    if term.casefold() in row[1].casefold()][:limit]
    def forget(self,identity):
        # Cannot delete Genesis store; it is separate and not addressed by this API.
        with closing(sqlite3.connect(self.path)) as db, db:
            cur=db.execute('DELETE FROM entries WHERE id=?',(identity,))
            return cur.rowcount
