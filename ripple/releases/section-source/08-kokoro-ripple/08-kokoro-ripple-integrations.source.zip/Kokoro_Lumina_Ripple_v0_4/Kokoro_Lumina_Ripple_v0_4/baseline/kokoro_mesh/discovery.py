"""Read-only AST discovery of ORIGINAL on-disk Python APIs.
AST inspection never imports or runs original source, avoiding training or state mutation.
"""
import ast,hashlib
from pathlib import Path

def scan(root,max_files=200):
    root=Path(root).resolve()
    if not root.is_dir():raise ValueError('Original project root not found')
    count=0;found=[]
    for p in sorted(root.rglob('*.py')):
        # Do not chase symlink files/folders outside original root.
        if p.is_symlink() or root not in p.resolve().parents:continue
        if count>=max_files:break
        try:
            if p.stat().st_size>1_000_000:continue
            raw=p.read_bytes()
            tree=ast.parse(raw,filename=str(p))
            funcs=[];classes=[]
            for n in tree.body:
                if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and not n.name.startswith('_'):
                    funcs.append({'name':n.name,'args':[a.arg for a in n.args.args], 'async':isinstance(n,ast.AsyncFunctionDef)})
                elif isinstance(n,ast.ClassDef) and not n.name.startswith('_'):
                    classes.append({'name':n.name,'methods':[a.name for a in n.body if isinstance(a,(ast.FunctionDef,ast.AsyncFunctionDef)) and not a.name.startswith('_')]})
            found.append({'path':str(p.relative_to(root)),'sha256':hashlib.sha256(raw).hexdigest(),
                          'functions':funcs[:50],'classes':classes[:30],'status':'parsed-not-executed'})
            count+=1
        except (OSError,UnicodeError,SyntaxError) as exc:
            found.append({'path':str(p.relative_to(root)),'status':'unreadable-or-invalid','error':type(exc).__name__})
    return {'root':str(root),'files_scanned':count,'max_files':max_files,
            'invented_bindings':False,'files':found}
