"""Append-only metadata audit. Never stores raw prompt, generated answer or source text."""
import json,sqlite3,time
from contextlib import closing
from pathlib import Path
class AuditLog:
    def __init__(self,path):
        self.path=str(path);Path(self.path).parent.mkdir(parents=True,exist_ok=True)
        with closing(sqlite3.connect(self.path)) as db, db:
            db.execute('CREATE TABLE IF NOT EXISTS runs (run_id TEXT PRIMARY KEY, timestamp REAL, capsule_hash TEXT, result_json TEXT)')
    def append(self,run_id,capsule_hash,statuses):
        with closing(sqlite3.connect(self.path)) as db, db:
            db.execute('INSERT INTO runs VALUES (?,?,?,?)',(run_id,time.time(),capsule_hash,json.dumps(statuses,sort_keys=True)))
    def history(self):
        with closing(sqlite3.connect(self.path)) as db, db:
            return db.execute('SELECT run_id,capsule_hash,result_json FROM runs ORDER BY timestamp DESC').fetchall()
