"""Explicit, allowlisted HTTPS evidence collector (OFF by default).
No crawling, no search-engine scraping, no private-network access or model instruction execution.
Network fetches have NOT been live-tested in this build. Test with permission and public sites.
"""
from __future__ import annotations
import asyncio,datetime,hashlib,http.client,ipaddress,json,socket,ssl
from html.parser import HTMLParser
from urllib.parse import urlsplit

class TextExtractor(HTMLParser):
    def __init__(self):super().__init__();self.skip=0;self.parts=[]
    def handle_starttag(self,tag,attrs):
        if tag in ('script','style','noscript'):self.skip+=1
    def handle_endtag(self,tag):
        if tag in ('script','style','noscript') and self.skip:self.skip-=1
    def handle_data(self,data):
        if not self.skip and data.strip():self.parts.append(data.strip())

def validate_url(url,hosts):
    if not isinstance(url,str) or len(url)>2000:raise ValueError('Invalid URL')
    parts=urlsplit(url)
    if parts.scheme!='https' or not parts.hostname or parts.username or parts.password or parts.port not in (None,443):
        raise ValueError('HTTPS public URL only; no userinfo or custom port')
    hostname=parts.hostname.lower().rstrip('.')
    if hostname not in hosts or any(c.isspace() for c in hostname):raise ValueError('Host not allowlisted')
    if hostname in ('localhost','localhost.localdomain'):raise ValueError('Local hosts forbidden')
    return hostname,parts

class PinnedHTTPS(http.client.HTTPSConnection):
    def __init__(self,host,ip,timeout):
        super().__init__(host,port=443,timeout=timeout,context=ssl.create_default_context())
        self.ip=ip
    def connect(self):
        sock=socket.create_connection((self.ip,443),timeout=self.timeout)
        self.sock=self._context.wrap_socket(sock,server_hostname=self.host)

def fetch_public_https(url,hosts,max_bytes=100000,timeout=5):
    host,p=validate_url(url,hosts)
    addresses=socket.getaddrinfo(host,443,type=socket.SOCK_STREAM)
    ips={a[4][0] for a in addresses}
    if not ips or not all(ipaddress.ip_address(ip).is_global for ip in ips):
        raise ValueError('DNS has non-public or missing addresses')
    conn=PinnedHTTPS(host,sorted(ips)[0],timeout)
    try:
        path=(p.path or '/')+('?' +p.query if p.query else '')
        conn.request('GET',path,headers={'User-Agent':'KokoroMeshResearch/0.3 (explicit user-directed request)',
                                         'Accept':'text/html,text/plain,application/json,application/xml'})
        resp=conn.getresponse()
        if resp.status!=200:raise RuntimeError('HTTP status '+str(resp.status)+'; redirects not followed')
        content_type=resp.getheader('Content-Type','').split(';')[0].strip().lower()
        if content_type not in ('text/html','text/plain','application/json','application/xml','text/xml'):
            raise ValueError('Non-text response disallowed')
        raw=resp.read(max_bytes+1)
        if len(raw)>max_bytes:raise ValueError('Source too large')
        decoded=raw.decode('utf8','replace')
        if content_type=='text/html':
            parser=TextExtractor();parser.feed(decoded);decoded=' '.join(parser.parts)
        return {'status':'fetched','url':url,'host':host,'source_sha256':hashlib.sha256(raw).hexdigest(),
                'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
                'content_type':content_type,'text_preview':decoded[:1200],
                'verified_claims':False,'untrusted_source_text':True,
                'note':'Content fetched but claims have not been corroborated or promoted into truth.'}
    finally:conn.close()

class SourceColony:
    def __init__(self,hosts,limit=3,fetcher=fetch_public_https):
        self.hosts=set(h.lower().rstrip('.') for h in hosts)
        if not self.hosts or not 1<=limit<=5:raise ValueError('Allowlisted host(s) and limit 1..5 required')
        self.limit=limit;self.fetcher=fetcher
    async def run(self,urls):
        if not isinstance(urls,list) or len(urls)>self.limit:raise ValueError('Too many URLs')
        # Validate every URL before any network activity.
        for url in urls:validate_url(url,self.hosts)
        sem=asyncio.Semaphore(2)
        async def get(url):
            async with sem:
                try:return await asyncio.wait_for(asyncio.to_thread(self.fetcher,url,self.hosts),timeout=8)
                except Exception as exc:return {'status':'failed','url':url,'error_type':type(exc).__name__}
        return {'classification':'untrusted-public-source-collection','results':await asyncio.gather(*(get(u) for u in urls))}
