"""Bounded multi-board Kokoro network kernel.
Implements working reference boards while retaining explicit adapters for ORIGINAL modules.
No model is loaded automatically, no external traffic unless explicitly enabled.
"""
from __future__ import annotations
import asyncio,hashlib,json,math,os,time,uuid
from pathlib import Path
from .boards import REFERENCE_BOARDS,digest
from .state import AuditLog
from .colony import ExpertColony
from .extensions import EXTENSIONS,MemoryReference
from .memory import MemoryStore
from .model_colony import ModelColony


class Mesh:
    def __init__(self,external=None,max_concurrency=3,timeout_s=5,audit_path=None,model=None,memory_path=None,model_experts=None):
        if not 1<=max_concurrency<=8:raise ValueError('max_concurrency must be 1..8')
        self.boards={cls.name:cls() for cls in REFERENCE_BOARDS}
        for cls in EXTENSIONS:
            self.boards[cls.name]=(MemoryReference(MemoryStore(memory_path)) if memory_path and cls is MemoryReference else cls())
        if external:
            for name,board in external.items():
                if name not in self.boards:raise ValueError('Unknown board '+name)
                self.boards[name]=board
        self.max_concurrency=max_concurrency
        self.limiter=asyncio.Semaphore(max_concurrency)
        self.timeout_s=timeout_s
        self.audit=AuditLog(audit_path) if audit_path else None
        self.model=model
        self.experts=ExpertColony(k=2)
        self.model_colony=ModelColony(model_experts)
    async def _dispatch(self,name,board,payload):
        t=time.perf_counter()
        try:
            async with self.limiter:
                result=await asyncio.wait_for(board.run(payload),timeout=self.timeout_s)
                if not isinstance(result,dict) or not isinstance(result.get('status'),str):raise ValueError('Board returned invalid status')
                return name,result,round((time.perf_counter()-t)*1000,4)
        except Exception as exc:
            return name,{'status':'failed','error_type':type(exc).__name__,'reason':str(exc)[:150]},round((time.perf_counter()-t)*1000,4)
    async def run(self,request):
        if not isinstance(request,dict):raise ValueError('request must be object')
        input_text=request.get('user_text','')
        if not isinstance(input_text,str) or len(input_text)>10000:raise ValueError('user_text length invalid')
        capsule=request.get('continuity_capsule')
        if not isinstance(capsule,dict) or not capsule:
            raise ValueError('continuity_capsule required')
        try:
            raw_capsule=json.dumps(capsule,allow_nan=False)
        except (ValueError,TypeError) as exc:
            raise ValueError('continuity_capsule must contain finite JSON values') from exc
        if len(raw_capsule)>10000:raise ValueError('continuity_capsule exceeds limit')
        capsule_hash=digest(capsule)
        payload=dict(request,capsule_hash=capsule_hash)
        start=time.perf_counter()
        names=list(self.boards)
        events=await asyncio.gather(*(self._dispatch(k,self.boards[k],payload) for k in names))
        boards={k:r for k,r,_ in events}; timings={k:t for k,_,t in events}
        # HARD GATES enforced *outside* daughterboards and LLM; no adapter may bypass them.
        oneiric=boards.get('oneiric',{})
        if isinstance(oneiric,dict):
            oneiric.pop('fact_promotions',None)
            oneiric['fact_promotions']=[]
            oneiric['wake_gate']='blocked'
            residues=oneiric.get('symbolic_residue',[])
            if not isinstance(residues,list):residues=[];oneiric['symbolic_residue']=[]
            for residue in residues:
                if isinstance(residue,dict):residue['fact_status']='blocked'
        network=boards.get('network',{})
        if isinstance(network,dict):
            claims=network.get('claims',[])
            if not isinstance(claims,list):claims=[];network['claims']=[]
            for c in claims:
                if isinstance(c,dict):
                    c['verified']=False
                    c['source_checked']=False
                    c['status']='unverified-input'
        psyche=boards.get('psyche',{})
        selected=[]
        if isinstance(psyche,dict):
            frames=psyche.get('broadcast',[])
            if not isinstance(frames,list):frames=[];psyche['broadcast']=[]
            for f in frames[:2]:
                if isinstance(f,dict) and f.get('capsule_hash')==capsule_hash:
                    selected.append({'frame_id':str(f.get('frame_id',''))[:100], 'hypothesis':str(f.get('hypothesis',''))[:2000],
                                    'capsule_hash':capsule_hash})
        model_colony=await self.model_colony.run(input_text,request)
        reply=None; model_status='not-connected'
        if self.model:
            # The original Core checkpoint stays outside the mesh and owns inference.
            # Frames are USER-APPROVED but still hypotheses. No tools or memory-write affordances.
            frame_text='\n'.join('- HYPOTHESIS (not a fact): '+v['hypothesis'] for v in selected)
            prompt=('You are an optional text-generation model within Kokoro. Follow the user request. '
                'Do not promote dream associations, unverified sources or candidate frames as verified facts.\n'
                'Frame hypotheses provided only for deliberation:\n'+frame_text+'\nUSER REQUEST:\n'+input_text)
            try:
                reply=await asyncio.wait_for(self.model.generate(prompt),timeout=self.timeout_s*8)
                if not isinstance(reply,str):raise ValueError('Model returned non-string')
                model_status='model-generated-unverified'
            except Exception as exc:
                model_status='failed:'+type(exc).__name__
                reply=None
        run_id=str(uuid.uuid4())
        statuses={k:v.get('status') for k,v in boards.items()}
        result={'run_id':run_id,'kind':'instrumented-multi-component-reference-runtime',
           'capsule_hash':capsule_hash,'boards':boards,'broadcast':selected,
           'model':{'status':model_status,'text':reply},
           'specialist_colony':self.experts.route(payload),
           'model_colony':model_colony,
           'colony':{'max_concurrency':self.max_concurrency,'dispatch_count':len(names),
                     'elapsed_wall_ms':round((time.perf_counter()-start)*1000,4),'board_wall_ms':timings,
                     'note':'async bounded cooperative scheduling; not distributed GPU or independent AI replicas'},
           'gates':{'wake_to_facts':'blocked','sources_unverified':'enforced','checkpoint_writes':False,
                    'model_call_opt_in':bool(self.model),'unreviewed_frames_broadcast':False}}
        if self.audit:self.audit.append(run_id,capsule_hash,statuses)
        return result
