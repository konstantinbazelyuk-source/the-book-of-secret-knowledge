"""Run: python -m kokoro_mesh doctor | demo | run -i request.json"""
import argparse,asyncio,hashlib,json,sys
from pathlib import Path
from .runtime import Mesh
from .boards import digest
from .adapters import ExternalBoard, LocalOllama


def demo_request():
    capsule={'identity':'Kokoro del AI','active_goal':'Test modular orchestration','revision':1}
    h=digest(capsule)
    return {'continuity_capsule':capsule,'user_text':'Explain current system status without inventing facts',
      'frames':[{'frame_id':'demo-1','capsule_hash':h,'approved':True,'confidence':0.7,'salience':0.8,
                 'hypothesis':'Check whether existing original module files are present before migration.'}],
      'heartspace':{'valence':0.5,'arousal':0.4,'tension':0.2,'significance':0.8,'stability':0.6},
      'claims':[{'id':'hyp-1','source':'simulation-fixture','topic':'scheduling','stance':'supports',
                 'text':'Fixture proposes controlled colony scheduling, not a verified study.'}],
      'idle':True,'memory_traces':[{'tag':'continuity','allow_symbolic_replay':True},
                                    {'tag':'resource allocation','allow_symbolic_replay':True}],
      'virtual_time_s':12.5,'training_sources':[{'id':'fixture-data','reviewed':False,'license':'unknown'}],
      'ripple_signals':{k:[0.35,0.4,0.1] for k in ['psyche','heartspace','network','oneiric']},
      'dt':0.05,'_classification':'synthetic demonstration inputs; NOT measured Kokoro telemetry'}


def doctor(project=None):
    files=[('Foundry','kokoro.py'),('Psyche','kokoro_core/psyche.py'),
           ('Heartspace','addons/Kokoro-Heartspace-Daughterboard'),
           ('Network','addons/Kokoro-Psyche-Network'),('Oneiric','addons/Kokoro-Oneiric-Resonance-System'),
           ('Adaptive Trainer','addons/Kokoro-CPU-Adaptive-Trainer'),
           ('Genesis Seed','addons/Kokoro-Genesis-Seed'),('Lumina','addons/Kokoro-Lumina'),
           ('Lawspace','addons/Kokoro-Lawspace'),('Oneiric Deep Dream','addons/Kokoro-Oneiric-Resonance-System'),
           ('Desktop Shell','addons/Kokoro-Desktop-Shell')]
    root=Path(project).resolve() if project else None
    found=[]
    for name,relative in files:
        path=root/relative if root else None
        if path and path.exists():
            found.append({'component':name,'status':'path-present-not-tested','path':str(path)})
        else:found.append({'component':name,'status':'unavailable','expected_relative_path':relative})
    ripple=Path(__file__).parent/'ripple_python.py'
    found.append({'component':'Ripple Python port','status':'file-present','sha256':hashlib.sha256(ripple.read_bytes()).hexdigest()})
    return {'project_root':str(root) if root else None,'checks':found,
            'note':'Presence alone does not establish daughterboard API compatibility or trained checkpoint availability.'}


def main():
    p=argparse.ArgumentParser(description='Kokoro Mesh read-only, bounded integration research')
    p.add_argument('mode',choices=('doctor','demo','run','scan','research'))
    p.add_argument('--project',help='Original Kokoro Foundry root (read-only inspection)')
    p.add_argument('-i','--input',help='JSON request file')
    p.add_argument('--audit',help='Optional SQLite metadata file outside original project')
    p.add_argument('--memory',help='Optional separately persisted user-approved memory store')
    p.add_argument('--adapter',action='append',default=[],help='Opt-in trusted adapter role=/absolute/path.py')
    p.add_argument('--ollama-model',help='Opt-in local Ollama model; NOT original Kokoro weights')
    p.add_argument('--expert',action='append',default=[],help='Opt-in local Ollama specialist role=modelname; max 4')
    p.add_argument('--url',action='append',default=[],help='Explicit public HTTPS URL for research')
    p.add_argument('--host',action='append',default=[],help='Exact allowlisted public research domain')
    p.add_argument('--confirm-research',action='store_true',help='Confirm external requests to supplied public URLs')
    p.add_argument('-o','--output',help='Save JSON result to new file')
    args=p.parse_args()
    if args.mode=='doctor':out=doctor(args.project)
    elif args.mode=='research':
        from .source_colony import SourceColony
        if not args.confirm_research:raise SystemExit('Research requires --confirm-research; no automatic network requests')
        out=asyncio.run(SourceColony(args.host).run(args.url))
    elif args.mode=='scan':
        from .discovery import scan
        if not args.project:raise SystemExit('scan requires --project')
        out=scan(args.project)
    else:
        x=demo_request() if args.mode=='demo' else json.loads(Path(args.input).read_text(encoding='utf8'))
        adapters={}
        for entry in args.adapter:
            name,sep,path=entry.partition('=')
            if not sep:raise SystemExit('Bad adapter. Expected role=/path/to/trusted_adapter.py')
            adapters[name]=ExternalBoard(name,path)
        expert_models={}
        for entry in args.expert:
            role,sep,modelname=entry.partition('=')
            if not sep:raise SystemExit('Expected role=modelname for expert')
            expert_models[role]=LocalOllama(modelname)
        runtime=Mesh(external=adapters,audit_path=args.audit,memory_path=args.memory,model_experts=expert_models,
                     model=LocalOllama(args.ollama_model) if args.ollama_model else None)
        out=asyncio.run(runtime.run(x))
    raw=json.dumps(out,indent=2,ensure_ascii=False,allow_nan=False)
    if args.output:
        dst=Path(args.output)
        if dst.exists():raise SystemExit('Output exists: refusing overwrite')
        dst.parent.mkdir(parents=True,exist_ok=True);dst.write_text(raw+'\n',encoding='utf8')
    print(raw)

if __name__=='__main__':main()
