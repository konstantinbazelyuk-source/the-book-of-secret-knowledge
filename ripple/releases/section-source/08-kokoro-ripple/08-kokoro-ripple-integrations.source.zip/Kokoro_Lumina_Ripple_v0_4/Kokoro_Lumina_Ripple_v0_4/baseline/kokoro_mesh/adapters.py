"""Opt-in external program bridges, with no implicit credentials or remote requests."""
from __future__ import annotations
import asyncio,json,os,sys
from pathlib import Path
from urllib import request, error

class ExternalBoard:
    def __init__(self,name,path,timeout_s=4):
        self.name=name;self.path=Path(path).resolve();self.timeout_s=timeout_s
        if not self.path.is_file() or self.path.suffix!='.py':raise ValueError('External board must be existing .py adapter')
    async def run(self,payload):
        # This executes user-supplied Python; only configure adapters you trust.
        proc=await asyncio.create_subprocess_exec(sys.executable, str(self.path),
              stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE,
              cwd=str(self.path.parent))
        try:
            stdout,stderr=await asyncio.wait_for(proc.communicate(json.dumps(payload).encode()),self.timeout_s)
        except asyncio.TimeoutError:
            proc.kill();await proc.communicate();raise TimeoutError(f'{self.name} adapter timed out')
        if proc.returncode!=0:raise RuntimeError(f'{self.name} adapter failed (exit {proc.returncode})')
        if len(stdout)>262144:raise ValueError('Adapter output exceeds size limit')
        result=json.loads(stdout)
        if not isinstance(result,dict) or not isinstance(result.get('status'),str):raise ValueError('Bad adapter output')
        return result


class LocalOllama:
    """Explicit local-only optional text generation; not a Kokoro checkpoint."""
    def __init__(self,model,timeout_s=30):
        if not isinstance(model,str) or not model or len(model)>100:raise ValueError('model name required')
        self.model=model;self.timeout=timeout_s
    async def generate(self,prompt):
        def sync_call():
            data=json.dumps({'model':self.model,'prompt':prompt,'stream':False}).encode()
            req=request.Request('http://127.0.0.1:11434/api/generate',data=data,
                                headers={'Content-Type':'application/json'})
            # urllib may honor HTTPS proxies; loopback is explicitly fixed, no arbitrary URL accepted.
            opener=request.build_opener(request.ProxyHandler({}))
            with opener.open(req,timeout=self.timeout) as resp:
                d=json.loads(resp.read(2_000_000))
            return str(d.get('response',''))
        return await asyncio.to_thread(sync_call)
