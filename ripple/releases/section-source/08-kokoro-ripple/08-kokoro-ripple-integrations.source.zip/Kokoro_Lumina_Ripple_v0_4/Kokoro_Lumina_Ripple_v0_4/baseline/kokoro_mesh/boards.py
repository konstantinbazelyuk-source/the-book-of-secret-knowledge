"""Reference software adapters, not original Kokoro daughterboard implementations.
No board is allowed to promote interpretations, candidate frames or dreams into facts.
"""
from __future__ import annotations
import hashlib
import json
import math
from pathlib import Path
from .ripple_python import RippleNeuron


def digest(x):
    return hashlib.sha256(json.dumps(x, sort_keys=True, separators=(',',':'), ensure_ascii=False).encode()).hexdigest()


def unit(x, name):
    if isinstance(x,bool) or not isinstance(x,(int,float)) or not math.isfinite(x) or not 0 <= x <= 1:
        raise ValueError(f'{name}: require finite number in [0,1]')
    return float(x)


class PsycheReference:
    name='psyche'
    async def run(self, payload):
        raw = payload.get('frames', [])
        if not isinstance(raw,list) or len(raw)>128: raise ValueError('frames must be list up to 128')
        h=payload['capsule_hash']; approved=[]; rejected=0
        for frame in raw:
            if not isinstance(frame,dict) or frame.get('capsule_hash')!=h or frame.get('approved') is not True:
                rejected+=1; continue
            conf=unit(frame.get('confidence',0),'confidence')
            sal=unit(frame.get('salience',0),'salience')
            hyp=frame.get('hypothesis')
            if not isinstance(hyp,str) or not hyp.strip() or len(hyp)>2000: rejected+=1;continue
            approved.append({'frame_id':str(frame.get('frame_id',''))[:100],
                'parent_id':str(frame.get('parent_id',''))[:100] if frame.get('parent_id') is not None else None,
                'hypothesis':hyp,'confidence':conf,'salience':sal,'capsule_hash':h})
        approved.sort(key=lambda f:(f['salience'],f['confidence']),reverse=True)
        return {'status':'available' if raw else 'unavailable', 'broadcast':approved[:2],
                'alternatives':len(approved[2:]),'rejected_frames':rejected,
                'note':'Frame approval and scores supplied by caller; not verified intelligence.'}


class HeartspaceReference:
    name='heartspace'
    async def run(self, payload):
        x=payload.get('heartspace')
        if x is None:return {'status':'unavailable','reason':'No actual Heartspace telemetry'}
        if not isinstance(x,dict):raise ValueError('heartspace must be object')
        fields=['valence','arousal','tension','significance','stability']
        if any(field not in x for field in fields):return {'status':'unavailable','missing':[k for k in fields if k not in x]}
        values={k:unit(x[k],k) for k in fields}
        expression_budget=round(min(1,max(0,1-0.6*values['tension']-0.25*values['arousal']+0.15*values['stability'])),4)
        return {'status':'available','source':'reported-numeric-state','values':values,
                'expression_budget':expression_budget,'note':'Numeric regulation heuristic; not a feeling or emotion measurement.'}


class NetworkReference:
    name='network'
    async def run(self,payload):
        raw=payload.get('claims')
        if raw is None:return {'status':'unavailable','reason':'No externally sourced claims were supplied'}
        if not isinstance(raw,list) or len(raw)>100:raise ValueError('claims must be list up to 100')
        seen={}; results=[]; conflicts=set()
        for i,c in enumerate(raw):
            if not isinstance(c,dict):raise ValueError(f'claim #{i} invalid')
            claim_id=str(c.get('id',''))[:100]; source=str(c.get('source',''))[:500]
            topic=str(c.get('topic',''))[:120]; stance=c.get('stance')
            statement=c.get('text')
            if not claim_id or not source or not topic or stance not in ('supports','opposes','unknown') or not isinstance(statement,str) or len(statement)>2000:
                raise ValueError(f'claim #{i} needs id, source, topic, text, stance')
            pair=(topic,stance)
            seen.setdefault(topic,set()).add(stance)
            results.append({'id':claim_id,'source':source,'topic':topic,'stance':stance,
                  'text':statement,'source_checked':False,'verified':False,'status':'unverified-input'})
        for topic,stances in seen.items():
            if 'supports' in stances and 'opposes' in stances:conflicts.add(topic)
        return {'status':'available','claims':results,'conflict_topics':sorted(conflicts),
                'source_count':len(set(c['source'] for c in results)),
                'note':'Source strings and stances are caller-supplied; NO URLs or evidence have been verified.'}


class OneiricReference:
    name='oneiric'
    async def run(self,payload):
        if not payload.get('idle',False):return {'status':'inactive','reason':'Only runs with explicit idle=True'}
        memories=payload.get('memory_traces',[])
        if not isinstance(memories,list) or len(memories)>100:raise ValueError('memory_traces must be list up to 100')
        # Symbolic pairing only, no hallucinated claims, nothing promoted into factual memory.
        available=[m for m in memories if isinstance(m,dict) and m.get('allow_symbolic_replay') is True and isinstance(m.get('tag'),str) and m['tag']]
        residues=[{'tags':[available[i]['tag'][:80],available[i+1]['tag'][:80]],
                   'classification':'symbolic-association','fact_status':'blocked'}
                  for i in range(0,max(0,len(available)-1),2)][:4]
        return {'status':'available','symbolic_residue':residues,'fact_promotions':[],
                'wake_gate':'blocked','note':'No original Oneiric simulation or semantic memory consolidation is claimed.'}


class GenesisReference:
    name='genesis'
    async def run(self,payload):
        sources=payload.get('training_sources')
        if sources is None:return {'status':'unavailable','reason':'No training manifests supplied'}
        if not isinstance(sources,list) or len(sources)>100:raise ValueError('training_sources invalid')
        statuses=[]
        for src in sources:
            if not isinstance(src,dict):raise ValueError('Training manifest entry not object')
            statuses.append({'id':str(src.get('id',''))[:100],
              'reviewed':src.get('reviewed') is True,'license':str(src.get('license','unspecified'))[:100],
              'training_approved':bool(src.get('reviewed') is True and src.get('license_ok') is True)})
        return {'status':'available','sources':statuses,'trained':False,'checkpoint_written':False}


class PocketTimeReference:
    name='pocket_time'
    async def run(self,payload):
        coordinate=payload.get('virtual_time_s')
        if coordinate is None:return {'status':'unavailable','reason':'No virtual time supplied'}
        if isinstance(coordinate,bool) or not isinstance(coordinate,(float,int)) or not math.isfinite(coordinate) or coordinate<0:
            raise ValueError('virtual time invalid')
        return {'status':'available','virtual_time_s':float(coordinate),
                'physical_speedup_claim':False,'note':'Coordinate only, not accelerated physical computation.'}


class RippleReference:
    name='ripple'
    def __init__(self):
        self.neurons={k:RippleNeuron() for k in ('psyche','heartspace','network','oneiric')}
    async def run(self,payload):
        sig=payload.get('ripple_signals')
        if sig is None:return {'status':'unavailable','reason':'No calibrated software input signals'}
        if not isinstance(sig,dict):raise ValueError('ripple_signals must be object')
        dt=payload.get('dt',0.05)
        if isinstance(dt,bool) or not isinstance(dt,(int,float)) or not math.isfinite(dt) or not 0<dt<=0.5:raise ValueError('dt invalid')
        required=set(self.neurons)
        if set(sig)!=required:return {'status':'unavailable','missing':sorted(required-set(sig)),'extra':sorted(set(sig)-required)}
        validated={}
        for k,channels in sig.items():
            if not isinstance(channels,(list,tuple)) or len(channels)!=3:raise ValueError(k+' three channels required')
            validated[k]=[unit(v,k) for v in channels]
        state={k:self.neurons[k].step(validated[k],dt) for k in self.neurons}
        return {'status':'available','source':'explicit-software-signals','channels':state,
                'note':'Original Ripple math; events are computational, not light or biological measurements.'}


REFERENCE_BOARDS=[PsycheReference,HeartspaceReference,NetworkReference,OneiricReference,GenesisReference,PocketTimeReference,RippleReference]
