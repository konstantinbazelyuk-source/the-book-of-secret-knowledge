# Kokoro Mesh + Ripple 0.3 — Reference Integration Harness

**Purpose.** Kokoro is modeled as cooperating modules, not merely a single LLM. This is a **new, executable, bounded mesh harness** with read-only compatibility ports for the **original Kokoro programs**. No original trained checkpoint, language-model training, Oneiric dream engine, 30D Heartspace engine, proprietary model, or original add-on source is bundled. A reference port is **not** evidence that the original program ran.

## What works

- 14 callable specialist/reference boards or ports: Psyche, Heartspace, Psyche Network, Oneiric, Genesis Seed/training registry, Pocket Time, Ripple, persistent Memory, Lumina, Fourth Wall, Lawspace, Heartspace-B, Overdrive Governor, Prospective Resonance (unavailable/future).
- Strict phase-ordered integration: input validation -> bounded async board execution -> mandatory frame/source/Wake Gates -> optional model calls -> audit status.
- Original Ripple leaky integrate-and-fire **Python port copied unchanged** from v0.2, and unchanged original JavaScript source archived under `sources/`.
- Real **concurrent** `asyncio` coordination of I/O-bound components (not distributed execution). Configurable worker bound 1–8. Errors and timeouts are isolated.
- Sparse deterministic top-2 metadata specialist routing with balancing; mathematically **inspired by** mixture-of-experts, not a trainable MoE layer.
- **Actual multi-model interfaces:** separate optional language providers for `analysis`, `evidence`, `creative`, `planning`, max two per request. Provider text is an **unverified candidate**, never an accepted fact. Optional localhost Ollama model or trusted external Python board adapters.
- Memory: optional, user-approved local SQLite records; source attribution, allowed classifications, search, item forget. **Separate** from and unable to overwrite the original protected Genesis origin.
- Static `scan` of installed Kokoro Python signatures and source hashes without importing or running those programs.
- Offline first. No credentials or APIs are used by default, and original project folders remain unchanged.

## Try it on Windows

Extract ZIP, then double-click `START_WINDOWS.bat`. Python 3.10+ is required; no `pip` packages are required for reference logic. Open a terminal in the extracted root:

```bat
python -m unittest discover -s tests -v
python -m kokoro_mesh demo
python -m kokoro_mesh run -i examples/minimal_request.json
python -m kokoro_mesh doctor --project "C:\Kokoro-del-Corazon-Foundry"
python -m kokoro_mesh scan --project "C:\Kokoro-del-Corazon-Foundry" -o original_api_inventory.json
```

**Scan is read-only.** Do not run installers, trainers or demo inference on a machine already performing uninterrupted pretraining.

## Original programs (honest integration contract)

To connect an original Psyche board, inspect actual signatures with `scan`, then create a **trusted adapter** that accepts JSON via stdin and prints `{"status":"available", ...}` via stdout. Run the adapter separately so core Kokoro programs are not imported into the mesh process:

```bat
python -m kokoro_mesh demo --adapter psyche=C:\path\to\trusted_psyche_adapter.py
```

The included `examples/trusted_test_board.py` demonstrates the protocol only and performs no AI inference. The original implementation's function signature has NOT been assumed. Only run adapter scripts you personally trust: subprocesses are not operating-system sandboxes, and may have the user's file permissions.

## Multiple AI models (explicit opt-in)

If Ollama and licensed models are **already installed locally** (not included), users can activate one central generator and/or two independent specialist models:

```bat
python -m kokoro_mesh run -i examples/multi_model_request.json --expert analysis=MODEL_A --expert evidence=MODEL_B --ollama-model=MODEL_C
```

The example explicitly requests `model_tasks`. Without provider flags, `model.status=not-connected`. A local Ollama model is NOT the user's trained Kokoro checkpoint. No cloud calls, paid API, remote sharing, automatic research, or training are performed. Running multiple models can exceed local RAM and CPU.

## What is not implemented or measured

- Original Kokoro checkpoints and original daughterboard binary packages are not in this delivered archive, therefore they have **not** been executed, patched, trained or merged. Adapter ports are a staging infrastructure for them.
- Reference Heartspace uses **five reported numeric coordinates**, rather than rebuilding the historical **30D, six-layer nonlinear** daughterboard. Reference Lumina emits scene command data, NOT holographic rendering. Oneiric generates bounded symbolic tag pairs, NOT autonomous dreaming. Prospective Resonance is explicitly unavailable. Genesis Seed never recreates or rewrites the original protected origin record.
- Neither consciousness nor feelings, neural biological waves, superior reasoning, exact real-time performance, optical EM sensing, network-scale parallelism nor improved language quality has been demonstrated.
- Concurrency benchmark is measured **wall time on synthetic async wait adapters** (not LLM). Sparse top-2 routing operates on metadata only.

## Results and sources

- `results/test_output.txt`: latest deterministic tests.
- `results/async_colony_measured.json`: **measured** local Python wall times with artificial 12-ms waits.
- `results/demo_output.json`: **simulated/synthetic** full-board input with explicit classification.
- `results/cloud_smoke.json`: Python 3.11 Floot VM contract smoke test (3 checks); not the full archive.
- `docs/ARCHITECTURE_AND_RESEARCH.md`: source citations, boundary matrix, integration roadmap.
- `docs/COMPARISON_AND_LIMITS.md`: measured-versus-proposed outcomes, original program preservation.

## Operational safety

No automatic network calls or file writes to installed originals. Explicit `--audit` writes metadata only in a separate SQLite database. Explicit `--memory` stores curated user-approved records only. `--expert`/`--ollama-model` permit model calls **only to 127.0.0.1** and require the user's local service. `--adapter` runs an explicitly supplied Python script as the current user: this is the only optional general-code-execution boundary. Source snippets, dream residues and model candidates never gain tool permissions or fact status. No copyright-restricted model weights are packaged.

## Optional user-directed public research colony

Kokoro can inspect up to three explicitly named public HTTPS pages using `kokoro_mesh.source_colony` with strict exact-host allowlists, TLS, pinned public IPs, no redirects, response-size limits, and an explicit CLI confirmation. Returned content is **untrusted** and its claims remain unverified. It does not run any model, automatically crawl the web, use proprietary APIs, or merge retrieved material into memory. This HTTPS client has **only passed mocked/offline unit tests** here; public live fetching is not yet verified on the user's machine. Example:

```bat
python -m kokoro_mesh research --confirm-research --host docs.python.org --url https://docs.python.org/3/library/asyncio.html
```

Respect website terms, usage rights and `robots.txt`. Do not use private URLs or sensitive documents. The `research` command does nothing without explicit URL, allowlist and confirmation.

A separate connected cloud-VM research smoke test successfully downloaded/hashes two public documents: `results/cloud_live_sources.json`. This is **not** a live test of the included Python HTTPS source collector. No automatic public publishing was performed.
