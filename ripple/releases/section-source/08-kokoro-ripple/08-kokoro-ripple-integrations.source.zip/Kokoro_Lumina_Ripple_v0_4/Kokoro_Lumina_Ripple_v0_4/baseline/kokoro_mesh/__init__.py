"""Kokoro Mesh: network-style reference runtime. No pretrained models bundled."""
__version__ = '0.3.0'
