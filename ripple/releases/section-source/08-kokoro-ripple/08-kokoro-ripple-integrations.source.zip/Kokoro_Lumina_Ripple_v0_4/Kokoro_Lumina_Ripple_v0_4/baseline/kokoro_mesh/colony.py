"""Sparse routing of *deterministic software tasks*, inspired by published MoE top-k routing.
Not a language-model MoE; no claim of pretrained experts or general intelligence.
Mandatory truth, provenance and consent gates do NOT depend on expert selection.
"""
import math

FEATURES={
 'signal_statistics': ('ripple_signals',),
 'evidence_inventory': ('claims',),
 'continuity_check': ('frames',),
 'replay_tags': ('memory_traces',),
 'training_inventory': ('training_sources',),
}

class ExpertColony:
    def __init__(self,k=2):
        if not 1<=k<=len(FEATURES):raise ValueError('invalid k')
        self.k=k;self.loads={name:0 for name in FEATURES};self.calls=0
    def route(self,request):
        ranked=[]
        for name,keys in FEATURES.items():
            relevant=any(request.get(key) is not None for key in keys)
            # Treat nonzero relevant input as priority, use fair tie-breaking by prior load.
            priority=1 if relevant else 0
            ranked.append((-priority,self.loads[name],name))
        names=[name for _,_,name in sorted(ranked)[:self.k]]
        reports=[]
        for name in names:
            self.loads[name]+=1
            reports.append({'expert':name,'result':self._process(name,request)})
        self.calls+=1
        return {'route_policy':'top-k-deterministic-heuristic','k':self.k,'selected':reports,
            'load_counts':dict(self.loads),'not_executed':sorted(set(FEATURES)-set(names))}
    def _process(self,name,req):
        if name=='signal_statistics':
            values=[]
            for signal in (req.get('ripple_signals') or {}).values():
                if isinstance(signal,(list,tuple)):
                    for v in signal:
                        if isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v):values.append(float(v))
            if not values:return {'status':'unavailable'}
            m=sum(values)/len(values)
            return {'status':'available','samples':len(values),'mean':m,'variance_population':sum((v-m)**2 for v in values)/len(values)}
        if name=='evidence_inventory':
            claims=req.get('claims')
            return {'status':'available' if isinstance(claims,list) else 'unavailable','count':len(claims) if isinstance(claims,list) else 0}
        if name=='continuity_check':
            f=req.get('frames')
            return {'status':'available' if isinstance(f,list) else 'unavailable','count':len(f) if isinstance(f,list) else 0}
        if name=='replay_tags':
            memories=req.get('memory_traces')
            return {'status':'available' if memories is not None else 'unavailable','replay_eligible_count':sum(1 for x in (memories if isinstance(memories,list) else []) if isinstance(x,dict) and x.get('allow_symbolic_replay') is True)}
        if name=='training_inventory':
            src=req.get('training_sources')
            return {'status':'available' if isinstance(src,list) else 'unavailable','count':len(src) if isinstance(src,list) else 0}
        raise ValueError(name)
