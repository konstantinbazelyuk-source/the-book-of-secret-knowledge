# Kokoro Lumina + Ripple 0.4 — executable avatar/embodiment add-on

**October 13, 2026 · Private author-owned working artifact · NOT a new model checkpoint.**

Kokoro's **Lumina** is an embodiment subsystem alongside the original Kokoro Core, Psyche, Heartspace, Network, Oneiric, Genesis, Pocket Time and Ripple. Unlike the v0.3 reference that returned only scene-command JSON, v0.4 **actually draws pixels** on a continuously updating browser canvas, writes PNGs/GIFs offscreen with Pillow, and streams typed frame packets from a local Python process. It preserves the original v0.3 files and accepts optional real board data via explicit JSON protocols.

## Start here

**Windows browser-only (Python 3.10+):** extract the ZIP and double-click `START_WINDOWS.bat`. It starts a localhost-only Python server and opens `http://127.0.0.1:8765/`. Close the terminal to stop it. No model API key, cloud account or GPU is needed. Directly opening `web/index.html` also runs an **offline demo**, without Python or network; control packets are synthetic in that mode.

**Terminal:**

```bash
python -m kokoro_lumina server --port 8765 --open
python -m kokoro_lumina frame
python examples/mesh_with_lumina.py
```

**Optional continuous headless PNG (needs Pillow):**

```bash
python -m pip install -r requirements-headless.txt
python -m kokoro_lumina continuous --out results/live --duration 20 --fps 12
# duration 0 = continuously until Ctrl+C; capped at 24 FPS, atomically updating latest.png
python -m kokoro_lumina export --out results/lumina.gif --frames 90 --fps 24
python -m kokoro_lumina export --reference assets/Adelita_Kokoro_reference.png --out results/reference.gif --frames 48 --fps 24
```

`results/live/latest.png` contains **actual new rasterized image bytes**, continually replaced while the headless process is running; `latest_state.json` reports what drove the frame. A process stops when the user exits. No cloud permanence or 24/7 background service is claimed.

## Recovered Kokoro artwork and continuity

The exact bytes of the user's Library asset **Adelita Kokoro: Synthetic Heart Android.png** are retained as `assets/Adelita_Kokoro_reference.png`. It is a reference poster, not automatically decomposed into a facial/body rig. The displayed poster can shift a few pixels beneath **hologram overlay** effects, but its source artwork is not regenerated, reauthored or overwritten. The demo's fallback generated silhouette is explicitly *noncanonical*.

Supported optional import slots: complete original art, head, eyes, mouth, heart, beam gun, sword, heels and compact feet. Weapon/foot modes are explicit controls, not spontaneous autonomous transformation of original art. Real expressive facial animation requires layered art or a verified VRM/Live2D rig. A separate `vrm.html` optional 3D bridge using three.js and `@pixiv/three-vrm` is coded, but **not runtime-verified here with a real character VRM**; it requires Internet for third-party modules and a user-owned rig. The offline 2D renderer remains the working default.

## How it works

1. A constrained `lumina.control.v1` packet or explicitly marked demo supplies three *normalized software channels* (`ripple_rgb`), pose/expression labels, gaze/speech amplitude, heart-power and scene epoch.
2. The preserved **Ripple v0.1** leaky integrate-and-fire model computes bounded pulse timing and a feedback threshold; no artificial intelligence, brain, physics, light or actual emotion is inferred from the channels.
3. A faithful **Ripple-Q v0.7** four-symbol encoder classifies software drive changes as `-1, -0, 0, +1`, with dedicated codes, a noise floor and two-sample confirmation. The original v0.7 module is archived byte-for-byte.
4. Lumina's time-based smoothing/decay and periodic blink/breath generate **visual control values**, explicitly simulated unless reported by a genuine external component.
5. The browser Canvas2D draws real frames with a conservative capped particle/scanline field, optional author-owned art overlays, and PNG/WebM export. Hidden tabs pause animation. A Python renderer can independently write new PNG/GIF files. The engine runs without external model weights.
6. A **Mesh v0.3 drop-in adapter** (`LuminaRenderBoard`) is available to replace the old Lumina scene-command reference in `Mesh(external={'lumina': LuminaRenderBoard()})`. Mesh source and checkpoints remain untouched; a frame packet by itself does NOT claim pixel rendering.

## Real tests, simulations and boundaries

- **25 Python automated tests PASS** (engine, invalid data, original hashes, Python/JavaScript Ripple-Q parity, Mesh v0.3 port, actual raster export,  localhost HTTP/SSE, CSRF/origin checks).
- **50 synthetic numeric scenarios, 240 steps each (12,000 updates), PASS**. Logged in `results/50_scenario_stress.json`. These are synthetic control patterns, not cognitive/LLM tests.
- **50 local render-profiling runs, 8 frames each (400 encoded images), PASS**. Measured local Pillow CPU processing, not GPU frame rate. See `results/render_50_profile_measurements.json`.
- **Browser Chromium tests PASS** at desktop 1365×850 and mobile 390×844, including continuously changing canvas pixels, import of the actual owned image, pause/resume and 2D control changes. Due to sandbox blocked loopback navigation, browser assets were injected as local inline code. **Python HTTP/SSE was independently tested**, not proven as a browser-to-server end-to-end connection inside sandbox.
- **Local headless streaming** ran for 1.75 s, wrote 21 PNGs (~12.0 images/sec), median render+encode 8.29 ms; no benchmark on the user's hardware.
- **Cloud:** independent 16-step quaternary reference test passed in an isolated Floot VM. The full archive and 3D VRM path were NOT deployed or executed in cloud.
- The Windows machine where original Kokoro was trained, her actual daughterboard implementations, optional camera/robotics and her trained checkpoint were NOT accessed. Her reasoning, performance, subjective experience and learned intelligence are NOT evaluated by these graphics results.

## Security and privacy

Everything is localhost-only or entirely offline. Uploaded images are browser-local object URLs in the offline 2D viewer. The optional 3D page fetches third-party JavaScript modules over the Internet; treat those remote dependencies as code you must separately trust before opening private VRM assets. The HTTP server binds to `127.0.0.1` only, accepts a strict JSON schema, enforces a per-process token and Origin check for packet injection, rejects unexpected URLs, and has an explicit 5-second stale-control return to demo. It is a developmental server, not an Internet-exposed production authentication system. Review any third-party VRM artwork and its separate licensing before use.

## Upstream engineering research

See `docs/SOURCES_AND_NEXT_STEPS.md` for dated primary-source links and precise distinctions between actually implemented vs optional untested features. No third-party character/model weights or proprietary software was copied into this project. The original Ripple program modules used here originated within the user's project and have not been modified.
