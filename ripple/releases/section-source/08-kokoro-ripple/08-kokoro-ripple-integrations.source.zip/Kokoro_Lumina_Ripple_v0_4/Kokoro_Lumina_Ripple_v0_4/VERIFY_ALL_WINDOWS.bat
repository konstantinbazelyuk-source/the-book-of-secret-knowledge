@echo off
cd /d "%~dp0"
echo Full tests need Python 3.10+, Node.js, and Pillow.
python -m unittest discover -s tests -v
pause
