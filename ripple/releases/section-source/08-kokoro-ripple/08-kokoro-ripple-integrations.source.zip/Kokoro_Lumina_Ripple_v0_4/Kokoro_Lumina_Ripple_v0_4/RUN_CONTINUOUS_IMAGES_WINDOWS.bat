@echo off
cd /d "%~dp0"
python -m kokoro_lumina continuous --out results\live --duration 0 --fps 12
pause
