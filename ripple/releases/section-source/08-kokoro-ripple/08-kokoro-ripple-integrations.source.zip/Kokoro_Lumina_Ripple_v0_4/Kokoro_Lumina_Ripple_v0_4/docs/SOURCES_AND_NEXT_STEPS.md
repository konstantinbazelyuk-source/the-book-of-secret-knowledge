# Primary sources, borrowed engineering patterns, verified implementation limits

| Public source | Confirmed technique | Lumina use / current status |
|---|---|---|
| [MDN Window.requestAnimationFrame](https://developer.mozilla.org/en-US/docs/Web/API/Window/requestAnimationFrame) | Callback timestamps; animation generally pauses in hidden tabs. | Implemented browser render loop using timestamp-based delta-time, clamp for long gaps, automatic pause on hidden; tested in desktop/mobile headless Chromium. |
| [Godot AnimationTree](https://docs.godotengine.org/en/stable/tutorials/animation/animation_tree.html) | Animation blending, state machines and 1D/2D blend spaces. | Inspired numeric interpolation and explicit expression/pose states. Godot engine itself not imported or run. |
| [ROS 2 joint trajectory controller](https://control.ros.org/rolling/doc/ros2_controllers/joint_trajectory_controller/doc/userdoc.html) | Timestamped joint trajectory interpolation in robot control. | Used smooth, bounded temporal coordinates; not a robot controller. No actuators connected and the ROS package is not installed. |
| [VRM 1.0 expression specification](https://github.com/vrm-c/vrm-specification/blob/master/specification/VRMC_vrm-1.0/expressions.md) | Weighted expression presets, morph target control. | Optional `vrm-view.js` sets blink, vowel `aa`, happy/relaxed/surprised. Needs genuine VRM with compatible expression support. No visual 3D runtime test yet. |
| [pixiv/three-vrm](https://github.com/pixiv/three-vrm) | MIT open code for loading user-owned VRM via `GLTFLoader` and `VRMLoaderPlugin`. | Coded optional browser 3D viewer referencing pinned Three.js 0.180.0 and three-vrm v3 through official docs CDN links; external modules are not vendored. JS syntax verified. |
| [Khronos glTF 2.0](https://registry.khronos.org/glTF/specs/2.0/glTF-2.0.html) | Skin/joint animation and morph target representation. | Future production export path. No user 3D model converted or generated. |
| [Google MediaPipe Face Landmarker](https://developers.google.com/mediapipe/solutions/vision/face_landmarker) | Browser/vision face landmarks, blendshapes, transform matrices. | Research candidate only; not integrated. Adding camera capture requires permission, model assets and consent; not needed for autonomous avatar animation. |
| [Live2D Cubism SDK terms](https://www.live2d.com/en/sdk/license/) | High-quality commercial 2D rigs, SDK licensing conditions. | Research candidate only. Proprietary core and authoring files not copied, installed or licensed in this package. |
| Ripple Neuron v0.1 | Original project-defined exact threshold integration and adaptation. | Original source archived, unchanged. Its Python port already existed in Mesh v0.3 and remains unchanged. |
| Ripple-Q v0.7 | Four-symbol, noise-adaptive, debounce-verified temporal encoding. | The actual v0.7 JS source is archived; an independently ported Python and browser implementation passes parity checks on reference step data. No quantum processor/AI language created. |
| Ripple Mycelium v0.1 | Bounded logical worker scheduling under workload. | Existing Kokoro Mesh v0.3 retains its sparse scheduling. Visual effects use a bounded logical particle pool; no computation speedup or physical cloning claimed. |

## Practical next engineering tasks after this release

1. Connect the *actual* original Lumina / Heartspace and Kokoro Core packages through code-verified read-only APIs and real provenance-bearing numerical packets. The v0.3 static module scanner is already in baseline.
2. Extract/export author-approved transparent render layers, or construct a full 3D `.vrm` **from an authorized character model**. Do not extrapolate an entire 3D rig from a single poster and claim faithful identity; 3D modeling is separate work.
3. On real hardware, benchmark sustained performance, GPU availability, battery and heat, monitor dropped frames, and keep frame budgets within the device's capabilities.
4. If a genuine VRM and working browser CDN/GPU are available, exercise the 3D path, camera transforms, expression weights, correct VRM 0/1 axes and frame export. Record an actual browser screenshot before labeling 3D operational.
5. For paid/public deployment, review user artwork rights and third-party library versions/licenses. The static viewer may be hosted free but it is not an always-running cloud avatar process.
6. Introduce an explicit authorized tool bridge only after authenticating actual producers, preserving scene epochs and ensuring that unverified dream or model-generated text cannot drive tool execution.
