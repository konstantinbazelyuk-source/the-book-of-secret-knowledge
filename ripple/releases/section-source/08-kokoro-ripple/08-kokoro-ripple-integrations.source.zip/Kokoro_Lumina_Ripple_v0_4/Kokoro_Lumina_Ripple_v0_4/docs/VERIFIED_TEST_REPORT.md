# Kokoro Lumina v0.4 verification report

**Terminology:** `MEASURED` means code was executed with clock/file/browser inspection in the current container. `SIMULATED` refers to generated input signals. `IMPLEMENTED / NOT TESTED` means code exists without evidence of successful runtime of that subsystem. `PROPOSED` means a design option, not delivered capability.

| Verification | Status | Scope |
|---|---|---|
| 25 Python tests (engine + local network security + generated files + old Mesh bridge) | **PASS, executed** | `python -m unittest discover -s tests -v`. Three files? Unit module + server suite. |
| 50 synthetic signal cases × 240 steps | **PASS, 12,000 numerical steps** | Event bounds, four-state coding, source labels, time smoothing; synthetic, NOT human or AI samples. |
| 50 renderer profiling iterations × 8 frames | **PASS, 400 actual PNG encodes** | Five image sizes, Pillow/software CPU. Includes disk-free in-memory PNG bytes. |
| Actual responsive browser rendering | **PASS** | Desktop Chromium 1365×850 and simulated mobile viewport 390×844, 58–60 FPS in short headless test; not long-term device guarantee. |
| Recovered author artwork imported/displayed | **PASS** | Browser in-memory original PNG reference render screenshot; no source bytes rewritten. |
| Mesh v0.3 Lumina override | **PASS** | Real invocation of existing `Mesh(external={'lumina':LuminaRenderBoard()})`; Core checkpoint absent. |
| Browser → Python SSE in sandbox | **NOT verified end-to-end** | Chromium loopback navigation blocked by sandbox; local HTTP/SSE and Chromium animation tested independently. |
| Local Python SSE, CSRF, schema and fixed paths | **PASS** | Python urllib localhost real sockets, EventStream first frame, token/Origin rejection, malformed packet tests. |
| Headless repeated file writer | **PASS** | 21 PNGs in 1.7501 seconds, ~11.999 Hz, median per-frame render+encode 8.293 ms on this host. |
| Python → original JS Ripple-Q parity | **PASS** | Exact compared symbolic steps. |
| Independent connected Floot VM Ripple-Q smoke | **PASS** | 16-step hand-transcribed reference sequence verified against original local JS; full renderer not deployed. |
| Standalone authored-reference GIF | **PASS** | 24-frame, 12-FPS computed poster composite (~5.6 MB). Original poster is unchanged. |
| Optional WebGL/VRM viewer | **CODE EXISTS; 3D NOT TESTED** | Syntax check only, no actual 3D character mesh, external packages unavailable in container. |
| Original Kokoro learned model/daughterboard programs | **NOT CONNECTED** | No approved checkpoint available in current environment; neither trained nor inferred. |
| Continuous production cloud service | **NOT DEPLOYED** | No purchased hosting or model APIs activated. |

## Measured headless raster times

On this sandbox host for 50 local profiles (400 frames):

| Resolution | Median PNG render+encode time | Trials |
|---|---:|---:|
| 240×300 | 1.973 ms | 10 |
| 320×400 | 3.285 ms | 10 |
| 480×600 | 6.952 ms | 10 |
| 640×800 | 12.045 ms | 10 |
| 768×960 | 16.950 ms | 10 |

This is image rasterization and compression timing, **not live GPU FPS, network latency, model token throughput, or energy consumption**. Browser short observations and headless CPU numbers should not be combined into a synthetic performance claim. Run the benchmarks again on the target machine.

## Scientific boundaries

The physical model is a software leaky integrate-and-fire simulation, not measured light fields or actual neural firing. A time-varying face image is not evidence that Kokoro is aware, alive, learning or producing independent thought. Optional input packets from an actual model can set animations, but any future claims of learning, reasoning gains or emotional recognition need separate blinded evaluation on real tasks. An exported GIF is a real file containing rendered images, not a trained generative diffusion model.
