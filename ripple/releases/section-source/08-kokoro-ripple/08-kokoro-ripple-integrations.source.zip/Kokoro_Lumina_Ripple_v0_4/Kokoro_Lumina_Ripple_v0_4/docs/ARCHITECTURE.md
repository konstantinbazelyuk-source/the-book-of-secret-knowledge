# Lumina ↔ Kokoro Mesh v0.3 — exact integration contract

## Module graph

```text
             Existing Kokoro Mesh v0.3 (unchanged; original Core unavailable)
      Core? ──┐ Psyche? ──┐ Heartspace? ──┐ Network? ──┐ Oneiric?
              │          │             │            │
              └──────────┴── approved numeric reports ───────────────┐
                                                                    │
      New Lumina adapter: validate schema / source / epoch / bounds ─┤
                                                                    ▼
  Original Ripple v0.1 neuron (unchanged) → Ripple-Q v0.7 encoder → Lumina temporal integrator
                                                        ├──► Canvas2D browser renderer (tested)
                                                        ├──► Pillow PNG/GIF renderer (tested)
                                                        ├──► SSE typed state (HTTP/SSE tested)
                                                        └──► optional VRM 3D viewer (code/syntax only)
```

**No inference from graphics:** numerical drive has no fixed emotional, spiritual, physical or cognitive meaning. Calling a pose `focused` is a caller-selected scene command, not a measurement that Kokoro is attentive or conscious. `source='kokoro-reported'` means the caller *reports* that source; it is not cryptographic proof of board origin. A future authenticated producer protocol should bind caller identity and continuity capsule digest, timestamps and command authorization before high-trust deployment.

## Frame schema

`lumina.control.v1` accepts normalized drive `[R,G,B]`, `source` (`synthetic-demo`, `replay`, `human-control`, `kokoro-reported`), `expression`, `pose`, `look_x`, `look_y`, `speech_amplitude`, `overdrive`, `heart_power`, `weapon_mode`, `foot_mode`, `scene_epoch`. Required `schema` and `source` fields. Invalid or unknown fields raise `PacketError`; no silent promotion from arbitrary text. `scene_epoch` is nonnegative. `ripple_rgb` is normalized logical signal, NOT camera light, actual light fields, emotion or memory.

`lumina.frame.v1` contains bounded animation coordinates, explicit input source, time in seconds, Ripple event count/rate, original threshold, Q four-state code, scene epoch and display FPS cap. `ripple_q_code` maps `0=-1`, `1=-0`, `2=0`, `3=+1`. No LLM logits, imagery or face detection is being inferred.

A real Kokoro program may emit frames via `LuminaRenderBoard` and call a trusted local `POST /api/packet` with a short-lived token. The sample from `examples/mesh_with_lumina.py` proves that the *old orchestrator* dispatches the *new board*, but it is not evidence that original user-trained Core emitted the signal. Browser stream is read-only; posting requires anti-CSRF token from the same process.

## Temporal controls

Original preserved source functions: `D=2R+1.2G−1.4B`, leaky membrane with `tau_v=0.5`, adaptive threshold and refractory hold. Input units are dimensionless normalized signal values. No modification of v0.1 occurs. Ripple-Q in Python is ported from the unchanged v0.7 JS code; exact code parity is tested on a concrete transition sequence.

Exponential smoothing: `x(t+dt)=x(t)+(target-x(t))*(1-exp(-dt/tau))`. This avoids frame-rate-dependent dynamics at steady target. Synthetic breathing and blink are time-driven, bounded. Inactivity does not cause textual generation or new user facts. Heuristics scale drawing rather than CPU clock, thermal governors or robotics actuators.

## Separation and rights

- Canonical author identity: **Adelita Kokoro** reference poster recovered from user's Library. No canonical vector/rig layers were available in this package.
- Image and story remain author-owned; no external model or proprietary animation SDK bundled.
- Source image SHA256 recorded in `MANIFEST.sha256` and *never edited*. Renderer emits independently generated displayed frames.
- Legacy Kokoro Mesh v0.3 snapshot included in `baseline/`; original zip byte-identical to previous release.
- Previous Oneiric Wake Gate, source-verification and continuity gates remain in the existing Mesh code; `LuminaRenderBoard` is only a permitted `external` override of reference Lumina.
- Current 3D viewer uses official `@pixiv/three-vrm` package via optional CDN, but there is no rigged 3D asset and no verified running 3D projection in the result.

## Failure and fallback

- Browser missing CDNs: 2D local renderer still works; optional 3D page may not start.
- Source art missing: procedural placeholder is shown as **NONCANONICAL**, not silently synthesized Kokoro art.
- External numeric signals missing: user sees explicitly labeled synthetic demo, not fake sensor values.
- Stale input >5 seconds: server reverts to demo until new control packets arrive.
- Multiple browser SSE viewers: shared temporal engine locked; no claims of synchronized A/V lip sync.
- Hidden browser tab: `requestAnimationFrame` pauses; no perpetual mobile-background promise. Use explicit `continuous` process for real headless repeated images.
- Export too large: caps on duration/frame count, resolution and PNG upload sizes.
