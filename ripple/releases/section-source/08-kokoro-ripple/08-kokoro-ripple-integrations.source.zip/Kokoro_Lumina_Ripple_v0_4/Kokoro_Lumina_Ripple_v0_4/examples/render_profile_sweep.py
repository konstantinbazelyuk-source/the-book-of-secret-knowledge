"""50 measured local render profiles: different resolution, seed, and signal complexities.
No claim of trained-model intelligence, battery power, or external device performance.
"""
from pathlib import Path
from kokoro_lumina.engine import LuminaEngine
from kokoro_lumina.offscreen import render_frame
from dataclasses import asdict
from io import BytesIO
from statistics import median
import time,json,statistics,hashlib,csv,math
ROOT=Path(__file__).resolve().parents[1]
RES=[(240,300),(320,400),(480,600),(640,800),(768,960)]
results=[]
for ix in range(50):
    w,h=RES[ix%5];e=LuminaEngine(seed=2000+ix);durations=[];byte_sizes=[];hashes=[]
    for j in range(8):
        packet={'schema':'lumina.control.v1','source':'synthetic-demo','ripple_rgb':[.1+.1*(ix%5),.1+.05*(j%4),.04],
                'look_x':math.sin(j*.5),'speech_amplitude':(j%3)*.15,'heart_power':.2,'expression':'neutral'}
        frame=asdict(e.advance(.05,packet));start=time.perf_counter()
        image=render_frame(frame,(w,h));buffer=BytesIO();image.save(buffer,format='PNG')
        durations.append((time.perf_counter()-start)*1000);data=buffer.getvalue();byte_sizes.append(len(data));hashes.append(hashlib.sha256(data).hexdigest())
    results.append({'iteration':ix+1,'size':f'{w}x{h}','pixels':w*h,'seed':2000+ix,
                    'median_png_encode_ms':round(median(durations),4),
                    'mean_png_bytes':round(statistics.mean(byte_sizes)),
                    'unique_frames':len(set(hashes))})
assert len(results)==50 and all(r['unique_frames']==8 for r in results)
summary={}
for w,h in RES:
    arr=[r['median_png_encode_ms'] for r in results if r['pixels']==w*h]
    summary[f'{w}x{h}']={'observed_median_ms':round(median(arr),3),'trials':len(arr),'approx_budget_fps':round(1000/median(arr),1)}
result={'classification':'MEASURED CPU raster/PNG encoding for synthetic reference avatar; single local host; not display FPS/GPU measurements',
        'profile_count':50,'frames_encoded':400,'resolution_summary':summary,'iterations':results}
(ROOT/'results/render_50_profile_measurements.json').write_text(json.dumps(result,indent=2)+'\n')
with (ROOT/'results/render_50_profile_measurements.csv').open('w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=results[0].keys());writer.writeheader();writer.writerows(results)
print(json.dumps({'iterations':50,'rendered_frames':400,'resolution_summary':summary},indent=2))
