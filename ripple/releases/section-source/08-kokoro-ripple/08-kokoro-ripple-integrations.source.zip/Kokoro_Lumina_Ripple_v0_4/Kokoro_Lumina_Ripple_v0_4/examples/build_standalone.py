"""Build a single-file offline Kokoro Lumina demo containing original copied poster bytes.
Image, not the rig, is the author's identity. Standalone is DEMO ONLY (no Python server).
"""
from pathlib import Path
import base64
ROOT=Path(__file__).resolve().parents[1]
html=(ROOT/'web/index.html').read_text()
css=(ROOT/'web/style.css').read_text()
ripple=(ROOT/'baseline/ripple_core_v0_1.js').read_text()
quad=(ROOT/'web/quaternary-port.js').read_text()
lumina=(ROOT/'web/lumina.js').read_text()
image_b64=base64.b64encode((ROOT/'assets/Adelita_Kokoro_reference.png').read_bytes()).decode('ascii')
html=html.replace('../assets/Adelita_Kokoro_reference.png','data:image/png;base64,'+image_b64)
html=html.replace('<link rel="stylesheet" href="style.css">','<style>'+css+'</style>')
html=html.replace('<script src="../baseline/ripple_core_v0_1.js"></script>','<script>'+ripple+'</script>')
html=html.replace('<script src="quaternary-port.js"></script>','<script>'+quad+'</script>')
html=html.replace('<script src="lumina.js"></script>','<script>'+lumina+'</script>')
html=html.replace('<a href="/vrm.html" style="color:#86dbe1">3D VRM (experimental)</a>','<span>STANDALONE OFFLINE DEMO</span>')
html=html.replace('Checking local runtime…','Standalone offline · synthetic input')
out=ROOT/'Kokoro_Lumina_Standalone_Offline.html'
out.write_text(html)
print(out,'bytes=',out.stat().st_size)
