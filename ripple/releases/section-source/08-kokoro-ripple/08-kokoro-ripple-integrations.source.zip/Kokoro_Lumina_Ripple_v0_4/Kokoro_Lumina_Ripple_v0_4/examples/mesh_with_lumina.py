"""Runs original Mesh v0.3 unchanged with add-on renderer port; no external model needed."""
import asyncio,json
from baseline.kokoro_mesh.runtime import Mesh
from baseline.kokoro_mesh.boards import digest
from kokoro_lumina.bridge import LuminaRenderBoard
async def main():
 capsule={'identity':'Kokoro','role':'non-destructive reference test'}
 m=Mesh(external={'lumina':LuminaRenderBoard()},timeout_s=2)
 req={'continuity_capsule':capsule,'user_text':'Test Lumina frame adapter only',
      'lumina_control':{'schema':'lumina.control.v1','source':'synthetic-demo','ripple_rgb':[.4,.2,.1],
         'look_x':.2,'speech_amplitude':.3,'expression':'neutral','pose':'speaking'}}
 out=await m.run(req)
 assert out['boards']['lumina']['status']=='available'
 assert out['gates']['wake_to_facts']=='blocked'
 print(json.dumps({'lumina':out['boards']['lumina'],'gates':out['gates']},indent=2))
if __name__=='__main__':asyncio.run(main())
