# Measured, calculated, simulated and unavailable results

**Experimental classification:** real GPU-independent VTK triangle-mesh rendering and software pixel processing of **simulated digital joint states**. No camera hardware, physical robots, trained Kokoro language model, or independent perception of natural human movement. The three colored, intentionally attached 3D markers define the evaluation task.

## 50-case geometry test

`python tests/study_50.py` rendered **50 actual RGB images** at 320×420 pixels at four known camera yaw values, with seeded randomized right-arm, forearm and head joint poses. It recovered **50/50**. The pooled estimated-joint RMS error against known test inputs was **0.0139701 radians**; 95th percentile absolute joint error **0.0219218 radians**, maximum absolute error **0.0288785 radians**. Rendered image data—not private joint-state readings—were supplied to the estimator. The test generator retained its reference joint angles solely for evaluation.

## Closed-loop experiment and meaningful ablation

A *simulated* virtual actuator with a deliberately introduced joint-command calibration bias was given identical requested movement trajectories. A trial recorded 25 rendered frames at 5 fps, encoded an MP4, and extracted pose measurements from pixels. The metric below is the RMS angle error on the last eight observed frames. The test does **not** demonstrate improvement for arbitrary actions, cameras, or uncalibrated rendering.

| Trial | Final 8-frame observed RMSE (rad) | Decoded MP4 poses | Notes |
|---|---:|---:|---|
| Fixed, no visual correction | 0.1330525 | 25/25 | Biased target |
| Visual correction + original Ripple gain modulation | 0.0448805 | 25/25 | 11 spike events, gain changed |
| Visual correction, neural modulation **disabled** | **0.0445486** | 25/25 | Slightly better than neuron on |
| Visual correction with four frames of hidden markers | 0.0464879 | 21/25 | No invented pose in hidden frames |
| Visual correction, alternate camera yaw 0.75 | 0.0444733 | 25/25 | Calibrated for this camera yaw |

Relative reduction for visual correction with neural modulation **off** vs fixed = approximately 66.52% in **this single controlled test**. The observed 0.00033-rad difference between neural-on/off is not evidence of superior general performance. Preserve Ripple event telemetry, but keep gain modulation opt-in until demonstrated beneficial across independent tests.

## Negative results and limitations

- Four marker-hidden video frames correctly returned no pose estimate. The controller does not synthesize substitute angles; existing bounded motor targets may still continue while observations are missing.
- Rendering an image with camera yaw=0.45 and estimating it using a falsely calibrated yaw=0.95 was rejected for excessive reprojection residual.
- Markerless image-to-joint geometry remains unavailable. This release cannot independently recognize limbs on other avatars or camera feeds.
- Blender cannot be executed in this environment. These frames came from VTK; the source models are valid triangle meshes but no Blender viewport result was measured.
- Live local HTTP is a **finished-recording operator** rather than a browser-frame-by-frame live remote controller. Safe text instructions use the original literal grammar, not trained language inference.
- The numerical solver assumes known avatar model and known software camera; calibration from unknown external cameras must be implemented separately before real webcam usage.
- Golf Digital Eyes computes genuine source/pixel metrics but does not supply an image semantic classifier or solve the kinematic inverse. The trained Regulatory Colony v2 was excluded because digit/sequence classification does not establish joint-angle inference. Ring of Mushrooms v4 was excluded from control because the existing evidence does not show an improvement on this task.
- Physical photon flux, physiological consciousness, real EEG, actual human vision, and reliable ChatGPT-level comprehension are **not** inferred from normalized display RGB values.

## Reproducibility

Run `python -m pytest -q tests`, `python tests/study_50.py`, `python tools/study_servo.py`, `python tools/test_operator_http.py`. The original v1.9 suite was also rerun in this environment and passed **58/58**, but these are separate tests from the new add-on. A separate connected Floot cloud VM passed an independent pinhole-camera numerical contract; the full VTK program was not cloud-deployed.

Generated evidence: `results/study_50.json`, `results/servo_comparison.json`, `results/measured_visual_servo_comparison.png`, per-run `recording.mp4`, saved `frame_*.png`, source `timeline.json`, and independently re-decoded MP4 `encoded_video_observations.json`.
