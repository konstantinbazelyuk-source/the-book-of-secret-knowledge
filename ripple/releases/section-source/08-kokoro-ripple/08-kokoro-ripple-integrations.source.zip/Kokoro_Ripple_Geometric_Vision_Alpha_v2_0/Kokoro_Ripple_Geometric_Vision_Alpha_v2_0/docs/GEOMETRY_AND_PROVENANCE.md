# Actual mathematical interface and source boundaries

## Source assets

- The original v0.6/v1.9 Kokoro avatar is a real 3D triangle mesh with a hierarchical skeleton, per-vertex skin weights, world/bind transformation matrices and CPU VTK offscreen rendering. It is unchanged in `upstream/`.
- The v1.8 motor subsystem contains gene-parameterized virtual actuator controllers; its safety limits are independent of the genotype. It remains unchanged in `ripple_genome/`.
- Golf Digital Eyes v0.2 (`external/golf_eyes_original.py`) contains an unmodified source/image inspection function; it reads saved recorded image files, computing actual RGB counts, edge ratio, image focus and ORB features. Its signals are **not semantic scene labels**.
- The user Library's Ring of Mushrooms v4.0 has an eight-colony optical field and delayed spike communications; its own docs explicitly state Z is Gaussian scale, not physical depth. It has not been shown to solve camera inverse kinematics, so it is deliberately not used here.
- Regulatory Colony v2 is a trained sequence classifier for digit/order tasks, not a trained object pose model; it is deliberately excluded from the motor path.

## 3D triangular surface and geometry

A modeled surface is a connected set of planar triangles **embedded in three-dimensional space**. A vertex in its bind pose is p_i = (x_i,y_i,z_i,1). Linear blend skinning deforms this geometry:

`p_i(q) = Σ_j w_ij T_j(q) B_j^{-1} p_i`, where Σ_j w_ij ≈ 1.

The elbow, wrist and head observations are *diagnostic spheres in the 3D scene* attached to specific bones. Their 3D coordinates are transformed by the same bone-skin matrices; they are not 2D screen icons. The spheres are rendered with deliberately identifiable RGB colors. Without them, this detector reports unavailable rather than trying to infer arbitrary body shapes.

Camera: position E, focal F, forward d=(F−E)/||F−E||, right r=normalize(d × world_up), up=u=r × d. For X in world space, z=d·(X−E). With focal length `f = image_height/(2 tan(FOV_y/2))`:

`pixel_x = cx + f [r·(X−E)]/z`

`pixel_y = cy − f [u·(X−E)]/z`.

The entire calculation is implemented numerically in `vision3d/geometry.py`. `vision3d/renderer.py` draws real triangular geometry and real marker spheres at those 3D positions. Calibration is **known because it is a software camera**; real cameras need separate intrinsics/distortion/extrinsics calibration.

## Image-to-joint inverse estimation

OpenCV extracts the centroids of the three visible color-tag regions from decoded RGB images; the solver never accesses privileged virtual-servo angles. For camera projection π and skeleton transformation X_j(q), solve:

`q_hat = argmin_{hard_joint_limits} Σ_markers ||π(X_j(q))−pixel_j_measured||²`.

`scipy.optimize.least_squares` implements constrained nonlinear least-squares; the Jacobian is assessed by finite differences for rank=3. If markers are missing, the perspective depth is invalid, or reprojection error >4 pixels, report **unavailable**. This also rejects a deliberately miscalibrated camera tested with a 0.5-radian yaw mismatch.

This is position-based visual servoing using image measurements. It is **not** OpenCV `solvePnP` on a rigid body: the head and arm deform relative to each other, so the correct forward model is a 3-joint kinematic chain.

## Actuation and sensor feedback

The unmodified v1.8 `VirtualRobot` remains the inner *simulated* motor loop, with exact original joint constraints. A new outer loop changes its target using the image-derived estimate q_hat.

`q_cmd = clip(q_desired + calibration_bias + Kp · a_t · (q_desired−q_hat) + Ki · bounded_integral_error)`

with Kp=0.82, Ki=0.15, integration sample dt=0.2 seconds and anti-windup cap ±0.5 rad·s. The hard joint limits are applied **outside mutable parameters**. The calibration_bias is a **deliberately imposed experimental perturbation**, not something Kokoro had learned in production. When the scene is unobservable, no new visual correction is applied. The inner simulated joint controller still reads its own virtual motor state; the *outer* correcting input comes solely from decoded RGB pixels.

The preserved original Ripple leaky integrator consumes three measured pixel-channel intensities from specific colored 3D markers. Its original drive is `D=2R+1.2G−1.4B` and its adaptive spiking dynamics are unchanged. Optional `a_t = 0.75+0.35 clip(u/threshold + 1_{spike},0,1)` affects the camera feedback gain. The neuron fires and this affects commands, but did **not** improve holdout tracking against the same outer controller with a_t=1. Neural modulation is **off by default**; optical events remain an actual measured software signal.

The saved PNGs are independently processed using the **unchanged** Golf vision code; the saved MP4 is separately decoded with OpenCV for a post-encode inverse reconstruction audit. No text semantics are fabricated from pixels. Original v1.9 WAV/audio functionality is retained in the archived parent, but not coupled to this geometric motor feedback controller.

## Research sources

1. OpenCV Camera Calibration and 3D Reconstruction, https://docs.opencv.org/4.5.1/d9/d0c/group__calib3d.html (pinhole projection, 3D/2D pose relationship, reprojection error).
2. F. Chaumette & S. Hutchinson, *Visual Servo Control, Part I: Basic Approaches*, IEEE Robotics & Automation Magazine 2006, https://www.researchgate.net/publication/29614156_Visual_servo_control_Part_I_Basic_approaches (image-based and position-based servo distinctions).
3. ROS 2 trajectory representation, https://control.ros.org/master/doc/ros2_controllers/joint_trajectory_controller/doc/trajectory.html (strictly digital kinematic message interop, not hardware verification).
4. Golf Digital Eyes v0.2 from the user Library: archived Python code observed and copied without edits; `external/GOLF_EYES_SHA256.txt` holds the exact checksum.
5. Original Kokoro LUMINA / Ripple packages from the user Library and the mounted v1.9 working release.

**No license transfer implied:** archived source remains subject to original terms. New additive source is provided for local experimentation, not a claim about third-party ownership or redistributed trained weights.
