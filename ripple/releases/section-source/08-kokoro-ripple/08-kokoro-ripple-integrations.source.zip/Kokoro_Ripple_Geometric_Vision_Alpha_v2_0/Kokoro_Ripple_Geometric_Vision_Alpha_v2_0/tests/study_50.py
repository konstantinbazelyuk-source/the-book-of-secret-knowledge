from __future__ import annotations
import sys,pathlib,json,time
import numpy as np
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from vision3d.renderer import MarkerRenderer
from vision3d.geometry import observe_pixels,estimate_pose

def run():
 rng=np.random.default_rng(20261015);cases=[];renderers={}
 t=time.perf_counter()
 for i in range(50):
  yaw=float([.12,.35,.6,.85][i%4]);
  if yaw not in renderers:renderers[yaw]=MarkerRenderer(size=(320,420),yaw=yaw)
  renderer=renderers[yaw]
  angles=[float(rng.uniform(.18,1.18)),float(rng.uniform(-.5,.18)),float(rng.uniform(-.25,.25))]
  im=renderer.frame(angles)
  obs=observe_pixels(im)
  estimate=estimate_pose(obs,renderer.base.data['bones'],renderer.cam)
  available=bool(estimate['available'])
  error=[estimate['angles'][n]-angles[j] for j,n in enumerate(('arm_R','forearm_R','head'))] if available else None
  cases.append({'index':i,'yaw':yaw,'reference_joint_angles_rad':angles,'visible_tags':len(obs),
                'available':available,'error_rad':error,'reprojection_rmse_px':estimate.get('reprojection_rmse_px'),
                'reason':estimate.get('reason')})
 errors=[v for c in cases for v in (c['error_rad'] or [])]
 result={'classification':'50 actual VTK-rendered 3D RGB frames with simulated pose inputs','cases':len(cases),
         'valid_pose_reconstructions':sum(c['available'] for c in cases),'failures':[c for c in cases if not c['available']],
         'rms_joint_error_rad':float(np.sqrt(np.mean(np.square(errors)))) if errors else None,
         'p95_abs_joint_error_rad':float(np.percentile(np.abs(errors),95)) if errors else None,
         'max_abs_joint_error_rad':float(np.max(np.abs(errors))) if errors else None,
         'elapsed_wall_s':time.perf_counter()-t,'input':'3D rig vertices and actual rendered pixels',
         'camera':'known software calibration; no camera hardware'}
 out=ROOT/'results';(out/'study_50.json').write_text(json.dumps({'summary':result,'cases':cases},indent=2,allow_nan=False))
 print(json.dumps(result,indent=2));return result
if __name__=='__main__':run()
