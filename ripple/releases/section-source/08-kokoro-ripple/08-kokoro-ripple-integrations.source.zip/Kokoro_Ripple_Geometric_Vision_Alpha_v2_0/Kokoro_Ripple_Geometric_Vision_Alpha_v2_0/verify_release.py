#!/usr/bin/env python3
"""Check exact release bytes from the locally packaged manifest."""
from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'RELEASE_MANIFEST.json').read_text())
assert manifest['schema']=='kokoro-geometric-vision-v2.0-sha256'
for p,h in manifest['files'].items():
 path=(ROOT/p).resolve(strict=True)
 if not path.is_relative_to(ROOT.resolve()):raise RuntimeError('path escape')
 if hashlib.sha256(path.read_bytes()).hexdigest()!=h:raise RuntimeError('sha256 mismatch: '+p)
print(f"PASS: {len(manifest['files'])} release-file SHA-256 checks")
