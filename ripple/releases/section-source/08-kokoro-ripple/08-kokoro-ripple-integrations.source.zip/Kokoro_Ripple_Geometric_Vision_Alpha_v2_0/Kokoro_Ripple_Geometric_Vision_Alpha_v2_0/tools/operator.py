"""Bounded localhost Kokoro geometric visual feedback operator. No network model/API."""
import http.server,pathlib,sys,json,urllib.parse,re,uuid,argparse,math
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from vision3d.feedback import run_visual_trial
from vision3d.geometry import BOUNDS
from ripple_genome.grammar import parse_command
from ripple_genome.genetics import DEFAULT_LANGUAGE
PAGE='''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Kokoro: Geometric RGB Vision Operator</title><style>body{font:16px system-ui;background:#0a1522;color:#d9e8f3;max-width:780px;margin:auto;padding:20px}label{display:block;margin:15px 0}input{width:170px}button{background:#20a7ad;border:0;padding:14px 20px;border-radius:8px;font-weight:700;cursor:pointer}video{max-width:100%;border:1px solid #416577;border-radius:8px}.card{border:1px solid #365265;padding:12px;border-radius:12px;margin-bottom:14px}small{color:#a0bac9}</style></head><body><h2>Kokoro Geometric Vision Operator</h2><p>True 3D avatar mesh, perspective camera, marker-tracked RGB pixels, numerical inverse kinematics, and Ripple-controlled correction. <strong>Virtual avatar only.</strong></p><div class="card"><label>Restricted text instruction <input id="instruction" style="width:90%" maxlength="240" placeholder="raise right arm 40 degrees"></label><small>Uses the preserved v1.8 literal grammar, not a language model. Leave blank to use numeric sliders.</small><label>Right arm radians <input id="arm" type="number" min="-.12" max="1.48" step=".01" value=".95"></label><label>Forearm radians <input id="forearm" type="number" min="-.75" max=".5" step=".01" value="-.35"></label><label>Head radians <input id="head" type="number" min="-.35" max=".35" step=".01" value=".17"></label><label><input id="feedback" type="checkbox" checked style="width:auto"> Image-derived motor correction</label><label><input id="neural" type="checkbox" style="width:auto"> Active original Ripple optical modulation</label><button id="run">Record a 3D trial</button><p id="status" aria-live="polite"></p></div><video id="video" controls playsinline></video><pre id="summary" style="white-space:pre-wrap;word-break:break-word"></pre><small>Diagnostic colored markers are real 3D scene objects. They permit joint measurement only when visible and the virtual camera is calibrated. No real camera, unconnected AI weights, or physical motors are used.</small><script>document.getElementById('run').onclick=async()=>{const a=document.getElementById('arm'),f=document.getElementById('forearm'),h=document.getElementById('head'),s=document.getElementById('status');s.textContent='Rendering and decoding actual 3D frames. Please wait…';try{const r=await fetch('/api/run',{method:'POST',headers:{'Content-Type':'application/json','X-Kokoro-Local':'1'},body:JSON.stringify({goal:[Number(a.value),Number(f.value),Number(h.value)],instruction:document.getElementById('instruction').value.trim(),feedback:document.getElementById('feedback').checked,neural:document.getElementById('neural').checked})});const data=await r.json();if(!r.ok)throw new Error(data.error||'Request failed');document.getElementById('video').src=data.video;document.getElementById('summary').textContent=JSON.stringify(data.summary,null,2);s.textContent='Actual encoded video and observed joint tracking ready.'}catch(e){s.textContent=String(e)}};</script></body></html>'''
def handler(port):
 class H(http.server.BaseHTTPRequestHandler):
  def _reply(self,b,code=200,ct='application/json'):
   self.send_response(code);self.send_header('Content-Type',ct);self.send_header('Content-Length',str(len(b)));self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(b)
  def do_GET(self):
   if self.path=='/':return self._reply(PAGE.encode(),ct='text/html; charset=utf-8')
   m=re.fullmatch(r'/sessions/([a-f0-9]{32})/recording\.mp4',self.path)
   if m:
    p=ROOT/'sessions'/m.group(1)/'recording.mp4'
    if p.is_file():return self._reply(p.read_bytes(),ct='video/mp4')
   return self._reply(b'{"error":"Not found"}',404)
  def do_POST(self):
   if self.path!='/api/run':return self._reply(b'{"error":"Not found"}',404)
   origin=self.headers.get('Origin')
   if origin and origin not in (f'http://127.0.0.1:{port}',f'http://localhost:{port}'):
    return self._reply(b'{"error":"Cross-origin denied"}',403)
   if self.headers.get('X-Kokoro-Local')!='1':return self._reply(b'{"error":"Required local request header"}',403)
   try:
    length=int(self.headers.get('Content-Length','0'))
    if not 1<=length<=512:raise ValueError('payload size exceeds bounds')
    j=json.loads(self.rfile.read(length))
    if set(j)!={'goal','feedback','neural','instruction'} or type(j['feedback']) is not bool or type(j['neural']) is not bool or type(j['instruction']) is not str or len(j['instruction'])>240:raise ValueError('invalid command keys')
    goal=j['goal']
    if not isinstance(goal,list) or len(goal)!=3 or any(type(x) not in (float,int) or not math.isfinite(x) or not float(BOUNDS[i,0])<=x<=float(BOUNDS[i,1]) for i,x in enumerate(goal)):raise ValueError('unsafe joint command')
    if j['instruction']:
     action=parse_command(j['instruction'],DEFAULT_LANGUAGE)
     for joint,value in action.items():goal[{'arm_R':0,'forearm_R':1,'head':2}[joint]]=value
    name=uuid.uuid4().hex
    result=run_visual_trial(ROOT/'sessions'/name,feedback=j['feedback'],neural_enabled=j['neural'],frames=25,fps=5,goal=goal)
    return self._reply(json.dumps({'summary':result,'video':f'/sessions/{name}/recording.mp4'}).encode())
   except (ValueError,TypeError,KeyError) as e:return self._reply(json.dumps({'error':str(e)}).encode(),400)
  def log_message(self,*args):pass
 return H
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8776);a=p.parse_args()
 if not 1024<=a.port<=65535:p.error('port out of bounds')
 print(f'Kokoro 3D operator on http://127.0.0.1:{a.port}',flush=True)
 http.server.HTTPServer(('127.0.0.1',a.port),handler(a.port)).serve_forever()
