from pathlib import Path
import json,sys,math
BASE=Path(__file__).resolve().parents[1];sys.path.insert(0,str(BASE))
from vision3d.feedback import run_visual_trial
cases={
 'open':{'feedback':False,'neural_enabled':True},
 'closed_neural':{'feedback':True,'neural_enabled':True},
 'closed_no_neural':{'feedback':True,'neural_enabled':False},
 'closed_occluded':{'feedback':True,'neural_enabled':True,'disable_tags_at':(9,10,11,12)},
 'closed_alt_camera':{'feedback':True,'neural_enabled':True,'camera_yaw':.75},
}
results={}
for name,kw in cases.items():
 results[name]=run_visual_trial(BASE/'results'/name,frames=25,fps=5,**kw)
 print(name,results[name]['visual_joint_rmse_rad'],'MP4',results[name]['video_encoded_observed_pose_frames'],'/25','Ripple',results[name]['original_ripple_spikes'],flush=True)
# True engineering outcome: do not demand every case improve. Observed result is the report.
(BASE/'results'/'servo_comparison.json').write_text(json.dumps(results,indent=2,allow_nan=False))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,ax=plt.subplots(figsize=(8.7,4.5))
for name in ('open','closed_neural','closed_no_neural','closed_occluded'):
 t=json.loads((BASE/'results'/name/'timeline.json').read_text());x=[u['time_s'] for u in t];y=[math.sqrt(sum(a*a for a in u['joint_observed_error_rad'])/3) if u['joint_observed_error_rad'] else math.nan for u in t]
 ax.plot(x,y,label=name.replace('_',' '))
ax.set_xlabel('Virtual movement time (s)');ax.set_ylabel('Image-estimated joint error (rad RMS)')
ax.set_title('Observed 3D pose reconstruction: feedback ablations')
ax.grid(alpha=.25);ax.legend(fontsize=9);fig.tight_layout();fig.savefig(BASE/'results'/'measured_visual_servo_comparison.png',dpi=160);plt.close(fig)
