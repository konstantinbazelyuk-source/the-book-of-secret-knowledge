import subprocess,urllib.request,urllib.error,json,time,pathlib,sys
B=pathlib.Path(__file__).resolve().parents[1];port=8779
p=subprocess.Popen([sys.executable,str(B/'tools'/'operator.py'),'--port',str(port)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
base=f'http://127.0.0.1:{port}'
def call(path='/',data=None,extra=None):
 h=extra or {}
 if data is not None:h={'Content-Type':'application/json','X-Kokoro-Local':'1',**h}
 try:
  r=urllib.request.urlopen(urllib.request.Request(base+path, data=None if data is None else json.dumps(data).encode(),headers=h),timeout=60)
  return r.status,r.read()
 except urllib.error.HTTPError as e:return e.code,e.read()
try:
 for _ in range(80):
  try:
   status,body=call()
   if status==200:break
  except Exception:time.sleep(.1)
 else:raise RuntimeError('operator failed to open')
 assert b'Geometric Vision Operator' in body
 payload={'goal':[.95,-.35,.17],'instruction':'raise right arm 40 degrees','feedback':True,'neural':False}
 assert call('/api/run',payload,{'Origin':'https://unknown.test'})[0]==403
 assert call('/api/run',{**payload,'goal':[999.,0.,0.]})[0]==400
 assert call('/api/run',{**payload,'instruction':'execute arbitrary Python'})[0]==400
 code,body=call('/api/run',payload);assert code==200,(code,body[:250])
 data=json.loads(body);assert data['summary']['decoded_mp4_frames']==25
 code,video=call(data['video']);assert code==200 and len(video)>1000 and video[:4]!=b'<htm'
 print(json.dumps({'browser_page':True,'valid_language_move':True,'cross_origin_denied':True,'unsafe_position_denied':True,'unknown_text_denied':True,'video_bytes':len(video),'video_frames':data['summary']['decoded_mp4_frames'],'pose_estimated_from_encoded_video':data['summary']['video_encoded_observed_pose_frames']}))
finally:
 p.terminate()
 try:p.communicate(timeout=5)
 except subprocess.TimeoutExpired:p.kill();p.communicate()
