"""Run a verified 3D RGB pose-feedback trial. No trained Kokoro model required."""
import sys,pathlib,json,argparse
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]))
from vision3d.feedback import run_visual_trial
p=argparse.ArgumentParser()
p.add_argument('--feedback',choices=['on','off'],default='on')
p.add_argument('--neural',choices=['on','off'],default='off')
p.add_argument('--frames',type=int,default=25)
p.add_argument('--fps',type=int,choices=[5,10],default=5)
p.add_argument('--yaw',type=float,default=.45)
p.add_argument('--arm',type=float,default=.95)
p.add_argument('--forearm',type=float,default=-.35)
p.add_argument('--head',type=float,default=.17)
p.add_argument('--output',type=pathlib.Path,default=pathlib.Path(__file__).resolve().parents[1]/'results'/'custom')
a=p.parse_args()
if not .05<=a.yaw<=1.0:p.error('camera yaw must be .05..1')
print(json.dumps(run_visual_trial(a.output,feedback=a.feedback=='on',neural_enabled=a.neural=='on',frames=a.frames,fps=a.fps,camera_yaw=a.yaw,goal=(a.arm,a.forearm,a.head)),indent=2))
