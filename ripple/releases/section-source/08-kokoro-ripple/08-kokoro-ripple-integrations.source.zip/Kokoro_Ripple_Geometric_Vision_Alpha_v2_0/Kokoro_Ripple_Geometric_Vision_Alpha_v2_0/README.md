# Kokoro Ripple Geometric Vision & Visual Servo — runnable Alpha v2.0

**Actual capability:** a calibrated RGB-camera observation path for the previously approved **skinned 3D Kokoro rig**. The system measures visible landmarks from rendered/encoded pixels, solves bounded inverse kinematics for the right arm, forearm and head, and uses those observed angles to adjust commands to the **original virtual servo simulator**. Produces real raster frames and an independently decoded MP4. The original Kokoro/Ripple sources and model are not edited.

**Not claimed:** a complete trained Kokoro neural network, natural-scene understanding, 3D reconstruction from arbitrary video, markerless pose detection, uncalibrated cameras, physical motor control, EEG, photon measurement, Blender execution, or a calibrated real robot. Camera calibration and deliberately visible colored **3D diagnostic spheres** are essential. The servo and simulation are virtual. The avatar's shape is actual 3D polygonal geometry, not an animated 2D poster.

## Run

Windows: extract the ZIP, run `RUN_WINDOWS.bat`, open `http://127.0.0.1:8776` in the same machine. macOS/Linux: run `sh RUN_UNIX.sh` (requires compatible VTK offscreen/OpenGL system). Python 3.10+ and packages in `requirements.txt` are required.

For CLI control without a browser: `python tools/run_trial.py --arm .9 --forearm -.3 --head .1 --feedback on --neural off --frames 25 --output results/my_trial`

To reproduce the validations:

```bash
python -m pytest -q tests
python tests/study_50.py
python tools/study_servo.py
python tools/test_operator_http.py
python verify_release.py
```

A new operator session takes several seconds for complete rendering and encoding; the browser does not operate Blender or a physical robot. It responds with a finished MP4 plus image-observation metrics. Browser text instructions are parsed by the preserved v1.8 literal grammar (e.g., `raise right arm 40 degrees`)—there is no connected LLM.

## Verification highlights (current test environment)

- **50 real 3D-rendered image poses**, four software-camera angles: **50 reconstructed**, joint RMSE **0.01397 rad** against deliberately recorded simulator reference angles, max absolute error **0.02888 rad**.
- **25 frame matched virtual-servo trials** with deliberate command bias; terminal eight-observation visual RMSE: no image correction **0.13305 rad**; image feedback, Ripple modulation disabled **0.04455 rad**; image feedback, Ripple modulation enabled **0.04488 rad**. The difference between neural modulation configurations is too small for a positive claim; modulation is **off by default**.
- In a deliberate four-frame occlusion, recorded video showed **21/25** estimable poses, and the missing markers did not generate invented estimates. Wrong-camera calibration was rejected by reprojection error.
- All 25 ordinary MP4 frames decoded with enough landmark evidence in every non-occluded matched run. Encoded file analysis is executed separately, not presumed from in-memory RGB arrays.
- The original archived Golf Digital Eyes v0.2 Python vision function is **copied unchanged**, called on actual saved PNGs, and identified by SHA-256. It independently extracts actual pixel statistics, image edges, ORB keypoints and file hashes. This function does not determine joints.
- Ripple's preserved v0.1 neuron computes observed RGB-stimulus events. In this test, its optional gain modulation changed virtual commands but did **not** improve the tracking metric; keeping telemetry without automatic modulation is the currently justified default.
- `tools/operator.py` passed safe-text, unsafe-command and cross-origin HTTP tests; localhost-only service, no installed model weights or external accounts.

See [`docs/GEOMETRY_AND_PROVENANCE.md`](docs/GEOMETRY_AND_PROVENANCE.md) and [`docs/MEASURED_RESULTS.md`](docs/MEASURED_RESULTS.md).

## Preserved resources and exclusions

`upstream/` contains **unchanged source bytes** from the approved v1.9 package. `ripple_genome/` contains the unchanged v1.8 genetic robotics adapter supplied through v1.9. `external/golf_eyes_original.py` is byte-identical to the recovered public code observer in the user's Golf Digital Eyes package. The original v1.9 ZIP is retained in `parent/` for provenance, not silently installed or altered.

Ring of Mushrooms v4 and Regulatory Colony v2 were reviewed as additional available sources but **not inserted into the pose estimator**: their task-specific results do not establish superior camera geometric estimation. Unnecessary neural copies would add computational load without demonstrated benefit.
