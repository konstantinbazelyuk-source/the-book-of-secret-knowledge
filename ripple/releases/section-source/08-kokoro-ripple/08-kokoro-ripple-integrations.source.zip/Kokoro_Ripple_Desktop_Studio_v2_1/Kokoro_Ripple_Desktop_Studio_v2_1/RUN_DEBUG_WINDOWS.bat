@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Run RUN_WINDOWS.bat first to install the environment.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" launcher.py
if errorlevel 1 echo Desktop startup failed. Read the error above and logs\application.log
pause
endlocal
