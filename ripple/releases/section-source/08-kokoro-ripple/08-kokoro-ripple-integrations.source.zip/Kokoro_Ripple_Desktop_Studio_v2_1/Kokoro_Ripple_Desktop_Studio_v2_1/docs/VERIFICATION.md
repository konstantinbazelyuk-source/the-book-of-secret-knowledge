# Kokoro Ripple Desktop Studio v2.1 — Verification

## Provenance and non-destructive integration

- Parent: `Kokoro_Ripple_Geometric_Vision_Alpha_v2_0.zip` kept inside `legacy/` unchanged.
- All original computational Python modules under `vision3d/`, `ripple_genome/`, `upstream/`, and `external/` are byte-level copies from the existing release. New code is isolated in `studio/` and the new tests.
- Automated checksum comparisons opened the original zip and checked key source files including geometric camera, original Ripple neuron, genome colony and original virtual motor controller.
- The application uses original VTK skinned 3D rig data and diagnostic markers. Their positions are solved via RGB segmentation and perspective camera math, not hidden simulator angle values.

## Executed results, current Linux container

- Native Tk desktop window **actually launched** under an Xvfb display (the desktop screenshot is in `results/actual_desktop_window.png`).
- Submitted instruction `raise right arm 40 degrees` was parsed by the unchanged original literal language specialist into 0.6981317008 rad.
- Start → worker → actual VTK 3D render → RGB camera detection → Ripple step → GUI image widget: **five visible new frames** delivered, backed by actual PNG image bytes.
- Five MP4 frames encoded; all five decoded in the direct backend smoke trial, with five actual camera-pose observations.
- Native operator drove the original code parser and signal specialist; AST and event-count results were displayed in their GUI tabs.
- GUI saved settings to SQLite; a completely new desktop window recovered the selected arm angle and previous session history.
- Unsupported natural-language instruction rejected and shown as an error rather than inventing a response.
- Real GUI pause/resume, live motor-target change, live feedback-gain change, Stop MP4 finalization and Restart to a second saved session all passed in a separate actual-window integration test.
- Original integration regression and new tests: see `results/test_run.txt`. The included tests themselves can be rerun using `python -m pytest -q tests`.

## Observed performance (single trial; not a Dell specification)

See `results/performance.json` for the machine-reported metrics. Measurement captured on Linux/Python 3.13.5; it does not establish Windows or GPU performance. 12 frames at output file 5 FPS were rendered and independently decoded. CPU wall throughput is *not* the same as display frame rate, and no hardware GPU was profiled. VTK may produce an X-server warning with headless EGL offscreen rendering while still rendering correctly.

## Correct terminology and boundaries

| Capability | State |
|---|---|
| Native desktop window with controls and actual frames | Tested on Linux/Xvfb |
| Literal language-to-angle command | Tested |
| Two-way GUI/backend event transfer | Tested |
| 3D virtual joints, VTK image renderer | Tested |
| Calibrated RGB fiducial vision and motor feedback | Tested in virtual camera scenario |
| Manual numerical RGB → original Ripple signals | Tested |
| Static Python AST/JSON inspection | Tested |
| Start, Pause, Resume, Stop, Restart | Tested through GUI |
| Live parameter changes | Tested through GUI for joint and gain |
| Session history and settings restore | Tested through SQLite and GUI restart |
| Windows launcher / installation | Prepared; not executed on actual Dell laptop |
| Exact mid-frame C++/neuron state deserialization | Not implemented; saved state restores settings and session files |
| Actual trained Kokoro language AI | Not connected |
| Actual physical RGB camera/sensor | Not connected |
| Blender rig editing/Blender rendering | Not included in desktop runtime |
| Real robot / real video scene understanding | Not claimed |

## Safety/validation

- Original mechanical joint hard limits are enforced and are independent of adjustable feedback gain.
- Unsupported commands, nonfinite joint values, unsupported FPS, invalid camera settings, and schema-invalid project files generate real errors.
- Original photographic observation returns unavailable when required markers are absent.
- Startup/diagnostic UI doesn't assume the test host is the user's Dell laptop.
- The code analysis tab parses source but never executes user-entered code.
- Network services are not started by the native desktop app.
