"""Tests real GUI events: pause/resume, change parameters, stop, restart and persist."""
import sys,pathlib,time,tempfile,json
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from studio.desktop import Studio

def until(app,pred,timeout=30):
 deadline=time.monotonic()+timeout
 while time.monotonic()<deadline:
  app.update()
  if pred():return
  time.sleep(.012)
 raise AssertionError(f'Timeout state={app.runner.state} frames={app.frame_count}')

def main():
 p=pathlib.Path(tempfile.mkdtemp(prefix='kokoro_gui_lifecycle_'));a=Studio(root=p)
 a.vars['fps'].set(5);a.vars['frames'].set(100);a.start_job();until(a,lambda:a.frame_count>=2)
 a.pause_job();assert a.runner.state=='paused';old=a.frame_count
 deadline=time.monotonic()+.22
 while time.monotonic()<deadline:a.update();time.sleep(.01)
 assert a.frame_count<=old+1
 a.vars['arm'].set(.55);a.apply_joint_targets()
 a.vars['gain'].set(.37);a.apply_live()
 assert abs(a.runner.config.gain-.37)<.01
 a.resume_job();until(a,lambda:a.frame_count>=8)
 a.stop_job();until(a,lambda:a.runner.state=='stopped' and len(a.session_tree.get_children())>=1)
 prior_id=a.runner.session_id;assert (p/'sessions'/prior_id/'recording.mp4').exists()
 oldtrace=json.loads((p/'sessions'/prior_id/'timeline.json').read_text())
 assert any(abs(x['requested'][0]-.55)<.01 for x in oldtrace),[x['requested'][0] for x in oldtrace]
 assert any(abs(x['gain']-.37)<.01 for x in oldtrace)
 a.vars['frames'].set(5);a.restart_job();until(a,lambda:a.runner.state=='completed' and a.frame_count==5 and len(a.session_tree.get_children())>=2)
 assert a.runner.session_id!=prior_id
 assert (p/'sessions'/a.runner.session_id/'summary.json').exists()
 result={'GUI_pause':True,'GUI_live_joint_update':True,'GUI_live_gain_update':True,'GUI_stop_finalized_mp4':True,'GUI_restart':True,'sessions':len(a.session_tree.get_children())}
 (ROOT/'results'/'lifecycle_smoke.json').write_text(json.dumps(result,indent=2))
 print(json.dumps(result))
 a.destroy()
if __name__=='__main__':main()
