"""Real Tk window integration test. Run with xvfb-run on headless Linux."""
import os,sys,time,json,pathlib,tempfile
from PIL import ImageGrab
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from studio.desktop import Studio

def main():
 storage=pathlib.Path(tempfile.mkdtemp(prefix='kokoro_desktop_gui_'))
 app=Studio(root=storage)
 assert app.winfo_exists()
 app.instruction.set('raise right arm 40 degrees')
 app.apply_instruction()
 assert abs(app.vars['arm'].get()-.6981317007977318)<1e-7
 app.code_source.delete('1.0','end');app.code_source.insert('1.0','def f(): return 1\n')
 app.inspect_code();assert 'valid' in app.code_output.get('1.0','end')
 app.run_rgb();assert 'event_count' in app.rgb_result.get('1.0','end')
 app.vars['fps'].set(5);app.vars['frames'].set(5)
 app.start_job()
 start=time.monotonic()
 while time.monotonic()-start<30:
  app.update()
  if app.runner.state=='completed' and app.frame_count==5 and len(app.session_tree.get_children())==1:break
  time.sleep(.01)
 assert app.runner.state=='completed',app.status.get()
 assert app.frame_count==5 and app.last_png is not None
 assert app.preview.cget('image')
 assert len(app.session_tree.get_children())==1
 app.save_state()
 app.update()
 bounds=(app.winfo_rootx(),app.winfo_rooty(),app.winfo_rootx()+app.winfo_width(),app.winfo_rooty()+app.winfo_height())
 result_path=ROOT/'results';result_path.mkdir(exist_ok=True)
 ImageGrab.grab(bbox=bounds,all_screens=True).save(result_path/'actual_desktop_window.png')
 app.destroy()
 app2=Studio(root=storage)
 assert abs(app2.vars['arm'].get()-.6981317007977318)<1e-7
 assert len(app2.session_tree.get_children())==1
 app2.instruction.set('think and speak like a human')
 app2.apply_instruction()
 assert 'Error:' in app2.status.get()
 app2.destroy()
 outcome={'display':'actual Tk window on Xvfb','rendered_frames':5,'image_bytes':len((storage/'sessions').rglob('frame_004.png').__iter__().__next__().read_bytes()),'restored_from_sqlite':True,'unsupported_instruction_rejected':True}
 (result_path/'gui_smoke.json').write_text(json.dumps(outcome,indent=2))
 print(json.dumps(outcome))

if __name__=='__main__':main()
