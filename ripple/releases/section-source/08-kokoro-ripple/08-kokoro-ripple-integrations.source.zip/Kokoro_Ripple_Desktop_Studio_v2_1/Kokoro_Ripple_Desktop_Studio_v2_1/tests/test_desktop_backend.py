import dataclasses,hashlib,json,pathlib,queue,time,zipfile
import numpy as np, pytest
from studio.backend import Config,Runner
from studio.storage import Storage

@pytest.mark.parametrize('param,value',[
 ('arm',99),('head',1),('fps',7),('frames',141),('gain',1.8),('camera_yaw',4),('bias_arm',.5),('arm',float('nan'))])
def test_runtime_rejects_unbounded_control(param,value):
 c=Config();setattr(c,param,value)
 with pytest.raises(ValueError):c.validate()

def test_sqlite_restore(tmp_path):
 s=Storage(tmp_path);c=dataclasses.asdict(Config(arm=.45,fps=2))
 s.save_settings(c);s2=Storage(tmp_path)
 assert s2.load_settings()==c
 s2.start_session('a',tmp_path,c);s2.finish_session('a','stopped',{'frames_encoded':1})
 assert s2.get('a')['status']=='stopped'

def test_language_code_and_signal_are_original(tmp_path):
 r=Runner(tmp_path,Storage(tmp_path/'db'))
 assert .69<r.command('raise right arm 40 degrees')['arm_R']<.70
 assert r.analyze_code('def f(x):return x+1')['summary']['functions']==1
 assert r.analyze_code('oops !!')['syntax']=='invalid'
 assert r.analyze_code('{"valid":true}','json')['syntax']=='valid'
 signal=r.analyze_rgb([[.9,.2,.1],[.9,.2,.1],[.1,.1,.1]])
 assert signal['samples']==3 and signal['observed_samples']>0
 with pytest.raises(ValueError):r.command('invent a helicopter')
 with pytest.raises(ValueError):r.analyze_rgb([[10,0,0]])

def test_actual_3d_record_and_decoded_observation(tmp_path):
 s=Storage(tmp_path/'db');r=Runner(tmp_path,s)
 r.start(Config(frames=5,fps=5,neural=False));assert r.wait(35)
 assert r.state=='completed' and r.last_result['frames_encoded']==5
 assert r.last_result['frames_decoded']==5 and r.last_result['pose_observations']==5
 assert list((r.current_dir).glob('frame_*.png'))
 events=[]
 while not r.events.empty():events.append(r.events.get_nowait())
 assert sum(x['event']=='frame' for x in events)==5
 assert events[-1]['event']=='complete'
 assert s.get(r.session_id)['status']=='completed'
 assert r.last_result['trained_kokoro_core_connected'] is False

def test_pause_resume_live_update_stop_and_restart(tmp_path):
 r=Runner(tmp_path,Storage(tmp_path/'db'))
 r.start(Config(frames=50,fps=5))
 deadline=time.monotonic()+12
 while time.monotonic()<deadline:
  if r.events.qsize()>=2:break
  time.sleep(.01)
 assert r.state=='running'
 r.pause();assert r.state=='paused'
 count_before=r.events.qsize();time.sleep(.45);count_after=r.events.qsize()
 assert count_after<=count_before+1  # one in-flight frame can finish before pause gate
 r.update(arm=.6,feedback=False,gain=.25,neural=True)
 with pytest.raises(ValueError):r.update(fps=10)
 r.resume();time.sleep(.30);r.stop();assert r.wait(30)
 assert r.state=='stopped'
 frames=json.loads((r.current_dir/'timeline.json').read_text())
 assert frames
 assert (r.current_dir/'recording.mp4').exists()
 r.start(Config(frames=5,fps=5));assert r.wait(30)
 assert r.state=='completed'

def test_preserved_parent_source_identical(tmp_path):
 root=pathlib.Path(__file__).resolve().parents[1]
 archive=root/'legacy'/'Kokoro_Ripple_Geometric_Vision_Alpha_v2_0.zip'
 assert archive.exists()
 with zipfile.ZipFile(archive) as z:
  for rel in ['vision3d/geometry.py','vision3d/renderer.py','vision3d/feedback.py',
              'upstream/motor_neuron_v07.py','upstream/ripple_core_v0_5.py',
              'ripple_genome/genetics.py','ripple_genome/colony.py']:
   matches=[n for n in z.namelist() if n.endswith('/'+rel) or n==rel]
   assert matches,rel
   original=z.read(matches[0]);current=(root/rel).read_bytes()
   assert hashlib.sha256(original).digest()==hashlib.sha256(current).digest(),rel
