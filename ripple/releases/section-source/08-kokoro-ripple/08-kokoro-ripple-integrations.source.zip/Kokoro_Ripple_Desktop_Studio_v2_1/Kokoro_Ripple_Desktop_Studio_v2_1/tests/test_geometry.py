import hashlib,math,pathlib,sys
import numpy as np
import pytest
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from vision3d.geometry import marker_world,project,observe_pixels,estimate_pose,BOUNDS
from vision3d.renderer import MarkerRenderer
from vision3d.feedback import VisualFeedback

def test_projection_consistency():
 r=MarkerRenderer(size=(300,400))
 targets=(.9,-.35,.19)
 im=r.frame(targets)
 observed=observe_pixels(im)
 expected=r.cam.project(marker_world(r.base.data['bones'],targets))
 assert len(observed)==3
 assert max(np.linalg.norm(observed[k]-expected[k]) for k in observed)<2
 q=estimate_pose(observed,r.base.data['bones'],r.cam)
 assert q['available']
 assert np.max(np.abs([q['angles'][k]-v for k,v in zip(('arm_R','forearm_R','head'),targets)]))<.035

def test_no_invented_pose_when_occluded():
 r=MarkerRenderer(size=(280,360))
 im=r.frame((.5,-.3,.1),with_markers=False)
 assert estimate_pose(observe_pixels(im),r.base.data['bones'],r.cam)['available'] is False

def test_unsafe_targets_rejected():
 r=MarkerRenderer(size=(240,320));c=VisualFeedback(r)
 with pytest.raises(ValueError):c.safe_command([99.,0.,0.],[0.,0.,0.],{'pose':{'available':False,'reason':'x'}})
 with pytest.raises(ValueError):c.safe_command([float('nan'),0,0],[0,0,0],{'pose':{'available':False,'reason':'x'}})

def test_numeric_jacobian_rank():
 r=MarkerRenderer(size=(300,400))
 z=(.7,-.2,.05);obs=r.cam.project(marker_world(r.base.data['bones'],z))
 q=estimate_pose(obs,r.base.data['bones'],r.cam)
 assert q['rank']==3 and q['available']
 assert max(abs(q['angles'][j]-v) for j,v in zip(('arm_R','forearm_R','head'),z))<1e-4

def test_preserved_upstream_file_hash():
 from vision3d.geometry import ROOT
 original=pathlib.Path('/mnt/data/Kokoro_Ripple_Perception_Action_Loop_v1_9/upstream')
 if not original.is_dir():pytest.skip('no original library mount')
 for n in ('vtk_renderer.py','model_data.js','ripple_core_v0_5.py','motor_neuron_v07.py'):
  assert hashlib.sha256((ROOT/'upstream'/n).read_bytes()).hexdigest()==hashlib.sha256((original/n).read_bytes()).hexdigest()

def test_golf_source_unchanged():
 import zipfile
 p=pathlib.Path('/mnt/data/kokoro_new_sources/Golf-Ripple-Digital-Eyes-Engine-v0.2-Complete.zip')
 if not p.is_file():pytest.skip('original not mounted')
 with zipfile.ZipFile(p) as z:
  assert (ROOT/'external'/'golf_eyes_original.py').read_bytes()==z.read('Golf-Ripple-Digital-Eyes-v0.2/src/eyes.py')

def test_camera_miscalibration_rejected():
 from vision3d.geometry import Calibration
 r=MarkerRenderer(size=(300,400),yaw=.45)
 obs=observe_pixels(r.frame((.7,-.25,.15)))
 result=estimate_pose(obs,r.base.data['bones'],Calibration(size=(300,400),yaw=.95))
 assert not result['available'] and result['reason']=='reprojection_error_exceeds_gate'
