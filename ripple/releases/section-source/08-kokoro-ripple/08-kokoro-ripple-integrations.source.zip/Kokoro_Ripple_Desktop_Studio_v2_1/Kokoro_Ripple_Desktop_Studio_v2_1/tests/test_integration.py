import pathlib,sys,json,cv2,numpy as np,hashlib
from unittest import mock
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from vision3d.renderer import MarkerRenderer
from vision3d.feedback import VisualFeedback,run_visual_trial
from vision3d.video import inspect_recorded_video
from ripple_genome.grammar import parse_command
from ripple_genome.genetics import DEFAULT_LANGUAGE

def test_original_language_instruction_maps_to_radians():
 a=parse_command('raise right arm 40 degrees',DEFAULT_LANGUAGE)
 assert a['arm_R']>0.69 and a['arm_R']<0.70

def test_image_RGB_drives_original_ripple_and_actual_command():
 r=MarkerRenderer(size=(280,360));p=r.frame((.7,-.3,.11))
 import cv2
 ok,enc=cv2.imencode('.png',cv2.cvtColor(np.asarray(p),cv2.COLOR_RGB2BGR));assert ok
 on=VisualFeedback(r,neural_enabled=True);off=VisualFeedback(r,neural_enabled=False)
 m=on.measure(enc.tobytes());off.measure(enc.tobytes())
 assert len(m['ripple_stimulus'])==3 and max(m['ripple_stimulus'])>.8
 d=np.array([.95,-.35,.17]);bias=np.array([-.19,.13,-.08])
 a,meta=on.safe_command(d,bias,m);b,_=off.safe_command(d,bias,m)
 assert meta['used_feedback'];assert not np.allclose(list(a.values()),list(b.values()))
 assert np.all(np.array(list(a.values()))<=[1.48,.5,.35])

def test_preexisting_recording_analyzable():
 f=ROOT/'results'/'closed_neural'/'recording.mp4'
 if not f.is_file():return
 r=MarkerRenderer(size=(320,420));x=inspect_recorded_video(f,r.base.data['bones'],r.cam)
 assert x['frames_decoded']==25 and x['frames_with_pose']>=20

def test_missing_landmarks_do_not_control():
 r=MarkerRenderer(size=(240,320));c=VisualFeedback(r)
 v=c.measure(cv2.imencode('.png',cv2.cvtColor(np.asarray(r.frame((.2,0,0),with_markers=False)),cv2.COLOR_RGB2BGR))[1].tobytes())
 cmd,meta=c.safe_command([.95,-.35,.17],[-.19,.13,-.08],v)
 assert not v['pose']['available'] and not meta['used_feedback']
