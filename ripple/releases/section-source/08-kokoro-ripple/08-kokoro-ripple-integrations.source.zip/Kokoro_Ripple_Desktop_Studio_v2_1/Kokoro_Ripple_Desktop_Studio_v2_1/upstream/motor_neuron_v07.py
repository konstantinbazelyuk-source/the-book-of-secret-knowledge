"""Ripple-Motor v0.7: bounded avatar motion controller + cumulative trial memory.

Not trained AI and not physical motor control. Original Ripple v0.1 LIF equation is
preserved by importing upstream/ripple_core_v0_5.py, not reimplementing it.
Repeated-trial memory follows iterative learning control (ILC), not neural weights.
"""
from __future__ import annotations
import hashlib, json, math, pathlib, sys, os, tempfile
from dataclasses import dataclass
BASE=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'upstream'))
from ripple_core_v0_5 import RippleNeuron

DT=0.02
JOINT_LIMITS={'arm_R':(-0.12,1.48),'forearm_R':(-.75,.5),'head':(-.35,.35)}
SPEED_LIMITS={'arm_R':2.8,'forearm_R':3.0,'head':1.3}
ACCEL_LIMITS={'arm_R':18.,'forearm_R':20.,'head':10.}
FF_MAX=3.0

def finite(value,lo=-1e5,hi=1e5):
    if type(value) not in (int,float) or not math.isfinite(value) or not lo<=value<=hi:
        raise ValueError('finite bounded numeric input required')
    return float(value)

def clamp(x,lo,hi):return max(lo,min(hi,x))

def target(t,skill='greet'):
    """Offline target for rig joints. Units radians; NOT measured human motion."""
    finite(t,0,60)
    if skill!='greet':raise ValueError('unknown skill')
    # smooth 0->1->hold->0 sequence; no discontinuous target acceleration
    def ease(u):u=clamp(u,0,1);return u*u*(3-2*u)
    lift=ease((t-.25)/1.0)*(1-ease((t-3.45)/.95))
    return {'arm_R':1.19*lift,
            'forearm_R':-.38*lift+.15*lift*math.sin(2*math.pi*1.25*t),
            'head':.11*ease((t-.3)/1.3)*(1-ease((t-4.0)/.65))}

@dataclass
class MotorObservation:
    t:float
    target:float
    angle:float
    velocity:float
    command:float
    tracking_error:float
    event_count:int
    threshold:float

class MotorNeuron:
    """A real software controller with an original Ripple event monitor.

    Plant telemetry is mandatory; absent observations are rejected. The LIF neuron
    observes tracking-error, motor activity and remaining safety headroom. It does
    not claim sensory or conscious experience. Learning occurs between repetitions.
    """
    def __init__(self,joint='arm_R',gains=(12.0,3.0),command_max=5.0, slew=45.0):
        if joint not in JOINT_LIMITS:raise ValueError('joint not in v0.6 rig')
        self.joint=joint;self.kp,self.kd=gains
        self.max_u=finite(command_max,.05,30);self.slew=finite(slew,.1,300)
        self.monitor=RippleNeuron();self.prev_u=0.0;self.prev_v=0.0;self.prev_target=0.0
        self.samples=[]
    def step(self,t,y,v,r,feedforward,dt=DT):
        if not 0<finite(dt)<=.5:raise ValueError('invalid dt')
        lo,hi=JOINT_LIMITS[self.joint]
        t=finite(t,0,1e5);y=finite(y,lo,hi);v=finite(v,-30,30)
        r=finite(r,lo,hi);ff=finite(feedforward,-FF_MAX,FF_MAX)
        # Target derivative is bounded; cannot exceed realistic avatar rig rate.
        rv=clamp((r-self.prev_target)/dt,-SPEED_LIMITS[self.joint],SPEED_LIMITS[self.joint])
        e=r-y
        desired=self.kp*e+self.kd*(rv-v)+ff
        desired=clamp(desired,-self.max_u,self.max_u)
        u=clamp(desired,self.prev_u-self.slew*dt,self.prev_u+self.slew*dt)
        # Side-effect-free RGB categories; these are numbers, not literal RGB photons.
        err_norm=clamp(abs(e)/(hi-lo),0,1)
        effort=clamp(abs(u)/self.max_u,0,1)
        headroom=clamp(min(y-lo,hi-y)/(hi-lo)*2,0,1)
        spike=self.monitor.step((err_norm,effort,headroom),dt)
        self.prev_u=u;self.prev_v=v;self.prev_target=r
        item=MotorObservation(t,r,y,v,u,e,spike['count'],spike['theta'])
        self.samples.append(item)
        return item

class VirtualJointPlant:
    """Declared second-order simulated servo only; never a physical hardware claim."""
    def __init__(self,joint,gain=1.0,damping=2.5,inertia=1.0,disturbance=0.0):
        self.joint=joint;self.gain=finite(gain,.1,5);self.damping=finite(damping,0,20)
        self.inertia=finite(inertia,.2,10);self.disturbance=finite(disturbance,-2,2)
        self.x=0.0;self.v=0.0;self.n=0;self.clipped=0
    def step(self,u,dt=DT):
        finite(u,-30,30);dt=finite(dt,1e-5,.5)
        acc=(self.gain*u-self.damping*self.v+self.disturbance)/self.inertia
        # Semi-implicit integration with explicit speed, acceleration and joint clamps.
        acc=clamp(acc,-ACCEL_LIMITS[self.joint],ACCEL_LIMITS[self.joint]);self.v=clamp(self.v+dt*acc,-SPEED_LIMITS[self.joint],SPEED_LIMITS[self.joint])
        lo,hi=JOINT_LIMITS[self.joint]
        new_x=clamp(self.x+dt*self.v,lo,hi)
        if new_x in (lo,hi) and abs(new_x-(self.x+dt*self.v))>1e-12:
            self.clipped+=1;self.v=0.0
        self.x=new_x;self.n+=1
        return self.x,self.v

def run_trial(joint='arm_R',skill='greet',ff=None,dt=DT,duration=5.2,plant_kwargs=None):
    steps=round(duration/dt)
    if abs(steps*dt-duration)>1e-8:raise ValueError('duration must be multiple of dt')
    if ff is None:ff=[0.0]*steps
    if len(ff)!=steps:raise ValueError('wrong memory shape')
    controller=MotorNeuron(joint);plant=VirtualJointPlant(joint,**(plant_kwargs or {}))
    errors=[];desired=[];commands=[];out=[];events=0
    for k in range(steps):
        t=k*dt;r=target(t,skill)[joint]
        p=controller.step(t,plant.x,plant.v,r,ff[k],dt)
        x,v=plant.step(p.command,dt)
        desired.append(r);errors.append(r-x);commands.append(p.command);out.append(x);events+=p.event_count
    rmse=math.sqrt(sum(e*e for e in errors)/steps)
    effort=sum(u*u for u in commands)*dt
    return {'rmse':rmse,'squared_effort':effort,'samples':steps,'events':events,
            'joint_limit_hits':plant.clipped,'errors':errors,'commands':commands,'actual':out,'desired':desired,
            'theta_last':controller.monitor.theta,'t_s':duration}

class MotorSkillMemory:
    """Bounded per-skill feedforward with transaction-like accept / rollback.
    Candidate must improve nominal training RMSE by >=0.5% and not worsen a
    withheld plant with different motor gain/damping by >2%. No silent writes.
    """
    def __init__(self,joint='arm_R',dt=DT,duration=5.2):
        if joint not in JOINT_LIMITS:raise ValueError('unknown joint')
        self.joint=joint;self.dt=dt;self.steps=round(duration/dt);self.duration=duration
        self.ff=[0.0]*self.steps;self.version=0;self.history=[]
    def evaluate(self,weights=None):
        ff=self.ff if weights is None else weights
        train=run_trial(self.joint,ff=ff,dt=self.dt,duration=self.duration)
        # This held-out parameter set is explicitly different from training.
        val=run_trial(self.joint,ff=ff,dt=self.dt,duration=self.duration,
                      plant_kwargs={'gain':.75,'damping':3.5,'inertia':1.25,'disturbance':.1})
        return train,val
    def learn(self,eta=1.0):
        eta=finite(eta,.0001,50.)
        before_train,before_val=self.evaluate()
        e=before_train['errors']
        # ILC: u^{k+1}(t)=clip(u^k(t)+L*e^k(t), limits). Smooth high-frequency
        # updates to avoid amplifying noise or turning a trajectory discontinuous.
        raw=[clamp(self.ff[i]+eta*e[i],-FF_MAX,FF_MAX) for i in range(self.steps)]
        smooth=[clamp((raw[max(0,i-1)]+2*raw[i]+raw[min(self.steps-1,i+1)])/4,-FF_MAX,FF_MAX) for i in range(self.steps)]
        trial_train,trial_val=self.evaluate(smooth)
        accepted=(trial_train['rmse']<=before_train['rmse']*.995 and
                  trial_val['rmse']<=before_val['rmse']*1.02 and
                  trial_train['joint_limit_hits']==0 and trial_val['joint_limit_hits']==0)
        reason=('improved-and-validated' if accepted else 'rolled-back-on-criteria')
        if accepted:self.ff=smooth;self.version+=1
        entry={'attempt':len(self.history)+1,'version':self.version,'accepted':accepted,'reason':reason,
          'train_before_rmse':before_train['rmse'],'train_candidate_rmse':trial_train['rmse'],
          'validation_before_rmse':before_val['rmse'],'validation_candidate_rmse':trial_val['rmse'],
          'max_feedforward':max(map(abs,self.ff)),'original_neuron_modified':False}
        self.history.append(entry)
        return entry
    def snapshot(self):
        obj={'schema':'kokoro.ripple.motor.skill.v1','joint':self.joint,'dt':self.dt,'duration':self.duration,
             'weights':self.ff,'version':self.version,'history':self.history}
        checksum=hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(',',':')).encode()).hexdigest()
        return {'payload':obj,'sha256':checksum}
    def save(self,path):
        path=pathlib.Path(path)
        if not path.parent.exists():raise FileNotFoundError('create destination folder explicitly')
        b=json.dumps(self.snapshot(),indent=2).encode()
        fd,temp=tempfile.mkstemp(prefix='.motor-',dir=path.parent)
        try:
            with os.fdopen(fd,'wb') as f:f.write(b);f.flush();os.fsync(f.fileno())
            os.replace(temp,path)
        finally:
            if os.path.exists(temp):os.unlink(temp)
    @classmethod
    def load(cls,path):
        obj=json.loads(pathlib.Path(path).read_text());data=obj['payload']
        check=hashlib.sha256(json.dumps(data,sort_keys=True,separators=(',',':')).encode()).hexdigest()
        if check!=obj['sha256'] or data['schema']!='kokoro.ripple.motor.skill.v1':raise ValueError('integrity check failed')
        m=cls(data['joint'],data['dt'],data['duration'])
        if len(data['weights'])!=m.steps:raise ValueError('wrong weight dimensions')
        m.ff=[finite(x,-FF_MAX,FF_MAX) for x in data['weights']]
        if type(data['version']) is not int or data['version']<0:raise ValueError('invalid version')
        m.version=data['version'];m.history=data['history']
        return m
