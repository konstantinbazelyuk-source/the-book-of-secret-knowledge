"""Persistent runtime settings and verified session metadata. Thread-safe SQLite usage."""
from __future__ import annotations
import json, sqlite3, pathlib, time, threading

class Storage:
 def __init__(self, root):
  self.root = pathlib.Path(root)
  self.root.mkdir(parents=True,exist_ok=True)
  self.db=self.root/'kokoro_studio.sqlite3'
  self.lock=threading.RLock()
  with self._db() as db:
   db.execute('CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)')
   db.execute('''CREATE TABLE IF NOT EXISTS sessions (
       id TEXT PRIMARY KEY, started TEXT NOT NULL, finished TEXT, status TEXT NOT NULL,
       directory TEXT NOT NULL, config TEXT NOT NULL, summary TEXT)''')
 def _db(self):
  c=sqlite3.connect(self.db, timeout=15)
  c.row_factory=sqlite3.Row
  return c
 def save_settings(self,config):
  data=json.dumps(config,allow_nan=False)
  with self.lock, self._db() as db:db.execute('INSERT OR REPLACE INTO settings VALUES (?,?)',('current',data))
 def load_settings(self):
  with self.lock,self._db() as db:
   r=db.execute('SELECT value FROM settings WHERE key=?',('current',)).fetchone()
  return json.loads(r[0]) if r else None
 def start_session(self,identifier,path,config):
  with self.lock,self._db() as db:
   db.execute('INSERT INTO sessions(id,started,status,directory,config) VALUES(?,?,?,?,?)',
              (identifier,time.strftime('%Y-%m-%d %H:%M:%S'), 'running',str(path),json.dumps(config,allow_nan=False)))
 def finish_session(self,identifier,status,summary):
  with self.lock,self._db() as db:
   db.execute('UPDATE sessions SET finished=?,status=?,summary=? WHERE id=?',
              (time.strftime('%Y-%m-%d %H:%M:%S'),status,json.dumps(summary,allow_nan=False),identifier))
 def sessions(self):
  with self.lock,self._db() as db:
   return [dict(row) for row in db.execute('SELECT * FROM sessions ORDER BY started DESC LIMIT 200')]
 def get(self,identifier):
  with self.lock,self._db() as db:
   x=db.execute('SELECT * FROM sessions WHERE id=?',(identifier,)).fetchone()
  return dict(x) if x else None
