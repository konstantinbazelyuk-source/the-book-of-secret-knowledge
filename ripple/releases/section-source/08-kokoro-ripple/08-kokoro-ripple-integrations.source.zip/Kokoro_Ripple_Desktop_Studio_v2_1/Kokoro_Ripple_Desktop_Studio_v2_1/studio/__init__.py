"""Kokoro Ripple Desktop Studio: native GUI and preserved v2.0 computational runtime."""
