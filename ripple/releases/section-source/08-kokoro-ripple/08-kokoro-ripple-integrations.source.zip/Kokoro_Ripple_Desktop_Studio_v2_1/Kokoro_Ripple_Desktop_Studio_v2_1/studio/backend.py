"""True streamed 3D geometric visual-feedback runtime using original v2.0 modules.

The mathematical/renderer components are imported, not rewritten. The stream is
actual VTK pixels and the observations are decoded RGB marker measurements.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
import copy, hashlib,json, math, pathlib, queue, threading, time, traceback, uuid
import numpy as np, cv2
from vision3d.feedback import VisualFeedback, clip_to_limits
from vision3d.geometry import JOINTS,BOUNDS
from vision3d.renderer import MarkerRenderer
from vision3d.video import inspect_recorded_video
from ripple_genome.robotics import VirtualRobot
from ripple_genome.colony import Overseer
from ripple_genome.genetics import DEFAULT_LANGUAGE
from ripple_genome.grammar import parse_command
from upstream.motor_neuron_v07 import DT

@dataclass
class Config:
 arm:float=.95
 forearm:float=-.35
 head:float=.17
 bias_arm:float=-.19
 bias_forearm:float=.13
 bias_head:float=-.08
 feedback:bool=True
 neural:bool=False
 gain:float=.82
 fps:int=5
 frames:int=25
 camera_yaw:float=.45
 def validate(self):
  values=asdict(self)
  for n in ('arm','forearm','head','bias_arm','bias_forearm','bias_head','gain','camera_yaw'):
   v=values[n]
   if type(v) not in (float,int) or not math.isfinite(v):raise ValueError(f'{n} must be finite')
  goal=np.array([self.arm,self.forearm,self.head])
  if np.any(goal<BOUNDS[:,0]) or np.any(goal>BOUNDS[:,1]):raise ValueError('Joint position exceeds original hard limits')
  if any(abs(x)>0.3 for x in (self.bias_arm,self.bias_forearm,self.bias_head)):raise ValueError('Bias outside study bounds +/-0.3')
  if not 0<=self.gain<=1:raise ValueError('Feedback gain must be 0..1')
  if self.fps not in (2,5,10):raise ValueError('Frame rate must be 2, 5 or 10 fps')
  if type(self.frames) is not int or not 5<=self.frames<=140:raise ValueError('Frames must be 5..140')
  if not -.8<=self.camera_yaw<=.8:raise ValueError('Camera yaw must be -0.8..0.8 radians')
  if type(self.feedback) is not bool or type(self.neural) is not bool:raise ValueError('Flags must be bool')
  return self
 def goal(self):return np.array([self.arm,self.forearm,self.head],dtype=float)
 def bias(self):return np.array([self.bias_arm,self.bias_forearm,self.bias_head],dtype=float)

class Runner:
 def __init__(self,root,storage,events=None):
  self.root=pathlib.Path(root);self.storage=storage
  self.events=events if events is not None else queue.Queue(maxsize=400)
  self.lock=threading.RLock();self.pause_gate=threading.Event();self.pause_gate.set()
  self.stop_gate=threading.Event();self.thread=None
  self.state='idle';self.config=Config();self.session_id=None;self.current_dir=None
  self.colony=Overseer(max_workers=4)
  self.last_result=None
 def emit(self,kind,**data):
  event={'event':kind,'time':time.time(),**data}
  try:self.events.put_nowait(event)
  except queue.Full:
   if kind=='frame':return
   try:self.events.get_nowait()
   except queue.Empty:pass
   self.events.put_nowait(event)
 def command(self,text):
  changes=self.colony.dispatch({'kind':'language','text':text})['joint_targets']
  with self.lock:
   update={'arm_R':'arm','forearm_R':'forearm','head':'head'}
   for joint,value in changes.items():setattr(self.config,update[joint],float(value))
   self.config.validate()
  self.emit('log',message=f'Literal command parsed: {changes}. No generative language model.')
  return changes
 def analyze_code(self,source,language='python'):
  result=self.colony.dispatch({'kind':'code','source':source,'language':language})
  self.emit('log',message=f'Code parsed by original static {language} parser; executed=False')
  return result
 def analyze_rgb(self,points):
  result=self.colony.dispatch({'kind':'signal','rgb':points,'dt':.05})
  self.emit('log',message=f'Actual numeric Ripple processor received {len(points)} samples')
  return result
 def update(self,**params):
  with self.lock:
   new=copy.copy(self.config)
   for name,val in params.items():
    if name not in asdict(new):raise ValueError(f'Unknown runtime control: {name}')
    if name in ('camera_yaw','fps','frames') and self.state in ('running','paused'):
     raise ValueError(f'{name} can only be changed before start')
    setattr(new,name,val)
   new.validate();self.config=new
   self.storage.save_settings(asdict(self.config))
  self.emit('log',message=f'Applied parameters: {params}')
  return asdict(new)
 def start(self,config=None):
  with self.lock:
   if self.thread is not None and self.thread.is_alive():raise RuntimeError('Process already active; stop first')
   if config is not None:self.config=copy.copy(config)
   self.config.validate()
   self.pause_gate.set();self.stop_gate.clear();self.state='running'
   self.session_id=uuid.uuid4().hex
   self.current_dir=self.root/'sessions'/self.session_id
   self.current_dir.mkdir(parents=True,exist_ok=True)
   self.storage.start_session(self.session_id,self.current_dir,asdict(self.config))
   self.storage.save_settings(asdict(self.config))
   self.emit('state',value='running',id=self.session_id)
   self.thread=threading.Thread(target=self._run,daemon=True,name='kokoro-render-worker')
   self.thread.start()
  return self.session_id
 def pause(self):
  with self.lock:
   if self.state!='running':raise RuntimeError('Nothing running')
   self.state='paused';self.pause_gate.clear()
  self.emit('state',value='paused')
 def resume(self):
  with self.lock:
   if self.state!='paused':raise RuntimeError('Nothing paused')
   self.state='running';self.pause_gate.set()
  self.emit('state',value='running')
 def stop(self):
  with self.lock:
   if self.state not in ('paused','running'):raise RuntimeError('No active process')
   self.stop_gate.set();self.pause_gate.set();self.state='stopping'
  self.emit('state',value='stopping')
 def wait(self,timeout=90):
  thread=self.thread
  if thread is not None:thread.join(timeout)
  return thread is None or not thread.is_alive()
 def _run(self):
  started=time.perf_counter();traces=[];encoded=0;decoder_count=0;robot=None;ren=None
  assert self.current_dir and self.session_id
  out=self.current_dir;identifier=self.session_id
  cap=None;status='failed'
  try:
   with self.lock:c=copy.copy(self.config)
   ren=MarkerRenderer(size=(320,420),yaw=c.camera_yaw)
   observer=VisualFeedback(ren,gain=c.gain,neural_enabled=c.neural)
   robot=VirtualRobot();robot.set_targets(dict(zip(JOINTS,map(float,clip_to_limits(c.goal()+c.bias())))))
   video=cv2.VideoWriter(str(out/'recording.mp4'),cv2.VideoWriter_fourcc(*'mp4v'),c.fps,(320,420))
   if not video.isOpened():raise RuntimeError('OpenCV MP4 video codec unavailable')
   cap=video;steps=round(1/(DT*c.fps))
   if abs(DT*steps-1/c.fps)>1e-8:raise ValueError('Frame rate incompatible with motor simulation timebase')
   for k in range(c.frames):
    if self.stop_gate.is_set():break
    while not self.pause_gate.wait(.08):
     if self.stop_gate.is_set():break
    if self.stop_gate.is_set():break
    with self.lock:live=copy.copy(self.config)
    if c.fps!=live.fps:raise RuntimeError('Frame rate modified without restart')
    goal=live.goal();bias=live.bias()
    for _ in range(steps):
     if self.stop_gate.is_set():break
     robot.step(DT)
    if self.stop_gate.is_set():break
    q=np.array([robot.plants[j].x for j in JOINTS],dtype=float)
    rendered=ren.frame(q,k/c.fps,with_markers=True,post=False)
    rgb=np.asarray(rendered);bgr=cv2.cvtColor(rgb,cv2.COLOR_RGB2BGR)
    ok,png=cv2.imencode('.png',bgr)
    if not ok:raise RuntimeError('Cannot encode actual VTK frame')
    blob=png.tobytes();(out/f'frame_{k:03}.png').write_bytes(blob)
    observation=observer.measure(blob)
    observer.gain=live.gain;observer.neural_enabled=live.neural
    command,gate=observer.safe_command(goal,bias,observation)
    if live.feedback and gate['used_feedback']:robot.set_targets(command)
    elif not live.feedback:robot.set_targets(dict(zip(JOINTS,map(float,clip_to_limits(goal+bias)))))
    else:robot.set_targets(dict(zip(JOINTS,map(float,clip_to_limits(goal+bias)))))
    video.write(bgr);encoded+=1
    pose=observation['pose'];measured_error=gate.get('observed_rmse_rad') if pose['available'] else None
    record={'frame':k,'time_s':k/c.fps,'requested':goal.tolist(),'image_observation':pose,
      'rgb':observation['rgb'],'ripple_spikes':observation['spikes'],'ripple_stimulus':observation['ripple_stimulus'],
      'feedback_used':bool(live.feedback and gate['used_feedback']),'gain':live.gain,
      'measured_error_rad':measured_error,'png_sha256':hashlib.sha256(blob).hexdigest(),
      'source':'actual VTK RGB pixels; virtual joint plant'}
    traces.append(record)
    self.emit('frame',index=k,total=c.frames,preview=blob,observation=record,elapsed_s=time.perf_counter()-started)
   status='stopped' if self.stop_gate.is_set() else 'completed'
  except Exception as e:
   status='failed';self.emit('error',message=f'{type(e).__name__}: {e}',traceback=traceback.format_exc())
  finally:
   if cap is not None:cap.release()
   if encoded and ren is not None:
    try:
     read=inspect_recorded_video(out/'recording.mp4',ren.base.data['bones'],ren.cam,limit=encoded)
     (out/'encoded_video_observations.json').write_text(json.dumps(read,indent=2))
     decoder_count=read['frames_decoded']
    except Exception as e:self.emit('error',message=f'Encoded video re-analysis failed: {e}')
   available=[t['measured_error_rad'] for t in traces if t['measured_error_rad'] is not None]
   summary={'classification':'3D raster output and camera-derived pose estimates; virtual servos only',
     'status':status,'session_id':identifier,'frames_encoded':encoded,'frames_decoded':decoder_count,
     'pose_observations':len(available),'final_window_observed_rmse_rad':float(np.sqrt(np.mean(np.square(available[-8:])))) if available else None,
     'ripple_events':sum(t['ripple_spikes'] for t in traces),'elapsed_wall_s':time.perf_counter()-started,
     'renderer':'Original v2.0 VTK/EGL','trained_kokoro_core_connected':False}
   (out/'timeline.json').write_text(json.dumps(traces,indent=2,allow_nan=False))
   (out/'summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False))
   self.storage.finish_session(identifier,status,summary)
   with self.lock:
    self.last_result=summary;self.state=status
   self.emit('complete',summary=summary,directory=str(out),value=status)
