"""Native Tk/ttk Kokoro studio; controls call actual mathematical backend.
No browser, mocked endpoints, chat model, or decorative telemetry.
"""
from __future__ import annotations
import dataclasses,json,logging,os,pathlib,platform,queue,subprocess,sys,time,tkinter as tk, traceback
from tkinter import ttk, filedialog, messagebox
from PIL import Image,ImageTk
from io import BytesIO
from .backend import Config,Runner
from .storage import Storage

ROOT=pathlib.Path(__file__).resolve().parents[1]
class Studio(tk.Tk):
 def __init__(self,root=ROOT,autostart=False):
  super().__init__();self.root_dir=pathlib.Path(root)
  self.root_dir.mkdir(parents=True,exist_ok=True)
  (self.root_dir/'logs').mkdir(exist_ok=True)
  self.logger=logging.getLogger('kokoro.studio');self.logger.setLevel(logging.INFO)
  if not self.logger.handlers:
   h=logging.FileHandler(self.root_dir/'logs'/'application.log',encoding='utf-8');h.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'));self.logger.addHandler(h)
  self.storage=Storage(self.root_dir/'data')
  self.runner=Runner(self.root_dir,self.storage)
  prior=self.storage.load_settings()
  try:self.runner.config=Config(**prior).validate() if prior else Config()
  except (TypeError,ValueError) as e:self.logger.warning('Invalid previous configuration: %s',e)
  self.title('Kokoro • Ripple Desktop Studio — 3D Geometric Vision')
  self.geometry('1240x800');self.minsize(940,650)
  self.configure(bg='#0b1522')
  s=ttk.Style(self)
  if 'clam' in s.theme_names():s.theme_use('clam')
  s.configure('.',font=('Segoe UI',10));s.configure('TFrame',background='#112139')
  s.configure('TLabel',background='#112139',foreground='#e2ebf5')
  s.configure('TLabelframe',background='#112139',foreground='#d1e4f8')
  s.configure('TLabelframe.Label',background='#112139',foreground='#c4daed',font=('Segoe UI',10,'bold'))
  s.configure('TButton',padding=(10,6));s.configure('TCheckbutton',background='#112139',foreground='#e3edf6')
  s.configure('TNotebook',background='#0b1522',borderwidth=0)
  s.configure('TNotebook.Tab',padding=(14,9),background='#1a304b',foreground='#d7eaf5')
  s.map('TNotebook.Tab',background=[('selected','#2b5369')])
  s.configure('Treeview',background='#14273e',foreground='#eaf4f9',fieldbackground='#14273e',rowheight=25)
  s.configure('Treeview.Heading',background='#22435c',foreground='#ffffff')
  self.ongoing=[];self.active_image=None;self.frame_count=0;self.last_png=None
  self._restarting=False;self._closing=False
  self.vars={}
  for field in dataclasses.fields(Config):
   value=getattr(self.runner.config,field.name)
   cls=tk.BooleanVar if isinstance(value,bool) else tk.IntVar if isinstance(value,int) else tk.DoubleVar
   self.vars[field.name]=cls(self,value=value)
  self.instruction=tk.StringVar(self,value='raise right arm 40 degrees')
  self.status=tk.StringVar(self,value='Idle • virtual avatar; no trained Kokoro language model connected')
  self.live_detail=tk.StringVar(self,value='No frames recorded')
  self.result_var=tk.StringVar(self,value='No completed session')
  self.make_layout();self.refresh_sessions();self.refresh_hardware()
  self.protocol('WM_DELETE_WINDOW',self.close_request)
  self.after(80,self.poll)
  if autostart:self.after(350,self.start_job)
 def make_layout(self):
  title=tk.Frame(self,bg='#0b1522');title.pack(fill='x',padx=15,pady=(13,6))
  tk.Label(title,text='KOKORO  /  RIPPLE DESKTOP STUDIO',font=('Segoe UI',16,'bold'),bg='#0b1522',fg='#d5f5ff').pack(side='left')
  tk.Label(title,text='REAL 3D VIRTUAL CONTROL • RGB CAMERA • RIPPLE',font=('Segoe UI',9),bg='#0b1522',fg='#86a8c1').pack(side='right')
  ttk.Label(self,textvariable=self.status,background='#0b1522',foreground='#87d5c6').pack(fill='x',padx=16,pady=(2,8))
  self.tabs=ttk.Notebook(self);self.tabs.pack(fill='both',expand=True,padx=12,pady=5)
  self.make_operator();self.make_signal();self.make_code();self.make_sessions();self.make_diagnostics()
  footer=ttk.Label(self,text='OBSERVATION: rendered RGB pixels / mathematical pose estimates  •  ACTUATION: simulated joints  •  AI CORE: unavailable',background='#0b1522',foreground='#a5b9c9')
  footer.pack(fill='x',padx=15,pady=10)
 def make_operator(self):
  pane=ttk.Frame(self.tabs);self.tabs.add(pane,text='3D Operator')
  sidebar=ttk.Frame(pane,width=415);sidebar.pack(side='left',fill='y',padx=9,pady=10);sidebar.pack_propagate(False)
  self.control_scroll=tk.Canvas(sidebar,bg='#112139',highlightthickness=0)
  scrollbar=ttk.Scrollbar(sidebar,orient='vertical',command=self.control_scroll.yview)
  self.control_scroll.configure(yscrollcommand=scrollbar.set)
  scrollbar.pack(side='right',fill='y');self.control_scroll.pack(side='left',fill='both',expand=True)
  left=ttk.Frame(self.control_scroll);window_id=self.control_scroll.create_window((0,0),window=left,anchor='nw')
  left.bind('<Configure>',lambda e:self.control_scroll.configure(scrollregion=self.control_scroll.bbox('all')))
  self.control_scroll.bind('<Configure>',lambda e:self.control_scroll.itemconfigure(window_id,width=e.width))
  self.control_scroll.bind('<MouseWheel>',lambda e:self.control_scroll.yview_scroll(-int(e.delta/120),'units'))
  self.control_scroll.bind('<Button-4>',lambda e:self.control_scroll.yview_scroll(-1,'units'))
  self.control_scroll.bind('<Button-5>',lambda e:self.control_scroll.yview_scroll(1,'units'))
  right=ttk.Frame(pane);right.pack(side='left',fill='both',expand=True,padx=8,pady=10)
  fastbar=ttk.Frame(right);fastbar.pack(fill='x',pady=(0,6))
  for label,fn in [('Start',self.start_job),('Pause',self.pause_job),('Resume',self.resume_job),('Stop',self.stop_job),('Restart',self.restart_job),('Save state',self.save_state)]:
   ttk.Button(fastbar,text=label,command=fn).pack(side='left',fill='x',expand=True,padx=3)
  group=ttk.LabelFrame(left,text='Instructions → original language parser');group.pack(fill='x',pady=4)
  ttk.Entry(group,textvariable=self.instruction,width=48).pack(fill='x',padx=8,pady=7)
  ttk.Button(group,text='Apply supported instruction',command=self.apply_instruction).pack(fill='x',padx=8,pady=(0,7))
  ttk.Label(group,text='Examples: raise right arm 40 degrees  |  reset pose').pack(padx=8,pady=4)
  limits=ttk.LabelFrame(left,text='3D skeletal joint targets (radians)');limits.pack(fill='x',pady=6)
  for name,label,lo,hi in [('arm','Right arm',-.12,1.48),('forearm','Forearm',-.75,.5),('head','Head',-.35,.35)]:
   row=ttk.Frame(limits);row.pack(fill='x',padx=6,pady=4)
   ttk.Label(row,text=label,width=13).pack(side='left')
   ttk.Scale(row,from_=lo,to=hi,variable=self.vars[name],orient='horizontal').pack(side='left',fill='x',expand=True,padx=5)
   ttk.Entry(row,textvariable=self.vars[name],width=7).pack(side='right')
  ttk.Button(limits,text='Apply joint targets to active motor',command=self.apply_joint_targets).pack(fill='x',padx=8,pady=7)
  controls=ttk.LabelFrame(left,text='True motor / visual feedback controls');controls.pack(fill='x',pady=6)
  ttk.Checkbutton(controls,text='Camera-observed joint correction',variable=self.vars['feedback'],command=self.apply_live).pack(anchor='w',padx=10,pady=3)
  ttk.Checkbutton(controls,text='Optional Ripple optical modulation',variable=self.vars['neural'],command=self.apply_live).pack(anchor='w',padx=10,pady=3)
  g=ttk.Frame(controls);g.pack(fill='x',padx=8,pady=4)
  ttk.Label(g,text='Visual gain').pack(side='left')
  ttk.Scale(g,from_=0,to=1,variable=self.vars['gain'],orient='horizontal').pack(side='left',fill='x',expand=True,padx=8)
  ttk.Entry(g,textvariable=self.vars['gain'],width=7).pack(side='right')
  ttk.Button(controls,text='Apply live feedback gain',command=self.apply_live).pack(fill='x',padx=8,pady=6)
  session=ttk.LabelFrame(left,text='Recording settings • require restart');session.pack(fill='x',pady=6)
  for name,label,values in [('fps','Frame rate',[2,5,10]),('frames','Frames',[5,10,12,25,50,100])]:
   row=ttk.Frame(session);row.pack(fill='x',padx=8,pady=4)
   ttk.Label(row,text=label,width=16).pack(side='left')
   ttk.Combobox(row,textvariable=self.vars[name],values=values,width=11,state='readonly').pack(side='right')
  row=ttk.Frame(session);row.pack(fill='x',padx=8,pady=4)
  ttk.Label(row,text='Camera yaw (radians)').pack(side='left')
  ttk.Entry(row,textvariable=self.vars['camera_yaw'],width=11).pack(side='right')
  ttk.Button(session,text='Load saved project / configuration',command=self.load_project).pack(fill='x',padx=9,pady=6)
  preview=ttk.LabelFrame(right,text='ACTUAL VTK FRAME • decoded rendered pixels');preview.pack(fill='both',expand=True)
  center=ttk.Frame(preview);center.pack(fill='both',expand=True,padx=4,pady=4)
  self.preview=tk.Label(center,text='Press Start to render actual 3D geometry',font=('Segoe UI',11),bg='#091626',fg='#adcee0',compound='center',width=48,height=20)
  self.preview.pack(fill='both',expand=True,pady=4)
  ttk.Label(preview,textvariable=self.live_detail).pack(anchor='w',padx=9,pady=5)
  ttk.Label(right,text='Joint error from RGB camera estimates • radians (not simulator ground truth)').pack(anchor='w',pady=(6,1))
  self.chart=tk.Canvas(right,height=100,bg='#0a1c2d',highlightthickness=0)
  self.chart.pack(fill='x',padx=3,pady=5)
  ttk.Label(right,textvariable=self.result_var,wraplength=650).pack(anchor='w',padx=6,pady=6)
 def make_signal(self):
  tab=ttk.Frame(self.tabs);self.tabs.add(tab,text='Ripple & Genome')
  p=ttk.LabelFrame(tab,text='Original Ripple signal colony • measured numeric inputs');p.pack(fill='x',padx=18,pady=15)
  ttk.Label(p,text='Enter normalized RGB triplets, one per line: 0.7,0.2,0.1').pack(anchor='w',padx=12,pady=6)
  self.rgb_text=tk.Text(p,height=7,bg='#0b1e32',fg='#dceafa',insertbackground='white')
  self.rgb_text.pack(fill='x',padx=12);self.rgb_text.insert('1.0','0.1,0.2,0.0\n0.8,0.3,0.0\n0.8,0.3,0.0\n0.2,0.1,0.0')
  ttk.Button(p,text='Execute actual Ripple neuron',command=self.run_rgb).pack(anchor='w',padx=12,pady=10)
  self.rgb_result=tk.Text(tab,height=8,bg='#0b1e32',fg='#dceafa',state='disabled');self.rgb_result.pack(fill='x',padx=18,pady=5)
  t=ttk.LabelFrame(tab,text='Original v1.8 digital genome overseer (read-only inventory)');t.pack(fill='both',expand=True,padx=18,pady=10)
  ttk.Button(t,text='Refresh active specialist inventory',command=self.show_genomes).pack(anchor='w',padx=12,pady=10)
  self.genome_text=tk.Text(t,height=12,bg='#0b1e32',fg='#dceafa',state='disabled');self.genome_text.pack(fill='both',expand=True,padx=12,pady=(0,9))
 def make_code(self):
  tab=ttk.Frame(self.tabs);self.tabs.add(tab,text='Code Inspection')
  tt=ttk.LabelFrame(tab,text='Real static parser • no arbitrary program execution');tt.pack(fill='both',expand=True,padx=18,pady=14)
  bar=ttk.Frame(tt);bar.pack(fill='x',padx=10,pady=8)
  self.code_lang=tk.StringVar(self,value='python')
  ttk.Combobox(bar,textvariable=self.code_lang,values=['python','json'],width=12,state='readonly').pack(side='left')
  ttk.Button(bar,text='Inspect source',command=self.inspect_code).pack(side='left',padx=8)
  ttk.Button(bar,text='Open local code file',command=self.open_code).pack(side='left')
  self.code_source=tk.Text(tt,height=13,bg='#0b1e32',fg='#dceafa',insertbackground='white');self.code_source.pack(fill='both',expand=True,padx=12,pady=7)
  self.code_source.insert('1.0','def move(a):\n    return a + 1\n')
  self.code_output=tk.Text(tt,height=12,bg='#0b1e32',fg='#b2f0da',state='disabled');self.code_output.pack(fill='both',expand=True,padx=12,pady=(5,12))
 def make_sessions(self):
  tab=ttk.Frame(self.tabs);self.tabs.add(tab,text='Sessions & Files')
  toolbar=ttk.Frame(tab);toolbar.pack(fill='x',padx=14,pady=9)
  for name,fn in [('Refresh sessions',self.refresh_sessions),('Open selected folder',self.open_selected_folder),('Play selected MP4',self.open_selected_video),('Load selected settings',self.load_selected_settings),('Export settings JSON',self.export_project)]:
   ttk.Button(toolbar,text=name,command=fn).pack(side='left',padx=3)
  self.session_tree=ttk.Treeview(tab,columns=('date','status','frames','rmse'),show='headings',height=11)
  for col,wide in [('date',175),('status',105),('frames',95),('rmse',175)]:
   self.session_tree.heading(col,text=col.upper());self.session_tree.column(col,width=wide,anchor='center')
  self.session_tree.pack(fill='both',expand=True,padx=14,pady=8)
  self.session_tree.bind('<<TreeviewSelect>>',self.select_session)
  self.session_detail=tk.Text(tab,height=13,bg='#0b1e32',fg='#dceafa',state='disabled');self.session_detail.pack(fill='both',expand=True,padx=14,pady=9)
 def make_diagnostics(self):
  tab=ttk.Frame(self.tabs);self.tabs.add(tab,text='Diagnostics & Logs')
  actions=ttk.Frame(tab);actions.pack(fill='x',padx=14,pady=9)
  ttk.Button(actions,text='Inspect actual host',command=self.refresh_hardware).pack(side='left',padx=4)
  ttk.Button(actions,text='Read program log',command=self.read_logs).pack(side='left',padx=4)
  ttk.Button(actions,text='Open persistent data folder',command=lambda:self.open_path(self.root_dir/'data')).pack(side='left',padx=4)
  self.diag=tk.Text(tab,height=17,bg='#0b1e32',fg='#dceafa',state='disabled');self.diag.pack(fill='both',expand=True,padx=15,pady=10)
  self.log_box=tk.Text(tab,height=12,bg='#0b1e32',fg='#e6cfaa',state='disabled');self.log_box.pack(fill='both',expand=True,padx=15,pady=(4,12))
 def set_text(self,widget,txt):
  widget.configure(state='normal');widget.delete('1.0','end');widget.insert('end',txt);widget.configure(state='disabled')
 def log(self,message,severity='info'):
  getattr(self.logger,severity if severity in ('info','warning','error') else 'info')(message)
  self.log_box.configure(state='normal');self.log_box.insert('end',f'{time.strftime("%H:%M:%S")} {severity.upper()}: {message}\n');self.log_box.see('end')
  if int(float(self.log_box.index('end-1c').split('.')[0]))>400:self.log_box.delete('1.0','100.0')
  self.log_box.configure(state='disabled')
 def guard(self,fn,*args):
  try:return fn(*args)
  except Exception as e:
   self.status.set(f'Error: {e}');self.log(f'{type(e).__name__}: {e}','error')
   return None
 def gui_config(self):
  d={}
  for field in dataclasses.fields(Config):
   value=self.vars[field.name].get()
   if field.name=='frames' or field.name=='fps':value=int(value)
   d[field.name]=value
  return Config(**d).validate()
 def sync_from_config(self,c):
  for k,v in dataclasses.asdict(c).items():self.vars[k].set(v)
 def apply_instruction(self):
  def impl():
   changes=self.runner.command(self.instruction.get())
   for joint,value in changes.items():self.vars[{'arm_R':'arm','forearm_R':'forearm','head':'head'}[joint]].set(value)
   self.status.set(f'Original language specialist accepted: {changes}')
   self.log(f'Instruction: {self.instruction.get()} → {changes}')
  return self.guard(impl)
 def apply_joint_targets(self):
  def impl():
   cfg=self.gui_config();vals={n:getattr(cfg,n) for n in ('arm','forearm','head')}
   self.runner.update(**vals)
   self.status.set('Joint targets applied to active digital twin at next frame')
  return self.guard(impl)
 def apply_live(self):
  def impl():
   cfg=self.gui_config();keys=('arm','forearm','head','feedback','neural','gain')
   self.runner.update(**{k:getattr(cfg,k) for k in keys})
   self.status.set('Updated original feedback path; next frame will use new parameters')
  return self.guard(impl)
 def start_job(self):
  def impl():
   config=self.gui_config();self.runner.start(config)
   self.frame_count=0;self.ongoing=[];self.result_var.set('Rendering started...')
   self.status.set('Computing actual 3D frames on virtual motor plant')
   self.log('Started VTK + original virtual motor + RGB pose-estimation pipeline')
  return self.guard(impl)
 def pause_job(self):return self.guard(self.runner.pause)
 def resume_job(self):return self.guard(self.runner.resume)
 def stop_job(self):return self.guard(self.runner.stop)
 def restart_job(self):
  if self.runner.state in ('running','paused'):
   self._restarting=True;self.guard(self.runner.stop);self.status.set('Stopping and restarting after clean video finalization')
  elif self.runner.state=='stopping':self._restarting=True
  else:self.start_job()
 def save_state(self):
  def impl():
   config=self.gui_config();self.storage.save_settings(dataclasses.asdict(config))
   self.runner.update(**{k:v for k,v in dataclasses.asdict(config).items() if k not in ('fps','frames','camera_yaw')} if self.runner.state in ('running','paused') else dataclasses.asdict(config))
   self.status.set('Settings saved to persistent SQLite storage; current execution remains intact')
   self.log('Saved verified GUI parameter state')
  return self.guard(impl)
 def export_project(self):
  def impl():
   cfg=self.gui_config();path=filedialog.asksaveasfilename(title='Save Kokoro config',initialfile='kokoro_project.json',defaultextension='.json',filetypes=[('JSON','*.json')]);
   if path:pathlib.Path(path).write_text(json.dumps({'schema':'kokoro-desktop-project/1','config':dataclasses.asdict(cfg)},indent=2),encoding='utf-8')
  return self.guard(impl)
 def load_project(self):
  def impl():
   file=filedialog.askopenfilename(title='Load Kokoro project',filetypes=[('JSON','*.json')]);
   if not file:return
   data=json.loads(pathlib.Path(file).read_text(encoding='utf-8'))
   if data.get('schema')!='kokoro-desktop-project/1':raise ValueError('Unrecognized config file schema')
   cfg=Config(**data['config']).validate()
   if self.runner.state in ('running','paused','stopping'):raise RuntimeError('Stop rendering before loading a different project')
   self.runner.update(**dataclasses.asdict(cfg));self.sync_from_config(cfg)
   self.log(f'Loaded validated project settings from {file}')
  return self.guard(impl)
 def run_rgb(self):
  def impl():
   raw=self.rgb_text.get('1.0','end-1c').strip().splitlines()
   if not 1<=len(raw)<=1024:raise ValueError('Provide 1..1024 RGB samples')
   rows=[]
   for line in raw:
    row=[float(v.strip()) for v in line.split(',')]
    if len(row)!=3:raise ValueError('Each line must have 3 channels')
    rows.append(row)
   result=self.runner.analyze_rgb(rows)
   self.set_text(self.rgb_result,json.dumps(result,indent=2));self.log('Calculated event count from supplied RGB samples')
  return self.guard(impl)
 def show_genomes(self):
  return self.guard(lambda:self.set_text(self.genome_text,json.dumps(self.runner.colony.inventory(),indent=2)))
 def inspect_code(self):
  def impl():
   source=self.code_source.get('1.0','end-1c');reply=self.runner.analyze_code(source,self.code_lang.get())
   self.set_text(self.code_output,json.dumps(reply,indent=2));self.log('Executed original static code-inspection parser')
  return self.guard(impl)
 def open_code(self):
  def impl():
   filename=filedialog.askopenfilename(filetypes=[('Text / source','*.py *.json *.txt'),('All files','*.*')]);
   if not filename:return
   p=pathlib.Path(filename)
   if p.stat().st_size>48000:raise ValueError('Code inspection limit is 48 KB')
   content=p.read_text(encoding='utf-8');self.code_source.delete('1.0','end');self.code_source.insert('1.0',content)
   self.code_lang.set('json' if p.suffix.lower()=='.json' else 'python')
  return self.guard(impl)
 def poll(self):
  if not self.winfo_exists():return
  for _ in range(30):
   try:event=self.runner.events.get_nowait()
   except queue.Empty:break
   kind=event['event']
   if kind=='frame':self.update_frame(event)
   elif kind=='state':self.status.set(f"Renderer status: {event['value']}");self.log('State '+event['value'])
   elif kind=='log':self.log(event['message'])
   elif kind=='error':self.log(event['message'],'error');self.status.set(event['message'])
   elif kind=='complete':
    s=event['summary'];self.status.set(f"{s['status']}: {s['frames_encoded']} frames; {s['frames_decoded']} video-decoded")
    rmse=s['final_window_observed_rmse_rad']
    error_text=f'{rmse:.5f}' if rmse is not None else 'unavailable'
    self.result_var.set(f"Observed RGB joint error: {error_text} rad RMS • Ripple events: {s['ripple_events']} • {s['elapsed_wall_s']:.2f}s wall")
    self.log(f"Finished {s['session_id']} status={s['status']} frames={s['frames_encoded']}")
    self.refresh_sessions()
    if self._restarting:
     self._restarting=False;self.after(250,self.start_job)
  if self._closing:
   if self.runner.wait(.005):self.destroy();return
  self.after(80,self.poll)
 def update_frame(self,event):
  self.last_png=event['preview'];self.frame_count=event['index']+1
  img=Image.open(BytesIO(self.last_png)).convert('RGB')
  available_w=max(180,self.preview.winfo_width()-18)
  available_h=max(160,self.preview.winfo_height()-18)
  img.thumbnail((available_w,available_h),Image.Resampling.LANCZOS)
  self.active_image=ImageTk.PhotoImage(img,master=self)
  self.preview.configure(image=self.active_image,text='')
  obs=event['observation'];pose=obs['image_observation']
  self.live_detail.set(f"Frame {self.frame_count}/{event['total']} • observed pose: {'yes' if pose['available'] else 'unavailable'} • Ripple events: {obs['ripple_spikes']} • wall {event['elapsed_s']:.2f}s")
  self.ongoing.append(obs['measured_error_rad']);self.paint_chart()
 def paint_chart(self):
  c=self.chart;c.delete('all');w=max(100,c.winfo_width());h=max(60,c.winfo_height());margin=15
  c.create_line(margin,h-margin,w-margin,h-margin,fill='#4c6782')
  c.create_text(28,12,text='0.5',fill='#8ca7bf',font=('Segoe UI',8))
  values=self.ongoing;pts=[];scale=.5
  for i,y in enumerate(values):
   if y is not None:pts.extend((margin+(w-2*margin)*i/max(1,len(values)-1),h-margin-(h-2*margin)*min(1,y/scale)))
  if len(pts)>=4:c.create_line(*pts,fill='#75d2bb',width=2)
 def refresh_sessions(self):
  if not hasattr(self,'session_tree'):return
  ids=set(self.session_tree.get_children());entries=self.storage.sessions()
  for key in ids:self.session_tree.delete(key)
  for r in entries:
   d=json.loads(r['summary']) if r['summary'] else {}
   rmse=d.get('final_window_observed_rmse_rad')
   self.session_tree.insert('','end',iid=r['id'],values=(r['started'],r['status'],d.get('frames_encoded','—'),f'{rmse:.5f}' if rmse is not None else '—'))
 def select_session(self,_=None):
  keys=self.session_tree.selection()
  if not keys:return
  r=self.storage.get(keys[0]);self.set_text(self.session_detail,json.dumps({k:(json.loads(v) if k in ('config','summary') and v else v) for k,v in r.items()},indent=2))
 def selected_record(self):
  keys=self.session_tree.selection()
  if not keys:raise ValueError('Select a saved session first')
  record=self.storage.get(keys[0])
  if record is None:raise ValueError('Selected session is missing')
  return record
 def open_path(self,path):
  path=pathlib.Path(path).resolve()
  if not path.exists():raise ValueError(f'Path does not exist: {path}')
  if sys.platform=='win32':os.startfile(str(path))
  elif sys.platform=='darwin':subprocess.Popen(['open',str(path)])
  else:subprocess.Popen(['xdg-open',str(path)])
 def open_selected_folder(self):return self.guard(lambda:self.open_path(self.selected_record()['directory']))
 def open_selected_video(self):return self.guard(lambda:self.open_path(pathlib.Path(self.selected_record()['directory'])/'recording.mp4'))
 def load_selected_settings(self):
  def impl():
   if self.runner.state in ('running','paused','stopping'):raise RuntimeError('Stop before loading session configuration')
   r=self.selected_record();cfg=Config(**json.loads(r['config'])).validate()
   self.runner.update(**dataclasses.asdict(cfg));self.sync_from_config(cfg)
   self.status.set('Restored selected historical session configuration (not internal neuron state)')
  return self.guard(impl)
 def refresh_hardware(self):
  import importlib.util
  info={'actual_execution_host':platform.platform(),'python':sys.version.split()[0],
    'cpu_logical_count':os.cpu_count(),'cpu_name':platform.processor() or 'unavailable',
    'available_disk_gb':round(os.statvfs(self.root_dir).f_bavail*os.statvfs(self.root_dir).f_frsize/1e9,2) if hasattr(os,'statvfs') else 'not measured',
    'renderer':'Original VTK raster (does not assert GPU acceleration)',
    'python_tk':str(self.tk.call('info','patchlevel')),
    'OpenCV':__import__('cv2').__version__,'VTK':__import__('vtk').vtkVersion.GetVTKVersion(),
    'GPU':'not measured; no GPU acceleration claim',
    'training_checkpoint':'unavailable; no LLM model connected',
    'source':'This computer only. Dell model cannot be determined without operating on Dell computer.'}
  if importlib.util.find_spec('psutil'):
   import psutil
   info.update({'RAM_total_gb':round(psutil.virtual_memory().total/1e9,2),'RAM_available_gb':round(psutil.virtual_memory().available/1e9,2),
               'CPU_usage_sample_percent':psutil.cpu_percent(interval=.08)})
  if hasattr(self,'diag'):self.set_text(self.diag,json.dumps(info,indent=2))
 def read_logs(self):
  def impl():
   p=self.root_dir/'logs'/'application.log';self.set_text(self.log_box,p.read_text(encoding='utf-8')[-30000:] if p.exists() else 'No log created')
  return self.guard(impl)
 def close_request(self):
  self._closing=True;self.status.set('Closing safely after background worker stops')
  if self.runner.state in ('paused','running'):self.runner.stop()
  if self.runner.thread is None or not self.runner.thread.is_alive():self.destroy()

def main():
 app=Studio();app.mainloop()
if __name__=='__main__':main()
