@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\pythonw.exe" (
  echo First launch: preparing Kokoro Desktop Studio Python environment...
  py -3 -m venv .venv
  if errorlevel 1 (echo Python 3.10+ with Tkinter required & pause & exit /b 1)
  ".venv\Scripts\python.exe" -m pip install --upgrade pip
  ".venv\Scripts\python.exe" -m pip install -r requirements.txt
  if errorlevel 1 (echo Installation failed. See error above. & pause & exit /b 1)
)
start "Kokoro Ripple Desktop Studio" ".venv\Scripts\pythonw.exe" "launcher.pyw"
endlocal
