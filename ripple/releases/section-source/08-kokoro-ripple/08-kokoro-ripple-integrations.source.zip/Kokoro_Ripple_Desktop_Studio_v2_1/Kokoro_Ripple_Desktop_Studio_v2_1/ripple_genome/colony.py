"""Functional on-demand specialist copies; overseer enforces exact contracts.

This is parallelizable source inspection and stateful numerical processing,
not independent trained intelligences or a claim of semantic understanding.
"""
from __future__ import annotations
import hashlib, json, pathlib, concurrent.futures, threading
from .genetics import DEFAULT_MOTOR,DEFAULT_SIGNAL,DEFAULT_LANGUAGE,DEFAULT_CODE,Genome
from .robotics import VirtualRobot, run_trajectory
from .grammar import analyze_code,parse_command
BASE=pathlib.Path(__file__).resolve().parents[1]

class Specialist:
 def __init__(self,genome:Genome,instance:int):self.genome=genome;self.instance=instance;self.executions=0;self.lock=threading.Lock()
 def handle(self,task,robot=None):
  kind=task.get('kind')
  if kind!=self.genome.role:raise ValueError('specialist mismatch')
  with self.lock:self.executions+=1
  if kind=='code':
   gate=self.genome.express();maxbytes=int(gate['code_max_kb']*1024)
   return analyze_code(task['source'],task.get('language','python'),maxbytes)
  if kind=='language':return {'joint_targets':parse_command(task['text'],self.genome)}
  if kind=='signal':
   from .robotics import GeneMotor
   data=task['rgb'];dt=task.get('dt',.02)
   if not isinstance(data,list) or len(data)>1024:raise ValueError('bounded samples required')
   from .genetics import DEFAULT_MOTOR
   # Locked LIF used directly, with the signal genome's conditioning actually expressed.
   import sys
   sys.path.insert(0,str(BASE/'upstream'))
   from ripple_core_v0_5 import RippleNeuron
   g=self.genome.express();neu=RippleNeuron(target=g['event_target']);n=0;observed=0
   # sensor_density determines observation coverage (not fabricated signal values).
   stride=max(1,round(1/g['sensor_density']))
   for i,x in enumerate(data):
    if not isinstance(x,(list,tuple)) or len(x)!=3 or any(type(y) not in (int,float) or not 0<=y<=1 for y in x):
     raise ValueError('normalized RGB sensor channels required')
    if i%stride!=0:continue
    y=[min(1,x[c]*g[f'gain_{"rgb"[c]}']) for c in range(3)]
    n+=neu.step(y,dt*stride)['count'];observed+=1
   return {'event_count':n,'threshold':neu.theta,'samples':len(data),'observed_samples':observed,'window_length':round(g['signal_window']),'note':'numerical input, not optical sensing'}
  if kind=='motor':
   if robot is None:raise ValueError('robot twin missing')
   return run_trajectory(self.genome,task.get('joint','arm_R'),duration=task.get('duration',5.2))
  raise ValueError('unknown task')

class Overseer:
 def __init__(self,genomes=None,max_workers=8):
  if type(max_workers)!=int or not 1<=max_workers<=16:raise ValueError('bounded OS worker cap')
  self.g=genomes or {'motor':DEFAULT_MOTOR,'signal':DEFAULT_SIGNAL,'code':DEFAULT_CODE,'language':DEFAULT_LANGUAGE}
  if set(self.g)!=set(['motor','signal','code','language']) or any(genome.role!=role for role,genome in self.g.items()):
   raise ValueError('typed seedbank required')
  self.max_workers=max_workers;self.instances={role:[] for role in self.g}
  self.lock=threading.Lock()
  self.robot=VirtualRobot({j:self.g['motor'] for j in ('arm_R','forearm_R','head')})
  self.log=[]
 def allocate(self,role,demand=1):
  if role not in self.g or type(demand)!=int or demand<1 or demand>10000:raise ValueError('invalid workload')
  with self.lock:
   instances=self.instances[role];permitted=min(self.g[role].capacity,self.max_workers)
   target=min(permitted,demand)
   while len(instances)<target:instances.append(Specialist(self.g[role],len(instances)))
   return instances[:target]
 def dispatch(self,task):
  if not isinstance(task,dict) or set(task)-{'kind','source','language','text','rgb','dt','joint','duration'}:raise ValueError('unsupported or oversized task schema')
  kind=task.get('kind');worker=self.allocate(kind,1)[0]
  reply=worker.handle(task,self.robot)
  self.log.append({'kind':kind,'marker':worker.genome.marker,'instance':worker.instance,'status':'complete'})
  return reply
 def batch(self,tasks):
  if not isinstance(tasks,list) or not 1<=len(tasks)<=40 or any(not isinstance(t,dict) for t in tasks):raise ValueError('bounded batch')
  if any(t.get('kind')=='motor' for t in tasks):raise ValueError('stateful motors run serially and explicitly')
  by_role={r:sum(t.get('kind')==r for t in tasks) for r in self.g}
  workers={r:self.allocate(r,n) for r,n in by_role.items() if n}
  used={r:0 for r in workers}
  # Dedicated instance per worker lane; clones differ by state, not by underlying role weights.
  def work(pair):
   i,task=pair;role=task['kind'];ls=workers[role]
   return ls[i%len(ls)].handle(task,self.robot)
  with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers) as pool:
   result=list(pool.map(work,enumerate(tasks)))
  return result
 def promote(self,role,new_genome:Genome,approved:bool=False):
  if not approved:raise PermissionError('only validated, explicitly authorized promotion')
  if role not in self.g or new_genome.role!=role:raise ValueError('typed genome mismatch')
  if role=='motor' and self.robot.tick>0:raise RuntimeError('cannot hot-swap an active motor controller')
  self.g[role]=new_genome;self.instances[role]=[]
  if role=='motor':self.robot=VirtualRobot({j:new_genome for j in ('arm_R','forearm_R','head')})
 def inventory(self):return {'genomes':{r:g.record() for r,g in self.g.items()},
                            'clones':{r:len(v) for r,v in self.instances.items()},
                            'recent_tasks':self.log[-10:],'classification':'typed numerical and parser workers; not generative language models'}
