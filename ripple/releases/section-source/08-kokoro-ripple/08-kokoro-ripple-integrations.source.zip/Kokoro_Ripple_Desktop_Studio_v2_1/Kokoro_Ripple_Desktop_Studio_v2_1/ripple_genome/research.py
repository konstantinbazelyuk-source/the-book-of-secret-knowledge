"""Human genomic public reference is a citable data fixture, not an AI genome.

No biological feature is interpreted as a motor-control instruction. The
local fixture is an exact 101 bp reference sequence from Ensembl REST for a
GRCh38 human chromosome-X interval. Never equate its variant positions to
neural intelligence or human traits.
"""
import json, hashlib, math, pathlib, collections
BASE=pathlib.Path(__file__).resolve().parents[1]

def inspect_reference(path=None):
 p=pathlib.Path(path) if path else BASE/'data/human_reference.json'
 data=json.loads(p.read_text())
 seq=data['sequence']
 if not 1<=len(seq)<=100000 or not set(seq)<=set('ACGTN'):raise ValueError('invalid public nucleotide fixture')
 if hashlib.sha256(seq.encode()).hexdigest()!=data['sequence_sha256'] or len(seq)!=data['expected_length']:
  raise ValueError('public sequence integrity mismatch')
 counts=dict(collections.Counter(seq))
 bases=[n for n in seq if n in 'ACGT']
 gc=(bases.count('G')+bases.count('C'))/len(bases) if bases else None
 pbase=[bases.count(k)/len(bases) for k in 'ACGT'] if bases else []
 entropy=-sum(a*math.log2(a) for a in pbase if a>0)
 return {'accession':data['accession'],'source_url':data['source_url'],'length':len(seq),
         'gc_fraction':gc,'base_entropy_bits':entropy,'counts':counts,'sha256':data['sequence_sha256'],
         'classification':'observed public genomic reference sequence; NOT a controller genome'}
