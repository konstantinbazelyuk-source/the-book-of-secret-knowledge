"""Typed, bounded *digital* genomes (not biological genes or DNA function predictions).

A base-4 triplet stores six bits of parameter data. A three-letter promoter
selects a permitted specialist class. All mutations create independent immutable
objects; schema and application-level hard safety limits cannot be mutated.
"""
from __future__ import annotations
from dataclasses import dataclass
from hashlib import sha256
from typing import Mapping
import json, math, random

BASES='ACGT'
ROLE={'A':'signal','C':'language','G':'code','T':'motor'}
CAPACITY={'A':1,'C':2,'G':3,'T':4}
POLICY={'A':'normal','C':'low_latency','G':'conservative','T':'accuracy'}
# All codons affect a permitted runtime parameter or an explicit policy.
LOCI={
 'kp':(3.,20.),'kd':(.35,7.),'pulse_damp':(0.,3.),
 'gain_r':(.45,1.45),'gain_g':(.45,1.45),'gain_b':(.45,1.45),
 'event_target':(.45,2.4),'slew':(8.,45.),
 'risk':(.01,.9),'gate':(.25,.92),
 'feedforward':(0.,1.2),'signal_window':(3.,16.),
 'code_max_kb':(2.,48.),'language_gate':(.3,.95),
 'smoothing':(.0,.5), 'sensor_density':(.1,1.),
}
GENOME_LENGTH=3*(1+len(LOCI))

def triplet_int(s):
 if len(s)!=3 or any(c not in BASES for c in s): raise ValueError('invalid digital codon')
 return BASES.index(s[0])*16+BASES.index(s[1])*4+BASES.index(s[2])

def int_triplet(n):
 if type(n) is not int or not 0<=n<=63: raise ValueError('codon integer out of range')
 return ''.join(BASES[i] for i in [n//16,(n//4)%4,n%4])

def phenotype_hash(dna):return sha256(dna.encode('ascii')).hexdigest()

@dataclass(frozen=True)
class Genome:
 dna:str
 generation:int=0
 parent:str|None=None
 def __post_init__(self):
  if len(self.dna)!=GENOME_LENGTH or any(c not in BASES for c in self.dna): raise ValueError('malformed DNA-like digital code')
  if type(self.generation) is not int or self.generation<0 or self.generation>1000000:raise ValueError('invalid generation')
  if self.parent is not None and (len(self.parent)!=64 or any(c not in '0123456789abcdef' for c in self.parent)):raise ValueError('bad parent hash')
 @property
 def marker(self):return phenotype_hash(self.dna)
 @property
 def role(self):return ROLE[self.dna[0]]
 @property
 def capacity(self):return CAPACITY[self.dna[1]]
 @property
 def policy(self):return POLICY[self.dna[2]]
 def express(self):
  out={'role':self.role,'capacity':self.capacity,'policy':self.policy}
  for i,(name,(lo,hi)) in enumerate(LOCI.items()):
   code=triplet_int(self.dna[3+i*3:6+i*3])
   out[name]=round(lo+(hi-lo)*code/63,9)
  return out
 def mutate(self,rng:random.Random,role_locked=True):
  positions=range(1 if role_locked else 0,GENOME_LENGTH)
  i=rng.choice(list(positions));old=self.dna[i]
  base=rng.choice([x for x in BASES if x!=old]);new=self.dna[:i]+base+self.dna[i+1:]
  return Genome(new,self.generation+1,self.marker)
 def record(self):return {'schema':'ripple-digital-genome/1','dna':self.dna,'generation':self.generation,'parent':self.parent,'sha256':self.marker,'role':self.role}
 @staticmethod
 def from_record(r):
  if not isinstance(r,dict) or r.get('schema')!='ripple-digital-genome/1':raise ValueError('unapproved genome schema')
  x=Genome(r['dna'],r['generation'],r.get('parent'))
  if x.marker!=r.get('sha256') or x.role!=r.get('role'):raise ValueError('genome integrity mismatch')
  return x

def encode(role='motor',capacity=2,policy='conservative',**traits):
 r=next((k for k,v in ROLE.items() if v==role),None)
 c=next((k for k,v in CAPACITY.items() if v==capacity),None)
 p=next((k for k,v in POLICY.items() if v==policy),None)
 if r is None or c is None or p is None:raise ValueError('invalid regulatory promoter')
 if set(traits)-set(LOCI):raise ValueError('unknown genes')
 payload=r+c+p
 for name,(lo,hi) in LOCI.items():
  v=traits.get(name,(lo+hi)/2)
  if type(v) not in (float,int) or not math.isfinite(v) or not lo<=v<=hi:raise ValueError(f'gene {name} outside bounds')
  payload+=int_triplet(round(63*(v-lo)/(hi-lo)))
 return Genome(payload)

DEFAULT_MOTOR=encode('motor',capacity=3,policy='conservative',kp=12.,kd=3.,pulse_damp=.6,feedforward=.2,risk=.24,
                     gate=.65,signal_window=7.,event_target=1.,slew=40.,smoothing=.05)
DEFAULT_CODE=encode('code',capacity=2,policy='accuracy',code_max_kb=32.,gate=.7)
DEFAULT_LANGUAGE=encode('language',capacity=2,policy='conservative',language_gate=.8)
DEFAULT_SIGNAL=encode('signal',capacity=4,policy='normal',sensor_density=.65)
