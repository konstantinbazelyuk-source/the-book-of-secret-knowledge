"""Bounded, executable static code examination and literal language-to-pose commands.

These tools are NOT a language model and do not run arbitrary submitted source.
"""
from __future__ import annotations
import ast, json, re, math
from .genetics import Genome
from .robotics import JOINT_LIMITS

def analyze_code(source,language='python',max_bytes=48000):
 if type(source) is not str or len(source.encode('utf-8'))>max_bytes:raise ValueError('source too large')
 if language=='python':
  try:tree=ast.parse(source)
  except SyntaxError as e:return {'syntax':'invalid','language':'python','line':e.lineno,'message':e.msg,'executed':False}
  counts={'functions':0,'classes':0,'imports':0,'calls':0,'loops':0}
  functions=[];modules=[]
  for n in ast.walk(tree):
   if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):
    counts['functions']+=1;functions.append(n.name)
   if isinstance(n,ast.ClassDef):counts['classes']+=1
   if isinstance(n,(ast.Import,ast.ImportFrom)):
    counts['imports']+=1
    if isinstance(n,ast.Import):modules.extend(alias.name for alias in n.names)
    elif n.module:modules.append(n.module)
   if isinstance(n,ast.Call):counts['calls']+=1
   if isinstance(n,(ast.For,ast.While,ast.AsyncFor)):counts['loops']+=1
  return {'syntax':'valid','language':'python','summary':counts,'functions':functions[:40],
          'imports':modules[:40],'executed':False,'interpretation':'AST structure only; no correctness or semantics proof'}
 if language=='json':
  try:item=json.loads(source)
  except json.JSONDecodeError as e:return {'syntax':'invalid','language':'json','line':e.lineno,'message':e.msg,'executed':False}
  return {'syntax':'valid','language':'json','top_level_type':type(item).__name__,
          'keys':list(item)[:40] if isinstance(item,dict) else [],'executed':False}
 return {'syntax':'unsupported','language':language,'executed':False,'reason':'only Python AST and JSON parser are supported'}

RE_ARM=re.compile(r'^\s*(raise|lower|set)\s+(right arm|right forearm|head)\s+(?:to\s+)?(-?\d+(?:\.\d+)?)\s+degrees\s*[.!]?\s*$',re.I)
RE_HEAD=re.compile(r'^\s*turn\s+head\s+(left|right)\s+(\d+(?:\.\d+)?)\s+degrees\s*[.!]?\s*$',re.I)

def parse_command(text,genome:Genome):
 if genome.role!='language':raise ValueError('language-specialist genome required')
 if type(text) is not str or len(text)>240:raise ValueError('invalid language command length')
 if text.strip().lower() in {'reset pose','neutral pose'}:return {j:0. for j in JOINT_LIMITS}
 m=RE_ARM.fullmatch(text)
 if m:
  verb,body,angle=m.groups();joint={'right arm':'arm_R','right forearm':'forearm_R','head':'head'}[body.lower()]
  deg=float(angle)
  if not math.isfinite(deg):raise ValueError('invalid degrees')
  rad=math.radians(deg)
  if verb.lower()=='lower':rad=-abs(rad)
  if verb.lower()=='raise':rad=abs(rad)
 elif (m:=RE_HEAD.fullmatch(text)):
  side,deg=m.groups();joint='head';rad=math.radians(float(deg))*(1 if side.lower()=='left' else -1)
 else:raise ValueError('unsupported instruction (bounded literal grammar only)')
 lo,hi=JOINT_LIMITS[joint]
 # Language safety margin is an actual, genome-controlled restriction, never a limit expansion.
 allowed=genome.express()['language_gate']
 lo,hi=(lo*allowed if lo<0 else lo,hi*allowed if hi>0 else hi)
 if not lo<=rad<=hi:raise ValueError('spoken target exceeds safe avatar joint range')
 return {joint:rad}
