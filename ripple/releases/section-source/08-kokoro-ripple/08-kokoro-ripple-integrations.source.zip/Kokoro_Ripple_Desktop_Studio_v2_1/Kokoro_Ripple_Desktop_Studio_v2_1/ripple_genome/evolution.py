"""Finite multi-plant fitness-gated evolution; no mutation of hard safety cage.

Training conditions determine candidate ranks; validation gates promotion.
Reserved holdout conditions are scored ONCE after selection, never used to tune.
"""
from __future__ import annotations
import random,math,json
from .genetics import Genome,DEFAULT_MOTOR
from .robotics import run_trajectory,CONTROL_JOINTS

TRAIN=({'gain':.8,'damping':2.1},{'gain':1.0,'damping':2.5},{'gain':1.15,'damping':2.9})
DEVELOPMENT=({'gain':.9,'damping':2.35},{'gain':1.08,'damping':2.8})
HELD_OUT=({'gain':.67,'damping':3.1},{'gain':1.28,'damping':1.9})

def score(genome:Genome,joint:str,plants):
 res=[run_trajectory(genome,joint,p) for p in plants]
 return {'fitness':sum(r['fitness'] for r in res)/len(res),
         'rmse':sum(r['rmse'] for r in res)/len(res),
         'events':sum(r['events'] for r in res),
         'limit_hits':sum(r['hits'] for r in res)}

def evolve(joint='arm_R',seed=19,generations=6,children=12,start:Genome=DEFAULT_MOTOR):
 if joint not in CONTROL_JOINTS:raise ValueError('unknown joint')
 if type(seed)!=int or not 1<=generations<=30 or not 1<=children<=40:raise ValueError('bounded evolution only')
 rng=random.Random(seed);champ=start;tr=score(start,joint,TRAIN);dv=score(start,joint,DEVELOPMENT)
 origin={'train':tr,'development':dv,'marker':start.marker};ledger=[]
 for generation in range(generations):
  pool=[]
  for _ in range(children):
   candidate=champ.mutate(rng,role_locked=True)
   if candidate.marker==champ.marker:continue
   candidate_tr=score(candidate,joint,TRAIN)
   pool.append((candidate_tr['fitness'],candidate,candidate_tr))
  pool.sort(key=lambda x:(x[0],x[1].marker))
  improved=False
  for candidate_score,candidate,candidate_tr in pool:
   if candidate_score>=tr['fitness']-1e-7:break
   new_dev=score(candidate,joint,DEVELOPMENT)
   if new_dev['fitness']<=dv['fitness']*1.01 and new_dev['limit_hits']==0:
    ledger.append({'generation':generation+1,'accepted':True,'mutation':candidate.marker,'parent':candidate.parent,
                   'train_fitness':candidate_tr['fitness'],'dev_fitness':new_dev['fitness'],
                   'expression':candidate.express()})
    champ=candidate;tr=candidate_tr;dv=new_dev;improved=True;break
  if not improved:
   ledger.append({'generation':generation+1,'accepted':False,'candidates_evaluated':len(pool)})
 # Critical: heldout result is computed only after all genome choices have terminated.
 final_holdout=score(champ,joint,HELD_OUT);start_holdout=score(start,joint,HELD_OUT)
 return {'schema':'ripple-genetic-robotics-study/1','joint':joint,'seed':seed,
         'candidates_evaluated':generations*children,
         'original_genome':start.record(),'selected_genome':champ.record(),
         'accepted_mutations':sum(int(z['accepted']) for z in ledger),
         'train_before':origin['train'],'train_selected':tr,
         'validation_before':origin['development'],'validation_selected':dv,
         'holdout_original':start_holdout,'holdout_selected':final_holdout,
         'holdout_improved':final_holdout['fitness']<start_holdout['fitness'],
         'ledger':ledger,
         'limitations':'simulated virtual joint plants only; holdout not used for selection; no hardware'}
