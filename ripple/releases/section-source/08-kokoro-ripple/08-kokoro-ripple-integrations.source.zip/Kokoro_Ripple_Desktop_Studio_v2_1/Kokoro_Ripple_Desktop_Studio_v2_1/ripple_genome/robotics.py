"""Digital avatar joint controller and virtual actuator. Absolutely no hardware output.

The *locked* Ripple v0.1 LIF operates on bounded task measurements and its
emitted event changes the actuator command: it is not merely decorative. The
unmodifiable safety cage is deliberately separate from mutable genes.
"""
from __future__ import annotations
from dataclasses import dataclass
import sys,math, pathlib
from .genetics import Genome
BASE=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'upstream'))
from ripple_core_v0_5 import RippleNeuron  # unchanged original numerical core
from motor_neuron_v07 import JOINT_LIMITS, SPEED_LIMITS, ACCEL_LIMITS, VirtualJointPlant, target, DT

CONTROL_JOINTS=('arm_R','forearm_R','head')
HARD_MAX_COMMAND=5.0  # simulated torque-like unit, not physical N.m
HARD_MAX_SLEW=45.0

def clip(x,lo,hi):return max(lo,min(hi,x))
def checked(x):
 if type(x) not in (float,int) or not math.isfinite(x):raise ValueError('finite numeric measurement required')
 return float(x)

@dataclass
class Record:
 t:float;ref:float;angle:float;vel:float;command:float;spikes:int;threshold:float

class GeneMotor:
 def __init__(self,genome:Genome,joint='arm_R',enable_ripple=True):
  if genome.role!='motor' or joint not in CONTROL_JOINTS:raise ValueError('motor genotype and approved joint required')
  self.g=genome.express();self.joint=joint;self.ripple=RippleNeuron(target=self.g["event_target"]);self.enable=enable_ripple
  self.old_target=0.;self.old_command=0.;self.old_vel=0.;self.event_total=0;self.filtered_target=0.
 def step(self,t,angle,vel,setpoint,dt=DT):
  t=checked(t);angle=checked(angle);vel=checked(vel);setpoint=checked(setpoint);dt=checked(dt)
  if not .001<=dt<=.05:raise ValueError('invalid sample duration')
  lo,hi=JOINT_LIMITS[self.joint]
  if not lo-1e-9<=angle<=hi+1e-9 or not lo<=setpoint<=hi:raise ValueError('unsafe joint position or target')
  speed=SPEED_LIMITS[self.joint]
  if abs(vel)>speed+1e-6:raise ValueError('unsafe measured velocity')
  self.filtered_target+=(1-self.g["smoothing"])*(setpoint-self.filtered_target)
  filtered=self.filtered_target
  e=filtered-angle
  vref=clip((filtered-self.old_target)/dt,-speed,speed)
  span=hi-lo
  headroom=clip(min(angle-lo,hi-angle)/(span/2),0,1)
  # Gene-weighted sensory conditioning; original LIF coefficient D=2R+1.2G-1.4B is untouched.
  rgb=[clip(abs(e)/span*self.g['gain_r'],0,1),
       clip(abs(vref-vel)/(2*speed)*self.g['gain_g'],0,1),
       clip(.12*headroom*self.g['gain_b'],0,1)]
  pulse=self.ripple.step(rgb,dt)
  self.event_total+=pulse['count']
  # Software events influence damping; ablation with enable_ripple=False is possible.
  error_score=clip(abs(e)/span+abs(vel)/(2*speed),0,1)
  active=pulse['count']>0
  # 'gate' regulates event strength; it cannot silence observed events completely.
  event_weight=.25+.75*(1-self.g['gate'])
  event_brake=(self.g['pulse_damp']*vel*int(active)*event_weight) if self.enable else 0.
  # Feedforward is a bounded desired velocity contribution.
  desired=self.g['kp']*e+self.g['kd']*(vref-vel)+self.g['feedforward']*vref-event_brake
  desired-=self.g['risk']*(1-headroom)*vel
  # Hardware-like safety constraints are not inherited and CANNOT be mutated.
  max_change=min(HARD_MAX_SLEW,self.g['slew'])*dt
  event_cap=max(0.8,HARD_MAX_COMMAND-min(2.,.45*self.g['pulse_damp']*int(active)*event_weight)) if self.enable else HARD_MAX_COMMAND
  command=clip(clip(desired,-event_cap,event_cap),
               self.old_command-max_change,self.old_command+max_change)
  if angle>hi-0.02 and command>0:command=0.0
  if angle<lo+0.02 and command<0:command=0.0
  self.old_target=filtered;self.old_command=command;self.old_vel=vel
  return Record(t,setpoint,angle,vel,command,pulse['count'],pulse['theta'])

def run_trajectory(genome:Genome,joint='arm_R',plant=None,enable_ripple=True,duration=5.2,dt=DT):
 # Intentional reuse of v0.7's unchanged virtual actuator implementation.
 plant=VirtualJointPlant(joint,**(plant or {}));ctrl=GeneMotor(genome,joint,enable_ripple)
 n=round(duration/dt);start=0;trace=[];errors=[];effort=0;jerk=0;old_u=0
 for k in range(n):
  t=k*dt;r=target(t)['arm_R' if joint=='arm_R' else joint]
  obs=ctrl.step(t,plant.x,plant.v,r,dt)
  x,v=plant.step(obs.command,dt)
  errors.append(r-x);effort+=obs.command**2*dt;jerk+=abs(obs.command-old_u)
  old_u=obs.command
  trace.append({'t':round(t,4),'target':r,'actual':x,'velocity':v,'command':obs.command,'spikes':obs.spikes})
 rmse=math.sqrt(sum(e*e for e in errors)/n)
 return {'joint':joint,'rmse':rmse,'effort':effort,'total_variation_command':jerk,
         'hits':plant.clipped,'events':ctrl.event_total,'trace':trace,
         'fitness':rmse+.0005*effort+.00004*jerk+.1*plant.clipped,
         'classification':'simulation of virtual joint plant; geometry/angles executable'}

class VirtualRobot:
 """Three-joint stateful digital twin with continuity and immutable joint limits."""
 def __init__(self,genomes=None):
  from .genetics import DEFAULT_MOTOR
  gs=genomes or {j:DEFAULT_MOTOR for j in CONTROL_JOINTS}
  self.genomes=gs
  self.controllers={j:GeneMotor(gs[j],j) for j in CONTROL_JOINTS}
  self.plants={j:VirtualJointPlant(j) for j in CONTROL_JOINTS}
  self.goal={j:0. for j in CONTROL_JOINTS};self.tick=0;self.history=[]
 def set_targets(self,changes:dict):
  if not isinstance(changes,dict) or not changes or set(changes)-set(CONTROL_JOINTS):raise ValueError('unknown or empty joint command')
  safe={}
  for joint,x in changes.items():
   x=checked(x);lo,hi=JOINT_LIMITS[joint]
   if not lo<=x<=hi: raise ValueError(f'{joint} outside hard position range')
   safe[joint]=x
  self.goal.update(safe)
 def step(self,dt=DT):
  dt=checked(dt);output={}
  for j in CONTROL_JOINTS:
   p=self.plants[j];obs=self.controllers[j].step(self.tick*dt,p.x,p.v,self.goal[j],dt)
   angle,velocity=p.step(obs.command,dt)
   output[j]={'position':angle,'velocity':velocity,'command':obs.command,'spikes':obs.spikes,
              'limit':list(JOINT_LIMITS[j]),'genome':self.genomes[j].marker[:12]}
  self.tick+=1
  self.history.append({'time_s':round(self.tick*dt,5),'joints':output})
  if len(self.history)>10000:self.history=self.history[-10000:]
  return output
 def status(self):
  return {'time_s':self.tick*DT,'target':self.goal.copy(),
          'joints':{j:{'position':p.x,'velocity':p.v,'limits':JOINT_LIMITS[j]} for j,p in self.plants.items()},
          'kind':'numerically simulated digital twin, not connected to hardware'}
