from .genetics import Genome,encode,DEFAULT_MOTOR,DEFAULT_CODE,DEFAULT_LANGUAGE,DEFAULT_SIGNAL
from .robotics import VirtualRobot,GeneMotor
from .colony import Overseer
