"""Exports: ROS-style joint trajectory, URDF, and NEW skinned GLB animation.

All angles derive from numerical virtual-plant trajectories. No physical ROS
node is started, and nothing sends commands to hardware.
"""
import json, struct, math, pathlib, xml.etree.ElementTree as ET
from .robotics import CONTROL_JOINTS,JOINT_LIMITS,SPEED_LIMITS,run_trajectory,DT
from .genetics import Genome
BASE=pathlib.Path(__file__).resolve().parents[1]

def generate_paths(genomes:dict):
 if set(genomes)!=set(CONTROL_JOINTS) or any(g.role!='motor' for g in genomes.values()):raise ValueError('three motor genomes required')
 return {j:run_trajectory(genomes[j],j) for j in CONTROL_JOINTS}

def trajectory_message(paths,sample_step=4):
 if set(paths)!=set(CONTROL_JOINTS):raise ValueError('all joint paths required')
 n=len(paths['arm_R']['trace']);indexes=list(range(0,n,sample_step))
 if indexes[-1]!=n-1:indexes.append(n-1)
 points=[]
 for i in indexes:
  pos=[paths[j]['trace'][i]['actual'] for j in CONTROL_JOINTS]
  vel=[paths[j]['trace'][i]['velocity'] for j in CONTROL_JOINTS]
  for j,p,v in zip(CONTROL_JOINTS,pos,vel):
   lo,hi=JOINT_LIMITS[j]
   if not lo-1e-8<=p<=hi+1e-8 or abs(v)>SPEED_LIMITS[j]+1e-8:raise ValueError('unsafe output trajectory')
  t=i*DT;sec=int(t);ns=round((t-sec)*1e9)
  points.append({'positions':pos,'velocities':vel,'time_from_start':{'sec':sec,'nanosec':ns}})
 return {'joint_names':list(CONTROL_JOINTS),'points':points,'classification':'ROS 2 trajectory_msgs-compatible JSON structure; NOT sent to ROS hardware'}

def urdf_string():
 robot=ET.Element('robot',{'name':'kokoro_digital_twin_3d'})
 # Purely kinematic URDF; no invented link masses, inertia, or physics calibration.
 for name in ('torso','right_upper_arm','right_lower_arm','head'):
  ET.SubElement(robot,'link',name=name)
 for joint,parent,child,axis,xyz in (
  ('arm_R','torso','right_upper_arm','0 0 1','-0.34 0 1.45'),
  ('forearm_R','right_upper_arm','right_lower_arm','0 0 1','-0.34 0 0'),
  ('head','torso','head','0 1 0','0 0 0.65')):
  el=ET.SubElement(robot,'joint',name=joint,type='revolute')
  ET.SubElement(el,'parent',link=parent);ET.SubElement(el,'child',link=child)
  ET.SubElement(el,'origin',xyz=xyz,rpy='0 0 0');ET.SubElement(el,'axis',xyz=axis)
  lo,hi=JOINT_LIMITS[joint]
  ET.SubElement(el,'limit',lower=str(lo),upper=str(hi),effort='5.0',velocity=str(SPEED_LIMITS[joint]))
 return ET.tostring(robot,encoding='unicode')

def parse_glb_bytes(raw):
 if raw[:4]!=b'glTF' or len(raw)<28:raise ValueError('bad glb magic')
 version,length=struct.unpack_from('<II',raw,4)
 if version!=2 or length!=len(raw):raise ValueError('invalid glb size/version')
 chunk_len,chunk_id=struct.unpack_from('<I4s',raw,12)
 if chunk_id!=b'JSON':raise ValueError('missing JSON header')
 gltf=json.loads(raw[20:20+chunk_len]);pos=20+chunk_len
 blob_len,blob_id=struct.unpack_from('<I4s',raw,pos)
 if blob_id!=b'BIN\0':raise ValueError('missing binary data')
 blob=bytearray(raw[pos+8:pos+8+blob_len])
 if len(blob)!=gltf['buffers'][0]['byteLength']:raise ValueError('invalid binary length')
 return gltf,blob

def export_animation(paths,output_path,source=None):
 source=pathlib.Path(source) if source else BASE/'assets/Kokoro_Lumina_Alpha_v0_6.glb'
 gltf,blob=parse_glb_bytes(source.read_bytes())
 names={node['name']:i for i,node in enumerate(gltf['nodes']) if 'name' in node}
 if any(j not in names for j in CONTROL_JOINTS):raise ValueError('missing required rig bones')
 indexes=list(range(0,len(paths['arm_R']['trace']),3));
 if indexes[-1]!=len(paths['arm_R']['trace'])-1:indexes.append(len(paths['arm_R']['trace'])-1)
 t=[i*DT for i in indexes]
 def floats(values,typ,minimum=None,maximum=None):
  blob.extend(b'\0'*((-len(blob))%4));off=len(blob)
  blob.extend(struct.pack('<'+str(len(values))+'f',*values))
  vi=len(gltf['bufferViews']);gltf['bufferViews'].append({'buffer':0,'byteOffset':off,'byteLength':4*len(values)})
  c={'bufferView':vi,'componentType':5126,'count':len(t),'type':typ}
  if minimum is not None:c['min']=[minimum]
  if maximum is not None:c['max']=[maximum]
  ix=len(gltf['accessors']);gltf['accessors'].append(c);return ix
 ti=floats(t,'SCALAR',t[0],t[-1])
 animation={'name':'Genome_Ripple_Robotics_Validated_Simulation','samplers':[],'channels':[]}
 for j in CONTROL_JOINTS:
  quats=[]
  for i in indexes:
   angle=paths[j]['trace'][i]['actual']
   s=math.sin(angle/2);c=math.cos(angle/2)
   quats.extend([0.,s,0.,c] if j=='head' else [0.,0.,s,c])
  oi=floats(quats,'VEC4');si=len(animation['samplers'])
  animation['samplers'].append({'input':ti,'output':oi,'interpolation':'LINEAR'})
  animation['channels'].append({'sampler':si,'target':{'node':names[j],'path':'rotation'}})
 gltf.setdefault('animations',[]).append(animation);gltf['buffers'][0]['byteLength']=len(blob)
 jb=json.dumps(gltf,separators=(',',':')).encode();jb+=b' '*((-len(jb))%4)
 blob.extend(b'\0'*((-len(blob))%4))
 package=struct.pack('<4sII',b'glTF',2,12+8+len(jb)+8+len(blob))+struct.pack('<I4s',len(jb),b'JSON')+jb+struct.pack('<I4s',len(blob),b'BIN\0')+blob
 output_path=pathlib.Path(output_path);output_path.parent.mkdir(parents=True,exist_ok=True);output_path.write_bytes(package)
 return {'path':str(output_path),'animations':[a.get('name') for a in gltf.get('animations',[])],
         'keyframes':len(t),'joints_animated':list(CONTROL_JOINTS),'bytes':len(package),
         'source_untouched':True}
