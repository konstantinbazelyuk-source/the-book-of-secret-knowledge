"""Unmodified 3D mesh rendering + diagnostic 3D tracked landmarks."""
from __future__ import annotations
import numpy as np
import vtk
from .geometry import Renderer,marker_world,Calibration,IDS
class MarkerRenderer:
 def __init__(self,size=(320,420),yaw=.45):
  self.base=Renderer(size=size);self.cam=Calibration(size=size,yaw=yaw)
  self.actors={}
  self.base.camera_yaw=yaw
  for name,color in IDS.items():
   sphere=vtk.vtkSphereSource();sphere.SetRadius(.07);sphere.SetThetaResolution(16);sphere.SetPhiResolution(12)
   mapper=vtk.vtkPolyDataMapper();mapper.SetInputConnection(sphere.GetOutputPort())
   actor=vtk.vtkActor();actor.SetMapper(mapper)
   rgb=(color[2]/255,color[1]/255,color[0]/255)
   actor.GetProperty().SetColor(*rgb);actor.GetProperty().LightingOff()
   self.base.renderer.AddActor(actor);self.actors[name]=actor
 def frame(self,angles,t=0,with_markers=True,post=False, light=1):
  points=marker_world(self.base.data['bones'],angles)
  for n,a in self.actors.items():
   a.SetPosition(*map(float,points[n]));a.SetVisibility(bool(with_markers))
  return self.base.frame(t,{'joint_overrides':dict(zip(('arm_R','forearm_R','head'),map(float,angles))),
                            'mode':'idle','yaw':self.cam.yaw,'density':0,'scan':0,'bloom':0,
                            'gene_rgb':[40*light,160*light,205*light]},post=post)
