"""Real calibrated 3D camera geometry and 2D RGB fiducial inversion.

Fiducials are virtual diagnostic objects physically rendered in the 3D scene.
The observer only receives camera pixels; it does not access the joint plant.
"""
from __future__ import annotations
import math,sys,pathlib
import numpy as np
import cv2
from scipy.optimize import least_squares
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'upstream'))
from vtk_renderer import pose,Renderer

JOINTS=('arm_R','forearm_R','head')
BOUNDS=np.array([[-.12,1.48],[-.75,.50],[-.35,.35]])
# Distinct id colors, independent of semantic RGB/stimulation neural channels.
IDS={'elbow':(0,0,255),'wrist':(0,255,0),'head':(255,0,0)} # OpenCV BGR target
REST_MARKERS={
 'elbow':('forearm_R',(0.72,1.71,0.32)),
 'wrist':('hand_R',(0.86,1.28,0.38)),
 'head':('head',(0.18,2.57+0.11,0.35)),
}

def marker_world(bones,angles):
 """Forward kinematics via original v0.6 bind pose matrices and homogeneous coords."""
 controls={'mode':'idle','joint_overrides':dict(zip(JOINTS,map(float,angles)))}
 skin=pose(bones,0,controls)
 lookup={b['name']:i for i,b in enumerate(bones)}
 return {tag:(skin[lookup[bone]]@np.array([*rest,1.]))[:3]
         for tag,(bone,rest) in REST_MARKERS.items()}

def camera_basis(yaw=.45,distance=6.0):
 eye=np.array([math.sin(yaw)*distance,1.85,math.cos(yaw)*distance],float)
 focal=np.array([0.,1.45,0.])
 forward=focal-eye;forward/=np.linalg.norm(forward)
 right=np.cross(forward,[0,1,0]);right/=np.linalg.norm(right)
 up=np.cross(right,forward);up/=np.linalg.norm(up)
 return eye,right,up,forward

def project(points, size, yaw=.45,distance=6.0, fov=40.0):
 """Pinhole perspective; image coordinates from actual world XYZ, not screen sprites."""
 eye,right,up,forward=camera_basis(yaw,distance)
 width,height=size
 f=height/(2*math.tan(math.radians(fov)/2))
 out={}
 for name,p in points.items():
  v=np.asarray(p)-eye; z=float(v@forward)
  if z<=0:raise ValueError('point behind camera')
  out[name]=np.array([width*.5+f*(v@right)/z,height*.5-f*(v@up)/z],float)
 return out

class Calibration:
 def __init__(self,size=(320,420),yaw=.45,distance=6.0):
  self.size=tuple(size);self.yaw=float(yaw);self.distance=float(distance)
 def project(self,points):return project(points,self.size,self.yaw,self.distance)

def observe_pixels(img, min_pixels=6):
 """A measured RGB segmentation; no access to renderer's angle variables."""
 a=np.asarray(img.convert('RGB')) if hasattr(img,'convert') else np.asarray(img)
 if a.ndim!=3 or a.shape[2]<3:raise ValueError('RGB image required')
 out={}
 # Direct color-specific high saturation and contrast; lit VTK markers still high confidence.
 for name,bgr in IDS.items():
  idx=0 if name=='elbow' else 1 if name=='wrist' else 2
  own=a[:,:,idx].astype(np.int16)
  others=[a[:,:,k].astype(np.int16) for k in range(3) if k!=idx]
  mask=np.uint8((own>130)&(own-others[0]>70)&(own-others[1]>70))*255
  n,labels,stats,centers=cv2.connectedComponentsWithStats(mask,8)
  components=[i for i in range(1,n) if stats[i,cv2.CC_STAT_AREA]>=min_pixels]
  if not components:continue
  chosen=max(components,key=lambda i:stats[i,cv2.CC_STAT_AREA])
  out[name]=np.array(centers[chosen],dtype=float)
 return out

def estimate_pose(observed,bones,cam,initial=(.1,-.1,0),min_tags=3):
 if not isinstance(observed,dict) or len(observed)<min_tags: return {'available':False,'reason':'insufficient_visible_fiducials','count':len(observed)}
 if any(k not in REST_MARKERS or np.shape(v)!=(2,) or not np.isfinite(v).all() for k,v in observed.items()):raise ValueError('invalid observations')
 tags=tuple(sorted(observed));y=np.concatenate([observed[k] for k in tags]);
 def predicted(x):
  p=cam.project(marker_world(bones,x));return np.concatenate([p[k] for k in tags]);
 # Numerically differentiate true forward kinematics. Identity/observability is checked separately.
 jac=np.stack([(predicted(np.array(initial)+np.eye(3)[i]*1e-4)-predicted(np.array(initial)-np.eye(3)[i]*1e-4))/2e-4 for i in range(3)],axis=1)
 rank=np.linalg.matrix_rank(jac,tol=1e-4)
 if rank<3:return {'available':False,'reason':'unobservable_camera_geometry','rank':int(rank)}
 res=least_squares(lambda x:predicted(x)-y,x0=np.clip(initial,BOUNDS[:,0],BOUNDS[:,1]),bounds=(BOUNDS[:,0],BOUNDS[:,1]),max_nfev=60,ftol=1e-9,xtol=1e-9)
 rms=float(np.sqrt(np.mean((predicted(res.x)-y)**2)))
 if not res.success or rms>4.0:return {'available':False,'reason':'reprojection_error_exceeds_gate','reprojection_rmse_px':rms}
 return {'available':True,'angles':dict(zip(JOINTS,map(float,res.x))),'reprojection_rmse_px':rms,'rank':int(rank),'visible_tags':list(tags)}
