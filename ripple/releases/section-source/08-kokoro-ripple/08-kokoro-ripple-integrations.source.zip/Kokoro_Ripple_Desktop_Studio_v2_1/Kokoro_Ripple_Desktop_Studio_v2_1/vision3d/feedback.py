"""Validated camera-pixel -> 3D joint angle -> Ripple and bounded virtual motor loop."""
from __future__ import annotations
import json,pathlib,sys,hashlib
import cv2
import numpy as np
from .renderer import MarkerRenderer
from .geometry import JOINTS,BOUNDS,observe_pixels,estimate_pose
from .video import inspect_recorded_video
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'upstream'))
from ripple_core_v0_5 import RippleNeuron
from ripple_genome.robotics import VirtualRobot
# User library Golf v0.2 original unmodified Python image assessment reused here.
sys.path.insert(0,str(ROOT/'external'))
from golf_eyes_original import vision as golf_vision

def clip_to_limits(x):
 return np.clip(x,BOUNDS[:,0],BOUNDS[:,1]);

class VisualFeedback:
 def __init__(self,renderer,gain=.72,neural_enabled=False):
  if not 0<=gain<=1:raise ValueError('invalid visual feedback gain')
  self.renderer=renderer;self.gain=gain;self.ripple=RippleNeuron();self.last_estimate=np.zeros(3);self.last_ripple={"count":0,"u":0.,"theta":.45};self.neural_enabled=neural_enabled;self.integral=np.zeros(3);self.neural_output_changing_frames=0
 def measure(self,decoded_png,observed_only=True):
  a=cv2.imdecode(np.frombuffer(decoded_png,np.uint8),cv2.IMREAD_COLOR)
  if a is None:raise ValueError('unreadable recorded frame')
  pixel_tags=observe_pixels(cv2.cvtColor(a,cv2.COLOR_BGR2RGB))
  observation=estimate_pose(pixel_tags,self.renderer.base.data['bones'],self.renderer.cam,initial=self.last_estimate)
  rgb=(a.mean(axis=(0,1))[::-1]/255.0).tolist()
  # Retain original RGB coupling as sensory alert, not pose estimator.
  # Stimulation derives from actual recorded RGB pixels under diagnostic
  # landmarks. These are display-referred counts, not photons or EEG.
  stimulus=[]
  for name,ch in [('elbow',2),('wrist',1),('head',0)]:
   if name not in pixel_tags:
    stimulus.append(0.0);continue
   x,y=np.rint(pixel_tags[name]).astype(int);x=int(np.clip(x,1,a.shape[1]-2));y=int(np.clip(y,1,a.shape[0]-2))
   stimulus.append(float(np.max(a[y-1:y+2,x-1:x+2,ch]))/255.)
  spike=self.ripple.step(stimulus,.1)
  self.last_ripple=spike
  if observation['available']:self.last_estimate=np.array([observation['angles'][j] for j in JOINTS])
  return {'pose':observation,'rgb':rgb,'spikes':spike['count'],'ripple_stimulus':stimulus,'observed_tags':{k:list(map(float,v)) for k,v in pixel_tags.items()}}
 def safe_command(self,desired,command_bias,measurement):
  desired=np.asarray(desired,dtype=float);command_bias=np.asarray(command_bias,dtype=float)
  if desired.shape!=(3,) or command_bias.shape!=(3,) or not np.isfinite(desired).all() or not np.isfinite(command_bias).all():raise ValueError('invalid commanded target')
  if not ((desired>=BOUNDS[:,0])&(desired<=BOUNDS[:,1])).all():raise ValueError('unsafe requested position')
  base=clip_to_limits(desired+command_bias)
  if not measurement['pose']['available']:
   return dict(zip(JOINTS,map(float,base))),{'used_feedback':False,'reason':measurement['pose']['reason']}
  sensed=np.array([measurement['pose']['angles'][j] for j in JOINTS]);
  error=desired-sensed
  self.integral=np.clip(self.integral+.2*error,-.5,.5)
  # Original Ripple membrane/events from observed colored pixels actively gate
  # a small fraction of visual correction; no neuron state can bypass limits.
  activity=min(1.,self.last_ripple['u']/max(.15,self.last_ripple['theta'])+min(1,self.last_ripple['count']))
  factor=(.75+.35*activity) if self.neural_enabled else 1.
  if self.neural_enabled and abs(factor-1.)>1e-5:self.neural_output_changing_frames+=1
  corrected=clip_to_limits(base+self.gain*factor*error+.15*self.integral)
  return dict(zip(JOINTS,map(float,corrected))),{'used_feedback':True,'ripple_gain_factor':factor,'observed_rmse_rad':float(np.sqrt(np.mean((desired-sensed)**2)))}

def run_visual_trial(out,feedback=True,frames=27,fps=8,size=(320,420),camera_yaw=.45,
                     goal=(.95,-.35,.17),bias=(-.19,.13,-.08),disable_tags_at=(),neural_enabled=False):
 if not 5<=frames<=140 or not 1<=fps<=15:raise ValueError('invalid render budget')
 out=pathlib.Path(out);out.mkdir(parents=True,exist_ok=True)
 ren=MarkerRenderer(size=size,yaw=camera_yaw)
 observer=VisualFeedback(ren,gain=.82 if feedback else 0.,neural_enabled=neural_enabled)
 robot=VirtualRobot();goal=np.array(goal,dtype=float);bias=np.array(bias,dtype=float)
 robot.set_targets(dict(zip(JOINTS,map(float,clip_to_limits(goal+bias)))))
 traces=[];video=cv2.VideoWriter(str(out/'recording.mp4'),cv2.VideoWriter_fourcc(*'mp4v'),fps,size)
 if not video.isOpened():raise RuntimeError('VideoWriter unavailable')
 try:
  # Motor simulator clock always DT; frame clock independent.
  from upstream.motor_neuron_v07 import DT
  steps_per_frame=int(round(1./(fps*DT)))
  if abs(steps_per_frame*DT-1/fps)>1e-7:raise ValueError('frame period must be an exact motor-step multiple')
  for k in range(frames):
   for _ in range(steps_per_frame):robot.step(DT)
   q=np.array([robot.plants[j].x for j in JOINTS]);im=ren.frame(q,k/fps,with_markers=(k not in disable_tags_at),post=False)
   ok,enc=cv2.imencode('.png',cv2.cvtColor(np.asarray(im),cv2.COLOR_RGB2BGR));
   if not ok:raise RuntimeError('PNG encoding failed')
   frame_path=out/f'frame_{k:03}.png';frame_path.write_bytes(enc.tobytes())
   measured=observer.measure(frame_path.read_bytes())
   command,gate=observer.safe_command(goal,bias,measured)
   if feedback and gate['used_feedback']:robot.set_targets(command)
   video.write(cv2.imdecode(np.frombuffer(enc,np.uint8),cv2.IMREAD_COLOR))
   visual=np.array([measured['pose']['angles'][j] for j in JOINTS]) if measured['pose']['available'] else None
   trace={'frame':k,'time_s':round(k/fps,4),'sensed':measured['pose'],'rgb_measured':measured['rgb'],'rgb_stimulus_from_markers':measured['ripple_stimulus'],
          'ripple_gain_factor':gate.get('ripple_gain_factor'),
          'ripple_spikes':measured['spikes'],'feedback_used':feedback and gate['used_feedback'],
          'requested':goal.tolist(),'joint_observed_error_rad':None if visual is None else (visual-goal).tolist(),
          'golf_observed':None,'png_sha256':hashlib.sha256(enc.tobytes()).hexdigest()}
   # Original Golf Digital Eyes extracts actual pixel metrics from recorded PNGs.
   if k in (0,frames-1):
    v=golf_vision(frame_path)
    trace['golf_observed']={key:v[key] for key in ('meanRGB','edgeFraction','orbKeypoints','lumaMean','sourceHash')}
   traces.append(trace)
 finally:video.release()
 dec=cv2.VideoCapture(str(out/'recording.mp4'))
 got=0
 try:
  while True:
   ok,frame=dec.read()
   if not ok:break
   got+=1
 finally:dec.release()
 errors=[np.asarray(t['joint_observed_error_rad']) for t in traces if t['joint_observed_error_rad'] is not None]
 summary={'kind':'real VTK/EGL mesh frames with software virtual servos; image-only diagnostic-marker pose estimation',
          'feedback':feedback,'requested_joint_angles_rad':goal.tolist(),'target_bias_rad':bias.tolist(),
          'image_frames':len(traces),'decoded_mp4_frames':got,'successful_observations':len(errors),
          'visual_joint_rmse_rad':float(np.sqrt(np.mean(np.square(errors[-min(8,len(errors)):])))) if errors else None,
          'visual_feedback_applied':int(sum(t['feedback_used'] for t in traces)),
          'neural_enabled':neural_enabled,'ripple_gain_modulated_frames':observer.neural_output_changing_frames if feedback else 0,
          'actual_motor_angles_hidden_from_observer':True,'original_ripple_spikes':int(sum(t['ripple_spikes'] for t in traces)),
          'camera_yaw_rad':camera_yaw,'model':'original Kokoro v0.6 skinned triangle mesh; unchanged model data',
          'limitations':['virtual markers attached to known 3D model','camera intrinsic/extrinsic are known','not markerless vision','not physical robotic feedback','Kokoro LLM not connected']}
 video_pose=inspect_recorded_video(out/'recording.mp4',ren.base.data['bones'],ren.cam,limit=frames)
 summary['video_encoded_observed_pose_frames']=video_pose['frames_with_pose']
 (out/'encoded_video_observations.json').write_text(json.dumps(video_pose,indent=2))
 (out/'summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False))
 (out/'timeline.json').write_text(json.dumps(traces,indent=2,allow_nan=False))
 return summary
