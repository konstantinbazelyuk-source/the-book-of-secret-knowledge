"""Kokoro add-on: calibrated perspective 3D vision and image-derived joint observations."""
