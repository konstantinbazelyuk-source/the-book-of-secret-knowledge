"""Read back an *encoded* 3D recording as the only pose-observation source."""
from __future__ import annotations
import json,pathlib
import numpy as np, cv2
from .geometry import observe_pixels,estimate_pose,JOINTS

def inspect_recorded_video(path,bones,calibration,limit=200):
 cap=cv2.VideoCapture(str(path))
 if not cap.isOpened():raise ValueError('video file cannot be decoded')
 frames=[];guess=np.zeros(3);k=0
 try:
  while k<limit:
   ok,bgr=cap.read()
   if not ok:break
   rgb=cv2.cvtColor(bgr,cv2.COLOR_BGR2RGB)
   tags=observe_pixels(rgb)
   estimate=estimate_pose(tags,bones,calibration,initial=guess)
   if estimate['available']:guess=np.array([estimate['angles'][j] for j in JOINTS])
   frames.append({'frame':k,'available':estimate['available'],'estimated_angles':estimate.get('angles'),
                  'reprojection_rmse_px':estimate.get('reprojection_rmse_px'),
                  'error':estimate.get('reason')});k+=1
 finally:cap.release()
 return {'classification':'observed encoded MP4 pixels; RGB fiducials on 3D avatar','frames_decoded':len(frames),
         'frames_with_pose':sum(v['available'] for v in frames),'observations':frames}
