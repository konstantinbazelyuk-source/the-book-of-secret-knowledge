#!/usr/bin/env python3
"""Golf Digital Eyes: source/visual/outcome observations. NO unrestricted execution.

External input JSON from stdin. Paths must resolve beneath --workspace. All reported
image metrics are computed from actual supplied pixels, not semantically invented.
"""
import ast
import hashlib
import json
import math
import operator
import os
from pathlib import Path
import subprocess
import sys

MAX_SOURCE = 100_000
MAX_IMAGE = 8_000_000

def check_workspace(workspace, relative, suffixes):
    if not isinstance(relative, str) or not relative or len(relative) > 250 or '\x00' in relative:
        raise ValueError('invalid relative workspace filename')
    root = Path(workspace).resolve(strict=True)
    target = (root / relative).resolve(strict=True)
    if not target.is_relative_to(root) or target == root or not target.is_file() or target.suffix.lower() not in suffixes:
        raise ValueError('access denied: file must be an allowed file beneath workspace')
    if target.stat().st_size > (MAX_IMAGE if suffixes == {'.png','.jpg','.jpeg','.bmp','.webp'} else MAX_SOURCE):
        raise ValueError('file over size limit')
    return target

def digest(data):return hashlib.sha256(data).hexdigest()

def python_observe(code):
    try: tree = ast.parse(code, type_comments=True)
    except SyntaxError as e:
        return {'syntaxValid':False,'diagnostics':[{'message':e.msg,'line':e.lineno,'column':e.offset}],
                'symbols':[],'calls':[],'imports':[],'edges':[],'complexity':None}
    items=[]; calls=[]; imports=[]; edges=[]; functions=[]
    class Walker(ast.NodeVisitor):
        def __init__(self): self.scope=[]
        def visit_FunctionDef(self,n):
            name='.'.join(self.scope+[n.name]);items.append({'kind':'function','name':name,'line':n.lineno,'end':n.end_lineno,'args':[a.arg for a in n.args.args]});functions.append(n)
            self.scope.append(n.name);self.generic_visit(n);self.scope.pop()
        visit_AsyncFunctionDef=visit_FunctionDef
        def visit_ClassDef(self,n):
            items.append({'kind':'class','name':'.'.join(self.scope+[n.name]),'line':n.lineno,'end':n.end_lineno});self.scope.append(n.name);self.generic_visit(n);self.scope.pop()
        def visit_Import(self,n):
            imports.extend(a.name for a in n.names)
        def visit_ImportFrom(self,n):imports.append(n.module or '')
        def visit_Call(self,n):
            dest=ast.unparse(n.func)[:120]
            calls.append({'name':dest,'line':n.lineno})
            if self.scope: edges.append({'from':'.'.join(self.scope),'to':dest,'line':n.lineno})
            self.generic_visit(n)
    Walker().visit(tree)
    return {'syntaxValid':True,'diagnostics':[],'symbols':items[:400],'imports':imports[:100],
            'calls':calls[:400],'edges':edges[:400], 'complexity':{
                'astNodes':sum(1 for _ in ast.walk(tree)),
                'branches':sum(isinstance(n,(ast.If,ast.For,ast.While,ast.Try,ast.IfExp,ast.Match)) for n in ast.walk(tree)),
                'functions':len(functions), 'lines':len(code.splitlines())}}

def js_observe(file_path):
    bridge=Path(__file__).with_name('js_parse.cjs')
    res=subprocess.run(['node',str(bridge),str(file_path)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=7,check=False)
    if res.returncode!=0:raise ValueError('JS/TS parser failed: '+res.stderr.decode('utf8','replace')[:200])
    return json.loads(res.stdout)

ALLOWED_BIN={ast.Add:operator.add,ast.Sub:operator.sub,ast.Mult:operator.mul,ast.Div:operator.truediv,
             ast.Pow:operator.pow,ast.Mod:operator.mod,ast.FloorDiv:operator.floordiv}
ALLOWED_CMP={ast.Gt:operator.gt,ast.GtE:operator.ge,ast.Lt:operator.lt,ast.LtE:operator.le,
             ast.Eq:operator.eq,ast.NotEq:operator.ne}
FUNS={'exp': math.exp,'log':math.log,'sqrt':math.sqrt,'abs':abs,'min':min,'max':max}

def bounded(v):
    if isinstance(v,bool):return v
    if not isinstance(v,(int,float)) or not math.isfinite(v) or abs(v)>1e12:raise ValueError('computed value not bounded finite number')
    return float(v)

def expression(n,scope,depth=0):
    if depth>30:raise ValueError('expression depth exceeds limit')
    if isinstance(n,ast.Constant) and type(n.value) in (bool,int,float):return bounded(n.value)
    if isinstance(n,ast.Name) and n.id in scope:return scope[n.id]
    if isinstance(n,ast.BinOp) and type(n.op) in ALLOWED_BIN:
        l=expression(n.left,scope,depth+1);r=expression(n.right,scope,depth+1)
        if isinstance(n.op,ast.Pow) and abs(r)>8:raise ValueError('unbounded power')
        return bounded(ALLOWED_BIN[type(n.op)](l,r))
    if isinstance(n,ast.UnaryOp) and isinstance(n.op,(ast.USub,ast.UAdd,ast.Not)):
        v=expression(n.operand,scope,depth+1)
        return bounded(-v if isinstance(n.op,ast.USub) else (not bool(v)) if isinstance(n.op,ast.Not) else v)
    if isinstance(n,ast.Compare) and len(n.ops)==1 and type(n.ops[0]) in ALLOWED_CMP:
        return ALLOWED_CMP[type(n.ops[0])](expression(n.left,scope,depth+1),expression(n.comparators[0],scope,depth+1))
    if isinstance(n,ast.IfExp):return expression(n.body if expression(n.test,scope,depth+1) else n.orelse,scope,depth+1)
    if isinstance(n,ast.BoolOp) and isinstance(n.op,(ast.And,ast.Or)):
        vals=[bool(expression(x,scope,depth+1)) for x in n.values]
        return all(vals) if isinstance(n.op,ast.And) else any(vals)
    if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id in FUNS and not n.keywords and len(n.args) in (1,2):
        if n.func.id not in ('min','max') and len(n.args)!=1:raise ValueError('invalid arity')
        return bounded(FUNS[n.func.id](*(expression(a,scope,depth+1) for a in n.args)))
    raise ValueError('unsupported AST construct: '+type(n).__name__)

def restricted_function(src,name,values):
    tree=ast.parse(src)
    if sum(1 for _ in ast.walk(tree))>300: raise ValueError('AST budget exceeded')
    if len(tree.body)!=1 or not isinstance(tree.body[0],ast.FunctionDef) or tree.body[0].name!=name:
        raise ValueError('one named function required')
    fn=tree.body[0]
    if fn.decorator_list or fn.args.vararg or fn.args.kwarg or fn.args.kwonlyargs or fn.args.defaults or fn.args.posonlyargs:
        raise ValueError('unsupported function signature')
    args=[a.arg for a in fn.args.args]
    if set(args)!=set(values) or len(args)!=len(values):raise ValueError('function parameters do not match case inputs')
    scope={k:bounded(v) for k,v in values.items()}
    def statements(lines,depth=0):
        if depth>6:raise ValueError('branch depth exceeded')
        for n in lines:
            if isinstance(n,ast.Return):return expression(n.value,scope)
            if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
                scope[n.targets[0].id]=expression(n.value,scope);continue
            if isinstance(n,ast.If):
                got=statements(n.body if expression(n.test,scope) else n.orelse,depth+1)
                if got is not None:return got
                continue
            raise ValueError('unsupported statement: '+type(n).__name__)
        return None
    out=statements(fn.body)
    if out is None:raise ValueError('function did not return')
    return bounded(out)

def assess_task(src,name,cases):
    if not isinstance(cases,list) or not 1<=len(cases)<=200:raise ValueError('1..200 test cases required')
    observations=[]
    for i,c in enumerate(cases):
        if not isinstance(c,dict) or set(c)!={'inputs','expected'} or not isinstance(c['inputs'],dict) or len(c['inputs'])>12:
            raise ValueError('case must specify inputs and expected')
        try:
            found=restricted_function(src,name,c['inputs'])
            expect=bounded(c['expected'])
            difference=abs(found-expect)
            tol=1e-9+1e-7*abs(expect)
            passed=difference<=tol
            observations.append({'index':i,'actual':found,'expected':expect,'absoluteError':difference,'pass':passed})
        except (ValueError,ArithmeticError,OverflowError) as e:
            observations.append({'index':i,'error':str(e)[:200],'pass':False})
    successes=sum(x['pass'] for x in observations)
    return {'cases':len(cases),'passed':successes,'failed':len(cases)-successes,
            'accuracy':successes/len(cases),'observations':observations,
            'scope':'BOUNDED AST INTERPRETATION; never executes untrusted Python bytecode'}

def vision(path,second=None,align=False,dark=None,flat=None):
    try:import cv2;import numpy as np
    except ImportError as e:raise ValueError('vision requires numpy and opencv-python-headless: '+str(e))
    def load(p):
        frame=cv2.imread(str(p),cv2.IMREAD_COLOR)
        if frame is None:raise ValueError('image cannot be decoded')
        if frame.shape[0]*frame.shape[1]>8_000_000:raise ValueError('pixel budget exceeded')
        return frame
    a=load(path);gray=cv2.cvtColor(a,cv2.COLOR_BGR2GRAY)
    lap=cv2.Laplacian(gray,cv2.CV_64F);edges=cv2.Canny(gray,70,150)
    orb=cv2.ORB_create(nfeatures=400);pts,_=orb.detectAndCompute(gray,None)
    result={'width':int(a.shape[1]),'height':int(a.shape[0]),'meanRGB':[float(v) for v in a.mean(axis=(0,1))[::-1]],
            'lumaMean':float(gray.mean()),'edgeFraction':float(np.count_nonzero(edges)/gray.size),
            'focusLaplacianVariance':float(lap.var()),'orbKeypoints':len(pts) if pts else 0,
            'provenance':'PIXEL MEASUREMENT of recorded file; not calibrated physical radiance',
            'sourceHash':digest(path.read_bytes())}
    if dark is not None or flat is not None:
        if dark is None or flat is None:raise ValueError('dark and flat must be supplied together')
        d=load(dark).astype('float64');f=load(flat).astype('float64')
        if d.shape!=a.shape or f.shape!=a.shape:raise ValueError('dark/flat dimensions must match input')
        denominator=f-d; mask=np.min(denominator,axis=2)>5
        if not np.any(mask):raise ValueError('flat-dark response too small for normalization')
        corrected=np.clip((a.astype('float64')-d)/np.maximum(denominator,1e-9),0,10)
        result['darkFlatCorrection']={'darkHash':digest(dark.read_bytes()),'flatHash':digest(flat.read_bytes()),
            'validPixelFraction':float(mask.mean()),'meanRelativeSignalRGB':[float(v) for v in corrected[mask].mean(axis=0)[::-1]],
            'scope':'Arithmetic detector-count correction only; not absolute radiance or verified calibration frames'}
    if second:
        b=load(second)
        if b.shape!=a.shape:raise ValueError('frames must have identical dimensions; no implicit resampling')
        transform=None;inliers=0;valid=np.ones(a.shape[:2],dtype='uint8')
        if align:
            kp1,desc1=orb.detectAndCompute(gray,None)
            kp2,desc2=orb.detectAndCompute(cv2.cvtColor(b,cv2.COLOR_BGR2GRAY),None)
            if desc1 is None or desc2 is None or len(kp1)<6 or len(kp2)<6:raise ValueError('insufficient feature points for registration')
            matcher=cv2.BFMatcher(cv2.NORM_HAMMING)
            pairs=matcher.knnMatch(desc2,desc1,k=2)
            good=[m for group in pairs if len(group)==2 for m,n in [group] if m.distance < .75*n.distance]
            if len(good)<6:raise ValueError('insufficient robust image matches')
            src=np.float32([kp2[m.queryIdx].pt for m in good]); dst=np.float32([kp1[m.trainIdx].pt for m in good])
            M,maskInliers=cv2.estimateAffinePartial2D(src,dst,method=cv2.RANSAC,ransacReprojThreshold=2.5,maxIters=1000)
            if M is None or maskInliers is None or int(maskInliers.sum())<5:raise ValueError('image transform cannot be validated')
            if abs(M[0,2])>.25*a.shape[1] or abs(M[1,2])>.25*a.shape[0]:raise ValueError('estimated translation exceeds allowed range')
            inliers=int(maskInliers.sum()); transform=M.tolist()
            b=cv2.warpAffine(b,M,(a.shape[1],a.shape[0]),flags=cv2.INTER_LINEAR,borderMode=cv2.BORDER_CONSTANT)
            valid=cv2.warpAffine(np.ones(a.shape[:2],dtype='uint8'),M,(a.shape[1],a.shape[0]),flags=cv2.INTER_NEAREST)
        delta=cv2.absdiff(a,b);diff=np.max(delta,axis=2);changed=(diff>25)&(valid>0)
        n=int(np.count_nonzero(changed));validN=max(1,int(np.count_nonzero(valid)))
        ys,xs=np.nonzero(changed)
        bounds=[int(xs.min()),int(ys.min()),int(xs.max())+1,int(ys.max())+1] if n else None
        result['comparison']={'secondHash':digest(second.read_bytes()),'changedPixels':n,
                              'changedFraction':float(n/validN),'meanAbsolutePixelDifference':float(delta[valid>0].mean()),
                              'validPixels':validN,'boundsXYXY':bounds,
                              'alignment':'ORB matches + RANSAC affine' if align else 'same registered pixel grid, no alignment',
                              'transform':transform,'inliers':inliers}
    return result

def execute(req,workspace):
    if not isinstance(req,dict) or 'mode' not in req:raise ValueError('mode required')
    mode=req['mode']
    if mode=='code':
        name=check_workspace(workspace,req.get('file'),{'.py','.js','.mjs','.cjs','.ts','.tsx','.jsx'})
        raw=name.read_bytes()
        src=raw.decode('utf8')
        obj=python_observe(src) if name.suffix.lower()=='.py' else js_observe(name)
        return {'mode':mode,'file':name.name,'sha256':digest(raw),'language':'python' if name.suffix.lower()=='.py' else 'javascript/typescript',
                'observation':obj,'scope':'static syntax/structure; not proof of program correctness'}
    if mode=='image':
        suff={'.png','.jpg','.jpeg','.bmp','.webp'}
        a=check_workspace(workspace,req.get('file'),suff)
        b=check_workspace(workspace,req['second'],suff) if req.get('second') else None
        dark=check_workspace(workspace,req['dark'],suff) if req.get('dark') else None
        flat=check_workspace(workspace,req['flat'],suff) if req.get('flat') else None
        if not isinstance(req.get('align',False),bool):raise ValueError('align must be boolean')
        return {'mode':mode,'file':a.name,'observation':vision(a,b,req.get('align',False),dark,flat)}
    if mode=='task':
        name=check_workspace(workspace,req.get('file'),{'.py'})
        label=req.get('function');cases=req.get('cases')
        if not isinstance(label,str) or not label.isidentifier():raise ValueError('valid function name required')
        raw=name.read_bytes();out=assess_task(raw.decode('utf8'),label,cases)
        return {'mode':mode,'file':name.name,'sha256':digest(raw),'function':label,'observation':out}
    raise ValueError('unknown perception mode')

if __name__=='__main__':
    try:
        if len(sys.argv)!=2:raise ValueError('usage: eyes.py workspace')
        data=sys.stdin.buffer.read(300000)
        if len(data)>=300000:raise ValueError('request exceeds limit')
        req=json.loads(data)
        output=execute(req,sys.argv[1]);print(json.dumps({'ok':True,'result':output},allow_nan=False))
    except Exception as ex:
        print(json.dumps({'ok':False,'error':type(ex).__name__+': '+str(ex)[:250]}));sys.exit(2)
