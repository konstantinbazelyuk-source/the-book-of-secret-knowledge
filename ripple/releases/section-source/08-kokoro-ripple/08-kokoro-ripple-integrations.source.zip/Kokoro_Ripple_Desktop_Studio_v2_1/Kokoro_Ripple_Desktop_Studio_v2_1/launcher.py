from studio.desktop import main
main()
