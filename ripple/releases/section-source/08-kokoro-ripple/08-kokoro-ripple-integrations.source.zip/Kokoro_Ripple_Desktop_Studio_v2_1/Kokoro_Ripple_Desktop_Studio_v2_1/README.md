# Kokoro Ripple Desktop Studio v2.1 — Native interactive application

**Status:** Runnable Python/Tk desktop application driving the original v2.0 Kokoro Geometric Vision, v1.8 digital genome specialist interfaces, original Ripple event neurons, existing virtual motor controllers and VTK 3D mesh renderer. These original source files have not been edited.

## One-click Windows launcher (Dell laptop)

1. Extract the **whole ZIP** into a normal writable directory such as `Documents\KokoroRippleStudio`. Do not run the application from inside a ZIP.
2. Install Python **3.11–3.13** from python.org with Tcl/Tk support and check **Add Python to PATH** if prompted. Internet is required only to install Python dependencies on first use.
3. Double-click **`RUN_WINDOWS.bat`**. This creates an isolated `.venv`, installs the actual rendering dependencies, then opens a **native Windows application window** using `pythonw.exe`. Later launches reuse the environment. No terminal commands are required.
4. If first-launch installation fails, keep the terminal window open and inspect its error text. Use `RUN_DEBUG_WINDOWS.bat` after setup to start the same window with visible Python diagnostics.

**Windows deployment status:** The launcher and Python files were syntax-checked, but the actual Dell/Windows machine was not accessible from this session. The native GUI was opened and tested on Linux in a real Xvfb display. VTK video/OpenGL support depends on installed graphics drivers and Python wheel availability; the launcher is a runnable distribution, not a Windows .exe build.

Linux desktop: run `sh RUN_UNIX.sh` (Python Tk/Tcl package, compatible OpenGL/EGL/VTK display drivers required). Native Tcl/Tk must exist. Note: offscreen VTK may warn about unavailable X if operating without a display.

## Working controls

**3D Operator:** enter a supported literal movement instruction (`raise right arm 40 degrees`, `lower right forearm 10 degrees`, `turn head left 10 degrees`, `reset pose`), or adjust original joint targets (radians). *The interpreter is the original bounded grammar, not a connected trained LLM.* Use Start, Pause, Resume, Stop, Restart, and Save state in the top toolbar. The avatar frame displayed is freshly rendered from the original skinned 3D model; the trace graph is calculated from camera-derived joint measurements. Enable/disable visual servo feedback and optional Ripple gain modulation; adjust gain and joint targets during a run. FPS, recording length and camera yaw are start-only settings.

**Ripple & Genome:** send actual normalized RGB numeric samples to the original Ripple signal specialist and view genuine event counts; inspect the original typed digital genome overseer (motor, signal, code, language).

**Code Inspection:** analyze Python AST or JSON without executing source, using the preserved code specialist. This does not provide general natural-language comprehension or code correctness proof.

**Sessions & Files:** persistent SQLite session history, completed/stopped recordings as MP4 files, frame PNGs, mathematical observation timelines, JSON summaries, file explorer actions, configuration export and session-configuration restore.

**Diagnostics & Logs:** inspect CPU count, Python, VTK, OpenCV, available RAM (where psutil works), machine platform and local application log. This reports the actual execution computer only; no assumption about the user's Dell GPU/CPU.

## How computation connects to the GUI

- The `studio/backend.py::Runner` operates a worker thread and emits actual frame/observation events via a bounded Python queue, separate from Tk's single-threaded GUI event loop.
- It calls **unchanged original** `VirtualRobot.step(DT)`, `MarkerRenderer.frame`, `VisualFeedback.measure`, `VisualFeedback.safe_command` and `inspect_recorded_video`.
- Camera pose estimation is calculated from measured RGB marker pixels using original calibrated perspective geometry and numerical least-squares. If markers are unavailable, the original sensor returns `available=false` rather than guessing a pose.
- The recorder saves actual encoded MP4 data and re-reads it after closing the video stream. **Recorded videos are silent** in this v2.0 geometric-vision branch; the full v1.9 audiovisual experiment is retained inside the protected original archive but is not a tab in this desktop release.
- GUI command input and code/RGB analysis dispatch to the existing `Overseer` and specialist processors. No new neural weights or AI model are fabricated.
- All live process updates are finite and bounded by hard limits in the original program. Frame rate and camera settings cannot be changed in the middle of a run.
- Camera rendering is performed as quickly as available computation permits. The video file's FPS is a *simulation-time timestamp*, not a guarantee of physical display refresh rate.

## Persistent data

Data is created alongside the application when used:

- `data/kokoro_studio.sqlite3` — checked configuration and immutable session paths/results.
- `sessions/<id>/` — actual recording.mp4, frame_###.png, RGB observation and summary JSON.
- `logs/application.log` — runtime messages, operations and errors.

Save state preserves settings and session history and restores them after reopening. It **does not** serialize mid-frame C++ VTK state or the original virtual-neuron membrane for exact in-flight continuation. Pause/Resume works for an active process while the application remains open. Stop finalizes the recorded frames; Restart starts a separate run.

## Verification

Run `python -m pytest -q tests` and the native GUI integration script `python tests/desktop_smoke.py` with an active display. On Linux headless CI, use `xvfb-run -a python tests/desktop_smoke.py` and `xvfb-run -a python tests/desktop_lifecycle_smoke.py`. The output screenshot in `results/actual_desktop_window.png` was captured from the actual Tk window after a real five-frame computation.

Read `docs/VERIFICATION.md` for measured outcomes, hardware, regression provenance and feature boundaries.

## Unsupported / pending capabilities

Trained Kokoro Core model weights and natural conversational understanding remain unavailable. No physical robot, real camera, Blender runtime, verified GPU acceleration, VRM importer, arbitrary 3D model editing, real-time microphone capture, speech recognition, or markerless human pose recognition is included. A tool not actually connected is not displayed as active. Other archived modules are kept available for subsequent opt-in integrations, not falsely presented as running.
