@echo off
cd /d "%~dp0"
python -c "import vtk,numpy,cv2,PIL,trimesh" >nul 2>&1
if errorlevel 1 (
  echo Missing required Python dependencies. Install with:
  echo python -m pip install -r requirements-live.txt
  pause
  exit /b 1
)
python tools\live_operator_server.py --port 8766 --fps 5
