"""Loopback-only live Kokoro 3D operator service; VTK renders real 3D frames.
No remote tool access, inference, network fetches, weights, or unsafe instructions.
"""
from __future__ import annotations
import argparse,io,json,math,time,threading,hashlib,pathlib,sys
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from vtk_renderer import Renderer,BASE
import sys
sys.path.insert(0,str(BASE/'sources'))
from forest_v05.forest import Overseer
PAGE='''<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><meta charset="utf-8"><title>Lumina · 3D Live Operator</title><style>
body{margin:0;background:#090e19;color:#d8f1f1;font:14px system-ui}header{padding:15px 24px;border-bottom:1px solid #344656}main{display:grid;grid-template-columns:minmax(280px,1fr) 275px;gap:16px;max-width:1150px;margin:20px auto;padding:0 15px}img{display:block;object-fit:contain;width:100%;height:min(80vh,850px);background:#040913;border-radius:10px;border:1px solid #384a56}aside{padding:20px;background:#121d2a;border:1px solid #314a54;border-radius:10px}label{display:block;margin:15px 0}input[type=range],select{display:block;width:100%;margin:7px 0;accent-color:#56cfcb}select{padding:10px;background:#1c3140;color:#e3eded;border:1px solid #4c6b73}h1{font:28px Georgia;margin:6px 0}h2{font-size:12px;color:#6cdbc9;letter-spacing:.12em}small{color:#9baebf}pre{white-space:pre-wrap;color:#93cad1;font-size:11px}button{cursor:pointer;padding:10px;color:#fff;background:#247478;border:0;border-radius:5px}@media(max-width:760px){main{grid-template-columns:1fr}img{height:60vh}}</style></head><body><header><small>REAL 3D · LOOPBACK RENDER PIPELINE</small><h1>Kokoro / Lumina Live Operator</h1><small>VTK EGL 3D skeletal skinning → genuine post-render compositing → PNG stream · synthetic demo only</small></header>
<main><div><img id="frame" alt="Live rendered Kokoro 3D frame"/><p><small>This is a sequence of rendered PNG frames, not video pretending to be an LLM or Blender output.</small></p></div><aside><h2>OPERATOR</h2><label>Pose<select id="mode"><option>idle</option><option>wave</option><option>greet</option><option>scan</option><option>focus</option><option>rest</option><option>spin</option></select></label><label>Head <input id="head" type="range" min="-1" max="1" step=".01" value="0"></label><label>Gesture <input id="wave" type="range" min="0" max="1" step=".01" value="0"></label><label>Orbit <input id="yaw" type="range" min="-3.1" max="3.1" step=".01" value=".45"></label><label>Heart pulse <input id="heart" type="range" min="0" max="1" step=".01" value=".7"></label><label>Bloom <input id="bloom" type="range" min="0" max="1" step=".01" value=".7"></label><label>Scanline <input id="scan" type="range" min="0" max="1" step=".01" value=".2"></label><label>Field density <input id="density" type="range" min="0" max="1" step=".01" value=".25"></label><button id="pause">Pause</button><pre id="telemetry">Waiting for live renderer...</pre></aside></main><script>
let paused=false,serial=0;async function update(){try{let r=await fetch('/api/state');let s=await r.json();document.querySelector('#telemetry').textContent=JSON.stringify(s,null,2);if(serial!==s.serial){serial=s.serial;document.querySelector('#frame').src='/frame.png?rev='+serial;}}catch(e){document.querySelector('#telemetry').textContent=e.message}}setInterval(update,400);update();
for(const e of document.querySelectorAll('input,select'))e.addEventListener('input',async()=>{const v=e.tagName==='SELECT'?e.value:Number(e.value);await fetch('/api/control',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({[e.id]:v})})});
document.querySelector('#pause').onclick=async()=>{paused=!paused;await fetch('/api/control',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({paused})});document.querySelector('#pause').textContent=paused?'Resume':'Pause'};
</script></body></html>'''
ALLOWED={'mode','head','wave','look','heart','bloom','scan','density','yaw','distance','paused'}
NUMERICS={'head':(-1,1),'wave':(0,1),'look':(-1,1),'heart':(0,1),'bloom':(0,1),'scan':(0,1),'density':(0,1),'yaw':(-3.2,3.2),'distance':(2.4,10)}
MODES={'idle','wave','greet','scan','focus','rest','spin'}
class State:
 def __init__(self,size=(540,700),fps=5):
  self.size=size;self.fps=fps;self.lock=threading.Lock();self.controls={'mode':'idle','head':0.,'wave':0.,'look':0.,'heart':.7,'bloom':.7,'scan':.2,'density':.25,'yaw':.45,'distance':6.0,'paused':False}
  self.latest=b'';self.latest_sha='';self.start=time.monotonic();self.frame=0;self.time=0;self.last={'status':'initializing'};self.running=True;self.forest_last={'status':'warming'};self.operator_source='synthetic-demo'
 def set(self,data):
  if not isinstance(data,dict) or not data or len(data)>len(ALLOWED):raise ValueError('Expected nonempty control object')
  result={}
  for key,v in data.items():
   if key not in ALLOWED:raise ValueError('Unknown operator control '+str(key)[:40])
   if key in NUMERICS:
    lo,hi=NUMERICS[key]
    if type(v) not in (float,int) or not math.isfinite(v) or v<lo or v>hi:raise ValueError('Value out of range')
   elif key=='mode':
    if not isinstance(v,str) or v not in MODES:raise ValueError('Unrecognized mode')
   elif key=='paused':
    if type(v)is not bool:raise ValueError('Expected boolean')
   result[key]=v
  with self.lock:self.controls.update(result);self.operator_source='human-control'
  return result
 def render_loop(self):
  renderer=Renderer(self.size);forest=Overseer(max_particles=80);started=time.monotonic();last=started
  while self.running:
   with self.lock:c=self.controls.copy();source=self.operator_source
   now=time.monotonic();dt=min(.45,max(.001,now-last));last=now
   if not c['paused']:
    self.time+=dt
    fc={'source':source,'rgb':[.4+.5*c['heart'],.3+.4*c['bloom'],.1+.4*c['density']],
        'look_x':c['head'],'look_y':c['look'],'speech':1 if c['mode']=='greet' else 0,
        'heart':c['heart'],'drive_load':c['wave'],'density':c['density'],'diffusion':.5,
        'occlusion':.7,'pose':'speaking' if c['mode']=='greet' else 'idle','scene_epoch':0}
    fstate=forest.step(dt,fc)
    self.forest_last={'gene':fstate['chromatic']['dominant'],'rgb':fstate['chromatic']['blend_rgb'],
      'q_code':fstate['chromatic']['q_code'],'monochrome_emergent':fstate['chromatic']['monochrome_emergent'],
      'ripple_events':sum(v['count'] for v in fstate['chromatic']['profiles'].values()),
      'field_mean_density':fstate['light_field']['mean_density'],'source':source}
   if self.forest_last.get('rgb') is not None:c['gene_rgb']=self.forest_last['rgb']
   im=renderer.frame(self.time,c,post=True);stream=io.BytesIO();im.save(stream,format='PNG');b=stream.getvalue()
   with self.lock:self.latest=b;self.latest_sha=hashlib.sha256(b).hexdigest();self.frame+=1;self.last=renderer.last_stats
   sleep=max(0,1/self.fps-(time.monotonic()-now));time.sleep(sleep)

class Handler(BaseHTTPRequestHandler):
 def senddata(self,b,code=200,ctype='application/json',cache='no-store'):
  self.send_response(code);self.send_header('Content-Type',ctype);self.send_header('Content-Length',str(len(b)));self.send_header('Cache-Control',cache);self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(b)
 def do_GET(self):
  path=self.path.split('?')[0]
  if path=='/':return self.senddata(PAGE.encode(),ctype='text/html;charset=utf-8')
  if path=='/frame.png':
   with self.server.state.lock:b=self.server.state.latest
   return self.senddata(b,200 if b else 503,'image/png' if b else 'text/plain')
  if path=='/api/state':
   s=self.server.state
   with s.lock:r={'state':'live' if s.latest else 'warming','serial':s.frame,'pose':s.controls,'render_ms':s.last.get('render_ms'),'image_sha256':s.latest_sha,'simulated_reality':True,'model_checkpoint_connected':False,'renderer':'VTK 3D EGL','operator':'human-control','fps_requested':s.fps,'forest':s.forest_last}
   return self.senddata(json.dumps(r).encode())
  return self.senddata(b'Not Found',404,'text/plain')
 def do_POST(self):
  if self.path!='/api/control':return self.senddata(b'Not Found',404,'text/plain')
  if self.headers.get('Content-Type','').split(';')[0].strip()!='application/json':return self.senddata(b'JSON required',415,'text/plain')
  try:
   count=int(self.headers.get('Content-Length','0'))
   if count<2 or count>4096:raise ValueError('Payload size invalid')
   data=json.loads(self.rfile.read(count));accepted=self.server.state.set(data)
  except (ValueError,TypeError,json.JSONDecodeError) as e:return self.senddata(json.dumps({'error':str(e)}).encode(),400)
  return self.senddata(json.dumps({'accepted':accepted,'source':'human-control'}).encode())
 def log_message(self,fmt,*args):pass

def serve(port=8766,size=(540,700),fps=5):
 s=State(size,fps);srv=ThreadingHTTPServer(('127.0.0.1',port),Handler);srv.state=s
 th=threading.Thread(target=s.render_loop,daemon=True);th.start()
 print(json.dumps({'listen':f'http://127.0.0.1:{srv.server_port}','operator':'loopback-only','renderer':'VTK EGL 3D','max_fps_requested':fps}),flush=True)
 try:srv.serve_forever()
 finally:s.running=False;srv.shutdown();srv.server_close()
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8766);p.add_argument('--fps',type=int,default=5);p.add_argument('--width',type=int,default=540);p.add_argument('--height',type=int,default=700);args=p.parse_args()
 assert 1<=args.fps<=20 and 1<=args.width<=1920 and 1<=args.height<=1920 and 1024<=args.port<=65535
 serve(args.port,(args.width,args.height),args.fps)
