"""Read-only adapter from explicit, existing Kokoro Mesh v0.3 / Lumina v0.5 packets.
Does not fabricate language-model states, send network actions or mutate Kokoro.
"""
from __future__ import annotations
import pathlib,sys,math
BASE=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'sources'))
from forest_v05.forest import control

def map_mesh_packet(mesh_packet):
 if not isinstance(mesh_packet,dict):raise TypeError('Expected Kokoro Mesh packet')
 explicit=mesh_packet.get('lumina_forest_control')
 if explicit is None:return {'status':'unavailable','reason':'No explicit Lumina control; cannot infer a live Kokoro state'}
 c=control(explicit)  # Preserved v0.5 validation, no made-up channels.
 # Mapping converts numerical controls into operator animations, not claimed emotions.
 pose_map={'idle':'idle','listening':'focus','speaking':'greet','thinking':'scan','rest':'rest'}
 selected=pose_map[c['pose']]
 mapped={'mode':selected,'head':c['look_x'],'look':c['look_y'],'wave':c['drive_load'],
         'heart':c['heart'],'density':c['density'],'bloom':c['diffusion'],'scan':c['occlusion']}
 return {'status':'mapped','source':c['source'],'fact_status':'no-new-facts','kokoro_checkpoint_accessed':False,
         'rig_operator_controls':mapped,'sensors_verified':False,'requires_user_live_bridge':True}
