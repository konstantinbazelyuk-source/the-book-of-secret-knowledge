"""Create a genuine skinned, animated glTF 2.0 GLB and WebGL source arrays.
New procedural 3D artwork. Earlier user image used solely as a visual reference.
No machine inference, model checkpoint, or proprietary asset is involved.
"""
from __future__ import annotations
import math, json, base64, struct, pathlib, hashlib
import numpy as np
import trimesh
from trimesh.transformations import quaternion_matrix

HERE = pathlib.Path(__file__).resolve().parents[1]
OUT = HERE / 'web'
OUT.mkdir(parents=True,exist_ok=True)
# Engine coordinates: +Y up, +Z forward; glTF uses Y up.
BONES = [
('root',None,(0,0,0)),('pelvis','root',(0,1.02,0)),('spine','pelvis',(0,1.39,0)),
('chest','spine',(0,1.94,0)),('neck','chest',(0,2.34,0)),('head','neck',(0,2.57,0)),
('arm_L','chest',(-.47,2.16,0)),('forearm_L','arm_L',(-.72,1.71,.01)),('hand_L','forearm_L',(-.86,1.28,.04)),
('arm_R','chest',(.47,2.16,0)),('forearm_R','arm_R',(.72,1.71,.01)),('hand_R','forearm_R',(.86,1.28,.04)),
('thigh_L','pelvis',(-.20,.95,0)),('shin_L','thigh_L',(-.23,.50,.015)),('foot_L','shin_L',(-.23,.12,.13)),
('thigh_R','pelvis',(.20,.95,0)),('shin_R','thigh_R',(.23,.50,.015)),('foot_R','shin_R',(.23,.12,.13)),
('hair_L','head',(-.23,2.67,-.10)),('hair_R','head',(.23,2.67,-.10)),
]
NAMES=[b[0] for b in BONES]
INDEX={n:i for i,n in enumerate(NAMES)}
REST=np.array([b[2] for b in BONES],dtype='float64')
PARENTS=[INDEX.get(b[1],-1) for b in BONES]
MAT={
'shell':('#e0dbd4',.28,.35,(0,0,0)),
'graphite':('#252b39',.70,.27,(0,0,0)),
'chrome':('#8c8a94',.86,.20,(0,0,0)),
'rose':('#c7a1a0',.44,.32,(0,0,0)),
'hair':('#cab5ad',.52,.32,(0,0,0)),
'hair_dark':('#8b6e76',.60,.36,(0,0,0)),
'eye':('#331e34',.25,.13,(0,0,0)),
'iris':('#f79dc1',.2,.2,(0,0,0)),
'ruby':('#ff4c9c',.08,.22,(.9,.05,.24)),
'cyan':('#58dfea',.08,.24,(.02,.45,.70)),
'gold':('#c7a776',.7,.35,(0,0,0)),
}
def rgb(hex):
 return [int(hex[x:x+2],16)/255 for x in (1,3,5)]
GROUPS={n:[] for n in MAT}
def piece(mesh, bone, material, glow=0.,secondary=None,second_ratio=0.):
 """Add vertices in world rest position, weighted to real glTF skin joints.
 Optional secondary weights make smooth two-bone linear-blend skinning.
 """
 assert bone in INDEX and material in MAT
 verts=np.asarray(mesh.vertices,dtype=np.float32)
 norms=np.asarray(mesh.vertex_normals,dtype=np.float32)
 faces=np.asarray(mesh.faces,dtype=np.uint32)
 col=rgb(MAT[material][0]); boneidx=INDEX[bone]
 weights=np.zeros((len(verts),4),dtype='float32');weights[:,0]=1.0
 joints=np.zeros((len(verts),4),dtype='uint16');joints[:,0]=boneidx
 if secondary is not None and np.any(np.asarray(second_ratio)>0):
  r=np.clip(second_ratio,0,1);weights[:,0]=1-r;weights[:,1]=r;joints[:,1]=INDEX[secondary]
 glowarr=np.full(len(verts),glow,dtype=np.float32)
 GROUPS[material].append((verts,norms,faces,joints,weights,glowarr))
def sphere(center,scale,material,bone,subdiv=2,glow=0.):
 m=trimesh.creation.icosphere(subdivisions=subdiv,radius=1)
 m.apply_scale(scale);m.apply_translation(center);piece(m,bone,material,glow)
def tube(a,b,r1,r2,material,bone,sections=16,glow=0.,secondary=None):
 """Conical cylinder between world-space endpoints."""
 a=np.array(a,dtype=float);b=np.array(b,dtype=float)
 d=b-a; L=np.linalg.norm(d);d/=L
 axis=np.array([0,1,0],dtype=float)
 v=np.cross(axis,d);c=float(np.dot(axis,d));s=float(np.linalg.norm(v))
 if s<1e-10: R=np.eye(3) if c>0 else np.diag([1,-1,-1])
 else:
  vx=np.array([[0,-v[2],v[1]],[v[2],0,-v[0]],[-v[1],v[0],0]])
  R=np.eye(3)+vx+vx@vx*((1-c)/(s*s))
 ring=[]
 for y,r in [(-L/2,r1),(L/2,r2)]:
  for i in range(sections):
   t=2*math.pi*i/sections;ring.append([r*math.cos(t),y,r*math.sin(t)])
 faces=[]
 for i in range(sections):
  j=(i+1)%sections;faces.extend([(i,j,sections+j),(i,sections+j,sections+i)])
 ring.extend([[0,-L/2,0],[0,L/2,0]])
 for i in range(sections):
  j=(i+1)%sections;faces.extend([(2*sections,j,i),(2*sections+1,sections+i,sections+j)])
 ring=np.array(ring,dtype='float64')@R.T+(a+b)/2
 m=trimesh.Trimesh(vertices=ring,faces=faces,process=False)
 blend=np.clip((np.asarray(m.vertices)-a)@d/L-.65,0,.35) if secondary is not None else 0.
 piece(m,bone,material,glow,secondary=secondary,second_ratio=blend)
def capsule(a,b,r,material,bone,glow=0.):
 sphere(a,(r,r,r),material,bone,subdiv=1,glow=glow)
 sphere(b,(r,r,r),material,bone,subdiv=1,glow=glow)
 tube(a,b,r,r,material,bone,glow=glow)
def torus(center,R=.3,r=.017,material='cyan',bone='root',segments=40,rings=8,glow=0.):
 V=[];F=[]
 cx,cy,cz=center
 for i in range(segments):
  phi=2*math.pi*i/segments
  for j in range(rings):
   th=2*math.pi*j/rings
   V.append([cx+(R+r*math.cos(th))*math.cos(phi),cy+r*math.sin(th),cz+(R+r*math.cos(th))*math.sin(phi)])
 for i in range(segments):
  ii=(i+1)%segments
  for j in range(rings):
   jj=(j+1)%rings
   a=i*rings+j;b=ii*rings+j;c=ii*rings+jj;d=i*rings+jj
   F.extend([(a,b,d),(b,c,d)])
 piece(trimesh.Trimesh(vertices=V,faces=F,process=False),bone,material,glow)
# Futuristic synthetic android built entirely from original 3D geometry.
# Root support and floating platform.
sphere((0,-.24,0),(.80,.10,.63),'graphite','root',2)
torus((0,-.115,0),.67,.022,'cyan','root',48,8,1.)
torus((0,-.102,0),.48,.015,'rose','root',48,8,.2)
# Pelvis and torso panels.
sphere((0,1.09,0),(.35,.24,.24),'graphite','pelvis',2)
sphere((0,1.16,.07),(.32,.18,.22),'shell','pelvis',2)
sphere((0,1.59,0),(.30,.43,.22),'graphite','spine',2)
sphere((0,1.82,.035),(.42,.35,.245),'shell','chest',3)
sphere((0,1.83,.24),(.26,.16,.035),'rose','chest',2)
# core couplers + heart shape approximate paired lobes and tip.
torus((0,1.92,.276),.125,.017,'gold','chest',36,7,.2)
sphere((-.052,1.94,.298),(.075,.065,.035),'ruby','chest',2,1)
sphere((.052,1.94,.298),(.075,.065,.035),'ruby','chest',2,1)
sphere((0,1.89,.300),(.075,.082,.031),'ruby','chest',2,1)
# mechanical exposed collar and neck.
capsule((0,2.21,0),(0,2.43,0),.105,'graphite','neck')
sphere((0,2.37,.00),(.16,.08,.145),'chrome','neck')
# Head human-ish original sculpture, face distinct from old image; no texture.
sphere((0,2.72,0),(.245,.33,.228),'shell','head',3)
sphere((0,2.795,-.10),(.265,.34,.225),'hair','head',2)
# Hair cap with side locks, geometry avoids old image sampling.
for s in (-1,1):
 tube((s*.20,2.90,-.07),(s*.29,2.42,-.14),.10,.07,'hair','hair_L' if s<0 else 'hair_R',12)
 tube((s*.25,2.42,-.14),(s*.24,2.06,-.10),.075,.035,'hair_dark','hair_L' if s<0 else 'hair_R',10)
 # brows eyelids eyes, facial detailing
 sphere((s*.104,2.760,.211),(.082,.038,.022),'eye','head',2)
 sphere((s*.107,2.762,.229),(.039,.028,.014),'iris','head',2,.2)
 sphere((s*.108,2.763,.243),(.014,.023,.009),'eye','head',2)
 sphere((s*.09,2.833,.215),(.075,.014,.010),'hair_dark','head',1)
 sphere((s*.25,2.68,.02),(.035,.12,.095),'chrome','head',2)
 sphere((s*.265,2.677,.08),(.02,.045,.025),'cyan','head',1,1)
# Nose lip and forehead ornament.
sphere((0,2.692,.233),(.031,.058,.038),'shell','head',2)
sphere((0,2.598,.214),(.064,.008,.011),'rose','head',2)
sphere((0,2.91,.204),(.03,.012,.011),'gold','head',1)
# Procedural strand-based long hair. No 2D billboard or imported texture.
# Curved multi-segment ribbons visually convey the earlier long-haired concept.
for s,label in ((-1,'L'),(1,'R')):
 for j in range(11):
  side= s*(.075+j*.029)
  depth= -.21-.030*math.sin(j*.7)
  ybase=2.98-.02*(j%3)
  bend=.025+ .07*math.sin(j*1.12)
  path=[(side*.75,ybase,depth*.55),(side,2.68,depth-.07),
        (side+s*.04,2.32,depth-.11),(side+s*bend,1.90-(j%4)*.065,depth-.01)]
  material='hair' if j%4 else 'hair_dark'
  for k in range(3):
   tube(path[k],path[k+1],.029-k*.007,.023-k*.006,material,'hair_'+label,8)
# Polished neck and clavicle seams.
for s in (-1,1):
 sphere((s*.23,2.19,.185),(.095,.035,.023),'gold','chest',1)
 tube((s*.18,2.23,.21),(s*.32,2.04,.19),.015,.013,'chrome','chest',10)
# Three protective abdominal ribs and vent channels.
for y,sc in ((1.50,.80),(1.61,.95),(1.71,1.0)):
 sphere((0,y,.215),(.25*sc,.031,.021),'chrome','spine',2)
for s in (-1,1):
 for y in (1.38,1.52,1.66):
  sphere((s*.27,y,.10),(.033,.041,.04),'rose','spine',1)
# tapered fringe tips.
for x in (-.17,-.095,.06,.18):
 tube((x,2.98,.05),(x+.03,2.80,.21),.057,.011,'hair','head',10)
# Limb structural paired servo joints; symmetric.
for sign,label in [(-1,'L'),(1,'R')]:
 a=tuple(REST[INDEX['arm_'+label]]);e=tuple(REST[INDEX['forearm_'+label]]);h=tuple(REST[INDEX['hand_'+label]])
 sphere(a,(.19,.19,.19),'chrome','arm_'+label)
 sphere(a,(.135,.135,.15),'graphite','arm_'+label)
 tube(a,e,.116,.096,'shell','arm_'+label,20,secondary='forearm_'+label)
 sphere(e,(.13,.13,.13),'chrome','forearm_'+label)
 tube(e,h,.100,.075,'shell','forearm_'+label,20,secondary='hand_'+label)
 sphere(h,(.090,.11,.07),'chrome','hand_'+label)
 sphere((h[0],h[1]-.09,h[2]+.01),(.087,.12,.048),'shell','hand_'+label)
 for finger in range(3):
  xx=h[0]+sign*(finger-1)*.041
  tube((xx,h[1]-.1,h[2]),(xx+sign*.012,h[1]-.24+0.03*abs(finger-1),h[2]+.04),.019,.010,'chrome','hand_'+label,8)
 # thigh and shin and feet
 hip=tuple(REST[INDEX['thigh_'+label]]);knee=tuple(REST[INDEX['shin_'+label]]);foot=tuple(REST[INDEX['foot_'+label]])
 sphere(hip,(.20,.16,.18),'graphite','thigh_'+label)
 tube(hip,knee,.17,.125,'shell','thigh_'+label,22,secondary='shin_'+label)
 sphere(knee,(.13,.14,.13),'chrome','shin_'+label)
 tube(knee,(foot[0],.17,foot[2]-.07),.126,.080,'shell','shin_'+label,20,secondary='foot_'+label)
 sphere((foot[0],.04,foot[2]+.09),(.125,.09,.25),'graphite','foot_'+label)
 sphere((foot[0],.12,foot[2]+.07),(.105,.11,.19),'shell','foot_'+label)
 torus((hip[0],hip[1],.13),.12,.012,'rose','thigh_'+label,20,6,.12)
# Additional rear spine disks.
for y in (1.35,1.52,1.70):sphere((0,y,-.233),(.13,.040,.020),'chrome','spine',1)

# glTF pack into one skin attached mesh with multiple material primitives.
blob=bytearray();views=[];accs=[]
def aligned_data(a,target=None):
 b=a.tobytes();off=len(blob);blob.extend(b);blob.extend(b'\0'*((-len(blob))%4));views.append({'buffer':0,'byteOffset':off,'byteLength':len(b),**({'target':target} if target else {})});return len(views)-1
DTYPE={np.dtype('float32'):5126,np.dtype('uint16'):5123,np.dtype('uint32'):5125,np.dtype('uint8'):5121}
def accessor(arr,type_,target=None,bounds=False):
 arr=np.ascontiguousarray(arr)
 bv=aligned_data(arr,target)
 o={'bufferView':bv,'componentType':DTYPE[arr.dtype],'count':len(arr),'type':type_}
 if bounds and len(arr):o.update({'min':arr.min(axis=0).astype(float).tolist(),'max':arr.max(axis=0).astype(float).tolist()})
 accs.append(o);return len(accs)-1
prim=[];webdat={n:[] for n in ('pos','normal','color','joints','weights','glow','indices')}
vertexoffset=0
for name,pieces in GROUPS.items():
 if not pieces:continue
 ps=[];ns=[];fs=[];js=[];ws=[];gs=[];off=0
 for p,n,f,j,w,g in pieces:
  ps.append(p);ns.append(n);fs.append(f+off);js.append(j);ws.append(w);gs.append(g);off+=len(p)
 P=np.concatenate(ps); N=np.concatenate(ns); F=np.concatenate(fs); J=np.concatenate(js); W=np.concatenate(ws); G=np.concatenate(gs)
 # PBR transparent? vertex color includes actual diffuse from material; emissive glTF material uses emissiveFactor.
 material_idx=list(MAT).index(name)
 prim.append({'attributes':{'POSITION':accessor(P,'VEC3',34962,True),'NORMAL':accessor(N,'VEC3',34962),'JOINTS_0':accessor(J,'VEC4',34962),'WEIGHTS_0':accessor(W,'VEC4',34962)},'indices':accessor(F.reshape(-1),'SCALAR',34963),'material':material_idx})
 webdat['pos'].append(P);webdat['normal'].append(N);webdat['joints'].append(J);webdat['weights'].append(W);webdat['glow'].append(G)
 webdat['color'].append(np.tile(np.array(rgb(MAT[name][0]),dtype='float32'),(len(P),1)))
 webdat['indices'].append(F.reshape(-1)+vertexoffset);vertexoffset+=len(P)

nodes=[]
for i,(name,parent,pos) in enumerate(BONES):
 local=np.array(pos)-(REST[parent] if isinstance(parent,int) else REST[INDEX[parent]] if parent else np.zeros(3))
 n={'name':name,'translation':local.astype(float).tolist()}
 child=[j for j,p in enumerate(PARENTS) if p==i]
 if child:n['children']=child
 nodes.append(n)
mesh_node=len(nodes)
nodes.append({'name':'Kokoro_Skin_Mesh','mesh':0,'skin':0})
# inverse bind matrices: column-major 4x4 flattened; translation only.
ibms=[]
for pos in REST:
 m=np.eye(4,dtype='float32');m[0,3]=-pos[0];m[1,3]=-pos[1];m[2,3]=-pos[2]
 ibms.append(m.T.flatten())
ibm_idx=accessor(np.array(ibms,dtype='float32'),'MAT4')
# Quaternions for glTF animation. Idle - head yaw, upper arms shoulder sway, heart body.
def qaxis(axis,ang):
 v=np.array(axis,dtype='float64');v=v/np.linalg.norm(v)
 return list((v*math.sin(ang/2)).astype(float))+[math.cos(ang/2)]
times=np.array([0.,1.,2.,3.,4.],dtype='float32')
timeacc=accessor(times,'SCALAR',bounds=True)
channels=[];samplers=[]
for bone,axis,amp in [('head',(0,1,0),.12),('chest',(0,0,1),.025),('arm_L',(0,0,1),.08),('arm_R',(0,0,1),-.08),('hair_L',(0,0,1),.05),('hair_R',(0,0,1),-.05)]:
 qs=np.array([qaxis(axis,amp*math.sin(t*math.pi/2)) for t in times],dtype='float32')
 qidx=accessor(qs,'VEC4');samplers.append({'input':timeacc,'output':qidx,'interpolation':'LINEAR'});channels.append({'sampler':len(samplers)-1,'target':{'node':INDEX[bone],'path':'rotation'}})
materials=[{'name':name,'pbrMetallicRoughness':{'baseColorFactor':rgb(tup[0])+[1.0],'metallicFactor':tup[1],'roughnessFactor':tup[2]},'emissiveFactor':list(tup[3]),'doubleSided':True} for name,tup in MAT.items()]
gltf={'asset':{'version':'2.0','generator':'Kokoro Lumina 3D Alpha authored geometry'},'scene':0,'scenes':[{'nodes':[0,mesh_node]}],'nodes':nodes,'meshes':[{'name':'Kokoro_Procedural_Android_Skinned','primitives':prim}],'skins':[{'name':'Kokoro_Body_Rig','joints':list(range(len(BONES))),'skeleton':0,'inverseBindMatrices':ibm_idx}],'accessors':accs,'bufferViews':views,'buffers':[{'byteLength':len(blob)}],'materials':materials,'animations':[{'name':'Ripple_Idle','samplers':samplers,'channels':channels}]}
jsonbytes=json.dumps(gltf,separators=(',',':')).encode('utf8');jsonbytes+=b' '*((-len(jsonbytes))%4)
assert len(blob)%4==0
size=12+8+len(jsonbytes)+8+len(blob)
glb=struct.pack('<4sII',b'glTF',2,size)+struct.pack('<I4s',len(jsonbytes),b'JSON')+jsonbytes+struct.pack('<I4s',len(blob),b'BIN\0')+bytes(blob)
(OUT/'Kokoro_Lumina_Alpha_v0_6.glb').write_bytes(glb)
# Browser arrays are base64, no original image content.
arrays={}
for key,a in webdat.items():
 if not a:continue
 A=np.concatenate(a).astype('uint32' if key=='indices' else 'uint16' if key=='joints' else 'float32')
 arrays[key]={'dtype':str(A.dtype),'components':4 if key in ('joints','weights') else 3 if key in ('pos','normal','color') else 1,'data':base64.b64encode(A.tobytes()).decode('ascii')}
meta={'bones':[{'name':n,'parent':PARENTS[i],'rest':list(REST[i])} for i,n in enumerate(NAMES)],'arrays':arrays,'totalVertices':vertexoffset,'totalTriangles':sum(len(x)/3 for x in webdat['indices']),'sha256_glb':hashlib.sha256(glb).hexdigest(),'source':'Original procedural 3D mesh, no poster pixels/texture used'}
(OUT/'model_data.js').write_text('window.KOKORO_3D_MODEL='+json.dumps(meta,separators=(',',':'))+';\n')
(HERE/'results'/'model_metrics.json').write_text(json.dumps({k:v for k,v in meta.items() if k!='arrays'},indent=2))
print(json.dumps({'glb_bytes':len(glb),'vertex_count':vertexoffset,'triangle_count':meta['totalTriangles'],'bones':len(BONES),'sha256':meta['sha256_glb']}))
