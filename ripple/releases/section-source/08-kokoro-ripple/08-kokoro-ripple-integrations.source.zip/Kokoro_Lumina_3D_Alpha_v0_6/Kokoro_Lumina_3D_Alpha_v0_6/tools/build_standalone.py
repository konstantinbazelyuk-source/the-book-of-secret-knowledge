from pathlib import Path
import base64
import re
base=Path(__file__).resolve().parents[1]
page=(base/'web/index.html').read_text()
repls={'model_data.js':'web/model_data.js','../sources/ripple_core_v0_1.js':'sources/ripple_core_v0_1.js','../sources/ripple_q_port_v0_7.js':'sources/ripple_q_port_v0_7.js','runtime.js':'web/runtime.js'}
fallback=base64.b64encode((base/'results/actual_3d_wave.gif').read_bytes()).decode('ascii')
page=page.replace('<script src="runtime.js"></script>','<script>window.LUMINA_VERIFIED_FALLBACK="data:image/gif;base64,'+fallback+'";</script><script src="runtime.js"></script>')
for src,path in repls.items():
 tag=f'<script src="{src}"></script>'
 assert page.count(tag)==1,tag
 script=(base/path).read_text().replace('</script','<\\/script')
 page=page.replace(tag,'<script>\n'+script+'\n</script>')
path=base/'Kokoro_Lumina_3D_Offline_Alpha.html'
path.write_text(page)
print('standalone bytes:',path.stat().st_size)
