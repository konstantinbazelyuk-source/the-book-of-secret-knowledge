"""ACTUAL 3D geometry skinning and VTK-EGL offscreen rendering.
Does not require Blender, GPU access or remote model inference.
May use software EGL depending on runtime.
"""
from __future__ import annotations
import os,math,json,base64,pathlib,time,threading,io
os.environ.setdefault('VTK_DEFAULT_RENDER_WINDOW_OFFSCREEN','1')
import numpy as np
from PIL import Image, ImageFilter, ImageEnhance
import vtk
from vtk.util.numpy_support import numpy_to_vtk, vtk_to_numpy, numpy_to_vtkIdTypeArray
BASE=pathlib.Path(__file__).resolve().parents[1]

def load_model():
 s=(BASE/'web/model_data.js').read_text().strip();assert s.startswith('window.KOKORO_3D_MODEL=')
 data=json.loads(s[len('window.KOKORO_3D_MODEL='):].rstrip(';'))
 def decoded(key):
  d=data['arrays'][key];dtype={'float32':np.float32,'uint16':np.uint16,'uint32':np.uint32}[d['dtype']]
  out=np.frombuffer(base64.b64decode(d['data']),dtype=dtype)
  return out.reshape(-1,d['components']) if d['components']>1 else out
 return data,{k:decoded(k) for k in data['arrays']}

def rot(axis,ang):
 c=math.cos(ang);s=math.sin(ang);m=np.eye(4)
 if axis=='x':m[:3,:3]=[[1,0,0],[0,c,-s],[0,s,c]]
 elif axis=='y':m[:3,:3]=[[c,0,s],[0,1,0],[-s,0,c]]
 else:m[:3,:3]=[[c,-s,0],[s,c,0],[0,0,1]]
 return m

def trans(x,y,z):
 m=np.eye(4);m[:3,3]=[x,y,z];return m

def pose(bones,t,controls):
 mode=controls.get('mode','idle');wave=controls.get('wave',0);head=controls.get('head',0);look=controls.get('look',0)
 angles={name:(0,0,0) for name in [b['name'] for b in bones]}
 a=lambda x,xyz:angles.__setitem__(x,xyz)
 a('root',(0,t*.35 if mode=='spin' else 0,0))
 a('pelvis',(0,0,.012*math.sin(t*.6)))
 a('chest',(0,0,.012*math.sin(t*2*math.pi/4.3)))
 a('head',(.035*math.sin(t*.7),.22*head+.1*math.sin(t*.8)+(.27*math.sin(t*1.3) if mode=='scan' else 0),.05*look))
 lift=max(wave,1 if mode in ('wave','greet') else 0)
 a('arm_R',(0,0,1.38*lift+.045*math.sin(t*.9)))
 a('forearm_R',(0,0,-.55*lift+.35*math.sin(t*4.4)*lift))
 a('arm_L',(0,0,-.12*(mode=='greet')))
 a('hair_L',(0,0,.045*math.sin(t*1.3)))
 a('hair_R',(0,0,-.04*math.sin(t*1.1)))
 if mode=='focus':a('head',(-.09,.12+.15*head,0))
 if mode=='rest':a('head',(-.06,0,-.08));a('arm_R',(0,0,-.04))
 world=[]
 for b in bones:
  p=b['parent'];parent=[0,0,0] if p<0 else bones[p]['rest']
  delta=np.array(b['rest'])-parent
  v=angles[b['name']];mat=trans(*delta)@rot('y',v[1])@rot('z',v[2])@rot('x',v[0]);world.append(mat if p<0 else world[p]@mat)
 skin=[w@trans(*(-np.array(b['rest']))) for w,b in zip(world,bones)]
 return np.array(skin)

def apply_skin(vertices,normals,joints,weights,skin):
 out=np.zeros_like(vertices,dtype=np.float64);nout=np.zeros_like(normals,dtype=np.float64)
 for k in range(4):
  ids=joints[:,k];w=weights[:,k,None].astype('float64')
  if np.count_nonzero(w)==0:continue
  rotm=skin[ids,:3,:3];p=skin[ids,:3,3]
  out+=w*(np.einsum('nij,nj->ni',rotm,vertices)+p)
  nout+=w*np.einsum('nij,nj->ni',rotm,normals)
 nout/=np.maximum(np.linalg.norm(nout,axis=1,keepdims=True),1e-8)
 return out.astype('float32'),nout.astype('float32')

class Renderer:
 def __init__(self,size=(540,700)):
  self.size=size;self.data,self.a=load_model();self.lock=threading.RLock();self.camera_yaw=.45
  self.renderer=vtk.vtkRenderer();self.renderer.SetBackground(.025,.042,.069)
  self.window=vtk.vtkRenderWindow();self.window.SetOffScreenRendering(1);self.window.AddRenderer(self.renderer);self.window.SetSize(*size)
  self.poly=vtk.vtkPolyData();self.points=vtk.vtkPoints();self.poly.SetPoints(self.points)
  indices=self.a['indices'].astype('int64').reshape((-1,3));n=len(indices)
  offsets=np.arange(0,3*n+1,3,dtype=np.int64)
  ca=vtk.vtkCellArray();ca.SetData(numpy_to_vtkIdTypeArray(offsets,deep=True),numpy_to_vtkIdTypeArray(indices.reshape(-1),deep=True));self.poly.SetPolys(ca)
  self.vertex_colors=(np.clip(self.a['color'],0,1)*255).astype('uint8')
  vtkcolors=numpy_to_vtk(self.vertex_colors,deep=True,array_type=vtk.VTK_UNSIGNED_CHAR);vtkcolors.SetName('Vertex RGB');vtkcolors.SetNumberOfComponents(3);self.vtkcolors=vtkcolors
  self.poly.GetPointData().SetScalars(vtkcolors)
  self.normals=vtk.vtkFloatArray();self.normals.SetNumberOfComponents(3);self.normals.SetName('Normals')
  self.poly.GetPointData().SetNormals(self.normals)
  self.mapper=vtk.vtkPolyDataMapper();self.mapper.SetInputData(self.poly);self.mapper.ScalarVisibilityOn();self.mapper.SetScalarModeToUsePointData()
  actor=vtk.vtkActor();actor.SetMapper(self.mapper);actor.GetProperty().SetInterpolationToPhong();actor.GetProperty().SetSpecular(.58);actor.GetProperty().SetSpecularPower(37);actor.GetProperty().SetAmbient(.32);actor.GetProperty().SetDiffuse(.77)
  self.renderer.AddActor(actor)
  self.renderer.SetUseDepthPeeling(False)
  l=vtk.vtkLight();l.SetLightTypeToSceneLight();l.SetPosition(3,6,5);l.SetFocalPoint(0,1.5,0);l.SetIntensity(1.5);self.renderer.AddLight(l)
  l2=vtk.vtkLight();l2.SetPosition(-3,3,-3);l2.SetIntensity(.7);l2.SetColor(.54,.86,1);self.renderer.AddLight(l2)
  self.camera=self.renderer.GetActiveCamera();self.camera.SetViewUp(0,1,0);self.camera.SetViewAngle(40);self.camera.SetFocalPoint(0,1.45,0)
  self.last_stats={}
 def frame(self,t=0,controls=None,post=True):
  controls=controls or {'mode':'idle'}
  with self.lock:
   now=time.perf_counter();sk=pose(self.data['bones'],t,controls)
   vertices,normals=apply_skin(self.a['pos'],self.a['normal'],self.a['joints'],self.a['weights'],sk)
   self.points.SetData(numpy_to_vtk(vertices,deep=True));self.normals.DeepCopy(numpy_to_vtk(normals,deep=True));self.poly.Modified()
   # Ripple-derived chromatic output affects actual luminous 3D surface pixels.
   gene=controls.get('gene_rgb')
   if gene is not None:
    gc=np.array(gene,dtype='float64')
    if gc.shape!=(3,) or not np.isfinite(gc).all() or not (0<=gc).all() or not (gc<=255).all():raise ValueError('Invalid forest chromatic data')
    glow=self.a['glow'].reshape((-1,1)).astype('float64')
    power=max(0.,min(1.,float(controls.get('heart',.6))))*(.65+.35*math.sin(t*5.4))
    overlay=np.clip(self.vertex_colors.astype('float64')*(1-.44*glow*power)+gc*(.44*glow*power),0,255).astype('uint8')
    self.vtkcolors.DeepCopy(numpy_to_vtk(overlay,deep=True,array_type=vtk.VTK_UNSIGNED_CHAR));self.vtkcolors.Modified()
   yaw=float(controls.get('yaw',self.camera_yaw));dist=float(controls.get('distance',6.0))
   self.camera.SetPosition(math.sin(yaw)*dist,1.85,math.cos(yaw)*dist)
   self.camera.SetFocalPoint(0,1.45,0);self.renderer.ResetCameraClippingRange()
   self.window.Render()
   filt=vtk.vtkWindowToImageFilter();filt.SetInput(self.window);filt.ReadFrontBufferOff();filt.Update()
   obj=filt.GetOutput();w,h=obj.GetDimensions()[:2]
   rgb=vtk_to_numpy(obj.GetPointData().GetScalars()).reshape(h,w,-1);im=Image.fromarray(np.flipud(rgb[:,:,:3]).copy(),'RGB')
   if post:im=self.post(im,t,controls)
   self.last_stats={'render_ms':round((time.perf_counter()-now)*1000,3),'tris':int(self.data['totalTriangles']),'vertices':int(self.data['totalVertices']),'mode':controls.get('mode','idle')}
   return im
 @staticmethod
 def post(im,t,controls):
  # CPU compositing is a genuinely executed post-render pass, not an overlay from original artwork.
  density=max(0,min(1,float(controls.get('density',.2))));bloom=max(0,min(1,float(controls.get('bloom',.7))));scan=max(0,min(1,float(controls.get('scan',.16))))
  a=np.asarray(im,dtype='float32')/255
  import cv2
  if bloom:
   v=cv2.GaussianBlur(a,(0,0),3.5)
   a=np.minimum(1,a+bloom*np.maximum(v-.13,0)*.24)
  h,w=a.shape[:2]
  yy,xx=np.mgrid[:h,:w]
  radius=np.sqrt(((xx-w/2)/(w/2))**2+((yy-h/2)/(h/2))**2)
  a*=np.clip(1-.21*radius**2,.45,1)[:,:,None]
  a*=((1-scan*.085*(.5+.5*np.sin(yy*1.35+t*1.5))))[:,:,None]
  return Image.fromarray((np.clip(a,0,1)*255).astype('uint8'),'RGB')

if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--mode',default='idle',choices=['idle','wave','greet','scan','focus','rest','spin']);p.add_argument('--frames',type=int,default=1);p.add_argument('--fps',type=int,default=8);p.add_argument('--width',type=int,default=540);p.add_argument('--height',type=int,default=700);p.add_argument('--out',default=str(BASE/'results'/'render_3d.png'));p.add_argument('--gif',action='store_true');args=p.parse_args()
 assert 1<=args.frames<=600 and 1<=args.fps<=60
 ren=Renderer(size=(args.width,args.height));frames=[];started=time.perf_counter()
 for i in range(args.frames):
  frame=ren.frame(i/args.fps,{'mode':args.mode});frames.append(frame)
  if args.frames>1 and not args.gif:
   out=pathlib.Path(args.out);out.parent.mkdir(parents=True,exist_ok=True);frame.save(out.parent/(out.stem+f'_{i:04d}.png'))
 if args.gif:frames[0].save(args.out,save_all=True,append_images=frames[1:],duration=int(1000/args.fps),loop=0,optimize=True)
 elif args.frames==1:frames[0].save(args.out)
 print(json.dumps({'frames':args.frames,'fps_simulated':args.fps,'duration_s':round(time.perf_counter()-started,2),'last_frame':ren.last_stats,'output':args.out,'renderer':ren.window.GetClassName()}))
