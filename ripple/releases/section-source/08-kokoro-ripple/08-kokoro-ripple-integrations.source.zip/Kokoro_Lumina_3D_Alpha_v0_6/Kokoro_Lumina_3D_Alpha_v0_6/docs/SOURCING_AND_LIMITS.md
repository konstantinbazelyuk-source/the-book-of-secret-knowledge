# Source register, architecture and evidence boundaries

## Original user project sources

Copied **without editing** from `Kokoro_Lumina_Forest_Alpha_v0_5`:

- `sources/forest_v05/forest.py` → original chromatic species, diffusion, overseer and particle-density control
- `sources/forest_v05/ripple_core.py` → original adaptive LIF implementation
- `sources/forest_v05/quaternary.py` → four-state Ripple-Q decoder
- `sources/ripple_core_v0_1.js` → preserved JavaScript v0.1 equations
- `sources/original_ripple_q_v0_7.mjs` → preserved original v0.7 module

New Python/JavaScript code is separate. We do **not** revise the original equations. Rendering is based on signals from the forest, not artificial evidence of subjective experience.

## Source material consulted — implementation is original, no code copied

1. **Khronos, glTF 2.0 normative specification** — PBR materials, `skins`, `joints`, `JOINTS_0`, `WEIGHTS_0`, inverse bind matrices, animation channels and Y-up coordinate conventions. https://registry.khronos.org/glTF/specs/2.0/glTF-2.0.html
2. **Blender Python API 4.4, export_scene / scene construction patterns** — Blender's glTF exporter and automation concepts. https://docs.blender.org/api/4.4/bpy.ops.export_scene.html
3. **Blender official portable installation requirements** — Blender is a desktop program with nontrivial RAM and GPU requirements. https://www.blender.org/download/requirements/
4. **MDN WebGL overview and animation** — GPU shader rendering, `requestAnimationFrame`, framebuffer-based rendering. https://developer.mozilla.org/en-US/docs/Web/API/WebGL_API/Tutorial and https://developer.mozilla.org/en-US/docs/Web/API/WebGL_API/Tutorial/Animating_objects_with_WebGL
5. **Adobe Mixamo FAQ** — additional path for third-party humanoid animations. Requires user account and a compatible character upload. *Not integrated, downloaded or tested.* https://helpx.adobe.com/creative-cloud/faq/mixamo-faq.html

## Actual architecture

`human control / future explicit Kokoro packet → validator → Ripple Forest (chromatic rate + Ripple-Q / diffusion state) → Overseer state → 20-joint pose matrices → linear blend skinning → VTK/EGL 3D render → PIL/OpenCV post pass → successive PNG bytes → local operator browser`.

Alternative unverified GPU browser path: `same procedural geometry → native WebGL2 vertex-shader matrix skinning → RGB lighting → texture framebuffer → fragment-shader bloom/scanlines/tone mapping → canvas → optional MediaRecorder WebM`.

Blender path awaiting a Blender installation: `new GLB skin + animation → bpy.import_scene.gltf → editable Blender rig scene → output .blend / render`.

The procedural color-coded avatar is an **initial alpha asset** with simplified mechanical anatomy and synthesized hair strands. It is **not** a photorealistic reconstruction of the earlier artwork and not a production-rigged character. This is a genuine new 3D model, but has visual limitations that need manual review.

## Guardrails

- Loopback operator only, no remote internet binding, no arbitrary script evaluation or executing uploaded model instructions.
- `POST /api/control` accepts only specified finite numbers and enumerated poses; invalid controls return HTTP 400. Source is identified as user/automated test when appropriate.
- No hallucinated sensor readings or inner emotional states. Chromatic variants are computational states, not genes or consciousness.
- Blender may require version/API changes; do not report it as tested.
- No claim of WebGL browser success in this sandbox: `canvas.getContext('webgl2')` returns null. Fallback animation render loaded and passed.
- Nothing in this package writes to Kokoro core checkpoints, original data, or installed runtime.

## Measured, simulated, calculated, proposed

| Status | Property | Meaning |
|---|---|---|
| Measured | VTK/EGL frame output | 3D polygons were transformed, rasterized, post-processed and encoded into PNG/GIF |
| Measured | Local live operator HTTP | An actual running server accepted a valid pose, generated new frame bytes and rejected malformed pose |
| Calculated | 20-joint and weight data | Actual authored file data, inspectable as GLB geometry |
| Simulated | Animation timings, Ripple optical channels, virtual heart light | Numerical/software signals; not physical sensation, sensor readings or autonomous behavior |
| Proposed/unverified | Blender scripting, WebGL2 GPU path, remote/cloud deployment | Files prepared but their target runtime not exercised in this environment |
| Unavailable | trained Kokoro Core, consciousness verification | Cannot infer language-model quality or machine consciousness from avatar activity |
