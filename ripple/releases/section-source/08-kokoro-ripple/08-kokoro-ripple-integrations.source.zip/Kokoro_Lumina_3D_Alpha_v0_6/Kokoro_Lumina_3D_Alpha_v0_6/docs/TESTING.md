# Test ledger

Executed in provided compute container (Debian Linux, Python 3.13, VTK EGL renderer).

- Unit suite includes numeric skinning, normalized weights, bone parent hierarchy, glTF header, glTF skin/animation presence, 50 finite randomized skeletal poses, lossless core source preservation checks, exact Kokoro control packet mapping, invalid operator controls, real 3D pixel render, pose-difference render and post-processing pixel difference.
- Live HTTP test starts the renderer as an actual subprocess, waits for PNG frames, sends a human pose via `POST /api/control`, compares frame SHA-256 values, and sends an invalid control to verify 400 rejection.
- Chromium test: GPU/WebGL2 unavailable, so browser displays fallback actually rendered 3D GIF; test checked fallback was visible and had nonzero natural image width.
- `trimesh.load(..., force='scene')` read the generated GLB successfully. This is not Blender runtime verification.
- 24 animation frames actually rendered and encoded into GIF. The **8 frames/sec field is playback timing**, not a proof of sustained 8 FPS on every machine.
- Blender scripts statically syntax-validated, not executed due absence of Blender binary or `bpy` package. Neither cloud Floot VM nor this container had Blender installed at check time.
