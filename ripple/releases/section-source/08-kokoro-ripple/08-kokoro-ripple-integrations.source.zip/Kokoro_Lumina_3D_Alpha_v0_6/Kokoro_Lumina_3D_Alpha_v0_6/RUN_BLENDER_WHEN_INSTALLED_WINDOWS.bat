@echo off
cd /d "%~dp0"
where blender >nul 2>&1
if errorlevel 1 (
  echo Blender not on PATH. Install Blender and run:
  echo blender --background --python blender\setup_scene.py
  pause
  exit /b 1
)
blender --background --python blender\setup_scene.py
