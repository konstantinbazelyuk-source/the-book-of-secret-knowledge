# Kokoro / Lumina 3D Alpha v0.6

**Functional 3D system, not a mockup.** The primary asset is `web/Kokoro_Lumina_Alpha_v0_6.glb`: a **newly authored skinned 3D android**, not a retextured poster. The older Adelita image was inspected for design inspiration only; no pixels, geometry, meshes or textures from it are in this release. This is **an experimental new art direction, not final canon**.

## Verified here

- 20-joint scene graph, 11,844 vertices, 23,080 triangles, linear blend skinning on selected limbs and a glTF idle animation. Imported by independent `trimesh` glTF parser; not imported by Blender here.
- VTK/EGL generated **real 3D images** and a **24-frame animated GIF** from this geometry and its changing pose. CPU-side bloom/vignette/scanline effects operate **after** 3D rendering.
- `tools/live_operator_server.py` continuously renders 3D PNG frames with a loopback browser operator. Live `POST /api/control` changed pose and changed rendered PNG hash. Invalid requests were rejected.
- Preserved Ripple v0.1, v0.5 Forest and Ripple-Q v0.7 mathematical code. The live server invokes Forest to influence a luminous subset of rendered mesh colors. None of this demonstrates consciousness.
- 27 automated tests + 50 randomized pose cases, live HTTP test and Chromium browser check for the *tested fallback*.

**Not yet verified:** Blender's UI, Blender import/edit/viewport, `.blend` creation, Blender addon live polling, the offline page's WebGL2 shader path (sandbox blocks WebGL), trained Kokoro core integration, VRM certification, live sensors, character quality/identity approval.

## Try now

**1. Live browser view, no 3D GPU needed** (requires Python 3, packages `numpy`, `Pillow`, `trimesh`, `vtk`, `opencv-python-headless`):

```
python -m pip install -r requirements-live.txt
python tools/live_operator_server.py --port 8766 --fps 5 --width 540 --height 700
```

Open **http://127.0.0.1:8766** in a browser on the same computer. Pose, rotate and change compositing controls while the actual 3D render loop generates frames. The HTTP server binds only to `127.0.0.1` and requires no online account. The frame rate depends on CPU/GPU and EGL driver.

**2. Standalone offline WebGL2 viewer**: Open `Kokoro_Lumina_3D_Offline_Alpha.html`. If WebGL2 is available, the implementation animates the new skinned mesh, exposes controls and uses a real framebuffer post-process pass. If blocked, the page displays a genuine prerendered 3D animation as a **non-interactive fallback**. This WebGL2 path could not be executed in the present browser sandbox and should be treated as **awaiting device validation**.

**3. Raw 3D asset**: Load `web/Kokoro_Lumina_Alpha_v0_6.glb` in a Blender glTF importer or other glTF viewer. The GLB has a skin and `Ripple_Idle` keyframe animation. This import route has only been tested with the independent trimesh parser in this workspace.

**4. Blender scene automation when Blender is available**:

```
blender --background --python blender/setup_scene.py
```

This script is provided **unexecuted** because Blender is unavailable here. It is intended to import the GLB, configure a camera/light scene, save `blender/output/Kokoro_Lumina_3D_Alpha.blend` and render an image. Correct Blender-version settings and coordinate conversion must be inspected on first run. For optional live pose input, use `blender/live_bridge_addon.py` with a separately running loopback operator. That addon is syntax checked but not Blender-runtime verified.

## Automated verification

```
python tests/test_alpha.py
python tests/browser_smoke.py
python tools/vtk_renderer.py --mode wave --frames 24 --fps 8 --width 430 --height 550 --gif --out results/actual_3d_wave.gif
```

The browser test checks that the verified animation fallback appears when WebGL is blocked; it is **not** a passing GPU/WebGL2 test.

## File selection

- `tools/build_avatar.py` — editable mesh, materials, skeleton, two-bone weights, GLB generator
- `web/*.glb` — new, cross-platform 3D asset
- `web/runtime.js` — WebGL2 3D renderer + post-processing + operator interface
- `tools/vtk_renderer.py` — verified 3D renderer used for stills and animations
- `tools/live_operator_server.py` — verified live 3D operator via localhost; frame PNG output
- `tools/kokoro_mesh_adapter.py` — read-only, explicit control-packet mapping
- `blender/*.py` — Blender scene and optional live control addon; **Blender execution unverified**
- `sources/*` — preserved project-owned original Ripple sources, hash checked
- `results/*` — actual rendered artifacts, measured tests and recorded evidence
- `docs/` — sourcing, mathematical and evidence limits

No trained model weights, files from proprietary Blender libraries, user photo pixels, or payment-required API integrations are included. User-provided original assets and prior releases remain untouched.
