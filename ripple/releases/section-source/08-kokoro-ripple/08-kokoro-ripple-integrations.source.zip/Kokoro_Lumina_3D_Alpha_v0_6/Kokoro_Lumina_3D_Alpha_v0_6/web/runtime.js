/* KOKORO / LUMINA 3D ALPHA 0.6. Real WebGL2 skinned 3D + framebuffer post effects.
 * No external libraries, network, or model checkpoint. Controls are software signals.
 */
(()=>{'use strict';
const model=window.KOKORO_3D_MODEL;
if(!model||typeof RippleNeuron==='undefined'||typeof RippleQPort==='undefined')throw Error('Required local sources missing');
const $=id=>document.getElementById(id);
const canvas=$('stage');const gl=canvas.getContext('webgl2',{antialias:true,alpha:false,preserveDrawingBuffer:true,depth:true});
if(!gl){
 $('status').textContent='WEBGL2 BLOCKED · 3D VIDEO FALLBACK (NOT INTERACTIVE)';$('status').dataset.status='error';
 canvas.style.display='none';const frame=document.createElement('img');frame.id='fallback-3d';
 frame.src=window.LUMINA_VERIFIED_FALLBACK||'../results/actual_3d_wave.gif';frame.alt='Actual VTK-rendered 3D skeletal animation, fallback: not interactive';
 frame.style.cssText='height:100%;width:100%;object-fit:contain;display:block;background:#040913';canvas.parentNode.appendChild(frame);
 return;
}
function decode(rec){const bin=atob(rec.data), u=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)u[i]=bin.charCodeAt(i);if(rec.dtype==='float32')return new Float32Array(u.buffer);if(rec.dtype==='uint16')return new Uint16Array(u.buffer);return new Uint32Array(u.buffer)}
const arr=Object.fromEntries(Object.entries(model.arrays).map(([k,v])=>[k,decode(v)]));
function shader(type,src){const s=gl.createShader(type);gl.shaderSource(s,src);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));return s;}
function program(v,f){const p=gl.createProgram();gl.attachShader(p,shader(gl.VERTEX_SHADER,v));gl.attachShader(p,shader(gl.FRAGMENT_SHADER,f));gl.linkProgram(p);if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(p));return p;}
const vShader=`#version 300 es
precision highp float;
in vec3 aPos;in vec3 aNor;in vec3 aCol;in vec4 aJoint;in vec4 aWeight;in float aGlow;
uniform mat4 uBones[20];uniform mat4 uViewProj;uniform float uPulse;
out vec3 vNor;out vec3 vPos;out vec3 vCol;out float vGlow;
void main(){
 mat4 skin=aWeight.x*uBones[int(aJoint.x)]+aWeight.y*uBones[int(aJoint.y)]+aWeight.z*uBones[int(aJoint.z)]+aWeight.w*uBones[int(aJoint.w)];
 vec4 w=skin*vec4(aPos,1.0);vPos=w.xyz;vNor=normalize(mat3(skin)*aNor);vCol=aCol;vGlow=aGlow;
 gl_Position=uViewProj*w;
}`;
const fShader=`#version 300 es
precision highp float;
in vec3 vNor;in vec3 vPos;in vec3 vCol;in float vGlow;
uniform float uPulse;uniform vec3 uGene;uniform vec3 uLight;
out vec4 outColor;
void main(){
 vec3 n=normalize(vNor);vec3 lightdir=normalize(uLight-vPos);
 float diffuse=max(dot(n,lightdir),0.0);float rim=pow(1.0-max(dot(n,normalize(vec3(0.,0.7,4.)-vPos)),0.0),2.4);
 vec3 base=vCol*(.25+.75*diffuse)+vCol*.20*rim;
 vec3 color=base+uGene*(vGlow*(.42+.65*uPulse))+.12*rim*uGene;
 outColor=vec4(color,1.0);
}`;
const postVS=`#version 300 es
precision highp float;in vec2 aUV;out vec2 vUV;void main(){vUV=aUV*.5+.5;gl_Position=vec4(aUV,0.,1.);}`;
const postFS=`#version 300 es
precision highp float;in vec2 vUV;out vec4 outColor;
uniform sampler2D uScene;uniform vec2 uResolution;uniform float uTime;uniform float uBloom;uniform float uScan;uniform float uDensity;uniform vec3 uTint;
float hash(vec2 uv){return fract(sin(dot(uv,vec2(12.9898,78.233)))*43758.5453);}
void main(){
 vec2 uv=vUV;vec2 dx=1.6/uResolution;
 vec3 c=texture(uScene,uv).rgb;
 vec3 sum=vec3(0.);
 sum+=texture(uScene,uv+dx*vec2( 2.,0.)).rgb;
 sum+=texture(uScene,uv+dx*vec2(-2.,0.)).rgb;
 sum+=texture(uScene,uv+dx*vec2(0., 2.)).rgb;
 sum+=texture(uScene,uv+dx*vec2(0.,-2.)).rgb;
 vec3 b=max(sum/4.-vec3(.28),vec3(0.));
 c+=b*uBloom*.28;
 c=c/(c+vec3(1.));c=pow(c,vec3(.82));
 float vig=1.-.43*pow(length((uv-.5)*1.3),2.);
 c*=vig*(1.-uScan*.12*(.5+.5*sin(uv.y*uResolution.y*1.3+uTime*1.5)));
 float n=hash(floor(uv*uResolution)+vec2(floor(uTime*19.)))-.5;
 c+=uTint*n*uDensity*.026;
 outColor=vec4(clamp(c,0.,1.),1.);
}`;
const modelP=program(vShader,fShader),postP=program(postVS,postFS);
const uni=(p,n)=>gl.getUniformLocation(p,n);
const BUFS={};
function attrib(p,name,data,size,typ=gl.FLOAT){let i=gl.getAttribLocation(p,name);const b=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.bufferData(gl.ARRAY_BUFFER,data,gl.STATIC_DRAW);gl.enableVertexAttribArray(i);gl.vertexAttribPointer(i,size,typ,false,0,0);BUFS[name]=b;}
gl.useProgram(modelP);
attrib(modelP,'aPos',arr.pos,3);attrib(modelP,'aNor',arr.normal,3);attrib(modelP,'aCol',arr.color,3);
attrib(modelP,'aJoint',arr.joints,4,gl.UNSIGNED_SHORT);attrib(modelP,'aWeight',arr.weights,4);attrib(modelP,'aGlow',arr.glow,1);
const idx=gl.createBuffer();gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,idx);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,arr.indices,gl.STATIC_DRAW);
const U={bones:uni(modelP,'uBones[0]'),view:uni(modelP,'uViewProj'),pulse:uni(modelP,'uPulse'),gene:uni(modelP,'uGene'),light:uni(modelP,'uLight'),scene:uni(postP,'uScene'),res:uni(postP,'uResolution'),time:uni(postP,'uTime'),bloom:uni(postP,'uBloom'),scan:uni(postP,'uScan'),density:uni(postP,'uDensity'),tint:uni(postP,'uTint')};
const full=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,full);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),gl.STATIC_DRAW);
let fb=gl.createFramebuffer(),tex=gl.createTexture(),depth=gl.createRenderbuffer(),width=0,height=0;
function fit(){const r=canvas.getBoundingClientRect(),dpr=Math.min(window.devicePixelRatio||1,1.7);let w=Math.max(2,Math.floor(r.width*dpr)),h=Math.max(2,Math.floor(r.height*dpr));if(width===w&&height===h)return;width=w;height=h;canvas.width=w;canvas.height=h;
 gl.bindTexture(gl.TEXTURE_2D,tex);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,w,h,0,gl.RGBA,gl.UNSIGNED_BYTE,null);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
 gl.bindRenderbuffer(gl.RENDERBUFFER,depth);gl.renderbufferStorage(gl.RENDERBUFFER,gl.DEPTH_COMPONENT16,w,h);
 gl.bindFramebuffer(gl.FRAMEBUFFER,fb);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,tex,0);gl.framebufferRenderbuffer(gl.FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.RENDERBUFFER,depth);if(gl.checkFramebufferStatus(gl.FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw Error('Framebuffer incomplete');gl.bindFramebuffer(gl.FRAMEBUFFER,null);
}
// Column-major mat4 utilities (world matrices and inverse rest bind).
function ident(){return [1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]}
function mul(a,b){let m=new Float32Array(16);for(let c=0;c<4;c++)for(let r=0;r<4;r++){let v=0;for(let k=0;k<4;k++)v+=a[k*4+r]*b[c*4+k];m[c*4+r]=v;}return m}
function trans(x,y,z){let m=ident();m[12]=x;m[13]=y;m[14]=z;return m}
function rotX(t){let c=Math.cos(t),s=Math.sin(t);return [1,0,0,0,0,c,s,0,0,-s,c,0,0,0,0,1]}
function rotY(t){let c=Math.cos(t),s=Math.sin(t);return [c,0,-s,0,0,1,0,0,s,0,c,0,0,0,0,1]}
function rotZ(t){let c=Math.cos(t),s=Math.sin(t);return [c,s,0,0,-s,c,0,0,0,0,1,0,0,0,0,1]}
function norm(a){const l=Math.hypot(...a);return a.map(v=>v/(l||1))}function cross(a,b){return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]}
function dot(a,b){return a.reduce((v,x,i)=>v+x*b[i],0)}
function lookAt(eye,target){const z=norm(eye.map((v,i)=>v-target[i])),x=norm(cross([0,1,0],z)),y=cross(z,x);return [x[0],y[0],z[0],0,x[1],y[1],z[1],0,x[2],y[2],z[2],0,-dot(x,eye),-dot(y,eye),-dot(z,eye),1]}
function perspective(fov,aspect,near,far){const f=1/Math.tan(fov/2),nf=1/(near-far);return [f/aspect,0,0,0,0,f,0,0,0,0,(far+near)*nf,-1,0,0,2*far*near*nf,0]}
const cfg={source:'synthetic-demo',mode:'idle',auto:true,paused:false,time:0,head:0,wave:0,heart:.6,light:.8,density:.32,bloom:.8,scan:.3,look:0,signal:.5,occlusion:1,yaw:.36,pitch:.10,distance:5.5};
const names=Object.fromEntries(model.bones.map((b,i)=>[b.name,i]));
function finite(x,a,b){if(typeof x!=='number'||!Number.isFinite(x)||x<a||x>b)throw Error('Control must be finite '+a+'..'+b);return x}
const allowedSources=new Set(['synthetic-demo','human-control','kokoro-reported','replay']);
function setControl(k,v,source='human-control'){
 if(!allowedSources.has(source))throw Error('Invalid source');
 const limits={head:[-1,1],wave:[0,1],heart:[0,1],light:[0,1],density:[0,1],bloom:[0,1],scan:[0,1],look:[-1,1],signal:[0,1],yaw:[-3.2,3.2],pitch:[-.5,.8],distance:[2.4,10]};
 if(k in limits)cfg[k]=finite(v,...limits[k]);else if(k==='mode'){if(!['idle','wave','greet','scan','focus','rest','spin'].includes(v))throw Error('Invalid mode');cfg.mode=v;}
 else if(k==='paused'||k==='auto')cfg[k]=!!v;else throw Error('Unknown control');cfg.source=source;return cfg[k];
}
const colony={profiles:{},q:new RippleQPort(),monoDuration:0,chromatic:[.4,.8,.95],dominant:'',events:0,qcode:2};
const species=[['ember',[0,1,2],[.98,.42,.55]],['verdant',[1,2,0],[.40,.95,.68]],['azure',[2,0,1],[.38,.72,1.]],['violet',[1,0,2],[.72,.50,.98]]];
for(const [name] of species)colony.profiles[name]=new RippleNeuron();
function forestStep(dt){
 let rgb=[cfg.signal, Math.min(1,.27+.4*cfg.light), Math.min(1,.12+.5*(1-cfg.signal))];
 let rates=[],sum=0,emitted=0;
 for(const [name,map] of species){const x=colony.profiles[name].step(map.map(i=>rgb[i]),dt);rates.push(x.rate);sum+=x.rate;emitted+=x.count;}
 let best=0;for(let i=1;i<rates.length;i++)if(rates[i]>rates[best])best=i;
 let dominance=sum>1e-7?rates[best]/sum:0;colony.monoDuration=dominance>.85&&sum>=.15?colony.monoDuration+dt:0;
 colony.dominant=sum>0?species[best][0]:'none';colony.events+=emitted;
 let colors=[0,0,0];for(let i=0;i<rates.length;i++)for(let j=0;j<3;j++)colors[j]+=species[i][2][j]*(sum>0?rates[i]/sum:0);
 colony.chromatic=sum>0?colors:[.36,.79,.90];colony.qcode=colony.q.step(2*rgb[0]+1.2*rgb[1]-1.4*rgb[2]);
}
function poses(t){if(!cfg.auto)t=0;const c={},pulse=Math.sin(t*2*Math.PI/4.3),wave=cfg.wave;
 const add=(name,a,b,d)=>c[name]=[a,b,d];
 add('root',0,((cfg.mode==='spin')?t*.35:0),0);
 add('pelvis',0,0,.012*Math.sin(t*.6));add('chest',0,0,.012*pulse);
 add('head',.035*Math.sin(t*.7),.22*cfg.head+.10*Math.sin(t*.8)+(cfg.mode==='scan'?.27*Math.sin(t*1.3):0),.05*cfg.look);
 let active=(cfg.mode==='wave'||cfg.mode==='greet'?1:0);let lift=Math.max(wave,active);
 add('arm_R',0,0,1.38*lift+.045*Math.sin(t*.9));add('forearm_R',0,0,-.55*lift+.35*Math.sin(t*4.4)*lift);
 add('arm_L',0,0,-.12*(cfg.mode==='greet'?1:0));add('forearm_L',0,0,0);
 add('hair_L',0,0,.045*Math.sin(t*1.3));add('hair_R',0,0,-.04*Math.sin(t*1.1));
 if(cfg.mode==='focus')add('head',-.09,.12+.15*cfg.head,0);
 if(cfg.mode==='rest'){add('head',-.06,0,-.08);add('arm_R',0,0,-.04);}
 return c;
}
function skinMatrices(t){const local=poses(t),world=[];for(let i=0;i<model.bones.length;i++){
  const b=model.bones[i],p=b.parent,abs=b.rest,par=p<0?[0,0,0]:model.bones[p].rest,delta=abs.map((v,j)=>v-par[j]);
  const ang=local[b.name]||[0,0,0];
  let M=mul(trans(...delta),mul(rotY(ang[1]),mul(rotZ(ang[2]),rotX(ang[0]))));
  world[i]=p<0?M:mul(world[p],M);
}
const floats=new Float32Array(model.bones.length*16);
 for(let i=0;i<model.bones.length;i++){const p=model.bones[i].rest,M=mul(world[i],trans(-p[0],-p[1],-p[2]));floats.set(M,i*16);}return floats;
}
let lastFrame=0,fps=0,frames=0,lastFps=0;let renderCount=0;
function draw(){fit();const time=cfg.time;let eye=[Math.sin(cfg.yaw)*cfg.distance,1.56+Math.sin(cfg.pitch)*cfg.distance*.32,Math.cos(cfg.yaw)*cfg.distance];
 let vp=mul(perspective(42*Math.PI/180,width/height,.08,90),lookAt(eye,[0,1.48,0]));
 gl.bindFramebuffer(gl.FRAMEBUFFER,fb);gl.viewport(0,0,width,height);gl.enable(gl.DEPTH_TEST);gl.enable(gl.CULL_FACE);gl.cullFace(gl.BACK);gl.clearColor(.025,.038,.061,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
 gl.useProgram(modelP);gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,idx);
 for(const [name,buf] of Object.entries(BUFS)){let i=gl.getAttribLocation(modelP,name);gl.bindBuffer(gl.ARRAY_BUFFER,buf);gl.enableVertexAttribArray(i);gl.vertexAttribPointer(i,name==='aJoint'?4:name==='aWeight'?4:name==='aGlow'?1:3,name==='aJoint'?gl.UNSIGNED_SHORT:gl.FLOAT,false,0,0)}
 gl.uniformMatrix4fv(U.bones,false,skinMatrices(time));gl.uniformMatrix4fv(U.view,false,new Float32Array(vp));
 gl.uniform1f(U.pulse,cfg.heart*(.5+.5*Math.sin(time*5.4)));gl.uniform3fv(U.gene,new Float32Array(colony.chromatic));gl.uniform3fv(U.light,new Float32Array([3,4.6,5]));
 gl.drawElements(gl.TRIANGLES,arr.indices.length,gl.UNSIGNED_INT,0);
 gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.disable(gl.DEPTH_TEST);gl.disable(gl.CULL_FACE);gl.viewport(0,0,width,height);
 gl.useProgram(postP);gl.bindBuffer(gl.ARRAY_BUFFER,full);let i=gl.getAttribLocation(postP,'aUV');gl.enableVertexAttribArray(i);gl.vertexAttribPointer(i,2,gl.FLOAT,false,0,0);
 gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,tex);gl.uniform1i(U.scene,0);gl.uniform2f(U.res,width,height);gl.uniform1f(U.time,time);gl.uniform1f(U.bloom,cfg.bloom);gl.uniform1f(U.scan,cfg.scan);gl.uniform1f(U.density,cfg.density);gl.uniform3fv(U.tint,new Float32Array(colony.chromatic));gl.drawArrays(gl.TRIANGLES,0,3);renderCount++;
}
function tick(ms){const dt=lastFrame?Math.min(.08,(ms-lastFrame)/1000):1/60;lastFrame=ms;
 if(!cfg.paused){cfg.time+=dt;let left=dt;while(left>1e-8){let step=Math.min(.05,left);forestStep(step);left-=step;}}
 draw();frames++;if(ms-lastFps>600){fps=Math.round(frames/((ms-lastFps)/1000));frames=0;lastFps=ms;updateHud();}requestAnimationFrame(tick);
}
function updateHud(){const s=$('status');s.textContent='RUNNING · WEBGL2 / '+cfg.source.toUpperCase();s.dataset.status='ok';$('fps').textContent=fps;$('seconds').textContent=cfg.time.toFixed(1);$('eventcount').textContent=colony.events;
 $('gene').textContent=colony.dominant.toUpperCase();$('quad').textContent=String(colony.qcode);$('mono').textContent=colony.monoDuration>=2?'DETECTED':'NOT OBSERVED';$('pose').textContent=cfg.mode.toUpperCase();
 for(const [name] of species)$(name+'-rate').textContent=colony.profiles[name].rate.toFixed(2);
}
const binds={head:'head',wave:'wave',heart:'heart',light:'light',density:'density',bloom:'bloom',scan:'scan',look:'look',signal:'signal'};
for(const [id,key] of Object.entries(binds)){const el=$(id),num=$(id+'-v');el.value=cfg[key];num.textContent=Number(cfg[key]).toFixed(2);el.addEventListener('input',()=>{setControl(key,Number(el.value));num.textContent=Number(el.value).toFixed(2);});}
$('mode').value=cfg.mode;$('mode').addEventListener('change',e=>setControl('mode',e.target.value));
$('auto').checked=cfg.auto;$('auto').onchange=e=>setControl('auto',e.target.checked);$('pause').onclick=()=>{setControl('paused',!cfg.paused);$('pause').textContent=cfg.paused?'Resume simulation':'Pause simulation'};
$('reset').onclick=()=>{cfg.time=0;colony.events=0;colony.monoDuration=0;for(const [name] of species)colony.profiles[name]=new RippleNeuron();colony.q=new RippleQPort();cfg.source='human-control';};
$('png').onclick=()=>{draw();canvas.toBlob(blob=>{if(!blob)return;const a=document.createElement('a');a.download='kokoro-lumina-alpha3d-'+Math.round(cfg.time*1000)+'.png';a.href=URL.createObjectURL(blob);a.click();setTimeout(()=>URL.revokeObjectURL(a.href),3000)},'image/png');};
let recorder=null;
$('record').onclick=()=>{if(recorder&&recorder.state==='recording'){recorder.stop();$('record').textContent='Record WebM';return;}
 if(!canvas.captureStream||!window.MediaRecorder){$('status').textContent='This browser cannot record WebM';return;}
 const chunks=[];try{recorder=new MediaRecorder(canvas.captureStream(24),{mimeType:MediaRecorder.isTypeSupported('video/webm;codecs=vp9')?'video/webm;codecs=vp9':'video/webm'});}catch(e){$('status').textContent='WebM recorder unavailable';return;}
 recorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data)};recorder.onstop=()=>{if(!chunks.length)return;const b=new Blob(chunks,{type:'video/webm'});const u=URL.createObjectURL(b),a=document.createElement('a');a.href=u;a.download='kokoro-lumina-3d.webm';a.click();setTimeout(()=>URL.revokeObjectURL(u),3000)};recorder.start();$('record').textContent='Stop recording';};
let dragging=false,px=0,py=0;
canvas.addEventListener('pointerdown',e=>{dragging=true;px=e.clientX;py=e.clientY;canvas.setPointerCapture(e.pointerId)});
canvas.addEventListener('pointermove',e=>{if(!dragging)return;setControl('yaw',Math.max(-3.2,Math.min(3.2,cfg.yaw+(e.clientX-px)*.007)));setControl('pitch',Math.max(-.5,Math.min(.8,cfg.pitch+(e.clientY-py)*.006)));px=e.clientX;py=e.clientY});
canvas.addEventListener('pointerup',()=>dragging=false);canvas.addEventListener('wheel',e=>{e.preventDefault();setControl('distance',Math.max(2.4,Math.min(10,cfg.distance+e.deltaY*.004)))},{passive:false});
// Public operator interface rejects external text, URL and unauthorized controls.
window.LuminaOperator={set:setControl,read:()=>({source:cfg.source,mode:cfg.mode,time:cfg.time,renderedFrames:renderCount,webgl:true,vertices:model.totalVertices,triangles:model.totalTriangles,bones:model.bones.length,gene:colony.dominant,monochrome:colony.monoDuration>=2,simulated:cfg.source==='synthetic-demo',fps,quad:colony.qcode}),render:draw,modelHash:model.sha256_glb,version:'3d-alpha-0.6'};
window.addEventListener('error',e=>{$('status').textContent='ERROR: '+(e.message||'unknown')});
requestAnimationFrame(tick);
})();
