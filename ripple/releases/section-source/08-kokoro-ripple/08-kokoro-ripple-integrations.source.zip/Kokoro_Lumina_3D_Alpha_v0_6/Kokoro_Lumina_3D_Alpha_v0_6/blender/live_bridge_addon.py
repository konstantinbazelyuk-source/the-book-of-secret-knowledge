"""Optional Blender addon for loopback-only operator pose updates.
Blender runtime not accessible in build container: syntax verified, Blender behavior unverified.
Install through Edit > Preferences > Add-ons > Install from Disk, run operator in View3D.
Start tools/live_operator_server.py separately. Polling has a 0.2s interval.
"""
bl_info={'name':'Kokoro Lumina Local Operator Bridge','author':'Kokoro / open engineering','version':(0,6,0),'blender':(4,2,0),'location':'View3D > Sidebar > Lumina','category':'Animation','description':'Loopback-only bounded Kokoro operator-to-Blender pose display'}
import json,urllib.request,math
import bpy
from mathutils import Quaternion,Vector
_live={'on':False,'last':None}
def clamp(x,lo,hi):return max(lo,min(hi,float(x)))

def tick():
 if not _live['on']:return None
 try:
  # Loopback only. No user-specified URL or code evaluation.
  req=urllib.request.Request('http://127.0.0.1:8766/api/state',headers={'Accept':'application/json'})
  with urllib.request.urlopen(req,timeout=.1) as f:data=json.load(f)
  control=data['pose'];mode=control['mode'];waves=clamp(control['wave'],0,1)
  amp=max(waves,1 if mode in ('wave','greet') else 0)
  rig=next((o for o in bpy.data.objects if o.type=='ARMATURE' and any('arm_R' in b.name for b in o.pose.bones)),None)
  if rig:
   # These local rotations are intentionally limited; Blender bone roll may
   # differ after glTF import and must be inspected before production use.
   targets={'arm_R':1.38*amp,'forearm_R':-.55*amp,'arm_L':-.12*(mode=='greet'),'head':.25*clamp(control['head'],-1,1)}
   for name,angle in targets.items():
    bone=rig.pose.bones.get(name)
    if bone:
     bone.rotation_mode='QUATERNION'
     axis=Vector((0,1,0)) if name!='head' else Vector((0,0,1))
     bone.rotation_quaternion=Quaternion(axis,angle)
   bpy.context.view_layer.update()
  _live['last']=data.get('serial')
 except Exception as e:
  _live['last']='UNAVAILABLE: '+type(e).__name__
 return .2

class LUMINA_OT_bridge_start(bpy.types.Operator):
 bl_idname='lumina.bridge_start';bl_label='Start Local Lumina Operator';bl_options={'REGISTER'}
 def execute(self,context):
  _live['on']=True
  if not bpy.app.timers.is_registered(tick):bpy.app.timers.register(tick,first_interval=.1)
  self.report({'INFO'},'Lumina operator polling started (localhost only)')
  return {'FINISHED'}
class LUMINA_OT_bridge_stop(bpy.types.Operator):
 bl_idname='lumina.bridge_stop';bl_label='Stop Local Lumina Operator';bl_options={'REGISTER'}
 def execute(self,context):
  _live['on']=False;self.report({'INFO'},'Lumina operator stopped');return {'FINISHED'}
class LUMINA_PT_panel(bpy.types.Panel):
 bl_label='Kokoro Lumina Alpha';bl_idname='LUMINA_PT_operator'
 bl_space_type='VIEW_3D';bl_region_type='UI';bl_category='Lumina'
 def draw(self,context):
  l=self.layout;l.label(text='Status: '+('POLLING' if _live['on'] else 'OFF'))
  l.operator('lumina.bridge_start');l.operator('lumina.bridge_stop')
classes=(LUMINA_OT_bridge_start,LUMINA_OT_bridge_stop,LUMINA_PT_panel)
def register():
 for k in classes:bpy.utils.register_class(k)
def unregister():
 _live['on']=False
 for k in reversed(classes):bpy.utils.unregister_class(k)
if __name__=='__main__':register()
