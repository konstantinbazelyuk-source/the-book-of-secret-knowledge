"""BLENDER-ONLY SCRIPT; run inside Blender's Python: blender --background --python setup_scene.py.
Imports ORIGINAL procedural glTF asset into a Blender-editable project; configures lights,
CYCLES or EEVEE, camera, saved .blend and rendered still. No internet or other assets.
This script is syntax-tested here, but not runtime-tested because bpy/Blender unavailable.
"""
from __future__ import annotations
import os, pathlib, sys, math
import bpy
from mathutils import Vector
ROOT=pathlib.Path(__file__).resolve().parents[1]
GLB=ROOT/'web'/'Kokoro_Lumina_Alpha_v0_6.glb'
OUT=ROOT/'blender'/'output'
OUT.mkdir(parents=True,exist_ok=True)
assert GLB.is_file(), 'Exported GLB not present'
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=str(GLB))
# GLB skin + idle animation included. We do not overwrite that animation.
armatures=[x for x in bpy.data.objects if x.type=='ARMATURE']
if not armatures:raise RuntimeError('glTF skeletal armature import failed')
rig=armatures[0]
rig.name='Kokoro_Lumina_20_Joint_Rig'
world=bpy.context.scene.world
if world is None:world=bpy.data.worlds.new('Lumina world');bpy.context.scene.world=world
world.use_nodes=True
bg=world.node_tree.nodes.get('Background');bg.inputs['Color'].default_value=(.022,.034,.07,1);bg.inputs['Strength'].default_value=.6

def light(name,location,color,energy,size):
 d=bpy.data.lights.new(name,type='AREA');d.energy=energy;d.color=color;d.shape='DISK';d.size=size
 o=bpy.data.objects.new(name,d);bpy.context.collection.objects.link(o);o.location=location
 direction=Vector((0,0,1.5))-o.location;o.rotation_euler=direction.to_track_quat('-Z','Y').to_euler()
 return o
light('Lumina Soft Key',(3,-4,6),(1,.86,.88),700,5)
light('Cool Rim',(-2,2,4),(.46,.78,1),450,3)
light('Core Bounce',(0,-2,2),(.9,.3,.6),140,2)
cam_data=bpy.data.cameras.new('Kokoro portrait camera');cam=bpy.data.objects.new('Kokoro portrait camera',cam_data);bpy.context.collection.objects.link(cam)
# glTF importer converts +Y up and +Z forward to Blender +Z up and -Y forward.
cam.location=(4,-6,3.1);target=Vector((0,0,1.45));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='PERSP';cam.data.lens=52
scene=bpy.context.scene;scene.camera=cam;scene.render.resolution_x=720;scene.render.resolution_y=900;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG'
for engine in ('BLENDER_EEVEE_NEXT','BLENDER_EEVEE','CYCLES'):
 try:
  scene.render.engine=engine
  break
 except (TypeError,ValueError):continue
scene.render.film_transparent=False
scene.frame_start=1;scene.frame_end=97;scene.render.fps=24
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'Kokoro_Lumina_3D_Alpha.blend'))
scene.render.filepath=str(OUT/'blender_render_first_frame.png')
if os.environ.get('LUMINA_SKIP_RENDER')!='1':bpy.ops.render.render(write_still=True)
print('BLENDER_IMPORT_SUCCESS',len(armatures),'armatures',len(bpy.data.objects),'objects',str(OUT))
