import hashlib,pathlib,sys
base=pathlib.Path(__file__).resolve().parent;lines=(base/'MANIFEST.sha256').read_text().splitlines();errors=[]
for line in lines:
 digest,sep,rel=line.partition('  ')
 if sep!='  ':errors.append('malformed '+line[:40]);continue
 path=(base/rel)
 if not path.is_file():errors.append('missing '+rel);continue
 if hashlib.sha256(path.read_bytes()).hexdigest()!=digest:errors.append('changed '+rel)
print('verified',len(lines),'files; errors',len(errors))
for e in errors:print(e)
sys.exit(bool(errors))
