/* Executable browser translation of project-owned Ripple-Q v0.7 QuadEncoder.
   Original v0.7 ES module archived unchanged under sources/ripple_q_v0_7.mjs.
   No remote CDN or inference service required. */
class RippleQPort{
 constructor(){this.base=.12;this.noiseMult=4;this.dwell=2;this.ref=null;this.prev=null;this.noise=0;this.pending=null;this.pendingCount=0;this.last=2;}
 step(d){if(!Number.isFinite(d))throw Error('finite drive required');if(this.ref===null)this.ref=d;const diff=d-this.ref,thr=Math.max(this.base,this.noiseMult*this.noise);
 let candidate=this.prev!==null&&diff>thr?3:this.prev!==null&&diff<-thr?0:d< -Math.max(this.base,.04)?1:2;
 if(candidate===this.pending)this.pendingCount++;else{this.pending=candidate;this.pendingCount=1;}
 if(this.pendingCount>=this.dwell){this.last=candidate;if(candidate===0||candidate===3)this.ref=d;}
 if(this.prev!==null&&Math.abs(diff)<thr)this.noise=.95*this.noise+.05*Math.abs(d-this.prev);
 this.prev=d;return this.last;}
}
