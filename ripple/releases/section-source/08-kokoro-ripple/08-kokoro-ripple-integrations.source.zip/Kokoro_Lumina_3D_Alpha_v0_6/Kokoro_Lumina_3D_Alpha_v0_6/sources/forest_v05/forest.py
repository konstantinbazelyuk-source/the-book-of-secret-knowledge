"""Lumina Alpha forest: bounded numerical masters overseen by an independent guardrail.
All channels are software controls; no psychological or biological interpretation.
"""
from __future__ import annotations
from collections import deque
from dataclasses import dataclass, asdict
import math,hashlib,json
import numpy as np
from .ripple_core import RippleNeuron
from .quaternary import QuadEncoder

GENES={
    'ember': {'channels':[0,1,2], 'color':[250,117,137]},
    'verdant': {'channels':[1,2,0], 'color':[105,239,183]},
    'azure': {'channels':[2,0,1], 'color':[103,183,255]},
    'violet': {'channels':[1,0,2], 'color':[195,137,246]},
}
SUPPORTED_SOURCE={'synthetic-demo','human-control','kokoro-reported','replay'}

def finite(v,lo,hi):
    if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or not lo<=v<=hi:
        raise ValueError(f'Expected finite scalar {lo}..{hi}')
    return float(v)

def control(x):
    if not isinstance(x,dict):raise ValueError('packet must be object')
    allowed={'source','rgb','look_x','look_y','speech','heart','drive_load','density','diffusion','occlusion','pose','scene_epoch'}
    if set(x)-allowed:raise ValueError('unknown controls')
    source=x.get('source')
    if source not in SUPPORTED_SOURCE:raise ValueError('source required')
    rgb=x.get('rgb')
    if not isinstance(rgb,list) or len(rgb)!=3:raise ValueError('rgb must contain 3 channels')
    a={'source':source,'rgb':[finite(v,0,1) for v in rgb]}
    for name in ('speech','heart','drive_load','density','diffusion','occlusion'):
        a[name]=finite(x.get(name,0.0),0,1)
    for name in ('look_x','look_y'):
        a[name]=finite(x.get(name,0.0),-1,1)
    a['pose']=x.get('pose','idle')
    if a['pose'] not in {'idle','listening','speaking','thinking','rest'}:raise ValueError('unknown pose')
    a['scene_epoch']=x.get('scene_epoch',0)
    if type(a['scene_epoch']) is not int or a['scene_epoch']<0:raise ValueError('invalid scene_epoch')
    return a

class ColorColony:
    def __init__(self):
        self.nodes={name:RippleNeuron() for name in GENES}
        self.quad=QuadEncoder()
        self.history=deque(maxlen=90)
        self.mono_count=0
        self.mono_elapsed=0.0
    def step(self,rgb,dt):
        results={}
        for name,gene in GENES.items():
            mapped=[rgb[i] for i in gene['channels']]
            r=self.nodes[name].step(mapped,dt)
            results[name]={'rate':r['rate'],'theta':r['theta'],'count':r['count'],'drive':r['drive'],'color':gene['color']}
        rates=np.array([r['rate'] for r in results.values()]);total=float(rates.sum())
        fractions=rates/total if total>1e-8 else np.zeros(4)
        # 'monochrome' is operationally defined as one profile dominating >=85%
        # of recorded event-rate mass for 5 consecutive update steps.
        dom=float(fractions.max()) if total>1e-8 else 0.0
        self.mono_count=self.mono_count+1 if dom>=.85 and total>=.15 else 0
        self.mono_elapsed=self.mono_elapsed+dt if dom>=.85 and total>=.15 else 0.0
        dominant=list(GENES)[int(np.argmax(fractions))] if total>1e-8 else None
        entropy=-float(np.sum(fractions[fractions>0]*np.log2(fractions[fractions>0])))/2 if total>1e-8 else 0.
        self.history.append({'t':next(iter(self.nodes.values())).t, 'share':fractions.tolist(),'dominant':dominant})
        q=self.quad.step(results['ember']['drive'])
        colors=np.array([GENES[g]['color'] for g in GENES],dtype=float)
        blend=np.dot(fractions,colors) if total>1e-8 else np.array([75,197,218])
        return {'blend_rgb':[int(round(v)) for v in blend], 'profiles':results,'dominant':dominant,'dominance':dom,'normalized_entropy':entropy,
             'monochrome_emergent':self.mono_elapsed>=2.0,'monochrome_streak':self.mono_count,
             'monochrome_duration_s':round(self.mono_elapsed,4),
             'q_code':q['code'],'q_symbol':q['symbol']}

class MotionMaster:
    name='motion'
    def step(self,t,c,activity):
        breath=math.sin(t*2*math.pi/4.2)
        load=c['drive_load'];head=3.5*math.sin(t*.65)+c['look_x']*4
        # Radians converted to degrees in pose output; rotatable study 2D parts.
        return {'head':{'angle':max(-10,min(10,head)),'dx':c['look_x']*5,'dy':c['look_y']*4},
                'hair_back':{'angle':2.5*math.sin(t*.52),'dx':math.sin(t*.72)*4,'dy':0},
                'hair_front':{'angle':.8*math.sin(t*.62),'dx':c['look_x'],'dy':0},
                'body':{'angle':.65*math.sin(t*.9),'dx':0,'dy':breath*2.0},
                'far_arm':{'angle':-1.5*math.sin(t*.65)-load*1.1,'dx':0,'dy':0},
                'near_arm':{'angle':2.8*math.sin(t*.65),'dx':0,'dy':0},
                'left_leg':{'angle':.5*math.sin(t*.4),'dx':0,'dy':0},
                'right_leg':{'angle':-.5*math.sin(t*.4),'dx':0,'dy':0},
                'breath':float(breath),'blink':float(max(0,1-abs((t%3.6)-2.8)/.09)),
                'mouth_amplitude':c['speech']}

class DiffusionMaster:
    name='light'
    def __init__(self,side=48):
        if not 16<=side<=128:raise ValueError('grid size out of range')
        self.side=side;self.field=np.zeros((side,side),dtype=np.float32)
        self.field[side//2,side//2]=1.0
    def step(self,dt,c,events):
        # 5-point 2D discrete diffusion with zero-flux boundary; dx=1.
        # Explicit scheme requires alpha=D * dt <= .25, enforced below.
        wanted=1.2*c['diffusion']*dt
        steps=max(1,math.ceil(wanted/.20))
        alpha=wanted/steps
        u=self.field.copy()
        if events:
            n=self.side;u[n//2-1:n//2+2,n//2-1:n//2+2]=np.minimum(1,u[n//2-1:n//2+2,n//2-1:n//2+2]+.2)
        for _ in range(steps):
            pad=np.pad(u,1,mode='edge')
            lap=pad[0:-2,1:-1]+pad[2:,1:-1]+pad[1:-1,0:-2]+pad[1:-1,2:]-4*u
            u=np.clip(u+alpha*lap,0,1)
        u*=max(0.,1-.15*dt)
        self.field=u.astype(np.float32)
        return {'grid_min':float(self.field.min()),'grid_max':float(self.field.max()),'mean_density':float(self.field.mean()),'explicit_alpha':alpha,'diffusion_steps':steps}

class Overseer:
    """Coordinates three independent masters. No autonomous research, network, or checkpoint writes."""
    def __init__(self,max_particles=120,seed=29):
        self.colony=ColorColony();self.motion=MotionMaster();self.light=DiffusionMaster()
        self.time=0.;self.last=None;self.max_particles=max_particles;self.seed=seed
    def step(self,dt,packet):
        dt=finite(dt,1e-5,.5)
        c=control(packet) # fail closed, no source inference
        self.time+=dt
        color=self.colony.step(c['rgb'],dt)
        activity=color['profiles']['ember']['count']
        motion=self.motion.step(self.time,c,color)
        field=self.light.step(dt,c,activity)
        # Density budget is bounded and never causes unbounded growth or runaway workload.
        particle_count=min(self.max_particles,int(self.max_particles*c['density']*(.3+.7*c['heart'])))
        channels=[v for v in color['profiles'].values()]
        payload={'schema':'lumina.forest.alpha.v1','elapsed_s':round(self.time,6),
            'source':c['source'],'synthetic':c['source'] in {'synthetic-demo','replay'},
            'source_claim':'external-report-unverified' if c['source']=='kokoro-reported' else c['source'],
            'rig':motion,'chromatic':color,'light_field':field,
            'effects':{'density':c['density'],'diffusion':c['diffusion'],'occlusion':c['occlusion'],
                       'particle_count':particle_count,'heart_intensity':c['heart']},
            'governance':{'max_particles':self.max_particles,'no_model_checkpoint_write':True,
                          'external_network_disabled':True,'masters':['motion','chromatic','light'],
                          'monitor_only':True,'verified_original_kokoro_model':False},
            'scene_epoch':c['scene_epoch']}
        self.last=payload
        return payload

def demo_packet(t,source='synthetic-demo'):
    return {'source':source,'rgb':[.45+.15*math.sin(t*.95),.25+.06*math.cos(t*.7),.12],
        'look_x':.45*math.sin(t*.55),'look_y':.12*math.cos(t*.6),'speech':.10*(1+math.sin(t*2.2)),
        'heart':.6+.3*math.sin(t*.65)**2,'drive_load':.25,'density':.64,
        'diffusion':.7,'occlusion':.8,'pose':'idle','scene_epoch':1}
