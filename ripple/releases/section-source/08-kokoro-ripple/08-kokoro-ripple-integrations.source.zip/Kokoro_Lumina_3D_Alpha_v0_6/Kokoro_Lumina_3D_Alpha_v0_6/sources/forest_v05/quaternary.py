"""Python functional translation of Ripple-Q v0.7 temporal QuadEncoder.
Upstream JavaScript source is included verbatim under sources/ripple_q_v0_7.mjs.
Symbols are state codes, not emergent intelligence.
"""
import math
SYMBOLS=('-1','-0','0','1')
class QuadEncoder:
    def __init__(self,threshold=.12,noise_mult=4.,dwell=2):
        self.base=max(.005,min(2.,threshold));self.noise_mult=max(0,min(20.,noise_mult))
        self.dwell=max(1,min(10,int(dwell)));self.reset()
    def reset(self):
        self.prev_drive=None;self.ref=None;self.noise=0.;self.pending=None
        self.pending_count=0;self.last=2;self.counts=[0,0,0,0]
    def step(self,drive,inhibited=False):
        if not isinstance(drive,(int,float)) or isinstance(drive,bool) or not math.isfinite(drive):
            raise ValueError('finite drive expected')
        if self.ref is None:self.ref=float(drive)
        diff=drive-self.ref;threshold=max(self.base,self.noise_mult*self.noise)
        if self.prev_drive is not None and diff>threshold:candidate=3
        elif self.prev_drive is not None and diff< -threshold:candidate=0
        elif drive< -max(self.base,.04) or inhibited:candidate=1
        else:candidate=2
        if candidate==self.pending:self.pending_count+=1
        else:self.pending=candidate;self.pending_count=1
        if self.pending_count>=self.dwell:
            self.last=candidate
            if candidate in (0,3):self.ref=float(drive)
        if self.prev_drive is not None and abs(diff)<threshold:
            self.noise=.95*self.noise+.05*abs(drive-self.prev_drive)
        self.prev_drive=float(drive);self.counts[self.last]+=1
        return {'code':self.last,'symbol':SYMBOLS[self.last],'bits':format(self.last,'02b'),
                'threshold':threshold,'drive':drive,'noise':self.noise}
