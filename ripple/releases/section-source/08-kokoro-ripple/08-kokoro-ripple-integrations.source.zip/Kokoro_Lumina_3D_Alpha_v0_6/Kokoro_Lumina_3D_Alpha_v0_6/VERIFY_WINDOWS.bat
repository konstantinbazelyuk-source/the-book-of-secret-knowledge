@echo off
cd /d "%~dp0"
python verify_manifest.py
python tests\test_alpha.py
pause
