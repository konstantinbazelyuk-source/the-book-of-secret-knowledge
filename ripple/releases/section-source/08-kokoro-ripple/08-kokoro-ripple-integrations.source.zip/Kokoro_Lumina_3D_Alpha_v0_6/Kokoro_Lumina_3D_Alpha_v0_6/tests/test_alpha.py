import sys,pathlib,unittest,json,struct,base64,subprocess,urllib.request,urllib.error,time,hashlib,random,ast,io,os
import numpy as np
from PIL import Image,ImageChops
BASE=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'tools'))
from vtk_renderer import load_model,pose,apply_skin,Renderer
from live_operator_server import State
from kokoro_mesh_adapter import map_mesh_packet
class RigContracts(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.m,cls.a=load_model()
 def test_vertex_counts(self):self.assertEqual(len(self.a['pos']),self.m['totalVertices'])
 def test_triangles(self):self.assertEqual(len(self.a['indices'])//3,self.m['totalTriangles'])
 def test_triangle_indices(self):self.assertLess(int(self.a['indices'].max()),self.m['totalVertices'])
 def test_twenty_bones(self):self.assertEqual(len(self.m['bones']),20)
 def test_bone_graph_acyclic(self):
  for i,b in enumerate(self.m['bones']):self.assertLess(b['parent'],i)
 def test_skin_weights_normalized(self):self.assertTrue(np.allclose(self.a['weights'].sum(axis=1),1))
 def test_skin_weights_finite(self):self.assertTrue(np.isfinite(self.a['weights']).all())
 def test_joint_indices(self):self.assertLess(int(self.a['joints'].max()),20)
 def test_rest_pose_identity(self):
  sk=pose(self.m['bones'],0,{'mode':'idle'})
  v,n=apply_skin(self.a['pos'],self.a['normal'],self.a['joints'],self.a['weights'],sk)
  self.assertTrue(np.allclose(v,self.a['pos'],atol=1e-5))
 def test_wave_changes_world_vertices(self):
  k=pose(self.m['bones'],0,{'mode':'wave'});v,_=apply_skin(self.a['pos'],self.a['normal'],self.a['joints'],self.a['weights'],k)
  self.assertGreater(float(np.max(np.abs(v-self.a['pos']))),.3)
 def test_idle_frame_change(self):
  a=pose(self.m['bones'],0,{'mode':'idle'});b=pose(self.m['bones'],1.2,{'mode':'idle'})
  self.assertGreater(float(np.max(np.abs(a-b))),.01)
 def test_color_norm(self):self.assertTrue((self.a['color']>=0).all() and (self.a['color']<=1).all())
 def test_origin_source_artifact_absent(self):self.assertEqual(set(self.a),{'pos','normal','color','joints','weights','glow','indices'})
 def test_no_external_assets(self):self.assertFalse(any('image' in k for k in self.m))
 def test_glb_magic_size(self):
  p=BASE/'web/Kokoro_Lumina_Alpha_v0_6.glb';b=p.read_bytes();magic,version,n=struct.unpack('<4sII',b[:12]);self.assertEqual((magic,version,n),(b'glTF',2,len(b)))
 def test_glb_skin_and_animation(self):
  b=(BASE/'web/Kokoro_Lumina_Alpha_v0_6.glb').read_bytes();size,type_=struct.unpack('<I4s',b[12:20]);obj=json.loads(b[20:20+size]);
  self.assertEqual(len(obj['skins'][0]['joints']),20)
  self.assertEqual(obj['skins'][0]['skeleton'],0)
  self.assertGreaterEqual(len(obj['animations'][0]['channels']),6)
  self.assertTrue(all('JOINTS_0' in p['attributes'] for p in obj['meshes'][0]['primitives']))
 def test_kokoro_mesh_absent_is_unavailable(self):
  self.assertEqual(map_mesh_packet({})['status'],'unavailable')
 def test_kokoro_mesh_explicit_mapping(self):
  p={'source':'human-control','rgb':[.7,.2,.3],'look_x':.4,'look_y':-.2,'speech':.5,'heart':.7,'drive_load':.2,'density':.3,'diffusion':.3,'occlusion':.5,'pose':'speaking','scene_epoch':0}
  r=map_mesh_packet({'lumina_forest_control':p})
  self.assertEqual(r['rig_operator_controls']['mode'],'greet');self.assertFalse(r['kokoro_checkpoint_accessed'])
 def test_two_bone_skinning_exists(self):
  n=int(np.count_nonzero(self.a['weights'][:,1]>.001))
  self.assertGreater(n,100)
 def test_glb_digest_matches(self):
  blob=(BASE/'web/Kokoro_Lumina_Alpha_v0_6.glb').read_bytes();self.assertEqual(hashlib.sha256(blob).hexdigest(),self.m['sha256_glb'])
 def test_operator_reject_injection(self):
  s=State()
  for bad in ({'script':'eval()'},{'mode':'execute'},{'head':float('nan')},{'head':10},{'yaw':100},{'paused':1},{'heart':'0.1'},{'url':'https://somewhere'}):
   with self.assertRaises(ValueError):s.set(bad)
 def test_operator_good(self):
  s=State();self.assertEqual(s.set({'mode':'greet','head':.3}),{'mode':'greet','head':.3})
 def test_blender_scripts_compile(self):
  for p in (BASE/'blender').glob('*.py'):ast.parse(p.read_text())
 def test_true_rig_transforms_sweep(self):
  rng=random.Random(103)
  modes=['idle','wave','greet','scan','focus','rest','spin']
  for _ in range(50):
   c={'mode':rng.choice(modes),'head':rng.uniform(-1,1),'wave':rng.uniform(0,1),'look':rng.uniform(-1,1)}
   k=pose(self.m['bones'],rng.uniform(0,8),c)
   v,n=apply_skin(self.a['pos'],self.a['normal'],self.a['joints'],self.a['weights'],k)
   self.assertTrue(np.isfinite(v).all() and np.isfinite(n).all())
   self.assertLess(np.max(np.abs(v)),10)
   self.assertTrue(np.allclose(np.linalg.norm(n,axis=1),1,atol=.001))

class RenderTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.r=Renderer(size=(220,300))
 def test_render_png_real_pixels(self):
  im=self.r.frame(0,{'mode':'idle'});self.assertEqual(im.size,(220,300));self.assertGreater(len(set(im.get_flattened_data())),500)
 def test_pose_changes_render(self):
  a=self.r.frame(0,{'mode':'idle'});b=self.r.frame(0,{'mode':'wave'})
  self.assertIsNotNone(ImageChops.difference(a,b).getbbox())
 def test_post_effect_changes_pixels(self):
  a=self.r.frame(0,{'mode':'idle','bloom':0,'density':0,'scan':0});b=self.r.frame(0,{'mode':'idle','bloom':1,'density':1,'scan':1})
  self.assertIsNotNone(ImageChops.difference(a,b).getbbox())

def live_test():
 # Test the complete loopback service with live-rendered 3D frames.
 cmd=[sys.executable,str(BASE/'tools/live_operator_server.py'),'--port','8754','--fps','3','--width','220','--height','300']
 proc=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
 try:
  last=None
  for _ in range(32):
   try:
    with opener.open('http://127.0.0.1:8754/api/state',timeout=.8) as r:last=json.load(r)
    if last['serial']>=2:break
   except Exception:pass
   time.sleep(.2)
  assert last and last['serial']>=2,last
  with opener.open('http://127.0.0.1:8754/frame.png',timeout=3) as r:frame=r.read()
  assert Image.open(io.BytesIO(frame)).size==(220,300)
  payload=json.dumps({'mode':'wave','head':.55}).encode()
  req=urllib.request.Request('http://127.0.0.1:8754/api/control',data=payload,headers={'Content-Type':'application/json'},method='POST')
  with opener.open(req,timeout=3) as r:assert json.load(r)['accepted']['mode']=='wave'
  changed=None
  for _ in range(20):
   with opener.open('http://127.0.0.1:8754/api/state',timeout=2) as r:changed=json.load(r)
   if changed['serial']>=last['serial']+2:break
   time.sleep(.2)
  assert changed and changed['pose']['mode']=='wave'
  with opener.open('http://127.0.0.1:8754/frame.png',timeout=3) as r:wave=r.read()
  assert hashlib.sha256(wave).hexdigest()!=hashlib.sha256(frame).hexdigest()
  req=urllib.request.Request('http://127.0.0.1:8754/api/control',data=b'{"mode":"execute python"}',headers={'Content-Type':'application/json'},method='POST')
  try:opener.open(req,timeout=2);raise AssertionError('invalid control accepted')
  except urllib.error.HTTPError as e:assert e.code==400
  data={'rendered_frame_sha256_before':hashlib.sha256(frame).hexdigest(),'rendered_frame_sha256_after':hashlib.sha256(wave).hexdigest(),'frame_serial_before':last['serial'],'frame_serial_after':changed['serial'],'pose_after':changed['pose']['mode'],'invalid_control_rejected':True,'live_http_pass':True}
  (BASE/'results/live_server_test.json').write_text(json.dumps(data,indent=2));print(json.dumps(data))
 finally:
  proc.terminate()
  try:proc.communicate(timeout=7)
  except subprocess.TimeoutExpired:proc.kill();proc.communicate()

if __name__=='__main__':
 result=unittest.main(exit=False,verbosity=1)
 if not result.result.wasSuccessful():sys.exit(1)
 live_test()
