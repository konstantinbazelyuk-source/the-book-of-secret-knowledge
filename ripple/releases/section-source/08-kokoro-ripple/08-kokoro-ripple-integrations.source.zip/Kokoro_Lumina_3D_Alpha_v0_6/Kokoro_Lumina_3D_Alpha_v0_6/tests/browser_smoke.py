import json, pathlib, time
from playwright.sync_api import sync_playwright
BASE=pathlib.Path(__file__).resolve().parents[1]
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--enable-webgl','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
 page=browser.new_page(viewport={'width':1365,'height':870},device_scale_factor=1)
 errors=[];con=[]
 page.on('pageerror', lambda e: errors.append(str(e)))
 page.on('console', lambda m: con.append('Console '+m.type+': '+m.text) if m.type=='error' else None)
 page.set_content((BASE/'Kokoro_Lumina_3D_Offline_Alpha.html').read_text(),wait_until='load',timeout=20000)
 page.wait_for_timeout(1500)
 print('status',page.locator('#status').inner_text(),'err',errors,'console',con)
 print('diag',page.evaluate('window.LuminaOperator?.read()'))
 page.screenshot(path=str(BASE/'results'/'browser_initial.png'),full_page=False)
 print('fallback count',page.locator('#fallback-3d').count())
 assert 'FALLBACK' in page.locator('#status').inner_text()
 assert page.locator('#fallback-3d').count()==1
 print('fallback image loaded:',page.evaluate("document.querySelector('#fallback-3d').naturalWidth"))
 assert page.evaluate("document.querySelector('#fallback-3d').naturalWidth")>0
 browser.close()
