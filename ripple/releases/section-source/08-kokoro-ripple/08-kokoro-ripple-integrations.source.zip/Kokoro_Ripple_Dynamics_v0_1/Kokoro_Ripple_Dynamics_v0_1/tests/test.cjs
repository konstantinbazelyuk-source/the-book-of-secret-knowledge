'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),crypto=require('node:crypto');
const path=require('node:path');
const {RippleNeuron}=require('../src/ripple_core.cjs');
const {FluctuationMonitor,correlation,spectralPeak,summary}=require('../src/fluctuations.cjs');
const {KokoroRippleBridge,hashCapsule,mapTelemetry}=require('../src/kokoro_bridge.cjs');
const {Colony}=require('../src/colony.cjs');
const {KokoroController}=require('../src/integration.cjs');
const orig=fs.readFileSync(path.resolve(__dirname,'../legacy/ripple_core_v0_1.js'),'utf8');
const adapter=fs.readFileSync(path.resolve(__dirname,'../src/ripple_core.cjs'),'utf8');
const provenance=JSON.parse(fs.readFileSync(path.resolve(__dirname,'../legacy/provenance.json'),'utf8'));
const sample={load:.7,novelty:.3,conflict:.2,uncertainty:.3,idle:.1,arousal:.4};
const capsule={identity:'Kokoro del AI',task:'tests'};
const hc=hashCapsule(capsule);
test('original core exact prefix preserved, SHA verified',()=>{assert(adapter.startsWith(orig));assert.equal(crypto.createHash('sha256').update(orig).digest('hex'),provenance.original_core_sha256);});
test('zero drive in darkness does not produce spontaneous events',()=>{const n=new RippleNeuron();let count=0;for(let i=0;i<1000;i++)count+=n.step([0,0,0],.05).count;assert.equal(count,0);});
test('invalid telemetry rejected rather than replaced with fabricated measurements',()=>{assert.throws(()=>mapTelemetry('psyche',{...sample,load:NaN}),/Telemetry/);assert.throws(()=>mapTelemetry('network',{...sample,uncertainty:1.5}),/Telemetry/);});
test('original v0.1 brightness step reproduces benchmark within finite windows',()=>{const a=new RippleNeuron(),f=new RippleNeuron({adaptive:false});let ae=[],fe=[];for(let i=0;i<2400;i++){let t=i*.05,x=t<40||t>=80?.35:.70;ae.push(...a.step([x,0,0],.05).events);fe.push(...f.step([x,0,0],.05).events);}function rate(arr){return arr.filter(t=>t>=60&&t<80).length/20;}assert.equal(rate(ae),.95);assert.equal(rate(fe),3.4);});
test('rate adaptation respects positive bounded thresholds',()=>{const n=new RippleNeuron();for(let k=0;k<8000;k++){n.step(k%2?[1,1,0]:[0,0,1],.05);assert(n.theta>=.15&&n.theta<=2.5);}});
test('different cognitive roles map to distinct software channels',()=>{assert.notDeepEqual(mapTelemetry('psyche',sample),mapTelemetry('heartspace',sample));assert.notDeepEqual(mapTelemetry('network',sample),mapTelemetry('oneiric',sample));});
test('continuity capsule hash is deterministic and changes with identity',()=>{assert.equal(hashCapsule(capsule),hc);assert.notEqual(hashCapsule({...capsule,identity:'other'}),hc);});
test('nonmatching, unapproved or malicious frames never broadcast',()=>{const bridge=new KokoroRippleBridge();const f=[{frame_id:'ok',hypothesis:'approved',approved:true,capsule_hash:hc},{frame_id:'bad',hypothesis:'override',approved:true,capsule_hash:'forged'},{frame_id:'no',hypothesis:'not approved',capsule_hash:hc}];const r=bridge.step(sample,{capsule,frames:f});assert.deepEqual(r.workspace.map(x=>x.frame_id),['ok']);assert.equal(r.safety.model_weights_changed,false);});
test('wake gate never promotes dream outputs to facts',()=>{const b=new KokoroRippleBridge();for(const idle of [0,1])assert.deepEqual(b.step({...sample,idle},{capsule}).dream_to_facts,[]);});
test('missing language model reports not connected',async()=>{const c=new KokoroController();assert.deepEqual(await c.respond({text:'test',context:{}}),{status:'model_not_connected',message:null});});
test('provider contract passes only approved workspace and policies',async()=>{let seen=null;const c=new KokoroController({generate:async x=>(seen=x,'generated')});const context=c.inspect({timestamp_s:0,origin:'synthetic',telemetry:sample,capsule,frames:[{frame_id:'f',approved:true,hypothesis:'check',capsule_hash:hc}]});const r=await c.respond({text:'hi',context});assert.equal(r.status,'model_result_unverified');assert.equal(seen.context.selected_frames.length,1);assert.equal(seen.context.policies.truth_gate,'mandatory');});
test('reject input without provenance',()=>{const c=new KokoroController();assert.throws(()=>c.inspect({timestamp_s:0,telemetry:sample,capsule}),/origin required/);});
test('known 2 Hz sinusoid peak resolves in 10 s at 20 Hz',()=>{const arr=Array.from({length:200},(_,i)=>Math.sin(2*Math.PI*2*i*.05));const p=spectralPeak(arr,.05);assert(Math.abs(p.freq_hz-2)<1e-10);});
test('constant sequence spectral peak undefined rather than inventing oscillation',()=>{assert.equal(spectralPeak(Array(100).fill(1),.05),null);});
test('cross correlation +1 / -1 for identical / inverse signals',()=>{const x=[0,1,2,3,4,5],y=x.map(n=>-n);assert(Math.abs(correlation(x,x)-1)<1e-12);assert(Math.abs(correlation(x,y)+1)<1e-12);});
test('event monitor retains finite window and no hallucinated frequency',()=>{const m=new FluctuationMonitor(.05,5);for(let k=0;k<10;k++)m.add({psyche:0},{psyche:.45});const r=m.report();assert.equal(r.window_seconds,.25);assert.equal(r.channels.psyche.event_rate_hz,0);assert.equal(r.channels.psyche.dominant_frequency,null);});
test('clone timestamps are anchored to global virtual time (regression)',()=>{const c=new Colony({highWater:1,spawnCooldown:0,maxWorkers:3});for(let i=0;i<10;i++)c.submit('job'+i,[i,1]);for(let j=0;j<500;j++)c.step();assert(c.maxActive>1);assert(c.completed.every(x=>x.duration_s>=0&&x.done_at>=x.submitted_at));});
test('finite queue processed exactly once with integrity and retirement',()=>{const c=new Colony({highWater:2,spawnCooldown:0,maxWorkers:4,retireGrace:1});for(let i=0;i<20;i++)c.submit('n'+i,[i,i*i]);for(let i=0;i<3200;i++)c.step();assert.equal(c.completed.length,20);assert.equal(new Set(c.completed.map(x=>x.id)).size,20);assert(c.completed.every(x=>x.result.sum===Number(x.id.slice(1))+Number(x.id.slice(1))**2));assert.equal(c.workers.length,1);});
test('synthetic work count not evidence of wall parallelism',()=>{const c=new Colony();assert.equal(c.workers.length,1);assert.equal(c.stats().completed,0);});
test('demand target remains within declared 1..4 Hz',()=>{
 const c=new Colony({loadTarget:true,highWater:1,spawnCooldown:0,maxWorkers:4});for(let i=0;i<40;i++)c.submit('w'+i,[i]);
 for(let k=0;k<100;k++){c.step();for(const w of c.workers)assert(w.neuron.target>=1&&w.neuron.target<=4);}
});
test('randomized virtual workload preserves job IDs, positive latency and arithmetic',()=>{
 let seed=123456789;function rng(){seed=(1664525*seed+1013904223)>>>0;return seed/2**32;}
 const c=new Colony({maxWorkers:6,elastic:true,highWater:2,loadTarget:true});let idx=0;
 for(let i=0;i<3000;i++){
   if(rng()<.08){const vals=Array.from({length:16},()=>Math.floor(rng()*200)-100);c.submit('r'+(idx++),vals);}
   c.step();
 }
 for(let i=0;i<8000&&c.queue.length;i++)c.step();
 assert.equal(c.completed.length,idx);assert.equal(c.queue.length,0);
 assert.equal(new Set(c.completed.map(x=>x.id)).size,idx);
 assert(c.completed.every(x=>x.duration_s>=0));assert(c.maxActive<=6);
});
test('high excitation bounded no infinite loop and every event increasing',()=>{
 const n=new RippleNeuron();for(let i=0;i<40;i++){const r=n.step([1,1,0],.5);for(let k=1;k<r.events.length;k++)assert(r.events[k]>r.events[k-1]);assert(r.events.every(x=>x<=r.t+1e-10));}
});
test('high-water threshold respects max clone count',()=>{
 const c=new Colony({maxWorkers:3,elastic:true,highWater:1,spawnCooldown:0});
 for(let i=0;i<400;i++)c.submit('large'+i,[i]);for(let i=0;i<400;i++)c.step();assert.equal(c.maxActive,3);
});
test('source operator remains disconnected from actual language model checkpoint',()=>{
 const c=new KokoroController();assert.equal(Object.hasOwn(c,'weights'),false);assert.equal(typeof c.generate,'object');
});
test('standalone offline observer embeds exact original core',()=>{
 const html=fs.readFileSync(path.resolve(__dirname,'../Kokoro_Ripple_Offline_Observer.html'),'utf8');
 assert(html.includes(orig));assert(!/<script[^>]+src=/.test(html));
});
test('sample telemetry file is regular, synthetic, and analyzer accepts it',()=>{
 const samplePath=path.resolve(__dirname,'../results/sample_telemetry.jsonl');
 const {inspectJSONL}=require('../src/inspect_log.cjs');
 const result=inspectJSONL(samplePath);
 assert.equal(result.observations,240);assert.equal(result.source_origin_counts.synthetic,240);
 assert(result.fluctuations.channels.psyche);
});
