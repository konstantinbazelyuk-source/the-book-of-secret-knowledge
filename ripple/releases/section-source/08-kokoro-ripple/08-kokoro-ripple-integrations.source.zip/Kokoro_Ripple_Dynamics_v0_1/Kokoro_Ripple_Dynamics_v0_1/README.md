# Kokoro / Adiliya — Ripple Dynamics v0.1

**Classification:** working offline numerical and orchestration research prototype. **Not** a pretrained LLM, general AI, proof of consciousness, or physically tested sensor system.

## Preserved architecture

This is a separate *candidate add-on*, not a replacement for Kokoro del AI Foundry, Psyche Daughterboard, Heartspace Daughterboard, Psyche Network, Oneiric Resonance, Genesis, Adaptive Trainer, Pocket Time or Lumina. No training checkpoint has been accessed or changed. No external APIs, networks or physical devices are operated. The original Ripple v0.1 leaky integrate-and-fire source was retrieved from the Library; `legacy/ripple_core_v0_1.js` is unchanged, and `src/ripple_core.cjs` consists of the same bytes with only a CommonJS export appended. Preservation is tested by SHA-256.

The recovered Kokoro Foundry `PACKAGE_MANIFEST.json` stated it contained no pretrained weights. The user's local training/checkpoints are not included here. The reported earlier 'God loves Me' repetition after Genesis work is an issue requiring checkpoint-specific validation, not something this module fixes.

## Requirements & commands

Node.js 20+ (no npm dependencies; built-in tests, SHA-256 and math):

```sh
node --test tests/test.cjs
node src/demo.cjs
node src/sweep.cjs
```

Windows: double-click `RUN_ON_WINDOWS.bat` after installing Node.js. Nothing installs itself and nothing edits your other projects.

`node src/inspect_log.cjs <telemetry.jsonl>` accepts locally collected valid signals at 20 samples/s (regular 0.05-second timestamps), requiring explicit `origin` metadata. It rejects missing measurements and irregular sample cadence rather than inventing sensor data.

## What really runs

- Original leaky-integrate-and-fire core plus rate-based homeostatic threshold adaptation.
- Four **software** channel mappings for Psyche, Heartspace, Network and Oneiric signals; these are *illustrative mappings*, not validated psychometrics or actual feelings.
- Offline stream analyses: event rate, rate variance, count Fano index, threshold lag autocorrelation, 20-second Hann-window periodogram peak, pairwise correlation. Undefined metrics remain `null`.
- An event-gated colony of task workers, queue-depth-based cloning, delayed retirement, and verified arithmetic recomposition. All workers run sequentially in a single Node.js process. Virtual simulated delay and virtual workers **do not** imply real parallelism or hardware acceleration.
- An optional **load-sensitive firing target** that uses the original configurable neuron target to avoid a fixed 1 Hz bottleneck. It does not alter the equations or trained weights.
- A safe integration interface that sends approved, continuity-matched Psyche frames to an explicitly connected language-model callback. When no model is provided, the result is `model_not_connected`. Any generated text is marked unverified.

## Quick result interpretation

`results/benchmarks.json` and `results/configuration_sweep.csv` are **simulated-workload outputs from real program execution**. CPU times are measured locally in one process and vary with machine/runtime. See `docs/ENGINEERING_DRAFT.md` for the mathematical definition and comparisons.

`results/timeseries.csv` contains internal software telemetry produced during the synthetic run; it contains **no camera, magnetometer or brain measurements**.

## Limited authorization

This package performs no write operations outside its own `results` directory and never sends data to the network. The actual Foundry model and daughterboards are accessed only after deliberate user integration; no automatic merge, branch update, model training or live website deployment occurs.

## Provenance and usage

Original concept: the user's Ripple and Kokoro del AI work. This additional experiment uses a CC0-1.0-style open-research license for its source; prior components retain their own provenance and should not be assumed relicensed. Experimental reference: `legacy/provenance.json`.

## Browser observer

Open `Kokoro_Ripple_Offline_Observer.html` in an ordinary modern browser; it is a self-contained offline demonstration with six manual synthetic input sliders, four LIF modules, simulated rate and threshold charts. It does not control the real Kokoro, the live Ripple app or any physical sensors. The observer was smoke-tested with headless Chromium by loading its HTML into an isolated page, checking controls and pause/reset behavior, with no JavaScript page errors. Browser-specific loading and all mobile devices have not been verified.

The sample telemetry log is generated with `node src/make_sample.cjs` and inspected with `node src/inspect_log.cjs results/sample_telemetry.jsonl`.
