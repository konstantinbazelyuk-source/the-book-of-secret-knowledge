# Kokoro × Ripple Dynamics v0.1 — Verified research run

**Classification:** executed computer model driven by synthetic software signals; no direct connection to real Kokoro weights, sensing, biological neurons, or consciousness.

## Original Ripple v0.1 reproducibility

| Virtual 20-second window | Adaptive events/s | Fixed-threshold events/s |
|:--|--:|--:|
| 20-40 s | 1.00 | 1.65 |
| 60-80 s | 0.95 | 3.40 |
| 100-120 s | 1.00 | 1.65 |

## 268-work-item synthetic burst

Each scenario was tested against eight policies, giving 32 total deterministic runs (four distinct workload profiles × eight policies). All arithmetic work items were executed and verified. The performance results are **simulated virtual task delay** in one sequential Node.js process, not real hardware wall-clock latency.

| Policy | 95th percentile virtual delay | Peak clones | Mean active clones | Peak queue |
|:--|--:|--:|--:|--:|
| `adaptive_static` | 169.461s | 1 | 1.00 | 179 |
| `fixed_static` | 13.280s | 1 | 1.00 | 47 |
| `adaptive_elastic_balanced` | 1.514s | 4 | 1.93 | 9 |
| `adaptive_elastic_loadtarget` | 1.247s | 3 | 1.64 | 6 |
| `adaptive_elastic_aggressive` | 0.591s | 4 | 2.04 | 4 |
| `idealized_ungated_upper_bound` | 0.100s | 1 | 1.00 | 1 |

The proposed **load-target + elastic** fusion measured 1.247 virtual seconds and mean 1.64 active clones in this burst, versus 0.591 seconds and 2.04 clones for aggressive scaling. The latter is quicker, but the fusion uses fewer virtual workers. Fixed-target adaptation alone was much slower (p95 169.5s) under this workload, demonstrating why rate targets must account for task load.

The historical 20s high-input window reproduced **0.95 events/s** for adaptive Ripple against **3.40 events/s** for fixed-threshold Ripple; this validates the numerical reproduction, not any new physical device.

## Test and integration boundary

- 26 source-preservation, parameter, invariance, clock, backlog, continuity, rejection, spectrum, adapter and sample-log tests passed using Node built-in test runner.
- One browser smoke test passed by injecting the observer HTML into isolated headless Chromium and operating sliders/pause/reset. Direct file URL navigation was blocked by this test environment, not demonstrated on the user's Android.
- Real Kokoro Foundry checkpoint, trained text behavior, tool permissions and hardware sensing were not available for this run; callbacks are not connected and AI response quality is unmeasured.
- The strongest next test is a genuine Kokoro runtime A/B comparison with aligned model checkpoint and measured CPU time, RAM, token latency and answer correctness, without writing to existing checkpoint files.

See `docs/ENGINEERING_DRAFT.md` for full formulas, provenance, instrumentation plan and citations.
