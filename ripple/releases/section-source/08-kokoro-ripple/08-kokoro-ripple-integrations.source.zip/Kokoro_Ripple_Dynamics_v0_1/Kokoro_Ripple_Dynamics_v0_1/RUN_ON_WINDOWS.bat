@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 20 or newer is required. No installation or downloads are performed.
  pause
  exit /b 1
)
node --test tests\test.cjs
if errorlevel 1 exit /b 1
node src\demo.cjs
if errorlevel 1 exit /b 1
node src\sweep.cjs
if errorlevel 1 exit /b 1
echo Tests and simulations complete. Inspect results folder.
pause
