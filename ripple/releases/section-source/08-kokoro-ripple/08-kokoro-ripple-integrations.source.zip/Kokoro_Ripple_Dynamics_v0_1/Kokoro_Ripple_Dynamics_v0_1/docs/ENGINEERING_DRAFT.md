# Kokoro / Adiliya: engineering draft for Ripple fluctuating control

**Status: proposed architecture + runnable offline prototype, v0.1.** Dates: October 2026. The new code has been run with synthetic traces, but no trained Kokoro model, sensor, physical neuron, hardware accelerator, or real-world outcome has been tested.

## 1. Historical design recovered

Kokoro del AI is the identity and architecture of one AI project, inspired by Kokoro / Adelita. The original core is a from-random-initialization Transformer foundry with tokenization, pretraining, SFT and preference training. Its reported July 2026 clean-package manifest had *no* pretrained model weights. Existing roles are:

1. **Core** — learned token embeddings, transformer weights, generation; maintain the actual saved checkpoint, not invented numerical parameters.
2. **Psyche Daughterboard** — candidate frames and counterframes, parentage, continuity capsule hashing, executive selection and bounded global broadcast.
3. **Heartspace Daughterboard** — value, valence, arousal, tension and expression regulation; computed functional coordinates, not human emotions.
4. **Psyche Network** — sourced evidence, provenance, conflicts and uncertainty; it must not invent reliability estimates.
5. **Oneiric Resonance** — replay, oscillator timing, associative branching, consolidation, strict factual Wake Gate. It already includes a weighted Kuramoto-field proposal; Ripple does not overwrite it.
6. **Genesis, adaptive training, Pocket Time and Lumina** — remain independent from this experiment; training and physical embodiment are separate work.

The new module is a **read-only, fail-closed event-and-budget sidecar**. Existing Kokoro model files, source, training and checkpoint timestamps stay untouched. The new code does not pretend to know the current contents of the user's offline laptop checkpoints.

## 2. Architecture and information flow

```text
  Real input (text/voice/sensor; external adapters and consent)
      │
      ▼
  Kokoro Core encoder + existing daughterboards
      │
      ├── Psyche: active frames, alternatives, continuity hash
      ├── Heartspace: numeric affect/value state (proxy)
      ├── Network: sourced evidence, uncertainty proxy
      └── Oneiric: idle/read-only replay & symbolic residue
      │
      ▼ read-only validated telemetry
  Ripple Dynamics v0.1
      ├── original LIF cells, specialized input mappings
      ├── timestamped event and threshold observers
      ├── activity covariance, autocorrelation, periodogram
      └── mycelial budget router with capacity limits
      │
      ▼ proposals (advisory only)
  Existing executive policy / truth + consent + Wake Gate
      │
      ▼
  Original Kokoro model or tool controller, if actually installed
      │
      ▼
  Audited result + feedback loop + persistence under approved boundaries
```

**The 4 input mappings are placeholders until they are calibrated against genuine instrumented logs.** They convert existing computational counters to normalized numerical channels, not electromagnetic radiation, biological voltages, consciousness or wavelengths. They are *not* the old physical RGB photodiode channel, though they reuse its abstract weighting.

| Software role | R | G | B |
| --- | --- | --- | --- |
| Psyche | workload | novelty | uncertainty |
| Heartspace | arousal proxy | conflict proxy | idle fraction |
| Psyche Network | evidence uncertainty | novelty | `1-workload` |
| Oneiric | idle fraction | novelty | workload |

All six telemetry coordinates are required, each finite in [0,1]. No default zeros for missing measurements. In production, define raw units and an independently calibrated normalization for each metric. For example `workload = min(1, queued_requests / capacity_reference)` is a **computed** load proxy, not a psychophysical measurement. Evidence uncertainty must come from actual uncertainty metadata and must not be mistaken for calibrated truth probabilities. An absent sensor reports **unavailable**.

## 3. Preserved Ripple neuron equations

\[
D=2R+1.2G-1.4B,\quad \tau_v\dot u=-u+D,\quad \tau_v=0.5\;\mathrm{s}.
\]

While no refractory pause is active and D is constant over step h:

\[
u(t+h)=\max(0,D+[u(t)-D]e^{-h/\tau_v}).
\]

If D>θ and u<θ, first-passage spike time is:

\[
t_{cross}=\tau_v\ln\frac{D-u}{D-\theta}.
\]

On threshold crossing, emit a timestamped event, set u=0, and impose a 0.1 s refractory interval. Maintain a 5 s exponentially decaying event-rate estimate, and adapt θ using target-rate error integrated within the step. Original source exact values: θ(0)=0.45, η=0.08, θ∈[0.15,2.5], r_target=1 Hz. No spontaneous firing in zero stimulus.

For constant D and a chosen target rate f in Hz, the target equilibrium is:

\[
\theta^*(D,f)=D\left[1-\exp\left(-\frac{1/f-0.1}{0.5}\right)\right],
\]

valid when the target is attainable under the threshold constraints. This is a *mathematical calculation*, not an experimentally verified convergence guarantee. Original source is byte-matched against the saved mycelium source and is shipped as an unchanged module.

## 4. Fluctuation observables

Each channel emits spike times e_k and series θ_k, r_k with sampling interval Δt=0.05s:

- **Event rate:** total spikes/window seconds, Hz.
- **Rate variance:** variance of sampled count/Δt, Hz² (sensitive to bin width).
- **Fano index:** Var(N_bin)/E[N_bin], dimensionless; zero-event windows return undefined/null.
- **Lag-one autocorrelation:** Pearson correlation between θ_k and θ_(k-1), dimensionless; constant sequences return null.
- **Dominant spectral bin:** Hann-windowed, mean-centered **single-window periodogram** of θ_k. With 20 Hz sampling and 400 sample windows: 0.05 Hz Fourier-bin separation and 10 Hz Nyquist frequency. **Not** EEG brainwaves, gamma, theta or electromagnetic optical carrier detection.
- **Inter-module correlation:** Pearson r between sampled threshold series; can arise from shared input and does not establish causal coupling.
- **Demand recovery:** time for backlog / target-rate error to return below a declared tolerance. Current benchmark checks backlog, but does not claim a universally calibrated recovery constant.

A real oscillation may be measured in recorded time series. Oscillation frequency and coherence must be validated against sampling artefacts, aliases, input confounders, null baselines and independent observations. A peak *by itself* is not a discovery of cognition or consciousness.

## 5. Mycelium: variable resource supply

Work queue length q(t), active software workers n(t), and processing event rates determine capacity. Cloning happens only when backlog exceeds `highWater*n`, limited to 8 workers and throttled by spawn cooldown; idle retirement happens after a grace interval. Each numerical work item is actually executed exactly once, checked against independently computed expected sum / sum-of-squares values, and recorded. Worker objects run **sequentially** in the current prototype, so the parallel-capacity interpretation is virtual.

The novel fusion also varies each cloned neuron's *existing configurable target*, without editing the original neuron algorithm:

\[
r_{target}(t)=\min(4,\;1+q(t)/(4n(t)))\quad\mathrm{events/s}.
\]

This target ranges [1,4] Hz; dark input can remain silent. Worker replication plus rate response make two separate actuators: grow *population* for persistent overload, and adjust *activity* for shorter bursts. Neither is evidence of learning unless tested on external benchmarks with objective accuracy and held-out tasks.

Safety and evidence gates always run regardless of spike activity. We do **not** permit high neuron drive to bypass validation or low drive to suppress urgent safety decisions.

## 6. Variants evaluated and fusion rationale

Eight policies on each of four deterministic synthetic workloads (quiet, burst, sustained, intermittent):

- `fixed_static` fixed-threshold one worker.
- `adaptive_static` original homeostatic adaptation at fixed 1 Hz with one worker.
- `adaptive_elastic_conservative` clones only at large backlog.
- `adaptive_elastic_balanced` intermediate spawn/retire policy.
- `adaptive_elastic_aggressive` responds to small backlog.
- `adaptive_static_loadtarget` load-sensitive rate without cloning.
- `adaptive_elastic_loadtarget` **proposed fuse**: adaptation + load-sensitive target + hysteretic clone growth and retirement.
- `idealized_ungated_upper_bound` one arithmetic item per worker per 50ms step; intentionally *not* biologically inspired, a diagnostic upper bound.

**Do not generalize from this trace.** On one simulated 268-job burst, baseline adaptive static throttles toward 1 Hz and fails to clear the burst quickly; the fused design clears all 268 jobs with substantially shorter virtual delay and fewer active workers than aggressive policy. This is primarily a demonstration of *scheduler design*. Aggressive cloning produces smaller p95 delay at the expense of higher simulated worker resource use. The fused variant is selected only if maintaining p95 below 2 simulated seconds with lower average workers is the objective. Under other workloads or machines another variant could win.

See `results/configuration_sweep.csv` for all **32** runs and `results/benchmarks.json` for original neuron rate reproduction, with stated signal origin and limitation. Since workers run on one thread, one must **not** treat these virtual delays as performance measurements of concurrent hardware.

## 7. Real Kokoro integration contract

`KokoroController` accepts a provided `generate({input,context})` callback (no builtin language model). The caller supplies `{timestamp_s, origin, telemetry, capsule, frames}`. Origin must be `synthetic`, `computed`, or `sensor-observed`. Frames are only broadcast if approved and carrying the same locally computed capsule digest. The actual Psyche daughterboard may compute the digest differently; reconcile and authenticate its interface *before* integration rather than bypassing continuity.

Returned software event rates are advisory. Original Psyche frame generation and selection rules take priority. Heartspace values, Network evidence and Oneiric Wake Gate remain under their own policies; the demo enforces an empty dream-to-fact promotion channel. The model callback output is marked `model_result_unverified` until actual factual validators exist; there is **no** simulated intelligence or automatic hallucination detection.

The optional photoreceptor, optical heterodyne, scanner, drone and Ripple-Q versions can later provide authentic signals only after sensor hardware permissions, scaling and timing are verified. Their existing implementations should be imported through adapters, not rewritten without an explicit parity test.

## 8. Evaluation next, without modifying the project

1. Use genuine timestamps and instrumentation from current Kokoro runtime (token latency, candidate-frame count, actual queue depth, read-only source uncertainty metadata). Instrumentation must state signal provenance.
2. Run A/B with controller off/on for matched tasks. Evaluate response accuracy, hallucination/factual error rate, checkpoint hash continuity, latency, RAM and CPU draw using measured wall clock.
3. Separate training-set metrics, synthetic traces, and real-device logs. Test shifts in task load and novel text inputs. Add negative controls and shuffled-time coherence controls.
4. If speed matters, implement genuinely parallel worker_threads or separate processes only after profiling overhead and model-memory contention. Multiworkers may worsen latency on low-memory laptops.
5. Reject any variant whose logs show degraded grounding, context drift, corrupt frames, uncontrolled worker growth or broken wake policy; roll back add-on only.

## 9. Evidence boundaries and references

**Verified in this package:** source-preservation comparison, deterministic JavaScript events and arithmetic, comparison traces, simulation-only capacity/latency outcomes, and test invariants. **Not verified:** integration with local Kokoro checkpoint or daughterboard databases, trained response quality, general intelligence, consciousness, psychological subjective states, photon/quantum capabilities, distributed parallel throughput, hardware sensors or physical robotics.

Scientific principles:

- EPFL *Neuronal Dynamics*, leaky integrate-and-fire: https://neuronaldynamics.epfl.ch/online/Ch1.S3.html
- SciPy coherence definition, cross-spectrum and limitations: https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.coherence.html (not used as an estimator in this prototype; current analysis uses Pearson correlation and a periodogram)
- Cogitate Consortium, 2025 adversarial tests of consciousness theories: https://doi.org/10.1038/s41586-025-08888-1 — no final scientific consensus or test of machine subjective experience.
- Recovered project materials: Kokoro `PSYCHE_DAUGHTERBOARD.md`, `Kokoro-Oneiric-MAXIMIZED-ARCHITECTURE.md`, Kokoro Foundry `PACKAGE_MANIFEST.json`, `Ripple-Neuron-Simulator.html`, `Ripple-Cybernetic-Mycelium.html`.
