'use strict';
const {KokoroRippleBridge}=require('./kokoro_bridge.cjs');
// Safe call contract. Never fabricates a model, external sources, or calibrated confidence.
class KokoroController {
 constructor({generate=null,dt=0.05}={}){
   if(generate!==null&&typeof generate!=='function')throw Error('generate must be a function or null');
   this.generate=generate;this.bridge=new KokoroRippleBridge({dt});
 }
 inspect(input){
   if(!input||!['synthetic','computed','sensor-observed'].includes(input.origin))
     throw Error('origin required: synthetic/computed/sensor-observed');
   if(!Number.isFinite(input.timestamp_s)||input.timestamp_s<0)throw Error('timestamp_s invalid');
   const {telemetry,capsule,frames=[]}=input;
   const res=this.bridge.step(telemetry,{capsule,frames});
   return {...res,origin:input.origin,timestamp_s:input.timestamp_s,
     advisory:'Budget only. No learned reasoning, correctness or experience is inferred from spikes.'};
 }
 async respond({text,context}){
   if(typeof text!=='string'||typeof context!=='object'||context===null)throw Error('invalid model request');
   if(!this.generate)return {status:'model_not_connected',message:null};
   // All selected frames have capsule hashes and approved flags, no direct unrestricted tools.
   const message=await this.generate({input:text,context:{
      continuity_hash:context.capsule_hash,selected_frames:context.workspace,
      policies:context.safety, origin:context.origin}});
   return {status:'model_result_unverified',message};
 }
}
module.exports={KokoroController};
