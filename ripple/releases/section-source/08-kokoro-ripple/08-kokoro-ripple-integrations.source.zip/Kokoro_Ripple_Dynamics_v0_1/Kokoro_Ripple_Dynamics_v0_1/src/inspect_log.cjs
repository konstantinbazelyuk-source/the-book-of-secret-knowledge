'use strict';
// Usage: node src/inspect_log.cjs data.jsonl . Reads telemetry without editing model weights.
const fs=require('node:fs'),{KokoroController}=require('./integration.cjs');
function inspectJSONL(filename){
 const entries=fs.readFileSync(filename,'utf8').split(/\r?\n/).filter(x=>x.trim()).map((s,i)=>{
  try{return JSON.parse(s);}catch(e){throw Error('Line '+(i+1)+': '+e.message);}});
 if(!entries.length)throw Error('no observations');
 const controller=new KokoroController({dt:.05});let prev=null,last=null;
 for(const [i,x] of entries.entries()){
   if(prev!==null&&Math.abs((x.timestamp_s-prev)-.05)>1e-5)
     throw Error('Line '+(i+1)+': requires regular 0.05 s sampling, no gaps');
   last=controller.inspect(x);prev=x.timestamp_s;
 }
 return {observations:entries.length,source_origin_counts:Object.fromEntries([...new Set(entries.map(e=>e.origin))].map(k=>[k,entries.filter(e=>e.origin===k).length])),
   last_module_states:last.module_states,fluctuations:controller.bridge.fluctuations()};
}
if(require.main===module){if(process.argv.length!==3){console.error('Usage: node src/inspect_log.cjs <telemetry.jsonl>');process.exit(2);}
try{console.log(JSON.stringify(inspectJSONL(process.argv[2]),null,2));}catch(e){console.error(e.message);process.exit(1);}}
module.exports={inspectJSONL};
