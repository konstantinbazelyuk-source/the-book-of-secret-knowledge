'use strict';
const fs=require('node:fs'),path=require('node:path');
const {KokoroRippleBridge,hashCapsule}=require('./kokoro_bridge.cjs');
const {Colony}=require('./colony.cjs');
const {RippleNeuron}=require('./ripple_core.cjs');
const target=path.resolve(__dirname,'..','results');fs.mkdirSync(target,{recursive:true});
const dt=.05,steps=3600; // 180 simulated seconds. Single process.
const capsule={identity:'Kokoro del AI',goal:'Run isolated Ripple fluctuation benchmark',source:'synthetic harness',version:1};
function telemetryAt(t){
 const burst=t>=30&&t<100,recovery=t>=100;
 return {load:burst?.82:(recovery?.12:.24),novelty:burst?.70:.20,conflict:burst?.35:.10,
 uncertainty:burst?.58:.18,idle:recovery?.95:(burst?.05:.45),arousal:burst?.62:.20};
}
// Independent runs: fixed-threshold single neuron, adaptive single neuron,
// static worker pool, elastic worker pool and fused Kokoro bridge.
const adapted=new RippleNeuron(),fixed=new RippleNeuron({adaptive:false});
const staticPool=new Colony({maxWorkers:8,elastic:false});
const elasticPool=new Colony({maxWorkers:8,elastic:true});
const bridge=new KokoroRippleBridge({dt});
const logs=[],spikes={adaptive:[],fixed:[]};
for(let i=0;i<steps;i++){
 const t=i*dt,red=t<40||t>=80?.35:.70;
 const a=adapted.step([red,0,0],dt),b=fixed.step([red,0,0],dt);
 spikes.adaptive.push(...a.events);spikes.fixed.push(...b.events);
 const signals=telemetryAt(t);
 // Deterministic workload: 3 low, 96 burst, 9 recovery jobs, spread across fixed windows.
 const deliver=(t<30&&i%200===0)||(t>=30&&t<100&&i%14===0)||(t>=100&&t<130&&i%60===0);
 if(deliver){const id='job-'+i,arr=Array.from({length:32},(_,k)=> ((i+k*7)%19)-9);staticPool.submit(id,arr);elasticPool.submit(id,arr);}
 staticPool.step();elasticPool.step();
 const frame={frame_id:'scope',hypothesis:'Only use synthetic test signals',approved:true,capsule_hash:hashCapsule(capsule),uncertainty:'demonstration',evidence:[]};
 const status=bridge.step(signals,{capsule,frames:[frame]});
 if(i%20===0)logs.push({time_s:Number(t.toFixed(2)),red,a_rate:a.rate,f_rate:b.rate,a_theta:a.theta,f_theta:b.theta,
   psi_theta:status.module_states.psyche.theta,heart_theta:status.module_states.heartspace.theta,
   network_theta:status.module_states.network.theta,oneiric_theta:status.module_states.oneiric.theta,
   psyche_rate:status.module_states.psyche.rate_hz,heart_rate:status.module_states.heartspace.rate_hz,
   network_rate:status.module_states.network.rate_hz,oneiric_rate:status.module_states.oneiric.rate_hz,
   static_queue:staticPool.queue.length,elastic_queue:elasticPool.queue.length,elastic_workers:elasticPool.workers.length});
}
// Continue 80 sim seconds to drain and retire; rates analysis pertains only to first 180s.
for(let i=0;i<1600;i++){staticPool.step();elasticPool.step();}
const windows=[[20,40],[60,80],[100,120]].map(([lo,hi])=>({period:`${lo}-${hi} s`,
 adaptive_hz:spikes.adaptive.filter(t=>t>=lo&&t<hi).length/(hi-lo),fixed_hz:spikes.fixed.filter(t=>t>=lo&&t<hi).length/(hi-lo)}));
const metric={classification:'SIMULATED input; actual JS arithmetic; virtual worker throughput; no AI/physical validation',
 source:'original Ripple LIF kernel, byte-matched to user mycelium file',
 windows,static_pool:staticPool.stats(),elastic_pool:elasticPool.stats(),fluctuations:bridge.fluctuations(),
 comparison_notes:'Colony workers are sequential in one Node.js process. Virtual latency not wall-clock speed, inference quality, or consciousness.'};
fs.writeFileSync(path.join(target,'benchmarks.json'),JSON.stringify(metric,null,2));
fs.writeFileSync(path.join(target,'timeseries.csv'),Object.keys(logs[0]).join(',')+'\n'+logs.map(x=>Object.values(x).join(',')).join('\n')+'\n');
console.log(JSON.stringify({windows,static_pool:metric.static_pool,elastic_pool:metric.elastic_pool},null,2));
