'use strict';
// Passive telemetry analysis. Frequencies below the sample Nyquist only.
function summary(values) {
  if (!values.length) return {mean:null,variance:null,sd:null};
  const mean=values.reduce((a,b)=>a+b,0)/values.length;
  const variance=values.reduce((a,b)=>a+(b-mean)**2,0)/values.length;
  return {mean,variance,sd:Math.sqrt(variance)};
}
function lag1(values) {
  if (values.length<3) return null;
  const m=summary(values).mean;
  let cov=0,var0=0,var1=0;
  for(let k=1;k<values.length;k++){let a=values[k-1]-m,b=values[k]-m;cov+=a*b;var0+=a*a;var1+=b*b;}
  return var0>1e-12&&var1>1e-12?cov/Math.sqrt(var0*var1):null;
}
function spectralPeak(values, dt) {
  if (values.length<16) return null;
  const n=values.length, fs=1/dt, mu=summary(values).mean;
  let best={freq_hz:0,relative_power:0},total=0;
  // Hann window reduces leakage. Single-window periodogram: diagnostic, not Welch PSD.
  for(let k=1;k<=Math.floor(n/2);k++){
    let re=0,im=0;
    for(let i=0;i<n;i++){
      const window=0.5*(1-Math.cos(2*Math.PI*i/(n-1)));
      const a=(values[i]-mu)*window, ph=2*Math.PI*k*i/n;
      re+=a*Math.cos(ph);im-=a*Math.sin(ph);
    }
    const power=(re*re+im*im)/n;
    total+=power;
    if(power>best.relative_power) best={freq_hz:k*fs/n,relative_power:power};
  }
  if(total<1e-12) return null;
  best.relative_power/=total;
  return best;
}
function correlation(x,y) {
  if(x.length!==y.length||x.length<3) return null;
  const mx=summary(x).mean,my=summary(y).mean;
  let xy=0,xx=0,yy=0;
  for(let i=0;i<x.length;i++){let a=x[i]-mx,b=y[i]-my;xy+=a*b;xx+=a*a;yy+=b*b;}
  return xx>1e-12&&yy>1e-12?xy/Math.sqrt(xx*yy):null;
}
class FluctuationMonitor {
  constructor(dt=0.05,history=400) {this.dt=dt;this.history=history;this.records=[];}
  add(eventCounts,states) {
    const r={counts:{...eventCounts},states:{...states}};
    this.records.push(r);if(this.records.length>this.history)this.records.shift();
  }
  report() {
    const names=this.records.length?Object.keys(this.records[0].counts):[];
    const out={window_seconds:this.records.length*this.dt,fs_hz:1/this.dt,channels:{},pairwise:{}};
    for(const name of names){
      const counts=this.records.map(x=>x.counts[name]??0);
      const rates=counts.map(x=>x/this.dt);
      const base=summary(counts),states=this.records.map(x=>x.states[name]??0);
      out.channels[name]={event_rate_hz:base.mean/this.dt,rate_variance:summary(rates).variance,
        fano_counts:base.mean>0?base.variance/base.mean:null,
        lag1_state:lag1(states),dominant_frequency:spectralPeak(states,this.dt),
        threshold_mean:summary(states).mean};
    }
    for(let i=0;i<names.length;i++)for(let j=i+1;j<names.length;j++){
      const a=names[i],b=names[j];out.pairwise[a+'__'+b]=correlation(this.records.map(x=>x.states[a]),this.records.map(x=>x.states[b]));
    }
    return out;
  }
}
module.exports={summary,lag1,spectralPeak,correlation,FluctuationMonitor};
