'use strict';
const crypto=require('node:crypto');
const {RippleNeuron,bound}=require('./ripple_core.cjs');
const {FluctuationMonitor}=require('./fluctuations.cjs');
const ROLES=['psyche','heartspace','network','oneiric'];
function hashCapsule(value){return crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex');}
// Semantic mapping for software channels only, not measured optical RGB or brain signals.
function mapTelemetry(role,s) {
  for (const k of ['load','novelty','conflict','uncertainty','idle','arousal'])
    if(!Number.isFinite(s[k])||s[k]<0||s[k]>1)throw new Error('Telemetry '+k+' must be finite [0,1]');
  switch(role){
    case 'psyche':return [s.load,s.novelty,s.uncertainty];
    case 'heartspace':return [s.arousal,s.conflict,s.idle];
    case 'network':return [s.uncertainty,s.novelty,1-s.load];
    case 'oneiric':return [s.idle,s.novelty,s.load];
    default:throw new Error('unknown role');
  }
}
class KokoroRippleBridge {
  constructor({dt=0.05,adaptive=true}={}){
    if(!(dt>0&&dt<=.5))throw Error('dt outside original core range');
    this.dt=dt;this.modules=Object.fromEntries(ROLES.map(n=>[n,new RippleNeuron({adaptive})]));
    this.monitor=new FluctuationMonitor(dt,400);this.frames=[];this.iterations=0;
  }
  step(telemetry,{capsule,frames=[]}={}){
    if(!capsule||!Array.isArray(frames))throw Error('continuity capsule and frames required');
    const capsule_hash=hashCapsule(capsule),events={},states={},reports={};
    for(const role of ROLES){
      const r=this.modules[role].step(mapTelemetry(role,telemetry),this.dt);
      events[role]=r.count;states[role]=r.theta;
      reports[role]={count:r.count,theta:r.theta,rate_hz:r.rate,drive:r.drive};
    }
    this.monitor.add(events,states);this.iterations++;
    const selected=frames.filter(f=>f&&f.approved===true&&typeof f.hypothesis==='string' && f.capsule_hash===capsule_hash)
      .slice(0,2).map(f=>({frame_id:f.frame_id, parent_id:f.parent_id??null, hypothesis:f.hypothesis,
           evidence:f.evidence??[],uncertainty:f.uncertainty??'unassessed',capsule_hash}));
    // Hard constraint gates do not depend on neuron firing; we must not let a low spike rate bypass them.
    const wakeResidue=telemetry.idle<0.5?[]:[]; // No dream -> fact promotion, ever.
    return {module_states:reports,capsule_hash,workspace:selected,dream_to_facts:wakeResidue,
      suggested_budget:{psyche:reports.psyche.count,heartspace:reports.heartspace.count,
       network:reports.network.count,oneiric:reports.oneiric.count},
      safety:{truth_gate:'mandatory',consent_gate:'mandatory',wake_gate:'mandatory',model_weights_changed:false}};
  }
  fluctuations(){return this.monitor.report();}
}
module.exports={KokoroRippleBridge,mapTelemetry,hashCapsule,ROLES};
