'use strict';
const {RippleNeuron}=require('./ripple_core.cjs');
// One-process virtual scheduler: workload capacity not real hardware parallelism.
function checksumTask(arr){
  if(!Array.isArray(arr)||arr.some(v=>!Number.isFinite(v)))throw Error('Invalid numeric task');
  return {sum:arr.reduce((a,b)=>a+b,0),sumsq:arr.reduce((a,b)=>a+b*b,0),n:arr.length};
}
class Colony {
 constructor({maxWorkers=8,elastic=true,dt=.05,minWorkers=1,highWater=4,retireGrace=6,spawnCooldown=1.5,adaptive=true,gating=true,loadTarget=false}={}){
  if(maxWorkers<minWorkers||minWorkers<1||maxWorkers>64||dt<=0||dt>.5)throw Error('colony configuration invalid');
  Object.assign(this,{maxWorkers,minWorkers,dt,elastic,highWater,retireGrace,spawnCooldown,adaptive,gating,loadTarget});
  this.t=0;this.workers=[];this.queue=[];this.completed=[];this.submitted=0;this.maxActive=0;this.spawned=0;this.retired=0;
  this.lastSpawn=-Infinity;this.lastBusy=0;this.highestQueue=0;this.addWorker();
 }
 addWorker(){ if(this.workers.length>=this.maxWorkers)return;
    const id=this.spawned++;const neuron=new RippleNeuron({adaptive:this.adaptive});neuron.t=this.t;this.workers.push({id,neuron,completed:0});this.maxActive=Math.max(this.maxActive,this.workers.length);this.lastSpawn=this.t;}
 submit(id,numbers){if(this.queue.some(j=>j.id===id)||this.completed.some(j=>j.id===id))throw Error('Duplicate job id');
   const expected=checksumTask(numbers);this.queue.push({id,numbers:numbers.slice(),expected,submittedAt:this.t});this.submitted++;}
 step(){
   if(this.queue.length>0)this.lastBusy=this.t;
   if(this.elastic&&this.queue.length>this.workers.length*this.highWater&&this.t-this.lastSpawn>=this.spawnCooldown)this.addWorker();
   const drive=this.queue.length>0?[.65,.1,.05]:[.05,0,.2];
   for(const w of this.workers){
     if(this.loadTarget){w.neuron.target=Math.min(4,1+this.queue.length/(4*this.workers.length));}
     const pulses=w.neuron.step(drive,this.dt);const count=this.gating?pulses.count:1;
     for(let k=0;k<count&&this.queue.length;k++){
       const j=this.queue.shift();const actual=checksumTask(j.numbers);
       if(actual.sum!==j.expected.sum||actual.sumsq!==j.expected.sumsq||actual.n!==j.expected.n)throw Error('Arithmetic integrity failed');
       w.completed++;this.completed.push({id:j.id,worker_id:w.id,submitted_at:j.submittedAt,done_at:(this.gating?pulses.events[k]:this.t+this.dt),duration_s:(this.gating?pulses.events[k]:this.t+this.dt)-j.submittedAt,result:actual});
     }
   }
   this.t+=this.dt;this.highestQueue=Math.max(this.highestQueue,this.queue.length);
   if(this.elastic&&this.queue.length===0&&this.workers.length>this.minWorkers&&this.t-this.lastBusy>this.retireGrace){this.workers.pop();this.retired++;this.lastBusy=this.t;}
 }
 stats(){let latency=this.completed.map(j=>j.duration_s),mean=latency.length?latency.reduce((a,b)=>a+b,0)/latency.length:null;
  const ordered=latency.slice().sort((a,b)=>a-b),p95=ordered.length?ordered[Math.ceil(.95*ordered.length)-1]:null;
  return {submitted:this.submitted,completed:this.completed.length,queued:this.queue.length,active:this.workers.length,max_active:this.maxActive,
    spawned:this.spawned,retired:this.retired,peak_queue:this.highestQueue,mean_virtual_latency_s:mean,p95_virtual_latency_s:p95};
 }
}
module.exports={Colony,checksumTask};
