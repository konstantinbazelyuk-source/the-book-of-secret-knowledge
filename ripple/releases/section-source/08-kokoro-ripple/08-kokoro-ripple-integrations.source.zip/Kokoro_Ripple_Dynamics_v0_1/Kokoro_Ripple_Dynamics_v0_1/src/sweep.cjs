'use strict';
const fs=require('node:fs'),path=require('node:path');const {Colony}=require('./colony.cjs');
const dt=.05,seconds=210;
// Deterministic traces of work arrival; identical traces reused by all variants.
function arrivals(scenario,t,i){
  if(scenario==='quiet')return i%400===0?1:0;
  if(scenario==='burst')return (t>=30&&t<95&&i%10===0)?2:(i%400===0?1:0);
  if(scenario==='sustained')return i%20===0?1:0;
  if(scenario==='intermittent')return (Math.floor(t/15)%2===0&&i%15===0)?1:0;
  throw Error('unsupported scenario');
}
const variants={
 'fixed_static':{elastic:false,adaptive:false},
 'adaptive_static':{elastic:false,adaptive:true},
 'adaptive_elastic_conservative':{elastic:true,adaptive:true,highWater:5,spawnCooldown:2.0,retireGrace:8},
 'adaptive_elastic_balanced':{elastic:true,adaptive:true,highWater:3,spawnCooldown:1.5,retireGrace:6},
 'adaptive_elastic_aggressive':{elastic:true,adaptive:true,highWater:1,spawnCooldown:.5,retireGrace:8},
 'adaptive_static_loadtarget':{elastic:false,adaptive:true,loadTarget:true},
 'adaptive_elastic_loadtarget':{elastic:true,adaptive:true,highWater:3,spawnCooldown:1.5,retireGrace:6,loadTarget:true},
 'idealized_ungated_upper_bound':{elastic:true,adaptive:true,highWater:3,gating:false}
};
function run(variant,scenario){
 const c=new Colony({maxWorkers:8,dt,...variants[variant]});const start=process.hrtime.bigint();
 const timepoints=[],counts=[];
 for(let i=0;i<seconds/dt;i++){
   const t=i*dt,arr=arrivals(scenario,t,i);
   for(let z=0;z<arr;z++)c.submit(`job-${i}-${z}`,Array.from({length:32},(_,k)=>(i+17*k)%97-48));
   c.step();if(i%20===0){timepoints.push(t);counts.push(c.workers.length);}
 }
 // allow up to 400 sec to finish, matching the simulator model budget
 for(let i=0;i<400/dt&&c.queue.length;i++)c.step();
 for(let i=0;i<20/dt;i++)c.step();
 const cpu_ms=Number(process.hrtime.bigint()-start)/1e6;
 const stats=c.stats();
 if(stats.completed!==stats.submitted||stats.queued!==0)throw Error('undrained queue '+variant+'/'+scenario);
 if(c.completed.some(x=>x.duration_s<0))throw Error('negative virtual latency');
 return {scenario,variant,wall_cpu_ms:cpu_ms,...stats,mean_active_workers:counts.reduce((a,b)=>a+b,0)/counts.length};
}
const rows=[];for(const scenario of ['quiet','burst','sustained','intermittent'])for(const variant of Object.keys(variants))rows.push(run(variant,scenario));
const dest=path.resolve(__dirname,'../results');fs.mkdirSync(dest,{recursive:true});
fs.writeFileSync(path.join(dest,'configuration_sweep.json'),JSON.stringify({description:'24 deterministic single-process software simulations; timings are runtime dependent and not hardware-independent performance',rows},null,2));
fs.writeFileSync(path.join(dest,'configuration_sweep.csv'),Object.keys(rows[0]).join(',')+'\n'+rows.map(x=>Object.values(x).join(',')).join('\n')+'\n');
console.log(JSON.stringify(rows.filter(r=>r.scenario==='burst').map(({variant,completed,max_active,peak_queue,p95_virtual_latency_s,wall_cpu_ms})=>({variant,completed,max_active,peak_queue,p95_virtual_latency_s,wall_cpu_ms})),null,2));
