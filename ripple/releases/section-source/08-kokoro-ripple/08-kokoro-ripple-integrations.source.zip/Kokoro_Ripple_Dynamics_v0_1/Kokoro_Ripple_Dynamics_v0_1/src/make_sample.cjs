'use strict';
const fs=require('node:fs'),path=require('node:path');
const {hashCapsule}=require('./kokoro_bridge.cjs');
const capsule={identity:'Kokoro del AI',task:'Analyze synthetic waveform test',source:'synthetic'};
const hc=hashCapsule(capsule),rows=[];
for(let i=0;i<240;i++){
 let t=i*.05,load=.3+.25*Math.sin(2*Math.PI*.5*t);
 rows.push({timestamp_s:+t.toFixed(3),origin:'synthetic',capsule,
 telemetry:{load,novelty:.4,conflict:.2,uncertainty:.3,idle:.2,arousal:.6},
 frames:[{frame_id:'trace-'+i,parent_id:null,hypothesis:'Synthetic trace observation',approved:true,capsule_hash:hc}]});
}
const p=path.resolve(__dirname,'../results/sample_telemetry.jsonl');
fs.writeFileSync(p,rows.map(v=>JSON.stringify(v)).join('\n')+'\n');
console.log(p);
