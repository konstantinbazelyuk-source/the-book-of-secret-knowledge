"""Loopback 3D motor operator: live, real VTK frames; simulated motor dynamics.
No LLM inference, external ports, remote API, Blender or physical sensor assertions.
"""
from __future__ import annotations
import argparse,hashlib,io,json,pathlib,sys,math,threading,time
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'compat'))
from motor.neuron import JOINT_LIMITS,MotorSkillMemory,run_trial
from vtk_renderer import Renderer

HTML='''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Ripple Motor Neuron · Kokoro 3D</title><style>body{background:#09101b;color:#e0e9f4;font:15px system-ui;margin:0}main{max-width:920px;margin:auto;padding:24px}h1{font:35px Georgia}p,small{color:#adbacb}section{display:grid;grid-template-columns:minmax(280px,1fr) 260px;gap:22px}img{width:100%;min-height:420px;object-fit:contain;border:1px solid #3c6570;border-radius:12px;background:#030b13}aside{background:#14202d;border:1px solid #415665;padding:20px;border-radius:12px}button,select{background:#173c43;color:#eaf9f7;border:1px solid #619c9d;border-radius:7px;padding:11px;cursor:pointer}label{display:block;margin:17px 0}pre{font-size:11px;white-space:pre-wrap;color:#9ad8c9}@media(max-width:650px){section{grid-template-columns:1fr}}</style></head><body><main><small>LUMINA 3D · RIPPLE MOTOR v0.7 · SIMULATED SERVO</small><h1>Kokoro’s Motor Neuron</h1><p>This view uses actual 3D skeletal deformation and render-to-PNG. Motor telemetry is simulated; no live trained Kokoro model or physical actuator is connected.</p><section><div><img id="frame" alt="Live 3D rendering of articulated Kokoro"/><p><small>Controller replays a 5.2-second greet motion. Compare fixed and cumulative feedforward under the same simulated plant.</small></p></div><aside><label>Motor control mode<select id="mode"><option value="learned">Cumulative motor memory</option><option value="baseline">Fixed PD baseline</option></select></label><button id="pause">Pause</button> <button id="restart">Restart trajectory</button><h3>Telemetry</h3><pre id="status">Connecting...</pre></aside></section></main><script>let serial=-1;async function post(d){await fetch('/api/control',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)})}document.querySelector('#mode').onchange=e=>post({mode:e.target.value});document.querySelector('#pause').onclick=async e=>{const paused=e.target.textContent==='Pause';await post({paused});e.target.textContent=paused?'Resume':'Pause'};document.querySelector('#restart').onclick=()=>post({restart:true});async function tick(){try{const s=await (await fetch('/api/state')).json();document.querySelector('#status').textContent=JSON.stringify(s,null,2);if(s.serial!==serial){serial=s.serial;document.querySelector('#frame').src='/frame.png?serial='+serial}}catch(e){document.querySelector('#status').textContent=e.message}}setInterval(tick,380);tick();</script></body></html>'''
class App:
 def __init__(self,size=(290,390),fps=6):
  self.size=size;self.fps=fps;self.lock=threading.Lock();self.controls={'mode':'learned','paused':False};self.running=True
  self.serial=0;self.latest=b'';self.sha='';self.sample_idx=0;self.joints=('arm_R','forearm_R','head')
  self.mem={j:MotorSkillMemory.load(ROOT/'results'/f'{j}_memory.json') for j in self.joints}
  self.trajectories={mode:{j:run_trial(j,ff=self.mem[j].ff if mode=='learned' else None) for j in self.joints} for mode in ('learned','baseline')}
  self.render_ms=0.;self.last_mode=''
 def set(self,obj):
  if not isinstance(obj,dict) or not obj or set(obj)-{'mode','paused','restart'}:raise ValueError('invalid keys')
  if 'mode' in obj and obj['mode'] not in {'learned','baseline'}:raise ValueError('invalid mode')
  if 'paused' in obj and type(obj['paused']) is not bool:raise ValueError('paused requires boolean')
  if 'restart' in obj and obj['restart'] is not True:raise ValueError('restart requires true')
  with self.lock:
   if 'mode' in obj:
    self.controls['mode']=obj['mode'];self.sample_idx=0
   if 'paused' in obj:self.controls['paused']=obj['paused']
   if 'restart' in obj:self.sample_idx=0
  return obj
 def run(self):
  r=Renderer(size=self.size)
  while self.running:
   started=time.perf_counter()
   with self.lock:mode=self.controls['mode'];paused=self.controls['paused'];i=self.sample_idx
   i=min(i,259)
   angles={j:self.trajectories[mode][j]['actual'][i] for j in self.joints}
   im=r.frame(i*.02,{'mode':'idle','joint_overrides':angles,'heart':.72,'scan':.18,'bloom':.55,'density':.32,'yaw':.43})
   f=io.BytesIO();im.save(f,format='PNG');blob=f.getvalue()
   with self.lock:
    self.latest=blob;self.sha=hashlib.sha256(blob).hexdigest();self.serial+=1;self.last_mode=mode;self.render_ms=r.last_stats['render_ms']
    if not paused:self.sample_idx=(self.sample_idx+max(1,round(50/self.fps)))%260
   time.sleep(max(0,1/self.fps-(time.perf_counter()-started)))
class Handler(BaseHTTPRequestHandler):
 def send(self,b,typ='application/json',status=200):
  self.send_response(status);self.send_header('Content-Type',typ);self.send_header('Content-Length',str(len(b)));self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(b)
 def do_GET(self):
  p=self.path.split('?')[0]
  if p=='/':return self.send(HTML.encode(),'text/html;charset=utf-8')
  with self.server.app.lock:
   a=self.server.app
   if p=='/frame.png':return self.send(a.latest,'image/png',200 if a.latest else 503)
   if p=='/api/state':return self.send(json.dumps({'serial':a.serial,'mode':a.controls['mode'],'paused':a.controls['paused'],'simulated_time_s':round(a.sample_idx*.02,3),'render_ms':a.render_ms,'sha256':a.sha,'3d_render':bool(a.latest),'source':'virtual simulated servo, not biological signal or real Kokoro LLM','learned_versions':{j:m.version for j,m in a.mem.items()}},indent=2).encode())
  return self.send(b'Not Found','text/plain',404)
 def do_POST(self):
  if self.path!='/api/control':return self.send(b'Not Found','text/plain',404)
  if self.headers.get('Content-Type','').split(';')[0]!='application/json':return self.send(b'JSON required','text/plain',415)
  try:
   n=int(self.headers.get('Content-Length','0'))
   if not 2<=n<=1024:raise ValueError('invalid request size')
   obj=json.loads(self.rfile.read(n));accepted=self.server.app.set(obj)
  except (ValueError,TypeError,json.JSONDecodeError) as e:return self.send(json.dumps({'error':str(e)}).encode(),status=400)
  return self.send(json.dumps({'accepted':accepted}).encode())
 def log_message(self,fmt,*args):pass

def main():
 p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8768);p.add_argument('--fps',type=int,default=6);p.add_argument('--width',type=int,default=290);p.add_argument('--height',type=int,default=390);a=p.parse_args()
 if not (1024<=a.port<=65535 and 1<=a.fps<=12 and 128<=a.width<=1920 and 128<=a.height<=1920):raise ValueError('operator resource limits')
 app=App((a.width,a.height),a.fps)
 server=ThreadingHTTPServer(('127.0.0.1',a.port),Handler);server.app=app
 t=threading.Thread(target=app.run,daemon=True);t.start()
 print('Ripple Motor 3D operator: http://127.0.0.1:'+str(a.port),flush=True)
 try:server.serve_forever()
 finally:app.running=False;server.server_close()
if __name__=='__main__':main()
