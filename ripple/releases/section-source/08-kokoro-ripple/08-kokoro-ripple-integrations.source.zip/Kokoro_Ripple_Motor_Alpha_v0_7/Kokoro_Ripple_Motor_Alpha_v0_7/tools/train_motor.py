"""Explicit training into caller's own new folder. Does not overwrite shipped baselines."""
import argparse,pathlib,sys,json
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from motor.neuron import MotorSkillMemory,JOINT_LIMITS
p=argparse.ArgumentParser();p.add_argument('--attempts',type=int,default=24);p.add_argument('--out',default='results/new_trial');args=p.parse_args()
if not 1<=args.attempts<=100:raise ValueError('attempts must be 1..100')
out=ROOT/args.out
if not out.resolve().is_relative_to(ROOT):raise ValueError('output must stay inside project')
out.mkdir(parents=True,exist_ok=True)
summary={}
for j in JOINT_LIMITS:
 m=MotorSkillMemory(j);before=m.evaluate()[0]['rmse']
 for k in range(args.attempts):m.learn(1.2)
 after=m.evaluate()[0]['rmse'];m.save(out/f'{j}_memory.json')
 summary[j]={'before':before,'after':after,'accepted':m.version,'attempts':args.attempts}
(out/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
