"""Optional Blender import and animated PNG rendering. UNTESTED if Blender absent.
Run: blender -b --python tools/blender_import_motor.py
"""
from __future__ import annotations
import pathlib,sys
try:import bpy
except ImportError as e:raise RuntimeError('Requires an actual Blender Python runtime') from e
BASE=pathlib.Path(__file__).resolve().parents[1]
model=BASE/'results/Kokoro_Ripple_Motor_Validated_Animation.glb'
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
bpy.ops.import_scene.gltf(filepath=str(model))
scene=bpy.context.scene
scene.render.engine='BLENDER_EEVEE_NEXT'
scene.frame_start=1;scene.frame_end=156;scene.render.fps=30
scene.render.resolution_x=560;scene.render.resolution_y=740;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG'
scene.render.filepath=str(BASE/'results/blender_motor_frame.png')
# Use imported camera only if one is present; otherwise user must set up a scene.
assert any(o.type=='ARMATURE' for o in scene.objects),'No armature imported'
scene.frame_set(65)
out=BASE/'results/Kokoro_Motor_Rig_Blend.blend'
bpy.ops.wm.save_as_mainfile(filepath=str(out))
print('BLENDER_IMPORT_OK',out)
