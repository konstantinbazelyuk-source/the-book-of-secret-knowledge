import subprocess,time,sys,pathlib,json,urllib.request,urllib.error,io,hashlib,socket
from PIL import Image
ROOT=pathlib.Path(__file__).resolve().parents[1]
with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
cmd=[sys.executable,str(ROOT/'tools/live_motor_server.py'),'--port',str(port),'--fps','4','--width','210','--height','275']
proc=subprocess.Popen(cmd,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
url='http://127.0.0.1:'+str(port)
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
def get(path):return opener.open(url+path,timeout=3)
def post(obj):return opener.open(urllib.request.Request(url+'/api/control',data=json.dumps(obj).encode(),headers={'Content-Type':'application/json'},method='POST'),timeout=3)
try:
 state=None
 for _ in range(80):
  try:
   state=json.load(get('/api/state'))
   if state['serial']>=2:break
  except Exception:pass
  time.sleep(.15)
 assert state and state['serial']>=2,state
 first=get('/frame.png').read();assert Image.open(io.BytesIO(first)).size==(210,275)
 assert json.load(post({'mode':'baseline','restart':True}))['accepted']['mode']=='baseline'
 other=None
 for _ in range(45):
  try:
   other=json.load(get('/api/state'))
   if other['mode']=='baseline' and other['serial']>=state['serial']+2:break
  except Exception:pass
  time.sleep(.15)
 assert other and other['mode']=='baseline' and other['serial']>=state['serial']+2,other
 second=get('/frame.png').read();assert hashlib.sha256(first).hexdigest()!=hashlib.sha256(second).hexdigest()
 try:post({'eval':'os.system'});raise AssertionError('unknown control accepted')
 except urllib.error.HTTPError as e:assert e.code==400
 report={'actual_http_operator_test':'passed','real_png_size':[210,275],'sha_before':hashlib.sha256(first).hexdigest(),'sha_after':hashlib.sha256(second).hexdigest(),'baseline_switched':True,'rejected_invalid_command':True,'synthetic_motion':True}
 (ROOT/'results/live_operator_test.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
finally:
 proc.terminate()
 try:proc.communicate(timeout=6)
 except subprocess.TimeoutExpired:proc.kill();proc.communicate()
