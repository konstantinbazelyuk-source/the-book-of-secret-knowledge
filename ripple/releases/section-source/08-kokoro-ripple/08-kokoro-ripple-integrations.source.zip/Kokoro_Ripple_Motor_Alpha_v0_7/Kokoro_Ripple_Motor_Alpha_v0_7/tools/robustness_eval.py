"""50 deterministic plant parameter combinations per joint; explicit simulation only."""
import sys,pathlib,json,csv,random,statistics,math
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from motor.neuron import MotorSkillMemory,run_trial,JOINT_LIMITS
from matplotlib import pyplot as plt
rng=random.Random(99);rows=[];summary={}
for joint in JOINT_LIMITS:
 m=MotorSkillMemory.load(ROOT/'results'/f'{joint}_memory.json')
 ratios=[];improves=0;worst=None
 for case in range(50):
  p={'gain':rng.uniform(.65,1.45),'damping':rng.uniform(1.9,3.9),'inertia':rng.uniform(.8,1.6),'disturbance':rng.uniform(-.15,.15)}
  base=run_trial(joint,plant_kwargs=p);learned=run_trial(joint,ff=m.ff,plant_kwargs=p)
  ratio=learned['rmse']/base['rmse'];better=ratio<1.0;improves+=int(better)
  row={'joint':joint,'case':case,'base_rmse':base['rmse'],'learned_rmse':learned['rmse'],'ratio':ratio,'improved':better,'base_events':base['events'],'learned_events':learned['events'],**p}
  rows.append(row);ratios.append(ratio)
  if worst is None or ratio>worst['ratio']:worst=row
 summary[joint]={'cases':50,'cases_improved':improves,'median_learned_over_baseline':statistics.median(ratios),
                 'worst_case_ratio':max(ratios),'best_case_ratio':min(ratios),
                 'negative_cases':sum(r>=1.0 for r in ratios),
                 'worst_case':{k:worst[k] for k in ('case','gain','damping','inertia','disturbance','ratio')}}
with (ROOT/'results/robustness_150_trials.csv').open('w',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
(ROOT/'results/robustness_summary.json').write_text(json.dumps({'status':'simulated parameter sweeps, not real hardware','seed':99,'summary':summary},indent=2))
fig,ax=plt.subplots(figsize=(8.5,4.4))
for j in JOINT_LIMITS:
 data=[r for r in rows if r['joint']==j]
 ax.plot([r['case'] for r in data],[r['ratio'] for r in data],marker='.',markersize=4,linewidth=1,label=j)
ax.axhline(1,linestyle='--',linewidth=1,label='fixed baseline')
ax.set(xlabel='Deterministic simulated plant variant',ylabel='Learned RMSE / fixed RMSE',title='Robustness of cumulative Ripple motor memory')
ax.legend(loc='best');fig.tight_layout();fig.savefig(ROOT/'results/robustness_chart.png',dpi=150);plt.close(fig)
fig,axs=plt.subplots(3,1,figsize=(8.8,8.0),sharex=True)
for ax,j in zip(axs,JOINT_LIMITS):
 m=MotorSkillMemory.load(ROOT/'results'/f'{j}_memory.json')
 b=run_trial(j);l=run_trial(j,ff=m.ff);ts=[i*.02 for i in range(b['samples'])]
 ax.plot(ts,b['desired'],label='target');ax.plot(ts,b['actual'],label='fixed');ax.plot(ts,l['actual'],label='learned');ax.set_ylabel(j+' (rad)');ax.grid(alpha=.2)
axs[0].legend();axs[-1].set_xlabel('Simulated seconds');fig.suptitle('Kokoro 3D motor joints: same target, fixed vs learned');fig.tight_layout();fig.savefig(ROOT/'results/tracking_curves.png',dpi=150);plt.close(fig)
print(json.dumps(summary,indent=2))
