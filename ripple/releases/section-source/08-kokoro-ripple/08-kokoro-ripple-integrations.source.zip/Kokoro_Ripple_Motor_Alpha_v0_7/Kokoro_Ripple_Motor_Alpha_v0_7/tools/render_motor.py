"""Real VTK avatar rendering of the virtual motor neuron output.
All motor positions come from a DECLARED SIMULATED SERVO, not sensors or Kokoro LLM.
"""
from __future__ import annotations
import argparse,sys, pathlib, json,time,hashlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'compat'))
from motor.neuron import MotorSkillMemory,run_trial
from vtk_renderer import Renderer

def render(learning=True,size=(320,420),frame_count=16,mode='both',outdir=None):
    outdir=pathlib.Path(outdir or ROOT/'results')
    memories={j:MotorSkillMemory.load(ROOT/'results'/f'{j}_memory.json') for j in ('arm_R','forearm_R','head')}
    states={j:run_trial(j,ff=memories[j].ff if learning else None) for j in memories}
    ren=Renderer(size=size)
    start=time.perf_counter();frames=[]
    from PIL import Image
    for i in range(frame_count):
        # This output samples an existing virtual-servo trajectory at exact indices.
        idx=min(states['arm_R']['samples']-1,round((i/(frame_count-1))*(states['arm_R']['samples']-1)))
        poses={j:r['actual'][idx] for j,r in states.items()}
        image=ren.frame(idx*.02,{'mode':'idle','joint_overrides':poses,'heart':.72,'scan':.15,'bloom':.55,'density':.35,'yaw':.44},post=True)
        frames.append(image)
    label='learned' if learning else 'baseline'
    png=outdir/f'motor_{label}_pose.png';frames[frame_count//2].save(png)
    gif=outdir/f'motor_{label}_3d.gif'
    frames[0].save(gif,save_all=True,append_images=frames[1:],duration=180,loop=0,optimize=False)
    return {'image':str(png),'gif':str(gif),'frames':len(frames),'render_elapsed_s':time.perf_counter()-start,
      'image_sha256':hashlib.sha256(png.read_bytes()).hexdigest(),'gif_sha256':hashlib.sha256(gif.read_bytes()).hexdigest(),
      'source':'offline simulation + actual VTK 3D pixel rendering','kokoro_model_connected':False}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--frames',type=int,default=16);p.add_argument('--width',type=int,default=320);p.add_argument('--height',type=int,default=420);p.add_argument('--baseline',action='store_true');a=p.parse_args()
    if not 2<=a.frames<=240:raise ValueError('frames out of range')
    report=render(not a.baseline,(a.width,a.height),a.frames)
    (ROOT/'results'/('learned_render_stats.json' if not a.baseline else 'baseline_render_stats.json')).write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))
