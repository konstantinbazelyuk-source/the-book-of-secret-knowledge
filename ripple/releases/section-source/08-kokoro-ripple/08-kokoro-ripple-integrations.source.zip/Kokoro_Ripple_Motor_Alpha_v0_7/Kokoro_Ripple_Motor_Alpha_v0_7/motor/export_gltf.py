"""Add independently generated learned motor animation to a COPY of the v0.6 GLB.
No modification to the original Kokoro 3D asset, no third-party code copied.
Khronos glTF 2.0 quaternion rotations (x,y,z,w) and aligned binary chunks.
"""
from __future__ import annotations
import json,math,struct,pathlib
from .neuron import MotorSkillMemory,run_trial
BASE=pathlib.Path(__file__).resolve().parents[1]
SRC=BASE/'compat/Kokoro_Lumina_Alpha_v0_6.glb'
JOINTS={'arm_R':9,'forearm_R':10,'head':5}

def quat(axis,angle):
    x,y,z=(0.,0.,0.)
    if axis=='y':y=math.sin(angle/2)
    else:z=math.sin(angle/2)
    return [x,y,z,math.cos(angle/2)]

def export_motor_glb(memories,out):
    b=SRC.read_bytes()
    if b[:4]!=b'glTF':raise ValueError('invalid GLB')
    jlen,jtype=struct.unpack_from('<I4s',b,12)
    if jtype!=b'JSON':raise ValueError('JSON chunk absent')
    g=json.loads(b[20:20+jlen]);offset=20+jlen
    blen,btype=struct.unpack_from('<I4s',b,offset)
    if btype!=b'BIN\0':raise ValueError('BIN chunk absent')
    blob=bytearray(b[offset+8:offset+8+blen]);assert len(blob)==g['buffers'][0]['byteLength']
    anim={'name':'Ripple_Motor_ILC_Validated','samplers':[],'channels':[]}
    def add_arr(items,typ,count,minimum=None,maximum=None):
        nonlocal blob
        pad=(-len(blob))%4
        blob.extend(b'\0'*pad)
        off=len(blob)
        blob.extend(struct.pack('<'+str(len(items))+'f',*items))
        view=len(g['bufferViews'])
        g['bufferViews'].append({'buffer':0,'byteOffset':off,'byteLength':len(items)*4})
        acc={'bufferView':view,'componentType':5126,'count':count,'type':typ}
        if minimum is not None:acc['min']=[minimum]
        if maximum is not None:acc['max']=[maximum]
        ix=len(g['accessors']);g['accessors'].append(acc);return ix
    # 20 fps downsampled to <=101 keyframes; validates a real learned pose path.
    samples=run_trial('arm_R',ff=memories['arm_R'].ff)['samples']
    indices=list(range(0,samples,3))
    if indices[-1]!=samples-1:indices.append(samples-1)
    t=[i*.02 for i in indices]
    times=add_arr(t,'SCALAR',len(t),t[0],t[-1])
    for name,node in JOINTS.items():
        m=memories[name]
        res=run_trial(name,ff=m.ff)
        angle=[res['actual'][i] for i in indices]
        axis='y' if name=='head' else 'z'
        values=[e for a in angle for e in quat(axis,a)]
        value_ix=add_arr(values,'VEC4',len(t))
        sid=len(anim['samplers']);anim['samplers'].append({'input':times,'output':value_ix,'interpolation':'LINEAR'})
        anim['channels'].append({'sampler':sid,'target':{'node':node,'path':'rotation'}})
    g['animations'].append(anim)
    g['buffers'][0]['byteLength']=len(blob)
    jb=json.dumps(g,separators=(',',':')).encode()
    jb+=b' '*((-len(jb))%4)
    blob.extend(b'\0'*((-len(blob))%4))
    result=struct.pack('<4sII',b'glTF',2,12+8+len(jb)+8+len(blob))+struct.pack('<I4s',len(jb),b'JSON')+jb+struct.pack('<I4s',len(blob),b'BIN\0')+blob
    dest=pathlib.Path(out);dest.write_bytes(result)
    return {'animation_name':anim['name'],'channels':len(anim['channels']),'keyframes':len(t),'duration_s':t[-1],'byte_length':len(result),'source_glb_untouched':True}
