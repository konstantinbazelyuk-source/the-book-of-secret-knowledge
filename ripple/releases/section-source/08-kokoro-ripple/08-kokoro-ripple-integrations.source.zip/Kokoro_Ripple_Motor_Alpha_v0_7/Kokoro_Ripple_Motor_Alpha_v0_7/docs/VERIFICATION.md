# Verification — Ripple Motor Alpha v0.7

## Runtime environment

Validation was conducted in the current sandbox, not on the user's device or in Blender. Python >=3.13, numpy 2.3.5, Pillow 12.3, VTK 9.6.2, trimesh 4.11.1 and matplotlib 3.10.8 were installed here. Dependencies are listed as minimum versions for a comparable Python environment but remain platform-dependent. No trained Kokoro model, camera, IMU, servomotor, Blender, Grok, Gemini or real robot is connected.

## Measured software results vs simulations

- **Algorithm simulation**: virtual second-order servo, explicit displacement, speed and acceleration constraints; one 5.2-second gesture sampled at 50Hz. Learning is 24 repeated update attempts on each of 3 joints.
- **Execution**: 34 unit tests passed against real Python code; fresh GLB imported with the independent `trimesh` loader; existing idle animation and new three-joint animation both present.
- **Graphics**: real VTK/EGL-rendered PNG/GIF images (16 frames each) differ for fixed and learned motor trajectories. This tests motor-to-skinning-to-pixel integration.
- **Live operator**: an HTTP control packet switched between fixed and learned modes. Two actual PNG responses had different SHA-256 hashes; unknown command was rejected with HTTP 400. Loopback only.
- **Robustness sweep**: 50 deterministic parameter sets per joint, seed=99. Not human motion data, and not measured real hardware.

## Nominal and held-out virtual plant

| Joint | Training RMSE fixed | Training RMSE learned | Held-out RMSE fixed | Held-out RMSE learned | Accepted of 24 |
|---|---:|---:|---:|---:|---:|
| arm_R | 0.173998 | 0.139204 | 0.331910 | 0.314436 | 24 |
| forearm_R | 0.087823 | 0.086675 | 0.109621 | 0.106579 | 2 |
| head | 0.015210 | 0.010204 | 0.026035 | 0.018148 | 19 |

All values in radians RMS from a **simulated control plant**. They are not the angular precision of a real physical robot, Blender rig or Kokoro agent.

## Generalization test (simulated)

| Joint | Improved on 50 virtual variants | Median RMSE ratio (learned / fixed) | Worst ratio |
|---|---:|---:|---:|
| arm_R | 50 | 0.84935 | 0.95154 |
| forearm_R | 44 | 0.98223 | 1.01282 |
| head | 49 | 0.70793 | 1.11306 |

**Negative results preserved**: 6 forearm and 1 head plant variations worsened. The candidate accept gate was tested on one fixed second plant; its use does not guarantee safety under all other simulated variations, let alone physical dynamics. Robustness range was gain=0.65–1.45, damping=1.9–3.9, inertia=0.8–1.6, disturbance=-0.15–0.15. Outside that range no evidence is provided.

## Integrity

The supplied original Javascript Ripple Neuron v0.1 file, the v0.5 Python port and the v0.6 GLB are byte-for-byte copied without edits. A new `compat/vtk_renderer.py` is intentionally altered to accept only three bounded joint overrides; this is labeled as a derived copy. Previous versions and archives remain untouched. The new GLB is a **separate** asset, not a replacement.

## Missing/untested

- Trained Kokoro checkpoint integration and Psyche/Heartspace live reports
- Actual Blender runtime import, skin preview or blend file
- Live high-fidelity camera/sensor measurements
- Human subject movement capture, torque tests, or physical servo validation
- General locomotion or open-world motion planning

## Reproduction commands

```shell
python -m unittest discover -s tests -p 'test_*.py' -v
python tools/test_live_operator.py
python tools/robustness_eval.py
python tools/render_motor.py --frames 16
python tools/render_motor.py --frames 16 --baseline
```
