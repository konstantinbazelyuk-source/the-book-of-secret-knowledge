# Additive Kokoro / Lumina motor port

1. Preserve the old v0.6 `Kokoro_Lumina_Alpha_v0_6.glb`. The new `results/Kokoro_Ripple_Motor_Validated_Animation.glb` is a second rig asset, with original `Ripple_Idle` plus `Ripple_Motor_ILC_Validated` (5.18 simulated seconds, 3 joint rotation tracks).
2. Use `motor.neuron.MotorNeuron` to sample a real **reported** angle and angular velocity only if a trustworthy source exists; never synthesize values and label them observed. No live Kokoro source is currently attached. The example `VirtualJointPlant` is explicitly simulated.
3. Use `MotorSkillMemory.load(...)` to read the accepted cumulative skill. It is separate JSON with SHA256 integrity; do not copy it into Kokoro Core language-model weights or Heartspace numerical coordinates.
4. Convert motor outputs to actual 3D rotations through `compat.vtk_renderer.pose(..., controls={'joint_overrides':{'arm_R':a,'forearm_R':b,'head':h}})`. Exactly three joint names supported; any unknown name or value outside the human-approved avatar rig constraints raises ValueError.
5. Control demo: `python tools/live_motor_server.py`; visits `127.0.0.1:8768`, enables toggling baseline vs learned mode. It does **not** train in the server or contact external networks. The non-GPU fallback is VTK offscreen rasterization, with a post-render image pass.
6. Optional Blender import `tools/blender_import_motor.py` is unexecuted in this environment; Blender was not installed and there is no `.blend` deliverable. Before use, confirm camera, bone axis conventions and GLB animation curves in the actual Blender UI.
7. To add a new skill, create its named target trajectory and per-joint limits; add baseline, held-out and adversarial evaluation; keep original memory as a rollback point. Do not extrapolate this gesture's learned feedforward to other contexts without new validation.

## Core isolation

The original Ripple leaky integrate-and-fire model retains its own threshold dynamics. The new motor-specific parameters (PD gains, virtual servo parameters, accepted feedforward corrections) belong solely to the new subsystem. No design creates awareness, consciousness, or a new general-purpose intelligence by itself.
