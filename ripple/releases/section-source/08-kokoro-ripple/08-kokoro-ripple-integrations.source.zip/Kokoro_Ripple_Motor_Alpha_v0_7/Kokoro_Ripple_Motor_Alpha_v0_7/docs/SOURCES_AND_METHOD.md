# Research + mathematical method (v0.7)

## Real source references

1. Original Ripple Neuron v0.1 (local project source `upstream/ripple_core_v0_1.js`, matching v0.6), originally adapted to Python in the v0.5 Forest (`upstream/ripple_core_v0_5.py`). The original event equation is preserved: D=2R+1.2G−1.4B; tau_v du/dt = -u+D; exact threshold crossing, reset, refractory and bounded adaptive threshold. Events are numerical abstractions.
2. Bristow, D.A., Tharayil, M., Alleyne, A.G. (2006), “A Survey of Iterative Learning Control,” IEEE Control Systems Magazine 26(3), 96–114. https://doi.org/10.1109/MCS.2006.1636313 — repeated-trial correction, convergence/robustness considerations. **Our fixed-gain, smoothing, and acceptance criteria are new local engineering choices, not copied theorem guarantees.**
3. Ijspeert, A.J., Nakanishi, J., Hoffmann, H., Pastor, P., Schaal, S. (2013), “Dynamical movement primitives: learning attractor models for motor behaviors,” Neural Computation 25(2), 328–373, DOI https://doi.org/10.1162/NECO_a_00393 — conceptual motivation for persistent parameterized motor skills, **NOT a DMP implementation**.
4. Khronos glTF 2.0 specification https://registry.khronos.org/glTF/specs/2.0/glTF-2.0.html — animations target joint nodes; quaternions are x/y/z/w; buffer chunks aligned to 4 bytes; imported GLB and preserved original idle clip.
5. Existing local Kokoro Lumina 3D Alpha v0.6 VTK renderer: derived `compat/vtk_renderer.py` now permits three constrained joint overrides. The prior v0.6 renderer and GLB are never written or overwritten.

## Cumulative algorithm

At time index i in repetition k:

- desired pose r_i is authored `target(t)` in radians.
- feedback servo u_i = clamp[k_p (r_i − q_i) + k_d (r_dot_i − v_i) + f_{k,i}] with output and output slew bounds.
- per-repetition memory proposal f_{k+1,i} = clamp[f_{k,i} + η (r_i − q_i)] smoothed by kernel `[1,2,1]/4`.
- stored only if training RMSE improves >=0.5%, validation RMSE worsens <=2%, and no hard joint-angle bound was hit.

Original Ripple event monitor receives software channels: normalized absolute tracking error, normalized commanded effort, and safety-range headroom. These are **not optical measurements**. The neuron event rate is observational and does **not** itself optimize the ILC correction. The distinction prevents spurious claims of consciousness or novel biologically faithful learning.

## Guardrails

- Only exact joints `arm_R`, `forearm_R`, `head` accepted for the motor extension.
- Only finite numeric commands, fixed joint bounds, speed and acceleration saturation, control effort clamps, max feedforward 3, nonnegative update budget.
- One gesture (`greet`) and 3 joints, not generalized motion planning. Unknown controls raise an error.
- Two test plants for transaction-like update validation. 50 additional deterministic randomized plant variants per joint in `results/robustness_150_trials.csv` demonstrate **empirical** out-of-set behavior (including some regressions).
- SHA256 motor memory integrity; `save()` uses write+fsync+atomic replace to an explicitly supplied destination. No other folder or original weights modified.
- No background outbound networking and no remote API calls; live operator binds only to 127.0.0.1.

## Criteria still needed before physical actuation

Motor torque/current limits, acceleration calibrated from real sensors, actuator identification, sensor feedback integrity, independent e-stop, collision handling, interlock design, conservative certification and a full robotic simulator (e.g. MuJoCo) — none are implemented and no real robot should be driven by this prototype.
