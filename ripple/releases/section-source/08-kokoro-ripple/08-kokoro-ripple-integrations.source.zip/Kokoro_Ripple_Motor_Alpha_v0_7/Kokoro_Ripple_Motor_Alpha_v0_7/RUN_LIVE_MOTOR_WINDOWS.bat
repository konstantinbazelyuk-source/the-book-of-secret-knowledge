@echo off
cd /d "%~dp0"
python -m pip install -r requirements-render.txt
python tools\live_motor_server.py --port 8768 --fps 6
pause
