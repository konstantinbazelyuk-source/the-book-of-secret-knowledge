"""Functional and regression tests of Ripple Motor, 3D rig and archive provenance."""
import sys,pathlib,unittest, tempfile, math, json, random,hashlib,struct,ast
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'compat'))
from motor.neuron import MotorSkillMemory,MotorNeuron,VirtualJointPlant,run_trial,target,JOINT_LIMITS,DT
from motor.export_gltf import export_motor_glb
from vtk_renderer import Renderer,load_model,pose,apply_skin
import numpy as np
from PIL import ImageChops
class MotorContracts(unittest.TestCase):
 def test_registered_joints(self):self.assertEqual(set(JOINT_LIMITS),{'arm_R','forearm_R','head'})
 def test_target_starts_zero(self):self.assertEqual(target(0)['arm_R'],0.)
 def test_target_continuity(self):
  for j in JOINT_LIMITS:
   a=[target(i*.01)[j] for i in range(521)];self.assertLess(max(abs(a[i]-a[i-1]) for i in range(1,len(a))),.035)
 def test_target_within_joint_limits(self):
  for i in range(521):
   for j,q in target(i*.01).items():
    lo,hi=JOINT_LIMITS[j];self.assertTrue(lo<=q<=hi)
 def test_bad_skill(self):
  with self.assertRaises(ValueError):target(.4,'make_sword')
 def test_bad_joint(self):
  with self.assertRaises(ValueError):MotorNeuron('unknown')
 def test_finite_inputs(self):
  for v in [float('nan'),float('inf'),-float('inf'),'0.4',True]:
   with self.subTest(v=v):
    with self.assertRaises(ValueError):MotorNeuron().step(0,0,0,.4,v)
 def test_bad_dt(self):
  with self.assertRaises(ValueError):MotorNeuron().step(0,0,0,.2,0,0)
 def test_out_of_range_pose(self):
  with self.assertRaises(ValueError):MotorNeuron('arm_R').step(0,50,0,.2,0)
 def test_neuron_events_are_software(self):
  n=MotorNeuron('arm_R')
  for i in range(500):n.step(i*.02,0,0,1.2,0)
  self.assertGreater(sum(s.event_count for s in n.samples),0)
  self.assertGreater(n.monitor.t,9.99)
 def test_learning_reduces_arm_error(self):
  m=MotorSkillMemory('arm_R');start=m.evaluate()[0]['rmse']
  for _ in range(8):m.learn(eta=1.2)
  self.assertLess(m.evaluate()[0]['rmse'],start*.94)
 def test_heldout_gate(self):
  m=MotorSkillMemory('arm_R')
  for i in range(5):
   b=m.evaluate()[1]['rmse'];res=m.learn(1.2)
   if res['accepted']:self.assertLessEqual(m.evaluate()[1]['rmse'],b*1.02)
 def test_forearm_rejection(self):
  m=MotorSkillMemory('forearm_R');accepted=[m.learn(1.2)['accepted'] for _ in range(8)]
  self.assertIn(False,accepted)
  self.assertLess(sum(accepted),8)
 def test_rejection_preserves_weights(self):
  m=MotorSkillMemory('forearm_R')
  for _ in range(6):
   prev=m.ff.copy();res=m.learn(1.2)
   if not res['accepted']:self.assertEqual(prev,m.ff)
 def test_cumulative_version(self):
  m=MotorSkillMemory('arm_R');accepted=0
  for _ in range(6):accepted+=int(m.learn(1.2)['accepted'])
  self.assertEqual(m.version,accepted)
 def test_bounds_after_training(self):
  m=MotorSkillMemory('arm_R')
  for _ in range(30):m.learn(1.2)
  self.assertLessEqual(max(map(abs,m.ff)),3)
 def test_save_load_integrity(self):
  m=MotorSkillMemory('arm_R');m.learn(1.2)
  with tempfile.TemporaryDirectory() as tmp:
   p=pathlib.Path(tmp)/'safe.json';m.save(p);n=MotorSkillMemory.load(p)
   self.assertEqual(n.ff,m.ff);self.assertEqual(n.version,m.version)
 def test_tampered_checkpoint_rejected(self):
  m=MotorSkillMemory('arm_R')
  with tempfile.TemporaryDirectory() as tmp:
   p=pathlib.Path(tmp)/'safe.json';m.save(p);r=json.loads(p.read_text());r['payload']['weights'][0]=2.2;p.write_text(json.dumps(r))
   with self.assertRaises(ValueError):MotorSkillMemory.load(p)
 def test_bad_memory_shape(self):
  with self.assertRaises(ValueError):run_trial('arm_R',ff=[1,2,3])
 def test_simulated_plant_never_exceeds_joint_limit(self):
  for j in JOINT_LIMITS:
   p=VirtualJointPlant(j)
   for u in [30]*400+[-30]*400:
    x,v=p.step(u)
    self.assertTrue(JOINT_LIMITS[j][0]<=x<=JOINT_LIMITS[j][1])
 def test_simulated_speed_bounded(self):
  p=VirtualJointPlant('head');
  for _ in range(400):x,v=p.step(30)
  self.assertLessEqual(abs(v),1.3)
 def test_original_ripple_source_sha_unchanged(self):
  a=ROOT/'upstream/ripple_core_v0_5.py';b=pathlib.Path('/mnt/data/Kokoro_Lumina_3D_Alpha_v0_6/sources/forest_v05/ripple_core.py')
  if b.exists():self.assertEqual(hashlib.sha256(a.read_bytes()).digest(),hashlib.sha256(b.read_bytes()).digest())
 def test_original_js_source_sha_unchanged(self):
  a=ROOT/'upstream/ripple_core_v0_1.js';b=pathlib.Path('/mnt/data/Kokoro_Lumina_3D_Alpha_v0_6/sources/ripple_core_v0_1.js')
  if b.exists():self.assertEqual(hashlib.sha256(a.read_bytes()).digest(),hashlib.sha256(b.read_bytes()).digest())
 def test_loaded_memories_have_accepted_versions(self):
  for j in JOINT_LIMITS:
   m=MotorSkillMemory.load(ROOT/'results'/f'{j}_memory.json')
   self.assertEqual(m.version,sum(int(h['accepted']) for h in m.history))
 def test_render_animation_loaded(self):
  b=(ROOT/'results/Kokoro_Ripple_Motor_Validated_Animation.glb').read_bytes()
  magic,version,total=struct.unpack_from('<4sII',b,0)
  self.assertEqual((magic,version,total),(b'glTF',2,len(b)))
  size,typ=struct.unpack_from('<I4s',b,12);g=json.loads(b[20:20+size]);self.assertEqual(typ,b'JSON')
  self.assertEqual([x['name'] for x in g['animations']],['Ripple_Idle','Ripple_Motor_ILC_Validated'])
  self.assertEqual({g['nodes'][x['target']['node']]['name'] for x in g['animations'][1]['channels']},{'arm_R','forearm_R','head'})
  self.assertEqual(len(g['animations'][1]['channels']),3)
 def test_exported_quaternions_normalized(self):
  b=(ROOT/'results/Kokoro_Ripple_Motor_Validated_Animation.glb').read_bytes();l=struct.unpack_from('<I',b,12)[0];g=json.loads(b[20:20+l]);bl=20+l;binary=b[bl+8:];anim=g['animations'][1]
  for sampler in anim['samplers']:
   acc=g['accessors'][sampler['output']];view=g['bufferViews'][acc['bufferView']]
   self.assertEqual(acc['type'],'VEC4');offset=view['byteOffset']+acc.get('byteOffset',0)
   for i in range(acc['count']):
    q=struct.unpack_from('<4f',binary,offset+16*i)
    self.assertAlmostEqual(sum(x*x for x in q),1.0,places=5)
 def test_generated_animated_clip_is_not_original(self):
  newer=(ROOT/'results/Kokoro_Ripple_Motor_Validated_Animation.glb').read_bytes()
  prior=(ROOT/'compat/Kokoro_Lumina_Alpha_v0_6.glb').read_bytes()
  self.assertNotEqual(hashlib.sha256(newer).hexdigest(),hashlib.sha256(prior).hexdigest())
 def test_original_glb_untouched(self):
  a=ROOT/'compat/Kokoro_Lumina_Alpha_v0_6.glb';b=pathlib.Path('/mnt/data/Kokoro_Lumina_3D_Alpha_v0_6/web/Kokoro_Lumina_Alpha_v0_6.glb')
  if b.exists():self.assertEqual(hashlib.sha256(a.read_bytes()).digest(),hashlib.sha256(b.read_bytes()).digest())
 def test_rig_bone_names(self):
  data,arrays=load_model();self.assertEqual(len(data['bones']),20)
  for n in JOINT_LIMITS:self.assertIn(n,[b['name'] for b in data['bones']])
 def test_rig_joint_motor_pose_moves_mesh(self):
  data,a=load_model()
  base=pose(data['bones'],0,{'mode':'idle'})
  angle=pose(data['bones'],0,{'mode':'idle','joint_overrides':{'arm_R':1.0,'forearm_R':-.2,'head':.1}})
  p0,_=apply_skin(a['pos'],a['normal'],a['joints'],a['weights'],base)
  p1,_=apply_skin(a['pos'],a['normal'],a['joints'],a['weights'],angle)
  self.assertGreater(float(np.max(np.abs(p0-p1))),.2)
 def test_rig_rejects_bad_joints(self):
  data,a=load_model()
  for ctl in [{'arm_L':.3},{'arm_R':3.2},{'head':float('nan')}]:
   with self.subTest(ctl=ctl):
    with self.assertRaises(ValueError):pose(data['bones'],0,{'joint_overrides':ctl})
 def test_blender_optional_script_parses(self):ast.parse((ROOT/'tools/blender_import_motor.py').read_text())
 def test_rendered_images_are_distinct(self):
  b=ROOT/'results/motor_baseline_pose.png';a=ROOT/'results/motor_learned_pose.png'
  self.assertNotEqual(hashlib.sha256(b.read_bytes()).hexdigest(),hashlib.sha256(a.read_bytes()).hexdigest())
 def test_no_original_source_edits(self):
  # The extended renderer lives in compat/; the original 3D Alpha file is never written.
  self.assertTrue((ROOT/'compat/vtk_renderer.py').exists())

if __name__=='__main__':unittest.main(verbosity=2)
