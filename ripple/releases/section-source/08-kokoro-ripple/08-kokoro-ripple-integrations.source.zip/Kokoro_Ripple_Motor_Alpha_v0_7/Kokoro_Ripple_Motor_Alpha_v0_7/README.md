# Kokoro Ripple Motor Neuron — Alpha v0.7

**A functioning motion-control subsystem, NOT a trained motor intelligence or physical servo.**

The earlier Kokoro/Lumina v0.6 has a genuine 20-joint skinned 3D android and the earlier Ripple Neuron has bounded event-generating LIF math. This release adds a **separate, cumulative motor-skill subsystem** without modifying either original. It learns a time-indexed feedforward signal for three avatar joints (`arm_R`, `forearm_R`, `head`) as it repeats a simulated greeting gesture. All reported state originates from a **virtual plant**, not from a user camera, real robot, Kokoro trained checkpoint, Blender, or external AI model.

## New neuron structure

`target trajectory -> error + speed -> PD feedback + retained feedforward -> bounded command -> virtual joint plant -> angle/speed feedback -> Ripple LIF event sensor -> episode error -> gated ILC update -> validation or rollback`

The LIF neuron is imported unchanged from the v0.5-preserved port of original Ripple v0.1. It observes numerical tracking error, effort and proximity to joint bounds (not literal RGB light). Its emitted software events are logged. The **new learning mechanism** is a bounded smoothed iterative-learning-control (ILC) correction accumulated per 5.2-second repetition. Learning changes only a separate JSON motor memory, and only after an explicit training request. Trained Kokoro weights are not accessed or modified.

The test scenario uses a second-order virtual joint servo with velocity, acceleration, range and input limits. A candidate correction is accepted only when training RMSE falls by at least 0.5% and a second declared plant does not worsen by over 2%. Rejected changes leave the last verified weights intact. This is a **local test heuristic**, not a robust universal guarantee. A 50-plant-per-joint evaluation is included to test generalization.

## Start the working 3D operator

Requires Python 3.10+ and the packages in `requirements-render.txt` (VTK needs compatible EGL/OpenGL drivers on the execution machine).

```bash
python -m pip install -r requirements-render.txt
python tools/live_motor_server.py --port 8768 --fps 6
```

Open `http://127.0.0.1:8768`. Switch between fixed controller and cumulative memory. The 3D geometry is rendered afresh using VTK and the pose data is created from the **simulated** joint servo. There is **no actual Blender instance** and no physical robot connection. The server binds to localhost. It does not train while serving.

## Run the experiments

```bash
python -m unittest discover -s tests -p 'test_*.py' -v
python tools/test_live_operator.py
python tools/robustness_eval.py
python tools/render_motor.py --frames 16 --width 300 --height 395
```

Motor memories were generated using 24 bounded update attempts per joint; the saved JSON files and generated motor GLB are included. Run a new training experiment on separate copies, not on this approved baseline:

```bash
python tools/train_motor.py --attempts 24 --out results/new_trial
```

The generated `results/Kokoro_Ripple_Motor_Validated_Animation.glb` **adds** `Ripple_Motor_ILC_Validated` with 3 animated joints and keeps the original `Ripple_Idle` animation in a newly written GLB. The original `compat/Kokoro_Lumina_Alpha_v0_6.glb` is byte-for-byte preserved. The GLB was imported by trimesh; it has **not** been imported or rendered by Blender in this session. The opt-in Blender import script is untested because Blender is absent.

## Limitations and safety

- This is a controller specializing in repeated motor trajectories. It is not generalized skill acquisition, robot learning from physical sensors, latent model training, consciousness, or proof of improved real LLM intelligence.
- The generated avatar retains the **experimental** visual identity from v0.6, not a finalized Kokoro character.
- The virtual plant is a simple second-order model; real humanoid motor dynamics are not represented.
- The 50-case randomized test set explores a constrained synthetic parameter range, not real hardware variation.
- No imported external research code or proprietary model weights are included; design references are cited in `docs/SOURCES_AND_METHOD.md`.
- Source hashes and outputs are catalogued in `MANIFEST.sha256`. Sources from previous versions are preserved in `upstream/` and `compat/`; `compat/vtk_renderer.py` is the explicitly extended renderer, *not* an original.
