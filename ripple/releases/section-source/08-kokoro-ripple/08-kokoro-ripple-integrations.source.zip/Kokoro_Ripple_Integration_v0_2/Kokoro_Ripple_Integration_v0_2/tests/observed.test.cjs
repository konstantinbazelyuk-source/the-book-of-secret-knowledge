'use strict';
const test=require('node:test'), assert=require('node:assert/strict');
const fs=require('node:fs'),cp=require('node:child_process'),crypto=require('node:crypto'),path=require('node:path');
const {analyzeObservedRows}=require('../src/observed_adapter.cjs');
const {RippleNeuron}=require('../src/ripple_core.cjs');
const {KokoroController}=require('../src/integration.cjs');
const orig=fs.readFileSync(path.join(__dirname,'../source_v0_1/ripple_core.cjs'));
const curr=fs.readFileSync(path.join(__dirname,'../src/ripple_core.cjs'));
const expHash='92cfa7aacb7ee09f4e2b9bf03956b8db1e477d879846cf1fdaf4e186c11d0f4a';
function sample(i,extras={}){return {origin:'observed-runtime',timestamp_s:i*.05,process_cpu_s:i*.023,queue_depth:i%4,rss_bytes:12000000+i*1024,...extras};}
const make=()=>Array.from({length:60},(_,i)=>sample(i));
test('original Ripple kernel byte-for-byte unchanged',()=>{assert.deepEqual(curr,orig);assert.equal(crypto.createHash('sha256').update(curr).digest('hex'),expHash)});
test('original step emits bounded finite states',()=>{const n=new RippleNeuron();for(let i=0;i<800;i++){const out=n.step([i<400?.35:.7,0,0],.05);assert(Number.isFinite(out.theta)&&out.theta>=.15&&out.theta<=2.5)}});
test('real trace requires explicit origin',()=>assert.throws(()=>analyzeObservedRows([{...sample(0),origin:'found'},{...sample(1),origin:'found'}])));
test('requires at least 2 samples',()=>assert.throws(()=>analyzeObservedRows([sample(0)])));
test('observed trace derives measured CPU ratio',()=>{const r=analyzeObservedRows(make());assert(Math.abs(r.cpu_seconds_per_wall_second-.46)<1e-10);assert.equal(r.channels.runtime_cpu.samples,59)});
test('peak reported memory preserved as reported',()=>{const r=analyzeObservedRows(make());assert.equal(r.peak_reported_rss_bytes,12000000+59*1024)});
test('absent unreported daughterboard signals stay unavailable',()=>{const r=analyzeObservedRows(make());for(const c of ['psyche_candidates','network_conflict_fraction','heartspace_reported_arousal','oneiric_reported_idle'])assert.equal(r.channels[c].status,'unavailable')});
test('queue channel explicitly observed',()=>{const r=analyzeObservedRows(make());assert.equal(r.channels.runtime_queue.samples,59);assert(r.channels.runtime_queue.input_max>0.5)});
test('missing queue not invented',()=>{const r=analyzeObservedRows(make().map(({queue_depth,...rest})=>rest));assert.equal(r.channels.runtime_queue.status,'unavailable')});
test('explicit frame values produce psyche signals',()=>{const r=analyzeObservedRows(make().map(s=>({...s,frame_candidate_count:4})));assert.equal(r.channels.psyche_candidates.samples,59)});
test('source conflicts require measured retrieval increments',()=>{const r=analyzeObservedRows(make().map((s,i)=>({...s,source_checked_total:i,source_conflict_total:Math.floor(i/3)})));assert.equal(r.channels.network_conflict_fraction.samples,59)});
test('zero source additions mean unavailable network signal',()=>{const r=analyzeObservedRows(make().map(s=>({...s,source_checked_total:1,source_conflict_total:0})));assert.equal(r.channels.network_conflict_fraction.status,'unavailable')});
test('no synthetic-to-observed origin laundering',()=>assert.throws(()=>analyzeObservedRows([sample(0),{...sample(1),origin:'synthetic'}])));
test('clock not monotonic',()=>assert.throws(()=>analyzeObservedRows([sample(1),sample(0)])));
test('cpu counter not monotonic',()=>assert.throws(()=>analyzeObservedRows([sample(0),{...sample(1),process_cpu_s:-0.1}])));
test('sample gaps over 500ms rejected',()=>assert.throws(()=>analyzeObservedRows([sample(0),{...sample(1),timestamp_s:1}])));
test('missing process CPU rejected',()=>assert.throws(()=>analyzeObservedRows([sample(0),{...sample(1),process_cpu_s:undefined}])));
test('reported arousal out of range rejected',()=>assert.throws(()=>analyzeObservedRows([sample(0),{...sample(1),heartspace_arousal:1.5}])));
test('reported idle out of range rejected',()=>assert.throws(()=>analyzeObservedRows([sample(0),{...sample(1),oneiric_idle_fraction:-.1}])));
test('bad frame counts rejected',()=>assert.throws(()=>analyzeObservedRows([sample(0),{...sample(1),frame_candidate_count:NaN}])));
test('negative source increments rejected',()=>assert.throws(()=>analyzeObservedRows([sample(0,{source_checked_total:2,source_conflict_total:1}),sample(1,{source_checked_total:1,source_conflict_total:0})])));
test('conflicts cannot exceed retrievals',()=>assert.throws(()=>analyzeObservedRows([sample(0,{source_checked_total:1,source_conflict_total:1}),sample(1,{source_checked_total:2,source_conflict_total:3})])));
test('no inference without real callback',async()=>{const c=new KokoroController();assert.equal((await c.respond({text:'test',context:{}})).status,'model_not_connected')});
test('source core never imports remote services',()=>{assert(!curr.includes('fetch('));assert(!curr.includes('https://'))});
test('Python port matches JS events and thresholds for varied signals',()=>{
 const samples=Array.from({length:1500},(_,i)=>[.1+.85*((i*17)%101)/100,.5*((i*11)%97)/96,.6*((i*19)%89)/88]);
 const n=new RippleNeuron();let js=[];for(const x of samples){const r=n.step(x,.05);js.push([r.t,r.u,r.theta,r.rate,r.count,r.events])}
 const code=`import json,sys\nsys.path.insert(0, ${JSON.stringify(path.resolve(__dirname,'../python'))})\nfrom ripple_python import RippleNeuron\nn=RippleNeuron()\narr=json.load(sys.stdin)\nfor x in arr:\n r=n.step(x,0.05)\n print(json.dumps([r['t'],r['u'],r['theta'],r['rate'],r['count'],r['events']]))`;
 const p=cp.spawnSync('python',['-c',code],{encoding:'utf8',input:JSON.stringify(samples),maxBuffer:10*1024*1024});
 assert.equal(p.status,0,p.stderr);const py=p.stdout.trim().split('\n').map(JSON.parse);assert.equal(py.length,js.length);
 for(let i=0;i<js.length;i++){for(let j=0;j<4;j++)assert(Math.abs(js[i][j]-py[i][j])<1e-8,`mismatch ${i} ${j}: ${js[i][j]} vs ${py[i][j]}`);assert.equal(js[i][4],py[i][4]);assert.equal(js[i][5].length,py[i][5].length)}
});
