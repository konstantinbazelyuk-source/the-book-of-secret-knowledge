# Kokoro × Ripple v0.2: Integration and testing infrastructure

## Architectural continuity

Preserve **Kokoro Core**, **Psyche Daughterboard**, **Heartspace Daughterboard**, **Psyche Network**, **Oneiric Resonance System**, **Genesis/Adaptive Trainer**, and optional Pocket Time. Ripple is added as a **read-only runtime observer**. It may suggest scheduling policies, but no automatic tool permissions, memory rewriting, fact promotion, or checkpoint edits are allowed. The recovered Psyche contract uses `frame_id`, `parent_id`, evidence, confidence, salience, selected workspace and continuity hash. The recovered Oneiric contract includes a Wake Gate and separate read-only adapters. This release changes neither.

### Execution path (current)

```
Actual running application (Kokoro if local model is available)
   └── Python generator wrapper [optional instrumented source]
           ├── perf_counter_ns (observed monotonic wall time)
           ├── process_time_ns (observed process CPU usage)
           ├── Linux /proc/self/statm current RSS (observed, optional)
           ├── actual outstanding jobs (component-reported when provided)
           └── optional real daughterboard counters
                    ↓
             explicit, local JSONL event log
                    ↓
             schema/monotonicity/provenance checks
                    ↓
             normalized scalar -> Ripple channel input
                    ↓
             unchanged Ripple LIF math
                    ↓
             event counts / thresholds / measurable fluctuations
                    ↓
             read-only report / integration comparison
```

`D=2R+1.2G-1.4B` is unchanged. We use a **software scalar projection** `R=value/2,G=0,B=0`, so `D=value`. This is an engineered computational mapping, **not** camera RGB, an electromagnetic field measurement, an emotional sensor, or a measured physical light signal.

## Channels and admissibility

| Role / observable | Input | Availability rule | Units |
|---|---|---|---|
| `runtime_cpu` | Difference of process CPU seconds divided by wall seconds, clipped to `[0,1]` for one-core saturation | Both monotonic clocks required | Normalized 1-core equivalent; not whole-machine load |
| `runtime_queue` | `q/(q+2)` | Explicit measured/instrumented `queue_depth` | Dimensionless |
| `psyche_candidates` | `f/(f+2)` | Actual reported candidate-frame count | Dimensionless |
| `network_conflict_fraction` | Δ conflicts / Δ sources checked | Both monotonic counters, positive Δ sources | Ratio |
| `heartspace_reported_arousal` | Direct normalized component export | Explicit Heartspace value only | Component-defined, **not calibrated feeling** |
| `oneiric_reported_idle` | Direct component-defined idle fraction | Explicit Oneiric value only | Component-defined |

Absent values remain **unavailable**. We do not fill missing information with arbitrary zeros. An actual process-time measurement does not prove the attached workload is trained Kokoro. A trace can be truthful while the numerical work is synthetic.

## Identity and truth gates

- The previous Kokoro controller has a continuity hash gate. New telemetry cannot introduce frames into the workspace. It records values, not conclusions.
- Real source provenance is separately maintained by Psyche Network and is not replaced with neuron spikes.
- Do not infer emotions, desires, consciousness, understanding, or trustworthiness from Ripple events.
- No autonomous writing to any memory, repository, weights or model settings; no network calls or access tokens.
- No inference claim without loading a real Kokoro checkpoint, fixed test set, repeatable seeds, measured responses and separate evaluation.

## Independent test environment assessment (13 Oct 2026)

1. **Floot connector VM — externally EXECUTED.** A read-only numeric experiment ran in an isolated VM associated with `Ripple Neuron — Phone Lab`, Node `v22.23.2`. Original historical rate windows reproduced: adaptive `[1.00,0.95,1.00]` Hz; fixed `[1.65,3.40,1.65]` Hz. Approximately 17.9 ms **remote runtime for that small math experiment**; not a general speed comparison. It did not edit any project files or connect a trained model.
2. **Google Colab — OFFICIAL FREE TIER, prepared but not executed in user's account.** Free interactive Jupyter CPU and availability-dependent GPU/TPU; sessions can terminate; free Colab forbids distributed worker farms and persistent web-app usage. The notebook can be uploaded to run read-only tests. Official: https://research.google.com/colaboratory/faq.html
3. **GitHub Actions — WORKFLOW PREPARED, not yet deployed.** Standard runner jobs on public repositories free under current GitHub policy, with plan-specific minutes for private repos. Limits and possible billing for other services still apply; don't run continuous mining or sustained training. Official: https://docs.github.com/en/billing/managing-billing-for-your-products/managing-billing-for-github-actions/about-billing-for-github-actions
4. **Kaggle — AVAILABLE IN PRINCIPLE, not yet run.** Interactive Python notebooks and quota-limited GPU (Kaggle's docs cite a 30-hour-or-higher weekly GPU quota subject to demand). Avoid demanding GPU for CPU LIF validation. Official: https://www.kaggle.com/docs/efficient-gpu-usage
5. **Hugging Face Spaces — static demo possible for free, compute Space may require paid plan.** CPU Basic has no hourly hardware charge but new compute-backed Spaces presently require a paid account. Official: https://huggingface.co/docs/hub/en/spaces-overview
6. **Google Cloud trial — not needed**; requires payment verification, and expiration/upgrade terms create avoidable billing risk for this simple research phase. Official: https://cloud.google.com/signup-faqs

No free-tier service should be represented as guaranteed, indefinite, unlimited or permissionless. This release creates **no recurring infrastructure bill**.

## Next actual integration requirements

Find Kokoro's installed `kokoro.py`, `kokoro_core` implementation and the precise loaded checkpoint path from the laptop. Establish one actual token-generation run and timestamped input/output log. Mount the read-only observer without touching the original directories. If signal APIs exist, collect real Psyche frames, Psyche Network retrieval counters, Oneiric idle state and optional Heartspace state under an explicitly documented schema. Otherwise keep those channels unavailable.

Compare three modes on **the same frozen model and prompts**: (A) uninstrumented, (B) passive Ripple observer only, (C) separately authorized budget-control experiment. Record task correctness judged against labels, answer latency, peak resident memory, CPU/gpu utilization, energy (if actual sensor exists), and token throughput. Require significant measured improvement under repeated independent trials before letting adaptive firing influence budgets. Any failed evaluation rolls back only the added adapter.
