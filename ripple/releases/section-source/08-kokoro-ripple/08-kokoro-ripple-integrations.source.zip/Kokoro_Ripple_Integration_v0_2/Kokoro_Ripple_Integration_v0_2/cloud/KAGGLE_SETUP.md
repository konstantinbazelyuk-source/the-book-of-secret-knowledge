# Kaggle Notebook plan — optional free accelerator validation (NOT run yet)

1. Create a Kaggle Notebook in your own account and add the Kokoro Ripple v0.2 ZIP as a **private dataset** input. Check Kaggle's terms and your own sharing settings before adding any proprietary checkpoints or personal chat records.
2. Unzip the attached ZIP inside the Kaggle session (e.g. `/kaggle/working`).
3. Run `python -m unittest discover -s python/tests -v`. Use CPU first. To test the small untrained PyTorch model, run `python python/torch_compatibility.py` if torch is installed.
4. Run `node --version` to check whether Node is installed, then `npm test` if available; do not assume Kaggle has Node 20+.
5. Keep the runtime interactive. The original Ripple integration does **not** require a GPU. A GPU should only be enabled later for actual PyTorch model profiling if your account provides GPU quota.

Kaggle's documentation: https://www.kaggle.com/docs/efficient-gpu-usage . This has not been executed in the user's Kaggle account. No quota entitlement is assumed.
