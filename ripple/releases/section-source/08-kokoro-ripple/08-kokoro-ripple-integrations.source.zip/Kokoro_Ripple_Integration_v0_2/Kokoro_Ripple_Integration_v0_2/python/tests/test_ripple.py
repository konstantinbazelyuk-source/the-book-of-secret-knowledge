import math
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from ripple_python import RippleNeuron

class RippleTests(unittest.TestCase):
    def test_original_three_windows(self):
        a=RippleNeuron();f=RippleNeuron(adaptive=False)
        counts=[[0,0] for _ in range(3)]
        windows=[(20,40),(60,80),(100,120)]
        for i in range(2400):
            t=i*.05;r=.35 if t<40 or t>=80 else .7
            ea=a.step([r,0,0],.05)['events'];ef=f.step([r,0,0],.05)['events']
            for j,(lo,hi) in enumerate(windows):
                counts[j][0]+=sum(lo<=s<hi for s in ea)
                counts[j][1]+=sum(lo<=s<hi for s in ef)
        self.assertEqual([x[0]/20 for x in counts],[1,.95,1])
        self.assertEqual([x[1]/20 for x in counts],[1.65,3.4,1.65])

    def test_darkness_no_spontaneous_firing(self):
        n=RippleNeuron();self.assertEqual(sum(n.step([0,0,0],.05)['count'] for _ in range(400)),0)

    def test_bounded_threshold(self):
        n=RippleNeuron();
        for _ in range(2000):
            x=n.step([.95,.5,0],.05)
            self.assertTrue(.15<=x['theta']<=2.5)

    def test_nonfinite_rejected(self):
        with self.assertRaises(ValueError): RippleNeuron().step([math.nan,0,0],.05)

    def test_bad_dt_rejected(self):
        with self.assertRaises(ValueError): RippleNeuron().step([.5,0,0],.501)

if __name__=='__main__': unittest.main()
