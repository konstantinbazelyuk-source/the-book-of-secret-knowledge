"""Genuine PyTorch inference + Ripple instrumentation compatibility test.
Random-initialized tiny causal transformer: NOT trained Kokoro and NOT language intelligence.
No checkpoint modifications, downloads, network, GPU purchase or model output steering.
"""
import hashlib
import json
import statistics
import time
from pathlib import Path
from instrument_kokoro import TraceRecorder


def model_hash(model):
    sha=hashlib.sha256()
    for name,tensor in model.state_dict().items():
        sha.update(name.encode());sha.update(tensor.detach().cpu().contiguous().numpy().tobytes())
    return sha.hexdigest()


def run(output_path='results/torch_trace.jsonl',run_count=6,tokens=18):
    import torch
    from torch import nn
    torch.manual_seed(72621)
    torch.set_num_threads(2)

    class CausalTransformer(nn.Module):
        def __init__(self):
            super().__init__()
            self.embed=nn.Embedding(128,48)
            self.pos=nn.Embedding(48,48)
            layer=nn.TransformerEncoderLayer(48,4,dim_feedforward=96,dropout=0.0,batch_first=True,activation='gelu')
            self.block=nn.TransformerEncoder(layer,2,enable_nested_tensor=False)
            self.proj=nn.Linear(48,128)
        def forward(self,token_ids):
            seq=token_ids.size(1)
            x=self.embed(token_ids)+self.pos(torch.arange(seq,device=token_ids.device))
            causal=torch.triu(torch.ones(seq,seq,device=token_ids.device,dtype=torch.bool),diagonal=1)
            return self.proj(self.block(x,mask=causal))

    net=CausalTransformer().eval()
    original_hash=model_hash(net)
    def generate(recorder=None):
        ids=torch.tensor([[2,7,11]],dtype=torch.long)
        steps=[]
        with torch.inference_mode():
            for _ in range(tokens):
                t0=time.perf_counter_ns()
                predicted=int(net(ids)[0,-1].argmax().item())
                ids=torch.cat((ids,torch.tensor([[predicted]],dtype=torch.long)),dim=1)
                steps.append((time.perf_counter_ns()-t0)/1e6)
                if recorder:
                    recorder.report_tokens(1)
                    recorder.sample(queue_depth=1)
        return ids[0].tolist(),steps
    # Warm up CPU kernel and Torch thread pools. No optimizer or gradient steps.
    generate()
    results=[]
    for i in range(run_count):
        if i%2:
            with TraceRecorder(output_path) as rec:
                start=time.perf_counter_ns()
                ids,steps=generate(rec)
                wall=(time.perf_counter_ns()-start)/1e9
            mode='observed'
        else:
            start=time.perf_counter_ns()
            ids,steps=generate()
            wall=(time.perf_counter_ns()-start)/1e9
            mode='bare'
        results.append({'mode':mode,'wall_seconds':wall,'tokens_per_second':tokens/wall,'token_ids':ids,'token_ms_median':statistics.median(steps),'token_ms_p95':sorted(steps)[int(.95*len(steps))-1]})
    output_equal=len({tuple(x['token_ids']) for x in results})==1
    new_hash=model_hash(net)
    if not output_equal or original_hash!=new_hash:raise RuntimeError('Model changed or token outputs diverged with read-only adapter')
    grouped={mode:[v['wall_seconds'] for v in results if v['mode']==mode] for mode in ['bare','observed']}
    report={'classification':'measured actual PyTorch CPU inference using RANDOM UNTRAINED tiny causal transformer; no language intelligence',
       'hardware':{'torch':torch.__version__,'device':'cpu','threads':torch.get_num_threads()},
       'model':{'vocab_size':128,'embedding_dim':48,'layers':2,'attention_heads':4,'parameters':sum(x.numel() for x in net.parameters()),'trained':False},
       'token_count_per_run':tokens,'runs':results,
       'bare_median_wall_seconds':statistics.median(grouped['bare']),
       'observed_median_wall_seconds':statistics.median(grouped['observed']),
       'model_weights_before_sha256':original_hash,'model_weights_after_sha256':new_hash,
       'weights_unchanged':True,'token_outputs_identical':True,
       'caution':'Shared CPU, small sample, Python I/O and scheduling noise. Not an LLM speed or quality benchmark; no Kokoro checkpoint is loaded.'}
    return report


if __name__=='__main__':
    target=Path(__file__).resolve().parents[1]/'results'
    target.mkdir(parents=True,exist_ok=True)
    result=run(str(target/'torch_trace.jsonl'))
    (target/'torch_compatibility.json').write_text(json.dumps(result,indent=2),encoding='utf8')
    print(json.dumps({k:result[k] for k in ['model','bare_median_wall_seconds','observed_median_wall_seconds','weights_unchanged','token_outputs_identical']},indent=2))
