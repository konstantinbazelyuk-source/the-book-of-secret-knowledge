@echo off
setlocal
cd /d "%~dp0"
where python >nul 2>&1
if errorlevel 1 (
 echo Python 3 not found. Install it and retry.
 pause
 exit /b 1
)
where node >nul 2>&1
if errorlevel 1 (
 echo Node.js 20+ not found. Install it and retry.
 pause
 exit /b 1
)
echo [1] Python mathematical tests
python -m unittest discover -s python/tests -v || exit /b 1
echo [2] Node regression tests
call npm test || exit /b 1
echo [3] CPU telemetry instrumented demo
python python\instrument_kokoro.py results\measured_runtime.jsonl || exit /b 1
node src\observed_adapter.cjs results\measured_runtime.jsonl > results\measured_report_windows.json || exit /b 1
echo Completed. No model files or checkpoints touched.
pause
