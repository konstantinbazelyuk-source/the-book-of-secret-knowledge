# Kokoro / Adiliya × Ripple Integration Observatory v0.2

**Executed software, not a consciousness claim.** This is a strictly **read-only, opt-in** telemetry adapter intended to connect to the existing Kokoro del AI Foundry. It does **not** contain the user's trained Kokoro checkpoint, revise model weights, install into the live system, autonomously issue external commands, or infer real psychological states from CPU pressure.

## What now actually works

- The original **Ripple Neuron v0.1** JS mathematical kernel is preserved byte-for-byte (`src/ripple_core.cjs` SHA-256 `92cfa7aacb7ee09f4e2b9bf03956b8db1e477d879846cf1fdaf4e186c11d0f4a`). The original historical files are preserved in `source_v0_1/`.
- The independent Python port (`python/ripple_python.py`) was cross-compared against original JS across 1,500 changing-input steps.
- A **real CPU/wall-time/RSS instrumenter** (`python/instrument_kokoro.py`) records only process signals and explicitly reported daughterboard metrics.
- The **observed-data Ripple adapter** (`src/observed_adapter.cjs`) converts valid measured counters into normalized computational inputs and Ripple events. Missing module signals remain `unavailable`. It never pretends they were measured.
- A real PyTorch model forward-pass test (`python/torch_compatibility.py`) verifies token output and random-initialized model weight hashes are identical with and without instrumentation. It tests compatibility only, NOT trained language intelligence.
- Local regression tests and a portable GitHub Actions CI workflow; a runnable interactive Google Colab notebook is included under `cloud/`.
- Floot isolated cloud-VM numerical parity executed separately against the original historical three-window experiment.

## Quick start (Windows)

Extract this ZIP to its own folder, then double-click `START_WINDOWS.bat`. Requires Python 3 and Node.js 20+. No pip/npm install necessary for the core tests. It does not modify existing Kokoro folders.

## Quick start (Linux/Mac)

```sh
python -m unittest discover -s python/tests -v
npm test
python python/instrument_kokoro.py results/measured_runtime.jsonl
node src/observed_adapter.cjs results/measured_runtime.jsonl > results/my_report.json
```

The optional **real PyTorch compatibility test** (requires an already installed PyTorch; may have installation/network cost if absent):

```sh
python python/torch_compatibility.py
node src/observed_adapter.cjs results/torch_trace.jsonl > results/my_torch_report.json
```

### Hook it to an existing Python Kokoro

Use `python/integration_example.py` as a minimal **generator wrapper**. Replace only the demonstrator callback with the real *existing* Kokoro model instance's generation method. You are not asked to replace Kokoro's model or change any checkpoint. Additional daughterboard signal values must come from real outputs, not assumptions.

```python
from instrument_kokoro import TraceRecorder
from integration_example import wrap_generation

with TraceRecorder('results/kokoro_observed.jsonl') as trace:
    result = wrap_generation(kokoro.generate, user_prompt, trace)
```

This is illustrative: `kokoro.generate` is a placeholder name **until** the actual Foundry runtime entry point is inspected. Do not paste it into an unknown version of the Foundry expecting it to work without adaptation. A plain text response is never used to guess its number of model tokens.

## Data taxonomy

| Kind | Example | Proper interpretation |
|---|---|---|
| **Measured** | `time.perf_counter_ns`, `time.process_time_ns`, Linux RSS | Real host-process measurements from the executing program |
| **Component-reported** | Psyche frames, Heartspace arousal, Oneiric idle | Actual value only when supplied explicitly by that board, with runtime provenance |
| **Calculated** | CPU/core pressure, normalized queue depth, Ripple event count | Mathematical transform of provided observations |
| **Simulated** | Benchmark queue bursts, legacy RGB patterns | Synthetic task data executed in software |
| **Proposed** | Dynamic policy controlling Kokoro's reasoning/tool budget | Disabled until measured against a real Kokoro checkpoint and audited |

The `origin` field is a declaration by the logging program, not a signed attestation. Never present an untrusted externally supplied JSONL file as proof of genuine measurement.

## Files

- `docs/INTEGRATION_AND_RESOURCES.md` — architecture, cloud matrix and safety boundaries.
- `results/VERIFIED_REPORT.md` — reproducibility, CPU and PyTorch tests, remote VM cross-check.
- `results/measured_runtime.jsonl` — local actual CPU/clock/RSS trace from a synthetic arithmetic workload.
- `results/measured_report.json` — computed Ripple events on those observed runtime values.
- `results/torch_compatibility.json` — actual PyTorch inference timings and unchanged model weights.
- `cloud/Kokoro_Ripple_Free_Colab_Tests.ipynb` — self-contained interactive notebook; manually upload this ZIP.
- `.github/workflows/read_only_ci.yml` — test workflow (not published or executed on GitHub yet).
- `Simulation_Observer_v0_1.html` — previous synthetic-only offline UI; not a live Kokoro monitor.

## Ownership / publication

The generated code is provided as CC0-1.0 to facilitate open engineering, consistent with the user's original Ripple release direction. Actual third-party dependencies, model weights, private logs and other recovered source documents may have their **own** licenses. Never publish private Kokoro checkpoint/chat information by default.

## More finished functionality in v0.2

- `src/threaded_benchmark.cjs` performs real Node worker-thread compute with integrity-checked results and calculates actual elapsed runtime; it does not claim virtual Ripple clones are hardware threads.
- `src/scheduling_advisor.cjs` proposes a **non-executing** scheduling experiment from observed CPU/queue signals, and fails closed when data is missing or synthetic.
- **32 Node and 5 Python tests** passed in the final validation round; numerical parity is also confirmed on an isolated external VM.
- The executed five-run hardware-thread comparison is in `results/threading_repeats.json`. The report identifies and supersedes an earlier unfair first-pass benchmark.
