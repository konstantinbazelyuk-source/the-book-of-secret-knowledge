'use strict';
/** ACTUAL Node.js worker_threads benchmark, no Ripple-controlled scheduling yet.
 * Numeric tasks only. Measures genuine shared-host concurrency and correctness.
 * Memory/thread startup costs are intentionally included. */
const os=require('node:os');
const fs=require('node:fs');
const {Worker,isMainThread,parentPort}=require('node:worker_threads');
const {performance}=require('node:perf_hooks');
function compute(seed,steps){
  let total=0;
  for(let i=0;i<steps;i++)total=(total+((i*13+seed)%104729))%1000000007;
  return total;
}
if(!isMainThread){parentPort.on('message',job=>{parentPort.postMessage({id:job.id,result:compute(job.id+7,job.steps)})});}
else{
  async function runPool(jobs,n,referenceResults=null){
    // Baseline references computed OUTSIDE timed worker run, never recomputed by main thread.
    const expected=referenceResults??jobs.map(j=>compute(j.id+7,j.steps));
    const t0=performance.now(),startedCpu=process.cpuUsage();
    const workers=Array.from({length:n},()=>new Worker(__filename));
    const done=new Map();let next=0, completed=0;
    await new Promise((resolve,reject)=>{
      let closed=false;
      const fail=e=>{if(!closed){closed=true;reject(e)}};
      const send=w=>{const job=jobs[next++];if(job)w.postMessage(job)};
      for(const w of workers){
        w.on('error',fail);w.on('exit',code=>{if(code!==0&&!closed)fail(Error('Worker unexpected exit '+code))});
        w.on('message',msg=>{
          if(closed)return;
          if(msg.result!==expected[msg.id]){fail(Error('Arithmetic integrity mismatch'));return;}
          done.set(msg.id,performance.now()-t0);completed++;
          if(completed===jobs.length){closed=true;resolve();}else send(w);
        });send(w);
      }
    }).finally(()=>Promise.all(workers.map(w=>w.terminate())));
    const wall_ms=performance.now()-t0,cpu=process.cpuUsage(startedCpu);
    const latencies=[...done.values()].sort((a,b)=>a-b);
    return {workers:n,wall_ms,process_cpu_ms:(cpu.user+cpu.system)/1000,completed:done.size,
      p95_completion_from_batch_start_ms:latencies[Math.ceil(.95*latencies.length)-1]};
  }
  async function main(){
    const nTasks=Number(process.env.RIPPLE_TASKS||36),steps=Number(process.env.RIPPLE_STEPS||400000);
    if(!Number.isSafeInteger(nTasks)||nTasks<1||nTasks>1000||!Number.isSafeInteger(steps)||steps<1||steps>10000000)throw Error('invalid bounded benchmark work');
    const jobs=Array.from({length:nTasks},(_,id)=>({id,steps}));
    const t0=performance.now(),expected=jobs.map(j=>compute(j.id+7,j.steps));
    const serial_wall_ms=performance.now()-t0;
    const pools=[];
    for(const n of [1,2,4])pools.push(await runPool(jobs,n,expected));
    const payload={classification:'measured Node worker_threads arithmetic throughput on this machine; not trained Kokoro inference or Ripple neuron gain',
      run_time_utc:new Date().toISOString(),device:{node:process.version,available_parallelism:os.availableParallelism(),logical_cpus:os.cpus().length},
      jobs:nTasks,steps_per_job:steps,serial_wall_ms,parallel:pools,outputs_verified:expected.length===nTasks};
    fs.mkdirSync('results',{recursive:true});fs.writeFileSync('results/real_threading.json',JSON.stringify(payload,null,2));
    console.log(JSON.stringify(payload,null,2));
  }
  if(require.main===module)main().catch(e=>{console.error(e);process.exitCode=1});
  module.exports={compute,runPool};
}
