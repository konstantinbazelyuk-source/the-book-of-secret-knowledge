'use strict';
/** Strict READ-ONLY adapter. It does not import Kokoro source, alter model weights,
 * invent affect/salience values, send data to the network or invoke any tools. */
const fs=require('node:fs');
const {RippleNeuron}=require('./ripple_core.cjs');
const {summary,lag1,spectralPeak}=require('./fluctuations.cjs');
const VALID_ORIGINS=new Set(['observed-runtime','synthetic']);
const CHANNELS=['runtime_cpu','runtime_queue','psyche_candidates','network_conflict_fraction','heartspace_reported_arousal','oneiric_reported_idle'];
function scalar(v){if(!Number.isFinite(v)||v<0||v>1)throw Error('invalid normalized scalar');return [v/2,0,0];}
function finiteNonnegative(v){return typeof v==='number'&&Number.isFinite(v)&&v>=0;}
function optionalNumber(x,name){if(x===undefined)return null;if(!finiteNonnegative(x))throw Error(`${name} must be nonnegative finite`);return x;}
function normCount(n){return n/(n+2);}
function analyzeObservedRows(rows){
  if(!Array.isArray(rows)||rows.length<2)throw Error('at least 2 readings required');
  const firstOrigin=rows[0]?.origin;
  if(!VALID_ORIGINS.has(firstOrigin))throw Error('invalid trace origin');
  const state=Object.fromEntries(CHANNELS.map(k=>[k,{neuron:new RippleNeuron(),spikes:0,values:[],theta:[],rates:[],durations:[]}]));
  let last= null,peakRss=0,elapsed=0,cpuSeconds=0,observedIntervals=0;
  const reports=[];
  for(const [i,row] of rows.entries()){
    if(row===null||typeof row!=='object'||row.origin!==firstOrigin)throw Error('mixed or missing origins');
    if(!finiteNonnegative(row.timestamp_s)||!finiteNonnegative(row.process_cpu_s))throw Error('timestamp_s/process_cpu_s required');
    for(const name of ['queue_depth','frame_candidate_count','source_checked_total','source_conflict_total','heartspace_arousal','oneiric_idle_fraction','rss_bytes'])optionalNumber(row[name],name);
    if(row.heartspace_arousal!==undefined&&row.heartspace_arousal>1)throw Error('heartspace_arousal requires normalized component value');
    if(row.oneiric_idle_fraction!==undefined&&row.oneiric_idle_fraction>1)throw Error('oneiric_idle_fraction requires normalized component value');
    if(row.source_checked_total!==undefined&&row.source_conflict_total!==undefined&&row.source_conflict_total>row.source_checked_total)
      throw Error('source_conflict_total exceeds source_checked_total');
    if(row.rss_bytes!==undefined)peakRss=Math.max(peakRss,row.rss_bytes);
    if(last){
      const dt=row.timestamp_s-last.timestamp_s, dc=row.process_cpu_s-last.process_cpu_s;
      if(!(dt>0&&dt<=0.5)||dc<0)throw Error(`invalid monotonic sample interval at row ${i+1}`);
      const values={runtime_cpu:Math.min(1,dc/dt)};
      if(row.queue_depth!==undefined)values.runtime_queue=normCount(row.queue_depth);
      if(row.frame_candidate_count!==undefined)values.psyche_candidates=normCount(row.frame_candidate_count);
      if(row.source_checked_total!==undefined&&row.source_conflict_total!==undefined&&last.source_checked_total!==undefined&&last.source_conflict_total!==undefined){
        const ds=row.source_checked_total-last.source_checked_total,dx=row.source_conflict_total-last.source_conflict_total;
        if(ds<0||dx<0||dx>ds)throw Error('nonmonotonic source counters');
        if(ds>0)values.network_conflict_fraction=dx/ds;
      }
      if(row.heartspace_arousal!==undefined)values.heartspace_reported_arousal=row.heartspace_arousal;
      if(row.oneiric_idle_fraction!==undefined)values.oneiric_reported_idle=row.oneiric_idle_fraction;
      const fired={};
      for(const [role,v] of Object.entries(values)){
        const c=state[role];const s=c.neuron.step(scalar(v),dt);c.spikes+=s.count;c.values.push(v);c.theta.push(s.theta);c.rates.push(s.count/dt);c.durations.push(dt);fired[role]=s.count;
      }
      reports.push({timestamp_s:row.timestamp_s,observed_or_derived:values,ripple_events:fired});
      elapsed+=dt;cpuSeconds+=dc;observedIntervals++;
    }
    last=row;
  }
  const result={origin:firstOrigin,measurement_type:firstOrigin==='observed-runtime'?'instrumented runtime timestamps and CPU measurements':'synthetic timestamps and CPU counters',
    elapsed_wall_s:elapsed,elapsed_cpu_s:cpuSeconds,cpu_seconds_per_wall_second:cpuSeconds/elapsed,
    observed_intervals:observedIntervals,peak_reported_rss_bytes:peakRss||null,channels:{},latest:reports.at(-1)};
  for(const [role,c] of Object.entries(state)){
    const n=c.values.length;
    result.channels[role]= n? {samples:n,ripple_events:c.spikes,event_rate_per_observed_second:c.spikes/c.durations.reduce((a,b)=>a+b,0),
      input_min:Math.min(...c.values),input_max:Math.max(...c.values),input_mean:summary(c.values).mean,threshold_last:c.theta.at(-1),
      lag1_threshold:lag1(c.theta),
      spectral_peak:(c.durations.every(x=>Math.abs(x-c.durations[0])<0.00001)?spectralPeak(c.theta,c.durations[0]):null)} : {status:'unavailable',reason:'no explicit signal was supplied'};
  }
  return result;
}
function fromJSONL(filename){
  const lines=fs.readFileSync(filename,'utf8').split(/\r?\n/).filter(Boolean);
  return analyzeObservedRows(lines.map((l,i)=>{try{return JSON.parse(l)}catch(e){throw Error(`line ${i+1}: ${e.message}`)}}));
}
if(require.main===module){try{if(process.argv.length!==3)throw Error('Usage: node src/observed_adapter.cjs <instrumented.jsonl>');console.log(JSON.stringify(fromJSONL(process.argv[2]),null,2));}catch(err){console.error(err.message);process.exitCode=1}}
module.exports={analyzeObservedRows,fromJSONL,scalar,CHANNELS};
