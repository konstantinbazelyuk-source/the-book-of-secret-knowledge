'use strict';
/** ADVISORY only: never scales a real model or grants tools. Input may be an observational trace report. */
function advise(report){
 if(!report||report.origin!=='observed-runtime')return {status:'insufficient_trust',action:'no_action',reason:'Need trusted local observed-runtime trace'};
 const c=report.channels||{},cpu=c.runtime_cpu,q=c.runtime_queue;
 if(!cpu?.samples||!q?.samples||Math.min(cpu.samples,q.samples)<12)return {status:'insufficient_data',action:'no_action',reason:'12 valid CPU and queue intervals required'};
 if(cpu.input_mean>=.8&&q.input_mean>=.65)return {status:'observed_pressure',action:'benchmark_optimization_not_cloning',reason:'Queue pressure with high CPU use; cloning may worsen contention'};
 if(cpu.input_mean<.70&&q.input_mean>=.65)return {status:'potential_spare_cpu',action:'benchmark_one_extra_worker',reason:'Observed queue pressure and apparent single-core CPU headroom; a real worker benchmark is required'};
 if(q.input_mean<.35)return {status:'light_queue',action:'hold_workers',reason:'Low observed queue pressure'};
 return {status:'uncertain',action:'collect_more_data',reason:'No policy action without a repeatable measured improvement'};
}
if(require.main===module){const fs=require('node:fs');if(!process.argv[2])throw Error('Usage: node src/scheduling_advisor.cjs <report.json>');console.log(JSON.stringify(advise(JSON.parse(fs.readFileSync(process.argv[2],'utf8'))),null,2));}
module.exports={advise};
