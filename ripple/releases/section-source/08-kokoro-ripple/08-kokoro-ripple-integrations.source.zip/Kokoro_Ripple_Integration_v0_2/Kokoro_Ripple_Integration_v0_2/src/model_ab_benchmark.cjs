'use strict';
/** Microbenchmark of passive Ripple processing overhead, NOT model accuracy or AI gain.
 * Replay one identical pre-generated trace for both paths. Distinguish simulation from wall time. */
const fs=require('node:fs'),path=require('node:path');
const {analyzeObservedRows}=require('./observed_adapter.cjs');
const trace=process.argv[2];if(!trace){console.error('Usage: node src/model_ab_benchmark.cjs trace.jsonl');process.exit(2)}
const rows=fs.readFileSync(trace,'utf8').trim().split(/\r?\n/).map(x=>JSON.parse(x));
function measure(run,repetitions=16){const samples=[];for(let i=0;i<repetitions;i++){const s=process.hrtime.bigint();const result=run();const e=process.hrtime.bigint();samples.push(Number(e-s)/1e6);if(result===undefined)throw Error('invalid result')}samples.sort((a,b)=>a-b);return{median_ms:(samples[7]+samples[8])/2,p95_ms:samples[15],trials:repetitions};}
const baseline=measure(()=>rows.reduce((s,x)=>s+x.process_cpu_s,0));
const withRipple=measure(()=>analyzeObservedRows(rows));
console.log(JSON.stringify({classification:'measured Node.js wall-clock runtime overhead on current machine; NOT Kokoro inference speedup',samples:rows.length,baseline,with_ripple:withRipple,notes:'Non-equivalent work: baseline is minimal trace parsing; Ripple additionally computes neuron dynamics. Ratio is NOT an overall LLM slowdown estimate.'},null,2));
