let serial=-1,paused=false;
async function api(url,data){const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});const obj=await r.json();if(!r.ok)throw Error(obj.error||'Rejected');return obj}
async function control(obj){try{await api('/api/control',obj);document.querySelector('#response').textContent='Accepted';}catch(e){document.querySelector('#response').textContent=e.message}}
document.querySelector('#send').onclick=()=>control({text:document.querySelector('#command').value});
document.querySelector('#reset').onclick=()=>control({reset:true});
document.querySelectorAll('button[data-cmd]').forEach(el=>el.onclick=()=>control({text:el.dataset.cmd}));
document.querySelector('#pause').onclick=async()=>{await control({paused:!paused});paused=!paused;document.querySelector('#pause').textContent=paused?'Resume':'Pause'};
document.querySelector('#inspect').onclick=async()=>{try{document.querySelector('#codeout').textContent=JSON.stringify(await api('/api/code',{source:document.querySelector('#source').value,language:document.querySelector('#lang').value}),null,2)}catch(e){document.querySelector('#codeout').textContent=e.message}};
async function tick(){try{const r=await fetch('/api/state');if(!r.ok)throw Error('No state');const s=await r.json();document.querySelector('#status').textContent=JSON.stringify({time_s:s.robot.time_s,joints:s.robot.joints,targets:s.robot.target,render_ms:s.render_ms,paused:s.paused,error:s.last_error},null,2);if(s.serial!==serial){serial=s.serial;document.querySelector('#frame').src='/frame.png?i='+serial}}catch(e){document.querySelector('#status').textContent=e.message}}
setInterval(tick,400);tick();
