# Genome Robotics: mathematical architecture and source trace

## A. Actual data path

```
Literal task or numeric target
  -> Overseer validates schema and selects typed promoter
  -> Clone pool (independent worker instance, bounded by genotype capacity and overseer cap)
  -> Role-specific expressed numeric genes
  -> If motor: target + virtual plant observation -> original v0.1 Ripple LIF
  -> real event count -> event-weighted damping and instantaneous command cap
  -> hard safety cage (not genetically mutable)
  -> unchanged v0.7 VirtualJointPlant steps at dt=0.02 simulated s
  -> actual world skeletal joint angles -> VTK offscreen 3D skinning and PNG
  -> local HTTP viewer
```

The language role can only parse restricted joint instructions; code role parses Python AST or JSON *without executing* user input. These are deliberately narrow useful capabilities, not pretend language comprehension.

## B. Digital genes: actual code

Each genotype has 17 triplets of letters from `ACGT`, **51 bases total**. The first triplet is a *promoter*: base 1 selects the worker type (`A=signal`, `C=language`, `G=code`, `T=motor`); base 2 limits permitted clones (1–4); base 3 records a policy class. Each of the next 16 codons is interpreted as an integer from 0 to 63 and scaled into a specified finite interval. For example, `kp` lives in [3, 20]; if its codon decodes to `n`, then `kp=3+17*n/63`.

The genome encodes numeric *control policy parameters*, not Python source. There is no `eval`, dynamic importing, script generation, or unchecked memory write in mutation. Point mutation changes one alphabet symbol; each new genome keeps a parent hash, integer generation, role and immutable record. Its SHA-256 identifies content only.

This is **not** the standard biological genetic code for amino acids. Biological codons are researched separately in `data/human_reference.json` and documented via NCBI. The public reference sequence cannot be used to infer cognitive capacity.

## C. Original neuron and avatar mathematics

Original Ripple LIF (unchanged): `D = 2R + 1.2G - 1.4B` and `tau_v du/dt = -u + D` with reset, refractory period and rate-feedback adaptation. The new motor code preconditions normalized input channels with gene-specific gains, without changing original coefficients.

Virtual motor controller computes an error `e=r-y`, clipped target velocity `v_ref`, and gene-dependent `u = kp*e + kd*(v_ref-v)+kff*v_ref - d_event - d_boundary`, with amplitude, rate-of-change, joint-position, speed and acceleration bounds enforced separately. The Ripple gate is an *observable optional event brake*. Any demonstrated benefit must be compared with the identical controller running with `enable_ripple=False`.

The sampled joint plant was preserved from previous Kokoro Ripple Motor v0.7. Synthetic actuator dynamics, not real 3D anatomy or hardware motors, produce the observations. The resulting joint positions directly drive the v0.6 skinned model by VTK's 3D mesh transformation.

## D. Bounded evolution procedure

- Mutation: seeded pseudorandom point changes on digital codon string. Always a single-base change; promoter role is locked during adaptation for a particular task.
- Train objective: mean across three declared virtual actuator models of `(tracking RMSE + 0.0005 effort + 0.00004 command variation + 0.1 joint-limit hits)`.
- Validation: independent two-actuator development cases must be no worse than 1% of the prior champion and must have no joint-limit clipping. Promotion also requires training improvement.
- One reserved two-actuator holdout (per joint) is evaluated **only after all selections stop**. A further 50 newly seeded disturbance/inertia configurations per joint are evaluated after selection; no retuning from either test.
- The selection metric is an engineering heuristic, not a certified objective for general robotics or neural intelligence. A negative case remains negative.

## E. Robotics and safety architecture

The URDF defines a three-axis kinematic chain for `arm_R`, `forearm_R`, `head`, with bounds borrowed from the proven digital avatar. It intentionally has **no fabricated link inertias, masses or material coefficients**. The `ros_joint_trajectory.json` is a serialized trajectory contract containing joint order, positions, velocities and timestamps. No ROS 2 process is started. Physical robot use would require calibrated geometry, actuators, dynamics, emergency stops and a hardware safety review.

Operator binds to localhost; HTTP endpoints are `/`, `/ui.js`, `/api/state`, `/frame.png`, `/api/control`, `/api/code`. No external network fetch or trained model calls occur during runtime.

## F. Sourced and independently implemented methods

- Human Genome Project (NHGRI): https://www.genome.gov/human-genome-project
- Human reference assembly / variation overview (NHGRI): https://www.genome.gov/genetics-glossary/Human-Genome-Reference-Sequence
- Public reference genome resources (NCBI): https://www.ncbi.nlm.nih.gov/projects/genome/guide/human/
- Ensembl API reference interval used for the biological fixture: https://rest.ensembl.org/sequence/region/human/X:1000000..1000100:1?content-type=text/plain
- Biological genetic codes (NCBI): https://www.ncbi.nlm.nih.gov/datasets/docs/v2/data-processing/taxonomy-processing/genetic-codes/
- ROS 2 JointTrajectory message contract: https://docs.ros.org/en/ros2_packages/iron/api/trajectory_msgs/index.html
- ROS 2 control trajectory controller and tolerance behavior: https://control.ros.org/jazzy/doc/ros2_controllers/joint_trajectory_controller/doc/userdoc.html
- ROS 2 joint safety limits: https://control.ros.org/lyrical/doc/api/structjoint__limits_1_1JointLimits.html
- Original user's Ripple Genetic Weights Alpha v1.7 mathematics/negative-results documents: copies archived in `upstream`.

Biological science informs the *organization of adaptation* (genotype, expression, inheritance, mutation, selection). It does **not** mathematically justify mapping a public human DNA sequence directly into motor intelligence. No proprietary third-party program or weights were copied. All new integration algorithms are separately written, executable and tested.
