# Verification report — Ripple Genome Robotics Alpha v1.8

Generated October 15, 2026. The release is a **working digital robotics and parser subsystem**; not a newly trained general AI, real biological processor, or physically commissioned robotic controller.

## Evidence classes

- **Observed digital-source evidence:** A 101-base Ensembl GRCh38 human-reference interval was retrieved through the live public Ensembl REST endpoint. Local fixture exact bytes and SHA-256 are checked. Its ACGT alphabet is *not* assigned human cognitive meaning and is not fed to the avatar controller.
- **Measured computer behavior:** The Python and Node test suites ran; the VTK/EGL renderer produced PNG images and a GIF; the localhost server produced different PNG SHA-256 values after a safe user command. A connected Floot Linux cloud VM independently verified a base-4 genotype-decoding/mutation contract, **not** the full model.
- **Simulated numerical behavior:** Three virtual servo joints were controlled with gene-encoded gains and the preserved Ripple event monitor; outcomes in radians are deterministic calculations from virtual actuators, not physical sensor readings.
- **Unverified / unavailable:** trained Kokoro checkpoint, semantic comprehension equal to ChatGPT, physical robot, ROS middleware execution, Blender run, full cloud test/deployment, clinical genomics, conscious experience.

## Genome evaluation

The *original* user archive v1.7 passed 21 Python tests and 12 Node tests independently in a temporary extraction. v1.7a was not located. The previous Kokoro v0.7 original core and 3D baselines remain intact in a separate archived `upstream` copy.

New release: 45 Python tests passed. The live localhost test passed 10 HTTP checks: route serving, genuine PNG returned, pose command accepted, simulated motion changed, raster PNG changed, safe AST inspection, unsafe language rejected, unsafe numbers rejected, code not executed, and JavaScript assets served.

A selected genome was chosen independently per joint from **5 generations × 15 candidate point mutations = 75 evaluated candidates per joint**. The objective combined RMSE, command effort, command variation and hard-limit hits. Selection used three training plants and two development plants. Two additional plants were held out until selection ended. All dates and random seeds are recorded in `results/genetic_studies.json`.

### Reserved virtual plant results (radians RMS)

| Joint | Original genome | Selected genome | Reduction |
|---|---:|---:|---:|
| Right arm | 0.21321 | 0.19295 | 9.5% |
| Right forearm | 0.09155 | 0.08305 | 9.3% |
| Head | 0.01650 | 0.01035 | 37.3% |

### Separate 150-plant robustness sweep

| Joint | Improvement cases | No improvement cases | Normal-motion Ripple event ablation changed controller |
|---|---:|---:|---:|
| Right arm | 50/50 | 0 | 49/50 |
| Forearm | 47/50 | 3 | 19/50 |
| Head | 50/50 | 0 | 0/50 |

**The three forearm counterexamples are retained** in `results/robustness_150.csv`. Head motion improves through the evolved PD/feedforward parameters, not through Ripple spikes: there were no qualifying head spikes in the 50 robustness cases. Do not attribute all performance improvement to spiking or human-genomic DNA.

### Corrected failures during development

1. First trial: neuron events did not fire in standard motor testing because an inhibitory input was too large. Adjusted task-specific input conditioning without changing locked LIF coefficients; retested.
2. Second trial: a saturated motor command could prevent emitted spikes from affecting control. Added a bounded, temporary command cap plus event-responsive damping; retested with an explicit on/off control comparison.
3. Third trial: a high event gate made the spiking subsystem inactive during ordinary motions. Reinterpreted the genome gate as attenuation within a nonzero finite interval; ablation results above reflect the correction.
4. An external cloud mutation contract initially failed because the test accidentally rewrote a base with the same value. The test was corrected to enforce a real base change and passed, while the failed intermediate result was retained in the conversation.
5. The virtual motor sample rate initially ran at the raster refresh rate. It now executes multiple virtual integration steps per lower-rate VTK frame; this improves simulation time consistency but is not a hard-real-time guarantee.

### 3D model and interoperability

The original 20-joint 3D avatar model is preserved. The **new GLB** contains the preserved idle animation and `Genome_Ripple_Robotics_Validated_Simulation` generated from actual numerical virtual-servo paths for `arm_R`, `forearm_R`, and `head`. It was loaded by the `trimesh` parser; VTK/EGL rendered separate original/evolved poses (distinct pixel values) and a real 26-frame animated GIF. The URDF contains no fabricated mass or moment of inertia; the trajectory is a ROS 2-message-shaped JSON export, not a live ROS controller.

### Deployment boundary

`tools/live_lab.py` runs on localhost and intentionally has no remote access or physical hardware interfaces. `web/index.html` serves a visual control surface but does no unverified AI inference. WebGL2 and Blender are not required for the functioning VTK pathway. Never treat physical safety as established from numerical simulation.
