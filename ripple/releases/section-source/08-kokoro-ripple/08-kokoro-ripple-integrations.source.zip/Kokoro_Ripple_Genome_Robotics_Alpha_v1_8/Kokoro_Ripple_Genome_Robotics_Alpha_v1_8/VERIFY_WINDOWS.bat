@echo off
cd /d "%~dp0"
py -3 -m unittest discover -s tests -v
if errorlevel 1 exit /b 1
py -3 tools\test_live_lab.py
if errorlevel 1 exit /b 1
py -3 verify_release.py
if errorlevel 1 exit /b 1
pause
