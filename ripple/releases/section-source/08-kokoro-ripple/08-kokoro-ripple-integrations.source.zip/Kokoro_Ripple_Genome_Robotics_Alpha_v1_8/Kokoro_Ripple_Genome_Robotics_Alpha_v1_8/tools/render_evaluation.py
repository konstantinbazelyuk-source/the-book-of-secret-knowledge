"""Real offscreen 3D rasterization of original vs evolved motor behavior."""
import pathlib,sys,json,hashlib,time
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'upstream'))
from ripple_genome.genetics import DEFAULT_MOTOR,Genome
from ripple_genome.robotics import run_trajectory,CONTROL_JOINTS
from vtk_renderer import Renderer
from PIL import Image,ImageDraw
import matplotlib.pyplot as plt

studies=json.loads((ROOT/'results/genetic_studies.json').read_text())
selected={j:Genome.from_record(studies[j]['selected_genome']) for j in CONTROL_JOINTS}
paths={m:{j:run_trajectory(selected[j] if m=='selected' else DEFAULT_MOTOR,j) for j in CONTROL_JOINTS} for m in ('fixed','selected')}
renderer=Renderer(size=(320,425))
def render(mode,k):
 angles={j:paths[mode][j]['trace'][k]['actual'] for j in CONTROL_JOINTS}
 events=sum(paths[mode][j]['trace'][k]['spikes'] for j in CONTROL_JOINTS)
 t=k*.02
 im=renderer.frame(t,{'mode':'idle','joint_overrides':angles,
     'heart':min(.95,.59+.06*events),'scan':.12,'bloom':.30,'density':.22,'yaw':.48})
 return im
images=[];metrics=[];start=time.perf_counter()
for mode in ('fixed','selected'):
 for k in (45,80,115,150,185):
  t0=time.perf_counter();im=render(mode,k);runtime=(time.perf_counter()-t0)*1000
  fname=ROOT/'results'/f'render_{mode}_frame_{k}.png';im.save(fname)
  metrics.append({'mode':mode,'sample':k,'render_wall_ms':runtime,'bytes':fname.stat().st_size,'sha256':hashlib.sha256(fname.read_bytes()).hexdigest()})
  if k==115:images.append(im.copy())
canvas=Image.new('RGB',(640,455),'#111a24');canvas.paste(images[0],(0,30));canvas.paste(images[1],(320,30));d=ImageDraw.Draw(canvas);d.text((10,10),'ORIGINAL MOTOR GENOME',fill='white');d.text((330,10),'EVOLVED MOTOR GENOME',fill='white')
canvas.save(ROOT/'results/robotics_comparison.png')
frames=[]
for k in range(0,260,10):
 im=render('selected',k).convert('RGB')
 frames.append(im)
frames[0].save(ROOT/'results/selected_motor_3d.gif',save_all=True,append_images=frames[1:],duration=125,loop=0,optimize=True)
(ROOT/'results/render_metrics.json').write_text(json.dumps({'frames':metrics,'additional_gif_frames':len(frames),'elapsed_sec':time.perf_counter()-start,
 'classification':'actual VTK/EGL renders of numerically simulated actuators'},indent=2))
fig,axs=plt.subplots(3,1,figsize=(11,8),sharex=True)
for ax,j in zip(axs,CONTROL_JOINTS):
 orig=paths['fixed'][j]['trace'];new=paths['selected'][j]['trace'];t=[x['t'] for x in orig]
 ax.plot(t,[x['target'] for x in orig],label='target',linewidth=1.4)
 ax.plot(t,[x['actual'] for x in orig],label='original controller',linestyle='--')
 ax.plot(t,[x['actual'] for x in new],label='evolved genome',linestyle=':')
 ax.set_ylabel(j+' (rad)');ax.grid(alpha=.2);ax.legend(loc='best')
axs[-1].set_xlabel('Virtual seconds');fig.suptitle('Kokoro 3D digital twin: numerical trajectories (simulated)')
fig.tight_layout();fig.savefig(ROOT/'results/tracking.png',dpi=140)
print(json.dumps({'real_vtk_frames':len(metrics)+len(frames),'comparison_bytes':(ROOT/'results/robotics_comparison.png').stat().st_size,'gif_bytes':(ROOT/'results/selected_motor_3d.gif').stat().st_size,'runtime_s':round(time.perf_counter()-start,2)}))
