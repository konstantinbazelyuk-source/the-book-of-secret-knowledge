"""Local operator with ACTUAL VTK/EGL skeletal 3D rendering and programming probes.

The image is rendered from actual 3D vertices using v0.7 skinning code.
The robot is a virtual actuator. No machine, robot or account access.
"""
from __future__ import annotations
import argparse, io,json,pathlib,threading,sys,time,hashlib,math
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'upstream'))
from ripple_genome import Genome,Overseer
from ripple_genome.robotics import JOINT_LIMITS
from vtk_renderer import Renderer
HTML=(ROOT/'web/index.html').read_text() if (ROOT/'web/index.html').exists() else ''
UI=(ROOT/'web/ui.js').read_text() if (ROOT/'web/ui.js').exists() else ''

class Lab:
 def __init__(self,size=(310,410),fps=6):
  if not (1<=fps<=15):raise ValueError('FPS must be bounded to 1–15')
  p=ROOT/'results/selected_genomes.json'
  self.overseer=Overseer(max_workers=6)
  if p.exists():
   selected={k:Genome.from_record(v) for k,v in json.loads(p.read_text()).items()}
   self.overseer.robot=self.overseer.robot.__class__(selected)
  self.fps=fps;self.size=size;self.lock=threading.RLock();self.started=False
  self.running=True;self.paused=False;self.latest=b'';self.sha='';self.serial=0
  self.frames=0;self.render_ms=0.;self.last_error=None
 def control(self,body):
  if not isinstance(body,dict) or set(body)-{'text','targets','paused','reset'} or len(body)!=1:raise ValueError('one allowed control per request')
  with self.lock:
   if 'text' in body:
    targets=self.overseer.dispatch({'kind':'language','text':body['text']})['joint_targets']
    self.overseer.robot.set_targets(targets)
   elif 'targets' in body:self.overseer.robot.set_targets(body['targets'])
   elif 'paused' in body:
    if type(body['paused']) is not bool:raise ValueError('pause requires bool')
    self.paused=body['paused']
   elif 'reset' in body:
    if body['reset'] is not True:raise ValueError('reset requires true')
    self.overseer.robot.set_targets({j:0.0 for j in JOINT_LIMITS})
   return self.snapshot()
 def code(self,body):
  if not isinstance(body,dict) or set(body)-{'source','language'} or 'source' not in body:raise ValueError('invalid code request')
  return self.overseer.dispatch({'kind':'code',**body})
 def snapshot(self):
  return {'operator':'Kokoro Ripple Digital Robotics Alpha v1.8',
          'paused':self.paused,'frames':self.frames,'serial':self.serial,'sha256':self.sha,
          'render_ms':self.render_ms,'last_error':self.last_error,
          'robot':self.overseer.robot.status(),
          'simulated':True,'physical_robot_connected':False,'trained_AI_connected':False}
 def tick(self,renderer):
  with self.lock:
   if not self.paused:
    # Integrate the 50-Hz virtual servo independently of the lower frame raster rate.
    for _ in range(max(1,round(50/self.fps))):self.overseer.robot.step()
   joints={j:p.x for j,p in self.overseer.robot.plants.items()}
   # Numerical brain feedback controls visible light (never claims measured photons).
   events=sum(c.event_total for c in self.overseer.robot.controllers.values())
  img=renderer.frame(self.frames/self.fps,{'mode':'idle','joint_overrides':joints,'heart':min(.95,.53+.025*(events%7)),
              'density':.24,'scan':.12,'bloom':.36,'yaw':.42})
  out=io.BytesIO();img.save(out,format='PNG');blob=out.getvalue()
  with self.lock:
   self.frames+=1;self.latest=blob;self.sha=hashlib.sha256(blob).hexdigest();self.serial+=1
   self.render_ms=renderer.last_stats['render_ms'];self.started=True
 def run(self):
  try:
   r=Renderer(size=self.size)
   while self.running:
    t=time.perf_counter()
    try:self.tick(r)
    except Exception as ex:
     with self.lock:self.last_error=type(ex).__name__+': '+str(ex)
     break
    time.sleep(max(0,1/self.fps-(time.perf_counter()-t)))
  except Exception as ex:
   with self.lock:self.last_error=type(ex).__name__+': '+str(ex)

class Handler(BaseHTTPRequestHandler):
 def send(self,payload,kind='application/json',status=200):
  b=payload if isinstance(payload,bytes) else json.dumps(payload,allow_nan=False).encode()
  self.send_response(status);self.send_header('Content-Length',str(len(b)))
  self.send_header('Content-Type',kind);self.send_header('Cache-Control','no-store')
  self.send_header('X-Content-Type-Options','nosniff');self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'")
  self.end_headers();self.wfile.write(b)
 def do_GET(self):
  path=self.path.split('?')[0]
  a=self.server.lab
  if path=='/':return self.send(HTML.encode(),'text/html; charset=utf-8')
  if path=='/ui.js':return self.send(UI.encode(),'application/javascript; charset=utf-8')
  if path=='/api/state':
   with a.lock:return self.send(a.snapshot())
  if path=='/frame.png':
   with a.lock:
    if not a.latest:return self.send({'error':'renderer warming up'},status=503)
    return self.send(a.latest,'image/png')
  return self.send({'error':'not found'},status=404)
 def do_POST(self):
  if self.path not in ('/api/control','/api/code'):return self.send({'error':'not found'},status=404)
  try:
   length=int(self.headers.get('Content-Length','0'))
   if length<1 or length>49152:raise ValueError('payload too large or empty')
   body=json.loads(self.rfile.read(length))
   if self.path=='/api/control':reply=self.server.lab.control(body)
   else:reply=self.server.lab.code(body)
   return self.send(reply)
  except (ValueError,TypeError,KeyError,json.JSONDecodeError) as e:
   return self.send({'error':str(e)},status=422)
  except Exception as e:
   return self.send({'error':type(e).__name__,'detail':'operation unavailable'},status=500)
 def log_message(self,*args):pass

def serve(port=8772,fps=6):
 app=Lab(fps=fps);thread=threading.Thread(target=app.run,daemon=True);thread.start()
 server=ThreadingHTTPServer(('127.0.0.1',port),Handler);server.lab=app
 print(f'Kokoro Genome Robotics live operator: http://127.0.0.1:{server.server_port}',flush=True)
 try:server.serve_forever()
 finally:app.running=False;server.server_close();thread.join(timeout=5)

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--port',type=int,default=8772);parser.add_argument('--fps',type=int,default=6)
 args=parser.parse_args();serve(args.port,args.fps)
