"""Predefined seed sweep, evaluated after candidate selection; no selection by these cases."""
from __future__ import annotations
import sys,pathlib,json,random,statistics,math,csv
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from ripple_genome.genetics import Genome,DEFAULT_MOTOR
from ripple_genome.robotics import run_trajectory,CONTROL_JOINTS
selected={j:Genome.from_record(x) for j,x in json.loads((ROOT/'results/selected_genomes.json').read_text()).items()}
records=[]
for joint_i,j in enumerate(CONTROL_JOINTS):
 for seed in range(50):
  rng=random.Random(10000+joint_i*500+seed)
  plant={'gain':rng.uniform(.58,1.45),'damping':rng.uniform(1.8,3.2),
         'inertia':rng.uniform(.8,1.25),'disturbance':rng.uniform(-.16,.16)}
  orig=run_trajectory(DEFAULT_MOTOR,j,plant)
  evolved=run_trajectory(selected[j],j,plant)
  disabled=run_trajectory(selected[j],j,plant,enable_ripple=False)
  records.append({'joint':j,'case':seed,**plant,'original_rmse':orig['rmse'],
                  'selected_rmse':evolved['rmse'],'selected_events':evolved['events'],
                  'original_fitness':orig['fitness'],'selected_fitness':evolved['fitness'],
                  'selected_no_spike_fitness':disabled['fitness'],
                  'improved':evolved['fitness']<orig['fitness'],
                  'ripple_changes_behavior':abs(evolved['fitness']-disabled['fitness'])>1e-10})
fields=list(records[0]);out=ROOT/'results'
with (out/'robustness_150.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(records)
summary={}
for j in CONTROL_JOINTS:
 r=[x for x in records if x['joint']==j]
 summary[j]={'cases':len(r),'improved':sum(x['improved'] for x in r),
             'events':sum(x['selected_events'] for x in r),
             'ripple_control_effect_cases':sum(x['ripple_changes_behavior'] for x in r),
             'median_fixed_rmse':statistics.median(x['original_rmse'] for x in r),
             'median_selected_rmse':statistics.median(x['selected_rmse'] for x in r),
             'median_fitness_ratio':statistics.median(x['selected_fitness']/x['original_fitness'] for x in r)}
(out/'robustness_summary.json').write_text(json.dumps({'conditions':'150 newly seeded virtual actuator models; NOT biological, not physical',
  'holdout_note':'50-case per joint robustness sweep evaluated once after genotype selection. No retuning.',
  'summary':summary},indent=2))
print(json.dumps(summary,indent=2))
