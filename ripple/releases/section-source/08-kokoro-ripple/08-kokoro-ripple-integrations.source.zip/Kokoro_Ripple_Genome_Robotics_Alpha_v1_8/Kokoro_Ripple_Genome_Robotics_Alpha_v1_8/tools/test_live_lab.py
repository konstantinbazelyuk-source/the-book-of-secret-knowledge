import sys,pathlib,subprocess,time,urllib.request,urllib.error,json,hashlib,socket,os
ROOT=pathlib.Path(__file__).resolve().parents[1]
sock=socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1];sock.close()
process=subprocess.Popen([sys.executable,'-u',str(ROOT/'tools/live_lab.py'),'--port',str(port),'--fps','6'],cwd=str(ROOT),stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
url=f'http://127.0.0.1:{port}'
def req(path,data=None):
 h={'Content-Type':'application/json'}
 request=urllib.request.Request(url+path,data=json.dumps(data).encode() if data is not None else None,headers=h)
 try:
  with urllib.request.urlopen(request,timeout=6) as r:return r.status,r.read(),r.headers.get('Content-Type')
 except urllib.error.HTTPError as e:return e.code,e.read(),e.headers.get('Content-Type')
try:
 ready=False
 for i in range(100):
  if process.poll() is not None:raise RuntimeError('server terminated early')
  try:
   status,raw,_=req('/api/state');data=json.loads(raw)
   if status==200 and data['serial']>=2:ready=True;break
  except Exception:pass
  time.sleep(.15)
 if not ready:raise RuntimeError('renderer did not start in timeout')
 checks={}
 checks['live_frame_png']=req('/frame.png')[1].startswith(b'\x89PNG\r\n\x1a\n')
 status,b,_=req('/api/state');before=json.loads(b)
 status,b,_=req('/api/control',{'text':'raise right arm 30 degrees'})
 checks['natural_language_command_accepted']=status==200
 time.sleep(.8)
 status,b,_=req('/api/state');after=json.loads(b)
 checks['real_simulated_joint_movement']=after['robot']['joints']['arm_R']['position']>before['robot']['joints']['arm_R']['position']
 checks['real_rendered_png_changed']=req('/frame.png')[1]!=b'' and after['sha256']!=before['sha256']
 code,body,_=req('/api/code',{'source':'def f(x): return x*2','language':'python'})
 checks['static_python_ast']=code==200 and json.loads(body)['summary']['functions']==1
 code,body,_=req('/api/control',{'text':'raise right arm 300 degrees'})
 checks['unsafe_pose_rejected']=code==422
 code,body,_=req('/api/control',{'targets':{'forearm_R':5.}})
 checks['numeric_unsafe_pose_rejected']=code==422
 code,body,_=req('/api/code',{'source':'import os\nos.system("echo failed")','language':'python'})
 checks['untrusted_code_never_executed']=code==200 and not json.loads(body)['executed']
 checks['web_ui_served']=b'Ripple Genome Robotics Lab' in req('/')[1]
 checks['javascript_ui_served']=b'async function api' in req('/ui.js')[1]
 report={'suite':'live loopback HTTP + actual PNG VTK render','checks':checks,'passed':all(checks.values()),'start_sha256':before['sha256'],'end_sha256':after['sha256'],
         'start_joint':before['robot']['joints']['arm_R']['position'],'end_joint':after['robot']['joints']['arm_R']['position'],
         'physical_robot_connected':False,'trained_AI_connected':False}
 (ROOT/'results/live_lab_integration.json').write_text(json.dumps(report,indent=2))
 print(json.dumps(report,indent=2))
 if not report['passed']:raise RuntimeError('HTTP check failure')
finally:
 process.terminate()
 try:process.wait(timeout=5)
 except subprocess.TimeoutExpired:process.kill();process.wait()
