"""Single-command reproducible joint evolution, holdout test, robotics export."""
import sys,pathlib,json,hashlib
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from ripple_genome.evolution import evolve
from ripple_genome.genetics import Genome
from ripple_genome.robotics import CONTROL_JOINTS
from ripple_genome.export import generate_paths,trajectory_message,export_animation,urdf_string,parse_glb_bytes
from ripple_genome.research import inspect_reference
from xml.etree import ElementTree

def run(generations=5,children=15,seed=19):
 out=ROOT/'results';out.mkdir(exist_ok=True)
 studies={j:evolve(j,generations=generations,children=children,seed=seed+i*37) for i,j in enumerate(CONTROL_JOINTS)}
 selected={j:Genome.from_record(studies[j]['selected_genome']) for j in studies}
 paths=generate_paths(selected)
 glb=export_animation(paths,ROOT/'assets/Kokoro_Genome_Robotics_Alpha_v1_8.glb')
 msg=trajectory_message(paths)
 (out/'ros_joint_trajectory.json').write_text(json.dumps(msg,indent=2))
 urdf=urdf_string();ElementTree.fromstring(urdf)
 (out/'kokoro_digital_twin.urdf').write_text('<?xml version="1.0"?>\n'+urdf)
 (out/'genetic_studies.json').write_text(json.dumps(studies,indent=2))
 (out/'selected_genomes.json').write_text(json.dumps({j:g.record() for j,g in selected.items()},indent=2))
 (out/'selected_motion.json').write_text(json.dumps({j:{k:v for k,v in result.items() if k!='trace'} for j,result in paths.items()},indent=2))
 info={'schema':'ripple-genetic-robotics-results/1','genomes':{j:g.marker for j,g in selected.items()},
       'selected_improvement':{j:studies[j]['holdout_improved'] for j in studies},
       'holdout_rmse':{j:{'baseline':studies[j]['holdout_original']['rmse'],
                          'selected':studies[j]['holdout_selected']['rmse']} for j in studies},
       'observed_reference':inspect_reference(),'new_glb':glb,
       'simulation_budget':{'candidate_mutations_per_joint':generations*children,
                            'train_plant_cases':3,'development_plant_cases':2,'reserved_plant_cases':2},
       'ROS_export':'serialization only; no ROS executor or physical robot tested'}
 (out/'summary.json').write_text(json.dumps(info,indent=2));print(json.dumps(info,indent=2));return info
if __name__=='__main__':run()
