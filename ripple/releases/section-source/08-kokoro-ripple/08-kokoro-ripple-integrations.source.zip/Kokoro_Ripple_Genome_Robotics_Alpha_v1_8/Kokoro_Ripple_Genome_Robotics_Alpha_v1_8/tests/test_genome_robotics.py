import unittest,random,json,math,pathlib,hashlib,struct,ast,sys,xml.etree.ElementTree as ET,tempfile
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from ripple_genome.genetics import *
from ripple_genome.robotics import *
from ripple_genome.grammar import *
from ripple_genome.colony import *
from ripple_genome.evolution import *
from ripple_genome.export import *
from ripple_genome.research import *

class GeneticIntegrity(unittest.TestCase):
 def test_reference(self):self.assertEqual(inspect_reference()['length'],101)
 def test_sha(self):self.assertEqual(len(DEFAULT_MOTOR.marker),64)
 def test_all_base4(self):
  for i in range(64):self.assertEqual(triplet_int(int_triplet(i)),i)
 def test_roles(self):
  for x in [DEFAULT_MOTOR,DEFAULT_CODE,DEFAULT_SIGNAL,DEFAULT_LANGUAGE]:self.assertIn(x.role,ROLE.values())
 def test_record_roundtrip(self):
  x=DEFAULT_MOTOR;self.assertEqual(Genome.from_record(json.loads(json.dumps(x.record()))),x)
 def test_corrupt_sha(self):
  x=DEFAULT_MOTOR.record();x['sha256']='a'*64
  with self.assertRaises(ValueError):Genome.from_record(x)
 def test_invalid_dna(self):
  for x in ['', 'X'*GENOME_LENGTH,'ATG','A'*54]:
   with self.assertRaises(ValueError):Genome(x)
 def test_point_mutation(self):
  m=DEFAULT_MOTOR.mutate(random.Random(99));self.assertEqual(sum(a!=b for a,b in zip(m.dna,DEFAULT_MOTOR.dna)),1)
  self.assertEqual(m.parent,DEFAULT_MOTOR.marker);self.assertEqual(m.generation,1)
 def test_safe_role_lock(self):
  for seed in range(100):self.assertEqual(DEFAULT_MOTOR.mutate(random.Random(seed)).role,'motor')
 def test_bounds(self):
  for x in [DEFAULT_MOTOR,DEFAULT_CODE,DEFAULT_SIGNAL,DEFAULT_LANGUAGE]:
   for k,(lo,hi) in LOCI.items():self.assertTrue(lo<=x.express()[k]<=hi)
 def test_gene_codon_expression(self):
  g=DEFAULT_MOTOR;mutants={g.mutate(random.Random(s)).marker for s in range(50)}
  self.assertGreater(len(mutants),8)
 def test_reject_invalid_gene(self):
  with self.assertRaises(ValueError):encode(kp=100)
  with self.assertRaises(ValueError):encode(nonsense=.3)
 def test_clone_identity(self):
  m=Overseer().allocate('code',3);self.assertEqual(len(m),2)
  self.assertEqual(m[0].genome.marker,m[1].genome.marker)
  self.assertIsNot(m[0],m[1])

class FunctionalRobotics(unittest.TestCase):
 def test_joint_names(self):self.assertEqual(len(CONTROL_JOINTS),3)
 def test_trajectory_finite(self):
  for joint in CONTROL_JOINTS:
   v=run_trajectory(DEFAULT_MOTOR,joint)
   self.assertTrue(math.isfinite(v['rmse']));self.assertEqual(len(v['trace']),260)
 def test_real_spikes(self):
  t=run_trajectory(DEFAULT_MOTOR,'arm_R');self.assertGreater(t['events'],0)
 def test_spike_motor_connection(self):
  # Demonstrates the new actual event-damping control path exists and changes a command when conditions match.
  g=encode('motor',pulse_damp=3.,gate=.25,kp=12.,kd=3.)
  on=GeneMotor(g,'arm_R',True);off=GeneMotor(g,'arm_R',False)
  diff=[]
  for k in range(50):
   t=k*.02
   a=on.step(t,.13,.6,1.12).command
   b=off.step(t,.13,.6,1.12).command
   diff.append(abs(a-b))
  self.assertGreater(max(diff),0.01)
 def test_virtual_limits(self):
  robot=VirtualRobot()
  for v in [-5,6,float('inf'),float('nan')]:
   with self.assertRaises(ValueError):robot.set_targets({'arm_R':v})
 def test_atomic_rejection(self):
  r=VirtualRobot()
  with self.assertRaises(ValueError):r.set_targets({'arm_R':.8,'head':100.})
  self.assertEqual(r.goal['arm_R'],0.)
 def test_robot_moves(self):
  r=VirtualRobot();r.set_targets({'arm_R':.65})
  for _ in range(70):r.step()
  self.assertGreater(r.status()['joints']['arm_R']['position'],.3)
 def test_trajectory_range(self):
  paths=generate_paths({j:DEFAULT_MOTOR for j in CONTROL_JOINTS})
  msg=trajectory_message(paths)
  self.assertEqual(msg['joint_names'],list(CONTROL_JOINTS))
  self.assertTrue(all(len(pt['positions'])==3 for pt in msg['points']))
 def test_urdf(self):
  doc=ET.fromstring(urdf_string());self.assertEqual(len(doc.findall('joint')),3)
 def test_glb_structure(self):
  data=(ROOT/'assets/Kokoro_Genome_Robotics_Alpha_v1_8.glb').read_bytes();g,b=parse_glb_bytes(data)
  self.assertIn('Genome_Ripple_Robotics_Validated_Simulation',[x['name'] for x in g['animations']])
  self.assertEqual(len(g['skins'][0]['joints']),20)
 def test_glb_source_not_mutated(self):
  data=(ROOT/'assets/Kokoro_Lumina_Alpha_v0_6.glb').read_bytes()
  self.assertEqual(data[:4],b'glTF')
 def test_evolution_selects_nonnegative(self):
  s=evolve(joint='arm_R',seed=8,generations=2,children=5)
  self.assertLessEqual(s['train_selected']['fitness'],s['train_before']['fitness'])
  self.assertEqual(s['candidates_evaluated'],10)
 def test_promote_approval(self):
  x=Overseer()
  with self.assertRaises(PermissionError):x.promote('motor',DEFAULT_MOTOR)
  x.promote('motor',DEFAULT_MOTOR,approved=True)
 def test_cannot_swap_active_motor(self):
  x=Overseer();x.robot.step()
  with self.assertRaises(RuntimeError):x.promote('motor',DEFAULT_MOTOR,approved=True)

class LanguageAndCode(unittest.TestCase):
 def test_python_ast(self):
  x=analyze_code('import math\ndef answer(x):\n return math.sqrt(x)')
  self.assertEqual(x['summary']['functions'],1);self.assertFalse(x['executed'])
 def test_invalid_python(self):self.assertEqual(analyze_code('def x(:')['syntax'],'invalid')
 def test_python_nonexecution(self):
  p=ROOT/'results/should_never_be_written.txt'
  source="open('"+str(p)+"','w').write('NEVER')"
  self.assertEqual(analyze_code(source)['syntax'],'valid');self.assertFalse(p.exists())
 def test_json(self):self.assertEqual(analyze_code('{"a":2}','json')['syntax'],'valid')
 def test_bad_json(self):self.assertEqual(analyze_code('{' ,'json')['syntax'],'invalid')
 def test_unsupported(self):self.assertEqual(analyze_code('print(1)','rust')['syntax'],'unsupported')
 def test_language_arm(self):self.assertAlmostEqual(parse_command('raise right arm 30 degrees',DEFAULT_LANGUAGE)['arm_R'],math.pi/6)
 def test_language_head(self):self.assertGreater(parse_command('turn head left 10 degrees',DEFAULT_LANGUAGE)['head'],0)
 def test_language_reset(self):self.assertEqual(len(parse_command('reset pose',DEFAULT_LANGUAGE)),3)
 def test_no_unsafe_text(self):
  for x in ['run shell command','delete this source','raise right arm 999 degrees','tell me the answer']:
   with self.assertRaises(ValueError):parse_command(x,DEFAULT_LANGUAGE)
 def test_wrong_role(self):
  with self.assertRaises(ValueError):parse_command('reset pose',DEFAULT_MOTOR)
 def test_oversize(self):
  with self.assertRaises(ValueError):analyze_code('x'*60000)
 def test_code_specialist(self):
  x=Overseer().dispatch({'kind':'code','source':'def f(): return 1'})
  self.assertEqual(x['summary']['functions'],1)
 def test_language_specialist(self):
  x=Overseer().dispatch({'kind':'language','text':'lower right forearm 20 degrees'})
  self.assertLess(x['joint_targets']['forearm_R'],0)
 def test_signal_specialist(self):
  x=Overseer().dispatch({'kind':'signal','rgb':[[.6,.2,.1]]*60})
  self.assertGreater(x['observed_samples'],0);self.assertLessEqual(x['observed_samples'],60)
 def test_batch_40(self):
  x=Overseer(max_workers=6).batch([{'kind':'code','source':f'a={i}'} for i in range(40)])
  self.assertEqual(len(x),40);self.assertTrue(all(v['syntax']=='valid' for v in x))
 def test_bad_batch(self):
  with self.assertRaises(ValueError):Overseer().batch([{'kind':'motor'}])
  with self.assertRaises(ValueError):Overseer().batch([None])
 def test_no_trained_ai(self):self.assertIn('not generative language models',Overseer().inventory()['classification'])

if __name__=='__main__':unittest.main()
