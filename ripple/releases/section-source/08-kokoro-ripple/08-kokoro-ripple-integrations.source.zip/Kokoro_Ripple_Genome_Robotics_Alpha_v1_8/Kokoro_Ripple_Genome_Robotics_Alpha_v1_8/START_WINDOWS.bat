@echo off
cd /d "%~dp0"
py -3 -m pip install -r requirements.txt
if errorlevel 1 (
 echo Unable to install local rendering dependencies. No external service is started.
 pause
 exit /b 1
)
py -3 tools\live_lab.py --port 8772 --fps 6
pause
