"""SHA-256 integrity of upstream releases and immutable pack contents."""
import pathlib,hashlib,sys,json
ROOT=pathlib.Path(__file__).resolve().parent

def main():
 m=json.loads((ROOT/'INTEGRITY_MANIFEST.json').read_text())
 failed=[]
 for rel,expected in m['files'].items():
  p=ROOT/rel
  actual=hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else 'MISSING'
  if actual!=expected:failed.append({'path':rel,'expected':expected,'actual':actual})
 for original,rel in m['original_archives'].items():
  if rel not in m['files']:failed.append({'missing_archive':rel})
 report={'checked':len(m['files']),'failed':failed,'passed':not failed,
         'source':'package contents and source archives; SHA-256 not proof of authorship'}
 print(json.dumps(report,indent=2))
 return 0 if not failed else 1
if __name__=='__main__':sys.exit(main())
