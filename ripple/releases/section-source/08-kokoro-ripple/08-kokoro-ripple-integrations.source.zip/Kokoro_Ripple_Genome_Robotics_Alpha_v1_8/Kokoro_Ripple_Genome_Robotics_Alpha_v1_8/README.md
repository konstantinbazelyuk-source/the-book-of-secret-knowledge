# Kokoro · Ripple Genetic Robotics Alpha v1.8

**An executable, bounded genetic controller laboratory and live 3D digital-robotics operator.** This is an extension of Kokoro Lumina 3D v0.6 and Ripple Motor v0.7, using the verified Ripple Genetic Weights v1.7 as a frozen research baseline. The user-requested **v1.7a** source was not found; it is not mislabeled or overwritten.

## What runs

- **Typed digital genotype → phenotype:** 51 symbols using `A/C/G/T` to encode one promoter and 16 parameter loci, constrained 6-bit triplet codons. `motor`, `signal`, `language`, `code` phenotypes are real executable roles; cloning copies genotype but allocates independent worker state.
- **Bounded mutation, selection, lineage:** point mutations create new immutable genomes with an inherited parent SHA-256. Candidate motor genomes are ranked on training virtual servo plants and promoted only after independent development acceptance, before any reserved holdout is examined. Mutation never changes hard safety limits or program code.
- **Ripple v0.1 numerical neuron:** imported unchanged from Kokoro v0.7 as a monitoring and control channel. Its software spikes can modulate motor-command damping and the event-time command cap. Does not assert biological firing or consciousness.
- **Live digital robotics:** a three-joint controller advances simulated servo state at ~50 numerical steps per virtual second; renderer updates at a separately configured FPS and uses the real skinned VTK/EGL 3D model. Bounds on joint position, speed, acceleration, command amplitude, command slew, and payload size are enforced.
- **Structured programming/language sensing:** Python AST and JSON structure parsing is real and non-executing. A small literal language grammar maps safe phrases into joint positions. Arbitrary programming-language understanding or natural-language comprehension is not claimed.
- **ROS 2 integration artifact:** a joint trajectory JSON and purely kinematic URDF are produced. Neither is connected to ROS middleware or a physical robot.
- **Avatar export:** creates a *new GLB file* with the original idle clip plus a generated, skinning-compatible `Genome_Ripple_Robotics_Validated_Simulation` clip. No original `.glb`, checkpoints, legacy archives or source files are modified.

## Start the live 3D laboratory (Windows, macOS, Linux)

Requirements: Python 3.10+; Python packages `numpy`, `Pillow`, `vtk`, `matplotlib`, and optionally `trimesh` for independent GLB checks. VTK rendering requires working OpenGL/EGL support. No account or paid API required.

```bash
python -m pip install -r requirements.txt
python tools/build_and_evaluate.py
python tools/live_lab.py --port 8772 --fps 6
```

Open **http://127.0.0.1:8772** in the same computer's browser. The server listens only on `127.0.0.1`, never on the public network. It exposes an actual PNG-rendered avatar, real numerical telemetry, supported pose commands, and a non-executing code-structure inspector.

**Windows:** use `START_WINDOWS.bat`. Do not run a legacy `.bat` from inside a ZIP; extract the archive first.

## Verification

```bash
python -m unittest discover -s tests -v
python tools/robustness.py
python tools/test_live_lab.py
python tools/render_evaluation.py
python verify_release.py
```

Regression baseline tested separately from the frozen v1.7 archive: 21 original Python tests and 12 original Node tests passed. This release has 45 Python tests and 10 live HTTP integration checks, plus 150 newly seeded simulated actuator cases. A separate cloud VM reproduced the 51-base codon-decoding contract, not the entire full system. See `docs/VERIFICATION.md` for exact negative findings and boundaries.

## Source provenance

- `upstream/` contains SHA-256-locked copies of archived personal Ripple releases and the untouched v0.7 motor source files. Older releases retain their individual copyright/license conditions; packaging does not relicense them.
- `data/human_reference.json` holds a verified **101-base public Ensembl human-reference sequence** for testing real nucleotide parsing and data provenance. Those biological bases **are never decoded into Kokoro weights**. The software genome uses the same alphabet as an independent, explicitly artificial encoding.
- `assets/Kokoro_Lumina_Alpha_v0_6.glb` is the unchanged baseline. The new `assets/Kokoro_Genome_Robotics_Alpha_v1_8.glb` is a derivative generated from virtual servo results.
- A custom `SHA256SUMS.txt` file checks packaged source integrity. It is an error-detection marker, not evidence of authorship or cryptographic authenticity.

**Scientific boundary:** No external LLM or trained Kokoro checkpoint is connected. The avatar is a digital twin controlled by simulated numerical observations. The program cannot demonstrate human-level understanding, phenomenal consciousness, biological phenotype prediction, or physically safe robot control. It is an executable, testable subsystem rather than an assertion that a complete new foundation AI has been trained.
