/** Ripple Daughter Triplet v3.1 — three functional cascaded layers, independently versioned.
 *  Layer P: filtered photoreceptor RGB and finite log temporal contrast
 *  Layer D: leaky dendritic integrator
 *  Layer S: leaky spiking soma with independently decaying adaptation and rate feedback
 * Only dimensionless engineered states, NOT neuron recordings or atomic measurements.
 * Original v0.1 & Delta v3.0 parent code are not modified.
 */
import {deltaOpticalInput, encodeDeltaSymbol} from '../vault/delta/delta-neuron.mjs';
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
function finite(v,n){if(typeof v!=='number'||!Number.isFinite(v))throw new RangeError(n+' must be finite');return v;}
export const TRIPLET_DEFAULTS=Object.freeze({
 tauP:.06,tauD:.08,tauS:.5,tauA:3,tauR:5,refractory:.1,
 theta:.45,thetaMin:.15,thetaMax:2.5,targetHz:1,eta:.08,
 logK:0,logFloor:.02,deltaGain:.22,deltaGate:.06,maxLogChange:.9,
 adaptJump:.008,deltaEnabled:true,spikeAdapt:true,feedback:true,
 feedforward:false,feedforwardGain:0,tauFF:4,srgb:false,attenuation:null,
});
function optionsCheck(options){
 if(!options||typeof options!=='object'||Array.isArray(options))throw new TypeError('options object required');
 for(const k of Object.keys(options))if(!(k in TRIPLET_DEFAULTS))throw new RangeError('unknown triplet option '+k);
 const o={...TRIPLET_DEFAULTS,...options};
 for(const k of ['tauP','tauD','tauS','tauA','tauR','tauFF'])if(!(finite(o[k],k)>.001&&o[k]<=120))throw new RangeError('time constant out of bounds');
 for(const k of ['refractory','theta','thetaMin','thetaMax','targetHz','eta','logK','logFloor','deltaGain','deltaGate','maxLogChange','adaptJump','feedforwardGain'])finite(o[k],k);
 if(o.refractory<.01||o.refractory>2||o.thetaMin<.05||o.thetaMin>=o.thetaMax||o.theta<o.thetaMin||o.theta>o.thetaMax||o.thetaMax>8||o.targetHz<=0||o.targetHz>8||o.targetHz*o.refractory>=1||o.eta<0||o.eta>1||o.logK<0||o.logK>40||o.logFloor<.001||o.logFloor>.5||o.deltaGain<0||o.deltaGain>2||o.deltaGate<0||o.deltaGate>1||o.maxLogChange<=0||o.maxLogChange>5||o.adaptJump<0||o.adaptJump>1||o.feedforwardGain<0||o.feedforwardGain>1)throw new RangeError('triplet options out of bounds');
 for(const k of ['deltaEnabled','spikeAdapt','feedback','feedforward','srgb'])if(typeof o[k]!=='boolean')throw new TypeError(k+' must be boolean');
 // Validate Delta's established optics contract in its own implementation, not a reimplementation.
 deltaOpticalInput([0,0,0],{srgb:o.srgb,attenuation:o.attenuation});
 return Object.freeze(o);
}
/** Analytic response of two coupled exponential leaks and exponential adaptation.
 * d(t)=D+(d0-D)e^(-t/tauD), a(t)=a0 e^(-t/tauA)
 * tauS u'= -u+d-a. Equal-time-constant cases are handled by the proper limit.
 */
function kernel(h,tauInput,tauS){
 const diff=tauInput-tauS;
 if(Math.abs(diff)<1e-9*Math.max(tauS,tauInput))return (h/tauS)*Math.exp(-h/tauS);
 return tauInput*(Math.exp(-h/tauInput)-Math.exp(-h/tauS))/diff;
}
export function tripletMembraneAt(u0,d0,a0,D,h,tauD,tauS,tauA){
 if(h===0)return u0;
 const es=Math.exp(-h/tauS);
 return D+(u0-D)*es+(d0-D)*kernel(h,tauD,tauS)-a0*kernel(h,tauA,tauS);
}
/** Exact endpoint against the held input for each sample; no Euler integration drift. */
export function tripletDendriteAt(d0,D,h,tauD){return D+(d0-D)*Math.exp(-h/tauD);}
/** Three-stage exponentially coupled filter kernel. Closed form for separated
 * time constants, Simpson quadrature for near-degenerate cases only.
 * G = (1/tauS) integral_0^h exp(-(h-t)/tauS) K(t,tauP,tauD) dt.
 */
export function tripletCascadeKernel(h,tauP,tauD,tauS){
 if(h===0)return 0;
 const t=[tauP,tauD,tauS];
 for(const x of t)if(!(x>0&&Number.isFinite(x)))throw new RangeError('positive finite time constants required');
 const proximity=(a,b)=>Math.abs(a-b)<=1e-4*Math.max(a,b);
 if(!proximity(tauP,tauD)&&!proximity(tauP,tauS)&&!proximity(tauD,tauS))
  return tauP/(tauP-tauD)*(kernel(h,tauP,tauS)-kernel(h,tauD,tauS));
 if(proximity(tauP,tauD)&&proximity(tauD,tauS))return .5*(h/tauS)**2*Math.exp(-h/tauS);
 const n=160,step=h/n;
 let total=0;
 for(let k=0;k<=n;k++){
  const t=k*step;
  total+=(k===0||k===n?1:k%2===0?2:4)*Math.exp(-(h-t)/tauS)*kernel(t,tauP,tauD)/tauS;
 }
 return total*step/3;
}
/** Exact piecewise-constant input response for the complete P→D→S linear
 * cascade with one decaying spike-adaptation current.
 */
export function tripletCascadeSomaAt(u0,d0,a0,J,X,h,o){
 const es=Math.exp(-h/o.tauS);
 return J+(u0-J)*es+(d0-J)*kernel(h,o.tauD,o.tauS)
  +X*tripletCascadeKernel(h,o.tauP,o.tauD,o.tauS)-a0*kernel(h,o.tauA,o.tauS);
}
export function tripletCascadeDendriteAt(d0,J,X,h,o){
 return J+(d0-J)*Math.exp(-h/o.tauD)+X*kernel(h,o.tauP,o.tauD);
}
function crossing(u0,d0,a0,J,X,theta,h,o){
 if(u0>=theta)return 0;
 let previous=u0-theta,low=0;
 for(let k=1;k<=48;k++){
  let high=k*h/48,now=tripletCascadeSomaAt(u0,d0,a0,J,X,high,o)-theta;
  if(previous<0&&now>=0){
   for(let i=0;i<45;i++){
    const mid=(low+high)/2;
    if(tripletCascadeSomaAt(u0,d0,a0,J,X,mid,o)>=theta)high=mid;else low=mid;
   }
   return high;
  }
  low=high;previous=now;
 }
 return Infinity;
}
export class DaughterTripletNeuron{
 constructor(options={}){this.o=optionsCheck(options);this.reset();}
 reset(){const o=this.o;this.t=0;this.p=[0,0,0];this.d=0;this.u=0;this.a=0;this.theta=o.theta;this.rate=0;this.rest=0;this.priorLog=null;this.spikeCount=0;}
 step(rgb,dt){
  if(finite(dt,'dt')<=0||dt>.2)throw new RangeError('dt outside (0,0.2]');
  const o=this.o,I=deltaOpticalInput(rgb,{srgb:o.srgb,attenuation:o.attenuation});
  const preproc=I.map(v=>o.logK?Math.log1p(o.logK*v)/Math.log1p(o.logK):v);
  const P0=[...this.p];
  const logs=I.map(x=>Math.log(x+o.logFloor));
  const transient=this.priorLog===null?[0,0,0]:logs.map((v,i)=>{const dv=v-this.priorLog[i];return Math.abs(dv)<o.deltaGate?0:clamp(dv,-o.maxLogChange,o.maxLogChange);});
  this.priorLog=logs;
  const w=[2,1.2,-1.4];
  const tonic=w.reduce((s,v,i)=>s+v*preproc[i],0);
  const prevTonic=w.reduce((s,v,i)=>s+v*this.p[i],0);
  const delta=w.reduce((s,v,i)=>s+v*transient[i],0);
  const T=o.deltaEnabled?o.deltaGain*delta:0;
  const J=tonic+T;
  const start=this.t,events=[];let elapsed=0;
  const advance=(h,advanceSoma)=>{
    // Store OLD state until both coupled trajectories are evaluated.
    const d0=this.d,u0=this.u,a0=this.a;
    const X=prevValue()-tonic;
    if(advanceSoma)this.u=tripletCascadeSomaAt(u0,d0,a0,J,X,h,o);
    else this.u=0;
    this.d=tripletCascadeDendriteAt(d0,J,X,h,o);
    this.a=a0*Math.exp(-h/o.tauA);
    this.p=preproc.map((v,i)=>v+(this.p[i]-v)*Math.exp(-h/o.tauP));
  };
  const prevValue=()=>w.reduce((sum,v,i)=>sum+v*this.p[i],0);
  while(elapsed<dt-1e-12){
   const h=dt-elapsed;
   if(this.rest>1e-12){
    const held=Math.min(h,this.rest);
    advance(held,false);this.rest=Math.max(0,this.rest-held);elapsed+=held;continue;
   }
   const X=prevValue()-tonic;
   const first=crossing(this.u,this.d,this.a,J,X,this.theta,h,o);
   if(Number.isFinite(first)&&first<=h){
    if(first>0){advance(first,false);elapsed+=first;}
    events.push(start+elapsed);this.spikeCount++;this.u=0;this.rest=o.refractory;
    if(o.spikeAdapt)this.a+=o.adaptJump;
    if(events.length>Math.ceil(dt/o.refractory)+2)throw new RangeError('excessive spikes');
   }else{
    advance(h,true);elapsed=dt;
   }
  }
  const decay=Math.exp(-dt/o.tauR);let rateIntegral=this.rate*o.tauR*(1-decay);this.rate*=decay;
  for(const time of events){const e=Math.exp(-(start+dt-time)/o.tauR);this.rate+=e/o.tauR;rateIntegral+=1-e;}
  // Optional feedforward uses simple LIF threshold inversion only when constant drive model is feasible.
  // In the actual three-layer dynamics it is heuristic, not an exact optimal controller.
  let ff=0;const period=1/o.targetHz-o.refractory;
  const thetaStar=tonic>0?tonic*(-Math.expm1(-period/o.tauS)):null;
  if(o.feedforward&&thetaStar!==null&&thetaStar>=o.thetaMin&&thetaStar<=o.thetaMax)
   ff=o.feedforwardGain*(-Math.expm1(-dt/o.tauFF))*(thetaStar-this.theta);
  if(o.feedback||o.feedforward)this.theta=clamp(this.theta+(o.feedback?o.eta*(rateIntegral-o.targetHz*dt):0)+ff,o.thetaMin,o.thetaMax);
  this.t=start+dt;
  for(const [key,value] of Object.entries({u:this.u,d:this.d,a:this.a,theta:this.theta,rate:this.rate}))if(!Number.isFinite(value))throw new RangeError('nonfinite triplet state: '+key);
  const symbol=encodeDeltaSymbol(delta,tonic,o.deltaGate);
  return {t:this.t,layer1:{rgb:I,previous:P0,filtered:[...this.p],contrast:transient},layer2:{dendrite:this.d,tonic,delta,drive:J},layer3:{soma:this.u,adaptation:this.a,threshold:this.theta,rate:this.rate},
   drive:J,count:events.length,events,rate:this.rate,theta:this.theta,u:this.u,adaptation:this.a,tonic,delta,quad:symbol,thetaStar,provenance:'SIMULATED TRIPLET NEURON'};
 }
}
