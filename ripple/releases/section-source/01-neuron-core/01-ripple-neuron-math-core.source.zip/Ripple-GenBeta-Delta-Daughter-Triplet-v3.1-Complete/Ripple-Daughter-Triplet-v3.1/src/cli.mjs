/** Restricted formula CLI. No eval, file writes, network, or dynamic source execution. */
import {compileDaughterFormula,listDaughterFormulas} from './daughter-compiler.mjs';
const [cmd='list',arg]=process.argv.slice(2);
try{
 if(cmd==='list'){console.log(JSON.stringify(listDaughterFormulas(),null,2));}
 else if(cmd==='eval'){
  if(!arg||arg.length>1_000_000)throw new RangeError('JSON request required (max 1MB)');
  const payload=JSON.parse(arg);
  if(!payload||typeof payload!=='object'||Array.isArray(payload))throw new TypeError('request object');
  for(const key of Object.keys(payload))if(!['formula','mode','inputs'].includes(key))throw new RangeError('unsupported request key: '+key);
  const compiled=compileDaughterFormula({formula:payload.formula,mode:payload.mode});
  console.log(JSON.stringify({metadata:compiled.metadata,result:compiled.evaluate(payload.inputs)},null,2));
 }else throw new RangeError('commands: list | eval JSON');
}catch(err){console.error('Ripple compiler rejected:',err.message);process.exitCode=1;}
