"""Deterministic paired resampling of synthetic-world outcomes, not physical inference."""
from pathlib import Path
import json
import numpy as np
p=Path(__file__).resolve().parents[1]
data=json.loads((p/'results/benchmarks.json').read_text())
rb={(r['scene'],r['seed'],r['mode']):r for r in data['rateTrials']}
rd=[rb[(s,seed,'original')]['value']-rb[(s,seed,'triplet')]['value'] for s in data['settings']['rateScenes'] for seed in data['settings']['rateSeeds']]
cb={(r['scene'],r['seed'],r['mode']):r for r in data['colonyTrials']}
cd=[cb[(s,seed,'daughter')]['coverage']-cb[(s,seed,'beta')]['coverage'] for s in data['settings']['colonyScenes'] for seed in data['settings']['colonySeeds']]
def sample(x,seed):
 a=np.asarray(x,dtype=float);rng=np.random.default_rng(seed)
 means=rng.choice(a,size=(12000,len(a)),replace=True).mean(axis=1)
 return {'n':len(x),'mean':float(a.mean()),'median':float(np.median(a)),'wins':int(np.sum(a>0)),'ties':int(np.sum(a==0)),'losses':int(np.sum(a<0)),'percentile95Exploratory':[float(z) for z in np.quantile(means,[.025,.975])]}
result={'rateErrorImprovementHzOriginalMinusDaughter':sample(rd,17031),'coverageDifferenceCellsDaughterMinusBeta':sample(cd,17032),'note':'Exploratory paired bootstrap over synthetic scene-seed units; these are not real-world performance confidence intervals or proof of a general advantage.'}
(p/'results/paired-audit.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
