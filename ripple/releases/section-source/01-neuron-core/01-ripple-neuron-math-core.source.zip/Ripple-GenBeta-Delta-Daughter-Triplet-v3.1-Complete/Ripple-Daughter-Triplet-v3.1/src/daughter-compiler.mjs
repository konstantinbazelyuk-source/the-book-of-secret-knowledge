/** Bounded, allowlisted Ripple mathematics compiler.
 * Parent v3.0 registry delegates unchanged; daughter adds triplet_ripple.
 */
import {compileFormula as compileParent, listFormulas as listParent} from '../vault/delta/formula-compiler.mjs';
import {DaughterTripletNeuron,TRIPLET_DEFAULTS} from './triplet-neuron.mjs';
export const TRIPLET_DESCRIPTOR=Object.freeze({
 id:'daughter_triplet',version:'3.1.0-alpha.1',
 layers:Object.freeze([
  Object.freeze({id:'P',label:'Photoreceptor',state:['p_R','p_G','p_B'],equation:'tauP * p_i_dot = C(I_i) - p_i',dependencies:['optical_input'],integrator:'exact held-input exponential',provenance:'ENGINEERED'}),
  Object.freeze({id:'D',label:'Dendritic integrator',state:['d'],equation:'tauD * d_dot = -d + w·p + gamma * delta',dependencies:['P','signed log contrast'],integrator:'analytic cascade exponential',provenance:'ENGINEERED'}),
  Object.freeze({id:'S',label:'Spike-generating soma',state:['u','a','theta','rate'],equation:'tauS * u_dot = -u + d - a; tauA * a_dot = -a; threshold/reset/event',dependencies:['D'],integrator:'analytic subthreshold cascade + bounded root search',provenance:'ENGINEERED'})
 ]),
 equation:'P→D→S coupled first-order differential-equation triplet with event reset/adaptation',

 modes:Object.freeze(['summary','run']),
 evidence:'SIMULATED ONLY',
 assumptions:'piecewise-constant normalized display RGB over a bounded dt; photometric coefficients are not sensor calibration; implicit exact held-input linear trajectories + bounded spike crossing search',
 units:Object.freeze({I:'dimensionless RGB intensity proxy',dt:'seconds of model time',d:'dimensionless dendrite',u:'dimensionless soma',a:'dimensionless adaptation',events:'spikes per model second'}),
 parents:Object.freeze(['Ripple Gen Beta v2.0 synthetic architecture','Ripple Delta Alpha v3.0','Ripple Neuron v0.1 locked'])
});
function exact(o,allowed,required=[]){if(!o||Object.getPrototypeOf(o)!==Object.prototype)throw new TypeError('plain JSON object required');for(const k of Object.keys(o))if(!allowed.includes(k))throw new RangeError('unknown key '+k);for(const k of required)if(!Object.hasOwn(o,k))throw new RangeError('missing key '+k);}
export function listDaughterFormulas(){return [...listParent(),TRIPLET_DESCRIPTOR];}
export function compileDaughterFormula(request){
 exact(request,['formula','mode'],['formula','mode']);
 if(request.formula!=='daughter_triplet')return compileParent(request);
 if(!TRIPLET_DESCRIPTOR.modes.includes(request.mode))throw new RangeError('unknown triplet mode');
 return Object.freeze({metadata:TRIPLET_DESCRIPTOR,evaluate(input){
  exact(input,['samples','dt','options'],['samples','dt']);
  if(!Array.isArray(input.samples)||input.samples.length<1||input.samples.length>10000)throw new RangeError('samples count 1..10000');
  if(typeof input.dt!=='number'||!Number.isFinite(input.dt)||input.dt<=0||input.dt>.2)throw new RangeError('dt (0,0.2]');
  const n=new DaughterTripletNeuron(input.options??{}),rows=[];
  let total=0;
  for(let i=0;i<input.samples.length;i++){
   const x=input.samples[i];const r=n.step(x,input.dt);total+=r.count;
   if(request.mode==='run')rows.push({t:r.t,events:r.count,rate:r.rate,layer1:r.layer1,layer2:r.layer2,layer3:r.layer3,symbol:r.quad.state});
  }
  return Object.freeze({formula:'daughter_triplet',evidence:'SIMULATED',samples:input.samples.length,durationSec:n.t,spikes:total,rateHz:n.rate,threshold:n.theta,last:{p:[...n.p],d:n.d,u:n.u,a:n.a},rows:request.mode==='run'?rows:undefined});
 }});
}
