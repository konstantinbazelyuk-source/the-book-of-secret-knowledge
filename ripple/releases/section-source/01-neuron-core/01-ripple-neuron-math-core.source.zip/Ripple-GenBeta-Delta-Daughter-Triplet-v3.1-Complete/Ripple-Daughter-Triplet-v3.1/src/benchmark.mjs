import {writeFileSync} from 'node:fs';
import {BetaWorld,RippleNeuron,rng} from '../vault/beta/src/beta-engine.mjs';
import {DeltaRippleNeuron} from '../vault/delta/delta-neuron.mjs';
import {DaughterTripletNeuron} from './triplet-neuron.mjs';
import {DaughterWorld} from './daughter-world.mjs';
const args=process.argv.slice(2),fast=args.includes('--fast');
const series=(kind,k,random)=>{
 const t=k*.05;let r=.35,g=0,b=0;
 if(kind==='steps'&&t>=24&&t<56)r=.70;
 if(kind==='color'&&t>=30&&t<60){r=.20;g=.25;b=.015;}
 if(kind==='periodic')r=.35+.23*(.5+.5*Math.sin(2*Math.PI*t/8));
 if(kind==='noisy')r=.45+.13*Math.sin(2*Math.PI*t/5);
 const a=kind==='steady'?0:kind==='noisy'?.045:.008;
 return [r,g,b].map(v=>Math.max(0,Math.min(1,v+(random()-.5)*2*a)));
};
function trial(kind,seed){
 const modes={original: new RippleNeuron(),delta: new DeltaRippleNeuron(),delta_no_ff:new DeltaRippleNeuron({feedforward:false}),triplet:new DaughterTripletNeuron(),triplet_no_delta:new DaughterTripletNeuron({deltaEnabled:false}),triplet_no_spikeadapt:new DaughterTripletNeuron({spikeAdapt:false})};
 const rows={};for(const mode of Object.keys(modes))rows[mode]={spikes:[],windowErrors:[],events:0,meanRuntimeMs:0};
 const random=rng(seed);
 const steps=fast?700:1800;
 for(let k=0;k<steps;k++){
  const x=series(kind,k,random);
  for(const [key,n] of Object.entries(modes)){
   const r=n.step(x,.05);rows[key].events+=r.count;
   rows[key].spikes.push(...r.events);
  }
 }
 const duration=steps*.05,windows=fast?[[15,25],[25,35]]:[[30,50],[50,70],[70,90]];
 for(const [key,z] of Object.entries(rows)){
  z.windowErrors=windows.map(([lo,hi])=>Math.abs(z.spikes.filter(x=>x>=lo&&x<hi).length/(hi-lo)-1));
  z.mae=z.windowErrors.reduce((a,b)=>a+b,0)/z.windowErrors.length;
  z.spikes=z.spikes.length;
  z.duration=duration;
 }
 return rows;
}
function groupBy(x,group){const groups=new Map();for(const z of x){let key=group(z);if(!groups.has(key))groups.set(key,[]);groups.get(key).push(z);}return [...groups].map(([id,rows])=>({id,n:rows.length,mean:rows.reduce((a,b)=>a+b.value,0)/rows.length}));}
function benchmark(){
 const tasks=['steady','steps','color','periodic','noisy'],seeds=fast?[2187,3119,4041]:[2187,3119,4041,5011,6029,7039,8101,9157];
 const rateTrials=[];
 for(const scene of tasks)for(const seed of seeds){const r=trial(scene,seed);for(const [mode,v] of Object.entries(r))rateTrials.push({scene,seed,mode,value:v.mae,spikes:v.spikes,windowErrors:v.windowErrors});}
 const rateMeans=groupBy(rateTrials,z=>z.mode+':'+z.scene).map(r=>({mode:r.id.split(':')[0],scene:r.id.split(':')[1],n:r.n,meanMAE_Hz:r.mean}));
 const scores=groupBy(rateTrials,z=>z.mode).map(r=>({mode:r.id,n:r.n,meanMAE_Hz:r.mean})).sort((a,b)=>a.meanMAE_Hz-b.meanMAE_Hz);
 const colonyTrials=[];
 const cseeds=fast?[193,1091]:[193,1091,2027,3041,4057,5069,6079,7103];
 for(const scene of ['mixed','barriers','noise','resources'])for(const seed of cseeds){
  for(const [mode,world] of Object.entries({beta:new BetaWorld({seed,scenario:scene}),daughter:new DaughterWorld({seed,scenario:scene})})){
   const result=world.run(fast?140:240);colonyTrials.push({mode,scene,seed,...result});
  }
 }
 const colonyMeans={};for(const mode of ['beta','daughter']){
  const subset=colonyTrials.filter(x=>x.mode===mode);
  colonyMeans[mode]={n:subset.length,coverage:subset.reduce((s,x)=>s+x.coverage,0)/subset.length,
   events:subset.reduce((s,x)=>s+x.events,0)/subset.length,
   clones:subset.reduce((s,x)=>s+x.clones,0)/subset.length,
   share:subset.reduce((s,x)=>s+x.shares,0)/subset.length};
 }
 const output={evidence:'SYNTHETIC MODEL EXECUTION; no sensor measurements',parameterSelection:'Predeclared default; no auto-tuning on these seeds',settings:{rateScenes:tasks,rateSeeds:seeds,colonySeeds:cseeds,colonyScenes:['mixed','barriers','noise','resources'],worldTicks:fast?140:240},rateMeans,scores,colonyMeans,colonyTrials,rateTrials};
 const dest=new URL('../results/benchmarks.json',import.meta.url);writeFileSync(dest,JSON.stringify(output,null,2));
 console.log(JSON.stringify({rateScores:scores,rateMeans,colonyMeans,rateTrials:rateTrials.length,colonyTrials:colonyTrials.length},null,2));
}
benchmark();
