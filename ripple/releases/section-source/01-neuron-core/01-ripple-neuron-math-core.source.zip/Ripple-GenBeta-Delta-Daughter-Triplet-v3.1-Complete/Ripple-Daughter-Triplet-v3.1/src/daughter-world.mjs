/** Daughter inherits Beta's world and action gates; replaces only neuron on agents. */
import {BetaWorld,BETA_LIMITS} from '../vault/beta/src/beta-engine.mjs';
import {DaughterTripletNeuron} from './triplet-neuron.mjs';
export class DaughterWorld extends BetaWorld{
 constructor(options={}){
  const {neuronOptions={},...worldOptions}=options;
  super(worldOptions);
  this.neuronOptions={...neuronOptions};this.tripletEnabled=true;
  for(const agent of this.agents)agent.neuron=new DaughterTripletNeuron(this.neuronOptions);
 }
 addAgent(g,x,y){
  super.addAgent(g,x,y);
  // applies to cloned daughter agents after super() has finished.
  if(this.tripletEnabled)this.agents.at(-1).neuron=new DaughterTripletNeuron(this.neuronOptions);
 }
 summary(){return {...super.summary(),neuronCore:'DaughterTriplet-v3.1',sourceModel:'SYNTHETIC'};}
}
