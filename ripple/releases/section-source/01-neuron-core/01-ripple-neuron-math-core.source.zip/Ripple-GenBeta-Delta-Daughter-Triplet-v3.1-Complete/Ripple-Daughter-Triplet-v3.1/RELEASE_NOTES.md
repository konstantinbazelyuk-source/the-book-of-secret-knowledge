# 3.1.0-alpha.1 — Gen Beta × Delta Daughter (2026-10-14 UTC)

- **ADDED** new P→D→S triplet neuron with mathematically coupled held-input trajectories and event reset/adaptation.
- **ADDED** immutable parent Beta and Delta code vault; no historical core overwritten.
- **ADDED** BetaWorld daughter subclass with actual neuron replacement for all agents and later descendants, preserving Beta guardrails.
- **ADDED** structured 3-layer formula compiler descriptor and bounded runtime `daughter_triplet`; prior `beer_lambert` and `delta_ripple` operations delegated unchanged.
- **ADDED** executable standalone browser lab, CLI, synthetic benchmarking, comparative report, paired-audit.
- **TESTED** 19 new tests, 18 Beta parent tests, 38 Delta parent tests, two browser content-interaction tests, 240 rate and 64 synthetic colony trials.
- **LIMITATION** early evidence does not establish universal performance gains, real sensor validation, artificial intelligence or biological correspondence.
- **SCOPE** separate Alpha daughter; no remote or phone release changed.
