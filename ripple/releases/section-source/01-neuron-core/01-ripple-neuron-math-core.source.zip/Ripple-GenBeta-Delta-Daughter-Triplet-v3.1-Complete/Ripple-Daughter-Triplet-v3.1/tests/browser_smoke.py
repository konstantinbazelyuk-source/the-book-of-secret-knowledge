"""Browser rendering through page.set_content (environment blocks file:// navigation).
Tests REAL executable inline bundled source code, not a mocked replacement engine.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json
root=Path(__file__).resolve().parents[1]
html=(root/'Ripple-Daughter-Triplet-v3.1.html').read_text()
outputs=[]
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
 for label,viewport in [('phone',{'width':390,'height':844}),('desktop',{'width':1270,'height':870})]:
  page=browser.new_page(viewport=viewport)
  errors=[]
  page.on('pageerror',lambda err:errors.append(str(err)))
  page.set_content(html,wait_until='load')
  page.wait_for_function('Boolean(window.__rippleDaughterTest)',timeout=20000)
  status=page.locator('#status').inner_text()
  assert 'daughter_triplet' in status,status
  page.locator('#run').click()
  page.wait_for_function("document.querySelector('#table').textContent.includes('triplet')")
  bench=page.locator('#table').inner_text()
  assert 'original' in bench and 'delta' in bench and 'triplet' in bench
  page.locator('#colony').click()
  page.wait_for_function("document.querySelector('#colonyr').textContent.includes('Daughter × Beta')")
  colony=page.locator('#colonyr').inner_text()
  assert 'Original Beta' in colony and 'Daughter × Beta' in colony
  page.locator('[data-preset="green"]').click()
  assert abs(float(page.locator('#v1').inner_text())-.65)<1e-12
  check=page.evaluate("() => { const r=window.__rippleDaughterTest.compileDaughterFormula({formula:'daughter_triplet',mode:'summary'}).evaluate({dt:.05,samples:[[.35,0,0]]});return r.evidence==='SIMULATED'&&r.last.p.length===3; }")
  assert check
  page.locator('#live').click();page.wait_for_timeout(170);page.locator('#live').click()
  assert page.locator('#live').inner_text()=='Live on/off'
  page.screenshot(path=str(root/f'results/browser-{label}.png'),full_page=True)
  outputs.append({'viewport':label,'size':viewport,'status':status,'benchmark':bench,'colony':colony,'pageErrors':errors,'compilerCheck':check})
  assert not errors,errors
  page.close()
 browser.close()
(root/'results/browser-smoke.json').write_text(json.dumps(outputs,indent=2))
print(json.dumps({'status':'PASS','views':len(outputs),'checks':['compiler','comparison','colony','preset','live','no page errors']},indent=2))
