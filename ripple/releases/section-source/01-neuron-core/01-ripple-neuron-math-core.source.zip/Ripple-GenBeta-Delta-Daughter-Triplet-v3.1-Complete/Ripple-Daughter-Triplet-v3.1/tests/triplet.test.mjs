import {test} from 'node:test';import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';import {readFileSync} from 'node:fs';
import {DaughterTripletNeuron,tripletDendriteAt,tripletMembraneAt,TRIPLET_DEFAULTS} from '../src/triplet-neuron.mjs';
import {DaughterWorld} from '../src/daughter-world.mjs';
import {BetaWorld} from '../vault/beta/src/beta-engine.mjs';
import {DeltaRippleNeuron} from '../vault/delta/delta-neuron.mjs';
import {compileDaughterFormula,listDaughterFormulas} from '../src/daughter-compiler.mjs';
const hash=p=>createHash('sha256').update(readFileSync(new URL(p,import.meta.url))).digest('hex');
test('immutable exact original v0.1 hash',()=>assert.equal(hash('../vault/beta/legacy/ripple-core.js'),'dba6639b7902f0c702d15fff588524629f3754cfd72d7b704f22a76b78960ee3'));
test('parent Delta checksum preserved',()=>assert.equal(hash('../vault/delta/delta-neuron.mjs'),'7b17a0ebc6c329cb832d372bdb6418111e6afe1d49e958d319f946d48ce19780'));
test('parent Beta engine checksum preserved',()=>assert.equal(hash('../vault/beta/src/beta-engine.mjs'),'c3272fb5c99ced6f3b14d2c90288bcf7ebacc7cf33c61bd2bf4f0a4497164bf3'));
test('decaying dendrite exact solution',()=>assert.ok(Math.abs(tripletDendriteAt(0.1,1.7,.25,.3)-(1.7+(0.1-1.7)*Math.exp(-.25/.3)))<1e-14));
test('coupled membrane response matches independent RK4 high-resolution ODE solver',()=>{
 let u0=.13,d0=.26,a0=.07,D=1.44,h=.27,td=.15,ts=.45,ta=2.7;
 let u=u0,d=d0,a=a0,steps=120000,dt=h/steps;
 const deriv=([x,y,z])=>[(-x+y-z)/ts,(-y+D)/td,-z/ta];
 for(let k=0;k<steps;k++){const v=[u,d,a],k1=deriv(v),k2=deriv(v.map((n,j)=>n+dt*k1[j]/2)),k3=deriv(v.map((n,j)=>n+dt*k2[j]/2)),k4=deriv(v.map((n,j)=>n+dt*k3[j]));[u,d,a]=v.map((n,j)=>n+dt*(k1[j]+2*k2[j]+2*k3[j]+k4[j])/6)}
 assert.ok(Math.abs(u-tripletMembraneAt(u0,d0,a0,D,h,td,ts,ta))<2e-11);
});
test('equal dendritic/somatic time constants use continuous analytic limit',()=>{
 const o=tripletMembraneAt(.23,.4,.17,1.3,.15,.5,.5,3);
 const v=tripletMembraneAt(.23,.4,.17,1.3,.15,.5+1e-10,.5,3);assert.ok(Math.abs(o-v)<1e-8);
});
test('zero input stays silent and outputs finite and guarded',()=>{
 const n=new DaughterTripletNeuron();for(let k=0;k<1000;k++){const v=n.step([0,0,0],.05);assert.equal(v.count,0);assert.ok(Number.isFinite(v.layer3.soma));}
 assert.equal(n.spikeCount,0);assert.ok(n.theta>=n.o.thetaMin&&n.theta<=n.o.thetaMax);
});
test('new three-layer state really evolves under light',()=>{
 const n=new DaughterTripletNeuron({deltaGain:0});const a=n.step([1,.25,0],.05),b=n.step([1,.25,0],.05);
 assert.ok(a.layer1.filtered[0]>0&&a.layer1.filtered[0]<1);
 assert.ok(b.layer1.filtered[0]>a.layer1.filtered[0]);assert.ok(Number.isFinite(b.layer2.dendrite));
 assert.ok(b.layer2.dendrite!==b.layer3.soma);
});
test('signed Delta light response is present',()=>{
 const n=new DaughterTripletNeuron();n.step([.1,0,0],.05);const rise=n.step([.9,0,0],.05),fall=n.step([.1,0,0],.05);
 assert.ok(rise.delta>0);assert.ok(fall.delta<0);assert.equal(rise.quad.state,'1');assert.equal(fall.quad.state,'-1');
});
test('daughter live triplet is actually substituted in Beta simulation agents and descendants',()=>{
 const w=new DaughterWorld({seed:1731,policy:'hybrid-beta'});assert.ok(w.agents.every(a=>a.neuron instanceof DaughterTripletNeuron));w.run(50);
 assert.ok(w.agents.every(a=>a.neuron instanceof DaughterTripletNeuron));const r=w.summary();assert.equal(r.neuronCore,'DaughterTriplet-v3.1');assert.ok(r.coverage>=0);
});
test('deterministic replay in Beta simulation',()=>{
 const a=new DaughterWorld({seed:75,scenario:'barriers'}),b=new DaughterWorld({seed:75,scenario:'barriers'});a.run(125);b.run(125);assert.deepEqual(a.exportRecord(),b.exportRecord());
});
test('compiler has daughter formula and preserves original Beer Lambert operation',()=>{
 assert.ok(listDaughterFormulas().some(x=>x.id==='daughter_triplet'));
 const x=compileDaughterFormula({formula:'daughter_triplet',mode:'summary'}).evaluate({dt:.05,samples:[[.35,0,0],[.7,0,0]]});
 assert.equal(x.samples,2);assert.equal(x.evidence,'SIMULATED');
 const v=compileDaughterFormula({formula:'beer_lambert',mode:'forward'}).evaluate({I0:1,mu:.35,L:2});assert.ok(Math.abs(v.T-Math.exp(-.7))<1e-14);
});
test('compiler rejects oversize and invalid physical inputs',()=>{
 const p=compileDaughterFormula({formula:'daughter_triplet',mode:'summary'});
 assert.throws(()=>p.evaluate({dt:.05,samples:Array(10001).fill([0,0,0])}),/samples/);
 assert.throws(()=>p.evaluate({dt:.05,samples:[[.1,Infinity,0]]}),/finite/);
 assert.throws(()=>p.evaluate({dt:3,samples:[[.3,0,0]]}),/dt/);
 assert.throws(()=>compileDaughterFormula({formula:'eval',mode:'run'}),/Unknown|unknown/);
});
test('guards invalid parameter options and giant delta',()=>{
 assert.throws(()=>new DaughterTripletNeuron({tauD:-1}),/bounds/);
 assert.throws(()=>new DaughterTripletNeuron({__proto__:2,external:'read'}),/unknown/);
 assert.throws(()=>new DaughterTripletNeuron({attenuation:{mu:[1,2,-3],L:1}}),/Invalid attenuation|outside/);
});
test('numerical stress: 40,000 bounded synthetic RGB samples',()=>{
 let s=8491;const rand=()=>((s=(Math.imul(s,1664525)+1013904223)>>>0)/4294967296);
 const n=new DaughterTripletNeuron();for(let k=0;k<40000;k++){
  const r=n.step([rand(),rand(),rand()],.02);assert.ok(Number.isFinite(r.rate));assert.ok(Number.isFinite(r.layer2.dendrite));
  assert.ok(Number.isFinite(r.layer3.adaptation));assert.ok(r.layer3.threshold>=.15&&r.layer3.threshold<=2.5);
  assert.ok(r.events.every((e,i)=>e>=0&&(i===0||e>=r.events[i-1])));
 }
});
test('full P-D-S cascade matches an independently integrated four-state ODE',async()=>{
 const {tripletCascadeSomaAt,tripletCascadeDendriteAt}=await import('../src/triplet-neuron.mjs');
 const o={tauP:.061,tauD:.14,tauS:.44,tauA:2.6},input=.94,p0=.15,d0=.24,u0=.08,a0=.09,T=.17;
 const X=p0-input,J=input+T,h=.39,n=240000,dt=h/n;
 let p=p0,d=d0,u=u0,a=a0;
 const f=([p,d,u,a])=>[(input-p)/o.tauP,(-d+p+T)/o.tauD,(-u+d-a)/o.tauS,-a/o.tauA];
 for(let k=0;k<n;k++){
  let v=[p,d,u,a],k1=f(v),k2=f(v.map((z,i)=>z+.5*dt*k1[i])),k3=f(v.map((z,i)=>z+.5*dt*k2[i])),k4=f(v.map((z,i)=>z+dt*k3[i]));
  [p,d,u,a]=v.map((z,i)=>z+dt*(k1[i]+2*k2[i]+2*k3[i]+k4[i])/6);
 }
 assert.ok(Math.abs(d-tripletCascadeDendriteAt(d0,J,X,h,o))<1e-10);
 assert.ok(Math.abs(u-tripletCascadeSomaAt(u0,d0,a0,J,X,h,o))<1e-10);
});
test('near-degenerate triple-lag kernel matches numerical triple filtering',async()=>{
 const {tripletCascadeKernel}=await import('../src/triplet-neuron.mjs');
 let tau=.25,h=.13,k=tripletCascadeKernel(h,tau,tau,tau);
 const ref=.5*(h/tau)**2*Math.exp(-h/tau);
 assert.ok(Math.abs(k-ref)<1e-14);
 assert.ok(tripletCascadeKernel(h,.25,.25000001,.49)>0);
});
test('Beta daughter clones receive the daughter neuron, not a legacy default',()=>{
 const w=new DaughterWorld({seed:193,policy:'hybrid-beta',scenario:'mixed'});
 w.run(240);assert.ok(w.agents.length>3);assert.ok(w.agents.every(a=>a.neuron instanceof DaughterTripletNeuron));
});
test('compiler exposes three separate computational layer contracts',()=>{
 const desc=listDaughterFormulas().find(x=>x.id==='daughter_triplet');
 assert.equal(desc.layers.length,3);
 assert.deepEqual(desc.layers.map(x=>x.id),['P','D','S']);
 const run=compileDaughterFormula({formula:'daughter_triplet',mode:'run'}).evaluate({dt:.05,samples:[[.35,0,0],[.7,0,0]]});
 assert.ok(run.rows.at(-1).layer1.filtered.length===3);
 assert.ok(Number.isFinite(run.rows.at(-1).layer2.dendrite));
 assert.ok(Number.isFinite(run.rows.at(-1).layer3.soma));
});
