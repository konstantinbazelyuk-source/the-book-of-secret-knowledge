# Ripple Daughter v3.1 — Measured, calculated, simulated, proposed

## Verified parent continuity

- `vault/beta/legacy/ripple-core.js` SHA-256 equals the original v0.1 locked hash.
- `vault/beta/src/beta-engine.mjs` SHA-256 matches the previous Gen Beta v2.0 runtime.
- `vault/delta/delta-neuron.mjs` SHA-256 matches the previous Delta Alpha v3.0 neuron.
- No original release or remote application was modified.

## Numerical solver verification

- Exact new P→D→S held-input solution compared against a separately coded fourth-order Runge–Kutta implementation integrating `p,d,u,a`: passed `abs(error)<1e-10` for the declared independent test case.
- Legacy two-exponential `d→u` response also compared against independent RK4 to `2e-11` tolerance.
- Equal time-constant limiting kernel and bounded threshold root logic covered by tests.
- 40,000 random bounded input steps completed without nonfinite states, threshold violations or invalid event ordering.
- Tests: 18 parent Beta checks PASS; 38 parent Delta checks PASS; 19 daughter checks PASS; 2 independent Chromium content-injection smoke checks PASS. Direct `file://` navigation could not be tested due administrator restrictions.

## Five identical synthetic light protocols: mean absolute firing-rate error (Hz)

Each reported value aggregates **8 predetermined seeds** and 3 windows of 20 seconds per 90-second run. Total `5 × 8 × 6 = 240` model trials across the 6 tested variants. The outcome is a metric of *target tracking*, not cognition, prediction quality or physical light calibration.

| Protocol | Original v0.1 | Delta default | Delta (feedforward off) | Daughter Triplet |
|---|---:|---:|---:|---:|
| Steady | 0.00000 | 0.08333 | 0.00000 | 0.00000 |
| Brightness steps | 0.21667 | 0.12083 | 0.20833 | 0.20417 |
| Channel change | 0.02083 | 0.08333 | 0.00000 | 0.03333 |
| Periodic | 0.05000 | 0.10000 | 0.00000 | 0.00000 |
| Noisy | 0.00625 | 0.10417 | 0.00625 | 0.01667 |
| **Overall mean** | **0.05875** | **0.09833** | **0.04292** | **0.05083** |

Daughter is modestly better than the original **on this aggregate**, but Delta with feedforward turned off is better still. It is weaker than original on the color-change and noise tests. Daughter temporal-contrast ablation has essentially the same target-tracking performance; a claim that light-change sensing causes the rate advantage is therefore unsupported.

Paired original-minus-daughter rate-error reduction across the 40 condition/seed pairs: **+0.00792 Hz** (15 better, 18 tied, 7 worse). Exploratory paired-bootstrap percentile interval **approximately [0.00000, 0.01583] Hz**, touches zero. No inference of a universal win is justified.

## Synthetic Beta-world mapping evaluation

4 world conditions × 8 seeds × 2 neuron-core choices = **64 world trials**, 240 ticks each. Every world used the same synthetic input generator, original Beta action grammar, memory, sharing and descendant reproduction. The only active difference is the neuron class, which changes future simulated agent paths and their source observations.

| Metric (mean of 32 runs per variant) | Original Beta | Beta × Daughter |
|---|---:|---:|
| Distinct discovered map cells | 52.84375 | 55.18750 |
| Neuron events | 38.81250 | 40.62500 |
| Clones | 4.18750 | 5.18750 |
| Share actions | 1.25000 | 0.46875 |

Paired daughter-minus-Beta coverage difference **+2.34375 cells**, with **15 positive, 2 tied, 15 negative** pairs. Exploratory paired-bootstrap percentile interval **[-2.1875,+6.75] cells**, spans zero. **No statistically convincing mapping advantage.** Inherited Beta action rules were not independently learned, and all worlds and images are synthetic.

## Evidence status

- **MEASURED physical/biological:** none.
- **CALCULATED mathematical:** analytic held-input coupled cascade and optical transformations.
- **EXECUTED NUMERICAL:** 19 daughter tests, 240 rate benchmark trials, 64 world benchmark trials, 40,000-step stress test, two parent test suites.
- **EXECUTED BROWSER:** source-embedded offline interface on 390-px and 1270-px Chromium `set_content`, comparisons, colony, presets, live control, no page errors.
- **PROPOSED / UNVERIFIED:** calibration to physical optical sensors, learning competence, efficient GPU/supercomputer execution, any physical neuron interpretation.

Raw results: `results/benchmarks.json`; paired difference analysis: `results/paired-audit.json`; full console output and test transcript under `results/`.
