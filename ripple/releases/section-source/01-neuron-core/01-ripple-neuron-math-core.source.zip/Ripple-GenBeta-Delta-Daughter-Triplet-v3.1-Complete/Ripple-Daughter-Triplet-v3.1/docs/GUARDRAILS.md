# Guardrails — Ripple Daughter v3.1

1. **Preservation:** parent core hashes immutable and checked. Parent source is stored separately in `vault/`, not reimplemented as a presumed improvement.
2. **Input schema:** three finite normalized RGB values in `[0,1]`; time step `(0,0.2]`; bounded optical and neuron coefficients. Parent Delta photometry supplies restricted optical transformations.
3. **State:** finite soma/dendrite/adaptation; strictly bounded threshold. No arbitrary script evaluator: formula compiler resolves only allowlisted names and validated schemas.
4. **Actions:** Gen Beta retains predeclared `SCAN`, `MOVE`, `SHARE`, `CLONE`, `WAIT`, guarded synthetic packets, capped population and runtime; daughter only replaces the neuron object per agent.
5. **Reproducibility:** seeds, scenarios, parameters and reference checksums recorded. No model-selection auto-tuning against the final evaluation seeds.
6. **Data provenance:** all benchmark fields are `SYNTHETIC` and optical RGB values are numerical proxies. No physical photons, light fields, atom counts, brain signals, or sensors were measured.
7. **Intelligence:** nothing here demonstrates self-improving programming, new general skills, or consciousness. Mutation rules and world actions remain explicitly bounded.
8. **Numerics:** exact subthreshold trajectories under piecewise constant optical samples for separated time constants; Simpson quadrature approximation near degenerate constants; bounded first-crossing bracket search can miss pathological fast transients.
9. **Deployments:** no connected GitHub repo, cloud runtime, camera app, or historical release altered. Standalone test application is isolated.
