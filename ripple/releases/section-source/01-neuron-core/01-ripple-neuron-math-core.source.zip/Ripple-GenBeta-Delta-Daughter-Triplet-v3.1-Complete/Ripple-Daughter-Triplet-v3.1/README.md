# Ripple Daughter Δ³ — Gen Beta × Delta, Alpha v3.1.0

**Status:** executable, separately versioned **three-layer engineered neuron** coupled to the existing Beta synthetic world. No earlier Ripple release was overwritten. The recorded evaluations are numerical only; no camera, hardware, living neuron, or quantum measurement was taken.

## Quick use

- **No setup:** Open `Ripple-Daughter-Triplet-v3.1.html` in a modern browser. It embeds the original Beta, Delta, and daughter source engines and executes numerical comparisons and colony runs. Tested by loading its complete HTML content into headless Chromium on 390 px and 1270 px viewports; direct `file://` browser navigation was blocked by this environment's administrator and was not tested. If local browser permissions reject `file://`, serve the file with a simple localhost HTTP server.
- **Developer/reproducibility:** Node.js 22+ and Python 3 with NumPy for the optional paired audit. No remote cloud, API key, paid tool, or network runtime is needed.

```sh
node --test tests/triplet.test.mjs
node src/benchmark.mjs
python src/statistical_audit.py
python build_standalone.py
python tests/browser_smoke.py
node src/cli.mjs list
node src/cli.mjs eval '{"formula":"daughter_triplet","mode":"summary","inputs":{"dt":0.05,"samples":[[0.35,0,0],[0.70,0,0]]}}'
```

If Playwright/Chromium aren't installed, the browser test is optional; numerical source and compiler tests need only Node. Browser test uses Chromium via Playwright and content injection, not a mocked engine.

## Exact design objective

A **triplet of mathematical stages**, not an ill-defined “three-bit neuron”:
1. **P: photoreceptor filter** converts bounded RGB proxy signals into filtered, per-channel states with a defined time constant; optionally uses established sRGB decoding, Beer–Lambert attenuation and logarithmic compression from the unchanged Delta utilities.
2. **D: dendritic accumulator** couples the photo-state to signed log temporal contrast, with its own RC time constant.
3. **S: soma with adaptation** integrates the *time-varying* dendritic state and a decaying spike-adaptation current; a threshold crossing produces an event, resets soma, and updates the bounded rate controller.

The coupled **P→D→S** subthreshold trajectories are solved analytically under held optical input and fixed contrast over each time step. Near-equal time constants use a numerically integrated limiting kernel. The maximum per-step time is 0.2 model seconds; threshold crossing uses 48 bounded brackets and bisection. These numerical choices are documented in `docs/TRIPLET_MATHEMATICS.md`.

## Parentage: actually imported, not rewritten

- **Original Ripple neuron v0.1:** SHA-256 `dba6639b7902f0c702d15fff588524629f3754cfd72d7b704f22a76b78960ee3`, stored at `vault/beta/legacy/ripple-core.js`. The unchanged code retains its original 0.95 Hz versus 3.40 Hz brightness-step numerical regression.
- **Gen Beta v2.0 runtime:** intact `vault/beta/src/beta-engine.mjs`, its original optical and Quad modules, and bounded synthetic world. This is the functional core archived under **Gen Beta v2.1**. The v2.1 image-digit classifier is *not* silently embedded or claimed to improve the triplet.
- **Delta Ripple v3.0:** intact `vault/delta/delta-neuron.mjs`, `photometry.mjs` and formula compiler, providing proven mathematical routines (not proven biological performance).
- **New daughter code:** `src/triplet-neuron.mjs`, `src/daughter-world.mjs`, `src/daughter-compiler.mjs`. The daughter replaces each Beta agent's neuron *at runtime* and retains Beta's limited grammar and spatial world; all child agents also receive the daughter neuron.

## Results and limitations

See `docs/COMPARISON_AND_EVIDENCE.md` and `results/benchmarks.json`. Over 40 synthetic rate evaluations, the daughter achieved mean absolute deviation **0.05083 Hz**, compared with **0.05875 Hz** for original Ripple, **0.09833 Hz** for Delta default, and **0.04292 Hz** for Delta without feedforward. The daughter was **not best overall**. In 32 paired Beta-colony simulations, mean coverage changed from 52.84 cells to 55.19; wins and losses were equal and an exploratory resampling interval included zero. This **does not demonstrate a reliable coverage improvement**. Physical validation remains unperformed.

Safety: bounded inputs/parameters, no arbitrary JavaScript evaluation, no internet access or physical device commands, no autonomous code generation, and no “intelligence” or “consciousness” assertions.

## Research basis

Established background, not proofs for the engineered daughter: EPFL *Neuronal Dynamics* (Gerstner et al.), [LIF/RC model](https://neuronaldynamics.epfl.ch/online/Ch1.S3.html), [spike adaptation](https://neuronaldynamics.epfl.ch/online/Ch6.S1.html), and [multi-compartment integrate-and-fire](https://lcnwww.epfl.ch/gerstner/SPNM/node29.html). Physical measurement and parameter fitting are required before biological/optical predictive claims.
