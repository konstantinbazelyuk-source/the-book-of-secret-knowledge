# Ripple Cybernetic Mycelium — isolated v0.1 experiment

**Status:** Working deterministic JavaScript simulation with tested source code. The proposed distributed architecture and mathematical worker capacity are **not** validated as a physical neuromorphic system, multithreaded application, trained neural network, or autonomous AI.

**Continuity:** This experiment uses the original Ripple Neuron v0.1 leaky-integrate-and-fire code *verbatim* in `ripple_core_reference.js`, except a descriptive header and Node module export. The original file is archived in `source_reference/` for byte comparison. Later Ripple v0.5/v0.7 work and any ongoing tests are not modified, replaced, or integrated.

## Quick start

1. Open **`Ripple-Cybernetic-Mycelium.html`** in any current browser. It is a single file; no server, install, or internet access is needed. Select the maximum population and choose **Start**.
2. For repeatable tests and data with Node.js (tested with Node 22), open a terminal in this folder:

   ```sh
   node test_colony.js
   node simulate.js 12 simulation_run
   node simulate.js 1 baseline_single_worker
   ```

3. The two simulation commands write one JSON and one CSV each. The included files contain the runs used for the report.

## Mathematical preservation

Original Ripple v0.1 kernel:

- Input drive: `D = 2*x_R + 1.2*x_G - 1.4*x_B` for normalized channels in `[0,1]`.
- Membrane evolution: `tau_v * du/dt = -u + D` with `tau_v = 0.5 s`; threshold crossing emits an event, resets `u = 0`, and enforces a `0.1 s` refractory period.
- Rate estimate `r_hat` has `tau_r = 5 s` and a `1/tau_r` impulse at each firing event.
- Feedback: `dtheta/dt = eta * (r_hat - target)` with `eta = .08`, target `1 event/s`, and clamped threshold `0.15 <= theta <= 2.5`.
- The 0.05-second step uses the original source's exact event crossing integration.

No membrane equation, drive weight, or adaptation parameter is changed. An instantiated clone starts with fresh independent state, rather than copying the parent's momentary activity/threshold history.

## Proposed *new* colony layer

- A **master/controller** decomposes input into chunks, watches load, collates numerical results, verifies result integrity, and controls the number of worker clones. The root R0 both coordinates and processes work. The master is a known single point of failure; decentralization and persistence remain future work.
- **Workers** are identical Ripple kernel instances, each with a queue. A pending chunk excites R only (`x_R=0.35`; green/blue zero). One actual Ripple firing event authorizes computing one chunk's integer sum and sum-of-squares. With an empty queue the worker receives darkness and stops emitting new spikes. This mapping is a proposed software interface, not a biological discovery.
- **Decomposition / composition:** A 32-integer job is split into four contiguous chunks. Workers compute separate partial sums and squared sums. The controller recombines and verifies equality against the independently calculated expected values. Worker outputs are actual integer arithmetic.
- **Local transport:** Each worker can transfer ownership of one queued chunk to a neighboring worker with a shorter queue. When cloning, a parent transfers half its remaining queue to its new child. A moving unit is not copied or recomputed; completed-unit identity is tracked.
- **Topology:** Parent-child bidirectional links form a branching connected tree. Retiring a non-root node reconnects its children to its parent. No wireless/electrical/mycelial hardware network is represented.
- **Growth:** At each simulated second, the controller measures 10-second arrival rate and outstanding queue. It computes the proposed desired count:

  `N_desired = clamp(ceil((arrival_chunks_per_second + queued_chunks/12) / (0.95 * 0.72)), 1, maxNodes)`

  Here 0.95 chunks/s per worker is a *design capacity estimate*, 0.72 a target fraction of capacity, and 12 seconds a queue-drainage timescale, **not measured throughput constants**. Scale-out is capped at two workers per control interval. A hard maximum enforces the population limit.
- **Contraction:** On sustained lower demand, the controller waits for 15 simulated seconds of below-target capacity before retiring workers, at most one per five seconds. It transfers queued work before removal. The permanent root remains.

## Reproducible numeric trial

The same deterministic sequence of 84 submitted 32-integer jobs arrives during 200 simulated seconds. Each job creates four chunks (336 total). Load phases:

- 0–30 seconds: a job every 5 seconds (light).
- 30–110 seconds: a job every 1.1 seconds (burst).
- 110–160 seconds: a job every 12 seconds (recovery).
- 160–200 seconds: no arrivals; existing work drains.

| Result at simulated t=200 s | Single fixed Ripple worker | Colony (max 12 workers) |
| --- | ---: | ---: |
| Jobs submitted | 84 | 84 |
| Jobs completed and verified | 50 | 84 |
| Chunks processed | 202 | 336 |
| Chunks queued | 134 | 0 |
| Logical clones created, including root | 1 | 7 |
| Logical clones retired | 0 | 6 |
| Logical clones still active | 1 | 1 |
| Interworker chunk relays | 0 | 210 |

The simulated colony processed more chunks *because multiple virtual neurons were granted their own modeled firing events*. This is not a measured parallel CPU speed-up: **all instances run sequentially within one JavaScript thread**. The model can even use more real CPU time than the single-worker case. Timings and physical capacity must be measured before performance claims.

## Testing and evidence

`node test_colony.js` passes **12/12 checks** as run for this package: exact v0.1 source comparison, documented parameters, dark/inhibited responses, fresh replica state, population cap, distinct workers processing actual arithmetic, eventual contraction, link integrity, input validation, adaptive-versus-single load trial, and deterministic replay.

`simulation_run.json` and `baseline_single_worker.json` contain their full numerical timelines, composed results, and state snapshots. `simulation_run.csv` and `baseline_single_worker.csv` can be plotted in a spreadsheet.

## Known limitations / engineering steps to reach true cybernetic deployment

1. **No true physical parallelism.** Port workers to Web Workers, Node `worker_threads`, processes, microcontrollers, or network services. Record wall-clock throughput, latency, CPU, energy, memory, and communication overhead against ordinary queue-worker baselines.
2. **No durable jobs or crash recovery.** Add job IDs, acknowledged assignment, persistent queue/ledger, worker heartbeat, lease expiry, retry policy, and idempotent deduplication.
3. **No intelligent semantic decomposition.** This is only exact, reversible arithmetic chunking; real agent tasks need explicit typed tools and execution boundaries. A Ripple firing event alone does not supply language reasoning or a learned representation.
4. **No learning of routing weights.** Edges are graph links, not trained neural weights. Edge cost, delay, congestion control, credit budgets, and reinforcement rules can be studied after workload correctness is established.
5. **Master is centralized.** To remove that dependency, design fault-tolerant decentralized coordination and consensus/persistence separately. Real distributed state is substantially harder than a simulated tree.
6. **No proof about fungal cognition.** Fungal electrophysiology is active research; mycelial nutrient transport and topology are design analogies. The cited adaptive-network `Physarum` literature concerns a *slime mold, not a true fungus*.

## Sources / references

- User's original `Ripple-Neuron-Simulator.html`, archived with the package (2026-10-13); original engineering brief is in the user's Library.
- FEMS Microbiology Reviews (2025), *Electrical signaling in fungi: past and present challenges*: https://doi.org/10.1093/femsre/fuaf009 .
- Tero et al., *Rules for biologically inspired adaptive network design*, Science (2010), doi: https://doi.org/10.1126/science.1177894 (slime mold network analogy, not fungal intelligence).
- Kubernetes Horizontal Pod Autoscaling: https://kubernetes.io/docs/concepts/workloads/autoscaling/horizontal-pod-autoscale/ .

## Permissions and separation

This is a local downloadable experiment only. No connected GitHub repository, live Ripple environment, or current testing branch has been edited. The original materials were released under CC0-1.0; this new experiment is also provided under CC0-1.0, with the usual distinction that third-party work remains governed by its own licenses and no patent novelty/clearance is promised.
