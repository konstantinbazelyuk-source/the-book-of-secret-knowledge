# Ripple colony: architecture and acceptance gates

## Biological pattern → bounded software engineering analogy

| Inspiration | Proposed mechanism | Important scientific boundary |
| --- | --- | --- |
| Hyphal branching | A worker instance can spawn another instance under load | A software clone is not a living organism |
| Nutrient source/sink movement | Queue ownership, task credits and redistribution | A payload is not energy or a nutrient; real CPU/RAM are host-provided |
| Electrical signaling | Original Ripple spiking event gates a chunk of computation | Fungal electrical signal encoding/computational meaning is not established |
| Network remodeling | Grow when demanded, retire only after sustained inactivity | This is a policy-based autoscaler, not biological self-organization |
| Mycelial substrate | A connected graph of worker links | Logical links have zero modeled latency in v0.1 |

## Contracts

**Core input:** calibrated `x=[R,G,B]` with 0..1 channels, `dt <= 0.5s`. In the present colony experiment `x_R=0.35` only when the worker's queue has work; green and blue are zero. Each event enables exactly one arithmetic chunk.

**Work envelope:** `{job:int, part:int, values:int[]}`. A queue may only hold a work unit in one place. The node's computation returns `{sum:int, sumsq:int, worker:int}`. Root waits for all chunk results and verifies the two reductions against the known input.

**Graph edges:** bidirectional neighbor links are represented as a `Set` of node IDs; transport removes from source queue and appends to neighbor queue. The current run models instantaneous one-hop transfers; it records relay counts but not link delays.

**Scale decision:** one simulated second control loop; 10-second trailing demand estimate; 1–12 logical workers by default; maximum 2 additions per interval; 15-second low-load condition followed by no more than one retirement per five seconds.

**Retirement contract:** Node R0 persists. When another node retires, queued work is handed to its parent and children are reconnected; no completed results are deleted. No persistence across app restarts exists.

## Feedback loops

1. **Neuron-level feedback (original):** observed event rate modifies the firing threshold. This loop is numerical and unchanged.
2. **Colony-level feedback (new):** observed incoming chunks and queued backlog modify the number of independent neuron instances. This loop is deterministic policy rather than learned weights.
3. **Branch-level load balancing (new):** neighboring workers compare queue lengths and relay a chunk if the difference is large enough.

These loops are deliberately separate. A spike is not a proof of intelligence, and a larger clone population is not a proof of greater wall-clock computing efficiency.

## Minimum falsifiable Stage 2 tests

- Same input, fixed seeds, durable queues: compare against a conventional worker pool and against a single Ripple under real concurrency and identical CPU/memory budgets.
- Induced worker failures: verify no job loss, duplicate side effects, or unbounded resubmission.
- Network cost/latency: measure throughput and control instability under backpressure, propagation delay, or partitions.
- Trace model dynamics independently: quantify `theta`, `u`, `r_hat`, event counts, queue ages, mean completion latency, 95th-percentile latency, CPU seconds, peak RSS and energy where measurement hardware exists.
- Reject the design if the neuron gate adds latency/overhead without an independently verifiable task-level advantage. Preserve negative results.
