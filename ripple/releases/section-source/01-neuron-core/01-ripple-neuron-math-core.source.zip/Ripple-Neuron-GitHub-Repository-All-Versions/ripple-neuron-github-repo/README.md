# Ripple Neuron — open optoelectronic neuron project

**Color carries the input. Feedback regulates the response.**

An archived sequence of Ripple Neuron prototypes based on a color-coded input scheme and a leaky integrate-and-fire neuron with bounded, adaptive threshold feedback.

Concept: Constantin x (2026). Engineering implementation prepared with AI assistance. Original project content is offered as CC0-1.0 (see [License and evidence notes](LICENSE-AND-EVIDENCE.md)); dependencies retain their own terms.

## Version archive

| Version | Status | Files | Scope |
| --- | --- | --- | --- |
| **v0.1** | Numerical model + untested hardware proposal | [Original simulator, PDF and diagram](versions/v0.1/) | RGB-coded inputs, spike events, adaptive threshold |
| **v0.2** | Phone/PWA prototype; physical phone unverified | [Phone lab source + original ZIP](versions/v0.2/) | Camera RGB input, on-phone numerical model |
| **v0.2-chat** | UI variant | [Chat-style tabbed prototype](versions/v0.2-chat/) | In-chat/standalone interactive interface |
| **v0.3** | Observer tests; actual Android hardware unverified | [Observer source + original ZIP](versions/v0.3/) | Offline recording, opt-in online numerical telemetry, Stage 2 plan |

**Historical preservation:** Files in each version directory are archived as received. They are not retroactively rewritten when later versions evolve. This git repository also has annotated tags `v0.1`, `v0.2`, `v0.2-chat`, and `v0.3`.

## Run current Stage 1 observer

```bash
cd versions/v0.3/observer
node tests/check_phone_model.cjs
node tests/check_observer.cjs
python -m unittest discover -s tests -p 'test_*.py' -v
python -m http.server 8000
```

Open `http://localhost:8000` for a local manual-mode smoke test. For Android camera access, host on HTTPS, grant permission, and validate real light input on the actual phone. Online telemetry receiver has a separate deployment process and must never be exposed without TLS and configured authentication. Refer to the v0.3 README.

## Evidence boundaries

- The model produces neuron-like numerical firing events and adjusts its threshold toward a target event rate under tested synthetic inputs.
- Camera input is derived from processed RGB pixels, not electromagnetic E/B field measurement or an AS7341 eight-channel spectral measurement.
- The physical AS7341/Pico proposal and phone camera behavior are not claimed validated by these archive files.
- Multi-neuron learning, intelligent task performance, consciousness and robot control are **not demonstrated** by these releases.
- Optional online signal upload does not link this archive to a live ChatGPT conversation.

## Working with Codex

Use [Codex handoff](versions/v0.3/observer/CODEX_HANDOFF.md). Keep `ripple-core.js` unchanged unless an explicit, versioned, reviewed modification is requested. Test Stage 1 before beginning any Stage 2 branch.

See [archive integrity](SHA256SUMS.txt) and [release history](CHANGELOG.md).
