# License and claims

The original Ripple Neuron documents and source code are presented by the project as **CC0-1.0** for unrestricted reuse of the original contributions. See <https://creativecommons.org/publicdomain/zero/1.0/>.

Third-party libraries, boards, datasheets, service dependencies, trademarks, and other preexisting materials retain their own licenses and terms. CC0 does not provide patent clearance, guarantee novelty, or grant rights to unrelated third-party code.

This repository is an **archive of existing project files and designs**, not evidence of physical assembly. Numerical unit tests and a source-level smoke test are not a substitute for camera or AS7341 bench results. Never label simulated pulse rates as measured hardware performance.

The preservation SHA-256 list covers copied artifacts after this import. Do not change old version files in-place; add new versions or explicitly marked corrections.
