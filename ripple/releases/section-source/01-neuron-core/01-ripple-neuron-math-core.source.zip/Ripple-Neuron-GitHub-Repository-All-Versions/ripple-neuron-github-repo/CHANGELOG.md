# Release history

## v0.1 — Numerical baseline and electronics plan

Original offline simulator; mathematical spiking neuron; feedback demonstration; wiring and calibration design in the seven-page engineering brief. The complete referenced original Python/firmware source package was not available for this archival import.

## v0.2 — Phone Lab

Phone-first web interface, processed camera RGB signal input, offline-capable PWA bundle, synthetic test controls.

## v0.2-chat — Chat tab interface variant

Interactive tabbed interface experiment, preserved separately from the phone PWA.

## v0.3 — Observer Stage 1

Read-only regulation diagnostics, IndexedDB numerical summaries after opt-in, optional authenticated HTTPS telemetry transport, local Python receiver tests, and separate Phase 2 research plan. Stage 2 not implemented.

The git tags represent archival milestones, not independently verified phone hardware releases or external publication dates.
