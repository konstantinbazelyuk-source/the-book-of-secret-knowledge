# Ripple Neuron v0.1 — Original numerical/engineering prototype

Unmodified source artifacts supplied for this archive:

- [HTML simulator](Ripple-Neuron-Simulator.html): interactive synthetic RGB input model and brightness-step comparison.
- [Engineering brief (PDF)](Ripple-Neuron-Engineering-Brief.pdf): equations, bill-of-materials proposal, wiring, calibration plan, and acceptance criteria.
- [Prototype overview image](Ripple-Neuron-Prototype.png): diagram and original numerical findings.

The original engineering brief mentions a separate complete source package containing `simulate.py`, `robustness.py`, firmware, and tests. **That original v0.1 package was not available in the material recovered for this archive**, so it has not been silently recreated or represented as included. The simulator contains runnable JavaScript for the original mathematical model.

**Evidence:** numerical simulation, not optical hardware. Physical Pico/AS7341 board is untested. Original materials: CC0-1.0; see the engineering brief for the scope and third-party dependencies.
