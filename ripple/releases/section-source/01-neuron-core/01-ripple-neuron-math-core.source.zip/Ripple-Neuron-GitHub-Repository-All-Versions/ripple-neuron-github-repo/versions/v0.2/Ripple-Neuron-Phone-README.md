# Ripple Neuron — Phone Lab v0.2

A smartphone-specific adaptation of the **original Ripple Neuron v0.1** model (2026-10-13). Concept: Constantin x. Original materials CC0-1.0.

## What actually works

- Original 3-channel integrate-and-fire and threshold feedback code is embedded unchanged from `Ripple-Neuron-Simulator.html`.
- Manual RGB mode and the original 120-second adaptive-versus-fixed numerical experiment work without internet.
- Camera mode requests permission and reads real average RGB *image pixels* from the center of the phone camera view while the app is open; camera access is subject to Android/browser permissions and must be tested on hardware.
- Quick camera mode normalizes average captured R/G/B 0–255 to 0–1. It is **not** calibrated illumination or independent spectral bands.
- Optional 4-reference calibration (dark, red, green, blue) solves a 3x3 linear system to estimate normalized relative inputs. Ill-conditioning, saturated captures and high residuals are rejected. This is approximate because phone-camera exposure, white balance and nonlinear image processing can change between frames.
- Every accepted sample feeds the mathematical neuron model, which returns events, rate estimate and threshold; CSV export saves *numbers only*, no images or video.
- No ChatGPT/API connection, no autonomous task learning, no robot control, no background sensing.

## Test on an Android phone

### Fast offline test (no deployment)

Download **`Ripple-Neuron-Phone.html`** and open it in a browser. The manual mode, controls, simulation, feedback, and original comparison should work offline. Depending on the browser and local file restrictions, camera mode may not work from a downloaded file. Not all Android file viewers execute scripts; use an actual browser.

### Camera mode / installable phone web app

Upload the *contents* of the `Ripple-Neuron-Phone-PWA` folder to a static site with **HTTPS** (for example GitHub Pages or Netlify). Open the URL in Android Chrome. Choose "Phone camera" → "Start camera" → Allow permission. Point the outlined square at colored light or surfaces. A stable colored light source is better than changing scenery.

You can install the hosted app from the Chrome menu ("Add to Home screen" / "Install app", depending on support). For offline use after installation, load the page while connected once so the service worker can cache it.

The app is not an APK and has **not** been installed or camera-tested on the user's physical Android phone.

## Camera calibration steps

1. Fix phone and light source position, reduce changes in ambient lighting. Use a second screen/LED source that can independently display red, green or blue. **Do not point the camera at hazardous bright light sources or lasers.**
2. Cover the source or make it dark. Capture **Dark**.
3. Show the same source at a single red intensity; capture **Red**.
4. Repeat for green and blue, same brightness setting for each reference.
5. After all four pass quality checks, enable **Use calibrated decoder**.
6. Increase and decrease one channel, watch the measured relative value and event rate, and export a CSV.

The calibration is the phone-camera approximation of the original engineering brief's reference-matrix decoding. The phone's 3 image color channels cannot replace the AS7341's eight wavelength-sensitive measurements. A native Android app with Camera2 capture/AE/AWB locking is a prospective route to better control. Calibration still requires physical validation and must be re-done if illumination or camera processing changes.

## Test behavior

- Manual R=0.35, G=B=0 starts firing near the 1 Hz target after settling (feedback on).
- Run the 120 s experiment: 60–80 s window adaptive=0.95 Hz, fixed=3.40 Hz (original model settings).
- Change brightness and enable/disable adaptive threshold; observe model behavior (not proof of closed-loop hardware stability).
- Camera off/suspended page: no new camera-based model steps.

## Files

- `index.html`: hosted PWA phone UI and model, with no external JavaScript library dependencies.
- `ripple-core.js`: unchanged model body extracted from the supplied v0.1 simulator, for auditing/reuse. `index.html` embeds the same model to enable standalone offline file use.
- `manifest.webmanifest`, `icon.svg`, `sw.js`: installation and offline app shell.
- `tests/check_phone_model.cjs`: numerical and decoder checks (Node.js).

## Safety, privacy and constraints

Camera access is explicitly user-initiated. Camera pixels are processed in memory; no photographs/videos are stored, sent to a server, or sent to OpenAI. CSV logs only normalized RGB values and model outputs. Android/browser permission banners and app installs are platform-dependent. Smartphone cameras measure processed RGB pixel data, **not** instantaneous electric or magnetic fields of light.
