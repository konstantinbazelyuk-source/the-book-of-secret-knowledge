# Ripple Neuron v0.2 — Phone adaptation

- [`phone-pwa/`](phone-pwa/) — preserved original offline-capable PWA project, with camera and RGB input model.
- [`Ripple-Neuron-Phone.html`](Ripple-Neuron-Phone.html) — standalone phone experiment.
- [`Ripple-Neuron-Phone-PWA-original.zip`](Ripple-Neuron-Phone-PWA-original.zip) — unmodified released PWA archive for provenance.
- [`Ripple-Neuron-Phone-README.md`](Ripple-Neuron-Phone-README.md) — original phone instructions.

Local manual mode works with synthetic RGB inputs; camera mode requires permission and typically HTTPS for reliable access. Image pixels are **not** optical field or eight-band AS7341 measurements. No phone-hardware validation is claimed by this archive.
