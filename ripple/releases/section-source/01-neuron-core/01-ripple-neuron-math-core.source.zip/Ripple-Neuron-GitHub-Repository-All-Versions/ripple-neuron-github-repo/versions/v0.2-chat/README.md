# Ripple Neuron v0.2 — Chat-style panel variant

This is the standalone HTML export of the ChatGPT-style tabbed interface experiment. It is a **UI variant of v0.2**, not a replacement of `versions/v0.2/` or a separately validated camera hardware build.

- [Interactive HTML panel](Ripple-Neuron-Chat-Panel.html)

The original in-chat embedded visualization is not a separate on-disk source artifact here. Embedded ChatGPT camera permission may differ from standalone HTTPS access.
