# Ripple Neuron v0.3 — Offline and online signal observer

- [`observer/`](observer/) — read-only Stage 1 observer (PWA, JS model, logging, tests, optional Python receiver).
- [`Ripple-Neuron-Codex-Observer-original.zip`](Ripple-Neuron-Codex-Observer-original.zip) — preserved original Codex handoff archive.

Read [observer/README.md](observer/README.md) and [observer/CODEX_HANDOFF.md](observer/CODEX_HANDOFF.md) first. Stage 2 is only a plan. Online telemetry does **not** mean live access to ChatGPT. No secrets, hosted server, or real Android camera results are included.
