"""Double-click/execute this script from any working directory to serve web/ locally.
HTTPS is required when hosting it on a phone; localhost is safe for desktop browser camera API.
"""
import functools
import http.server
from pathlib import Path
import webbrowser

ROOT = Path(__file__).parent / 'web'
PORT = 8000
handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=str(ROOT))
with http.server.ThreadingHTTPServer(('127.0.0.1', PORT), handler) as server:
    url = f'http://localhost:{PORT}/quaternary.html'
    print('RIPPLE-Q local lab', url)
    print('Keep this window open while testing; Ctrl+C to stop. No external account or AI API required.')
    webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print('Server stopped.')
