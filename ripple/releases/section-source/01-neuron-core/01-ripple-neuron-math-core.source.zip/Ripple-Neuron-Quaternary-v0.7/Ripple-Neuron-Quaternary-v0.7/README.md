# Ripple Neuron v0.7 — Quaternary Sensor & Program Engine

**13 October 2026 · Concept: Constantin x · incremental CC0-1.0 research release**

This release adds a **deterministic four-symbol signal computer** next to the unmodified v0.1 leaky-integrate-and-fire neuron, the v0.5 optical attenuation simulation, and the v0.6 logarithmic photoreceptor. The original `web/ripple-core.js` is byte-for-byte identical to the v0.6 original. This is **not** a claim of autonomous reasoning, consciousness, direct energy-field sensing, or quantum computation.

## Quick start — no Codex required

1. **Desktop, live webcam:** unzip, install Python 3 if it is not already available, double-click `Start-Ripple-Windows.bat` on Windows or run `python serve.py` on other computers. Your normal browser opens `http://localhost:8000/quaternary.html`. Press **Webcam / Samsung camera → Start camera**, allow permission and test real RGB image readings. The page works without OpenAI or an internet connection while served locally.
2. **Samsung Android:** the exact same static `web/` site must be hosted over HTTPS (or packaged in a trusted web app) for camera access. Do **not** expect camera permission to work when the HTML is opened from `content://` or an Android file viewer. Hosting requires no API key; the original Floot URL at the time of release is still v0.5 because the existing account hit a platform build quota and v0.7 is not published there.
3. **Manual demonstration:** open the new tab and choose **Run reproducible demo**. The emitted symbols are synthetic, not measured. Click **Resume live signals** afterward. Select another preset to compile a different safe program, or **Generate from sampled ranges** to select a preset from observed numeric ranges.
4. The original experiment is available in `web/index.html` and remains unmodified except for the visible navigation link to v0.7. Its source code is preserved.

A webcam is an optical sensor but its ordinary browser feed is typically display-referred 8-bit RGB: it is **not** a calibrated spectrometer, EM-field probe, photon counter, device-to-brain interface, or absolute reflectance/atomic-density meter.

## Four-symbol code versus binary

| Ripple state | Binary code | Formal meaning in this system |
|---|---|---|
| `-1` | `00` | Confirmed decreasing signal / negative-going event |
| `-0` | `01` | Held inhibition, e.g. sustained negative neuron drive or suppressed phase |
| `0` | `10` | Stable neutral/rest state |
| `1` | `11` | Confirmed positive-going event |

`-0` is an explicit **symbol** with its own code and behavior, not an assertion that `-0` and `+0` are four distinct ordinary integer values. In floating point JS `Object.is(-0,+0)` can distinguish signed zero, but JSON may lose it. Ripple-Q instead stores explicit symbol codes. **Four possible states are 2 conventional bits per symbol, not 4 bits**; two symbols encode a 4-bit opcode, four symbols can be packed into one 8-bit byte. The mapping is reversible.

A noise-adaptive threshold and 2-sample debounce reduce false transitions while retaining step detection. Default transition threshold is 0.12 in *normalized drive units*, not a physical electric-field intensity. The existing core `D=2R +1.2G -1.4B` is unchanged and all newer code sits outside it.

## What real phone signals can and cannot measure

| Channel | Units / data type | Access | Classification |
|---|---|---|---|
| Local camera | Mean 32×32 ROI RGB (0–1) | Browser camera permission | Actual display-referred pixel observation when camera active |
| Image `edgeDensity` | Mean Sobel luminance gradient (unitless) | Camera feed | **Texture/contrast proxy**; not atomic mass or electromagnetic energy density |
| Image `frameDifference` | Average pixel-luminance absolute change between adjacent frames | Camera feed | **Image-motion proxy**, not object speed in physical units or full optical flow |
| Accelerometer | m/s², may include gravity | Optional `devicemotion` API | Motion measurement if browser emits an actual event |
| Magnetometer | µT for exposed Generic Sensor API | Optional `Magnetometer` | Environmental magnetic field measurement **if available**; not a person’s concentration, mind energy or directly their electrical field |
| Ambient light | lux | Optional `AmbientLightSensor` | Light-level observation **if available**; not a spectrometer |
| Temporal sensor frequency | Hz below Nyquist | 24+ consecutive regular sensor readings | Calculated periodic modulation in sampled values. **Not** the carrier oscillation of optical light (~10^14 Hz) or a human output frequency |
| Browser CPU hints | Logical processor count and approximate memory if exposed | Browser properties | Coarsened browser hints. The exact Samsung Galaxy model, Snapdragon/Exynos SoC, clock, neural accelerator, RAM size and sensor inventory **are not verified** |
| Local CPU test | JS loop iterations/s | Program benchmark | A reproducible browser microtest. Not manufacturer TOPS/GFLOPS or processor specifications |

**Samsung model was not supplied in the conversation.** App includes **Inspect this device**. Browser privacy protections may suppress exact model information; obtain the exact model from **Settings → About phone → Model number** for chip-specific engineering. Sensor capabilities are tested in the running browser rather than guessed from screenshots.

## Optical, quantum and signal mathematics

**Image brightness:** `Y = 0.2126R + 0.7152G + 0.0722B`, where these display-referred RGB values are not necessarily raw linear irradiance. `edgeDensity` uses a normalized 3×3 Sobel gradient on 32×32 luminance samples. `frameDifference = mean(abs(Y_t - Y_(t-1)))`. Movement, compression, camera exposure and white balance confound the latter.

**Light drive:** `D = 2R + 1.2G − 1.4B` remains the same as Ripple v0.1. The quaternary module observes this drive or other physically available channels, quantizes their temporal changes (with a noise-adaptive threshold), and emits a typed stream: `-1, -0, 0, 1`.

**Quantization:** A held reference is updated after a confirmed transition so that a sustained light step can pass the 2-frame debounce. An optional noise estimate grows only during sub-threshold changes. The emitted time series is encoded as explicit two-bit symbols, not actual binary floating-point `-0` values.

**Virtual machine:** Ripple-Q has an intentionally restricted 16-opcode stack machine: `PUSH_R`, `PUSH_G`, `PUSH_B`, `PUSH_DRIVE`, `PUSH_EDGE`, `PUSH_FRAME_DIFF`, `PUSH_ACCEL`, `PUSH_MAG`, `PUSH_LUX`, `PUSH_ZERO`, `ADD`, `SUB`, `MUL`, `CLAMP01`, `QUANTIZE`, `EMIT`. Programs are compiled into opcode pairs (two quaternary symbols each) and executed without dynamic JavaScript evaluation, file write instructions, external network actions, device control or unconstrained loops. Missing genuine sensors raise **unavailable**, not a synthetic zero measurement. The **Generate from sampled ranges** button uses an explicit heuristic to choose among safe presets using actual logged numeric ranges. It does **not** learn a new language or invent code.

**Magnetic modulation:** where an actual magnetometer stream is available, 24–128 regularly timed samples are subjected to a Hann-windowed DFT. We reject irregular timing or unclear spectral peaks. For 10 Hz sampling the Nyquist limit is **5 Hz**; neither optical light carrier frequencies nor 50/60 Hz fields can be reliably measured at that rate. Readings could include Earth’s field, speaker/magnet electronics, nearby devices, movement, etc.

**Quantum foundations, not quantum computing:** An individual photon of wavelength λ has energy `E = hc/λ`. At nominal wavelengths 625, 530 and 460 nm, the per-photon energies are approximately 1.98, 2.34 and 2.70 eV respectively. These are calculated exemplars; three RGB camera channels do not identify exact wavelengths. Discrete photon arrival counts are modeled with a Poisson process (`variance ≈ mean = λ` for the specified ideal counting process) and a Gaussian approximation for higher λ. **This is synthetic shot-noise simulation**, not photon counting on a Samsung image sensor, and is not a quantum processor or measurement of a quantum state.

## Engineering verification

Executed on available computational resources; there is **no claim of access to an HPC/supercomputer**.

- `node --test tests/quaternary.test.mjs`: all 11 regression tests pass, including distinct sign-zero codes, four emitted states, noise rejection, safe ISA, ROI calculations, sensor-unavailable behavior, photon physics, 10 Hz temporal modulation and rule-based compiler.
- `node tests/numerical_study.mjs`: 60 combinations of additive synthetic drive noise, threshold and debounce; **118,800 synthetic steady-state samples** plus controlled step tests. `numerical-study.json` and `noise-grid.csv` are generated reproducibly with a specified RNG seed. They are not physical observations.
- `python tests/browser_smoke.py`: desktop and 390px mobile headless Chromium tests: UI, compiled instructions, all four states, export, simulator, device profile, CPU microtest. The sandbox blocks network navigation; browser smoke runs from an `about:blank` page with equivalent inlined ES modules. Consequently **HTTPS, webcam permission and real Samsung hardware are not browser-tested**.
- `node ../Ripple-Neuron-Photoreceptor-v0.6/tests/check_phone_model.cjs` and its v0.6 photoreceptor regression tests: original numeric responses preserved, including 0.95 Hz adaptive versus 3.40 Hz fixed threshold during the defined brightness step. A copied `web/ripple-core.js` must have the same SHA-256 as v0.6.

From the simulated 60-condition grid, at default 0.12 threshold / 2-sample debounce, no false state-transition samples were observed in the specific tested ranges (0.004–0.300 peak-to-peak drive noise, 1,980 steady samples per case); a sustained +0.35 step took 2 samples to confirm. **This does not guarantee robustness** to color drift, auto-exposure, interference or actual camera noise.

## Recommended physical protocol

1. Fix the computer/phone camera on a stand facing one constant illuminated object; disable auto-exposure/white balance if the camera driver supports it. Avoid varying screen brightness. Run 30 seconds and export JSON.
2. Change only one variable: LED red intensity, an opaque diffuser, or a measured object displacement; preserve all other conditions. Export JSON. Repeat 5 trials for each condition.
3. Compare real camera-drive histograms, ROI edge density, inter-frame differences, q-symbol counts and original neuron rate. Estimate repeatability. If the phone’s magnetometer API is exposed, run it separately while keeping the phone stationary and all magnets, USB cables, and powered speakers at fixed locations.
4. Optional blinded attention/concentration task: randomize trials without showing the operator whether target intensity or animation should change; inspect logs for uncontrolled camera/motion/display changes and compare a null baseline. This cannot be interpreted as proving a human energy field without independent instrumentation and replication.

## Sources consulted

- MDN camera browser API: https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia
- MDN motion events: https://developer.mozilla.org/en-US/docs/Web/API/DeviceMotionEvent
- Chrome Generic Sensors feature detection: https://developer.chrome.com/docs/capabilities/web-apis/generic-sensor
- MDN hardwareConcurrency (browser may underreport): https://developer.mozilla.org/en-US/docs/Web/API/Navigator/hardwareConcurrency
- MDN approximate memory (rounded/privacy protected): https://developer.mozilla.org/en-US/docs/Web/API/Navigator/deviceMemory
- Hamamatsu photon shot noise (Poisson sqrt(N)): https://camera.hamamatsu.com/us/en/learn/camera_glossary/p.html
- W3C sRGB transfer: https://www.w3.org/Graphics/Color/srgb.pdf
- SI exact constants for Planck law: https://physics.nist.gov/cuu/Constants/

This release does not overwrite a live app, turn on surveillance, infer mental states, or export photographs. It exports numerical observations locally; any online networking from earlier versions stays optional and separate.
