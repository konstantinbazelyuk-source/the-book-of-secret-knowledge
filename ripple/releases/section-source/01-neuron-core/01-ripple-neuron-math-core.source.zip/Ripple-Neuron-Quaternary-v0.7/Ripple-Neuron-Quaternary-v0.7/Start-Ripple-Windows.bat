@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel% equ 0 (
  py -3 serve.py
) else (
  where python >nul 2>nul
  if %errorlevel% equ 0 (
    python serve.py
  ) else (
    echo Python 3 is needed to serve this local website securely on localhost.
    echo Open https://www.python.org/downloads/ to get Python 3, then run this again.
    pause
  )
)
