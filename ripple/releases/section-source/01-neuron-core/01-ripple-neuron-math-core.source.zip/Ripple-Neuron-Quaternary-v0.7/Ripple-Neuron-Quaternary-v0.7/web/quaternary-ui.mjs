import {QuadVM,PROGRAMS,drive,deviceProfile,runtimeProbe,pack4,temporalFrequencyHz,proposeProgram} from './quaternary-core.mjs';
import {RippleSensors} from './sensors.mjs';
import {syntheticPhotonStudy,photonEnergy} from './quantum-model.mjs';
const $=id=>document.getElementById(id),fix=(n,d=3)=>Number.isFinite(n)?n.toFixed(d):'—',now=()=>new Date().toISOString();
let source='manual',recent=[],capture=[],packBuffer=[],lastSymbol=null,vm=new QuadVM('Drive events',{threshold:.12,dwell:2}),
  neuron=new globalThis.RippleNeuron(),lastSpike=0, manual=[.35,0,0],frequency=null,autoSampling=true,magTimes=[],magValues=[],lastMagTime=null;
function setStatus(message,warning=false){$('sensorStatus').textContent=message;$('sensorStatus').classList.toggle('warning',warning);}
const sensor=new RippleSensors(function onSample(s){if(source==='camera'||source==='manual')frequency=s.cameraHz;if(Number.isFinite(s.magTimestamp)&&s.magTimestamp!==lastMagTime){lastMagTime=s.magTimestamp;magTimes.push(s.magTimestamp);magValues.push(s.magnetometer);if(magTimes.length>128){magTimes.shift();magValues.shift();}}} ,msg=>{$('cameraStatus').textContent=msg;});
sensor.setManual(manual);
function exportJSON(){
 const payload={format:'Ripple-Q/v0.7',created:now(),units:{camera:'normalized display-referred RGB',edge:'normalized Sobel-gradient proxy',frameDifference:'mean luminance difference between 32x32 frames',acceleration:'m/s²',magnetometer:'µT',lux:'lx'},
  sampleCount:capture.length,program:vm.program,labels:['-1','-0','0','1'],bitCode:['00','01','10','11'],evidence:'Computed symbols from observed or manual inputs; zero sensor unavailable is never substituted with a measured zero.',records:capture};
 const file=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}),u=URL.createObjectURL(file),a=document.createElement('a');a.href=u;a.download='Ripple-Q-Recorded-Signals-v07.json';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);
}
function renderProgram(){
 $('sourceCode').textContent=vm.program.source;$('machineCode').textContent=vm.program.symbols;$('binaryCode').textContent=vm.program.bits;
}
function setupVM(){const old=vm.program.source,settings={threshold:Number($('threshold').value),dwell:Number($('dwell').value)};vm=new QuadVM($('preset').value,settings);recent=[];packBuffer=[];lastSymbol=null;$('symbolLog').textContent='Program compiled. Waiting for data…';renderProgram();$('vmState').textContent='Compiled Ripple-Q program. '+vm.program.ops.length+' instructions.';}
function recordSample(sample){
 try{
  const ev=vm.run(sample);
  lastSymbol=ev;recent.push(ev.code);packBuffer.push(ev.code);
  if(packBuffer.length>=4){$('packedRead').textContent='0x'+pack4(packBuffer.splice(0,4)).toString(16).padStart(2,'0').toUpperCase();}
  if(recent.length>60)recent.shift();
  capture.push({timestamp:now(),evidenceSource:sample.source,rgb:sample.rgb,drive:sample.drive,edgeDensity:sample.edgeDensity??null,frameDifference:sample.frameDifference??null,
   acceleration:sample.acceleration??null,magnetometer:sample.magnetometer??null,lux:sample.lux??null,quaternary:ev.label,bits:ev.bits,
   modelNeuronEstimatedHz:neuron.rate});if(capture.length>30000)capture.shift();
  $('symbolLog').textContent=recent.map(c=>['−1','−0','0','1'][c]).join('  ');
  for(let i=0;i<4;i++)$('symbol'+i).classList.toggle('hot',ev.code===i);
  $('currentSymbol').textContent=['−1','−0','0','1'][ev.code];$('bitRead').textContent=ev.bits;
  $('totalRead').textContent=capture.length;$('noiseRead').textContent=fix(ev.noiseFloor,4);
  $('vmState').textContent='RUNNING · '+vm.program.ops.length+' instructions · latest Δ='+fix(ev.diff)+' · threshold='+fix(ev.threshold);
 }catch(e){$('vmState').textContent='Not computed: '+e.message;}
}
function tick(){
 const s=sensor.snapshot();if(source==='manual')s.rgb=manual,s.drive=drive(manual),s.edgeDensity=null,s.frameDifference=null,s.source='manual';
 $('rgbRead').textContent=s.rgb.map(n=>fix(n,2)).join(' / ');$('driveRead').textContent=fix(s.drive);
 $('edgeRead').textContent=fix(s.edgeDensity,3);$('frameRead').textContent=fix(s.frameDifference,3);$('hzRead').textContent=fix(source==='camera'?frequency:null,1);
 $('accelRead').textContent=fix(s.acceleration,2);$('magRead').textContent=fix(s.magnetometer,2);$('luxRead').textContent=fix(s.lux,1);const fieldFrequency=temporalFrequencyHz(magValues,magTimes);$('magHz').textContent=fieldFrequency.valid?fix(fieldFrequency.hz,2)+' Hz (Nyquist '+fix(fieldFrequency.nyquistHz,1)+' Hz)': '—';
 recordSample(s);
}
$('cameraButton').onclick=()=>{autoSampling=true;source='camera';$('cameraPanel').hidden=false;$('manualPanel').hidden=true;$('cameraButton').classList.add('good');$('manualButton').classList.remove('good');sensor.mode='camera';$('sourceState').textContent='Camera input (not started)';};
$('manualButton').onclick=()=>{autoSampling=true;sensor.stopCamera();source='manual';$('cameraPanel').hidden=true;$('manualPanel').hidden=false;$('manualButton').classList.add('good');$('cameraButton').classList.remove('good');sensor.setManual(manual);$('sourceState').textContent='Manual RGB';};
for(const [id,i] of [['red',0],['green',1],['blue',2]])$(id).oninput=()=>{autoSampling=true;manual[i]=Number($(id).value);$(id+'Out').textContent=fix(manual[i],2);sensor.setManual(manual);};
$('startCamera').onclick=async()=>{
 try{await sensor.startCamera($('cameraFeed'),$('cameraDevices').value);$('sourceState').textContent='Live local camera';const list=await sensor.devices();const old=$('cameraDevices').value;$('cameraDevices').innerHTML='<option value="">Automatic camera</option>';list.forEach(d=>{const op=document.createElement('option');op.value=d.id;op.textContent=d.label;$('cameraDevices').append(op);});$('cameraDevices').value=old||'';}
 catch(e){$('cameraStatus').textContent='Camera unavailable: '+e.message;}
};
$('cameraDevices').onchange=()=>{if(sensor.stream)$('startCamera').click()};
$('stopCamera').onclick=()=>{sensor.stopCamera();$('sourceState').textContent='Camera stopped';};
$('probe').onclick=async()=>{
 const info=await deviceProfile();const cells=[['Model (reported by browser)',info.model],['Platform',info.platform],['CPU logical thread hint',info.logicalProcessorHint??'not exposed'],['Memory hint (GB)',info.approximateDeviceMemoryGB??'not exposed'],['Camera access API',info.cameraAPI?'Detected':'Not detected'],['Motion API',info.motionAPI?'Detected':'Not detected'],['Magnetometer API',info.magnetometerAPI?'Detected (access unverified)':'Not exposed'],['Ambient light API',info.ambientLightAPI?'Detected (access unverified)':'Not exposed'],['Secure context',info.secureContext?'Yes':'No']];
 const parent=$('specs');parent.replaceChildren();for(const [label,value] of cells){const div=document.createElement('div'),b=document.createElement('b');b.textContent=label;div.append(b,document.createTextNode(String(value)));parent.append(div);}
 setStatus('Device capability probe complete. Browser hints are not independently verified manufacturer specifications.');
};
$('benchmark').onclick=()=>{const b=runtimeProbe(100000);setStatus('Observed JavaScript loop: '+fix(b.iterationsPerSecond/1e6,2)+' M iterations/sec in '+fix(b.elapsedMs,1)+' ms; this is not a chipset clock speed or AI TOPS rating.');};
$('motionButton').onclick=async()=>{try{if(sensor.motionFn){sensor.stopMotion();setStatus('Motion sensor stopped.');}else{await sensor.startMotion();autoSampling=true;setStatus('Motion sensor requested. Values appear when emitted by hardware.');}}catch(e){setStatus(e.message,true);}};
$('magButton').onclick=()=>{try{if(sensor.magneticSensor){sensor.stopMagnetometer();setStatus('Magnetometer stopped.');}else{sensor.startMagnetometer();setStatus('Magnetometer started. Readings in microtesla depend on hardware and permission.');}}catch(e){setStatus(e.message,true);}};
$('luxButton').onclick=()=>{try{if(sensor.luxSensor){sensor.stopAmbientLight();setStatus('Ambient sensor stopped.');}else{sensor.startAmbientLight();setStatus('Ambient light sensor started.');}}catch(e){setStatus(e.message,true);}};
$('threshold').oninput=()=>{$('thresholdOut').textContent=fix(Number($('threshold').value));setupVM();};
$('dwell').oninput=()=>{$('dwellOut').textContent=$('dwell').value;setupVM();};
$('preset').onchange=setupVM;
$('reset').onclick=()=>{autoSampling=true;setupVM();capture=[];neuron=new globalThis.RippleNeuron();$('totalRead').textContent='0';$('packedRead').textContent='—';};
$('export').onclick=exportJSON;
$('generate').onclick=()=>{const p=proposeProgram(capture);$('preset').value=p.program;setupVM();$('vmState').textContent='Rule-generated safe program: '+p.program+'. '+p.reason+' No arbitrary code was executed.';};
$('resume').onclick=()=>{autoSampling=true;$('vmState').textContent='Live quaternary sampling resumed.';};
$('runOnce').onclick=()=>{tick();};
$('runDemo').onclick=()=>{
 autoSampling=false;$('preset').value='Drive events';setupVM();capture=[];const stimulus=[.0,.0,.3,.6,.9,.9,.9,.4,.0,-.5,-.5,-.5,-.5,.2,.5,.5,.5];
 const d=stimulus.map((v,i)=>({source:'DETERMINISTIC_DEMO',rgb:[Math.max(0,Math.min(1,v)),0,Math.max(0,-v)/1.4],drive:v,edgeDensity:0,frameDifference:0}));
 d.forEach(x=>recordSample(x));$('vmState').textContent='Verified demo executed '+stimulus.length+' synthetic steps; live capture paused until Resume. No sensor claim.';
};
$('photonTest').onclick=()=>{const lambda=Number($('photonMean').value);if(!Number.isFinite(lambda)||lambda<0||lambda>1000){setStatus('Expected photons must be 0–1000.',true);return;}const r=syntheticPhotonStudy(lambda,5000,9001);$('shotMean').textContent=fix(r.measuredSampleMean,2);$('shotVar').textContent=fix(r.measuredSampleVariance,2);$('shotExpected').textContent=fix(lambda,1);};
let neuronTimer=setInterval(()=>{if(document.hidden)return;if(source==='camera'&&!sensor.stream)return;const s=sensor.snapshot(),x=source==='manual'?manual:s.rgb;
 try{const out=neuron.step(x,.05);lastSpike+=out.count;$('neuronRead').textContent=fix(out.rate,2);}catch{}},50);
let symbolTimer=setInterval(()=>{if(document.hidden)return;if(!autoSampling)return;if(source==='camera'&&!sensor.stream)return;tick();},100);
document.addEventListener('visibilitychange',()=>{if(document.hidden&&sensor.stream){sensor.stopCamera();$('sourceState').textContent='Camera stopped (page hidden)';}});
window.addEventListener('pagehide',()=>{clearInterval(symbolTimer);clearInterval(neuronTimer);sensor.stop();});
setupVM();
$('photonEnergy').textContent='Nominal single-photon energy: red 625 nm '+fix(photonEnergy(625).electronVolts,2)+' eV; green 530 nm '+fix(photonEnergy(530).electronVolts,2)+' eV; blue 460 nm '+fix(photonEnergy(460).electronVolts,2)+' eV. Calculated, not measured.';
