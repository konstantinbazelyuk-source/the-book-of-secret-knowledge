import {frameFeatures,drive} from './quaternary-core.mjs';
export class RippleSensors{
 constructor(onSample=()=>{},onState=()=>{}){this.onSample=onSample;this.onState=onState;this.video=null;this.stream=null;this.timer=null;this.previous=null;this.mode='manual';this.lastCameraTime=null;this.camFrames=0;
  this.current={rgb:[.35,0,0],drive:.7,edgeDensity:0,frameDifference:null,acceleration:null,magnetometer:null,lux:null,source:'manual',cameraHz:null};
  this.motionFn=null;this.motionSamples=0;this.magneticSensor=null;this.luxSensor=null;this.latest={};}
 snapshot(){return {...this.current,hardware:{motionSamples:this.motionSamples,magnetometerActive:!!this.magneticSensor,luxActive:!!this.luxSensor}};}
 setManual(rgb){this.mode='manual';this.current.rgb=rgb.map(v=>Math.max(0,Math.min(1,v)));this.current.drive=drive(this.current.rgb);this.current.source='manual';this.onSample(this.snapshot());}
 async startCamera(video,deviceId=''){
  if(!navigator.mediaDevices?.getUserMedia)throw Error('Camera API unavailable (requires HTTPS or localhost).');
  this.stopCamera();this.mode='camera';this.video=video;
  const constraints=deviceId?{deviceId:{exact:deviceId},width:{ideal:640},height:{ideal:480}}:{facingMode:{ideal:'environment'},width:{ideal:640},height:{ideal:480}};
  const stream=await navigator.mediaDevices.getUserMedia({video:constraints,audio:false});this.stream=stream;
  video.srcObject=stream;await video.play();
  const canvas=document.createElement('canvas');canvas.width=32;canvas.height=32;const ctx=canvas.getContext('2d',{willReadFrequently:true});
  this.lastCameraTime=null;this.previous=null;
  const sample=()=>{
   if(document.hidden)return;
   if(video.readyState<2||video.videoWidth<2)return;
   const now=performance.now(),min=Math.min(video.videoWidth,video.videoHeight),roi=Math.max(16,Math.floor(min*.4));
   ctx.drawImage(video,(video.videoWidth-roi)/2,(video.videoHeight-roi)/2,roi,roi,0,0,32,32);
   const current=frameFeatures(ctx.getImageData(0,0,32,32).data,32,32,this.previous);
   this.previous=current.luminance;
   const hz=this.lastCameraTime?1000/Math.max(1,now-this.lastCameraTime):null;
   this.lastCameraTime=now;this.camFrames++;
   const {luminance,...rest}=current;
   this.current={...this.current,...rest,drive:drive(rest.rgb),source:'camera',cameraHz:hz,frames:this.camFrames};
   this.onSample(this.snapshot());
  };
  this.timer=setInterval(sample,100);sample();
  this.onState('Camera active. RGB pixels, spatial edges and frame changes are computed locally.');
 }
 async devices(){if(!navigator.mediaDevices?.enumerateDevices)return [];const d=await navigator.mediaDevices.enumerateDevices();return d.filter(x=>x.kind==='videoinput').map((d,i)=>({id:d.deviceId,label:d.label||'Camera '+(i+1)}));}
 stopCamera(){if(this.timer)clearInterval(this.timer);this.timer=null;if(this.stream)this.stream.getTracks().forEach(t=>t.stop());this.stream=null;
  if(this.video)this.video.srcObject=null;this.video=null;this.previous=null;this.lastCameraTime=null;
  if(this.mode==='camera'){this.mode='manual';this.current.source='camera stopped';}this.onState('Camera stopped.');}
 async startMotion(){
  if(!('DeviceMotionEvent' in window))throw Error('DeviceMotionEvent not exposed by browser.');
  if(typeof DeviceMotionEvent.requestPermission==='function'){
   const result=await DeviceMotionEvent.requestPermission();if(result!=='granted')throw Error('Device motion permission denied.');
  }
  this.stopMotion();
  this.motionFn=(event)=>{
   const a=event.acceleration || event.accelerationIncludingGravity;
   if(!a||![a.x,a.y,a.z].some(Number.isFinite))return;
   const xyz=[a.x,a.y,a.z].map(v=>Number.isFinite(v)?v:0);
   const acceleration=Math.hypot(...xyz);this.motionSamples++;
   this.current={...this.current,acceleration,accelXYZ:xyz,accelIncludesGravity:!event.acceleration, motionTimestamp:performance.now()};
   this.onSample(this.snapshot());
  };
  window.addEventListener('devicemotion',this.motionFn);this.onState('Listening to motion samples; permission and sampling vary by browser.');
 }
 stopMotion(){if(this.motionFn)window.removeEventListener('devicemotion',this.motionFn);this.motionFn=null;}
 startMagnetometer(){
  if(typeof window.Magnetometer!=='function')throw Error('Magnetometer not exposed. Browser support, permissions and phone hardware vary.');
  this.stopMagnetometer();
  const m=new window.Magnetometer({frequency:10});
  m.addEventListener('reading',()=>{if(![m.x,m.y,m.z].every(Number.isFinite))return;
   this.current={...this.current,magnetometer:Math.hypot(m.x,m.y,m.z),magXYZ:[m.x,m.y,m.z],magTimestamp:performance.now()};this.onSample(this.snapshot());});
  m.addEventListener('error',e=>this.onState('Magnetometer error: '+(e.error?.name||e.type)));
  m.start();this.magneticSensor=m;this.onState('Magnetometer started (µT if exposed). It does not measure a person’s bioelectric energy.');
 }
 stopMagnetometer(){if(this.magneticSensor)try{this.magneticSensor.stop()}catch{}this.magneticSensor=null;}
 startAmbientLight(){
  if(typeof window.AmbientLightSensor!=='function')throw Error('AmbientLightSensor is unavailable in this browser.');
  this.stopAmbientLight();const s=new window.AmbientLightSensor({frequency:2});
  s.addEventListener('reading',()=>{if(Number.isFinite(s.illuminance)){this.current={...this.current,lux:s.illuminance,luxTimestamp:performance.now()};this.onSample(this.snapshot());}});
  s.addEventListener('error',e=>this.onState('Ambient-light error: '+(e.error?.name||e.type)));
  s.start();this.luxSensor=s;this.onState('Ambient light in lux is available through the browser.');
 }
 stopAmbientLight(){if(this.luxSensor)try{this.luxSensor.stop()}catch{}this.luxSensor=null;}
 stop(){this.stopCamera();this.stopMotion();this.stopMagnetometer();this.stopAmbientLight();}
}
