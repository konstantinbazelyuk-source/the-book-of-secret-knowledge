/** Classical numerical approximations to photon shot noise.
 * Photons are quantized, but phone camera RGB cannot count individual photons or
 * directly measure an optical-frequency oscillation (~10^14 Hz).
 */
export function mulberry32(seed=9001){let a=seed>>>0;return()=>{a+=0x6D2B79F5;let t=a;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return ((t^t>>>14)>>>0)/4294967296;};}
export function poisson(lambda,random=Math.random){
 if(!Number.isFinite(lambda)||lambda<0||lambda>1e8)throw Error('Invalid expected photon count');
 if(lambda===0)return 0;
 if(lambda<35){let L=Math.exp(-lambda),p=1,k=0;do{k++;p*=Math.max(Number.EPSILON,random());}while(p>L&&k<10000);return k-1;}
 // Gaussian approximation for large mean photon counts, with sqrt(lambda) shot noise.
 const u=Math.max(1e-12,random()),v=random();return Math.max(0,Math.round(lambda+Math.sqrt(lambda)*Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v)));
}
export function syntheticPhotonStudy(expected=25,samples=5000,seed=9001){
 const rng=mulberry32(seed);let sum=0,sum2=0;
 for(let i=0;i<samples;i++){const n=poisson(expected,rng);sum+=n;sum2+=n*n;}
 return {model:'SYNTHETIC Poisson photon count',samples,expected,measuredSampleMean:sum/samples,measuredSampleVariance:sum2/samples-(sum/samples)**2,
  theoreticalMean:expected,theoreticalVariance:expected,seed,
  caveat:'This simulation is not measured photon flux from a Samsung camera or sensor.'};
}
// Exact SI constants: h=6.62607015e-34 J s, c=299792458 m/s,
// electron charge e=1.602176634e-19 C. Wavelengths for example colors are nominal.
export function photonEnergy(wavelengthNm){
 if(!Number.isFinite(wavelengthNm)||wavelengthNm<=0)throw Error('Positive wavelength required');
 const joules=(6.62607015e-34*299792458)/(wavelengthNm*1e-9);
 return {wavelengthNm,joules,electronVolts:joules/1.602176634e-19,calculated:true,
  note:'Energy of one photon at a user-specified wavelength, not measured from RGB color.'};
}
