import test from 'node:test';import assert from 'node:assert/strict';
import {LABELS,toBits,fromBits,pack4,unpack4,frameFeatures,drive,QuadEncoder,QuadVM,compile,PROGRAMS,deviceProfile} from '../web/quaternary-core.mjs';
import {poisson,mulberry32,syntheticPhotonStudy} from '../web/quantum-model.mjs';

test('four distinct states encode faithfully as two bits',()=>{
 assert.deepEqual(LABELS,['-1','-0','0','1']);
 for(let i=0;i<4;i++)assert.equal(fromBits(toBits(i)),i);
 assert.equal(toBits(1),'01');assert.equal(toBits(2),'10');
 assert.deepEqual(unpack4(pack4([0,1,2,3])),[0,1,2,3]);assert.equal(pack4([0,1,2,3]),27);
 assert.throws(()=>fromBits('4'));
});
test('bounded synthetic steps can reach every four-state symbol',()=>{
 const e=new QuadEncoder({threshold:.10,dwell:2,noiseMult:0});
 const seq=[.7,.7,.3,1.3,1.3,-.3,-.3,-.3,-.3,.4,.4,.4];
 const states=seq.map(d=>e.step({drive:d}).code);
 assert.ok(states.includes(0),'-1 falling');assert.ok(states.includes(1),'-0 inhibited stable');
 assert.ok(states.includes(2),'0 neutral');assert.ok(states.includes(3),'1 rising');
 assert.ok(e.noise>=0);
});
test('steady scene noise does not cause spurious rising/falling states at base threshold',()=>{
 const q=new QuadEncoder({threshold:.08,dwell:2});let pulse=0;
 for(let i=0;i<10000;i++){const x=.7+.015*Math.sin(i*.273);const r=q.step({drive:x});if(r.code===0||r.code===3)pulse++;}
 assert.equal(pulse,0);
});
test('compiled opcode round-trip and finite verified stack execution',()=>{
 const v=new QuadVM('Red minus blue',{threshold:.05,dwell:1});
 assert.equal(v.program.pairs.length,5);assert.equal(v.program.pairs[0].length,2);
 const a=v.run({rgb:[.4,0,.6],drive:0});
 assert.equal(a.label,'-0');
 v.run({rgb:[.9,0,.1],drive:0});const r=v.run({rgb:[.9,0,.1],drive:0});
 assert.ok(['-1','-0','0','1'].includes(r.label));
 assert.equal(v.emitted.length,3);
 assert.throws(()=>compile(['PUSH_R']));assert.throws(()=>compile(['EVAL','EMIT']));
 const missing=new QuadVM('Magnetic field',{dwell:1});assert.throws(()=>missing.run({rgb:[0,0,0]}),/unavailable/);
});
test('image ROI proxies respond to edges and scene-frame differences',()=>{
 const make=(f)=>{const x=new Uint8ClampedArray(32*32*4);for(let y=0;y<32;y++)for(let i=0;i<32;i++){const k=(y*32+i)*4,v=f(i,y);x[k]=x[k+1]=x[k+2]=v;x[k+3]=255;}return x;};
 const blank=frameFeatures(make(()=>100),32,32);
 const edge=frameFeatures(make((x)=>x<16?0:255),32,32,blank.luminance);
 assert.ok(edge.edgeDensity>blank.edgeDensity);
 assert.ok(edge.frameDifference>.4);
 const still=frameFeatures(make((x)=>x<16?0:255),32,32,edge.luminance);
 assert.equal(still.frameDifference,0);
 assert.equal(blank.frameDifference,null);
 assert.throws(()=>frameFeatures(new Uint8Array(100),32,32));
});
test('original RGB drive weights unchanged',()=>{
 assert.equal(drive([.35,0,0]),.7);
 assert.equal(drive([0,0,1]),-1.4);
});
test('device probe avoids inventing a chipset or model',async()=>{
 const profile=await deviceProfile({hardwareConcurrency:8,deviceMemory:4,platform:'Android'}, {isSecureContext:true,DeviceMotionEvent:function(){}});
 assert.equal(profile.model,'not available');assert.equal(profile.logicalProcessorHint,8);
 assert.equal(profile.approximateDeviceMemoryGB,4);assert.equal(profile.cameraAPI,false);
});
test('seeded Poisson simulation mean and variance near lambda (not real camera)',()=>{
 const a=syntheticPhotonStudy(25,50000,9001);assert.ok(Math.abs(a.measuredSampleMean-25)<.45);assert.ok(Math.abs(a.measuredSampleVariance-25)<1.2);
 assert.equal(a.model,'SYNTHETIC Poisson photon count');assert.equal(poisson(0),0);
 assert.throws(()=>poisson(-1));
 const rng=mulberry32(5);const b=Array.from({length:10000},()=>poisson(60,rng));const avg=b.reduce((a,n)=>a+n,0)/b.length;
 assert.ok(Math.abs(avg-60)<1);
});
test('nominal photon energies are physically dimensioned but not sensor measurements',async()=>{
 const {photonEnergy}=await import('../web/quantum-model.mjs');
 assert.ok(Math.abs(photonEnergy(625).electronVolts-1.984)<.01);
 assert.ok(photonEnergy(460).electronVolts>photonEnergy(625).electronVolts);
 assert.throws(()=>photonEnergy(0));
});
test('sampled sensor frequency calculation enforces Nyquist and rejects constant/noisy absent events',async()=>{
 const {temporalFrequencyHz}=await import('../web/quaternary-core.mjs');
 const t=Array.from({length:128},(_,i)=>i*100);const f=1.25;
 const s=t.map(x=>40+3*Math.sin(2*Math.PI*f*x/1000));const r=temporalFrequencyHz(s,t);
 assert.equal(r.valid,true);assert.ok(Math.abs(r.hz-f)<.1);assert.ok(r.nyquistHz===5);
 assert.equal(temporalFrequencyHz(Array.from({length:128},()=>40),t).valid,false);
 const badT=t.slice();badT[50]+=500;assert.equal(temporalFrequencyHz(s,badT).valid,false);
});
test('rule-based compiler proposes a safe program only from actual available ranges',async()=>{
 const {proposeProgram,PROGRAMS}=await import('../web/quaternary-core.mjs');
 const empty=proposeProgram([]);assert.equal(empty.program,'Drive events');assert.equal(empty.computed,false);
 const camera=Array.from({length:20},(_,i)=>({drive:.6,edgeDensity:.02,frameDifference:.1,source:'camera'}));
 const choice=proposeProgram(camera);assert.equal(choice.program,'Pixel change');
 assert.ok(choice.reason.includes('proxy'));
 const withMotion=Array.from({length:24},(_,i)=>({drive:.6,acceleration:i%2?1:2,source:'motion'}));
 assert.equal(proposeProgram(withMotion).program,'Phone acceleration');
 for(const q of [empty,choice,proposeProgram(withMotion)])assert.ok(PROGRAMS[q.program]);
});
