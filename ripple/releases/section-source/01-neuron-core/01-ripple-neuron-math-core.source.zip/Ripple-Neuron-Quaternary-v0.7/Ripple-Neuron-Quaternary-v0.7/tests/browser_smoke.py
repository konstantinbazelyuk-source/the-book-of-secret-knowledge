"""Headless browser smoke test using about:blank + source-inlined ES modules.
Network navigation is blocked in this environment, so this test does NOT test
HTTPS camera permissions, hosted deployment or physical Samsung sensors.
"""
import base64,re
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]/'web'
def data_url(text):return 'data:text/javascript;base64,'+base64.b64encode(text.encode()).decode()
core=data_url((root/'quaternary-core.mjs').read_text())
quantum=data_url((root/'quantum-model.mjs').read_text())
sensors=data_url((root/'sensors.mjs').read_text().replace("'./quaternary-core.mjs'",repr(core)))
ui=(root/'quaternary-ui.mjs').read_text().replace("'./quaternary-core.mjs'",repr(core)).replace("'./sensors.mjs'",repr(sensors)).replace("'./quantum-model.mjs'",repr(quantum))
uiurl=data_url(ui)
html=(root/'quaternary.html').read_text();html=re.sub(r'<script\b[^>]*>\s*</script>','',html)
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for name,viewport in [('desktop',{'width':1280,'height':850}),('phone',{'width':390,'height':844})]:
  page=browser.new_page(viewport=viewport,accept_downloads=True)
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(html,wait_until='load')
  page.add_script_tag(content=(root/'ripple-core.js').read_text())
  page.evaluate('(url)=>import(url)',uiurl)
  page.wait_for_timeout(450)
  assert page.get_by_text('A neuron can signal.').count()==1
  assert page.locator('#machineCode').inner_text().strip()!='—'
  page.locator('#runDemo').click()
  assert page.locator('#totalRead').inner_text()=='17',page.locator('#totalRead').inner_text()
  stream=page.locator('#symbolLog').inner_text()
  print(name,'demo states:',stream)
  assert '−1' in stream and '−0' in stream and '0' in stream and '1' in stream
  page.locator('#photonTest').click()
  assert float(page.locator('#shotMean').inner_text())>0
  page.locator('#probe').click();page.wait_for_timeout(140)
  assert 'Model' in page.locator('#specs').inner_text()
  page.locator('#benchmark').click()
  assert 'JavaScript loop:' in page.locator('#sensorStatus').inner_text()
  page.locator('#preset').select_option('Red minus blue')
  assert 'PUSH_R' in page.locator('#sourceCode').inner_text()
  page.locator('#manualButton').click()
  page.locator('#red').fill('0.75')
  page.locator('#runOnce').click()
  with page.expect_download() as dl:page.locator('#export').click()
  assert dl.value.suggested_filename.endswith('.json')
  assert not errors,errors
  page.screenshot(path=str(root.parent/f'preview-{name}.png'),full_page=True)
  print(name,'PASS: quaternary demo, source compiler, photonic model, CPU probe, export; no runtime errors')
  page.close()
 assert 'href="quaternary.html"' in (root/'index.html').read_text()
 print('Original index additive navigation PASS')
 browser.close()
