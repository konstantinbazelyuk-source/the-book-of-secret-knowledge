import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
import {QuadEncoder} from '../web/quaternary-core.mjs';
import {mulberry32,syntheticPhotonStudy,photonEnergy} from '../web/quantum-model.mjs';
const dir=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const rows=[],seed=20261013;
for(const noisePeakToPeak of [.004,.016,.04,.12,.3])
 for(const threshold of [.04,.08,.12,.2])
  for(const dwell of [1,2,3]){
   const random=mulberry32(seed+Math.round(noisePeakToPeak*100000)+threshold*10000+dwell*13);
   const e=new QuadEncoder({threshold,dwell});let falseEvents=0;
   for(let t=0;t<2000;t++){
    const x=.7+(random()-.5)*noisePeakToPeak;
    const r=e.step({drive:x});if(t>=20&&(r.code===0||r.code===3))falseEvents++;
   }
   // Reset to establish a quiet baseline, then apply a persistent step.
   e.reset();for(let t=0;t<30;t++)e.step({drive:.7});
   let latencySteps=null;for(let k=0;k<20;k++){
     const r=e.step({drive:1.05});if(r.code===3){latencySteps=k+1;break;}
   }
   rows.push({noisePeakToPeak,threshold,dwell,noiseFloorFalseStateSamples:falseEvents,totalQuietSamples:1980,
    stepInputDelta:.35,detected:latencySteps!==null,latencySamples:latencySteps,
    method:'deterministic bounded synthetic values',sampleHzAssumed:10});
  }
const photon=syntheticPhotonStudy(25,10000,20261013);
const report={project:'Ripple-Q four-symbol signal engine v0.7',evidence:'SYNTHETIC ONLY',date:'2026-10-13',
 oscillator:'No physical camera or magnetic sensor sampled; simple threshold response under synthetic input.',
 dimensions:{conditions:rows.length,quietSamplesPerCase:1980,totalQuietSamples:rows.length*1980},
 photon,nominalPhotonEnergy:[625,530,460].map(photonEnergy),rows};
fs.writeFileSync(path.join(dir,'numerical-study.json'),JSON.stringify(report,null,2));
fs.writeFileSync(path.join(dir,'noise-grid.csv'),[Object.keys(rows[0]).join(','),...rows.map(r=>Object.values(r).join(','))].join('\n')+'\n');
for(const t of [.04,.08,.12,.2]){
 const s=rows.filter(r=>r.threshold===t&&r.dwell===2);
 console.log('threshold',t,'dwell 2:',s.map(r=>`${r.noisePeakToPeak.toFixed(3)}:${r.noiseFloorFalseStateSamples}`).join(' | '),'step latency',s[0].latencySamples,'samples');
}
console.log(JSON.stringify({conditions:rows.length,quietSamples:rows.length*1980,shots:photon.samples,shotMean:photon.measuredSampleMean,shotVariance:photon.measuredSampleVariance},null,2));
