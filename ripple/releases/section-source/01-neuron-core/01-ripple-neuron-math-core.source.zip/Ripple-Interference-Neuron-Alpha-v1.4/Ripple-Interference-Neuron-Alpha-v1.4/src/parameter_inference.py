"""Holdout maximum likelihood slit-separation inference from synthetic photon hits.
Not an optical measurement or new physical equation.
"""
from pathlib import Path
import json,sys
import numpy as np
sys.path.insert(0,str(Path(__file__).parent))
from physics import Setup,profile,count_photons
ROOT=Path(__file__).resolve().parents[1]
xs=np.linspace(-.015,.015,81)
rng=np.random.default_rng(1807)
d_grid=np.linspace(.18e-3,.42e-3,481) # 0.5 um spacing
# Precompute log of normalized p for all models, maintaining detector response and finite slit width.
models=np.array([profile(xs,Setup(separation_m=float(d))) for d in d_grid]);models=models/np.sum(models,axis=1,keepdims=True)
logp=np.log(np.maximum(models,1e-300))
true_d=.3e-3
true=profile(xs,Setup(separation_m=true_d))
rows=[]
for N in (250,2500,25000):
  for rep in range(40):
    counts=count_photons(true,N,rng)
    # Multinomial log-likelihood up to d-independent factorial terms.
    likelihood=logp@counts
    idx=int(np.argmax(likelihood));d=float(d_grid[idx])
    rows.append(dict(N=N,trial=rep,d_est_m=d,abs_error_um=abs(d-true_d)*1e6,correct_to_2um=abs(d-true_d)<=2e-6,detected_total=int(counts.sum())))
# negative control: incoherent V=0 has no d dependence, hence cannot estimate d from these observations.
incoherent=profile(xs,Setup(visibility=0))
models_zero=np.array([profile(xs,Setup(separation_m=float(d),visibility=0)) for d in d_grid]);models_zero/=models_zero.sum(axis=1,keepdims=True)
flat_likelihood=float(np.max(np.abs(models_zero-models_zero[0])))
assert flat_likelihood==0.0
record={"model":"conditional multinomial likelihood with externally known wavelength, screen geometry, slit width, coherence=1, fixed photon totals","nuisance":"Unknown V, unknown wavelength, phase drift, occlusion, dark counts and PSF are NOT estimated","true_separation_m":true_d,"candidate_grid_step_m":float(d_grid[1]-d_grid[0]),"incoherent_d_identifiability_probability_difference":flat_likelihood,"cases":rows}
record['summary']=[dict(n=n,MAE_um=float(np.mean([r['abs_error_um'] for r in rows if r['N']==n])),p_within_2um=float(np.mean([r['correct_to_2um'] for r in rows if r['N']==n]))) for n in (250,2500,25000)]
(ROOT/'data'/'slit_inference.json').write_text(json.dumps(record,indent=2));print(json.dumps(record['summary'],indent=2))
