'use strict';
// Locked ORIGINAL RippleNeuron is imported, never modified.
const {RippleNeuron}=require('../reference/ripple_core_reference_LOCKED.js');
const fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');
const input=JSON.parse(fs.readFileSync(path.join(root,'data/optics_trials.json')));
const log=(x)=>Math.log(Math.max(x,0)+.03);
const clamp=(v,a,b)=>Math.min(b,Math.max(a,v));
const mode=process.argv.includes('--adaptive')?'adaptive':'fixed';
const threshold=.34,steps=4,dt=.2;
function advance(node,value){
  let n=0;
  for(let i=0;i<steps;i++)n+=node.step([clamp(value,0,1),0,0],dt).count;
  return n;
}
function predict(seq, adaptive=false, photonScale=150){
 const base=new RippleNeuron({theta:.45,adaptive,target:1});
 const on=new RippleNeuron({theta:.45,adaptive,target:1});
 const off=new RippleNeuron({theta:.45,adaptive,target:1});
 const guardedOn=new RippleNeuron({theta:.45,adaptive,target:1});
 const guardedOff=new RippleNeuron({theta:.45,adaptive,target:1});
 const out=[]; let prev=null,prevCnt=null;
 for(const s of seq){
   let lr=prev===null?0:log(s)-log(prev);
   let intensity=advance(base,s);
   // Calibrated count-error approximation: Poisson variance lambda, delta method for log(count).
   // This is not a rigorous exact confidence interval; only an explicit noise model.
   const noiseSigma = prev===null?Infinity:Math.sqrt(
     (photonScale*s+2)/(photonScale*photonScale*(s+.03)**2)
     +(photonScale*prev+2)/(photonScale*photonScale*(prev+.03)**2));
   const significant = Math.abs(lr)>Math.max(threshold,2.0*noiseSigma);
   const gon=advance(guardedOn,significant&&lr>0?1:0);
   const goff=advance(guardedOff,significant&&lr<0?1:0);
   // Two opponent **copies** of locked LIF: no negative/complex inputs to original neuron.
   let inc=advance(on,4*Math.max(0,lr));
   let dec=advance(off,4*Math.max(0,-lr));
   let vote=inc>dec?1:dec>inc?-1:0;
   let directVote=prevCnt===null?0:intensity>prevCnt?1:intensity<prevCnt?-1:0;
   out.push({base:intensity,on:inc,off:dec,guardedOn:gon,guardedOff:goff,guardedVote:gon>goff?1:goff>gon?-1:0,opponentVote:vote,scalarDeltaVote:directVote,observedDiff:lr,noiseSigma,significant});
   prev=s;prevCnt=intensity;
 }
 return out;
}
function quality(ideal,observed,adaptive=false,photonScale=150){
 const p=predict(observed,adaptive,photonScale); let trueEdge=0;
 const q={total:0,changed:0,scalarMatches:0,dualMatches:0,guardedMatches:0,arithmeticMatches:0,guardArithmeticMatches:0,scalarEdgeMatches:0,dualEdgeMatches:0,guardedEdgeMatches:0,arithmeticEdgeMatches:0,guardArithmeticEdgeMatches:0,scalarFalseAlarm:0,dualFalseAlarm:0,guardedFalseAlarm:0,arithmeticFalseAlarm:0,guardArithmeticFalseAlarm:0,brightMatches:0,brightArithmetic:0,directSpikeTotal:0,onSpikeTotal:0,offSpikeTotal:0};
 for(let i=1;i<ideal.length;i++){
    const oracleDiff=log(ideal[i])-log(ideal[i-1]);
    const truth=oracleDiff>threshold?1:oracleDiff<-threshold?-1:0;
    const arithmeticVote=p[i].observedDiff>threshold?1:p[i].observedDiff<-threshold?-1:0;
    const gateVote=p[i].significant?(p[i].observedDiff>0?1:-1):0;
    const bright=ideal[i]>=.55;
    q.total++;
    q.scalarMatches+=+(p[i].scalarDeltaVote===truth);
    q.dualMatches+=+(p[i].opponentVote===truth);q.guardedMatches+=+(p[i].guardedVote===truth);
    q.arithmeticMatches+=+(arithmeticVote===truth);q.guardArithmeticMatches+=+(gateVote===truth);
    q.brightMatches+=+((p[i].base>=2)===bright);
    q.brightArithmetic+=+((observed[i]>=.55)===bright);
    q.directSpikeTotal+=p[i].base;
    q.onSpikeTotal+=p[i].on;
    q.offSpikeTotal+=p[i].off;
    if(truth){q.changed++;q.scalarEdgeMatches+=+(p[i].scalarDeltaVote===truth);q.dualEdgeMatches+=+(p[i].opponentVote===truth);q.guardedEdgeMatches+=+(p[i].guardedVote===truth);q.arithmeticEdgeMatches+=+(arithmeticVote===truth);q.guardArithmeticEdgeMatches+=+(gateVote===truth)}
    else{q.scalarFalseAlarm+=+(p[i].scalarDeltaVote!==0);q.dualFalseAlarm+=+(p[i].opponentVote!==0);q.guardedFalseAlarm+=+(p[i].guardedVote!==0);q.arithmeticFalseAlarm+=+(arithmeticVote!==0);q.guardArithmeticFalseAlarm+=+(gateVote!==0)}
 }
 return q;
}
const trials=[];
for(const s of input.scenarios)trials.push({id:s.id,visibility:s.visibility,photon_scale:s.photon_scale,...quality(s.ideal,s.observed,mode==='adaptive',s.photon_scale)});
const keys=Object.keys(trials[0]).filter(x=>!['id','visibility','photon_scale'].includes(x));
function sum(a){const o={};for(const k of keys)o[k]=a.reduce((x,r)=>x+r[k],0);return o}
function fmt(a){let t=sum(a);return {scenarios:a.length,bins:t.total,truth_changes:t.changed, overall_accuracy:{scalar:t.scalarMatches/t.total,dual:t.dualMatches/t.total,guarded:t.guardedMatches/t.total,arithmetic:t.arithmeticMatches/t.total,guard_arithmetic:t.guardArithmeticMatches/t.total},directional_change_recall:{scalar:t.changed?t.scalarEdgeMatches/t.changed:null,dual:t.changed?t.dualEdgeMatches/t.changed:null,guarded:t.changed?t.guardedEdgeMatches/t.changed:null,arithmetic:t.changed?t.arithmeticEdgeMatches/t.changed:null,guard_arithmetic:t.changed?t.guardArithmeticEdgeMatches/t.changed:null},quiet_false_alarm_rate:{scalar:t.scalarFalseAlarm/(t.total-t.changed||1),dual:t.dualFalseAlarm/(t.total-t.changed||1),guarded:t.guardedFalseAlarm/(t.total-t.changed||1),arithmetic:t.arithmeticFalseAlarm/(t.total-t.changed||1),guard_arithmetic:t.guardArithmeticFalseAlarm/(t.total-t.changed||1)},bright_classification_accuracy:{one_lif:t.brightMatches/t.total,arithmetic:t.brightArithmetic/t.total},spikes:{scalar:t.directSpikeTotal,on:t.onSpikeTotal,off:t.offSpikeTotal}}}
const o={schema:'ripple-neural-study/1',original_sha256:'d75d4208e92f19623b127615bd52b4002e85d2c0a59b76471764b55a24294210',mode, settings:{contrast_threshold:threshold,photons_simulated:true,model_dt:dt,steps_per_pixel:steps,contrast_drive_gain:4,noise_gate_sigma:2.0, dark_counts:2,bright_label_threshold:.55,bright_readout_spikes_at_least:2},all:fmt(trials),by_visibility:[...new Set(trials.map(x=>x.visibility))].map(v=>({visibility:v,...fmt(trials.filter(x=>x.visibility===v))})),by_photon_scale:[...new Set(trials.map(x=>x.photon_scale))].map(v=>({photon_scale:v,...fmt(trials.filter(x=>x.photon_scale===v))})),trials};
fs.writeFileSync(path.join(root,'data','neuron_trials_'+mode+'.json'),JSON.stringify(o,null,2));
console.log(JSON.stringify({mode,all:o.all,by_visibility:o.by_visibility.map(x=>({visibility:x.visibility,changeRecall:x.directional_change_recall,alarms:x.quiet_false_alarm_rate}))},null,2));
