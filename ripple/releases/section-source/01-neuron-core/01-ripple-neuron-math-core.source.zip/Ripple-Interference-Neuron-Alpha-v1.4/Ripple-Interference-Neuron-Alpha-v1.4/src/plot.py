from pathlib import Path
import json,sys
import numpy as np
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/'data/optics_trials.json').read_text())
X=np.array(D['x_m'])*1000
fig,ax=plt.subplots(figsize=(10,4.4))
ax.plot(X,D['coherent'],label='Coherent: interference × slit envelope',lw=1.6)
ax.plot(X,D['incoherent'],label='Incoherent: no interference',lw=1.5)
ax.set(xlabel='Screen position (mm)',ylabel='Relative intensity',title='Calculated two-slit patterns · 532 nm, d=0.30 mm, a=0.05 mm, L=1.8 m')
ax.legend();ax.grid(alpha=.2);fig.tight_layout();fig.savefig(ROOT/'charts/wave_theory.png',dpi=140);plt.close(fig)
ph=D['photon_trials'];fig,ax=plt.subplots(figsize=(8,4));ax.errorbar([x['n'] for x in ph],[x['mean_total_variation'] for x in ph],yerr=[x['sd_total_variation'] for x in ph],marker='o');ax.set_xscale('log');ax.set(xlabel='Simulated photon detections (fixed total)',ylabel='Total variation distance',title='Statistical convergence to the known double-slit probability pattern');ax.grid(alpha=.2);fig.tight_layout();fig.savefig(ROOT/'charts/photon_convergence.png',dpi=150);plt.close(fig)
N=json.loads((ROOT/'data/neuron_trials_fixed.json').read_text());d=N['all'];names=['single LIF','ON/OFF LIF','Noise-gated ON/OFF','Arithmetic threshold','Arithmetic noise gate'];keys=['scalar','dual','guarded','arithmetic','guard_arithmetic'];a=[d['directional_change_recall'][k] for k in keys];b=[d['quiet_false_alarm_rate'][k] for k in keys];z=np.arange(len(keys));width=.38
fig,ax=plt.subplots(figsize=(10,4.6));ax.bar(z-width/2,a,width,label='Recall of true change sign');ax.bar(z+width/2,b,width,label='False alarms on quiet steps');ax.set(ylim=(0,1),ylabel='Fraction',title='Simulated neuron coding: detection–false alarm trade-off');ax.set_xticks(z,names,rotation=13,ha='right');ax.legend();fig.tight_layout();fig.savefig(ROOT/'charts/neuron_tradeoff.png',dpi=150);plt.close(fig)
print('Created charts')
