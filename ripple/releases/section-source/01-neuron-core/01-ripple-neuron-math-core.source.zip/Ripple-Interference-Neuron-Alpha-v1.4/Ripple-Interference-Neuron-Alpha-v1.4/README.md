# Ripple Interference–Neuron Alpha v1.4

**Separate executable mathematical research branch. Original Ripple unchanged.**

## Open it
Open `Ripple-Interference-Neuron-Alpha-v1.4.html` in a normal browser to examine calculated two-slit diffraction, adjust wavelength, slit geometry, visibility and phase, and draw synthetic photon events. The page is self-contained and does **not** use remote services or real sensors.

## Rebuild and verify (Python 3, NumPy, Matplotlib; Node.js 18+)

```sh
python src/make_data.py
python src/parameter_inference.py
node src/neuron_compare.js
node src/neuron_compare.js --adaptive
python src/plot.py
python src/build_lab.py
python -m unittest discover -s tests -p test_physics.py -v
node tests/test_neuron.js
python tests/browser_smoke.py
```

The browser test requires Playwright and an installed Chromium. This environment forbids direct `file://` navigation in Chromium; the test uses an `about:blank` document populated from the standalone HTML, executing the same embedded script, and checks errors and overflow. That test does not validate OS-level opening of the saved file or any webcam permissions.

## Scientific contributions / technical claims
- Implemented two separate mathematically grounded optical models: wave-field interference and individual photon-position probability samples; verified coherent phasor equivalence and photon statistical convergence.
- Retained and used the original Ripple LIF class with exactly the same SHA-256 `d75d4208e92f19623b127615bd52b4002e85d2c0a59b76471764b55a24294210`.
- Studied two positive-drive original-neuron copies for ON/OFF contrast, plus a Poisson-noise-aware gate; characterized false positives, recall and the low-photon failure boundary.
- Reported an ordinary arithmetic baseline: **the gated spiking version has no classification advantage** in these scenes. This does not demonstrate new intelligence.
- Performed conditional maximum-likelihood inference of a known-pattern slit separation on synthetic photon hits; **incoherent light cannot identify slit separation under the specified model**.

## Explicit boundary
Waveforms are mathematical fields, photons are simulated discrete detections, and LIF firing consists of numeric events. The optics program is not a measured electromagnetic field probe or quantum computer. The ON/OFF processing is not a biological neuron-development experiment. Real optical testing has not been done and this branch is not installed into any other Ripple project.

See `docs/FORMULAS_AND_VERIFICATION.md`, `docs/ALPHA_REQUIREMENTS.md`, `docs/NEGATIVE_RESULTS.md` and recorded `data/` for full assumptions and failures. Formulas are based on published OpenStax wave optics, EPFL integrate-and-fire research, and retinal ON/OFF signal-processing literature; source URLs are in the formula report.
