# Negative results and revisions

1. **Wrong physics:** Adding independent slit intensities cannot reproduce phase-coherent double-slit fringes. Correct law is `|A1+A2|²`, not `|A1|²+|A2|²`, unless coherence is absent.
2. **Incoherence destroys d identifiability:** For V=0, under fixed slit width and geometry, `p(x|d)` does not depend on d. The likelihood surface is flat. Refuse to report a unique d.
3. **Unfiltered ON/OFF:** 85.2% change-sign recall but 71.7% false alarm rate on no-change frames. Not reliable under noisy observations.
4. **Noise gate loses faint events:** 2σ conditional gate reduced false alarms to 2.88% but change recall to 46.2% overall. At the lowest simulated photon scale (18) it recovered no true changes.
5. **No neural advantage beyond filter:** The ON/OFF gated LIF and same pure-arithmetic gate yielded *identical* classifications. Therefore do not claim that LIF gained intelligence or improved detection accuracy.
6. **Static luminance vs changes:** ON/OFF contrast pathways encode changes, not absolute brightness; a separate direct-intensity readout is required for a sustained-light observable.
7. **Original feedback not universally better:** Adaptive vs fixed threshold changes response; in this sweep it did not establish a superior change detector.
8. **No physical E/B measurement:** Hypothetical plane-wave field magnitudes can be inferred only from known irradiance under restrictive assumptions, not from arbitrary relative RGB values.
9. **UI defect:** Initial label `phoval` didn't match JavaScript's `photonsval`; detected by actual Chromium browser and corrected.
10. **Evaluation coverage gap:** With V=.5 and V=0, the selected 0.34 clean-log threshold generated no positive direction labels. Their recall is undefined; a wider evaluation is mandatory.

No failed candidate was silently removed from comparisons. Keep these as rejection/revisit criteria for future versions.
