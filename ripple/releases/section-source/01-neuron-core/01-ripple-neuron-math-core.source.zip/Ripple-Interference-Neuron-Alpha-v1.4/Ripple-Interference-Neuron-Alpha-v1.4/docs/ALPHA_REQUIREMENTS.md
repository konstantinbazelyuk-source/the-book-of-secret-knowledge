# Ripple optical-neuron Alpha v1.4 requirements and acceptance

| ID | Requirement | Evidence / gate |
|---|---|---|
| PHY-01 | Preserve physical units and explicit geometry | `physics.py` meters, `test_physics.py` reference geometry |
| PHY-02 | Coherent wave intensity equals squared field-superposition amplitude | Absolute numeric discrepancy <1e-13, executed |
| PHY-03 | Coherence loss eliminates fringe, not slit envelope | `visibility=0` analytic and unit test |
| PHY-04 | Slit extrema and exact point-slit fringe positions | Geometry unit tests, not measured |
| PHY-05 | Irradiance-derived E and B labeled conditional | `field_amplitudes_from_irradiance`, rejection of negative irradiance |
| PHY-06 | No false inference of d under V=0 | Flat-likelihood test, return non-identifiable |
| PHO-01 | Photon sample totals preserved | Multinomial generator count-sum tests |
| PHO-02 | Photon statistics converge without fabricating detector measurements | 24 repeated trials at four photon budgets |
| NEU-01 | Original JS core byte-identical and runnable | SHA-256 assertion `d75d...`; Node test |
| NEU-02 | Signed changes represented by separate positive-drive ON and OFF LIF cores | `src/neuron_compare.js` |
| NEU-03 | False alarm and missed detection scored on unseen synthetic observations | 72 seeded scenes and independent truth stored |
| NEU-04 | Adaptive original threshold compared, not automatically adopted | `node src/neuron_compare.js --adaptive` |
| NEU-05 | Conventional arithmetic comparator evaluated with exactly the same input gate | Identical gated accuracy disclosed |
| LAB-01 | Offline UI interactive independent of cloud | Standalone HTML; no external scripts |
| LAB-02 | Browser script and narrow viewport behavior checked | Chromium rendered from inlined HTML, actual URL navigation blocked |
| LAB-03 | All outputs reproducible and source preserved | Rebuild scripts, logs, release manifest |
| RELEASE | No hardware/cloud/model mutation without explicit deployment request | All artifacts stored in isolated Alpha directory |

## Before physical use
Require actual narrowband coherent source (laser safety evaluated separately); manufactured known apertures; measured wavelength/distance/slit geometry; detector with characterized spectral response, dark counts, linear range, quantum efficiency, integration timing; repeated independent observations and uncertainty budget; tests of phase drift and coherence; device safety and valid experimental procedures. No physical setup or data are claimed here.

## Before an adaptive neurological-model claim
A genuine neuroscience study would require biological recordings or a validated biophysical model and reference datasets, distinct pathways with experimentally constrained dynamics, separate model-identification/validation samples, and comparison with standard retina/LIF baselines. This Alpha only implements a software-coding analogy inspired by retinal ON/OFF segregation.
