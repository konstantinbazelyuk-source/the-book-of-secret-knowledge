import unittest,sys,json,math
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from physics import *
class OpticalLaws(unittest.TestCase):
    def setUp(self):self.s=Setup();self.x=np.linspace(-.012,.012,1001)
    def test_coherent_phasor_equivalence(self):
        self.assertLess(np.max(abs(profile(self.x,self.s)-field_superposition(self.x,self.s))),1e-13)
    def test_double_slit_bright_center_and_null(self):
        self.assertAlmostEqual(float(profile([0],self.s)[0]),1,places=13)
        y=self.s.distance_m*np.tan(np.arcsin(.5*self.s.wavelength_m/self.s.separation_m))
        self.assertLess(float(profile([y],self.s,finite=False)[0]),1e-12)
    def test_peak_location_geometry(self):
        for m in range(-4,5):
            y=self.s.distance_m*np.tan(np.arcsin(m*self.s.wavelength_m/self.s.separation_m))
            self.assertAlmostEqual(float(profile([y],self.s,finite=False)[0]),1,places=12)
    def test_visibility_zero_eliminates_fringe(self):
        s=Setup(visibility=0)
        self.assertTrue(np.allclose(profile(self.x,s),naive_intensity_sum(self.x,s)))
        self.assertTrue(np.allclose(profile(self.x,s,False),.5))
    def test_partial_coherence_bounds(self):
        for v in [0,.25,.5,.75,1]:
            p=profile(self.x,Setup(visibility=v));self.assertTrue(np.all(p>=-1e-14))
            self.assertAlmostEqual(float(profile([0],Setup(visibility=v))[0]),(1+v)/2,places=12)
    def test_slit_envelope_zero(self):
        y=self.s.distance_m*np.tan(np.arcsin(self.s.wavelength_m/self.s.width_m))
        self.assertLess(float(profile([y],self.s)[0]),1e-12)
    def test_wave_amplitude_not_incoherent_intensity_sum(self):
        self.assertGreater(abs(float(profile([0],self.s)[0])-float(naive_intensity_sum([0],self.s)[0])),.49)
    def test_intensity_field_relation_conditional(self):
        r=field_amplitudes_from_irradiance(100)
        self.assertAlmostEqual(.5*C*EPS0*r['e_peak_v_m']**2,100,places=11)
        self.assertAlmostEqual(r['b_peak_t']*C,r['e_peak_v_m'],places=11)
    def test_photon_counts_fixed_total(self):
        rng=np.random.default_rng(6)
        counts=count_photons(profile(self.x,self.s),3000,rng)
        self.assertEqual(sum(counts),3000);self.assertTrue((counts>=0).all())
    def test_photon_convergence_saved_study(self):
        d=json.loads((ROOT/'data'/'optics_trials.json').read_text())
        errs=[x['mean_total_variation'] for x in d['photon_trials']]
        self.assertTrue(all(errs[i]>errs[i+1] for i in range(len(errs)-1)))
    def test_incoherent_unidentifiable_d(self):
        xs=np.linspace(-.01,.01,101)
        a=profile(xs,Setup(visibility=0,separation_m=.2e-3))
        b=profile(xs,Setup(visibility=0,separation_m=.4e-3))
        self.assertTrue(np.array_equal(a,b))
    def test_dispersion_multi_color_spacing(self):
        sblue=Setup(wavelength_m=450e-9)
        sred=Setup(wavelength_m=650e-9)
        self.assertAlmostEqual((sred.wavelength_m*sred.distance_m/sred.separation_m)/(sblue.wavelength_m*sblue.distance_m/sblue.separation_m),650/450)
        mix=(profile(self.x,sblue)+profile(self.x,sred))*.5
        self.assertTrue(np.all((mix>=0)&(mix<=1)))
    def test_false_claim_rejected_excess_visibility(self):
        for v in [-.01,1.01]:
            with self.assertRaises(ValueError):profile(self.x,Setup(visibility=v))
    def test_bad_photocount_inputs(self):
        with self.assertRaises(ValueError):count_photons([0,0],10,np.random.default_rng(1))
        with self.assertRaises(ValueError):field_amplitudes_from_irradiance(-1)
    def test_saved_physics_unit_and_checksums(self):
        d=json.loads((ROOT/'data'/'optics_trials.json').read_text());self.assertEqual(len(d['scenarios']),72)
        self.assertLess(d['analytic']['wave_phasor_max_abs_error'],1e-13)
        self.assertEqual(d['units']['wavelength'],'meters')
if __name__=='__main__':unittest.main(verbosity=2)
