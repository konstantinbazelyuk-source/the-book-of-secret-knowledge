'use strict';
const assert=require('node:assert/strict'),crypto=require('node:crypto'),fs=require('node:fs'),path=require('node:path');
const ROOT=path.resolve(__dirname,'..');
const locked=fs.readFileSync(path.join(ROOT,'reference/ripple_core_reference_LOCKED.js'));
assert.equal(crypto.createHash('sha256').update(locked).digest('hex'),'d75d4208e92f19623b127615bd52b4002e85d2c0a59b76471764b55a24294210');
const {RippleNeuron}=require('../reference/ripple_core_reference_LOCKED');
let a=new RippleNeuron({adaptive:false}), count=0;
for(let t=0;t<60;t++)count+=a.step([.65,0,0],.05).count;
assert(count>0);assert(a.theta===.45);assert.throws(()=>a.step([1,0,0],0));
const fixed=JSON.parse(fs.readFileSync(path.join(ROOT,'data/neuron_trials_fixed.json')));
const adapted=JSON.parse(fs.readFileSync(path.join(ROOT,'data/neuron_trials_adaptive.json')));
for(const x of [fixed,adapted]){
 assert.equal(x.all.scenarios,72);assert.equal(x.all.bins,8640);
 assert.equal(x.all.truth_changes,1170);
 for(const k of ['scalar','dual','guarded','arithmetic']){
   assert(x.all.overall_accuracy[k]>=0&&x.all.overall_accuracy[k]<=1);
   assert(x.all.quiet_false_alarm_rate[k]>=0&&x.all.quiet_false_alarm_rate[k]<=1);
 }
 assert(x.all.quiet_false_alarm_rate.guarded < x.all.quiet_false_alarm_rate.dual);
 assert(x.all.directional_change_recall.dual > x.all.directional_change_recall.scalar);
 assert(x.by_visibility.find(y=>y.visibility===0).directional_change_recall.dual===null);
}
console.log('PASS: locked source, active original neuron, 2 modes, all simulation records, opponent/gated constraints, no-edge null metrics');
