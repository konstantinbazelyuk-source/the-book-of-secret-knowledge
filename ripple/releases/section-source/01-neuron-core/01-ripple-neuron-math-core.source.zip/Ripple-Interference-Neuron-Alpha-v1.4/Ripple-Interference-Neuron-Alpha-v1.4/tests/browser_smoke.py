from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
html=(ROOT/'Ripple-Interference-Neuron-Alpha-v1.4.html').read_text()
with sync_playwright() as p:
  browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  for name,width,height in [('desktop',1280,900),('mobile',390,844)]:
    page=browser.new_page(viewport={'width':width,'height':height},device_scale_factor=1)
    errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.goto('about:blank');page.set_content(html,wait_until='load')
    page.locator('#photons').fill('4300')
    page.locator('#vis').fill('0.4')
    page.locator('#lam').fill('650')
    page.locator('#resample').click()
    text=page.locator('#spacing').inner_text()
    assert 'mm' in text
    print('DEBUG',page.locator('#neuro tr').count(),errors);assert page.locator('#neuro tr').count()==5
    assert page.locator('#photontable tr').count()==4
    assert page.evaluate('document.documentElement.scrollWidth<=window.innerWidth+1'),f'{name} overflow'
    assert not errors,errors
    path=ROOT/'charts'/f'browser_{name}.png'
    page.screenshot(path=str(path),full_page=True)
    print(f'{name}: PASS spacing={text}, screenshot={path.name}, js_errors={errors}, overflow=none')
    page.close()
  browser.close()
