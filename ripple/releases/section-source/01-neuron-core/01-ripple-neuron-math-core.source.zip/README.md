# 01_Ripple_Neuron_Math_Core — curated source files

This is actual selected executable source and tests from original ZIP releases. Original ZIPs remain unmodified in the user Library. See _SOURCE_PROVENANCE.json for archive SHA-256, selected file SHA-256 and exclusion counts. Do not mistake source selection for complete original installers.
