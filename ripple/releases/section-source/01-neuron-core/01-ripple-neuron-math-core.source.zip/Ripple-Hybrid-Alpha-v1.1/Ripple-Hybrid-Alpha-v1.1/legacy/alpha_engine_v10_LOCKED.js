'use strict';
/** Ripple Alpha v1.0. Deterministic simulated mapping colony, not biological genetics or physical sensor data.
 * Original Ripple v0.5 kernel is imported without modification. Only this adapter is experimental.
 */
const {RippleNeuron}=require('../legacy/ripple_mycelium_v05_LOCKED.js');
const crypto=require('node:crypto');
const SCHEMA='ripple-alpha-genome/1';
const variants={single:{cap:1,grow:false,diffusion:false,occlusion:false,density:false,special:false},
 fixed4:{cap:4,grow:false,diffusion:false,occlusion:false,density:false,special:false},
 adaptive:{cap:14,grow:true,diffusion:false,occlusion:false,density:false,special:false},
 diffusion:{cap:14,grow:true,diffusion:true,occlusion:false,density:false,special:false},
 occlusion:{cap:14,grow:true,diffusion:false,occlusion:true,density:false,special:false},
 density:{cap:14,grow:true,diffusion:false,occlusion:false,density:true,special:false},
 specialized:{cap:14,grow:true,diffusion:true,occlusion:true,density:true,special:true},
 guarded:{cap:14,grow:true,diffusion:true,occlusion:true,density:true,special:false},
 fused:{cap:14,grow:true,diffusion:true,occlusion:true,density:true,special:false}};
function rnd(seed){let s=(seed>>>0)||1;return ()=>{s^=s<<13;s^=s>>>17;s^=s<<5;return (s>>>0)/4294967296;};}
function clip(v,a,b){return Math.max(a,Math.min(b,v));}
function canonical(o){if(Array.isArray(o))return '['+o.map(canonical).join(',')+']';if(o&&typeof o==='object')return '{'+Object.keys(o).sort().map(k=>JSON.stringify(k)+':'+canonical(o[k])).join(',')+'}';return JSON.stringify(o);}
function sha(o){return crypto.createHash('sha256').update(typeof o==='string'?o:canonical(o)).digest('hex');}
function color(rgb){const sum=rgb.reduce((a,b)=>a+b,0);return rgb.map(x=>x/sum);}
function validateGenes(g){if(!g||Object.keys(g).sort().join(',')!=='color,densitySense,diffusionSense,mobility,occlusionSense,role')throw Error('unknown genome gene');
 if(!Array.isArray(g.color)||g.color.length!==3||g.color.some(x=>!Number.isFinite(x)||x<0||x>1)||Math.abs(g.color.reduce((a,b)=>a+b)-1)>1e-8)throw Error('bad color');
 for(const k of ['densitySense','diffusionSense','mobility','occlusionSense'])if(!Number.isFinite(g[k])||g[k]<0||g[k]>1)throw Error('bad '+k);
 if(!['explorer','processor','observer','archivist'].includes(g.role))throw Error('bad role');return true;}
function genome(g,parent=null){validateGenes(g);if(parent!==null&&!/^[a-f0-9]{64}$/.test(parent))throw Error('bad parent marker');const payload={schema:SCHEMA,genes:g,parent};return {...payload,marker:sha(payload)};}
function verifyGenome(o){if(!o||o.schema!==SCHEMA||o.marker!==sha({schema:SCHEMA,genes:o.genes,parent:o.parent}))throw Error('invalid lineage marker');validateGenes(o.genes);return true;}
function mutate(g,rng){const rgb=color(g.color.map(x=>Math.max(.002,x+(rng()+rng()-1)*.22)));const out={...g,color:rgb.map(x=>x),mobility:clip(g.mobility+(rng()-.5)*.14,0,1),diffusionSense:clip(g.diffusionSense+(rng()-.5)*.2,0,1),occlusionSense:clip(g.occlusionSense+(rng()-.5)*.2,0,1),densitySense:clip(g.densitySense+(rng()-.5)*.2,0,1),role:rng()<.16?['explorer','processor','observer','archivist'][Math.floor(rng()*4)]:g.role};validateGenes(out);return out;}
function starter(role='explorer'){
 const c={explorer:[.52,.29,.19],processor:[.29,.52,.19],observer:[.2,.31,.49],archivist:[.34,.33,.33]}[role];
 return {color:c,densitySense:.45,diffusionSense:.55,mobility:.5,occlusionSense:.5,role};}
function mono(g,threshold=.92){const max=Math.max(...g.color);return {monochrome:max>=threshold,purity:max,channel:['R','G','B'][g.color.indexOf(max)]};}
const dirs2=[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0]];
const dirs3=[...dirs2,[0,0,1],[0,0,-1]];
function createWorld(seed,dim){if(![2,3].includes(dim))throw Error('dim must be 2 or 3');const rand=rnd(seed^0x452cc3ed),width=12,height=12,depth=dim===2?1:2,cells=[];for(let z=0;z<depth;z++)for(let y=0;y<height;y++)for(let x=0;x<width;x++){
 const blocked=rand()<.12+(z? .05:0);cells.push({x,y,z,blocked,resource:blocked?0:.32+rand()*.8,density:.06+rand()*.32,rgb:[.26+.6*rand(),.22+.65*rand(),.2+.62*rand()],seen:false});}
 // Secure at least one valid open origin. This is simulated ground truth.
 cells[0].blocked=false;cells[0].resource=1.1;
 return {width,height,depth,dim,cells,seed,hash:sha(cells.map(c=>[c.blocked,c.resource,c.density,c.rgb]))};}
function index(w,x,y,z){return (z*w.height+y)*w.width+x;}
function neighbors(w,i){const c=w.cells[i],out=[];for(const [dx,dy,dz] of (w.dim===2?dirs2:dirs3)){const x=c.x+dx,y=c.y+dy,z=c.z+dz;if(x<0||y<0||z<0||x>=w.width||y>=w.height||z>=w.depth)continue;let j=index(w,x,y,z);if(!w.cells[j].blocked)out.push(j);}return out;}
/** Conservative no-flux finite-volume diffusion; flux for each undirected open-cell edge once. */
function diffuse(w,coefficient=.12,dt=.25){if(coefficient<0||dt<=0||coefficient*dt*(w.dim===2?4:6)>.5)throw Error('unsafe diffusion step');const delta=new Float64Array(w.cells.length);let exchanged=0;
 for(let i=0;i<w.cells.length;i++){if(w.cells[i].blocked)continue;const c=w.cells[i];for(const j of neighbors(w,i)){if(j<=i)continue;const f=coefficient*dt*(w.cells[j].resource-c.resource);delta[i]+=f;delta[j]-=f;exchanged+=Math.abs(f);}}
 for(let i=0;i<w.cells.length;i++){if(w.cells[i].blocked)continue;w.cells[i].resource+=delta[i];if(w.cells[i].resource < -1e-10)throw Error('negative resource from diffusion');}
 return exchanged;}
/** Grid-ray visibility: solid voxels block; otherwise Beer-Lambert exponential transmission proxy.
 * Does not infer optical density from a camera. */
function visibility(w,i,source=[0,0,0],useDensity=true){const dest=w.cells[i],d=[dest.x-source[0],dest.y-source[1],dest.z-source[2]],n=Math.max(...d.map(Math.abs)),s=Math.max(1,n*3);let absorb=0;
 for(let k=1;k<=s;k++){const t=k/s;const xyz=d.map((v,j)=>Math.round(source[j]+v*t));const j=index(w,xyz[0],xyz[1],xyz[2]);if(j!==i&&w.cells[j].blocked)return 0;absorb+=(useDensity?w.cells[j].density:.15)/s;}
 return Math.exp(-.8*absorb*Math.max(1,Math.hypot(...d)));}
function reportConfig(v){if(!variants[v])throw Error('bad variant');return variants[v];}
function run({seed=11,dim=2,variant='fused',steps=160,dt=.25,densityFrom=80,trackEvery=8,maxPopulation=null}={}){
 if(densityFrom>steps && densityFrom===80) densityFrom=Math.floor(steps/2);
 if(!Number.isSafeInteger(seed)||seed<1||seed>2147483647||!Number.isSafeInteger(steps)||steps<1||steps>1000||!Number.isFinite(dt)||dt<=0||dt>.5||!Number.isInteger(densityFrom)||densityFrom<0||densityFrom>steps)throw Error('bad run arguments');
 if(!Number.isInteger(trackEvery)||trackEvery<1||trackEvery>100)throw Error('bad trackEvery');const cfg=reportConfig(variant),cap=Math.min(cfg.cap,maxPopulation??cfg.cap);if(cap<1||cap>24||!Number.isInteger(cap))throw Error('invalid population cap');
 const w=createWorld(seed,dim),rng=rnd(seed^0x83ca21),trace=[],lineage=[],genomeMap=new Map(),pathStore=new Map(),agents=[],monoCrossings=[],species=['explorer','processor','observer','archivist'];
 let nextAgent=0,events=0,births=0,retired=0,duplicate=0,travel=0,visObs=0,resourceUsed=0,stalled=0,blockedLight=0,spent=0;
 function birth(parent=null){if(agents.length>=cap)return null;const g=parent?mutate(parent.genes.genes,rng):starter(species[nextAgent%species.length]),rec=genome(g,parent?parent.genes.marker:null);verifyGenome(rec);const c={id:nextAgent++,parent:parent?.id??null,generation:parent?parent.generation+1:0,position:parent?.position??0,created:tick,genes:rec,neuron:new RippleNeuron(),energy:1.5,done:0,last:tick};
 agents.push(c);pathStore.set(c.id,[]);genomeMap.set(rec.marker,rec);lineage.push({id:c.id,parent:c.parent,generation:c.generation,created:tick,marker:rec.marker,color:rec.genes.color,role:rec.genes.role});births++;
 const m=mono(g);if(m.monochrome){monoCrossings.push({tick,id:c.id,generation:c.generation,marker:rec.marker,channel:m.channel,purity:m.purity});}
 return c;}
 let tick=0;birth();if(variant==='fixed4'){for(let k=1;k<cap;k++)birth();}
 for(tick=0;tick<steps;tick++){
   let massBefore=w.cells.reduce((s,c)=>s+c.resource,0);const flux=diffuse(w,.12,dt),massAfter=w.cells.reduce((s,c)=>s+c.resource,0);if(Math.abs(massBefore-massAfter)>1e-8)throw Error('diffusion mass violation');
   const densityActive=tick>=densityFrom;
   const remaining=w.cells.reduce((s,c)=>s+(!c.blocked&&!c.seen),0);
   if(cfg.grow && tick%7===0 && remaining>0){const desire=Math.min(cap,Math.max(1,Math.ceil(remaining/(cfg.density&&densityActive?13:23))));
     if(agents.length<desire){const parent=[...agents].sort((a,b)=>(b.energy+b.done*.025)-(a.energy+a.done*.025)||a.id-b.id)[0];if(parent&&parent.energy>.25){parent.energy-=.15;birth(parent);}}
   }
   // After decline, keep the root and retire only an idle worker, preserving all observations.
   if(cfg.grow && tick%13===0 && tick>25 && agents.length>1 && remaining<agents.length*3){const choice=agents.slice(1).sort((a,b)=>a.done-b.done||b.id-a.id)[0];agents.splice(agents.indexOf(choice),1);retired++;}
   for(const a of agents){const cell=w.cells[a.position];const ng=neighbors(w,a.position);const options=[a.position,...ng];const gains=a.genes.genes;
    const rank=options.map(j=>{const c=w.cells[j],dx=c.x-cell.x,dy=c.y-cell.y,dz=c.z-cell.z;
      const perceived=cfg.occlusion?visibility(w,j,[0,0,0],densityActive):1;const densityBonus=cfg.density&&densityActive?(variant==='guarded'?.15:(1-c.density)*gains.densitySense):0;
      const nutrient=cfg.diffusion?(variant==='guarded'?.12*c.resource:gains.diffusionSense*c.resource):.12*c.resource;
      const task=!c.seen?.85:0;const occlusionBonus=cfg.occlusion?(variant==='guarded'?(perceived>.65?.1:0):gains.occlusionSense*perceived*.4):0;
      const role=cfg.special?({explorer:task*.25,processor:nutrient*.5,observer:occlusionBonus*.5,archivist:c.seen?.08:0}[gains.role]):0;
      const localCrowd=agents.filter(b=>b.position===j&&b.id!==a.id).length;
      const drift=(rng()-.5)*.28;return {j,score:task+nutrient+occlusionBonus+densityBonus+role-localCrowd*.15-(Math.abs(dz)? .12:0)+drift};});
    rank.sort((x,y)=>y.score-x.score||x.j-y.j);const stay=rank.find(z=>z.j===a.position);const j=rank[0].score-stay.score>(1-gains.mobility)*.08?rank[0].j:a.position;
    const moved=j!==a.position;if(moved){a.position=j;travel++;}const c=w.cells[a.position];
    const visible=visibility(w,a.position,[0,0,0],densityActive);if(visible===0)blockedLight++;
    const optical=cfg.occlusion?(variant==='occlusion'?visible:(variant==='guarded'?1:(.18+.82*visible))):1; // Strict direct beam vs documented simulated ambient fallback
    const rgb=c.rgb.map((x,k)=>clip(x*(.55+.75*gains.color[k])*optical,0,1));
    const spikes=a.neuron.step(rgb,dt).count;events+=spikes;pathStore.get(a.id).push([tick,c.x,c.y,c.z,spikes]);
    a.energy=clip(a.energy+.005-.006*moved,0,2.5); // motion counted via travel above; per-step baseline maintenance only
    for(let pulse=0;pulse<spikes;pulse++){
      if(!c.seen){c.seen=true;a.done++;a.last=tick;visObs++;const used=Math.min(c.resource,.08);c.resource-=used;resourceUsed+=used;a.energy=clip(a.energy+used*.65-.025,0,2.5);}
      else duplicate++;
    }
    if(!spikes)stalled++;
   }
   spent+=agents.length*dt;
   if(tick%trackEvery===0||tick===steps-1){const count=w.cells.reduce((s,c)=>s+(!c.blocked&&c.seen),0),total=w.cells.reduce((s,c)=>s+(!c.blocked),0);
    trace.push({tick,phase:densityActive?'density':'lineage',mapped:count,total,coverage:count/total,population:agents.length,monochrome:monoCrossings.length,energy:agents.reduce((s,a)=>s+a.energy,0),resource:w.cells.reduce((s,c)=>s+c.resource,0),meanDensity:w.cells.reduce((s,c)=>s+c.density,0)/w.cells.length,
      seenIds:w.cells.filter(c=>c.seen).map(c=>index(w,c.x,c.y,c.z)),individuals:agents.map(a=>({id:a.id,x:w.cells[a.position].x,y:w.cells[a.position].y,z:w.cells[a.position].z,color:a.genes.genes.color,role:a.genes.genes.role,gen:a.generation}))});}
 }
 const total=w.cells.filter(c=>!c.blocked).length,mapped=w.cells.filter(c=>!c.blocked&&c.seen).length;const genes=[...genomeMap.values()];
 const monochromeCount=monoCrossings.length;const output={schema:'ripple-alpha-run/1',seed,dim,variant,steps,dt,densityFrom,worldHash:w.hash,
 summary:{coverage:mapped/total,mapped,total,events,created:births,retired,remaining:agents.length,workerSeconds:spent,duplicate,travel,spikesPerWorkerSecond:events/Math.max(1,spent),monochromeCount,resourceUsed,blockedLight,stalled,
  objective:1000*mapped/total-1.1*spent-.04*duplicate-1.4*births},
 trace,lineage,paths:Object.fromEntries(pathStore),monoCrossings,world:{size:[w.width,w.height,w.depth],cells:w.cells.map(c=>({x:c.x,y:c.y,z:c.z,blocked:c.blocked,seen:c.seen,density:c.density,rgb:c.rgb,resource:c.resource}))},genomes:genes};
 output.resultHash=sha({seed,dim,variant,summary:output.summary,trace:output.trace,lineage:output.lineage});return output;
}
module.exports={run,createWorld,neighbors,diffuse,visibility,genome,verifyGenome,mutate,mono,starter,rnd,sha,variants,SCHEMA};
