import fs from 'node:fs';
import {genome,mutate,crossover,rnd,colorClass} from './hybrid_lab.mjs';
const paths=['R','G','B','GRAY'];const records=[];
function fitness(g,env){const c=g.color;if(env==='GRAY')return -(Math.max(...c)-Math.min(...c));return c[['R','G','B'].indexOf(env)];}
for(const env of paths)for(const seed of [15,37,59,83]){
 const random=rnd(seed+env.length*27013),popSize=22,generations=48;let pop=Array.from({length:popSize},()=>genome());const lineage=[],crossings=[];
 let seen=new Set();
 for(let gen=0;gen<generations;gen++){
  pop.sort((a,b)=>fitness(b,env)-fitness(a,env));const elites=pop.slice(0,6);
  const report=pop.map(g=>colorClass(g.color));
  for(const g of pop){const cls=colorClass(g.color);if(cls!=='MIXED'&&!seen.has(g.marker)){crossings.push({generation:gen,genome:g.marker,parent:g.parent,donor:g.donor,color:g.color,class:cls});seen.add(g.marker);}}
  lineage.push({generation:gen,topColor:elites[0].color,topClass:colorClass(elites[0].color),bestFitness:fitness(elites[0],env),phenotypeCounts:{fixed:report.filter(x=>x.endsWith('FIXED')).length,achromatic:report.filter(x=>x==='ACHROMATIC').length}});
  pop=[...elites];while(pop.length<popSize){const a=elites[Math.floor(random()*elites.length)];const b=elites[Math.floor(random()*elites.length)];pop.push(random()<.3?mutate(crossover(a,b,random),random):mutate(a,random));}
 }
 records.push({environment:env,seed,generations,population:popSize,finalBest:lineage.at(-1),firstCrossing:crossings[0]??null,crossings:crossings.slice(0,30),lineage});
}
fs.writeFileSync(new URL('../data/color_selection.json',import.meta.url),JSON.stringify({schema:'ripple-color-selection/1',warning:'forced artificial fitness landscapes: not spontaneous intelligence or physical DNA',environments:paths,records},null,2));
console.log(JSON.stringify(records.map(r=>({environment:r.environment,seed:r.seed,top:r.finalBest.topClass,first:r.firstCrossing?.generation??null}))));
