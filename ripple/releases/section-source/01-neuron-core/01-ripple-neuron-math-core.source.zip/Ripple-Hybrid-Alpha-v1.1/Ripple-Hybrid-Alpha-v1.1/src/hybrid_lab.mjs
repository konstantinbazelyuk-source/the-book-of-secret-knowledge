// Ripple Hybrid Alpha v1.1. Offline bounded digital phenotype research. CC0-1.0.
// All observations and environments below are synthetic, not calibrated camera data.
import { createRequire } from 'node:module';
import crypto from 'node:crypto';
import { QuadEncoder } from '../legacy/quaternary_v07_LOCKED.mjs';
const require=createRequire(import.meta.url);
const {RippleNeuron}=require('../legacy/ripple_mycelium_v05_LOCKED.js');
const {Photoreceptor,absorb}=require('../legacy/photoreceptor_v06_LOCKED.js');
const {rnd,sha,diffuse}=require('../legacy/alpha_engine_v10_LOCKED.js');
export {rnd};
export const FEATURES=['vision','depth','photo','quad','diffusion','occlusion','replicate','memory','density'];
export const ACTIONS=['SCAN','MOVE','SHARE','CLONE','WAIT'];
export const CONDITIONS=['unknown','blocked','low_energy','positive','crowded','nutrient','always'];
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const avg=a=>a.reduce((x,y)=>x+y,0)/Math.max(a.length,1);
const canonical=x=>Array.isArray(x)?'['+x.map(canonical).join(',')+']':x&&typeof x==='object'?'{'+Object.keys(x).sort().map(k=>JSON.stringify(k)+':'+canonical(x[k])).join(',')+'}':JSON.stringify(x);
export function marker(record){return crypto.createHash('sha256').update(canonical(record)).digest('hex');}
export function defaultProgram(){return [{if:'low_energy',do:'SHARE'},{if:'unknown',do:'SCAN'},{if:'nutrient',do:'MOVE'},{if:'always',do:'CLONE'}];}
export function validateProgram(p){if(!Array.isArray(p)||p.length<1||p.length>8)throw Error('program size');for(const rule of p){if(!rule||Object.keys(rule).sort().join(',')!=='do,if'||!CONDITIONS.includes(rule.if)||!ACTIONS.includes(rule.do))throw Error('forbidden rule');}return true;}
export function genome(spec={}){
 const rgb=spec.color||[.44,.35,.21],program=spec.program||defaultProgram();validateProgram(program);
 if(!Array.isArray(rgb)||rgb.length!==3||rgb.some(x=>!Number.isFinite(x)||x<0||x>1)||Math.abs(rgb.reduce((a,b)=>a+b)-1)>1e-8)throw Error('bad color');
 const floats={mobility:spec.mobility??.6,replicationBias:spec.replicationBias??.5,densitySense:spec.densitySense??.5,lightGain:spec.lightGain??.8,communication:spec.communication??.5};
 if(Object.values(floats).some(x=>!Number.isFinite(x)||x<0||x>1))throw Error('bad gene');
 if(spec.parent!==undefined&&spec.parent!==null&&!/^[a-f0-9]{64}$/.test(spec.parent))throw Error('bad parent');
 if(spec.donor!==undefined&&spec.donor!==null&&!/^[a-f0-9]{64}$/.test(spec.donor))throw Error('bad donor');
 const raw={schema:'ripple-phenotype-genome/1',color:rgb,...floats,program:program.map(r=>({...r})),parent:spec.parent??null,donor:spec.donor??null};return {...raw,marker:marker(raw)};
}
export function colorClass(color){const mx=Math.max(...color),mn=Math.min(...color);return mx>=.92?['RED','GREEN','BLUE'][color.indexOf(mx)]+'-FIXED':mx-mn<=.025?'ACHROMATIC':'MIXED';}
export function verifyGenome(g){if(!g||g.marker!==marker(Object.fromEntries(Object.entries(g).filter(([k])=>k!=='marker'))))throw Error('genome marker mismatch');genome(g);return true;}
export function mutate(g,r){verifyGenome(g);const spec={...g,parent:g.marker};delete spec.marker;delete spec.donor;
 let weights=g.color.map(x=>Math.max(.003,x+(r()-.5)*.25));const s=weights.reduce((a,b)=>a+b);spec.color=weights.map(x=>x/s);
 const ks=['mobility','replicationBias','densitySense','lightGain','communication'];const k=ks[Math.floor(r()*ks.length)];spec[k]=clamp(g[k]+(r()-.5)*.6,0,1);
 spec.program=g.program.map(x=>({...x}));const at=Math.floor(r()*spec.program.length);
 const which=Math.floor(r()*4);
 if(which===0)spec.program[at].if=CONDITIONS[Math.floor(r()*CONDITIONS.length)];
 if(which===1)spec.program[at].do=ACTIONS[Math.floor(r()*ACTIONS.length)];
 if(which===2&&spec.program.length<8)spec.program.splice(at,0,{if:CONDITIONS[Math.floor(r()*CONDITIONS.length)],do:ACTIONS[Math.floor(r()*ACTIONS.length)]});
 if(which===3&&spec.program.length>1)spec.program.splice(at,1);
 return genome(spec);
}
export function crossover(a,b,r){verifyGenome(a);verifyGenome(b);let n=1+Math.floor(r()*Math.min(7,a.program.length));let pa=a.program.slice(0,n).concat(b.program.slice(n)).slice(0,8);if(!pa.length)pa=defaultProgram();const color=a.color.map((x,k)=>(x+b.color[k])/2);const rest={};for(const k of ['mobility','replicationBias','densitySense','lightGain','communication'])rest[k]=r()<.5?a[k]:b[k];return genome({color,program:pa,parent:a.marker,donor:b.marker,...rest});}
const axes=[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]];
const key=(x,y,z)=>x+','+y+','+z;
export function world(seed=1,dim=2){if(!Number.isInteger(seed)||seed<1||![2,3].includes(dim))throw Error('invalid world');const r=rnd(seed^0x7f93a),w=10,h=10,d=dim===2?1:3,cells=[];
 for(let z=0;z<d;z++)for(let y=0;y<h;y++)for(let x=0;x<w;x++){const wall=r()<(.12+.015*z)&&!(x===1&&y===1&&z===0);cells.push({x,y,z,blocked:wall,resource:wall?0:.2+.7*r(),density:.08+.65*r(),rgb:[.25+.65*r(),.25+.65*r(),.25+.65*r()]});}
 return {width:w,height:h,depth:d,dim,cells,seed};}
export function idx(w,x,y,z){return (z*w.height+y)*w.width+x;}
export function cellAt(w,x,y,z){return x>=0&&y>=0&&z>=0&&x<w.width&&y<w.height&&z<w.depth?w.cells[idx(w,x,y,z)]:null;}
/** Ray samples hidden truth only inside a sensor function. 'Known' maps receive only these returns. */
export function ray(w,start,dir,range,{occlusion=true,depth=true,density=false}={}){
 if(![...start,...dir,range].every(Number.isFinite)||range<1||range>8)throw Error('ray arguments');
 let trans=1;const records=[];
 for(let step=1;step<=range;step++){
  const [x,y,z]=start.map((a,i)=>a+dir[i]*step),c=cellAt(w,x,y,z);
  if(!c)return {hit:'edge',distance:depth?step:null,rangeSteps:step,transmission:trans,records};
  if(density)trans*=Math.exp(-.35*c.density);
  // Non-occlusion is a deliberately faulty sensor alternative, retained as control.
  if(c.blocked&&occlusion)return {hit:'solid',distance:depth?step:null,rangeSteps:step,transmission:0,records};
  records.push({x,y,z,occupied: false});
 }
 return {hit:'range',distance:depth?range:null,rangeSteps:range,transmission:trans,records};
}
function nearbyDirections(w){return w.dim===2?axes.slice(0,4):axes;}
function visibleRoutes(w,position,range,opt){const observations=[];for(const direction of nearbyDirections(w)){
 const q=ray(w,position,direction,range,opt);for(const rec of q.records)observations.push(rec);
 if(q.hit==='solid'){const hitAt=direction.map((v,i)=>position[i]+v*q.rangeSteps);observations.push({x:hitAt[0],y:hitAt[1],z:hitAt[2],occupied:true});}
 }return observations;
}
export function effectiveFeatures(flags){if(Array.isArray(flags))flags=Object.fromEntries(FEATURES.map(x=>[x,flags.includes(x)]));if(!flags||FEATURES.some(x=>typeof flags[x]!=='boolean'))throw Error('feature flags incomplete');return flags;}
export function run({seed=11,dim=2,flags=Object.fromEntries(FEATURES.map(x=>[x,true])),candidate=null,steps=70,maxPopulation=9,densityFrom=35}={}){
 flags=effectiveFeatures(flags);if(!Number.isInteger(steps)||steps<1||steps>300||!Number.isInteger(maxPopulation)||maxPopulation<1||maxPopulation>16||!Number.isInteger(densityFrom)||densityFrom<0||densityFrom>steps)throw Error('bounds');
 const w=world(seed,dim),random=rnd(seed^0x819df2),base=candidate||genome();verifyGenome(base);let id=0,created=0,retired=0,scans=0,correctSeen=0,knownWalls=0,observedFree=0,depthHits=0,moves=0,shared=0,knowledgeTransferred=0,events=0,forbidden=0,actionCount=Object.fromEntries(ACTIONS.map(x=>[x,0]));
 const genealogy=[],agents=[],known=new Map(),paths=[],snapshots=[],mutationEvents=[],memoryState=new Map();
 function birth(g,parent=null,pos=[1,1,0],tick=0){if(agents.length>=maxPopulation)return null;const node={id:id++,parent:parent?.id??null,g,age:0,pos:[...pos],energy:1.5,neuron:new RippleNeuron(),photo:new Photoreceptor(),quad:new QuadEncoder({threshold:.12,dwell:2}),lastSignal:2,known:new Map()};agents.push(node);created++;
 genealogy.push({id:node.id,parent:node.parent,marker:g.marker,generation:parent?genealogy.find(x=>x.id===parent.id).generation+1:0,born:tick,color:g.color,colorClass:colorClass(g.color)});paths.push({id:node.id,steps:[]});return node;}
 birth(base);const worldTarget=w.cells.filter(c=>!c.blocked).length;
 // Sensor results are the only way into the known map. World truth is used only for sensor and post-run scoring.
 for(let t=0;t<steps;t++){
  if(flags.diffusion)diffuse(w,.12,.25);const activeDensity=flags.density&&t>=densityFrom;
  for(const agent of [...agents]){
   if(!agents.includes(agent))continue;
   const current=cellAt(w,...agent.pos);if(!current||current.blocked)throw Error('agent penetrated wall');
   const rgb=current.rgb.map((x,k)=>clamp(x*(.5+agent.g.color[k]*1.4),0,1));
   const field=flags.occlusion?absorb(rgb,[.36,.36,.36],activeDensity?current.density:.15).output:rgb;
   let light=field.map(v=>v*agent.g.lightGain);
   if(flags.photo)light=agent.photo.step(light,.25).output;
   let out=agent.neuron.step(light,.25);events+=out.count;
   const four=flags.quad?agent.quad.step({drive:out.drive,inhibited:out.drive<0}):{code:out.count?3:2};agent.lastSignal=four.code;
   // Every step may update the bounded digital rule state; effectful actions need neuron events.
   const localUnknown=flags.vision?nearbyDirections(w).some(a=>{const xyz=agent.pos.map((x,i)=>x+a[i]);return cellAt(w,...xyz)&&!agent.known.has(key(...xyz));}):false;
   const observations={unknown:localUnknown,blocked:flags.vision&&nearbyDirections(w).some(a=>agent.known.get(key(...agent.pos.map((x,i)=>x+a[i])))===true),low_energy:agent.energy<.65,positive:agent.lastSignal===3,crowded:agents.some(other=>other!==agent&&key(...other.pos)===key(...agent.pos)),nutrient:current.resource>.35,always:true};
   let act='WAIT';for(const rule of agent.g.program){if(observations[rule.if]){act=rule.do;break;}}
   if(!flags.vision&&act==='SCAN')act='WAIT';if(!flags.replicate&&act==='CLONE')act='WAIT';
   // Gate actions by the genuine v0.1 kernel; no event means no action.
   if(out.count===0)act='WAIT';actionCount[act]++;
   if(act==='SCAN'){
    scans++;const range=flags.depth?3:1;
    for(const rec of visibleRoutes(w,agent.pos,range,{depth:flags.depth,occlusion:flags.occlusion,density:activeDensity})){
      const id=key(rec.x,rec.y,rec.z),previous=known.get(id);known.set(id,rec.occupied);agent.known.set(id,rec.occupied);
      if(previous===undefined){if(rec.occupied)knownWalls++;else observedFree++;}
      if(flags.depth&&Math.max(Math.abs(rec.x-agent.pos[0]),Math.abs(rec.y-agent.pos[1]),Math.abs(rec.z-agent.pos[2]))>1)depthHits++;
    }
   }
   if(act==='MOVE'){
    // Planner consumes only sensed free cells; vision-disabled mode uses a blind, random walk.
    let opts=[];for(const d of nearbyDirections(w)){const next=agent.pos.map((v,i)=>v+d[i]),c=cellAt(w,...next);if(!c)continue;
     const state=agent.known.get(key(...next));if(flags.vision){if(state===false)opts.push({pos:next,s:!memoryState.has(key(...next))?2:1});}
     else opts.push({pos:next,s:1});
    }
    if(opts.length){opts.sort((a,b)=>b.s-a.s);const picks=opts.filter(o=>o.s===opts[0].s);const chosen=picks[Math.floor(random()*picks.length)].pos;const c=cellAt(w,...chosen);
      if(c&&!c.blocked){agent.pos=chosen;moves++;if(flags.memory)memoryState.set(key(...chosen),1);}else forbidden++;}
   }
   if(act==='SHARE'&&flags.diffusion){const recipients=agents.filter(a=>a!==agent&&Math.max(...a.pos.map((v,i)=>Math.abs(v-agent.pos[i])))<=1);
    if(recipients.length){const r=recipients[Math.floor(random()*recipients.length)],amount=Math.min(.08,Math.max(0,agent.energy-.2));agent.energy-=amount;r.energy+=amount;shared+=amount;
      if(flags.memory){const budget=Math.max(1,Math.floor(agent.g.communication*8));let sent=0;for(const [k,v] of agent.known){if(sent>=budget)break;if(!r.known.has(k)){r.known.set(k,v);sent++;knowledgeTransferred++;}}}}}
   if(act==='CLONE'&&flags.replicate&&agents.length<maxPopulation&&agent.energy>.7&&t%4===0&&random()<agent.g.replicationBias){
     agent.energy-=.22;const child=mutate(agent.g,random);birth(child,agent,agent.pos,t);mutationEvents.push({tick:t,parent:agent.g.marker,child:child.marker,ruleChanged:JSON.stringify(child.program)!==JSON.stringify(agent.g.program),fromColor:colorClass(agent.g.color),toColor:colorClass(child.color)});
   }
   // Clipped toy maintenance and environment nutrient intake. Not biological metabolism.
   agent.energy=clamp(agent.energy-.012+.006*current.resource,0,2.5);
   if(agent.energy<=0&&agent.id!==0){agents.splice(agents.indexOf(agent),1);retired++;}
   paths.find(p=>p.id===agent.id).steps.push({t,pos:[...agent.pos],act,signal:agent.lastSignal});
   agent.age++;if(!flags.memory)agent.known.clear();
  }
  if(t%7===0||t===steps-1)snapshots.push({tick:t,workers:agents.map(a=>({id:a.id,pos:a.pos,color:a.g.color})),known:[...known].map(([k,v])=>[...k.split(',').map(Number),v?1:0]),population:agents.length});
 }
 for(const [str,isWall] of known){const c=cellAt(w,...str.split(',').map(Number));if(c&&!isWall&&!c.blocked)correctSeen++;}
 const visits=new Set(paths.flatMap(p=>p.steps.map(z=>key(...z.pos))));const root=genealogy.find(x=>x.id===0);
 const novelty=[Math.min(4,Math.floor(correctSeen/12)),Math.min(4,created-1),Math.min(4,Math.floor(depthHits/15)),Math.min(4,Math.floor(visits.size/7)),Math.min(4,Math.floor(shared*10))];
 const result={schema:'ripple-hybrid-alpha-run/1',seed,dim,steps,flags,genome:base.marker,metrics:{created,retired,remaining:agents.length,scans,seenFree:correctSeen,seenWalls:knownWalls,depthHits,moves,shared,knowledgeTransferred,events,blockedMoves:forbidden,visits:visits.size,totalFree:worldTarget,coverage:correctSeen/worldTarget,mutatedRules:mutationEvents.filter(x=>x.ruleChanged).length,actions:actionCount,novelty},genealogy,mutationEvents,paths,snapshots,initialColor:root.color,createdColorClasses:genealogy.map(x=>x.colorClass),finalKnown:[...known].map(([k,v])=>({pos:k.split(',').map(Number),solid:v}))};
 result.hash=marker({seed,dim,flags,genome:result.genome,metrics:result.metrics,genealogy,mutationEvents});return result;
}
export function behavioralNovelty(records,k=5){const ds=x=>x.metrics.novelty;const out=[];for(const v of records){const rest=records.filter(x=>x!==v).map(x=>Math.sqrt(ds(x).reduce((s,n,i)=>s+(n-ds(v)[i])**2,0))).sort((a,b)=>a-b);out.push({id:v.hash,novelty:avg(rest.slice(0,k))});}return out;}
export function phenotypeBio(r){return {marker:r.genome,dimensions:r.dim,syntheticSight:r.metrics.seenFree>0,syntheticDepth:r.metrics.depthHits>0,reproduced:r.metrics.created>1,ruleMutationObserved:r.metrics.mutatedRules>0,diffused:r.flags.diffusion,observedTransfers:r.metrics.knowledgeTransferred,quaternary:r.flags.quad,observedCells:r.metrics.seenFree,children:r.metrics.created-1,geneticColor:colorClass(r.initialColor),observedColorTransitions:r.mutationEvents.filter(x=>x.fromColor!==x.toColor).length,noveltyBin:r.metrics.novelty,limitations:['synthetic voxel environment','original Ripple LIF kernel','no real camera or independent intelligence']};}
