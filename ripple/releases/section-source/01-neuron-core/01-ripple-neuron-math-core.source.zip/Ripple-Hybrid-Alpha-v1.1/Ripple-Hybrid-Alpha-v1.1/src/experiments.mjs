import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {FEATURES,genome,mutate,crossover,rnd,run,phenotypeBio} from './hybrid_lab.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const data=path.join(root,'data');fs.mkdirSync(data,{recursive:true});
const store=(name,d)=>fs.writeFileSync(path.join(data,name),JSON.stringify(d,null,2));
function flagsFromMask(mask){return Object.fromEntries(FEATURES.map((f,i)=>[f,!!(mask&(1<<i))]));}
const sweep=[],seeds=[11,29,47];
for(let mask=0;mask<(1<<FEATURES.length);mask++)for(const dim of [2,3])for(const seed of seeds){
 const x=run({seed,dim,flags:flagsFromMask(mask),steps:56,densityFrom:28,maxPopulation:8});
 sweep.push({mask,dim,seed,metrics:x.metrics,hash:x.hash});
}
store('factorial_3072.json',{schema:'ripple-factorial/1',purpose:'feature-presence comparisons not speed',features:FEATURES,seeds,steps:56,runs:sweep});
const maskAgg=[];
for(let mask=0;mask<(1<<FEATURES.length);mask++){
 const rows=sweep.filter(r=>r.mask===mask);const mean=k=>rows.reduce((s,r)=>s+r.metrics[k],0)/rows.length;
 maskAgg.push({mask,flags:flagsFromMask(mask),coverage:mean('coverage'),depthHits:mean('depthHits'),created:mean('created'),ruleMutations:mean('mutatedRules'),seenWalls:mean('seenWalls'),moves:mean('moves'),visits:mean('visits'),blockedMoves:mean('blockedMoves')});
}
store('factorial_summary.json',maskAgg);
const specPrograms=[
 [{if:'unknown',do:'SCAN'},{if:'always',do:'MOVE'}],
 [{if:'always',do:'SCAN'}],
 [{if:'always',do:'MOVE'}],
 [{if:'always',do:'CLONE'}],
 [{if:'always',do:'SHARE'}],
 [{if:'unknown',do:'SCAN'},{if:'crowded',do:'MOVE'},{if:'always',do:'CLONE'}],
 [{if:'positive',do:'SCAN'},{if:'nutrient',do:'MOVE'},{if:'always',do:'CLONE'}],
 [{if:'always',do:'WAIT'}]
];
const R=rnd(21672),all=FEATURES.reduce((o,k)=>({...o,[k]:true}),{});
const fullRuns=[];const archive=new Map();const lineage=[];const trainingSeeds=[103,211];const holdoutSeeds=[409,557];
const candidateGenomes=specPrograms.map(program=>genome({program}));
const evalCandidate=(g,seed,dim)=>run({seed,dim,flags:all,candidate:g,steps:72,densityFrom:36,maxPopulation:9});
function archiveKey(x){return x.metrics.novelty.join(':');}
function insert(g,origin){
 const training=[evalCandidate(g,trainingSeeds[0],2),evalCandidate(g,trainingSeeds[1],3)];
 const signature=training.map(archiveKey),coverage=training.reduce((s,x)=>s+x.metrics.coverage,0)/training.length;
 const descriptions=training.map(x=>phenotypeBio(x));const composite=training.map(x=>x.metrics);
 const record={index:lineage.length,marker:g.marker,parent:g.parent,donor:g.donor,origin,program:g.program,color:g.color,fullGenome:g,signature,coverage,metrics:composite};lineage.push(record);
 for(let i=0;i<training.length;i++){const k=signature[i],prev=archive.get(k);const score=training[i].metrics.coverage;
   // MAP-archive records diverse behavioral categories. Coverage only breaks ties within a category.
   if(!prev||score>prev.score)archive.set(k,{marker:g.marker,score,sourceIndex:record.index,dimension:training[i].dim});}
 if(record.index<30||record.index%20===0)fullRuns.push({genome:g,results:training});
 return record;
}
for(const g of candidateGenomes)insert(g,'starter');
for(let i=0;i<200;i++){
 const pool=[...archive.values()].map(x=>lineage[x.sourceIndex]).filter(Boolean);
 const leader=pool[Math.floor(R()*pool.length)];
 const parent=candidateGenomes.find(g=>g.marker===leader.marker)||lineageToGenome(leader);
 let child;
 if(i%5===0&&pool.length>1){const mate=pool[Math.floor(R()*pool.length)];child=crossover(parent,lineageToGenome(mate),R);}else child=mutate(parent,R);
 candidateGenomes.push(child);insert(child,i%5===0?'crossover':'mutation');
}
function lineageToGenome(rec){return rec.fullGenome;}
// Predeclared holdout across reserved seeds for select archived phenotype representatives only.
const representatives=[...archive.values()].sort((a,b)=>a.sourceIndex-b.sourceIndex).filter((v,i,a)=>a.findIndex(z=>z.marker===v.marker)===i).slice(0,24);
const holdout=representatives.map(x=>{
 const rec=lineage[x.sourceIndex],g=lineageToGenome(rec),res=holdoutSeeds.map((seed,i)=>evalCandidate(g,seed,i===0?2:3));
 return {marker:g.marker,sourceIndex:rec.index,trainedCoverage:rec.coverage,holdoutCoverage:res.reduce((s,y)=>s+y.metrics.coverage,0)/res.length,bio:res.map(phenotypeBio),metrics:res.map(z=>z.metrics)};
});
const lineageData={schema:'ripple-synthetic-logic/1',method:'bounded rule mutation and crossover without executable code generation',trainingSeeds,holdoutSeeds,trainingCount:lineage.length,archiveBins:archive.size,archive:[...archive.entries()].map(([key,v])=>({bin:key,...v})),lineage,holdout};
store('genetic_logic_study.json',lineageData);
const specimenIds=[0,3,5,30,75,150,207];
const specimenRuns=specimenIds.map(i=>{const rec=lineage[i];const g=lineageToGenome(rec);const result=run({seed:911,dim:i%2?3:2,flags:all,candidate:g,steps:96,densityFrom:48,maxPopulation:9});return {lineageIndex:i,bio:phenotypeBio(result),result};});
store('specimens.json',specimenRuns);
const summary={schema:'ripple-hybrid-alpha-summary/1',features:FEATURES,factorialTrials:sweep.length,trainingGenomes:lineage.length,genomeTrainTrials:lineage.length*2,holdoutTrials:holdout.length*2,archiveBins:archive.size,
 designedAbilityVariants:{vision:maskAgg.filter(x=>x.flags.vision).reduce((s,x)=>s+x.seenWalls,0)/(1<<(FEATURES.length-1)),blind:maskAgg.filter(x=>!x.flags.vision).reduce((s,x)=>s+x.seenWalls,0)/(1<<(FEATURES.length-1))},
 topFeatureMasks:maskAgg.slice().sort((a,b)=>b.depthHits-a.depthHits).slice(0,5).map(x=>({mask:x.mask,depthHits:x.depthHits,coverage:x.coverage})),
 negativeCases:{noVision:maskAgg.filter(x=>!x.flags.vision).every(x=>x.seenWalls===0),noReplication:maskAgg.filter(x=>!x.flags.replicate).every(x=>x.created===1),noDepth:maskAgg.filter(x=>!x.flags.depth).every(x=>x.depthHits===0)},
 note:'All worlds synthetic, genetic rules restricted grammar, no learning model or real sensors. This is quality-diversity exploration, not performance optimization.'};
store('summary.json',summary);console.log(JSON.stringify(summary,null,2));
