from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parent.parent
content=(root/'Ripple-Hybrid-Alpha-v1.1.html').read_text()
results=[]
with sync_playwright() as p:
 for width,height in [(1280,850),(390,844)]:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  page=b.new_page(viewport={'width':width,'height':height},device_scale_factor=1)
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(content,wait_until='load')
  page.wait_for_timeout(250)
  assert not errors,errors
  assert page.locator('#statExperiments').inner_text()=='3,072'
  assert page.locator('#specimen option').count()>=7
  page.locator('#specimen').select_option('1')
  page.locator('#frame').fill('5')
  assert page.locator('#frameCaption').inner_text().startswith('Recorded step')
  page.locator('#traitOptions input').first.uncheck()
  assert 'No vision:' in page.locator('#mixNote').inner_text()
  page.locator('#selection').select_option('15')
  assert 'ACHROMATIC' in page.locator('#selectionInfo').inner_text()
  over=page.evaluate('document.documentElement.scrollWidth>innerWidth')
  assert not over,('horizontal overflow',width)
  name='desktop' if width>800 else 'mobile'
  file=root/'charts'/f'hybrid_alpha_{name}_verified.png';page.screenshot(path=str(file),full_page=True)
  results.append({'viewport':[width,height],'errors':errors,'noHorizontalOverflow':True,'screenshots':str(file),'controls':True})
  b.close()
(root/'data'/'browser_log.json').write_text(__import__('json').dumps(results,indent=2))
print(results)
