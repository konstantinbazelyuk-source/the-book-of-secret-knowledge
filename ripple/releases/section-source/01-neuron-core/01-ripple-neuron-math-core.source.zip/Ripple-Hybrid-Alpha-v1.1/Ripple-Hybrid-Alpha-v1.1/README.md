# Ripple Hybrid Alpha v1.1 — Digital Phenotypes and Rule Evolution

**Executable research Alpha | User's Ripple mathematics and prior work preserved | New original code: CC0-1.0**

This laboratory tests whether combinations of existing Ripple features produce new **observable synthetic abilities**, not whether more virtual workers are faster. It contains a genuine 2D/3D simulated environment, independently mutated rule lists, per-clone pulse-gated control with the original v0.1 LIF kernel, per-agent observed maps, a diversification archive, digital genetics with recorded ancestry, and experimental artificial selection of RGB genes.

**No claim:** general intelligence, autonomous understanding, camera vision, physical 3D depth measurement, real biological genetics, true self-editing arbitrary program code, quantum computation, or game-engine deployment.

## Quick start

- **Visual laboratory:** open `Ripple-Hybrid-Alpha-v1.1.html` directly in a modern browser. It is a self-contained offline *experiment viewer*; selectors replay actual saved simulations and do not invent new observations.
- **Executable simulation:** Node.js 22+; run `node src/experiments.mjs` to reproduce the 3,072 feature combinations and 208-genome evolutionary study, then `node src/color_selection.mjs` for 16 targeted RGB selection runs.
- **Automated tests:** `node --test tests/hybrid.test.mjs` (42 tests in the delivered version). Browser: `python tests/browser_check.py`, provided Playwright and system Chromium are installed.
- **Rebuild standalone explorer:** `python src/build_explorer.py` (standard library).

No credentials, external services, paid platforms, Docker, cloud GPUs, or npm package installations are required for the simulations. Node is necessary only to rerun the engineering model, not to open the viewer.

## Executed experiment record

- Nine independent feature switches: `vision`, `depth`, `photo`, `quad`, `diffusion`, `occlusion`, `replicate`, `memory`, `density`.
- **3,072 full-factorial recorded runs:** 512 combinations × 2 map dimensions × 3 world seeds, each 56 steps. Fixed seeds allow exact same-environment comparison.
- **208 tested digital genomes:** 8 authored initial rule lists, 160 mutation events and 40 crossovers; 416 training runs; 48 held-out runs of 24 selected diversity-archive representatives.
- **137 unique rule lists** across those 208 genome records; 69 occupied behavioral descriptor categories. These counts represent programs and bins, not distinct intelligent entities.
- **16 targeted color selection studies:** red, green, blue, achromatic × 4 seeds; 48 generations, 22 genomes each. Selected output was fixed in the requested channel/gray in these explicitly biased scoring environments.
- **7 specimen bio replays**, including lineage steps, virtual births, gene colors, synthetic depth observations, map records and transferred information.

## Significant negative findings

- Offspring can proliferate without acquiring sight. CLONE-only populations hit their hard caps and record no map coverage.
- Enabling extra feature modules can lower coverage; the photoreceptor is not universally beneficial.
- Virtual perception comes only from synthetic ray observations, not direct reading of world truth by the planner. Occlusion can hide obstacles; depth returns a limited ray range.
- Sample counts can increase from repeated redundant scanning. They are not independent unique discoveries.
- Under this restricted synthetic comparison, the 24 held-out selected representatives averaged about **0.111** unique-free-cell mapping fraction compared with **0.152** on their training runs. This is a warning about generalization, not a benchmark of physical robotics.
- Artificial color fixation is caused by the fitness rules; neither intelligence nor autonomous natural evolution is implied.

## Continuity and safe program generation

- Locked original `legacy/ripple_mycelium_v05_LOCKED.js` SHA-256 **d75d4208e92f19623b127615bd52b4002e85d2c0a59b76471764b55a24294210** (tested).
- Locked v0.6 photoreceptor and v0.7 quaternary source are imported into the new engine.
- Source `references/` archives user-file versions without editing their contents. Archived SpiderScan, Kokoro and additional modules are **not** silently represented as combined working hardware/software.
- Logic mutation is a finite decision list (max eight rules; predefined conditions and actions) interpreted by our code, not free-running code generation. It has no network, filesystem, subprocess or external control instructions.
- SHA-256 markers detect accidental and intentional alterations *relative to a trusted external record*; hashes alone do not authenticate origin or provide cryptographic consensus.
- Only original new code in this directory is offered as CC0-1.0. Bundled user and third-party archives retain their own terms.

## Documentation

- `docs/SOFTWARE_REQUIREMENTS.md` — formal functional requirements, guardrails and acceptance tests.
- `docs/DIGITAL_BIOS.md` — seven inspectable descendants and phenotype outcomes.
- `docs/NEGATIVE_AND_LIMITS.md` — failed mutants, limitations and unanswered questions.
- `docs/SOURCE_INVENTORY.md` — where each Ripple family came from and what is or isn't integrated.
- `docs/RESEARCH_AND_METHOD.md` — outside published research and reproduction methods.
- `data/factorial_3072.json`, `data/genetic_logic_study.json`, `data/color_selection.json`, `data/specimens.json` — actual generated, replayable experiment records.

## Next development gate

The next justified enhancement is not another synthetic optimization claim. Bring camera or game-engine sensor **recordings** through a typed observation adapter, then measure detection accuracy, depth uncertainty, occlusion error and reproducibility on unseen recordings. Only then determine whether hybrids create useful new capabilities outside a synthetic toy world.
