# Ripple Hybrid Alpha v1.1 — integrity manifest

Created: 2026-10-13 (local project session)

- File count (excluding SHA256SUMS.txt and MANIFEST.md): 37
- Offline viewer: Ripple-Hybrid-Alpha-v1.1.html
- Unit and safety tests: 42/42 passed (new); previous Alpha regression tests 43/43 passed independently.
- Browser: Playwright via system Chromium, 1280px desktop and 390px mobile, assertions passed, no page errors, no horizontal overflow.
- Simulated full-factorial trials: 3072; tested genomes: 208; selected heldout trials: 48.
- Original neuron SHA-256: d75d4208e92f19623b127615bd52b4002e85d2c0a59b76471764b55a24294210.
- SHA256SUMS.txt covers the 37 listed files and their exact relative paths.

No physical camera or motors were tested. Archived files were preserved, not rewritten.
