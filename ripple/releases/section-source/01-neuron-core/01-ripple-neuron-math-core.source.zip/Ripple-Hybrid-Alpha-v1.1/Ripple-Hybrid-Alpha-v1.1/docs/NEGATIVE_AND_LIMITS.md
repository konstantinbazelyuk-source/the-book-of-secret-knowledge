# Negative findings and scientific limitations

1. **Speed was intentionally not optimized.** The objective is feature diversity; high novelty can correspond to a poor mapper.
2. **Many descendants do not equal useful behavior.** A CLONE-only program reaches the population cap without mapping the world. In one explicit test its 9 workers recorded zero seen cells.
3. **Feature interactions can degrade behavior.** In the complete synthetic factorial, activating the photoreceptor reduced mean mapped fraction compared with its absence; photoreceptor events are not a guarantee of mapping improvement.
4. **No vision means no credited map data.** Blind movement still occurs in some variants, but it is not credited as vision or depth.
5. **Memory-off variants can scan repeatedly and forget.** More depth samples can mean redundant repeated observations, not a superior depth estimator.
6. **Density toggling has a small, conditional effect in the test set.** No instrument estimates real physical mass or absolute optical density.
7. **Novelty bins are designed descriptors.** A count of 69 bins depends on the fixed binning; it is not a count of new scientific discoveries or independent intelligences.
8. **Synthetic selection pressures directly cause color fixation.** Monochromatic and achromatic output under 4 targeted fitness environments is expected; no spontaneous biological genetic emergence is established.
9. **Holdout generalization is imperfect.** Training and reserved-seed coverage are reported separately; some digital lineages regress on reserved seeds.
10. **Computation is serial within the Node.js test process.** Multiple virtual clones do not imply distributed threads or reduced CPU wall time.
11. **No actual RGB video or depth hardware in this version.** Raycasting uses exact synthetic world occupancy within the sensor function, not an inferred map from raw camera pixels. A sensor model with error/uncertainty is still required for real use.
12. **Source preservation is not system interoperability.** SpiderScan, Kokoro Mesh, heterodyne, FieldSphere, and phone extensions are sourced/archived but not silently treated as compatible coupled modules. Their safety interfaces must be assessed separately.
13. **No intelligence attribution.** Finite rule-list manipulation and recurrent LIF events do not establish understanding, consciousness, self-aware decision-making or general reasoning.
