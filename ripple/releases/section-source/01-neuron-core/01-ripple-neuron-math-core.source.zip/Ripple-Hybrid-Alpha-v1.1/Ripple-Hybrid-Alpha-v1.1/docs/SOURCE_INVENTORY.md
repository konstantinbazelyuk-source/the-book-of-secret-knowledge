# Verified Ripple library and integration boundary

Actual uploaded files and extracted source were reviewed before adding the new Alpha.

| Recovered family | Existing capability | v1.1 treatment |
|---|---|---|
| Original Ripple Neuron v0.1 and Mycelium v0.5 | LIF pulse gate, adaptive feedback | LOCKED, directly executed |
| Photoreceptor v0.6 | log contrast events, Beer–Lambert synthetic attenuation | copied exact reference, directly executed |
| Quaternary v0.7 | four-symbol signal encoder, bounded VM | original QuadEncoder directly executed; VM still not a colony controller |
| Mycelium v0.1–v0.3 | worker population, work stealing, specialist tasks | v1.0 archived source and mathematical methods; selected reproduction modeled, NOT OS work stealing |
| Optical historical mathematics v0.4 | calibration, optical decoder, ambiguity filter | research reference, NOT a calibrated active sensor |
| Digital World v0.5 and Alpha v1.0 | voxel mapping, diffusion, lineage, synthetic occlusion | original source archived; original finite-volume function imported |
| SpiderScan ground v0.5 | proposed physical camera/ToF and tested synthetic mosaics | unchanged source archive; v1.1 uses ONLY independent voxel sensor simulation |
| Kokoro Mesh Ripple v0.3 | higher-level coordination, trace, safety boards | preserved source archive; no connected models or accounts |
| Sensor Bridge, optical agent, FieldSphere, Spectrum, heterodyne | optical hardware ideas / adapters | referenced via user's original repository archive, NOT fabricated or tested hardware |
| Phone PWA/widget, Android | device interfaces | referenced only, NOT connected or given OS permissions |

The `references/` directory includes unchanged zip archives where recovered. The root `legacy/` includes individually checksum-locked source used by this Alpha. The prior Alpha v1.0 archive is retained for continuity and regression, not overwritten.

**Source model:** original contribution metadata, previous project license notices and third-party software notices remain governing for each archived source. CC0 designation for newly written v1.1 original code does not relicense bundled third-party documents, images or programs.
