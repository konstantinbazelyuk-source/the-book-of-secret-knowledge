# Methods and outside research

Scientific and engineering connections to the new work:

- Mouret, Jean-Baptiste and Jeff Clune, *Illuminating Search Spaces by Mapping Elites*, 2015, https://arxiv.org/abs/1504.04909 . Our archive uses discretized behavioral descriptors and per-bin retention; it is a smaller MAP-Elites-inspired archive, not a claim to reproduce its full reported comparisons.
- Lehman, Joel and Kenneth O. Stanley, *Abandoning Objectives: Evolution Through the Search for Novelty Alone*, Evolutionary Computation 19(2), 2011, doi:10.1162/EVCO_a_00025 ; https://pubmed.ncbi.nlm.nih.gov/20868264/ . Motivates exploring behavior classes rather than only maximizing speed.
- Elfes, Alberto, *Using Occupancy Grids for Mobile Robot Perception and Navigation*, Computer 22(6), 1989, doi:10.1109/2.30720 . A foundation for mapped occupancy from sensors. Unlike Elfes' probabilistic grids, v1.1 uses an idealized discrete known/unknown binary map, not Bayesian occupancy inference.
- Tao et al., *Grammar-obeying program synthesis*, Computer Standards & Interfaces 92, 2025, doi:10.1016/j.csi.2024.103938 . Restricted grammars constrain permissible generated programs. This Alpha uses only a tiny built-in rule grammar, not the paper's LLM-based system.
- Original Ripple v0.1 LIF equations and v0.6 optical math are sourced from archived user project code; no newer optical physics law is asserted.

## Reproduction protocol

1. Run `node --test tests/hybrid.test.mjs` to validate the kernel, sensors, trait switches, genome markers and saved results.
2. Run `node src/experiments.mjs` to recompute full `2^9 × 2 × 3` factorial data and 208-configuration program selection plus reserved-seed trials.
3. Run `node src/color_selection.mjs` for 16 artificial RGB selection runs.
4. Run `python src/build_explorer.py` to rebuild the self-contained browser explorer.
5. Optional `python tests/browser_check.py` uses Playwright with the system Chromium; browsers may not be installed in other environments.

## Measured vs. calculated vs. simulated

- **Calculated:** source SHA-256 checksums and finite algebraic operations, color thresholds and behavior bins.
- **Executed and measured as software tests:** concrete assertions, browser interaction, elapsed process duration if explicitly timed.
- **Simulated:** every voxel, line of sight, optical intensity, mutable genome, digital 'birth', transfer, map and artificial selective pressure.
- **Unverified:** physical sight, sensor calibration, real depth, robotic autonomy, general intelligence, usefulness of rule evolution in a real application.
