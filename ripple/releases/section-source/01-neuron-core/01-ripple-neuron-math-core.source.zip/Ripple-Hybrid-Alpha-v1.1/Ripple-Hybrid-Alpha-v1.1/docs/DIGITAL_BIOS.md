# Digital Phenotype Bios — observed synthetic runs

Each entry is a real result of deterministic software execution. Behaviors are **not** biological species, intelligent beings, or physical sensor events. Depth samples count repeats; children are independent **virtual** Ripple neuron instances.

| Specimen | Dim | Vision observed free cells | Reproduced | Distant samples | Knowledge entries transferred | Rule mutations in descendants |
|---|---:|---:|---:|---:|---:|---:|
| G0 (MIXED) | 2D | 25 | 0 | 27 | 0 | 0 |
| G3 (MIXED) | 3D | 8 | 8 | 190 | 0 | 4 |
| G5 (MIXED) | 3D | 42 | 4 | 252 | 0 | 4 |
| G30 (MIXED) | 2D | 7 | 8 | 140 | 0 | 4 |
| G75 (MIXED) | 3D | 47 | 4 | 59 | 0 | 3 |
| G150 (MIXED) | 2D | 0 | 0 | 0 | 0 | 0 |
| G207 (MIXED) | 3D | 35 | 6 | 275 | 28 | 6 |

## Reading a bio

- "Seen" means a simulated raycast plus Ripple pulse produced occupancy evidence in the agent map.
- "Reproduced" means a bounded instance was created with a logged parent genome marker.
- "Logic mutation" means a changed finite conditional rule list, not generated unconstrained JavaScript.
- A specimen with many offspring and few mapped cells is a negative example, not a superior colony.

Full per-specimen trajectories, genome hashes, action sequences and time snapshots are in `data/specimens.json`.
