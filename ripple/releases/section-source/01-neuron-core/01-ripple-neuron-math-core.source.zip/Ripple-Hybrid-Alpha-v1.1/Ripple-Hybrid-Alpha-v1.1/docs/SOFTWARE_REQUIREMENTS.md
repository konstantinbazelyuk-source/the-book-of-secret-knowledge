# Ripple Hybrid Alpha v1.1 — software requirements and evidence gates

**Status:** implemented, executable local software (Alpha). **Scope:** synthetic spatial phenotype research. Not calibrated sensing, independent intelligence, unattended self-modification, biological metabolism, or a robot controller.

| ID | Requirement | Implementation | Acceptance / evidence |
|---|---|---|---|
| ALPHA-001 | Preserve original neuron's original coefficients, states and clock semantics | Locked `legacy/ripple_mycelium_v05_LOCKED.js` | SHA-256 exact regression hash, original function tests |
| ALPHA-002 | Evaluate full factorial of mutually independent 9 feature switches | `src/experiments.mjs` | 512 combinations × 2 dimensions × 3 seeds = 3,072 saved trials |
| ALPHA-003 | Distinguish sensed space from ground-truth map | Ray API, agent knowledge map | Vision-off sees zero map cells; obstacle blocking tests |
| ALPHA-004 | Provide depth samples only if enabled | range 1 vs range 3, `ray()` | depth-off never logs beyond-neighbor samples; no physical depth claims |
| ALPHA-005 | Replicate bounded descendants with parent lineage | per-descendant LIF and genome | 1–16 max population, candidate with CLONE creates descendants |
| ALPHA-006 | Guard program mutation using a finite allowlisted grammar | `validateProgram`, mutate, crossover | only 7 predicates / 5 actions, 1–8 rules; EXE/EVAL/FETCH disallowed |
| ALPHA-007 | Preserve both donors of recombined programs | `parent`, `donor`, SHA256 marker | crossover ancestry test and tamper rejection |
| ALPHA-008 | Persist spatial memory as a switchable trait | per-agent `known` map | memory-off changes behavior; no omniscient shared world map |
| ALPHA-009 | Transfer acquired information, rather than implicit global sharing | explicit SHARE rule, adjacency and per-genome bounded transfer | transfer tally and observed live cases in genetic runs; zero otherwise |
| ALPHA-010 | Handle optical occlusion and dimensioned density separately | `ray`, v0.6 `absorb`, density activation halfway | attenuation decreases transmission; phase is explicit; no physical calibration |
| ALPHA-011 | Track quaternary sensor state from v0.7 | actual `QuadEncoder` import | original codec tests and conditional action variable |
| ALPHA-012 | Track resource diffusion separately from intelligence claims | original Alpha finite-volume `diffuse` | mass conservation and bound test |
| ALPHA-013 | Maintain diverse behaviors instead of optimizing only worker score | descriptors + diversity archive | 69 occupied behavior bins recorded; coverage breaks ties **within bins** |
| ALPHA-014 | Generate bounded new logic proposals and evaluate without arbitrary execution | grammar edit and crossover, `src/experiments.mjs` | 208 tested genomes, including 200 variations; 416 training + 48 holdout trial records |
| ALPHA-015 | Record color fixation and achromatic states without false biological claims | `src/color_selection.mjs` | 16 explicitly selected scenarios, trace every generation |
| ALPHA-016 | Separate observation and post-run evaluation | `known` per-agent, `world` hidden in sensor | architectural inspection and strict sight-off tests |
| ALPHA-017 | Offline audit and replay console, not misleading live sensor | offline HTML dataset and generator | desktop and mobile browser verification, no external APIs |
| ALPHA-018 | Preserve failed mutations and report unresolved capabilities | dataset, negative-results ledger | no best-variant universal claims |

## Observable capability contract

- **Can see (synthetically):** a voxel enters the agent's local knowledge only when `SCAN` is selected, an original Ripple neuron pulse occurs, and a ray trace returns the voxel. Successful synthetic occlusion and negative controls are required. No object recognition or real camera sight is implemented.
- **Can sense depth (synthetically):** sensor rays explore more than one voxel with range encoded; `depthHits` counts *observations, including repeats*, not unique objects or metric hardware range estimates.
- **Can reproduce (digitally):** `CLONE` action with sufficient synthetic energy and time produces a new worker running a fresh original LIF instance with an inherited and possibly mutated genome. No OS process cloning or unauthorized cloud deployment.
- **Can create a new logic configuration:** mutation/crossover generate a valid executable decision list from finite rule types. It is a new configuration of old primitives, not arbitrary new machine intelligence or entirely new source code.
- **Can build memories:** each agent keeps a local occupancy dictionary only when that trait is switched on. Shared global map is used for offline evaluation, not path decisions.
- **Can exchange knowledge:** explicit SHARE sends a bounded number of map entries to another reachable agent. SHARING can remain ineffective if no new information exists; these cases are retained.
- **Can diffuse:** resources exchange by conservative finite-volume updates; not new matter creation.
- **Can show color lineage:** a software RGB triple and threshold-derived labels, not biological genes or physical light wavelengths.

## Safety constraints

- No arbitrary shell commands, eval, network calls, secrets, repository writes or game-world changes in the generated program interpreter.
- Candidate rules are validated before evaluation; invalid features, bounds or genome markers reject with errors.
- Up to 8 rules per organism and 16 agents per run; bounded iterations and ray range.
- Physical hardware not connected; do not issue robot-motor commands from this simulation.
- Original neuron kernel and previous Alpha sources remain locked. Do not substitute improved-looking results for independent empirical validation.
- No self-issued permanent tool permissions, no long-running autonomous background service, no hidden cloud spending.

## Next gate (not implemented)

Implement a real sensor adapter with calibrated camera/depth data and evidence-driven occlusion uncertainty. Evaluate old and hybrid algorithms on the **same unseen physical recordings** before enabling any motor controls. Later, only after permission and platform-specific tests, map the agent observation protocol to Luanti or other world engines.
