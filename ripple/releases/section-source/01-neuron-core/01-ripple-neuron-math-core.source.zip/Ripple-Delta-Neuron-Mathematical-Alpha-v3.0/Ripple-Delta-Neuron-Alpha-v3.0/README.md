# Ripple Δ — Delta Neuron Mathematical Alpha v3.0.0-alpha.1

An **actual new mathematical neuron implementation**, built from prior Ripple mathematics. It does not replace or modify the frozen original; original baseline is **Ripple Neuron v0.1 (2026)**, SHA-256 `dba6639b7902f0c702d15fff588524629f3754cfd72d7b704f22a76b78960ee3`.

## Use it offline

Open `Ripple-Delta-Neuron-Alpha-v3.0.html` in a modern browser. All equations and code are embedded; adjust simulated RGB, choose Delta mechanisms and click Start / Single step / Light step; watch both the Delta and original model. Run the 120 s comparison, export trace JSON. No internet, Python, cloud provider, or developer setup is necessary for the standalone file.

## Use the mathematical compiler

With Node.js 18+ installed:

```bash
node src/ripple-math-cli.mjs list
node src/ripple-math-cli.mjs schema
node src/ripple-math-cli.mjs eval '{"formula":"delta_ripple","mode":"summary","inputs":{"dt":0.05,"samples":[[0.35,0,0],[0.35,0,0],[0.70,0,0],[0.70,0,0]]}}'
node src/ripple-math-cli.mjs eval '{"formula":"beer_lambert","mode":"forward","inputs":{"I0":1,"mu":0.35,"L":2}}'
node --test tests/*.test.mjs
node src/benchmark.mjs
```

`formula-compiler.mjs` is an allowlisted registry, not an arbitrary JavaScript expression evaluator. Input lengths/parameters are bounded. The `run` mode returns a numerical time series and `summary` returns compact trace rows.

## Model

See `docs/SCIENCE_AND_LIMITS.md` for full equations, analytic membrane solution, source references, physical limitations, and what “metaphysical structure” can/cannot mean scientifically.

## Evidence

- **CALCULATED:** exact homogeneous Beer–Lambert and two-exponential membrane solution conditional on their assumptions.
- **SIMULATED:** all neuron firing rates, contrast responses, adaptations, and synthetic optical attenuation in this release.
- **MEASURED:** none; no calibrated sensor or living tissue data obtained.
- **PROPOSED:** treating this as an empirical sensor-neuron interface or neurological model; requires external calibration and independent validation.
- Benchmark output: `results/benchmark.json` (`600` numerical executions, five named conditions × 20 seeded runs × 6 mathematical variants; only noise scenarios vary by seed). Negative results included.

See `docs/ENGINEERING_DECISIONS.md`, `results/browser-smoke.json` and `results/node-tests.txt`.

## Preservation and provenance

The old original kernel is at `legacy/ripple-core.js`; the *prior* offline compiler UI is at `legacy/compiler-v2.1.1.html` and the original (unchanged) copy at project root; historical Charlie formula study at `references/CHARLIE_MATHEMATICAL_STUDY.md`. License/attribution for individual inherited sources must be checked before further redistribution; new Delta code does not alter licenses retroactively.
