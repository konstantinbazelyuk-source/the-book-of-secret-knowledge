import test from 'node:test';import assert from 'node:assert/strict';import {readFileSync} from 'node:fs';import vm from 'node:vm';
const html=readFileSync(new URL('../Ripple-Mathematics-Compiler-v2.1.1.html',import.meta.url),'utf8');
const script=html.match(/<script type="module">([\s\S]*?)<\/script>/i)?.[1];
test('standalone contains fully bundled mathematical engine and no external imports',()=>{
 assert.ok(script);assert.equal(/\bimport\s/.test(script),false);
 assert.ok(html.includes('I = I₀ e'));assert.ok(html.includes('Calculated — not measured'));
});
test('compiled standalone computes forward, inverses and rejects negative coefficient',()=>{
 const ctxCanvas={clearRect(){},beginPath(){},moveTo(){},lineTo(){},stroke(){},fillText(){},set fillStyle(x){},set strokeStyle(x){},set lineWidth(x){},set font(x){}};
 const store=new Map();
 function get(id){if(!store.has(id))store.set(id,{id,value:'',textContent:'',className:'',dataset:{},hidden:false,width:700,height:160,listeners:{},addEventListener(kind,fn){this.listeners[kind]=fn},getContext(){return ctxCanvas}});return store.get(id);}
 get('mode').value='forward';get('I0').value='1';get('mu').value='0.35';get('L').value='2';get('I').value='0.4965853037914095';
 const sandbox={document:{getElementById:get},console};
 vm.runInNewContext(script,sandbox,{timeout:2500});
 assert.equal(get('result').dataset.status,'ok');
 assert.ok(Math.abs(Number(get('outIntensity').textContent)-.4965853)<1e-6);
 get('mode').value='solve_mu';get('mode').listeners.change();get('I0').value='1';get('I').value='.5';get('L').value='1';get('evaluate').listeners.click();
 assert.equal(get('result').dataset.status,'ok');const r=JSON.parse(get('result').textContent);
 assert.ok(Math.abs(r.result.mu-Math.LN2)<1e-12);
 get('mode').value='forward';get('mode').listeners.change();get('mu').value='-1';get('evaluate').listeners.click();
 assert.equal(get('result').dataset.status,'error');
});
