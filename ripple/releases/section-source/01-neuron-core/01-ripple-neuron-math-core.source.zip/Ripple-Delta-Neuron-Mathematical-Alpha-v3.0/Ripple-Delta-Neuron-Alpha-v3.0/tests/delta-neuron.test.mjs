import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import {DeltaRippleNeuron,membraneAt,deltaOpticalInput} from '../src/delta-neuron.mjs';
import {listFormulas,executeRecipe} from '../src/formula-compiler.mjs';
const near=(a,b,tol=1e-9)=>Math.abs(a-b)<=tol*Math.max(1,Math.abs(a),Math.abs(b));
const n=(x=3000,rgb=[.35,0,0],options={})=>{const r=new DeltaRippleNeuron(options);let total=0;for(let i=0;i<x;i++)total+=r.step(rgb,.05).count;return {r,total};};
test('immutable original v0.1 spike-window regression independent of new code',()=>{
 const sandbox={};vm.runInNewContext(readFileSync(new URL('../legacy/ripple-core.js',import.meta.url),'utf8'),sandbox);
 const res=sandbox.runExperiment().windows;
 assert.equal(res[1].adaptive_hz,.95);assert.equal(res[1].fixed_hz,3.4);
});
test('original weights remain exactly 2, 1.2, -1.4 for default raw input',()=>{
 const z=new DeltaRippleNeuron().step([.3,.4,.1],.05);
 assert.ok(near(z.tonic,.3*2+.4*1.2-.1*1.4));assert.equal(z.delta,0);
});
test('no events in permanent darkness including nonzero adaptation settings',()=>{
 const {r,total}=n(2000,[0,0,0]);assert.equal(total,0);assert.equal(r.rate,0);assert.equal(r.u,0);
});
test('optical map identity if attenuation is absent and srgb decoding is off',()=>{
 assert.deepEqual(deltaOpticalInput([0,.32,1]),[0,.32,1]);
});
test('physically defined optical attenuation matches Beer-Lambert numerical law',()=>{
 const x=deltaOpticalInput([.4,.3,.1],{attenuation:{mu:[.2,.4,.6],L:2}});
 assert.ok(x.every((v,i)=>near(v,[.4,.3,.1][i]*Math.exp(-[.2,.4,.6][i]*2))));
});
test('gamma decoding standard reference',()=>{
 assert.ok(near(deltaOpticalInput([.5,0,1],{srgb:true})[0],.21404114048223255));
});
test('exact membrane analytical solution against small-step independent RK4 solver',()=>{
 function rhs(u,a,D,tv,ta){return [(-u+D-a)/tv,-a/ta];}
 let u=.22,a=.13;const tv=.5,ta=2.1,D=.71,h=.37,dt=h/10000;
 for(let k=0;k<10000;k++){
  const f=(U,A)=>rhs(U,A,D,tv,ta); const [u1,a1]=f(u,a);const [u2,a2]=f(u+u1*dt/2,a+a1*dt/2);
  const [u3,a3]=f(u+u2*dt/2,a+a2*dt/2);const [u4,a4]=f(u+u3*dt,a+a3*dt);
  u+=dt*(u1+2*u2+2*u3+u4)/6;a+=dt*(a1+2*a2+2*a3+a4)/6;
 }
 assert.ok(near(membraneAt(.22,D,.13,h,tv,ta),u,3e-10));
});
test('equal membrane/adaptation time constants have analytic finite limit',()=>{
 const got=membraneAt(.1,.5,.12,.4,.5,.5);
 const expected=.5+(.1-.5)*Math.exp(-.8)-.12*(.4/.5)*Math.exp(-.8);
 assert.ok(near(got,expected));
});
test('light increment gives positive signed delta, decrement gives negative',()=>{
 const r=new DeltaRippleNeuron({feedback:false,feedforward:false});
 r.step([.15,0,0],.05);const increase=r.step([.45,0,0],.05);
 const decrease=r.step([.15,0,0],.05);
 assert.ok(increase.delta>0);assert.ok(decrease.delta<0);
});
test('stable repeated intensity has zero transient after first sample',()=>{
 const r=new DeltaRippleNeuron();r.step([.2,.1,.1],.05);
 for(let i=0;i<150;i++)assert.equal(r.step([.2,.1,.1],.05).delta,0);
});
test('sustained adaptation decays and spike-triggered adaptation rises',()=>{
 const r=new DeltaRippleNeuron({feedforward:false,feedback:false,adaptJump:.12});
 let seen=false,atSpike=0;
 for(let i=0;i<200;i++){const a=r.step([.8,.3,0],.05);if(a.count){seen=true;atSpike=a.adaptation;break;}}
 assert.ok(seen);assert.ok(atSpike>.115);
 for(let i=0;i<100;i++)r.step([0,0,1],.05);
 assert.ok(r.a<atSpike);
});
test('all state fields finite and threshold bounded under seeded stressful signals',()=>{
 let seed=123456789;const random=()=>((seed=(1664525*seed+1013904223)>>>0)/4294967296);
 const r=new DeltaRippleNeuron({logK:4});
 for(let i=0;i<40000;i++){
  const z=r.step([random(),random(),random()],.05);
  for(const k of ['u','adaptation','theta','rate','tonic','drive'])assert.ok(Number.isFinite(z[k]));
  assert.ok(z.theta>=.15&&z.theta<=2.5);assert.ok(z.adaptation>=0);
 }
});
test('seeded traces are byte-reproducible without nondeterministic noise',()=>{
 const produce=()=>{const r=new DeltaRippleNeuron();const t=[];for(let i=0;i<300;i++){
  const z=r.step([i%23/23,(i%17)/17,.1],.05);t.push([z.u,z.theta,z.rate,z.count]);
 }return t};assert.deepEqual(produce(),produce());
});
test('invalid sample domain and unsafe settings rejected',()=>{
 for(const rgb of [[NaN,0,0],[1.01,0,0],[-.1,0,0],[0,0],[Infinity,0,0]])assert.throws(()=>new DeltaRippleNeuron().step(rgb,.05));
 for(const opts of [{theta:-1},{logFloor:0},{maxLogChange:Infinity},{tauA:-2},{unknownFlag:1},{attenuation:{mu:[.1,.1],L:1}}])assert.throws(()=>new DeltaRippleNeuron(opts));
 assert.throws(()=>new DeltaRippleNeuron().step([.2,0,0],0));
});
test('compiler formula is allowlisted, finite, and executable on real model',()=>{
 assert.ok(listFormulas().some(f=>f.id==='delta_ripple'));
 const out=executeRecipe({formula:'delta_ripple',mode:'run',inputs:{samples:Array(200).fill([.35,0,0]),dt:.05}});
 assert.equal(out.trace.length,200);assert.ok(out.totalModelEvents>0);
 assert.throws(()=>executeRecipe({formula:'delta_ripple',mode:'summary',inputs:{samples:[[.25,NaN,0]],dt:.05}}));
 assert.throws(()=>executeRecipe({formula:'delta_ripple',mode:'summary',inputs:{samples:Array(10001).fill([.25,0,0]),dt:.05}}));
});
test('quaternary telemetry has distinct two-bit encodings including signed zero', async ()=>{
 const {encodeDeltaSymbol}=await import('../src/delta-neuron.mjs');
 assert.equal(encodeDeltaSymbol(-1,.7).bits,'00');
 assert.equal(encodeDeltaSymbol(0,-.2).bits,'01');
 assert.equal(encodeDeltaSymbol(0,.2).bits,'10');
 assert.equal(encodeDeltaSymbol(1,.2).bits,'11');
});
test('compiler metadata never reports simulated Delta neuron as a measurement',async()=>{
 const {compileFormula}=await import('../src/formula-compiler.mjs');
 assert.equal(compileFormula({formula:'delta_ripple',mode:'run'}).metadata.evidence,'SIMULATED');
 assert.equal(compileFormula({formula:'beer_lambert',mode:'forward'}).metadata.evidence,'CALCULATED');
});
