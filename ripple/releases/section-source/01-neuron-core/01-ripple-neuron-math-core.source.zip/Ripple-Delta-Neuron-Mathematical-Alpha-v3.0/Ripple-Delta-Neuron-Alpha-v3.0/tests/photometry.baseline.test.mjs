import test from 'node:test';
import assert from 'node:assert/strict';
import {photonEnergyJ,srgbEncode,srgbDecode,beerLambert,inverseSquareIrradiance,fresnelNormalIncidence,calibratedRatio,validatedRecordedImage} from '../src/photometry.mjs';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const approx=(a,b,tol=1e-11)=>Math.abs(a-b)<tol;
test('locked original Ripple v0.1 source has original SHA-256',()=>{
 const p=new URL('../legacy/ripple-core.js',import.meta.url);
 assert.equal(createHash('sha256').update(readFileSync(p)).digest('hex'),'dba6639b7902f0c702d15fff588524629f3754cfd72d7b704f22a76b78960ee3');
});
test('sRGB decoding reference breakpoints and exact inversion',()=>{
 for(const x of [0,.003,.04045,.1,.25,.5,.9,1])assert.ok(approx(srgbEncode(srgbDecode(x)),x,5e-8));
 assert.ok(approx(srgbDecode(.5),.21404114048223255));
});
test('Beer-Lambert exponential, multiplicative path and zero absorption',()=>{
 assert.ok(approx(beerLambert(1,Math.log(2),1),.5));
 assert.ok(approx(beerLambert(beerLambert(2,.35,1),.35,2),beerLambert(2,.35,3)));
 assert.equal(beerLambert(.75,0,8),.75);
});
test('ideal point-source inverse square and Lambert cosine illumination',()=>{
 assert.ok(approx(inverseSquareIrradiance(1,2),inverseSquareIrradiance(1,1)/4));
 assert.ok(approx(inverseSquareIrradiance(2,1,Math.PI/3),1));
});
test('Fresnel normal interface for ideal nonabsorbing dielectrics',()=>{
 assert.ok(approx(fresnelNormalIncidence(1,1.5),.04));
 assert.ok(approx(fresnelNormalIncidence(1.5,1),.04));
});
test('photon energy formula eV at 550 nm is approximately 2.254',()=>{
 const ev=photonEnergyJ(550)/1.602176634e-19;
 assert.ok(Math.abs(ev-2.2542)<.0002);
});
test('calibrated camera ratios reject clipping, poor contrast and out of span',()=>{
 assert.equal(calibratedRatio({sample:100,dark:10,clear:190}).valid,true);
 assert.ok(approx(calibratedRatio({sample:100,dark:10,clear:190}).transmission,.5));
 assert.equal(calibratedRatio({sample:252,dark:10,clear:190}).valid,false);
 assert.equal(calibratedRatio({sample:14,dark:10,clear:18}).valid,false);
 assert.equal(calibratedRatio({sample:200,dark:10,clear:190}).valid,false);
});
test('sensor adapter rejects fake provenance and labels',()=>{
 const a={provenance:'recorded_scanner',dataset:'sklearn_digits_1998',datasetIndex:3,pixels:Array(64).fill(0)};
 assert.equal(validatedRecordedImage(a).pixels.length,64);
 assert.throws(()=>validatedRecordedImage({...a,provenance:'real_camera'}),/provenance/);
 assert.throws(()=>validatedRecordedImage({...a,groundTruth:1}),/Leaked label/);
 assert.throws(()=>validatedRecordedImage({...a,pixels:[1,2,3]}),/shape/);
});
test('all optical laws reject impossible parameters rather than silently invent output',()=>{
 assert.throws(()=>beerLambert(1,-1,1));assert.throws(()=>inverseSquareIrradiance(1,0));
 assert.throws(()=>fresnelNormalIncidence(-1,1));assert.throws(()=>photonEnergyJ(0));
});
