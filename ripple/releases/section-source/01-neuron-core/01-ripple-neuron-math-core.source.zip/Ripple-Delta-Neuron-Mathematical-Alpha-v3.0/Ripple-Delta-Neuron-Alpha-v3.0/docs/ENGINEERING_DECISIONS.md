# Engineering choices and review gates — Delta Ripple

**Frozen/locked:** Original `legacy/ripple-core.js` SHA-256 `dba6639b7902f0c702d15fff588524629f3754cfd72d7b704f22a76b78960ee3`; original Ripple Mathematics Compiler Beer–Lambert API and tests; original RGB weighting `2,1.2,-1.4`.

**New/experimental:** `src/delta-neuron.mjs` with dynamic tonic/transient contrast, exact between-event two-exponential membrane evolution, spike adaptation, feasible analytic feedforward, original feedback, and quaternary telemetry. `src/formula-compiler.mjs` adds the allowlisted formula ID `delta_ripple`, modes `run` and `summary`. The formula receives an array of `RGB` triplets and fixed model sample period. No arbitrary scripts, network calls, or camera access in compiler.

**Not merged:** Other modules—mycelium workers, molecular density, colony evolution, physical robot control—remain separate because units and causal provenance have not been independently reconciled. Sensor density/occlusion can be added as a typed transform *before* the neuron only with evidence guards. Neither the user source study nor peer reviewed science supports claiming a metaphysical field measurement.

**Not promoted:** Initial feedforward + spike-adaptation defaults failed to beat original constant/staged light target tracking. Those options remain research toggles, not a replacement for the control. The 120 s scripted step comparison is **not a blinded test**. Some seeds in the 600-case comparison are repetitions of deterministic conditions: only the noise stimulus varies across 20 seeds. See `results/benchmark.json` for per-run records.

**Machine-readable output:** State: u, adaptation, rate, threshold, tonic, transient, four-state encoding, spike times. Uniform mean rate over windows `W`: model spikes in `W` divided by elapsed model seconds. Frequency is a model event rate, not optical carrier frequency.

**Release acceptance:** All inherited/new tests pass, off-line dashboard desktop and mobile DOM interaction smoke tests pass, SHA-256 preserved, no physical observation claims, negative comparisons reported. New Beta not deployed/overwritten.
