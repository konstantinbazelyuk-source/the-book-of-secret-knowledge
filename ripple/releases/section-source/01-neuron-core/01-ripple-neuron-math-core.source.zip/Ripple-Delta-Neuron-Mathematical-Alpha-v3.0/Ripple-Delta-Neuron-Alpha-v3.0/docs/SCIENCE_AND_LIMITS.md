# Delta Ripple v3.0 — Scientific mapping, proofs, and evidence boundaries

## Governing mathematical definition (new model, not a newly established law)

Inputs: normalized, dimensionless RGB `x_i` in `[0,1]`; model sample period `h` seconds. No device-provided physical optical field is presumed. Weights `w=(2,1.2,-1.4)` are inherited from preserved Ripple v0.1 and are not a measured spectral sensitivity curve.

Optical preprocessing: optional `x_i -> sRGB_decode(x_i) -> x_i exp(-mu_i L)`; `mu_i` must be provided with inverse-length units and `L` in matching length units; unless derived from calibrated observations, the attenuation result is synthetic. Optional compression `C(x)=ln(1+kx)/ln(1+k)` for `k>0`, and identity otherwise.

Continuous/sampled hybrid dynamics:

```
S = Σ_i w_i C(x_i)
δ_i = gate_{g}( clamp[ln(x_i(t)+ε)-ln(x_i(t-h)+ε), ±δ_max] )
Δ = Σ_i w_i δ_i
D = S + γ Δ
τ_v du/dt = -u + D - a
τ_a da/dt = -a
when u hits θ: event; u ← 0; a ← a+b; refractory t_ref
rhat(t+h) = rhat(t)e^{-h/τ_r} + Σ_event e^{-(t+h-t_event)/τ_r}/τ_r
θ* = S[1-exp(-(1/f_target-t_ref)/τ_v)]   (feasible steady-state LIF approximation only)
θ_next=clip(θ + α(θ*−θ) + η(∫_t^{t+h} rhat(s)ds - f_target h), θ_min, θ_max)
α=(1-exp(-h/τ_FF)) × feedforward_gain
```

`a` in the original EPFL papers represents a *different notation* for subthreshold adaptation; here we use `a` as a **dimensionless spike-triggered adaptation trace**. The adaptation component is simpler than the full published AdEx model, which has an exponential spike-initiation nonlinearity. Do **not** describe Delta Ripple as an experimentally fitted AdEx neuron.

**Exact held-drive, between-spike membrane solution:** Let `m0 = u(t)`, `a0=a(t)`, and hold `D` constant for `h`. For `tau_a≠tau_v`,

```
u(t+h)=D+(m0-D)e^{-h/τv}
          -a0 τa/(τa-τv) [e^{-h/τa}-e^{-h/τv}]
a(t+h)=a0 e^{-h/τa}
```

When `τa=τv=τ`, subtract `a0(h/τ)e^{-h/τ}` instead. The implementation searches the crossing on a bounded grid and refines it by bisection, rather than numerically integrating u by forward Euler. Thus the between-event evolution is analytic for frozen D and the event time is numerically bracketed. The grid can fail to detect exceptionally brief crossings *inside* a bin; no universal event-time accuracy has been established. Refractory integration maintains the adaptation decay.

**Threshold feedforward limitation:** `θ*` is exact only for the original simple LIF under *constant positive drive* and no adaptation or transient term. Once an adaptation current or an oscillating optical signal is present, using it is heuristic. Benchmarks show it can worsen firing-rate tracking, so it must not be described as universally beneficial. For feasible target, `0<f_target<1/t_ref`, `S>0`, and `theta_star` within bounds; otherwise the feedforward term is disabled.

## What scientifically established systems it resembles

| Ripple mathematical mechanism | Established real structure | What is *not* established |
|---|---|---|
| Exponential Beer–Lambert transmission | Absorption of appropriately calibrated narrowband light in homogeneous non-scattering media | Three RGB camera outputs are not measured physical absorption spectra; the app has no sensor calibration |
| Leaky membrane and RC time constant | Cell membrane passive electrical dynamics `τ_m=C_m/g_L`; membrane voltage leakage | Our voltage `u` is dimensionless; `C_m`, `g_L` and real membrane voltages have not been measured |
| Spike-triggered slow decay | Neural adaptation currents including calcium-dependent potassium mechanisms | `adaptJump` and `tauA` have not been fitted to living tissue |
| Opponent ON/OFF transient response | Retinal ON/OFF signaling and contrast-sensitive pathways | Whole-image RGB differences do not replicate retinal cellular circuitry |
| Threshold feedback and reciprocal-homeostasis approximation | Mathematical feedback control | No proof of globally optimal homeostasis; target may be infeasible |
| Signed four-state telemetry | Digital two-bit quaternary encoding | Not a physical four-level quantum state, nor a new number system |

### About 'metaphysical structure'

The retrieved source corpus and scientific references do not establish experimentally verified equations for metaphysical energy, consciousness, intentional influence on light, or extrasensory fields. The engineering product therefore attaches to **testable physical analogues** (optics, RC dynamics, adaptation and measured electrical instrumentation), not a fabricated proof of a metaphysical effect. A philosophical analogy may be discussed but carries no physical evidence status. Nothing in the model measures a human aura, consciousness, or concentration.

## Sources actually reviewed

1. Original locked Ripple v0.1 source: `legacy/ripple-core.js` SHA-256 in `SOURCE_HASHES.json`.
2. Charlie's 56-source-attributed formula study recovered from Library: `references/CHARLIE_MATHEMATICAL_STUDY.md` (original source retained verbatim).
3. Ripple Mathematics Compiler v2.1.1, frozen original output: `Ripple-Mathematics-Compiler-v2.1.1.html`, original Beer–Lambert op retained within new compiler source.
4. Brette & Gerstner (2005), *Adaptive Exponential Integrate-and-Fire Model as an Effective Description of Neuronal Activity*, https://doi.org/10.1152/jn.00686.2005 (background comparison, NOT proof this implementation is that model).
5. EPFL Neuronal Dynamics, Ch. 6 §1, https://neuronaldynamics.epfl.ch/online/Ch6.S1.html (adaptation and spike-triggered trace).
6. Review of Beer–Lambert limitations: https://pmc.ncbi.nlm.nih.gov/articles/PMC8553265/ (scattering and spectral bandwidth warnings).
7. Existing Ripple compiler code, `src/photometry.mjs` (sRGB, Beer–Lambert, other established optical calculations).

## Research record

The existing v0.1 model remains the control in every comparison. All numerical outputs are SIMULATED. Real light and living neural tissue are NOT part of the experiment. Physical advancement requires AS7341/photodiode spectra or other calibrated capture with confidence intervals, followed by cross-device test–retest, an independent held-out dataset, and a biophysical model fit where relevant.
