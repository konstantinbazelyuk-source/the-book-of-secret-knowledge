#!/usr/bin/env node
/** Predeclared numerical comparison. Not measured signal or brain data. */
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import vm from 'node:vm';
import {DeltaRippleNeuron} from './delta-neuron.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const sb={};vm.runInNewContext(readFileSync(path.join(root,'legacy/ripple-core.js'),'utf8'),sb);
const seeds=Array.from({length:20},(_,i)=>32917+7919*i);
const scenarios=['steady','step','color_swap','pulsed','noise'];
const rows=[],STEP=.05,STEPS=2400;
function sequence(name,seed){
 let s=seed;const rand=()=>((s=(1664525*s+1013904223)>>>0)/4294967296);
 const frames=[];
 for(let i=0;i<STEPS;i++){
  const t=i*STEP;let r=.35,g=0,b=0;
  if(name==='steady')r=.35;
  if(name==='step')r=t<40||t>=80?.35:.7;
  if(name==='color_swap'){if(t>=40&&t<80){r=.2;g=.4;b=.08;}}
  if(name==='pulsed')r=(Math.floor(t/5)%2===0)? .18:.68;
  if(name==='noise'){r=.35+(rand()-.5)*.08;g=.04+(rand()-.5)*.04;b=.015+(rand()-.5)*.03;}
  frames.push([Math.max(0,r),Math.max(0,g),Math.max(0,b)]);
 }return frames;
}
const flavors=[
 ['legacy',null],
 ['delta_default',{}],
 ['delta_without_transient',{deltaEnabled:false}],
 ['delta_without_ff',{feedforward:false}],
 ['delta_without_spike_adaptation',{spikeAdapt:false}],
 ['delta_log_photometry',{logK:8,srgb:true}]
];
for(const name of scenarios)for(const seed of seeds){
 const xs=sequence(name,seed);
 for(const [variant,config] of flavors){
  const m=variant==='legacy'?new sb.RippleNeuron():new DeltaRippleNeuron(config);
  const windows=[{from:20,to:40},{from:60,to:80},{from:100,to:120}];
  let spikes=0;const wCounts=windows.map(()=>0);let thetaEnd=NaN,delay=null,deltaEvents=0;
  for(let i=0;i<STEPS;i++){
   const t=i*STEP,z=m.step(xs[i],STEP);spikes+=z.count;
   for(let j=0;j<windows.length;j++)if(t>=windows[j].from&&t<windows[j].to)wCounts[j]+=z.count;
   if(name==='step'&&t>=40&&delay===null&&z.count)delay=t-40;
   if(variant!=='legacy'&&Math.abs(z.delta)>.01)deltaEvents++;
   thetaEnd=z.theta;
  }
  const rates=wCounts.map(n=>n/20);
  const absError=rates.reduce((s,r)=>s+Math.abs(r-1),0)/3;
  rows.push({scenario:name,seed,variant,counts:wCounts,rates,absError,targetHz:1,totalSpikes:spikes,thetaEnd,firstEventDelayAfter40s:delay,nonzeroContrastSteps:deltaEvents});
 }
}
const grouped=[];
for(const name of scenarios)for(const [variant] of flavors){
 const rs=rows.filter(r=>r.scenario===name&&r.variant===variant);
 const mean=x=>x.reduce((a,b)=>a+b,0)/x.length;
 grouped.push({scenario:name,variant,trials:rs.length,meanAbsError:mean(rs.map(x=>x.absError)),meanWindows:[0,1,2].map(i=>mean(rs.map(x=>x.rates[i]))),meanSpikes:mean(rs.map(x=>x.totalSpikes)),meanNonzeroContrast:mean(rs.map(x=>x.nonzeroContrastSteps))});
}
const legacy=sb.runExperiment().windows;
const result={study:'Ripple Delta Alpha v3, synthetic fixed cases',evidence:'SIMULATED',dt:STEP,totalRuns:rows.length,seeds,scenarios,variants:flavors.map(x=>x[0]),legacyControl:{baselineTest:legacy,sha256:'dba6639b7902f0c702d15fff588524629f3754cfd72d7b704f22a76b78960ee3'},grouped,rows};
mkdirSync(path.join(root,'results'),{recursive:true});
writeFileSync(path.join(root,'results','benchmark.json'),JSON.stringify(result,null,2));
writeFileSync(path.join(root,'results','benchmark-summary.json'),JSON.stringify({runs:rows.length,grouped},null,2));
console.log(`Trials ${rows.length} (${scenarios.length} scenarios × ${seeds.length} seeds × ${flavors.length} variants)`);
console.log('Mean absolute firing-rate target error, units model Hz:');
for(const s of scenarios){console.log('\n'+s);for(const g of grouped.filter(x=>x.scenario===s))console.log(`${g.variant.padEnd(34)} ${g.meanAbsError.toFixed(4)} windows=${g.meanWindows.map(x=>x.toFixed(2)).join(',')}`)}
