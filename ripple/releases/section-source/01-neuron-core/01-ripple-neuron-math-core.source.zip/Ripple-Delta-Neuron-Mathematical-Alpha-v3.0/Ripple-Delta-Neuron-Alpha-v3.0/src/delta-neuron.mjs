/**
 * Ripple Δ (Delta) Neuron Alpha v3.0, a NEW and independently versioned model.
 * The frozen v0.1 Ripple in legacy/ripple-core.js is not altered.
 * Physics-inspired parts: exponential radiometric attenuation, leaky first-order
 * membrane, exponential adaptation, log temporal contrast, homeostatic feedback.
 * THESE DIMENSIONLESS PARAMETERS ARE SOFTWARE DESIGN VALUES, NOT BIOPHYSICAL FITS.
 * Source relationships/assumptions: docs/SCIENCE_AND_LIMITS.md.
 */
import {beerLambert, srgbDecode} from './photometry.mjs';
const clip = (x,a,b)=>Math.max(a,Math.min(b,x));
function finite(x,key){if(typeof x!=='number'||!Number.isFinite(x))throw new RangeError(`${key} must be a finite number`);return x;}
const DEFAULTS=Object.freeze({
  tauV:0.5,tauA:3,tauR:5,tRef:0.1,theta:0.45,
  thetaMin:0.15,thetaMax:2.5,targetHz:1,
  eta:0.08,tauFF:4,ffGain:1,
  logK:0,logFloor:0.02,deltaGain:0.22,deltaGate:0.06,
  maxLogChange:0.9,adaptJump:0.02,
  feedforward:true,feedback:true,deltaEnabled:true,spikeAdapt:true,
  srgb:false,attenuation:null
});
function validateOptions(options){
  if(!options||typeof options!=='object'||Array.isArray(options))throw new TypeError('options object required');
  for(const key of Object.keys(options))if(!(key in DEFAULTS))throw new RangeError(`Unknown option: ${key}`);
  const o={...DEFAULTS,...options};
  const domain={tauV:[.01,30],tauA:[.02,120],tauR:[.1,120],tRef:[0,2],theta:[.01,10],thetaMin:[.01,10],thetaMax:[.02,20],targetHz:[.01,10],eta:[0,2],tauFF:[.05,100],ffGain:[0,1],logK:[0,100],logFloor:[.0001,.5],deltaGain:[0,5],deltaGate:[0,1],maxLogChange:[.05,5],adaptJump:[0,5]};
  for(const [k,[a,b]] of Object.entries(domain))if(finite(o[k],k)<a||o[k]>b)throw new RangeError(`${k} outside [${a},${b}]`);
  if(o.thetaMax<=o.thetaMin||o.theta<o.thetaMin||o.theta>o.thetaMax)throw new RangeError('Invalid threshold bounds');
  if(o.targetHz>=1/(o.tRef||1e-10))throw new RangeError('Target exceeds refractory-limit rate');
  for(const b of ['feedforward','feedback','deltaEnabled','spikeAdapt','srgb'])if(typeof o[b]!=='boolean')throw new TypeError(`${b} must be boolean`);
  if(o.attenuation!==null){
    const {mu,L}=o.attenuation;
    if(!Array.isArray(mu)||mu.length!==3)throw new RangeError('attenuation.mu: exactly three coefficients');
    for(let i=0;i<3;i++)if(finite(mu[i],`mu[${i}]`)<0||mu[i]>20)throw new RangeError('attenuation coefficient outside [0,20]');
    if(finite(L,'attenuation.L')<0||L>5)throw new RangeError('attenuation path outside [0,5]');
    if(mu.some(m=>m*L>100))throw new RangeError('Optical depth exceeds numerical guard');
    o.attenuation={mu:[...mu],L};
  }
  return Object.freeze(o);
}
export const DELTA_DEFAULTS=DEFAULTS;
/** Signed four-state telemetry; each symbol is carried by exactly two bits. */
export function encodeDeltaSymbol(delta,tonic,threshold=.06){
  finite(delta,'delta');finite(tonic,'tonic');
  if(finite(threshold,'threshold')<0)throw new RangeError('threshold must be nonnegative');
  if(delta>threshold)return Object.freeze({state:'1',bits:'11',meaning:'increasing encoded drive'});
  if(delta< -threshold)return Object.freeze({state:'-1',bits:'00',meaning:'decreasing encoded drive'});
  if(tonic<0)return Object.freeze({state:'-0',bits:'01',meaning:'stable inhibition'});
  return Object.freeze({state:'0',bits:'10',meaning:'stable neutral/excitatory drive'});
}

/** Forward optical preprocessing: input is display-referred normalized RGB, not radiant flux. */
export function deltaOpticalInput(rgb,options={}){
  if(!Array.isArray(rgb)||rgb.length!==3)throw new TypeError('RGB must contain three channels');
  for(const [i,v] of rgb.entries())if(finite(v,`rgb[${i}]`)<0||v>1)throw new RangeError('RGB outside [0,1]');
  const {srgb=false,attenuation=null}=options;
  if(typeof srgb!=='boolean')throw new TypeError('srgb must be boolean');
  const decoded=rgb.map(v=>srgb?srgbDecode(v):v);
  const result=attenuation?decoded.map((v,i)=>beerLambert(v,attenuation.mu[i],attenuation.L)):decoded;
  return result;
}
/** Decay-and-driven two-exponential exact evolution between spikes for held D, a0. */
export function membraneAt(u0,drive,a0,h,tauV,tauA){
  if(h===0)return u0;
  const em=Math.exp(-h/tauV),ea=Math.exp(-h/tauA);
  const adaptationTerm=Math.abs(tauA-tauV)<1e-12?
    a0*(h/tauV)*em:
    a0*tauA/(tauA-tauV)*(ea-em);
  return drive+(u0-drive)*em-adaptationTerm;
}
/** Root search over time bins + bisection; no explicit Euler spike-timing step. */
function firstCrossing(u,drive,a,theta,h,tauV,tauA){
  if(u>=theta)return 0;
  const N=32;
  let lo=0,prev=u-theta;
  for(let k=1;k<=N;k++){
    let hi=k*h/N,fhi=membraneAt(u,drive,a,hi,tauV,tauA)-theta;
    if(prev<0&&fhi>=0){
      for(let iter=0;iter<48;iter++){
        const mid=(lo+hi)/2;
        if(membraneAt(u,drive,a,mid,tauV,tauA)>=theta)hi=mid;else lo=mid;
      }
      return hi;
    }
    lo=hi;prev=fhi;
  }
  return Infinity;
}
export class DeltaRippleNeuron{
  constructor(options={}){
    this.options=validateOptions(options);
    this.t=0;this.u=0;this.a=0;this.theta=this.options.theta;
    this.rate=0;this.rest=0;this.previousLog=null;this.spikeCount=0;
  }
  reset(){const o=this.options;this.t=0;this.u=0;this.a=0;this.theta=o.theta;this.rate=0;this.rest=0;this.previousLog=null;this.spikeCount=0;}
  step(rgb,dt){
    if(finite(dt,'dt')<=0||dt>.2)throw new RangeError('dt must be in (0,0.2] seconds');
    const o=this.options;
    const linear=deltaOpticalInput(rgb,o);
    const logs=linear.map(v=>Math.log(v+o.logFloor));
    const prior=this.previousLog;
    const contrast=prior===null?[0,0,0]:logs.map((l,i)=>{
      const difference=l-prior[i];
      return Math.abs(difference)<o.deltaGate?0:clip(difference,-o.maxLogChange,o.maxLogChange);
    });
    this.previousLog=logs;
    const sustained=linear.map(v=>o.logK>0?Math.log1p(o.logK*v)/Math.log1p(o.logK):v);
    const w=[2,1.2,-1.4];
    const S=w.reduce((acc,c,i)=>acc+c*sustained[i],0);
    // Signed log contrasts: the physical ON/OFF evidence is kept distinct.
    const delta=contrast.reduce((acc,c,i)=>acc+w[i]*c,0);
    const transient=o.deltaEnabled?o.deltaGain*delta:0;
    const drive=S+transient;
    const start=this.t,events=[];
    let elapsed=0;
    while(elapsed<dt-1e-12){
      const h=dt-elapsed;
      if(this.rest>1e-12){
        const held=Math.min(h,this.rest);
        this.a*=Math.exp(-held/o.tauA);
        this.rest=Math.max(0,this.rest-held);this.u=0;elapsed+=held;
        continue;
      }
      const crossing=firstCrossing(this.u,drive,this.a,this.theta,h,o.tauV,o.tauA);
      if(Number.isFinite(crossing)&&crossing<=h){
        const tEvent=elapsed+crossing;
        this.a*=Math.exp(-crossing/o.tauA);
        elapsed=tEvent;
        events.push(start+elapsed);this.spikeCount++;
        this.u=0;this.rest=o.tRef;
        if(o.spikeAdapt)this.a+=o.adaptJump;
        if(events.length>Math.ceil(dt/Math.max(o.tRef,0.001))+2)throw new RangeError('Unphysical excessive spike count');
      }else{
        this.u=membraneAt(this.u,drive,this.a,h,o.tauV,o.tauA);
        this.a*=Math.exp(-h/o.tauA);
        elapsed=dt;
      }
    }
    const e=Math.exp(-dt/o.tauR);
    let integral=this.rate*o.tauR*(1-e);
    this.rate*=e;
    for(const te of events){const d=Math.exp(-(start+dt-te)/o.tauR);this.rate+=d/o.tauR;integral+=(1-d);}
    // Analytic inverse threshold from original *constant drive* LIF; heuristic
    // if adaptation, transient drive, or nonstationarity is present.
    const period=1/o.targetHz-o.tRef;
    const thetaStar=S>0&&period>0?S*(-Math.expm1(-period/o.tauV)):null;
    const feedforward=o.feedforward&&thetaStar!==null&&thetaStar>=o.thetaMin&&thetaStar<=o.thetaMax?
      o.ffGain*(-Math.expm1(-dt/o.tauFF))*(thetaStar-this.theta):0;
    const feedback=o.feedback?o.eta*(integral-o.targetHz*dt):0;
    this.theta=clip(this.theta+feedforward+feedback,o.thetaMin,o.thetaMax);
    this.t=start+dt;
    for(const [name,x] of Object.entries({u:this.u,a:this.a,theta:this.theta,rate:this.rate,t:this.t,drive}))if(!Number.isFinite(x))throw new Error(`Nonfinite state: ${name}`);
    return {t:this.t,rgb:[...rgb],light:linear,sustained,contrast,tonic:S,delta,transient,drive,
      u:this.u,adaptation:this.a,theta:this.theta,rate:this.rate,count:events.length,events,quad:encodeDeltaSymbol(delta,S,o.deltaGate),
      thetaStar,thetaStarFeasible:thetaStar!==null&&thetaStar>=o.thetaMin&&thetaStar<=o.thetaMax,
      provenance:o.attenuation?'SIMULATED_OPTOELECTRONIC_PREPROCESS':'NUMERICAL_MODEL'};
  }
}
