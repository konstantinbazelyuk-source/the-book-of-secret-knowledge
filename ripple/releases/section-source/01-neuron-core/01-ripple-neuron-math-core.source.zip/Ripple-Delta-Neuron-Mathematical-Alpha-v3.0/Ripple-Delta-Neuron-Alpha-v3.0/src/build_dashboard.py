from pathlib import Path
import re,hashlib
root=Path(__file__).resolve().parent.parent
photo=(root/'src/photometry.mjs').read_text()
delta=(root/'src/delta-neuron.mjs').read_text()
original=(root/'legacy/ripple-core.js').read_text()
delta=re.sub(r'^import \{[^}]+\} from [^\n]+\n','',delta,flags=re.M)
delta=re.sub(r'^export (const|function|class) ',r'\1 ',delta,flags=re.M)
photo=re.sub(r'^export (const|function|class) ',r'\1 ',photo,flags=re.M)
# Export-Free inline modules with a one-to-one source provenance. Original source is separate scope.
original=original.replace('globalThis.RippleNeuron=RippleNeuron;globalThis.runExperiment=runExperiment;',
                         'globalThis.LegacyRipple=RippleNeuron;globalThis.LegacyExperiment=runExperiment;')
styles='''
:root{color-scheme:light;--bg:#edf2ef;--ink:#123044;--green:#206d56;--blue:#3276a7;--line:#d0ded6;--muted:#5a707b}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font-family:system-ui,-apple-system,Segoe UI,sans-serif;line-height:1.48}
header{background:#0e2533;color:#f6fbf7;padding:22px max(20px,calc((100vw - 1160px)/2));}
header .meta{letter-spacing:.1em;text-transform:uppercase;font-size:11px;color:#b7d7cb}h1{font-size:clamp(24px,3vw,36px);margin:4px 0 6px;letter-spacing:-.03em}header p{margin:0;color:#d4e8df;font-size:14px}
main{max-width:1160px;margin:auto;padding:22px 16px 60px} .status{background:#dff0e5;border:1px solid #c2e0d0;color:#1c6142;border-radius:12px;padding:12px 15px;font-size:13px}
.grid{display:grid;grid-template-columns:360px 1fr;gap:16px;align-items:start;margin-top:16px}.panel{background:white;border:1px solid var(--line);border-radius:15px;padding:19px;box-shadow:0 1px 6px #1542340a;margin-bottom:16px}
h2{font-size:19px;margin:0 0 10px;letter-spacing:-.02em}h3{font-size:15px;margin:12px 0 8px}p{margin:8px 0;color:#425b66;font-size:13px}.small{font-size:12px;color:var(--muted)}
.control{display:block;padding:8px 0;border-bottom:1px solid #e8efea}.control>div{display:flex;align-items:center;justify-content:space-between;font-size:13px;font-weight:600}.control output{font-variant-numeric:tabular-nums}.control input[type=range]{width:100%;accent-color:var(--green)}
.toggle{display:flex;align-items:center;gap:9px;padding:7px 0;font-size:13px}.toggle input{width:19px;height:19px;accent-color:var(--green)}
.actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:14px}button{border:0;background:var(--ink);color:white;min-height:44px;border-radius:9px;padding:10px 14px;cursor:pointer;font-weight:700}button.secondary{background:#e5eee9;color:var(--ink);border:1px solid #c8d7ce}button:hover{filter:brightness(.92)}button:focus-visible,input:focus-visible{outline:3px solid #7ac5ec;outline-offset:2px}
.stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:9px;margin:12px 0}.stat{background:#eff6f1;padding:13px 8px;border-radius:9px}.stat strong{font-variant-numeric:tabular-nums;font-size:clamp(17px,2vw,25px);display:block}.stat span{display:block;font-size:11px;color:var(--muted)}
canvas{width:100%;height:245px;display:block;background:#f9fcfa;border-radius:8px;margin:9px 0}.legend{font-size:12px;color:var(--muted)}.legend b{font-size:14px}.equations{font-family:ui-monospace,SFMono-Regular,Consolas,monospace;background:#f3f7f5;border:1px solid #dae4de;padding:12px;border-radius:10px;white-space:pre-wrap;overflow:auto;font-size:12px;color:#183746}
table{border-collapse:collapse;width:100%;font-variant-numeric:tabular-nums;font-size:12px}td,th{border-bottom:1px solid #e1e9e4;text-align:left;padding:8px 6px}.scroll{overflow-x:auto}.scope{font-size:12px;margin-top:6px}
@media(max-width:780px){.grid{display:block}.stats{grid-template-columns:repeat(2,minmax(0,1fr))}main{padding:16px 10px}header{padding:20px 14px}}
'''
app=r'''
const $=id=>document.getElementById(id),bound=(x,a,b)=>Math.max(a,Math.min(b,x));
const state={run:false,dt:.05,delta:null,legacy:null,data:[],time:null,steps:0};
const controls=['r','g','b','logK','deltaGain','deltaGate','adaptJump','tauFF','mu','path'];
function getParams(){return {
  rgb:[+$('r').value,+$('g').value,+$('b').value],
  opts:{logK:+$('logK').value,deltaGain:+$('deltaGain').value,deltaGate:+$('deltaGate').value,adaptJump:+$('adaptJump').value,tauFF:+$('tauFF').value,
  deltaEnabled:$('useDelta').checked,spikeAdapt:$('useAdapt').checked,feedforward:$('useFF').checked,feedback:true,
  attenuation:$('useBeer').checked?{mu:[+$('mu').value,+$('mu').value,+$('mu').value],L:+$('path').value}:null}
};}
function makeNew(){const {opts}=getParams();state.delta=new DeltaRippleNeuron(opts);state.legacy=new globalThis.LegacyRipple();state.data=[];state.steps=0;state.run=false;$('run').textContent='▶ Start';updateDisplay();}
for(const name of controls){$(name).addEventListener('input',()=>{$('o_'+name).textContent=Number($(name).value).toFixed(['r','g','b','mu','path'].includes(name)?2:2);});}
for(const t of ['useDelta','useAdapt','useFF','useBeer'])$(t).addEventListener('change',()=>{makeNew();});
for(const t of ['logK','deltaGain','deltaGate','adaptJump','tauFF','mu','path'])$(t).addEventListener('change',()=>{makeNew();});
$('reset').onclick=()=>makeNew();
$('run').onclick=()=>{state.run=!state.run;$('run').textContent=state.run?'❚❚ Pause':'▶ Start';};
$('step').onclick=()=>{state.run=false;$('run').textContent='▶ Start';advance();};
$('jump').onclick=()=>{const r=Math.random();$('r').value=Number((.15+.65*r).toFixed(2));$('o_r').textContent=Number($('r').value).toFixed(2);advance();};
$('export').onclick=()=>{const a=document.createElement('a'),blob=new Blob([JSON.stringify({evidence:'SIMULATED',source:'Ripple Delta Alpha v3.0',parameters:getParams(),traces:state.data},null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);a.href=url;a.download='ripple-delta-session.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
function advance(){const x=getParams().rgb,d=state.delta.step(x,state.dt),c=state.legacy.step(x,state.dt);state.steps++;
 const z={t:d.t,u:d.u,theta:d.theta,rate:d.rate,tonic:d.tonic,delta:d.delta,transient:d.transient,events:d.count,quaternary:d.quad.state,legacyRate:c.rate,legacyTheta:c.theta,legacyEvents:c.count};
 state.data.push(z);if(state.data.length>6000)state.data.shift();updateDisplay(z);
}
function graph(){const canvas=$('graph');const w=Math.max(canvas.clientWidth,300),h=Math.max(canvas.clientHeight,160),scale=Math.min(window.devicePixelRatio||1,2);canvas.width=w*scale;canvas.height=h*scale;
 const ctx=canvas.getContext('2d');ctx.scale(scale,scale);ctx.clearRect(0,0,w,h);const l=35,t=10,p=25,right=10,H=h-t-p,W=w-l-right;
 ctx.lineWidth=1;ctx.font='11px system-ui';for(let j=0;j<5;j++){const y=t+H*j/4;ctx.strokeStyle='#e0e9e2';ctx.beginPath();ctx.moveTo(l,y);ctx.lineTo(w-right,y);ctx.stroke();ctx.fillStyle='#78908b';ctx.fillText((3*(1-j/4)).toFixed(1),3,y+3);}
 const tail=state.data.slice(-500);if(tail.length<2)return;const min=tail[0].t,max=tail.at(-1).t;
 for(const [key,color] of [['rate','#1e8659'],['legacyRate','#c47b40'],['theta','#2e79aa']]){ctx.strokeStyle=color;ctx.lineWidth=2;ctx.beginPath();tail.forEach((o,i)=>{const x=l+((o.t-min)/Math.max(.001,max-min))*W,y=t+(1-bound(o[key]/3,0,1))*H;if(i===0)ctx.moveTo(x,y);else ctx.lineTo(x,y);});ctx.stroke();}
 ctx.fillStyle='#637a74';ctx.fillText(`${min.toFixed(0)} s`,l,h-5);ctx.fillText(`${max.toFixed(0)} s`,w-43,h-5);
}
function updateDisplay(z=null){z=z||state.data.at(-1)||{t:0,rate:0,theta:.45,delta:0,quaternary:'0',legacyRate:0,events:0,tonic:0,transient:0};
 $('time').textContent=z.t.toFixed(2);$('rate').textContent=z.rate.toFixed(2);$('oldRate').textContent=z.legacyRate.toFixed(2);$('symbol').textContent=z.quaternary;
 $('details').textContent=`Tonic ${z.tonic.toFixed(3)} · Contrast Δ ${z.delta.toFixed(3)} · Transient ${z.transient.toFixed(3)} · Threshold ${z.theta.toFixed(3)} · Total samples ${state.steps}`;
 graph();}
$('comparison').onclick=()=>{
 const original=globalThis.LegacyExperiment().windows;
 const modes=[['Delta defaults',{}],['No analytic feedforward',{feedforward:false}],['No transient',{deltaEnabled:false}],['No spike adaptation',{spikeAdapt:false}]];
 const comparisons=modes.map(([name,opts])=>{const n=new DeltaRippleNeuron(opts),bins=[0,0,0];for(let i=0;i<2400;i++){const t=.05*i,red=t<40||t>=80?.35:.7;const z=n.step([red,0,0],.05);if(t>=20&&t<40)bins[0]+=z.count;if(t>=60&&t<80)bins[1]+=z.count;if(t>=100&&t<120)bins[2]+=z.count;}return{name,rate:bins.map(n=>n/20)};});
 const rows=[{name:'Original v0.1',rate:[1,1,1].map((_,i)=>original[i].adaptive_hz)},...comparisons];
 // Historical original baseline is from three 20-second windows, not full 40-second blocks.
 const tbody=$('results');tbody.textContent='';for(const row of rows){const tr=document.createElement('tr');[row.name,...row.rate.map(x=>x.toFixed(3))].forEach(cell=>{const td=document.createElement('td');td.textContent=cell;tr.append(td);});tbody.append(tr);}
 $('resultsNote').textContent='Comparison uses identical 20-second windows (20–40, 60–80, 100–120 s), initial red .35, high red .70. All numerical, not measured.';
};
makeNew();setInterval(()=>{if(state.run)advance();},50);window.addEventListener('resize',()=>graph());
'''
html=f'''<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Ripple Δ — Delta Neuron Mathematical Alpha v3</title><style>{styles}</style></head><body>
<header><div class="meta">Ripple Research · Mathematical Alpha v3.0 · New neuron, original preserved</div><h1>Ripple Δ | Delta Neuron</h1><p>Optical transport → log contrast → exact leaky membrane → slow adaptation → event timing → 2-bit telemetry</p></header>
<main><div class="status"><strong>Evidence: SIMULATED / CALCULATED.</strong> All inputs are manual, dimensionless RGB proxies. This offline laboratory does not connect to a camera, a cloud service, a living neuron, or a physical sensor.</div>
<div class="grid"><div>
<section class="panel"><h2>Input RGB</h2>
'''
for label,k,v,color in [('Red excitation','r','.35','#bb5649'),('Green excitation','g','0','#237e60'),('Blue inhibition','b','0','#3682b4')]:
 html+=f'<label class="control"><div><span style="color:{color}">{label}</span><output id="o_{k}">{float(v):.2f}</output></div><input type="range" id="{k}" min="0" max="1" step=".01" value="{v}"></label>'
html+='''<h3>Experimental Delta mechanisms</h3>
<label class="toggle"><input type="checkbox" id="useDelta" checked> Signed temporal-contrast drive</label>
<label class="toggle"><input type="checkbox" id="useAdapt" checked> Spike-triggered slow adaptation</label>
<label class="toggle"><input type="checkbox" id="useFF" checked> Analytic steady-rate feedforward (experimental)</label>
<label class="toggle"><input type="checkbox" id="useBeer"> Synthetic Beer–Lambert attenuation</label>'''
for label,k,value,minval,maxval,step in [('Log-compression strength','logK','0',0,20,.5),('Transient gain','deltaGain','.22',0,2,.01),('Contrast gate','deltaGate','.06',0,.5,.01),('Adaptation jump','adaptJump','.02',0,.2,.005),('Feedforward time constant, s','tauFF','4',.5,20,.5),('Synthetic μ, m⁻¹','mu','0',0,3,.05),('Synthetic path length, m','path','1',0,5,.1)]:
 html+=f'<label class="control"><div><span>{label}</span><output id="o_{k}">{float(value):.2f}</output></div><input type="range" id="{k}" min="{minval}" max="{maxval}" step="{step}" value="{value}"></label>'
html+='''<div class="actions"><button id="run">▶ Start</button><button id="step" class="secondary">Single step</button><button id="reset" class="secondary">Reset</button><button id="jump" class="secondary">Light step</button></div><p class="small">Changing model parameters resets the numerical run. The original kernel is held separate and unchanged.</p></section></div><div>
<section class="panel"><h2>Side-by-side neuron simulation</h2><div class="stats"><div class="stat"><strong id="time">0.00</strong><span>Model time (s)</span></div><div class="stat"><strong id="rate">0.00</strong><span>Delta rate (events/s)</span></div><div class="stat"><strong id="oldRate">0.00</strong><span>Original rate (events/s)</span></div><div class="stat"><strong id="symbol">0</strong><span>Four-state symbol</span></div></div><div id="details" class="scope"></div><canvas id="graph" aria-label="Delta and original simulated model firing rates"></canvas><div class="legend"><b style="color:#1e8659">━</b> Delta rate &nbsp; <b style="color:#c47b40">━</b> Original rate &nbsp; <b style="color:#2e79aa">━</b> Delta threshold</div><div class="actions"><button class="secondary" id="export">Export numerical trace</button></div></section>
<section class="panel"><h2>Mathematical core</h2><div class="equations">S = 2C(R) + 1.2C(G) − 1.4C(B)
Δ = Σ wᵢ gate[ln((Iᵢ(t)+ε)/(Iᵢ(t−dt)+ε))]
D = S + γΔ
τᵥ du/dt = −u + D − a
τₐ da/dt = −a ; on spike: a ← a + b
u crosses θ → spike ; u ← 0, refractory interval
θ ← clip[θ + α(θ*(S)−θ) + η∫(r−r*)dt]
θ*(S) = S[1 − exp(−(1/r*−tref)/τᵥ)] (only feasible constant-input approximation)
Four-state telemetry: decrease=00, inhibited stable=01, stable=10, increase=11</div><p>Light encoding and adaptation are model additions, not measured biophysical parameters. Optical attenuation is optional and synthetic without calibrated coefficients.</p></section>
<section class="panel"><h2>Original vs Delta regression</h2><button id="comparison" class="secondary">Run 120 s step comparison</button><div class="scroll"><table><thead><tr><th>Variant</th><th>20–40s</th><th>60–80s</th><th>100–120s</th></tr></thead><tbody id="results"></tbody></table></div><p id="resultsNote" class="small">For exact comparisons across identical windows and seeds, see the accompanying validated benchmark.json.</p></section>
<section class="panel"><h2>Physical interpretation boundary</h2><p><strong>Physics:</strong> exponential attenuation for an idealized homogeneous absorber; electrical RC-like leak; exponential recovery/adaptation; temporal contrast and event gating.</p><p><strong>What this is not:</strong> calibrated optical field sensing, an experimentally characterized biological membrane, demonstrated consciousness, a discovered metaphysical structure, or artificial general intelligence.</p><p>The term “metaphysical” has no independently established measurable equation in these source materials. Philosophical interpretation is separate from empirical validation.</p></section>
</div></div><p class="small">Ripple Δ v3.0 research Alpha. Standalone source bundles: frozen original v0.1 + existing optical laws + new Delta runtime. No external resources are loaded.</p></main>
<script type="module">
{original}
{photo}
{delta}
{app}
</script></body></html>'''
# Replace source placeholders without evaluating/reinterpreting source contents.
html=html.replace('{original}', '(function(){\n'+original+'\n})();').replace('{photo}', '(function(){\n'+photo+'\nObject.assign(globalThis,{beerLambert,srgbDecode});\n})();').replace('{delta}', '(function(){\nconst {beerLambert,srgbDecode}=globalThis;\n'+delta+'\nObject.assign(globalThis,{DeltaRippleNeuron});\n})();').replace('{app}', '(function(){\nconst {DeltaRippleNeuron}=globalThis;\n'+app+'\n})();')
output=root/'Ripple-Delta-Neuron-Alpha-v3.0.html'
output.write_text(html)
print(f'Built {output} length={output.stat().st_size} bytes sha256={hashlib.sha256(output.read_bytes()).hexdigest()}')
