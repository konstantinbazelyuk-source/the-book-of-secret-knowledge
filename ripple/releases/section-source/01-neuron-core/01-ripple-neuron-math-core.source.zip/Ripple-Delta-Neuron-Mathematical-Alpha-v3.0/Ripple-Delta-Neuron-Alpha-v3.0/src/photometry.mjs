/** Ripple Gen Beta v2.1: isolated, physically grounded radiometric calculations.
 * Real sensor calibration MUST be supplied externally. No implicit absolute
 * light or density inference from camera/display RGB or scanner digit counts.
 */
const ok=(x,n)=>{if(!(typeof x==='number'&&Number.isFinite(x)))throw Error('Nonfinite '+n);return x;};
const bound=(v,a,b)=>Math.max(a,Math.min(b,v));
export const H=6.62607015e-34, C=299792458;
export function photonEnergyJ(lambdaNm){ok(lambdaNm,'wavelength');if(lambdaNm<=0||lambdaNm>1e9)throw Error('Wavelength out of bounds');return H*C/(lambdaNm*1e-9);}
export function srgbDecode(v){ok(v,'sRGB');if(v<0||v>1)throw Error('out of sRGB bounds');return v<=.04045?v/12.92:((v+.055)/1.055)**2.4;}
export function srgbEncode(v){ok(v,'linear RGB');if(v<0||v>1)throw Error('out of linear RGB bounds');return v<=.0031308?12.92*v:1.055*v**(1/2.4)-.055;}
export function beerLambert(intensity,mu,path){ok(intensity,'intensity');ok(mu,'attenuation');ok(path,'path');if(intensity<0||mu<0||path<0||mu*path>100)throw Error('Invalid attenuation');return intensity*Math.exp(-mu*path);}
export function inverseSquareIrradiance(sourceFactor,radius,incidenceRad=0){ok(sourceFactor,'source factor');ok(radius,'radius');ok(incidenceRad,'angle');if(sourceFactor<0||radius<=0||Math.abs(incidenceRad)>Math.PI/2)throw Error('Invalid point-source geometry');return sourceFactor*Math.cos(incidenceRad)/radius**2;}
export function fresnelNormalIncidence(n1,n2){ok(n1,'n1');ok(n2,'n2');if(n1<=0||n2<=0)throw Error('Invalid refractive index');return ((n1-n2)/(n1+n2))**2;}
/** Relative *camera-output* ratio: does not infer material optical density.
 * Each observation, dark and clear must have been captured under controlled
 * optics/exposure/white balance/gamma with declared uncertainties.
 */
export function calibratedRatio({sample,dark,clear,sigma=0,linearize=false,clipping=250}){
 for(const [k,v] of Object.entries({sample,dark,clear,sigma,clipping}))ok(v,k);
 if([sample,dark,clear].some(v=>v<0||v>255)||sigma<0||clipping>255||clipping<10)throw Error('Out of camera-code range');
 if(sample>=clipping||clear>=clipping||dark>=clipping)return {valid:false,reason:'Clipped channel'};
 if(clear-dark<Math.max(20,6*sigma))return {valid:false,reason:'Insufficient reference span / low SNR'};
 let f=x=>linearize?srgbDecode(x/255):x/255;
 const span=f(clear)-f(dark);if(span<=0)return {valid:false,reason:'Nonpositive optical reference'};
 const raw=(f(sample)-f(dark))/span;
 if(raw<0||raw>1)return {valid:false,reason:'Sample outside reference span'};
 const transmission=raw;
 return {valid:true,transmission,relativeOpacity:1-transmission,relativeOD:-Math.log10(Math.max(transmission,1e-6)),
   interpretation:'Camera-code ratio, not physical calibrated spectral transmittance',
   presumedLinear:linearize,uncertaintyQualifier:'No uncertainty interval without repeated, independent instrument characterization'};
}
/** Explicit model-data boundary, sampled optics only. No claimed sensor feed. */
export function validatedRecordedImage(packet){
 if(!packet||packet.provenance!=='recorded_scanner'||packet.dataset!=='sklearn_digits_1998')throw Error('Unverified provenance');
 if(!Number.isInteger(packet.datasetIndex)||packet.datasetIndex<0||packet.datasetIndex>=1797)throw Error('index');
 if(!Array.isArray(packet.pixels)||packet.pixels.length!==64||packet.pixels.some(v=>!Number.isInteger(v)||v<0||v>16))throw Error('shape/range');
 if('groundTruth' in packet||'digitLabel' in packet)throw Error('Leaked label inside input');
 return Object.freeze({provenance:packet.provenance,dataset:packet.dataset,datasetIndex:packet.datasetIndex,pixels:Object.freeze([...packet.pixels]),units:'on-pixel counts per 4x4 region; not photon energy or spectral bands'});
}
