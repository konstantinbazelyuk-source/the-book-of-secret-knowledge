from pathlib import Path
from hashlib import sha256
import json,zipfile,subprocess
root=Path(__file__).resolve().parent.parent
assert sha256((root/'legacy/ripple-core.js').read_bytes()).hexdigest()=='dba6639b7902f0c702d15fff588524629f3754cfd72d7b704f22a76b78960ee3'
bench=json.loads((root/'results/benchmark.json').read_text());assert len(bench['rows'])==600
assert len(bench['grouped'])==30
out={
 'release':'Ripple Delta Neuron Alpha v3.0.0-alpha.1',
 'locked_baseline_sha256':'dba6639b7902f0c702d15fff588524629f3754cfd72d7b704f22a76b78960ee3',
 'inputs':'Synthetic normalized RGB (dimensionless); no real sensor measurements',
 'programs':{'original':'legacy/ripple-core.js','new':'src/delta-neuron.mjs','compiler':'src/formula-compiler.mjs'},
 'evidence':'SIMULATED/CALCULATED',
 'benchmark_design':{'total_executions':600,'scenarios':5,'seeds':20,'variants':6,'independent_noise_seeds':20,'constant_scenario_repetition':'Deterministic scenarios repeat identically for each seed'},
 'validation':'Node automated tests, Chromium DOM smoke on two viewport sizes, SHA-256 and ZIP CRC checks',
 'limits':['No physical light or tissue measurements','No metaphysical evidence','No general intelligence assessment','Spiking parameters not biologically fitted','Analytic threshold inverse only exact for stationary basic LIF']
}
(root/'results/RELEASE_EVIDENCE.json').write_text(json.dumps(out,indent=2)+'\n')
paths=sorted(p for p in root.rglob('*') if p.is_file() and not p.name in {'SHA256SUMS.txt','SOURCE_HASHES.json'} and '__pycache__' not in p.parts)
manif={str(p.relative_to(root)):sha256(p.read_bytes()).hexdigest() for p in paths}
(root/'SOURCE_HASHES.json').write_text(json.dumps(manif,indent=2)+'\n')
(root/'SHA256SUMS.txt').write_text(''.join(f'{v}  {k}\n' for k,v in manif.items()))
zippath=root.parent/'Ripple-Delta-Neuron-Mathematical-Alpha-v3.0.zip'
with zipfile.ZipFile(zippath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as z:
 for p in sorted(root.rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:z.write(p,arcname=root.name+'/'+str(p.relative_to(root)))
with zipfile.ZipFile(zippath) as z:
 assert z.testzip() is None
 assert root.name+'/src/delta-neuron.mjs' in z.namelist()
print(json.dumps({'file':str(zippath),'bytes':zippath.stat().st_size,'files':len([p for p in root.rglob('*') if p.is_file()]),'sha256':sha256(zippath.read_bytes()).hexdigest()},indent=2))
