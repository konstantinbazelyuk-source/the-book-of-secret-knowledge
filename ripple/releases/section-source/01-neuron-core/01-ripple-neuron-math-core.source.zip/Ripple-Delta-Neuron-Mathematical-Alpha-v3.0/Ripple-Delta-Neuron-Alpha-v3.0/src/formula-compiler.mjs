/**
 * Ripple Mathematics Compiler v2.1.1 — add-on formula registry.
 * Beer–Lambert model from verified v2.1 photometry, NOT a new optical measurement.
 * One verified operation is compiled from a fixed allowlist; arbitrary user code,
 * eval, Function constructors, networking, and source rewriting are excluded.
 * Units: mu [m^-1], L [m], I0 and I in the same non-negative intensity units.
 */
import { beerLambert } from './photometry.mjs';
import { DeltaRippleNeuron } from './delta-neuron.mjs';

const has = (o,k) => Object.prototype.hasOwnProperty.call(o,k);
const ensureRecord = (obj,name) => {
  if(obj===null || typeof obj!=='object' || Array.isArray(obj) || Object.getPrototypeOf(obj)!==Object.prototype)
    throw new TypeError(`${name} must be a plain JSON object`);
  return obj;
};
function exactKeys(obj, required, optional=[],name='record'){
  ensureRecord(obj,name);
  const allowed=new Set([...required,...optional]);
  for(const k of Object.keys(obj))if(!allowed.has(k))throw new RangeError(`${name}: unexpected field ${k}`);
  for(const k of required)if(!has(obj,k))throw new RangeError(`${name}: missing ${k}`);
}
function finite(v,name){
  if(typeof v!=='number' || !Number.isFinite(v))throw new RangeError(`${name} must be finite number`);
  return v;
}
function nonnegative(v,name){finite(v,name);if(v<0)throw new RangeError(`${name} must be nonnegative`);return v;}
function positive(v,name){nonnegative(v,name);if(v===0)throw new RangeError(`${name} must be positive`);return v;}
const DOMAIN_MAX=100;
function opticalDepth(mu,L){
  nonnegative(mu,'mu');nonnegative(L,'L');
  const d=mu*L;
  if(!Number.isFinite(d)||d>DOMAIN_MAX)throw new RangeError('mu*L exceeds numerical guard (100)');
  return d;
}

export const FORMULAS=Object.freeze({
 beer_lambert:Object.freeze({
  id:'beer_lambert',version:'2.1.1',
  equation:'I = I0 * exp(-mu * L)',
  modes:Object.freeze(['forward','solve_mu','solve_L','rgb_forward']),
  units:Object.freeze({I0:'same intensity unit as I',I:'same intensity unit as I',mu:'m^-1',L:'m'}),
  assumptions:'Collimated narrowband light; homogeneous, non-scattering medium; mu and L are externally supplied or independently calibrated.',
  evidence:'CALCULATED/SIMULATED, never a direct observation of a camera or material',
  source:'src/photometry.mjs:beerLambert; IUPAC Gold Book B00626'
 }),
 delta_ripple:Object.freeze({
  id:'delta_ripple',version:'3.0.0-alpha.1',
  equation:'S=w·C(I); Δ=w·gate(log((I+ε)/(Iprev+ε))); τv u̇=−u+S+γΔ−a; τa ȧ=−a, a+=b at spikes',
  modes:Object.freeze(['run','summary']),
  units:Object.freeze({rgb:'dimensionless normalized intensity proxy',dt:'model seconds',u:'dimensionless membrane model',rate:'model events/s'}),
  assumptions:'Piecewise-constant drive each sample; original color weights; controlled and independently calibrated input required for physical interpretation.',
  evidence:'SIMULATED or CALCULATED ONLY; no biological neuron data fit',
  source:'src/delta-neuron.mjs; original Ripple v0.1; EPFL Neuronal Dynamics Chapters 1 and 6; established optical transfer functions'
 })
});
export function listFormulas(){return Object.values(FORMULAS);}

/** Compile an allowlisted formula plan; values can only be supplied to evaluate(). */
export function compileFormula(request){
 exactKeys(request,['formula','mode'],[],'compiler request');
 if(typeof request.formula!=='string'||!has(FORMULAS,request.formula))throw new RangeError('Unknown formula');
 const descriptor=FORMULAS[request.formula];
 if(!descriptor.modes.includes(request.mode))throw new RangeError('Unsupported formula mode');
 const mode=request.mode;
 const metadata=Object.freeze({formula:descriptor.id,mode,version:descriptor.version,equation:descriptor.equation,units:descriptor.units,evidence:descriptor.id==='delta_ripple'?'SIMULATED':'CALCULATED'});
 return Object.freeze({metadata,evaluate(params){return descriptor.id==='delta_ripple'?evaluateDelta(mode,params):evaluateMode(mode,params);}});
}

function evaluateMode(mode,p){
 if(mode==='forward'){
  exactKeys(p,['I0','mu','L'],[],'forward inputs');
  const I0=nonnegative(p.I0,'I0'), d=opticalDepth(p.mu,p.L);
  const I=beerLambert(I0,p.mu,p.L);
  const T=Math.exp(-d), A=d/Math.LN10;
  if(!Number.isFinite(I))throw new RangeError('Nonfinite transmitted intensity');
  return Object.freeze({I,T,lossFraction:1-T,OD10:A,opticalDepthNeper:d,dIdI0:T,dIdMu:-p.L*I,dIdL:-p.mu*I,
   units:{I:'same as I0',T:'dimensionless',OD10:'dimensionless',dIdL:'intensity/m'},evidence:'CALCULATED'});
 }
 if(mode==='solve_mu'||mode==='solve_L'){
  const third=mode==='solve_mu'?'L':'mu';
  exactKeys(p,['I0','I',third],[],'inverse inputs');
  const I0=positive(p.I0,'I0'),I=positive(p.I,'I');
  if(I>I0)throw new RangeError('Measured I cannot exceed I0 in this pure-attenuation model');
  const known=positive(p[third],third);
  const depth=-Math.log(I/I0);
  if(depth>DOMAIN_MAX)throw new RangeError('Inferred optical depth exceeds 100');
  const solved=depth/known;
  if(!Number.isFinite(solved))throw new RangeError('Nonfinite inverse result');
  const result=mode==='solve_mu'?{mu:solved,muUnit:'m^-1'}:{L:solved,LUnit:'m'};
  return Object.freeze({...result,T:I/I0,OD10:depth/Math.LN10,evidence:'CALCULATED',warning:'Inverse requires independent calibrated I and I0; not an inferred camera measurement'});
 }
 if(mode==='rgb_forward'){
  exactKeys(p,['rgb','muRGB','L'],[],'RGB model inputs');
  if(!Array.isArray(p.rgb)||!Array.isArray(p.muRGB)||p.rgb.length!==3||p.muRGB.length!==3)
    throw new RangeError('rgb and muRGB must each contain exactly three channels');
  nonnegative(p.L,'L');
  const channels=p.rgb.map((v,i)=>{
   nonnegative(v,`rgb[${i}]`);opticalDepth(p.muRGB[i],p.L);
   return evaluateMode('forward',{I0:v,mu:p.muRGB[i],L:p.L});
  });
  return Object.freeze({output:Object.freeze(channels.map(c=>c.I)),transmittance:Object.freeze(channels.map(c=>c.T)),
   evidence:'SIMULATED',warning:'Broad RGB is not a spectral measurement; each channel coefficient is a user-provided synthetic parameter'});
 }
 throw new RangeError('Unsupported mode');
}
export function executeRecipe(recipe){
 exactKeys(recipe,['formula','mode','inputs'],[],'recipe');
 return compileFormula({formula:recipe.formula,mode:recipe.mode}).evaluate(recipe.inputs);
}

function evaluateDelta(mode,p){
 exactKeys(p,['samples','dt'],['options'],'delta inputs');
 if(!Array.isArray(p.samples)||p.samples.length===0||p.samples.length>10000)throw new RangeError('samples must have 1..10000 rows');
 const dt=positive(p.dt,'dt');if(dt>.2)throw new RangeError('dt must be ≤0.2 s');
 const neuron=new DeltaRippleNeuron(p.options??{});
 const traces=[];let total=0;
 for(let i=0;i<p.samples.length;i++){
  const sample=p.samples[i];
  if(!Array.isArray(sample)||sample.length!==3)throw new TypeError(`samples[${i}] must be RGB triplet`);
  const r=neuron.step(sample,dt);total+=r.count;
  if(mode==='run')traces.push({t:r.t,tonic:r.tonic,delta:r.delta,drive:r.drive,u:r.u,adaptation:r.adaptation,theta:r.theta,rate:r.rate,events:r.count});
  else if(i%10===0||i===p.samples.length-1)traces.push({t:r.t,rate:r.rate,threshold:r.theta,events:r.count});
 }
 const last=traces.at(-1);
 return Object.freeze({formula:'delta_ripple',version:'3.0.0-alpha.1',mode,totalModelEvents:total,elapsedModelSeconds:dt*p.samples.length,meanObservedHz:total/(dt*p.samples.length),finalRateHz:neuron.rate,finalTheta:neuron.theta,trace:traces,evidence:'SIMULATED',warning:'Dimensionless synthesized inputs unless physical sensor calibration and provenance are independently documented'});
}
