# Ripple Gen Beta v2.1 — recorded optical data and scientific-light-law evaluation

**Status:** executable research branch; baseline v2.0 archived, unchanged. This is an extension to the perception/evaluation toolkit, **not** proof of generalized intelligence or physically calibrated light perception.

## Open without installing tools
Open `Ripple-Gen-Beta-v2.1-Standalone.html` in a browser. The self-contained read-only dashboard contains results from actual executed training/evaluation, the 30 real scanned-digit images, the blinded assistant comparison, and an interactive *calculated* attenuation-law tool. It does not access a camera, network, or remote model.

## Evidence inventory

| Part | Status and meaning |
|---|---|
| Source image data | **RECORDED** optical handwritten-digit scanner images from scikit-learn/UCI, 1,797 samples, 8×8, pixel **counts** 0–16 from original form scans. Ground truth = handwritten digit label. Not raw camera RGB or radiance. |
| Data division | **EXECUTED** 1,078 training, 359 validation, 360 held-out test; stratified deterministic split with `split_seed=20311013`. Original scikit-learn digits copy has no per-writer IDs, so test is **not writer-disjoint**. |
| Original Ripple modules | **EXECUTED** byte-identical v0.1 event LIF, v0.6 photoreceptor (using `linear:false` on scanner counts), v0.7 QuadEncoder. Each scanned image was raster-scanned **spatially**, not sensed as a temporal camera sequence. Output used as supervised classification features. |
| Learning adapter | **TRAINED & HELD-OUT TESTED** sklearn SVC on digit labels outside holdout. This adds a *narrow classifier* to Ripple's signals, not independent online learning by the original LIF or synthetic agent/colony. |
| ChatGPT comparator | **ONE-PASS RECORDED VISUAL PROBE**: GPT-6 viewed 30 images as a numbered contact sheet, wrote 30 predictions, then ground-truth labels were checked. That is not a programmatic API invocation, not a fair comparison of pretrained vision and task-specific supervised learning, and not an intelligence rating. |
| Physics module | **ANALYTICALLY TESTED** sRGB transfer, Beer–Lambert exponential attenuation, point-source inverse-square with incidence cosine, Fresnel normal incidence, photon energy E=hc/lambda. Assumptions matter; none independently estimates real scene distance or density. |
| Synthetic photometric test | **SIMULATED TRANSFORMATION OF RECORDED INPUT**: digit pixels were assumed to be hypothetical linear-light surrogates, scaled with `e^(-0.35L)`. This is a robustness challenge on real shapes/labels, not measured attenuation. |
| Real photometry | **NOT MEASURED**: no spectrometer, calibrated camera RAW, controlled lighting/exposure, physical transmittance, or temporal camera motion data were provided. |
| Existing synthetic BetaWorld | **ARCHIVED, UNMODIFIED** in `archive/Ripple-Gen-Beta-v2.0/`. Real digit recognition doesn't establish mapping/robot navigation performance. |

## Executed results

| Model | Correct on 360 held-out real scans |
|---|---:|
| Pixel-based RBF SVC | 354 / 360 (98.33%) |
| Locked Ripple LIF + photoreceptor + Quad engineered features (learned SVC) | 327 / 360 (90.83%) |
| Pixel + Ripple learned SVC | 354 / 360 (98.33%) |
| 3-nearest-neighbor pixels | 355 / 360 (98.61%) |

**Negative finding:** Ripple's feature channels did *not* improve digit recognition over simple pixels on this test. The two methods misclassified different 3 examples each, but had the same overall 354/360.

Blind 30-image sheet: GPT-6 manual vision **19/30 (63.33%)** versus trained Ripple features SVC **27/30 (90%)** and fused SVC **30/30**. Interpret as one small controlled exposure of task conditions, not superiority of Ripple versus ChatGPT in general. SHA-256 of the precommitted ChatGPT predictions is in `data/statistical_audit.json`.

### Known-law illumination stress test (not a physical exposure dataset)

The original recorded 360 samples were multiplied by `exp(-0.35 * L)` for each indicated L (0..4). A clean-only supervised classifier versus a predeclared train-augmented classifier (training attenuation paths 0,1,2,3; evaluation path 4 unseen):

| L | Transmission | Clean-trained | Training with attenuation augmentation |
|---|---:|---:|---:|
| 0 | 1.000 | 354/360 | 353/360 |
| 1 | 0.705 | 338/360 | 354/360 |
| 2 | 0.497 | 310/360 | 354/360 |
| 3 | 0.350 | 198/360 | 353/360 |
| 4 | 0.247 | 81/360 | 354/360 |

A separate oracle that knew the exact imposed coefficient/path recovered 354/360 in all conditions by exact inversion. This is **calculated**, not a calibration measurement. There is a real **one-sample regression** on unattenuated images when using augmentation; it remains in the evidence. The path-4 paired difference is large on this dataset, but the same augmentation family creates both train and test conditions; it does not establish broad real-world robustness.

## Source layout
- `src/photometry.mjs`: physically dimensioned equations, input guards, explicit provenance adapters.
- `src/extract_beta_features.mjs`: real imports of archived v0.1/v0.6/v0.7 and reproducible, bounded 8×8 spatial scan feature extraction.
- `src/prepare_blind.py`, `benchmark_real.py`, `statistical_audit.py`, `make_dashboard.py`: reproducible research processing and blind protocol.
- `tests/photometry.test.mjs`: analytic safeguards and regression.
- `models/*.joblib`: trusted fitted SVCs (joblib deserialization is unsafe for untrusted files; don't load models from outside sources).
- `data/*`: pixel data, observations, splits, guesses, scores, and hash-backed validation record.
- `archive/Ripple-Gen-Beta-v2.0/`: complete previous Beta, source unchanged.

## Reproduce (requires Python with scikit-learn, scipy, numpy, statsmodels, joblib and Node.js)

From this project's root, without changing original v2.0:

```bash
python src/prepare_blind.py
node src/extract_beta_features.mjs data/scanner_frames_input.json data/ripple_features.json
python src/benchmark_real.py
python src/statistical_audit.py
python src/make_dashboard.py
node --test tests/photometry.test.mjs
node --test archive/Ripple-Gen-Beta-v2.0/tests/core.test.mjs
```

`prepare_blind.py` recreates the ground-truth holdout but does not rewrite the separately committed ChatGPT predictions. Rerunning all steps reproduces the fixed-seed data split and scores given the supplied dependency versions; minor numeric differences may be possible across library versions.

## Physical validation gate
A valid physical-transmittance study requires *independent* dark/reference/sample observations at fixed camera manual gain/exposure/white balance and geometry; repeated shots to estimate uncertainty; a target with traceable or instrument-measured transmission; and independent real validation. The code explicitly rejects saturated channels, insufficient reference separation, and impossible input values. A normal consumer webcam cannot independently separate scattering, absorption, and ambient scene changes from a single uncalibrated image.

## Primary outside sources
- [Optical recognition handwritten digits — scikit-learn](https://scikit-learn.org/stable/modules/generated/sklearn.datasets.load_digits.html)
- [Preprocessing/validation pitfalls — scikit-learn](https://scikit-learn.org/stable/common_pitfalls.html)
- [NIST spectrophotometry](https://www.nist.gov/programs-projects/spectrophotometry)
- [NIST reference on optical transmittance and Beer–Lambert](https://www.govinfo.gov/content/pkg/GOVPUB-C13-76768f69725804d9d383b5246a5ce1c7/pdf/GOVPUB-C13-76768f69725804d9d383b5246a5ce1c7.pdf)
- [NIST inverse-square geometry](https://nvlpubs.nist.gov/nistpubs/Legacy/TN/nbstechnicalnote910-7.pdf)

This is a bounded research system. It neither claims consciousness nor general intelligence nor direct photon counting.
