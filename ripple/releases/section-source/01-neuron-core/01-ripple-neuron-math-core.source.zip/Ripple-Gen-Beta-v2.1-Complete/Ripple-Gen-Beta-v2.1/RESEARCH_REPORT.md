# Ripple Gen Beta v2.1 — Evidence-bound evaluation report

## Abstract
An **unmodified original** Ripple v0.1 leaky-integrate-and-fire kernel, v0.6 logarithmic photoreceptor kernel, and v0.7 quaternary encoder were exercised on recorded optical digit-scanner images and evaluated with true handwritten-digit labels. A supervised task-specific classifier was trained on fixed training/validation partitions, then assessed once on a disjoint 360-image holdout. A one-pass GPT-6 visual labeling probe was recorded on 30 selected holdout images before their ground-truth labels were opened. Separately, a scientifically grounded light-equation module was verified analytically, and the recorded pixel images underwent **explicitly synthetic** Beer–Lambert attenuation to test *robustness to a mathematical model*, not actual optical measurement.

## 1. Ground-truth dataset and provenance
- scikit-learn `load_digits`, 1,797 handwritten digits, each represented by an 8×8 integer matrix, values 0–16, with classification labels `0..9`.
- Origin: UCI Optical Recognition of Handwritten Digits; NIST preprocessing of handwritten forms generated each 8×8 4×4-block on-pixel count. The test used **original recorded digit shapes and labels**, not program-generated digit glyphs.
- Official source: https://scikit-learn.org/stable/modules/generated/sklearn.datasets.load_digits.html
- Train **1,078**; validation **359**; independently held-out test **360**. All partitions disjoint. Reader/author IDs not supplied; no writer-disjoint validation claim.
- Dataset content SHA-256 (`data.tobytes()+target.tobytes()`): `f6d9e39f37dc45d327f6db33428ee58970ccceabb2535a5c179de35886b70443`.

## 2. What Ripple actually did
- The binary canonical `legacy/ripple-core.js` v0.1 SHA-256 was checked, unchanged: `dba6639b7902f0c702d15fff588524629f3754cfd72d7b704f22a76b78960ee3`.
- The spatial scan of each 8×8 image generated LIF state/rate/spike counts, ON/OFF change events from the preserved v0.6 module (`linear:false` because normalized scanner values are **not** sRGB), and four-state symbols from v0.7.
- This generated 80 features (8 row groups × 10 features) and was evaluated by an ordinary **supervised radial-basis SVM**. The model is new; the existing Ripple neuron and colony do not learn digit classes on their own.
- Hyperparameter C was selected using only the validation split for each architecture, and models were refitted on train + validation before the held-out evaluation.

## 3. Ground-truth outcome — 360 real scans

| Method | Correct | Holdout accuracy | Interpretation |
|---|---:|---:|---|
| Pixel RBF SVC | 354/360 | 98.33% | Simple baseline, supervised |
| Ripple photoreceptor + original neuron + Q only | 327/360 | 90.83% | Supervised on Ripple-derived raster-scan features |
| Pixel + Ripple features | 354/360 | 98.33% | Additional Ripple features did not improve accuracy |
| Pixel 3-NN | 355/360 | 98.61% | Separate conventional reference |

Pixel versus combined predictions differed on **6 examples**: pixel-only wrong/combined right = **3**, pixel-only right/combined wrong = **3**. Exact paired McNemar p = **1.0**. One held-out dataset does not establish universal equivalence.

Descriptive Wilson 95% intervals: pixel baseline **96.41–99.23%**, Ripple-only **87.41–93.40%**. These intervals do not incorporate the uncertainty from writers, scans, domain changes, or selection protocol.

## 4. Explicit ChatGPT comparison

The assistant visually inspected a single numbered sheet of 30 blurred 8×8 handwritten digits and saved its digit guesses **before** examining `blind_ground_truth.json`. The predictions were committed with SHA-256:

`02325c02634ae2908fbf0ab760dfc21de47fc3bcfd76b52489d4f64fd657da4d`

| One batch of 30 identical scanned images | Correct |
|---|---:|
| GPT-6 one-pass visual responses | 19/30 (63.3%) |
| Supervised Ripple-only learned classifier | 27/30 (90.0%) |
| Supervised pixel + Ripple learned classifier | 30/30 (100.0%) |

**Interpretation restriction:** ChatGPT was not fine-tuned on this classification task in this experiment, nor independently invoked through an API. The models used different preparation and task-specific labeled training access; a tiny batch is not a fair comparison of general intelligence, training efficiency, or perception under equal compute. This result demonstrates the particular visual-format and training contrast in one session only. The 30 images are a subset of the 360 held-out tests and must not be counted as an independent additional dataset.

## 5. Physical optics and validation

| Law | Module expression | Verification | What remains unverified |
|---|---|---|---|
| sRGB opto-electronic transfer approximation | segment-wise decode/encode | Round-trip analytic test | Scanner counts are not sRGB nor RAW camera photons |
| Beer–Lambert | `I = I0 * exp(-mu * L)` | Half-transmission and path composition | Physical mu and path for any real material |
| Inverse-square, ideal point source | `I ∝ cos(theta)/r^2` | 2× radius -> 1/4 irradiance in appropriate geometry | Real extended/near-field light geometry |
| Fresnel reflection, normal incidence | `R = ((n1-n2)/(n1+n2))²` | 1.0 vs 1.5 -> 0.04 | Spectral index, polarization, multilayer effects |
| Photon energy | `E = h*c/lambda` | 550nm -> ~2.254 eV | Photons actually counted by sensors |
| Three-point relative camera-output ratio | `(sample-dark)/(clear-dark)` | Rejects saturation, insufficient span, out-of-span | External calibrated reflectance/transmittance target, RAW sensor calibration |

Applicable NIST guidance: https://www.nist.gov/programs-projects/spectrophotometry and https://nvlpubs.nist.gov/nistpubs/Legacy/TN/nbstechnicalnote910-7.pdf.

## 6. Artificial Beer–Lambert degradation challenge on real input images

Given a real scanner-derived digit shape `I`, construct `I' = I * exp(-0.35 * L)` for **simulated** L=0..4. Digit class label remains ground truth, but **I' is not recorded light attenuation**. The original pixel counts are 4×4 block occupancies, not optically linear radiance; this transformation is a mathematical surrogate experiment, not an instrument calibration. Compare:

- Clean-only supervised RBF SVC trained on originals (best C chosen using validation).
- Simulated-light augmented RBF SVC trained on paths 0,1,2,3 (same C) without test-set labels or path 4 training examples.
- Known-law oracle reversing `exp(-0.35*L)` with the true, artificially imposed L (not possible without measuring/knowing attenuation in an unknown physical scene).

| Path | Ideal T | Clean-trained correct | Augmented-trained correct | Known-law oracle correct |
|---|---:|---:|---:|---:|
| 0 | 1.000 | 354/360 | 353/360 | 354/360 |
| 1 | 0.705 | 338/360 | 354/360 | 354/360 |
| 2 | 0.497 | 310/360 | 354/360 | 354/360 |
| 3 | 0.350 | 198/360 | 353/360 | 354/360 |
| 4 | 0.247 | 81/360 | 354/360 | 354/360 |

At synthetic path 4, correct classifications increase by **273/360** (75.83 percentage points). Paired discordances were 274 repaired / 1 regressed, exact McNemar p approximately **9.09e-81** conditional on this test dataset and deterministic synthetic transform. This does **not** establish performance on actual camera exposure, real materials, or varying illumination spectra. At original conditions, augmentation regressed by one example.

## 7. Research gates for genuine physical optics

The task of **recorded ground-truth image recognition is complete**. Real physical attenuation/occlusion/density claims are not. The next real-world test would require:
1. Acquired RAW or fixed-exposure camera observations including device, focal length, integration time, gain/white-balance, ambient light and target geometry.
2. Repeated dark, clear, and sample measurements, controlled reference sensor/standard transmittance or reflectance, error bars, and sensor clipping checks.
3. A predeclared train/validation/holdout procedure with independent physical materials/illumination sessions rather than only digitally altered existing images.
4. Separate scoring of physical calibration accuracy, scene recognition, temporal-contrast rate, and digital colony navigation. Do **not** conflate them with the digit benchmark.

**Verdict:** v2.1 has a real, narrowly supervised optical-data evaluation and a mathematically verified light-physics toolkit; no benefit from adding all Ripple channels was observed on clean digit classification. Light attenuation **augmentation** improved performance against the chosen synthetic attenuation family. The original BetaWorld mapping and physically instrumented neuron were **not** validated by this experiment.
