from pathlib import Path
import json
from playwright.sync_api import sync_playwright
P=Path(__file__).resolve().parents[1]
html=(P/'Ripple-Gen-Beta-v2.1-Standalone.html').read_text()
with sync_playwright() as p:
  browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  page=browser.new_page(viewport={'width':390,'height':844},device_scale_factor=1)
  errors=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(html,wait_until='domcontentloaded')
  assert page.locator('h1').count()==1
  assert page.locator('.board').count()==1
  assert page.locator('#bars .track').count()==4
  assert page.locator('#opticalbars table tbody tr').count()==5
  assert page.locator('#individual').is_hidden()
  page.locator('#toggle').click()
  assert page.locator('#individual table tbody tr').count()==30
  page.locator('#mu').fill('0.5')
  page.locator('#length').fill('2')
  val=page.locator('#transmission').inner_text()
  assert abs(float(val.strip('%'))-36.8)<.1
  assert not errors,errors
  page.screenshot(path=str(P/'assets'/'dashboard-mobile.png'),full_page=True)
  w=page.evaluate('document.documentElement.scrollWidth')
  assert w<=390, f'horizontal viewport overflow {w}'
  pc=browser.new_page(viewport={'width':1200,'height':850})
  pc.set_content(html,wait_until='domcontentloaded')
  assert pc.locator('#bars .track').count()==4
  pc.screenshot(path=str(P/'assets'/'dashboard-desktop.png'),full_page=True)
  print(json.dumps({'browser':'Chromium','phone_pageerrors':errors,'mobile_document_width':w,'result_rows':pc.locator('#opticalbars tbody tr').count(),'chat_items':page.locator('#individual tbody tr').count(),'beer_lambert_slider_transmission':val,'pass':True}))
  browser.close()
