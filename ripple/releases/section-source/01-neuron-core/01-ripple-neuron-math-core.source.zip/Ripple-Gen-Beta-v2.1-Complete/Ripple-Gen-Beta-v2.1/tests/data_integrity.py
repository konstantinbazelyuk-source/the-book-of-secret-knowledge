import unittest,json,hashlib
from pathlib import Path
import numpy as np
from sklearn.datasets import load_digits
from sklearn.metrics import accuracy_score
P=Path(__file__).resolve().parents[1]
class TestRealDatasetEvidence(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.dataset=load_digits();cls.split=json.loads((P/'data/split.json').read_text());cls.results=json.loads((P/'data/results.json').read_text());cls.audit=json.loads((P/'data/statistical_audit.json').read_text())
 def test_original_dataset_not_synthetic(self):
  d=self.dataset
  self.assertEqual(d.images.shape,(1797,8,8))
  self.assertEqual(d.target.shape,(1797,))
  self.assertEqual(hashlib.sha256(d.data.tobytes()+d.target.tobytes()).hexdigest(),'f6d9e39f37dc45d327f6db33428ee58970ccceabb2535a5c179de35886b70443')
 def test_holdout_is_disjoint_and_stratified(self):
  x=[self.split[k] for k in ['train','val','test']]
  self.assertEqual([len(v) for v in x],[1078,359,360])
  self.assertEqual(len(set(sum(x,[]))),1797)
  self.assertEqual(len(self.split['blind']),30)
  self.assertTrue(set(self.split['blind']).issubset(set(self.split['test'])))
 def test_chatgpt_precommitted_blind_prediction_hash(self):
  p=P/'data/chatgpt_blind_predictions.json'
  self.assertEqual(hashlib.sha256(p.read_bytes()).hexdigest(),'02325c02634ae2908fbf0ab760dfc21de47fc3bcfd76b52489d4f64fd657da4d')
  pred=json.loads(p.read_text())['ordered_predictions']
  gt=json.loads((P/'data/blind_ground_truth.json').read_text())['labels']
  self.assertEqual(sum(int(a==b) for a,b in zip(pred,gt)),19)
 def test_model_accuracy_from_recorded_prediction_files(self):
  for name in ['raw-rbf','ripple-lif-quad','raw-plus-ripple']:
   o=json.loads((P/'data'/('prediction-'+name+'.json')).read_text())
   self.assertEqual(o['dataset_indices'],self.split['test'])
   self.assertEqual(int(np.sum(np.asarray(o['predictions'])==self.dataset.target[self.split['test']])),self.results['models'][name]['correct'])
 def test_real_vs_synthetic_distinction(self):
  self.assertFalse(self.results['safety']['physical_photo_sensor_tested'])
  self.assertFalse(self.results['safety']['camera_calibration_applied'])
  self.assertFalse(self.results['safety']['digit_scans_are_radiance'])
  for k,v in self.results['photometric_synthetic_test'].items():
   self.assertEqual(v['synthetic_transformation'],k!='clean_original')
 def test_no_fake_general_capability(self):
  self.assertEqual(self.results['models']['raw-rbf']['correct'],354)
  self.assertEqual(self.results['models']['raw-plus-ripple']['correct'],354)
  self.assertEqual(self.results['models']['ripple-lif-quad']['correct'],327)
  self.assertEqual(self.results['chatgpt_blind_test']['correct'],19)
 def test_known_law_attenuation_is_declared_simulated(self):
  r=self.results['photometric_synthetic_test']['attenuation_d4_mu.35']
  self.assertAlmostEqual(r['applied_transmission'],np.exp(-1.4),places=12)
  self.assertEqual(r['raw']['correct'],81)
  self.assertEqual(r['train_augmented_classifier']['correct'],354)
  self.assertEqual(r['known_law_oracle']['correct'],354)
if __name__=='__main__':unittest.main()
