#!/bin/sh
set -eu
cd "$(dirname "$0")"
python src/prepare_blind.py
node src/extract_beta_features.mjs data/scanner_frames_input.json data/ripple_features.json
python src/benchmark_real.py
python src/statistical_audit.py
python src/make_dashboard.py
node --test tests/photometry.test.mjs
node --test archive/Ripple-Gen-Beta-v2.0/tests/core.test.mjs
