# Physical light-physics acceptance protocol — no fictitious sensor evidence

## Minimum recorded dataset required
A source must record (1) actual sensor stream timestamps and immutable frame hashes, (2) device model and optical path, (3) camera gain/exposure and white balance or RAW Bayer with calibration, (4) illuminant and material ID, (5) independent real ground truth from a traceable calibrated light meter/spectrometer or physical-distance instrument, (6) repeated dark, clear and sample captures and (7) known train/held-out session assignments.

## Controlled tests to acquire in reality

**Real attenuation:** With gain/exposure locked and constant illuminant, use certified neutral density filters or spectrometer-traceable optical samples at fixed geometry. Measure multiple repetitions for each filter, independent reference to estimate transmittance, and record uncertainty. Compare **measured** T against calibrated predictions; flag channels saturated/low SNR; do not infer spectral OD from RGB alone.

**Real inverse-square:** A small nearly point-like emitter in far field at verified distances from a physically fixed receiving aperture. Capture radiometric irradiance with calibrated photodiode, test log intensity vs log distance slope near −2 only where geometry assumptions hold. Ordinary displayed-image average brightness with auto exposure is invalid for this inference.

**Real light-induced event timing:** Change a light source using a timing circuit/oscilloscope or accurately timestamped LED driver; compare true event timestamps with software photoreceptor ON/OFF thresholds, false positives and sensitivity at several noise levels. A sequential raster scan of a still frame does not count as time-series evidence.

**ChatGPT comparison (fairer followup):** Preset common dataset, matching training examples/prompt/evaluation time budget and task description. Obtain real model outputs via authorized API or direct independent UI run. The v2.1 one-off visual challenge is explicitly not this procedure.

## Supported vs unsupported
- Supported currently: digit scanner recognition accuracy, analytic optics equations, synthetic attenuation robustness.
- Unsupported currently: photon counting, calibrated quantum measurement, atomic density, radiation-field mapping, independent embodied intelligence, physical RGB spectral reconstruction, distance from a lone camera value.
- Never label future physical trials as completed without the recorded observations, metadata and independent ground truth.
