from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from PIL import Image, ImageDraw, ImageFont
from pathlib import Path
import numpy as np,json,hashlib
P=Path(__file__).resolve().parents[1]
d=load_digits()
ids=np.arange(len(d.target))
train,valtest=train_test_split(ids,test_size=.40,stratify=d.target,random_state=20311013)
val,test=train_test_split(valtest,test_size=.5,stratify=d.target[valtest],random_state=20311013)
# 3 per digit uniformly drawn from untouched test partition, in a blinded visual board.
rng=np.random.default_rng(943821)
choices=np.array([k for digit in range(10) for k in rng.choice(test[d.target[test]==digit],3,replace=False)],dtype=int)
rng.shuffle(choices)
(P/'data'/'split.json').write_text(json.dumps({'train':train.tolist(),'val':val.tolist(),'test':test.tolist(),'blind':choices.tolist(),'split_seed':20311013,'blind_seed':943821},indent=2))
# no true labels in board or output; store in separate file for later evaluation
(P/'data'/'blind_ground_truth.json').write_text(json.dumps({'labels':d.target[choices].tolist(),'dataset_indices':choices.tolist()},indent=2))
scale=11;gw=95;gh=118;cols=6;rows=5
canvas=Image.new('RGB',(cols*gw,rows*gh),(236,239,242));dr=ImageDraw.Draw(canvas)
for i,k in enumerate(choices):
  a=(d.images[k]/16*255).astype('uint8')
  im=Image.fromarray(a,'L').resize((8*scale,8*scale),resample=Image.Resampling.NEAREST).convert('RGB')
  x=(i%cols)*gw+3;y=(i//cols)*gh+25
  canvas.paste(im,(x,y));dr.text((x+2,y-20),f'{i+1:02d}',fill=(0,0,0));dr.rectangle((x-1,y-1,x+8*scale,y+8*scale),outline=(99,109,114))
canvas.save(P/'assets'/'blind_board.png')
print(json.dumps({'train_count':len(train),'validation_count':len(val),'test_count':len(test),'blind_board_count':len(choices),'dataset_sha256':hashlib.sha256(d.data.tobytes()+d.target.tobytes()).hexdigest(),'board_file':str(P/'assets'/'blind_board.png')}))
