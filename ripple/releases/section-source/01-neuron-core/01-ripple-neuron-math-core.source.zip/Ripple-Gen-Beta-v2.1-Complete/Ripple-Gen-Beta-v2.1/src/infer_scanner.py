"""Use ONLY trusted packaged classifier weights for 8x8 0..16 preprocessed digit scans.
Usage: python src/infer_scanner.py path/to/64-pixel-list.json [model-name]
"""
from pathlib import Path
import sys,json
import numpy as np
import joblib
P=Path(__file__).resolve().parents[1]
if len(sys.argv)<2:
    raise SystemExit('Pass a JSON file containing a 64-element integer 0..16 scanner pixel list')
model_name=sys.argv[2] if len(sys.argv)>2 else 'attenuation-trained'
if model_name not in {'attenuation-trained','raw-rbf'}:
    raise SystemExit('Use the prepared scanner-input models only: attenuation-trained or raw-rbf')
pixels=json.loads(Path(sys.argv[1]).read_text())
if not isinstance(pixels,list) or len(pixels)!=64 or not all(type(x)==int and 0<=x<=16 for x in pixels):
    raise SystemExit('Input must be exactly 64 integers, range 0..16')
clf=joblib.load(P/'models'/f'{model_name}.joblib')  # trusted package only
label=int(clf.predict((np.asarray(pixels,dtype=float)/16).reshape(1,-1))[0])
print(json.dumps({'predicted_digit':label,'model':model_name,'evidence':'Inference on user-provided 8x8 scanner-style digit counts; not a camera or optical-density measurement'}))
