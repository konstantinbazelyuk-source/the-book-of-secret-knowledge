"""Real pre-recorded optical scanner images + real digit-label ground truth.

Synthetic radiometric transformations are explicitly separate: they DO NOT imply
scanned digit values are linear photon measurements. Both original and
artificially changed images carry their correct original digit class.
"""
from pathlib import Path
import joblib
import json,time,hashlib,csv
import numpy as np
from sklearn.datasets import load_digits
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score,confusion_matrix,balanced_accuracy_score
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
P=Path(__file__).resolve().parents[1]
(P/'models').mkdir(exist_ok=True)
D=load_digits();x=D.data.astype(float)/16;y=D.target
splits=json.loads((P/'data'/'split.json').read_text());train=np.array(splits['train']);val=np.array(splits['val']);test=np.array(splits['test']);blind=np.array(splits['blind'])
features=json.loads((P/'data'/'ripple_features.json').read_text());rf=np.array([k['features'] for k in features['features']])
assert rf.shape==(len(x),80)
assert not (set(train)&set(val) or set(train)&set(test) or set(val)&set(test))

def metric(pred,idx):return dict(n=len(idx),correct=int(np.sum(pred==y[idx])),accuracy=float(accuracy_score(y[idx],pred)),balanced_accuracy=float(balanced_accuracy_score(y[idx],pred)),errors=np.where(pred!=y[idx])[0].tolist())
# Quantify feature value by held-out genuine images; choose hyperparameters on validation only.
models={}
for name,feat in [('raw-rbf',x),('ripple-lif-quad',rf),('raw-plus-ripple',np.column_stack([x,rf]))]:
    trials=[]
    for c in [0.3,1,3,10,30]:
        pipe=make_pipeline(StandardScaler(),SVC(C=c,gamma='scale',kernel='rbf'))
        pipe.fit(feat[train],y[train]);acc=accuracy_score(y[val],pipe.predict(feat[val]));trials.append({'C':c,'val_accuracy':float(acc),'model':pipe})
    chosen=sorted(trials,key=lambda r:(-r['val_accuracy'],r['C']))[0]
    # Refit using train+validation after selecting C, keep test untouched.
    tr=np.concatenate([train,val]);final=make_pipeline(StandardScaler(),SVC(C=chosen['C'],gamma='scale',kernel='rbf'))
    final.fit(feat[tr],y[tr]);pred=final.predict(feat[test]);models[name]=(final,feat)
    score=metric(pred,test)
    score.update(chosen_C=chosen['C'],val_candidates=[{'C':v['C'],'accuracy':v['val_accuracy']} for v in trials])
    print(name,'chosen C',chosen['C'],'holdout',score['accuracy'])
    (P/'data'/('prediction-'+name+'.json')).write_text(json.dumps({'dataset_indices':test.tolist(),'predictions':pred.tolist(),'metrics':score},indent=2))
    models[name]=(final,feat,score)
    joblib.dump(final,P/'models'/f'{name}.joblib',compress=3)
# Nontrainable comparator: 3-nearest neighbor in original pixel space.
base=KNeighborsClassifier(n_neighbors=3);base.fit(x[np.concatenate([train,val])],y[np.concatenate([train,val])]);baseline=metric(base.predict(x[test]),test)
print('raw-knn',baseline['accuracy'])

# ChatGPT provided one-pass, precommitted predictions. Ground truth exposed only here.
chat=json.loads((P/'data'/'chatgpt_blind_predictions.json').read_text())['ordered_predictions']; truth=json.loads((P/'data'/'blind_ground_truth.json').read_text())['labels']
assert len(chat)==len(truth)==30
chat_metric={'n':30,'correct':sum(a==b for a,b in zip(chat,truth)), 'predictions':chat,'truth':truth,'indices':blind.tolist(),'untrained_visual_one_batch':True}
chat_metric['accuracy']=chat_metric['correct']/30
print('blind ChatGPT visual',chat_metric['correct'],'/',30,'accuracy',chat_metric['accuracy'])

# Identical 30 images; the supervised Beta-related adapters were trained on ~1437 other images.
blind_models={}
for name,(model,feat,score) in models.items():
    pred=model.predict(feat[blind]);blind_models[name]={'n':30,'correct':int((pred==y[blind]).sum()),'accuracy':float((pred==y[blind]).mean()),'predictions':pred.tolist()}
    print('on same 30:',name,blind_models[name]['correct'])

# Guaranteed synthetic photometric perturbations applied only to recorded *test images*.
# Identity validated against analytical Beer-Lambert optical law. Since originals
# are scanner ink counts, 
# the numbers below are NOT physical transmission measurements. The optics is
# applied as an intentionally controlled mathematical image perturbation.

def attenuate(a,mu=0,L=0):
    return np.clip(np.asarray(a,dtype=float)*np.exp(-mu*L),0,1)

raw_model=models['raw-rbf'][0]
scenes=[('clean_original',0,0),('attenuation_d1_mu.35',.35,1),('attenuation_d2_mu.35',.35,2),('attenuation_d3_mu.35',.35,3),('attenuation_d4_mu.35',.35,4)]
perturb={}
for name,mu,L in scenes:
    z=attenuate(x[test],mu,L)
    pred=raw_model.predict(z)
    oracle=np.clip(z*np.exp(mu*L),0,1)
    oracle_pred=raw_model.predict(oracle)
    perturb[name]={'raw':metric(pred,test),'known_law_oracle':metric(oracle_pred,test),'applied_transmission':float(np.exp(-mu*L)), 'real_samples':len(test),'synthetic_transformation':name!='clean_original'}
    print('synthetic perturb',name,round(perturb[name]['raw']['accuracy'],3),round(perturb[name]['known_law_oracle']['accuracy'],3),flush=True)

# A fixed (predeclared) supervised data-augmentation test. No access to holdout labels.
tr=np.concatenate([train,val]);train_clean=x[tr]
aug=np.concatenate([attenuate(train_clean,.35,L) for L in [0,1,2,3]])
y_aug=np.tile(y[tr],4)
aug_clf=make_pipeline(StandardScaler(),SVC(C=models['raw-rbf'][2]['chosen_C'],gamma='scale',kernel='rbf'))
aug_clf.fit(aug,y_aug)
joblib.dump(aug_clf,P/'models'/'attenuation-trained.joblib',compress=3)
for name,mu,L in scenes:
    z=attenuate(x[test],mu,L)
    score=metric(aug_clf.predict(z),test)
    perturb[name]['train_augmented_classifier']=score
    print('augmented classifier:',name,round(score['accuracy'],3),flush=True)

r={'research_kind':'real scanned labeled data + separate synthetic optical perturbations',
   'dataset':{'name':'scikit-learn optical recognition digits (NIST preprocessed, UCI source)','n':len(x),'pixel_shape':[8,8],'pixel_range':[0,16],'train':len(train),'validation':len(val),'test':len(test),'source_url':'https://scikit-learn.org/stable/modules/generated/sklearn.datasets.load_digits.html'},
   'features_provenance':'Active untouched Ripple v0.1 LIF, Ripple v0.6 log frontend, Ripple v0.7 Q encoder; raster scan is not a temporal camera stream',
   'models':{k:v[2] for k,v in models.items()},'knn_pixel_baseline':baseline,
   'chatgpt_blind_test':chat_metric,'models_same_30':blind_models,
   'photometric_synthetic_test':perturb,
   'safety':{'physical_photo_sensor_tested':False,'camera_calibration_applied':False,'absolute_photon_units':False,'digit_scans_are_radiance':False,'chatgpt_API_invoked':False,'chatgpt_baseline':'GPT-6 visual predictions through one unlabeled screenshot of 8x8 digits, not a separate API'}}
(P/'data'/'results.json').write_text(json.dumps(r,indent=2))
print('RESULTS SAVED',P/'data'/'results.json',flush=True)
