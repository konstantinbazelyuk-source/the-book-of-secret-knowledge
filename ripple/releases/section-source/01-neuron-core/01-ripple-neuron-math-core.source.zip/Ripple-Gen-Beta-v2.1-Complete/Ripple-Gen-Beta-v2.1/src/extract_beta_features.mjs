/** Actual unchanged Ripple LIF + v0.6 photoreceptor + v0.7 QuadEncoder
 *  on recorded scanner images. Spatial raster scan is a deliberate
 *  representation choice; not a physically time-sequential exposure.
 */
import {readFileSync,writeFileSync} from 'node:fs';
import {RippleNeuron,Photoreceptor,QuadEncoder} from '../archive/Ripple-Gen-Beta-v2.0/src/beta-engine.mjs';
const [input,output]=process.argv.slice(2);if(!input||!output)throw Error('Expected input JSON and output JSON');
const {images}=JSON.parse(readFileSync(input,'utf8'));const all=[];
for(const values of images){
 if(!Array.isArray(values)||values.length!==64||values.some(v=>!Number.isFinite(v)||v<0||v>16))throw Error('Invalid scan pixel');
 const neuron=new RippleNeuron(),photo=new Photoreceptor({linear:false,logGain:8}),quad=new QuadEncoder({threshold:.12,dwell:1});
 const features=[],gray=values.map(v=>v/16);
 let ev=0,onTot=0,offTot=0;
 for(let row=0;row<8;row++){
  let spikes=0,theta=0,rate=0,voltage=0,on=0,off=0,qHist=[0,0,0,0];
  for(let col=0;col<8;col++){
   const pix=gray[row*8+col];
   const base=neuron.step([pix,0,0],.05);
   const p=photo.step([pix,0,0],.05);
   const q=quad.step({drive:base.drive});
   spikes+=base.count;ev+=base.count;theta+=base.theta;rate+=base.rate;voltage+=base.u;
   on+=p.on[0];off+=p.off[0];onTot+=p.on[0];offTot+=p.off[0];qHist[q.code]++;
  }
  features.push(spikes/8,theta/8,rate/8,voltage/8,on/64,off/64,...qHist.map(x=>x/8));
 }
 all.push({features,events:ev,on:onTot,off:offTot});
}
writeFileSync(output,JSON.stringify({source:'locked Ripple v0.1 LIF, v0.6 Photoreceptor, v0.7 QuadEncoder',units:'8x8 normalized scanner pixel sequence; spatial order only',features:all}));
console.log(JSON.stringify({samples:all.length,feature_len:all[0].features.length,meanEvents:all.reduce((s,x)=>s+x.events,0)/all.length}));
