import json,math,hashlib
from pathlib import Path
import numpy as np
from scipy.stats import binomtest
from statsmodels.stats.proportion import proportion_confint
P=Path(__file__).resolve().parents[1]
r=json.loads((P/'data/results.json').read_text())
def wilson(correct,n):return [float(v) for v in proportion_confint(correct,n,method='wilson')]

def paired(a,b,n):
   ea=set(a['errors']);eb=set(b['errors']);a_only=len(ea-eb);b_only=len(eb-ea)
   discord=a_only+b_only
   p=binomtest(a_only,n=discord,p=.5).pvalue if discord else 1
   return {'n':n,'A_wrong_B_right':a_only,'A_right_B_wrong':b_only,'two_sided_exact_McNemar_p':float(p),'A_correct':n-len(ea),'B_correct':n-len(eb)}
a=r['models']['raw-rbf'];b=r['models']['raw-plus-ripple'];c=r['models']['ripple-lif-quad']
audit={'confidence_interval_method':'Wilson 95% interval for descriptive sample accuracies; not a writer-disjoint CI.',
  'genuine_holdout':{name:{'correct':val['correct'],'n':val['n'],'CI95':wilson(val['correct'],val['n'])} for name,val in r['models'].items()},
  'raw_vs_fused':paired(a,b,360),'raw_vs_ripple_only':paired(a,c,360),
  'ChatGPT_one_batch':{'correct':r['chatgpt_blind_test']['correct'],'n':30,'CI95':wilson(r['chatgpt_blind_test']['correct'],30),
    'precommitted_sha256':hashlib.sha256((P/'data/chatgpt_blind_predictions.json').read_bytes()).hexdigest(),
    'caveat':'Not matched training; not a fair general intelligence comparison.'},
  'synthetic_light_interventions':{k:{'raw_vs_aug':paired(v['raw'],v['train_augmented_classifier'],360),
                                    'oracle_correct':v['known_law_oracle']['correct'],
                                    'transmission':v['applied_transmission']}
                                   for k,v in r['photometric_synthetic_test'].items()}}
(P/'data'/'statistical_audit.json').write_text(json.dumps(audit,indent=2))
print(json.dumps({'raw_vs_fused':audit['raw_vs_fused'],
 'chat_ci':audit['ChatGPT_one_batch']['CI95'],'d4':audit['synthetic_light_interventions']['attenuation_d4_mu.35']},indent=2))
