# Ripple Neuron v0.6 — Photoreceptor and Optical-Math Study

**Independent, runnable research build · 13 October 2026 · Concept: Constantin x · original code/materials CC0-1.0**

## What this build actually does

An **optional optical frontend** transforms either (a) user-entered three-channel RGB numbers or (b) three mean RGB image-channel values taken from a webcam. It supplies bounded values to the **unchanged original Ripple Neuron v0.1** leaky-integrate-and-fire core. New components are additive and OFF by default.

1. **Approximate sRGB inverse transfer (optional):** encoded RGB is mapped to *display-referred linear-light estimates* using the standard piecewise sRGB function. This is **NOT sensor RAW, irradiance calibration, photon measurement, or a guarantee about webcam gamma**.
2. **Logarithmic low-light compression (optional):** `log(1+kI)/log(1+k)` maps input [0,1] to a bounded code. K is a user-selected gain, not a learned parameter.
3. **Three-channel temporal-contrast response:** detect positive (ON) or negative (OFF) changes in `ln(I+epsilon)` when the change from the encoder reference exceeds a selected threshold. OFF changes are **logged but not injected as separate inhibition**; ON events can optionally boost the current RGB input. All event counts are **software-generated**, from a frame-based camera. This is NOT a true DVS.
4. **Beer–Lambert simulation:** `I_i = I_0i exp(-mu_i L)`. User-supplied three-channel coefficients and relative path length are NOT physically measured spectra, concentrations, or distances. Scattering, broad-band sensors, and surface reflection break a naive interpretation.
5. **Preservation:** original emitter/AS7341/Pico physical plan remains proposed and untouched; original neuron weight equation `D=2R+1.2G-1.4B`, threshold adaptation, sample stepping and 120-second comparison are unchanged.

## Run directly on your computer with a local camera

The files in `web/` are a standalone installable web app. Serve them from a local trusted origin: `cd web && python3 -m http.server 8000`, then visit `http://localhost:8000` in desktop Chrome/Edge. The browser treats localhost as a potentially trustworthy origin for camera APIs. Click **Phone / computer webcam**, choose the camera, start it, and allow permission. If `file://` or `content://` camera permission is denied, use localhost/HTTPS. Offline computation needs no OpenAI, account, or paid subscription. The app does not upload your images. Existing observer telemetry network sharing is opt-in only.

A separate HTTPS host is necessary to install/use the browser app on a phone reliably. **The existing published Floot site is still v0.5 at the time of this package:** v0.6 was coded in the isolated Floot development project, but the next production publish was blocked by Floot's daily build quota. No false deployment claim is made. This self-contained release can run on localhost immediately.

## Repeatable numerical verification

- `node tests/check_phone_model.cjs` — original unmodified model, dark inhibition, numeric experiment (0.95 Hz adaptive, 3.40 Hz fixed in bright step)
- `node tests/check_observer.cjs` — observer regression
- `node tests/check_v06.cjs` — 9 optical/photoreceptor tests; 50,000 bounded random inputs + 40 noise-grid conditions + 10,000 dark samples; all PASS
- `node tests/study_v06.cjs` — regenerate the 49-case threshold/noise parameter sweep and 40s temporal step sequence. Generates `numerical-study.json` and `noise-sweep.csv`.
- `python tests/verify_browser.py` — Chromium desktop and 390px mobile UI smoke test, original experiment, optional controls and temporal sequence. This environment used an `about:blank` test canvas where real webcam access was not available; **no camera is claimed physically verified**.

## Bounded, measured, simulated, proposed

| Claim | Evidence tier | Result |
|---|---|---|
| Original v0.1 120s comparison preserved | Executed numerical regression | 0.95 vs 3.40 Hz in specified bright-step window |
| New low-light gamma/log and ON/OFF encoder executes | Executed synthetic tests | Tests pass; temporal sequence produced 11 ON and 6 OFF software events in one particular seeded scenario |
| 0.005 peak-to-peak synthetic camera noise and threshold 0.25 | Simulated 1,000-step noise sequence | 0 false temporal events in the designated steady windows, 6 ON and 6 OFF at the large simulated step |
| 0.08 peak-to-peak synthetic noise and threshold 0.25 | Simulated 1,000-step noise sequence | 420 false temporal events, a demonstrated weakness |
| Camera photometry, calibration and physical scattering | Not measured | Browser video must be tested on real hardware with known light sources; true absorption/distance cannot be inferred from RGB alone |
| Learning, intelligence, consciousness | Not established | These extensions do not add or prove them |

## Papers and specifications studied

- W3C — Specification of sRGB: https://www.w3.org/Graphics/Color/srgb.pdf
- Gallego et al., *Event-based Vision: A Survey* (2020), IEEE TPAMI: https://doi.org/10.1109/TPAMI.2020.3008413
- Review of Beer–Lambert law limitations in scattering samples: https://pmc.ncbi.nlm.nih.gov/articles/PMC8553265/
- MDN — Browser camera constraints: https://developer.mozilla.org/en-US/docs/Web/API/Media_Capture_and_Streams_API/Constraints
- Original Ripple Neuron mathematical core and engineering brief included in prior release v0.1, not reauthored here.

## Next physical experiment

Lock/record exposure and white balance where the browser actually exposes controls, fix the webcam and illuminated target, sample dark/clear/colored references, vary one controlled optical property at a time, export raw and encoded event streams, and compare repeated trials. Report camera-specific settings and failures, including automatic-exposure drift. Don't promote a numerical model to a physical optical sensor claim.
