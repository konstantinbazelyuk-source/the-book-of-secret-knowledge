const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
vm.runInThisContext(fs.readFileSync(path.join(__dirname,'../web/ripple-core.js'),'utf8'));
const {Photoreceptor,absorb,opacityCal}=require('../web/photoreceptor-v06.js');
const seedInit=7432;
function seedRand(start=seedInit){let seed=start;return()=>((seed=(seed*1664525+1013904223)>>>0)/4294967296);}
const cases=[],series=[];
for(const noise of [0,.002,.005,.01,.02,.05,.08])for(const th of [.10,.15,.2,.25,.35,.5,.8]){
 const p=new Photoreceptor({contrastThreshold:th,logGain:8,transientGain:.35}),rnd=seedRand();
 let falseEvents=0,realOn=0,realOff=0,postEvents=0;
 for(let i=0;i<1000;i++){
  const base=i>=300&&i<600?[.38,.08,.04]:[.12,.08,.04],rgb=base.map(v=>Math.max(0,Math.min(1,v+(rnd()-.5)*noise)));
  const r=p.step(rgb,.05),count=r.on.reduce((a,b)=>a+b,0)+r.off.reduce((a,b)=>a+b,0);
  if(i>=60&&i<280||i>=680){falseEvents+=count;}
  if(i>=300&&i<310)realOn+=r.on[0];
  if(i>=600&&i<610)realOff+=r.off[0];
  if(i>=300&&i<600)postEvents+=count;
 }
 cases.push({noisePeakToPeak:noise,logContrastThreshold:th,falseEvents,realOn,realOff,signalDetected:realOn>0&&realOff>0,postEvents});
}
const p=new Photoreceptor(),baseline=new RippleNeuron(),enhanced=new RippleNeuron();let seed=414;const rnd=seedRand(414);let cumulativeLegacy=0,cumulativeNew=0,onTotal=0,offTotal=0;
for(let i=0;i<800;i++){
 const time=i*.05;
 const ideal=i<100?[.12,.08,.04]:i<250?[.34,.08,.04]:i<350?[.12,.08,.04]:[.12,.25,.04];
 const rgb=ideal.map(v=>Math.max(0,Math.min(1,v+(rnd()-.5)*.004)));
 const enc=p.step(rgb,.05),raw=baseline.step(rgb,.05),neu=enhanced.step(enc.output,.05);
 cumulativeLegacy+=raw.count;cumulativeNew+=neu.count;
 onTotal+=enc.on.reduce((s,v)=>s+v,0);offTotal+=enc.off.reduce((s,v)=>s+v,0);
 if(i%5===0)series.push({time_s:+time.toFixed(2),raw_r:rgb[0],raw_g:rgb[1],enhanced_r:enc.output[0],legacy_hz:raw.rate,enhanced_hz:neu.rate,legacy_theta:raw.theta,enhanced_theta:neu.theta,on_red:enc.on[0],off_red:enc.off[0]});
}
const run=runExperiment();const summary={type:'NUMERICAL SIMULATION ONLY',dt_s:.05,steps:1000,noiseAndThresholdCases:cases.length,zeroNoiseFalseEventsAt025:cases.find(x=>x.noisePeakToPeak===0&&x.logContrastThreshold===.25)?.falseEvents,lowNoiseCase:cases.find(x=>x.noisePeakToPeak===.005&&x.logContrastThreshold===.25),highNoiseCase:cases.find(x=>x.noisePeakToPeak===.08&&x.logContrastThreshold===.25),legacyBrightWindowHz:run.windows[1].fixed_hz,adaptiveBrightWindowHz:run.windows[1].adaptive_hz,temporalExample:{legacyNeuronEvents:cumulativeLegacy,enhancedNeuronEvents:cumulativeNew,softwareOnEvents:onTotal,softwareOffEvents:offTotal},interpretation:'No learning measured. Threshold and gamma choices are research controls, not optimized guarantees.'};
const root=path.join(__dirname,'..');fs.writeFileSync(path.join(root,'numerical-study.json'),JSON.stringify({summary,noiseCases:cases,temporalSeries:series},null,2));
fs.writeFileSync(path.join(root,'noise-sweep.csv'),['noise_peak_to_peak,log_contrast_threshold,false_events,signal_on,signal_off,detected',...cases.map(x=>[x.noisePeakToPeak,x.logContrastThreshold,x.falseEvents,x.realOn,x.realOff,Number(x.signalDetected)].join(','))].join('\n'));
console.log(JSON.stringify(summary,null,2));
