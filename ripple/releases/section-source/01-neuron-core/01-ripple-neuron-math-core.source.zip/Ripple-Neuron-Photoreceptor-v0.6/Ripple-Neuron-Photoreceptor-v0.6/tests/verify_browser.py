from pathlib import Path
import os
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
html=(ROOT/'web/index.html').read_text()
for file in ['photoreceptor-v06.js','observer-core.js','observer-ui.js']:
 html=html.replace(f'<script src="./{file}"></script>', '<script>'+ (ROOT/'web'/file).read_text() + '</script>')
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--use-fake-device-for-media-stream','--use-fake-ui-for-media-stream'])
 for kind,size in [('phone',{'width':390,'height':844}),('desktop',{'width':1250,'height':860})]:
  context=browser.new_context(viewport=size,device_scale_factor=1,permissions=['camera'],is_mobile=kind=='phone',has_touch=kind=='phone')
  page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(html,wait_until='load');page.wait_for_timeout(250)
  assert page.locator('#view-live').is_visible()
  assert page.locator('#rec-enable').count()==1
  assert page.locator('#abs-enable').count()==1
  page.locator('#rec-enable').check();page.locator('#abs-enable').check()
  page.locator('#abs-path').fill('2');page.locator('#abs-r').fill('1')
  page.wait_for_timeout(1100)
  value=page.evaluate('app.processed')
  assert value and all(isinstance(x,(int,float)) and 0<=x<=1 for x in value),str(value)
  page.locator('#rec-enable').uncheck();page.locator('#abs-enable').uncheck()
  page.wait_for_timeout(200)
  page.locator('[data-view="experiment"]').click();page.locator('#run-experiment').click()
  original=page.locator('#results').inner_text()
  assert '0.95' in original and '3.40' in original
  page.locator('#run-retina').click()
  retina=page.locator('#retina-results').inner_text()
  assert 'synthetic ON' in retina and 'synthetic' in retina
  page.locator('[data-view="live"]').click();page.locator('#camera-mode').click()
  page.locator('#start-camera').click();page.wait_for_timeout(2200)
  camera_status=page.locator('#camera-status').inner_text()
  rgb=page.locator('#raw-rgb').inner_text()
  print('CAMERA cannot be tested in about:blank browser environment:',camera_status)
  page.locator('#stop-camera').click()
  page.screenshot(path=str(ROOT/('preview-'+kind+'.png')),full_page=False)
  print(kind,'retina:',retina,'camera:',camera_status,'rgb:',rgb,'pageerrors:',errors)
  assert not errors,errors
  context.close()
 browser.close()

print('PASS: phone and desktop browser app, optional front-end, original experiment, temporal experiment, camera hardware not verified')
