# Safe integration notes

Origin: Ripple Gen Beta v2.1 optical evidence module, `src/photometry.mjs`.
Add-on: `src/formula-compiler.mjs` introducing an allowlisted operation named `beer_lambert` with strict validation.

**Locked**: original v0.1 neuron hash `dba6639b7902f0c702d15fff588524629f3754cfd72d7b704f22a76b78960ee3`.
**Unmodified**: the user-approved Gen Beta v2.1 package and the v1.2 JavaScript change gate.
**Added**: formula descriptor and four bounded operations, calculated-versus-simulated provenance labels, offline calculator, CLI, and tests.

Input adapter example:

```
Optical instrumentation (external calibration required)
   ↓
I0, I, mu, L (consistent units)
   ↓
Ripple formula compiler: beer_lambert
   ↓
{I,T,OD10} tagged CALCULATED
   ↓
Optional downstream neuron preprocessing in a separately approved version
```

There is no camera access, material-density estimation, remotely executed JS, or autonomous action in this add-on.

The formula `T = exp(-mu*L)` is one idealized law; not a general model of occlusion, diffuse scattering, fluorescence, or reflection. Only apply it in scenarios matching its assumptions.
