#!/usr/bin/env node
import {readFileSync} from 'node:fs';
import {compileFormula,executeRecipe,listFormulas} from './formula-compiler.mjs';
const usage='Usage: node src/ripple-math-cli.mjs list | schema | eval <JSON or ->';
try{
 const [command,arg]=process.argv.slice(2);
 if(command==='list'){console.log(JSON.stringify(listFormulas(),null,2));}
 else if(command==='schema'){console.log(JSON.stringify({formula:'beer_lambert',mode:'forward',inputs:{I0:1,mu:0.35,L:2}},null,2));}
 else if(command==='eval'){
  if(!arg)throw Error(usage);
  const json=arg==='-'?readFileSync(0,'utf8'):arg;
  if(json.length>8192)throw Error('Recipe exceeds 8 KiB');
  const recipe=JSON.parse(json);
  console.log(JSON.stringify(executeRecipe(recipe),null,2));
 }else{console.error(usage);process.exitCode=2;}
}catch(e){console.error('Ripple Mathematics Compiler:',e.message);process.exitCode=2;}
