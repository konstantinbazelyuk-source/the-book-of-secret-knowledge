import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {compileFormula,executeRecipe,listFormulas} from '../src/formula-compiler.mjs';
import {beerLambert} from '../src/photometry.mjs';
const forward=(I0,mu,L)=>executeRecipe({formula:'beer_lambert',mode:'forward',inputs:{I0,mu,L}});
const near=(a,b,tol=1e-12)=>Math.abs(a-b)<=tol*Math.max(1,Math.abs(a),Math.abs(b));

test('registry contains a single allowlisted scientific formula',()=>{
 const items=listFormulas();assert.equal(items.length,1);assert.equal(items[0].equation,'I = I0 * exp(-mu * L)');
 assert.equal(items[0].units.mu,'m^-1');assert.equal(items[0].units.L,'m');
 assert.equal(compileFormula({formula:'beer_lambert',mode:'forward'}).metadata.evidence,'CALCULATED');
});
test('forward formula delegates to unchanged v2.1 optical function',()=>{
 const result=forward(1,.35,2);assert.ok(near(result.I,beerLambert(1,.35,2)));
 assert.ok(near(result.I,Math.exp(-.7)));assert.ok(near(result.T,result.I));
 assert.ok(near(result.OD10,.7/Math.log(10)));
 assert.ok(near(result.lossFraction,1-result.T));
});
test('attenuation has multiplicative path composition and reference case',()=>{
 const I0=2.5,mu=.35;const I=forward(I0,mu,2).I;
 assert.ok(near(forward(I,mu,3).I,forward(I0,mu,5).I));
 assert.ok(near(forward(1,Math.log(2),1).I,.5));
 assert.equal(forward(.8,0,9).I,.8);
 assert.equal(forward(0,2,2).I,0);
});
test('inverse solves attenuation coefficient and path with known reference intensities',()=>{
 const I0=7,mu=.23,L=2.6,I=forward(I0,mu,L).I;
 const invmu=executeRecipe({formula:'beer_lambert',mode:'solve_mu',inputs:{I0,I,L}});
 const invL=executeRecipe({formula:'beer_lambert',mode:'solve_L',inputs:{I0,I,mu}});
 assert.ok(near(invmu.mu,mu));assert.ok(near(invL.L,L));
 assert.equal(invmu.evidence,'CALCULATED');
});
test('absorbance base conversion and analytic sensitivity derivatives',()=>{
 const I0=4,mu=.21,L=2.2,h=1e-6,r=forward(I0,mu,L);
 assert.ok(near(r.dIdI0,r.T));
 assert.ok(near(r.dIdMu,-L*r.I));assert.ok(near(r.dIdL,-mu*r.I));
 assert.ok(near((forward(I0,mu,L+h).I-forward(I0,mu,L-h).I)/(2*h),r.dIdL,1e-8));
 assert.ok(near((forward(I0,mu+h,L).I-forward(I0,mu-h,L).I)/(2*h),r.dIdMu,1e-8));
});
test('optional three-channel model is independent per channel and not called measured',()=>{
 const result=executeRecipe({formula:'beer_lambert',mode:'rgb_forward',inputs:{rgb:[1,.5,.25],muRGB:[0,.3,.7],L:2}});
 assert.ok(near(result.output[0],1));
 assert.ok(near(result.output[1],.5*Math.exp(-.6)));
 assert.ok(near(result.output[2],.25*Math.exp(-1.4)));
 assert.equal(result.evidence,'SIMULATED');
});
test('guard rejects invalid numeric values, impossible attenuation and invalid inverse',()=>{
 const bad=[{I0:-1,mu:1,L:1},{I0:1,mu:-1,L:1},{I0:1,mu:1,L:-1},{I0:1,mu:1,L:Infinity},{I0:1,mu:100,L:2},{I0:NaN,mu:1,L:1},{I0:1,mu:0,L:1e309}];
 for(const p of bad)assert.throws(()=>forward(p.I0,p.mu,p.L));
 for(const mode of ['solve_L','solve_mu']){
  const third=mode==='solve_L'?'mu':'L';
  assert.throws(()=>executeRecipe({formula:'beer_lambert',mode,inputs:{I0:1,I:0,[third]:1}}));
  assert.throws(()=>executeRecipe({formula:'beer_lambert',mode,inputs:{I0:1,I:2,[third]:1}}));
  assert.throws(()=>executeRecipe({formula:'beer_lambert',mode,inputs:{I0:1,I:.5,[third]:0}}));
 }
});
test('compiler rejects unknown formulas and arbitrary code/data fields',()=>{
 assert.throws(()=>compileFormula({formula:'user_script',mode:'forward'}));
 assert.throws(()=>compileFormula({formula:'beer_lambert',mode:'javascript'}));
 assert.throws(()=>executeRecipe({formula:'beer_lambert',mode:'forward',inputs:{I0:1,mu:1,L:1,eval:'process.exit(1)'}}));
 assert.throws(()=>executeRecipe({formula:'beer_lambert',mode:'forward',inputs:{I0:'1',mu:1,L:1}}));
 assert.throws(()=>executeRecipe({formula:'beer_lambert',mode:'forward',inputs:{I0:1,mu:1,L:1},newField:true}));
});
test('original Ripple neuron code SHA-256 remains unchanged',()=>{
 const original=readFileSync(new URL('../archive/Ripple-Gen-Beta-v2.0/legacy/ripple-core.js',import.meta.url));
 assert.equal(createHash('sha256').update(original).digest('hex'),'dba6639b7902f0c702d15fff588524629f3754cfd72d7b704f22a76b78960ee3');
});
test('deterministic bounded randomized property checks',()=>{
 let seed=92755;const rng=()=>((seed=(1664525*seed+1013904223)>>>0)/2**32);
 for(let i=0;i<3000;i++){
  const I0=.01+100*rng(),mu=3*rng(),L=15*rng(),d=mu*L;
  const out=forward(I0,mu,L);
  assert.ok(out.I<=I0 && out.I>=0);
  assert.ok(out.T<=1 && out.T>0);
  assert.ok(near(out.I,I0*Math.exp(-d)));
  assert.ok(near(out.OD10,d/Math.LN10));
 }
});
