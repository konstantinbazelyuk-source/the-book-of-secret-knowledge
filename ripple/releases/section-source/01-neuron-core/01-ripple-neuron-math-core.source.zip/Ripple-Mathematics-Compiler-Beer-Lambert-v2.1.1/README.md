# Ripple Mathematics Compiler — Beer–Lambert v2.1.1

**Status:** executable, verified mathematical-compiler add-on, not physical optical measurement. The originally approved v2.1 and neuron v0.1 files have not been modified.

## Formula registered

**Natural exponential attenuation**: `I = I0 × exp(-mu × L)`.

- `I0` is input radiant intensity/power/irradiance in any **consistent, fixed** unit.
- `I` is output radiant intensity/power/irradiance in the **same** unit.
- `mu` is the supplied absorption coefficient in **m⁻¹**.
- `L` is the supplied optical path length in **m**.
- `mu×L` is dimensionless. The program rejects negative or nonfinite values and restricts numerical optical depth to `0≤mu×L≤100`.

The compiler's `beer_lambert` operation is registered with four bounded modes:

| Mode | Inputs | Output |
|---|---|---|
| `forward` | I0, mu, L | I; transmittance T; loss fraction; decadic optical density OD10; derivatives |
| `solve_mu` | I0, independently observed I, nonzero L | mu and associated T, OD10 |
| `solve_L` | I0, independently observed I, nonzero mu | L and associated T, OD10 |
| `rgb_forward` | three model channel intensities, three synthetic mu values, L | channelwise attenuation; tagged **SIMULATED** |

The compiler uses the unchanged and independently tested `src/photometry.mjs:beerLambert` calculation from Gen Beta v2.1 and does not use `eval`, `new Function`, file/network access, a free-form expression parser, or the separate restricted JavaScript policy gate. Unknown formula IDs, operations, input keys, and values are rejected.

Decadic absorbance/optical density is **A = μL / ln(10)**; note that the IUPAC molar decadic extinction coefficient ε and concentration c have `μ = ln(10)εc` when units agree. Do not confuse a natural exponent coefficient with decadic absorbance coefficients.

## Execute

Open `Ripple-Mathematics-Compiler-v2.1.1.html` in a normal browser; it is a self-contained, offline scientific calculator. The same calculation is also available through Node.js:

```bash
node src/ripple-math-cli.mjs list
node src/ripple-math-cli.mjs schema
node src/ripple-math-cli.mjs eval '{"formula":"beer_lambert","mode":"forward","inputs":{"I0":1,"mu":0.35,"L":2}}'
node --test tests/*.test.mjs
```

Expected example (CALCULATED): `I=0.4965853037914095`, `T=0.4965853037914095`, `OD10=0.3040061373322762`.

Example registered use in another Ripple ES module:

```javascript
import { compileFormula } from './formula-compiler.mjs';
const equation = compileFormula({formula:'beer_lambert',mode:'forward'});
const result = equation.evaluate({I0:1,mu:0.35,L:2});
console.log(result.I); // 0.4965853037914095 (calculated)
```

## Applying the add-on to the existing Beta

The actual formula's **core** was already present in the last verified Ripple Gen Beta v2.1 optical study. This release makes it accessible through a safe formula compiler registry and an offline user interface. To integrate without modifying v2.1 in place:

1. Copy `src/formula-compiler.mjs` to a new versioned branch or release's `src/` directory **next to its existing `photometry.mjs`**.
2. Import and call `compileFormula` / `executeRecipe` as shown above.
3. Copy the new test file into that versioned release and run its Node tests. Keep v2.1 and the v0.1 neuron immutable.
4. Reproduction requires no network, API key, or sensor. No actual camera data was used.

The original v0.1 source copy inside `archive/` is present **only as a checksum-preservation reference**; it is not modified or executed by the new compiler. The complete Gen Beta v2.1 package remains a separate, preserved release.

## Scientific limitations

Beer–Lambert absorption assumes a collimated narrowband beam and a sufficiently homogeneous, non-scattering absorbing medium. **Reflection, scattering, camera nonlinearity, mixed spectrum, ambient illumination, and path geometry are separate effects.** A consumer camera frame alone is insufficient to infer physical material density, μ, or L.

A solved μ or L is **CALCULATED** from supplied input values; if the inputs were laboratory measurements, their calibration/uncertainty/provenance must be provided separately. This compiler never marks any output as physically measured.

## Verification evidence

The development run executed **21 passing Node tests**: 9 previous optical tests, 10 compiler numerical/guard/regression tests, and 2 standalone script checks. The numerical randomized test covered **3,000 deterministic samples**. A browser-like execution of the single-file script was tested using Node's `vm` and an instrumented DOM stub. A real headless Chromium navigation attempt was blocked by the test environment, so no real browser run is claimed.

## Sources

- International Union of Pure and Applied Chemistry (IUPAC), *Beer–Lambert law*, Gold Book B00626: https://goldbook.iupac.org/terms/view/B00626
- IUPAC, *transmittance*, Gold Book T06484: https://goldbook.iupac.org/terms/view/T06484
- Original approved Ripple Gen Beta v2.1 file: `src/photometry.mjs` (unchanged copy, hashed in manifest).
