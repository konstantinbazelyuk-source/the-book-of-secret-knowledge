# Stage 2 — Controlled tests of more complex behavior (NOT IMPLEMENTED)

**Do not begin until Stage 1's observer is validated on the actual phone.** Stage 2 is an independent test module, not a silent change to the v0.1 neuron.

## What must be established before Stage 2

- Original adaptive/fixed brightness-step test still equals the published baseline.
- Camera samples and model event logs can be recorded on the phone with time stamps and calibration metadata.
- Controlled red, green, blue and dark trials are compared to manual-mode trials.
- Signal dropouts and camera exposure/white-balance changes are documented.
- Each result is labeled `manual synthetic input`, `camera RGB input`, or `AS7341 hardware` (if later acquired). Never merge these evidence types.
- Online transfer is confirmed with receipt IDs or unique `(session_id, seq)` acknowledgements and no unapproved uploads.

## Experiments (sequential, gated)

**B1: Coupled two-node network.** Create two copies of the *unchanged* RippleNeuron core in an independent test file. Route the previous time step's event from neuron A to a user-selected red/green/blue input of B. Keep bounded input, deterministic seeds and a fixed update interval. Compare coupling ON/OFF, including cross-correlation, latency, stability and response to light sequences. No feedback should create zero-time self-loops.

**B2: Task-specific plasticity, not consciousness.** Give the coupled system an objectively scored task, such as classifying two temporal RGB sequences. Implement a separate bounded update rule for connection weights. Use fixed train/validation/test stimuli; a fresh unseen test set; compare against (1) random, (2) fixed-weight neurons and (3) an ordinary software classifier. Report accuracy and number of evaluations, not subjective claims of intelligence.

**B3: Control task.** After B2 passes, use the same architecture to control a simulated actuator toward a target. Compare task completion, noise tolerance, response latency, oscillation, and resource usage against a straightforward electronic controller (e.g., PID). Do not connect motors without power and safety review.

**B4: Online/offline parallel validation.** Both modes must produce the same model outputs from the same timestamped inputs. The online service may analyze or store data, but must never inject actuator commands into the original model without a separately reviewed protocol and owner authorization.

## Nonclaims

Firing, homeostasis, association, and task learning do not establish sentience, subjective experience or artificial general intelligence. Results should be described as measured behaviors of a computational system. The Android camera is not an AS7341 sensor and does not measure optical electric or magnetic field oscillations.

## Change control

Keep `ripple-core.js` byte-for-byte unchanged. Add new modules and tests rather than rewriting it. No production activation, API spending, social posting or external communications without the owner's approval.
