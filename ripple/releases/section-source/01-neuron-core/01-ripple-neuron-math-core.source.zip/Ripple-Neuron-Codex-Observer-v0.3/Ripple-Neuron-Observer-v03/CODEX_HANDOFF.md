# Codex implementation handoff — Ripple Neuron Observer v0.3

## Request

Maintain this codebase as an **Android-browser/PWA numerical sensor prototype**, with **Stage 1 (self-regulation observer)** fully isolated from the neuron core and **Stage 2 (complex-behavior experiments)** deferred until validated.

## Immutable anchor

- `ripple-core.js` and the `RippleNeuron` class in `index.html` represent the approved original model and original 120-second brightness-step experiment. Verify `CORE-SHA256.txt` and keep this code exactly as-is.
- `observer-core.js` only ingests *copies* of numeric samples. Do not allow the observer to call model mutators, change targets, inject synthetic stimuli, or repair input data silently.
- `observer-ui.js` handles consent, offline summaries, and optional data transmission.
- The receiver cannot send control commands back to the phone. No OpenAI/ChatGPT API exists in this package.

## Testing order

1. `node tests/check_phone_model.cjs`
2. `node tests/check_observer.cjs`
3. `python -m unittest discover -s tests -p 'test_*.py' -v`
4. Host the app with a local static server to test manual controls and the Observer tab.
5. Test HTTPS hosting on Android Chrome and camera permission; capture real input under controlled lighting.
6. Test the optional backend only behind HTTPS with a strong token and specific allowed origins. Verify offline retry, queue persistence and exact acknowledgment.
7. Only then address `PHASE-2-PLAN.md` as a separate feature branch.

## Acceptance gates

- Original step test windows: 20–40s adaptive 1.00/fixed 1.65; 60–80s adaptive 0.95/fixed 3.40; 100–120s adaptive 1.00/fixed 1.65.
- Observer can be reset without resetting the neuron. Observe-only telemetry must not alter event times or results.
- Manual mode works without network; offline numerical data persists locally only after the user enables recording (IndexedDB permitting).
- Online sending starts only with manual opt-in, accepts HTTPS endpoints ending `/api/telemetry`, transmits numeric one-second summaries and never sends raw images or camera pixels.
- Backend requires a bearer token and explicit origin allowlist. Store secrets server-side and never commit them to Git.
- Offline web app does not run camera collection in the background; Android may suspend web pages.

## Do not

- Do not replace the mathematical model, fabricate physical measurements, infer consciousness from event firing, or quietly extend to robot control.
- Do not promise integration with this ChatGPT conversation. An OpenAI API connection is a different, future integration with separate credentials and usage costs.
- Do not deploy or publish anything without explicit permission.
