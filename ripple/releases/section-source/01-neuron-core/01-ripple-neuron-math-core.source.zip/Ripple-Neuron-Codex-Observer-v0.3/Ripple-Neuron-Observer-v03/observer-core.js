// SPDX-License-Identifier: CC0-1.0
// Independent READ-ONLY data observer for Ripple Neuron. Never controls/modifies the neuron.
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.RippleObserverCore = api;
})(typeof globalThis === 'object' ? globalThis : null, function () {
  'use strict';
  const isFiniteNum = x => typeof x === 'number' && Number.isFinite(x);
  const clamp = (x, lo, hi) => Math.min(hi, Math.max(lo, x));
  const mean = xs => xs.length ? xs.reduce((a,b)=>a+b,0)/xs.length : 0;
  class Observer {
    constructor() { this.reset(); }
    reset() {
      this.last = null; this.bucket = null; this.rows = []; this.seq = 0;
      this.lastChange = null; this.totalEvents = 0; this.diagnostics = 'Collecting samples';
    }
    ingest(raw) {
      const p = {
        t: Number(raw.time_s), red: Number(raw.red), green: Number(raw.green), blue: Number(raw.blue),
        drive: Number(raw.drive), state: Number(raw.state), theta: Number(raw.threshold),
        estimated_hz: Number(raw.estimated_rate_hz), events: Number(raw.events),
        target: Number(raw.target), source: raw.source === 'camera' ? 'camera' : 'manual',
        calibrated: raw.calibrated === 1 || raw.calibrated === '1',
        adaptive: raw.adaptive === true || raw.adaptive === 1
      };
      if (![p.t,p.red,p.green,p.blue,p.drive,p.state,p.theta,p.estimated_hz,p.events,p.target].every(isFiniteNum) ||
          p.t < 0 || p.red < 0 || p.red > 1 || p.green < 0 || p.green > 1 ||
          p.blue < 0 || p.blue > 1 || p.events < 0 || !Number.isInteger(p.events) ||
          p.target <= 0 || p.target > 3 || p.theta < 0.14 || p.theta > 2.51) return null;
      if (this.last && p.t <= this.last.t) {
        if (p.t < this.last.t - 0.1) this.reset();
        else return null;
      }
      if (this.last && Math.abs(p.drive-this.last.drive) >= 0.25) this.lastChange = p.t;
      const index = Math.floor(Math.max(0,p.t-1e-9)); // each whole second after 0 is one bin
      if (this.bucket && index !== this.bucket.index) {
        const ready = this._finishBucket();
        this.bucket = this._newBucket(p,index);
        this._accumulate(p);
        this.last = p; this.totalEvents += p.events;
        return ready;
      }
      if (!this.bucket) this.bucket = this._newBucket(p,index);
      this._accumulate(p);
      this.last = p; this.totalEvents += p.events;
      return null;
    }
    _newBucket(p,index) {
      return {index, n:0, start_t:p.t, end_t:p.t, total_drive:0, total_theta:0, total_state:0,
        events:0, max_rate:0, target:p.target, source:p.source, calibrated:p.calibrated,
        adaptive:p.adaptive, min_theta:Infinity, max_theta:-Infinity, last_t:p.t};
    }
    _accumulate(p) {
      const b=this.bucket;
      b.n++; b.end_t=p.t; b.total_drive+=p.drive; b.total_theta+=p.theta;
      b.total_state+=p.state; b.events+=p.events; b.max_rate=Math.max(b.max_rate,p.estimated_hz);
      b.target=p.target; b.source=p.source; b.calibrated=p.calibrated; b.adaptive=p.adaptive;
      b.min_theta=Math.min(b.min_theta,p.theta); b.max_theta=Math.max(b.max_theta,p.theta);
    }
    _finishBucket() {
      const b=this.bucket;
      // Ignore incomplete bins; a page may be paused and resume minutes later.
      if (!b || b.n < 5) return null;
      const row={seq:this.seq++, model_s: Number(b.end_t.toFixed(3)),
        drive:Number((b.total_drive/b.n).toFixed(5)),
        threshold:Number((b.total_theta/b.n).toFixed(5)),
        state:Number((b.total_state/b.n).toFixed(5)),
        events:b.events, max_estimated_hz:Number(b.max_rate.toFixed(5)),target:b.target,
        source:b.source, calibrated:b.calibrated, adaptive:b.adaptive,
        count:b.n, wall_utc:new Date().toISOString()};
      this.rows.push(row);
      if (this.rows.length>3600) this.rows.shift();
      return row;
    }
    report() {
      const last=this.rows.at(-1);
      if (!last) return {status:'collecting',message:'Waiting for at least one complete second.',count:0};
      const time=last.model_s;
      const recent=this.rows.filter(r=>r.model_s>time-20);
      const duration = recent.length; // only complete 1-second bins: approximate window length
      const count=recent.reduce((s,r)=>s+r.events,0);
      const observed=duration ? count/duration : 0;
      const target=last.target;
      const thresholdShift=recent.length>1 ? last.threshold-recent[0].threshold:0;
      const drives=recent.map(r=>r.drive);
      const inputRange=drives.length?Math.max(...drives)-Math.min(...drives):0;
      const tolerance=Math.max(0.15,0.15*target);
      const possible = last.drive>0 && target>0 && (1/target > .1) &&
        (()=>{const theta=last.drive*(1-Math.exp(-(1/target-.1)/.5));return theta>=.15 && theta<=2.5;})();
      let status='collecting',message='Collect at least 15 one-second bins to evaluate regulation.';
      if (duration>=15) {
        if (!possible) {status='unreachable';message='Target may be unattainable at the current drive and threshold limits.';}
        else if (inputRange>.25) {status='changing_input';message='Input changed within this window; avoid concluding steady-state behavior.';}
        else if (Math.abs(observed-target)<=tolerance) {status='near_target';message='Window rate is near the target; this is not a proof of long-term stability.';}
        else {status='off_target';message='Window rate differs from target; continue observing recovery.';}
      }
      return {status,message,window_seconds:duration,count,observed_hz:Number(observed.toFixed(3)),
        target_hz:target,estimated_hz:last.max_estimated_hz,
        threshold:last.threshold,threshold_shift:Number(thresholdShift.toFixed(4)),
        drive:last.drive,input_range:Number(inputRange.toFixed(4)),
        total_events:this.totalEvents,source:last.source,calibrated:last.calibrated,
        adaptive:last.adaptive,model_s:last.model_s,record_count:this.rows.length};
    }
  }
  return {Observer};
});
