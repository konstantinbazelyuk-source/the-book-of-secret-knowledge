// SPDX-License-Identifier: CC0-1.0
// Optional observer and telemetry UI; only reads numerical model output.
(() => {
 'use strict';
 const $=id=>document.getElementById(id), core=globalThis.RippleObserverCore;
 if (!core) return;
 const monitor=new core.Observer();
 let session=globalThis.crypto?.randomUUID?.() || String(Date.now())+'-'+Math.random().toString(16).slice(2);
 let db=null, storageReady=false, recording=false, transmit=false, sending=false, endpoint='', bearer='';
 let writeChain=Promise.resolve(), lastDraw=0, lastSent=0;
 const memoryFallback=[];
 function notice(msg,kind='') {const e=$('obs-status'); e.textContent=msg;e.className='status '+kind;}
 function networkNotice(msg,kind=''){const e=$('obs-online-status');e.textContent=msg;e.className='status '+kind;}
 function openDB() {
  return new Promise((resolve,reject)=>{
   if(!globalThis.indexedDB) return reject(Error('IndexedDB unavailable'));
   const req=indexedDB.open('ripple-neuron-observer-v1',1);
   req.onupgradeneeded=()=>{const database=req.result;
    if (!database.objectStoreNames.contains('samples')) database.createObjectStore('samples',{keyPath:'id',autoIncrement:true});};
   req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);
  });
 }
 async function storageTx(mode, work) {
  if(!db) throw Error('Device storage unavailable');
  return new Promise((resolve,reject)=>{
   const tx=db.transaction('samples',mode),store=tx.objectStore('samples');
   let result;
   try{result=work(store);}catch(e){reject(e);return;}
   tx.oncomplete=()=>resolve(result);tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error);
  });
 }
 async function addOne(sample,sessionId) {
  const item={session_id:sessionId,record:sample};
  if(!storageReady){memoryFallback.push(item);return;}
  await storageTx('readwrite',store=>store.add(item));
 }
 async function getBatch(limit=30){
  if(!storageReady) return memoryFallback.slice(0,limit).map((v,i)=>({...v,id:i}));
  return new Promise((resolve,reject)=>{
   const arr=[],tx=db.transaction('samples','readonly'),request=tx.objectStore('samples').openCursor();
   request.onsuccess=()=>{const cursor=request.result;if(!cursor||arr.length>=limit)return;
    arr.push({...cursor.value,id:cursor.key});cursor.continue();};
   tx.oncomplete=()=>resolve(arr);tx.onerror=()=>reject(tx.error);
  });
 }
 async function dropBatch(batch){
  if(!storageReady){memoryFallback.splice(0,batch.length);return;}
  await storageTx('readwrite',store=>{for(const item of batch)store.delete(item.id);});
 }
 async function countLocal(){
  if(!storageReady) return memoryFallback.length;
  return new Promise((resolve,reject)=>{
   const req=db.transaction('samples','readonly').objectStore('samples').count();
   req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);
  });
 }
 async function updateCount(){try{$('obs-queued').textContent=String(await countLocal());}catch(e){$('obs-queued').textContent='unavailable';}}
 function observe(original) {
  if(monitor.last && Number(original.time_s)<monitor.last.t-0.1) session=globalThis.crypto?.randomUUID?.() || String(Date.now());
  const row=monitor.ingest(original);
  if(!row)return;
  if(recording){const sid=session;writeChain=writeChain.then(()=>addOne(row,sid)).then(updateCount).catch(e=>notice('Storage issue: '+e.message,'warn'));}
  if(monitor.rows.length%2===0) refresh();
 }
 globalThis.rippleObserve=observe;
 function refresh(){
  const r=monitor.report();
  $('obs-rate').textContent=r.observed_hz===undefined?'—':r.observed_hz.toFixed(2);
  $('obs-delta').textContent=r.threshold_shift===undefined?'—':(r.threshold_shift>=0?'+':'')+r.threshold_shift.toFixed(3);
  $('obs-range').textContent=r.input_range===undefined?'—':r.input_range.toFixed(3);
  $('obs-events').textContent=String(r.total_events||0);
  $('obs-state').textContent=r.status.replaceAll('_',' ').toUpperCase();
  $('obs-explanation').textContent=r.message;
  $('obs-window').textContent=r.window_seconds ? r.window_seconds+' × 1-second bins' : 'Collecting';
  drawPlot();
 }
 function drawPlot(){
  const c=$('obs-chart');if(!c||c.closest('[hidden]'))return;
  const data=monitor.rows.slice(-90),rect=c.getBoundingClientRect(),w=Math.max(300,rect.width||400),h=200,dpr=Math.min(devicePixelRatio||1,2);
  c.width=Math.round(w*dpr);c.height=h*dpr;
  const g=c.getContext('2d');if(!g)return;g.scale(dpr,dpr);
  g.clearRect(0,0,w,h);g.font='11px sans-serif';
  const x0=34,y0=10,W=w-47,H=h-35,maxY=Math.max(2,Math.ceil(Math.max(...data.map(p=>Math.max(p.events,p.target)),1)+.5));
  for(let i=0;i<=4;i++){const y=y0+H*i/4;g.strokeStyle='#dce7e1';g.beginPath();g.moveTo(x0,y);g.lineTo(x0+W,y);g.stroke();g.fillStyle='#74857d';g.fillText((maxY*(1-i/4)).toFixed(1),2,y+4);}
  if(data.length<2)return;
  const minT=data[0].model_s,maxT=data.at(-1).model_s;
  const trace=(field,color,dash)=>{g.beginPath();g.strokeStyle=color;g.lineWidth=1.8;g.setLineDash(dash?[4,4]:[]);
   data.forEach((d,i)=>{const x=x0+(d.model_s-minT)/Math.max(.1,maxT-minT)*W;
    const y=y0+H*(1-Math.min(1,d[field]/maxY));if(i===0)g.moveTo(x,y);else g.lineTo(x,y);});g.stroke();g.setLineDash([]);};
  trace('events','#247953');trace('target','#9caea5',true);
  g.fillStyle='#74857d';g.fillText(minT.toFixed(0)+'s',x0,h-5);g.fillText(maxT.toFixed(0)+'s',w-37,h-5);
 }
 function download(content,name,mime) {
  const url=URL.createObjectURL(new Blob([content],{type:mime}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);
 }
 async function exportData(){
  const local=await getAllLocal();const contents={schema:'ripple-neuron-telemetry-v1',
   note:'Numeric summaries; no camera pixels. Local offline logs; may include earlier sessions.',
   generated_utc:new Date().toISOString(),offline_rows:local.map(({session_id,record})=>({session_id,...record}))};
  download(JSON.stringify(contents,null,2),'Ripple-Neuron-Observer-Offline.json','application/json');
 }
 async function getAllLocal(){
  if(!storageReady)return memoryFallback;
  return new Promise((resolve,reject)=>{
   const request=db.transaction('samples','readonly').objectStore('samples').getAll();
   request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);
  });
 }
 function validateEndpoint(url){
  try{const u=new URL(url);
   return (u.protocol==='https:' || (u.protocol==='http:'&&['localhost','127.0.0.1'].includes(u.hostname))) &&
    u.pathname==='/api/telemetry' && !u.username && !u.password && !u.hash && !u.search;
  }catch{return false;}
 }
 async function flush(){
  if(!transmit||sending||!endpoint||!bearer||document.hidden)return;
  sending=true;
  try{
   await writeChain;
   const batch=await getBatch(30);
   if(!batch.length){networkNotice('Connected mode ready. No unsent records.','good');return;}
   const selected=batch.filter(x=>x.session_id===batch[0].session_id);
   const payload={schema:'ripple-neuron-telemetry-v1',session_id:selected[0].session_id,records:selected.map(x=>x.record)};
   const response=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+bearer},body:JSON.stringify(payload),cache:'no-store',mode:'cors'});
   if(!response.ok)throw Error('Receiver returned HTTP '+response.status);
   const ack=await response.json();
   if(ack.ok!==true||ack.received!==selected.length)throw Error('Receiver acknowledgement did not match batch.');
   await dropBatch(selected);lastSent+=selected.length;await updateCount();
   networkNotice('Online receiver acknowledged '+selected.length+' summaries. Total acknowledged: '+lastSent+'.','good');
  }catch(e){networkNotice('Offline queue retained. Upload failed: '+e.message,'warn');}
  finally{sending=false;}
 }
 $('obs-record').onclick=()=>{
  recording=!recording;$('obs-record').textContent=recording?'Stop offline recording':'Start offline recording';
  $('obs-record').classList.toggle('green',recording);
  notice(recording?'Recording one-second numerical summaries on this device.':'Offline recording stopped; already saved records remain.',recording?'good':'');
 };
 $('obs-export').onclick=()=>exportData().catch(e=>notice('Export failed: '+e.message,'bad'));
 $('obs-clear').onclick=async()=>{
  if(!confirm('Delete ALL locally queued observer summaries, including unsent records?'))return;
  transmit=false;bearer='';endpoint='';$('obs-connect').textContent='Enable online sending';
  await writeChain;
  if(storageReady)await storageTx('readwrite',store=>store.clear());else memoryFallback.length=0;
  await updateCount();notice('Saved observer data cleared.','good');
 };
 $('obs-connect').onclick=async()=>{
  if(transmit){transmit=false;bearer='';endpoint='';$('obs-connect').textContent='Enable online sending';networkNotice('Online sending disabled; device logs stay local.');return;}
  const url=$('obs-url').value.trim(),token=$('obs-token').value.trim();
  if(!validateEndpoint(url)){networkNotice('Use a valid HTTPS URL ending in /api/telemetry (localhost HTTP only for development).','bad');return;}
  if(!token){networkNotice('Receiver token is required.','bad');return;}
  endpoint=url;bearer=token;$('obs-token').value='';
  transmit=true;$('obs-connect').textContent='Disable online sending';
  networkNotice('Sending is enabled. Data is numerical only; no camera frames.','good');await flush();
 };
 $('obs-sendnow').onclick=flush;
 $('obs-reset').onclick=()=>{monitor.reset();session=globalThis.crypto?.randomUUID?.()||String(Date.now());refresh();notice('Observer window reset. Neuron model was NOT reset.','good');};
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)refresh();});
 globalThis.addEventListener('online',()=>{if(transmit)void flush();});
 setInterval(()=>{if(transmit)void flush();},5000);
 openDB().then(async d=>{db=d;storageReady=true;for(const item of memoryFallback){await storageTx('readwrite',store=>store.add(item));}memoryFallback.length=0;notice('Offline numerical storage ready. Press Start offline recording to save samples.','good');return updateCount();})
   .catch(()=>{storageReady=false;notice('Persistent storage is unavailable. Summaries will last only until this page closes.','warn');});
 refresh();
})();
