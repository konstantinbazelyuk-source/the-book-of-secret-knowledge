# Ripple Neuron — Android/Phone Observer v0.3

**The runnable Stage 1 prototype** is a phone-first offline web app with a read-only observer. It can optionally send **numerical** one-second telemetry to your own online receiver. Stage 2 research is documented, not implemented. Concept: Constantin x, 2026-10-13. Original code and written materials: CC0-1.0.

## What's in the bundle

- `index.html` — existing Phone Lab v0.2 UI and the original embedded RippleNeuron v0.1 math; adds an **Observer** tab and a one-way observation hook.
- `observer-core.js` — a deterministic monitor: 1-second event bins, rolling 20-second count-based firing rate, threshold drift, light-drive variation, target-reachability estimate.
- `observer-ui.js` — offline IndexedDB numeric logging **after opt-in**, JSON export, optional HTTPS upload with bearer-token authentication and acknowledge-before-delete.
- `ripple-core.js` — extracted original mathematics unchanged. Check its SHA-256 against `CORE-SHA256.txt`.
- `server/receiver.py` — minimal Python standard-library receiver, bearer token, origin allowlist, strict numeric schema, SQLite and idempotent inserts.
- `tests/` — deterministic regression and server tests.
- `CODEX_HANDOFF.md` — instructions and continuity rules for Codex.
- `PHASE-2-PLAN.md` — future coupled-neuron and learning experiments, **not** claims of intelligence.

## Try it immediately (offline)

1. Extract the ZIP and open `index.html` in Chrome for **manual** inputs. The camera may not work directly from a file URL.
2. Tap **Live neuron** and adjust RGB. Its original equations run locally.
3. Tap **Observer** and watch observations. Tap **Start offline recording** to persist one-second summaries on your device. Tap **Export offline JSON** to save logged numerical data.
4. Tap **Experiment**, run the original brightness-step comparison. The expected results are adaptive/fixed 0.95/3.40 Hz in the final 60–80-second interval.
5. For camera input or installable/offline PWA, host the files as an **HTTPS static website**, open in Android Chrome and allow the requested camera permission. The service worker caches the app shell on initial successful load.

The model steps are paused by the browser when the page is hidden. No continuous background camera activity is claimed. Offline recording needs IndexedDB; if the browser blocks it, records remain only in memory during that page session. Data in the local device can be cleared from the Observer tab.

## Optional online signal transport

Online mode is **OFF by default**, and no receiver is preconfigured. This is an upload transport, **not automatic live ChatGPT access**. To use it:

1. Choose a Python-capable server under your control and put `server/receiver.py` behind a properly configured **HTTPS reverse proxy**. Do not directly expose the insecure HTTP port to the Internet.
2. Generate a long random receiver token with `python -c "import secrets; print(secrets.token_urlsafe(32))"`.
3. Set `RIPPLE_TOKEN` on the server, and `RIPPLE_ALLOWED_ORIGINS` to the *exact* HTTPS origin hosting the phone PWA (for example `https://your-site.example`). Never embed the token in the app or commit it.
4. For local development only: `RIPPLE_TOKEN='<LONG_RANDOM_SECRET>' RIPPLE_ALLOWED_ORIGINS='http://localhost:8000' python server/receiver.py`. Defaults to loopback at port 8765, unencrypted; **do not use this raw endpoint from an Internet-hosted phone**.
5. In the phone Observer tab, enable **Start offline recording**, enter your receiver URL ending in `/api/telemetry`, paste the token, then tap **Enable online sending**. The app sends up to 30 queued 1-second records at a time and only deletes them after a valid acknowledgment. You can disable it at any time.
6. `GET /api/latest` with the same bearer token returns the last 20 received summaries for inspection; `GET /health` returns basic receiver status. SQLite defaults to `./ripple_telemetry.sqlite3` (configurable with `RIPPLE_DB`).

The HTTPS deployment, real device camera and remote receiver are **not provisioned** as part of this bundle. The app cannot send telemetry directly into this ChatGPT conversation; an explicitly connected AI service would require a separate implementation and authorization.

## Data/evidence boundaries

- Manual input is synthetic. Camera mode measures average RGB **processed image-pixel values** or calibrated approximations, not photon wavelengths, the AS7341's eight spectral bands, instantaneous electromagnetic fields or electrical neural voltages.
- Pulse events are generated mathematically on the device. Regulation diagnostics are heuristics, not proof of global stability. Online/offline transport of measurements is not evidence of autonomous learning.
- The read-only observer never changes RippleNeuron calculations; it only receives numeric copies of states.
- Persistent offline capture is opt-in. Online transmission is a second explicit opt-in. The receiver rejects fields outside the numerical schema, including images. Images are never uploaded by this program.

## Regression commands

```bash
node tests/check_phone_model.cjs
node tests/check_observer.cjs
python -m unittest discover -s tests -p 'test_*.py' -v
```

See `CODEX_HANDOFF.md` for safe maintenance sequencing and `PHASE-2-PLAN.md` for the separately gated next stage.
