#!/usr/bin/env python3
"""Ripple Neuron v0.3 opt-in telemetry receiver. Python stdlib only.

Run behind a correctly configured HTTPS reverse proxy in production. HTTP
listener defaults to loopback and is not suitable for direct Internet exposure.
No OpenAI integration; no control commands; numerical sample ingestion only.
"""
import hmac
import json
import math
import os
import re
import sqlite3
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

SCHEMA = 'ripple-neuron-telemetry-v1'
FIELDS = {'seq','model_s','drive','threshold','state','events','max_estimated_hz',
          'target','source','calibrated','adaptive','count','wall_utc'}
MAX_REQUEST = 64 * 1024
MAX_RECORDS = 30


def config_from_env():
    token = os.getenv('RIPPLE_TOKEN', '')
    if len(token) < 20:
        raise RuntimeError('Set RIPPLE_TOKEN to a long unpredictable secret (at least 20 characters).')
    return {
        'token': token,
        'db_path': Path(os.getenv('RIPPLE_DB', './ripple_telemetry.sqlite3')),
        'allowed_origins': set(filter(None, os.getenv('RIPPLE_ALLOWED_ORIGINS', '').split(','))),
        'host': os.getenv('RIPPLE_HOST', '127.0.0.1'),
        'port': int(os.getenv('RIPPLE_PORT', '8765')),
    }


def init_db(path):
    path.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(path, timeout=10) as con:
        con.execute('PRAGMA journal_mode=WAL')
        con.execute('''CREATE TABLE IF NOT EXISTS samples (
          session_id TEXT NOT NULL,
          seq INTEGER NOT NULL,
          model_s REAL NOT NULL,
          received_utc TEXT NOT NULL,
          payload_json TEXT NOT NULL,
          PRIMARY KEY(session_id, seq)
        )''')
        con.execute('CREATE INDEX IF NOT EXISTS idx_recent ON samples(received_utc)')


def valid_record(r):
    if not isinstance(r,dict) or set(r)!=FIELDS: return False
    for key in ('model_s','drive','threshold','state','max_estimated_hz','target'):
        if isinstance(r[key],bool) or not isinstance(r[key],(int,float)) or not math.isfinite(r[key]):return False
    if not (0<=r['model_s']<=1e8 and -1.4<=r['drive']<=3.2 and 0.14<=r['threshold']<=2.51
            and 0<=r['state']<=4 and 0<=r['max_estimated_hz']<=15 and 0.25<=r['target']<=3):return False
    for key in ('seq','events','count'):
        if type(r[key]) is not int or r[key]<0:return False
    if r['count']>30 or r['events']>20 or r['source'] not in ('manual','camera'):return False
    if type(r['adaptive']) is not bool or type(r['calibrated']) is not bool:return False
    if not isinstance(r['wall_utc'],str) or len(r['wall_utc'])>40 or 'T' not in r['wall_utc']:return False
    return True


def make_server(cfg):
    init_db(cfg['db_path'])
    class Handler(BaseHTTPRequestHandler):
        server_version = 'RippleTelemetry/0.3'
        def _origin(self):
            origin=self.headers.get('Origin')
            return origin is None or origin in cfg['allowed_origins']
        def _cors(self):
            origin=self.headers.get('Origin')
            if origin in cfg['allowed_origins']:
                self.send_header('Access-Control-Allow-Origin',origin)
                self.send_header('Vary','Origin')
                self.send_header('Access-Control-Allow-Headers','Authorization, Content-Type')
                self.send_header('Access-Control-Allow-Methods','GET, POST, OPTIONS')
        def _reply(self,code,obj):
            raw=json.dumps(obj,separators=(',',':')).encode('utf8')
            self.send_response(code)
            self._cors()
            self.send_header('Content-Type','application/json; charset=utf-8')
            self.send_header('Cache-Control','no-store')
            self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Content-Length',str(len(raw)))
            self.end_headers();self.wfile.write(raw)
        def _authorized(self):
            return hmac.compare_digest(self.headers.get('Authorization',''), 'Bearer '+cfg['token'])
        def do_OPTIONS(self):
            if not self._origin():return self._reply(403,{'ok':False,'error':'origin denied'})
            self.send_response(204);self._cors();self.send_header('Content-Length','0');self.end_headers()
        def do_GET(self):
            if self.path=='/health':return self._reply(200,{'ok':True,'service':'ripple-neuron-receiver-v0.3'})
            if self.path!='/api/latest':return self._reply(404,{'ok':False})
            if not self._origin() or not self._authorized():return self._reply(403,{'ok':False})
            with sqlite3.connect(cfg['db_path'],timeout=10) as con:
                data=con.execute('SELECT session_id,payload_json FROM samples ORDER BY rowid DESC LIMIT 20').fetchall()
            rows=[{'session_id':r[0],**json.loads(r[1])} for r in data]
            return self._reply(200,{'ok':True,'records':rows})
        def do_POST(self):
            if self.path!='/api/telemetry':return self._reply(404,{'ok':False})
            if not self._origin() or not self._authorized():return self._reply(403,{'ok':False,'error':'not authorized'})
            try: length=int(self.headers.get('Content-Length','0'))
            except ValueError: return self._reply(400,{'ok':False,'error':'invalid length'})
            if not 0<length<=MAX_REQUEST:return self._reply(413,{'ok':False,'error':'request too large or empty'})
            try:payload=json.loads(self.rfile.read(length))
            except (ValueError,UnicodeDecodeError):return self._reply(400,{'ok':False,'error':'invalid json'})
            if not isinstance(payload,dict) or set(payload)!={'schema','session_id','records'} or payload['schema']!=SCHEMA:
                return self._reply(400,{'ok':False,'error':'invalid schema'})
            sid=payload['session_id'];records=payload['records']
            if not isinstance(sid,str) or not re.fullmatch(r'[a-zA-Z0-9-]{8,128}',sid):
                return self._reply(400,{'ok':False,'error':'invalid session'})
            if not isinstance(records,list) or not 1<=len(records)<=MAX_RECORDS or not all(valid_record(r) for r in records):
                return self._reply(400,{'ok':False,'error':'invalid records'})
            utc=datetime.now(timezone.utc).isoformat();inserted=0
            with sqlite3.connect(cfg['db_path'],timeout=10) as con:
                for record in records:
                    cur=con.execute('INSERT OR IGNORE INTO samples(session_id,seq,model_s,received_utc,payload_json) VALUES (?,?,?,?,?)',
                        (sid,record['seq'],record['model_s'],utc,json.dumps(record,separators=(',',':'))))
                    inserted+=cur.rowcount
            return self._reply(200,{'ok':True,'received':len(records),'inserted':inserted})
    return ThreadingHTTPServer((cfg['host'],cfg['port']),Handler)


if __name__=='__main__':
    settings=config_from_env()
    server=make_server(settings)
    print(f'Ripple receiver listening on http://{settings["host"]}:{server.server_port}',flush=True)
    print('To accept remote phone traffic, run behind HTTPS; never expose this HTTP listener directly.',flush=True)
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close()
