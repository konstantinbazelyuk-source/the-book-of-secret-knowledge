import http.client
import json
import tempfile
import threading
import unittest
from pathlib import Path
from sys import path
path.insert(0,str(Path(__file__).parent.parent / 'server'))
from receiver import make_server

TOKEN='T' * 40
BASE={'seq':0,'model_s':3.0,'drive':.7,'threshold':.5,'state':.1,'events':1,
      'max_estimated_hz':.9,'target':1,'source':'manual','calibrated':False,
      'adaptive':True,'count':20,'wall_utc':'2026-10-13T17:00:00.000Z'}

class ReceiverTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory()
        cls.srv=make_server({'token':TOKEN,'db_path':Path(cls.tmp.name)/'db.sqlite',
                            'allowed_origins':{'https://example.test'},'host':'127.0.0.1','port':0})
        cls.thread=threading.Thread(target=cls.srv.serve_forever,daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown();cls.srv.server_close();cls.thread.join();cls.tmp.cleanup()

    def call(self, method, path, data=None, token=TOKEN, origin='https://example.test'):
        c=http.client.HTTPConnection('127.0.0.1',self.srv.server_port,timeout=5)
        head={'Content-Type':'application/json','Authorization':'Bearer '+token}
        if origin:head['Origin']=origin
        c.request(method,path,json.dumps(data).encode() if data is not None else None,head)
        response=c.getresponse();status=response.status
        result=json.loads(response.read())
        c.close();return status,result

    def test_auth_and_ingestion_and_dedup(self):
        payload={'schema':'ripple-neuron-telemetry-v1','session_id':'session-example-a','records':[BASE]}
        self.assertEqual(self.call('POST','/api/telemetry',payload,token='bad')[0],403)
        self.assertEqual(self.call('POST','/api/telemetry',payload,origin='https://untrusted.test')[0],403)
        status,data=self.call('POST','/api/telemetry',payload)
        self.assertEqual(status,200);self.assertEqual(data['received'],1);self.assertEqual(data['inserted'],1)
        status,data=self.call('POST','/api/telemetry',payload)
        self.assertEqual(status,200);self.assertEqual(data['inserted'],0)
        status,data=self.call('GET','/api/latest')
        self.assertEqual(status,200);self.assertEqual(len(data['records']),1)
        self.assertNotIn('image',data['records'][0])

    def test_no_video_images_or_unknown_fields(self):
        sample=dict(BASE, camera_image='base64')
        payload={'schema':'ripple-neuron-telemetry-v1','session_id':'session-example-b','records':[sample]}
        self.assertEqual(self.call('POST','/api/telemetry',payload)[0],400)
        sample=dict(BASE,drive=float('inf'))
        self.assertEqual(self.call('POST','/api/telemetry',{**payload,'records':[sample]})[0],400)

if __name__=='__main__':unittest.main()
