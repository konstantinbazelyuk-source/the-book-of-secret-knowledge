'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const {Observer}=require('../observer-core.js');
vm.runInThisContext(fs.readFileSync(__dirname+'/../ripple-core.js','utf8'));
function testModel(){
 const m=new RippleNeuron(), monitor=new Observer(), rawEvents=[], reports=[];
 for(let i=0;i<2400;i++){
  const t=i*.05,red=t<40||t>=80?.35:.7;
  const r=m.step([red,0,0],.05);
  rawEvents.push(r.count);
  const original={time_s:r.t.toFixed(2),red:red.toFixed(4),green:'0',blue:'0',
    drive:r.drive.toFixed(4),state:r.u.toFixed(4),threshold:r.theta.toFixed(4),
    estimated_rate_hz:r.rate.toFixed(4),events:r.count,target:1,source:'manual',adaptive:true,calibrated:0};
  const summary=monitor.ingest(original);
  if(summary)reports.push(summary);
 }
 assert.ok(reports.length>115 && reports.length<121,'one-second summaries');
 assert.equal(monitor.totalEvents,rawEvents.reduce((a,b)=>a+b,0),'no lost pulse counts');
 assert.ok(monitor.report().observed_hz>=.85 && monitor.report().observed_hz<=1.15,'rate returns to 1 Hz');
 assert.equal(monitor.report().status,'near_target');
 assert.ok(reports.every(r=>r.source==='manual' && r.target===1),'metadata recorded');
 assert.ok(reports.every(r=>r.count>=18&&r.count<=21),'bounded one-second sample counts');
 const before=m.theta;monitor.reset();assert.equal(m.theta,before,'observer reset cannot affect neuron');
 assert.equal(monitor.ingest({time_s:1,drive:'NaN'}),null,'reject invalid data');
 return reports;
}
const results=testModel();
const page=fs.readFileSync(__dirname+'/../index.html','utf8');
assert.ok(page.includes("typeof window.rippleObserve==='function'"),'read-only observer hook present');
assert.ok(page.includes('<script src="./observer-core.js"></script>'));
assert.ok(page.includes('<script src="./observer-ui.js"></script>'));
assert.ok(fs.readFileSync(__dirname+'/../ripple-core.js','utf8').includes('class RippleNeuron'),'original source present');
console.log('PASS observer: source model unchanged, 1-second aggregation, target recovery, reset isolation, sanitization; rows='+results.length);
