# Release notes — 2.0.0-beta.1

- Built a new independent Beta from the actually recovered original Ripple neuron, optical frontend and quaternary codec.
- Audited historical Mycelium, Digital World, Alpha and Hybrid-Alpha source strategies; retained source vault unchanged.
- Added bounded synthetic sensor schemas, per-agent neuron state, local map memory, digital genealogy, parameter inheritance, action allowlist, source-provenance checking and replay.
- Added hard scenario caps, 16-agent cap, max 8 rules, 1,200 steps, 1,024 cells/agent memory, 8-entry SHARE budget.
- Added 300 architecture trials and 420 controlled interventions over paired synthetic worlds, with fresh final validation seeds [131,137,139,149,151].
- Disabled synthetic density in the default release; optional density comparison available.
- Preserved negative findings: v0.7 quaternary coding changed observability but not evaluated mapping coverage; feature removal sometimes improves synthetic task metrics; improvements are not proof of physical intelligence.
- Excluded all discontinued monochrome research from executable Beta tabs and studies.
- Verified 22 Node checks and desktop/mobile-width Chromium interactions; no claims of physical hardware, calibrated optics, network agents, GPU acceleration or quantum computation.
- Added self-contained offline click-to-run HTML, source-mode web UI, release notes, source hashes, architecture matrix, machine-readable trials and runnable test suite.
