# RIPPLE GEN BETA — v2.0.0-beta.1

**Status: EXECUTABLE RESEARCH BETA.** Original Ripple Neuron source preserved. This is an integrated computer-simulation runtime with reproducible studies of its program designs and engineering trade-offs. It is **not** an AI model, physical light instrument, robot controller, calibrated sensor, cloud supercomputer, or demonstration of autonomous intelligence.

## Run directly, without Codex or cloud hosting

**Fastest:** open `Ripple-Gen-Beta-Standalone.html` in a modern browser. The 68 KB single HTML file includes actual original kernels, the new bounded Beta engine, both executed study reports, the interactive 2D simulation and JSON trace export. It runs locally without network access. It does not have camera/device access and does not need it.

**Full source mode:**
- Windows: double-click `Start-Ripple-Beta-Windows.bat` (requires Python 3) or run `python -m http.server 8770` in this directory and visit `http://localhost:8770/web/index.html`.
- Linux/macOS: `./Start-Ripple-Beta-Mac-Linux.sh`, visit `http://localhost:8770/web/index.html`.
- Rerun scientific checks: `node --test tests/*.test.mjs` or `npm test` (Node.js 22 or a compatible modern build).
- Rerun studies: `node src/study.mjs` (300 architecture cases), `node src/ablation.mjs` (420 feature interventions). Then `python3 build_standalone.py` to refresh the one-file browser artifact and baked reports.
- Optional UI smoke in a browser-enabled environment: `python tests/standalone_browser.py` with Python Playwright and Chromium; tested in this build environment using `page.set_content` with no network navigation.

## Four interfaces, one deterministic engine
1. **Interactive world:** run seeded synthetic RGB fields, source diffusion, barriers, genome traits, bounded digital reproduction and lineages; switch policies and watch individual paths.
2. **Architecture trials:** compare five real algorithm combinations, including original neuron baseline, optical/quaternary-only, spatial, colony and final hybrid.
3. **Design review:** inspect sourced strengths/weaknesses and what was actually integrated; no feature is implicitly promoted to intelligence.
4. **Evidence & safety:** explicit software/physical evidence boundaries, file-free sensor protocol and bounded rules.

## Final engineering decisions

The Beta's default policy preserves the tested v0.1 neuron, uses v0.6 photoreceptor and v0.7 quaternary temporal symbol encoder, enforces typed synthetic input, and combines a conservative RGB field, blocked ray sensing, agent-local memory, explicit map sharing, finite rules and bounded reproduction. Roles and inherited mobility/memory/share/reproduction settings are operational. Optional **synthetic density** is off by default because no physical calibration supports it and it was not beneficial in this particular evaluation.

**No discontinued color-convergence or grayscale experiments are run or linked in the live Beta interface.** Earlier Alpha sources are archived read-only solely to establish real provenance; archived code is not silently executed.

## Results and limitations

- **22 Node test checks passed**, covering original exact source hash, original 0.95 vs 3.40 Hz numerical event-rate experiment, transport conservation, blocked walls, genome role/traits, source provenance rejection, quaternary codec, replay, etc.
- **2 browser interaction checks passed** (desktop 1280×900; phone-width 393×852) with no script exceptions in Chromium.
- **300 architecture trials** and **420 feature interventions** executed, with raw comparison CSV, JSON, seeded split and analysis files in `results/`.
- Numeric implementation verified; no physically measured optical, magnetic, density or environmental readings. Runtime CPU timing measured on only the current container.
- Results are selected according to a **traceable software architecture** and safety boundary, not a fabricated all-purpose score.

See `docs/COMPARATIVE_RESULTS.md`, `docs/ARCHITECTURE_DECISIONS.md`, `docs/EVIDENCE_AND_SAFETY.md`, `docs/RESEARCH_AND_SOURCING.md` and `docs/SOURCE_MANIFEST.json`.

## Exact locked sources

`legacy/ripple-core.js` must hash to `dba6639b7902f0c702d15fff588524629f3754cfd72d7b704f22a76b78960ee3`. It retains the LIF state, feedback and temporal assumptions. `legacy/photoreceptor-v06.js` and `legacy/quaternary-core.mjs` are also preserved verbatim from the recovered reference packages. Beta `src/beta-engine.mjs` is new code that imports those modules; the original sources remain unchanged. `references/` is a recovery vault of actual prior project files, not a proof that each has been directly executed in the Beta.

## Licensing and provenance

The original Ripple invention and its archived sources belong to their respective original authors. Historical source notices and licensing continue to apply. New integration code is supplied as a research deliverable; this package is not a blanket relicensing of any historical artwork, third-party library, firmware or research text. The generated study CSV/JSON may be inspected and independently reproduced, subject to source terms. No API keys, network-connected accounts or cloud worker credentials are included.
