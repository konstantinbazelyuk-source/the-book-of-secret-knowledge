// Ripple Neuron v0.6: optional and isolated light preprocessor. CC0-1.0.
(function(root){
'use strict';
const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
const sRGBToLinear=x=>{x=clamp(Number(x)||0);return x<=.04045?x/12.92:Math.pow((x+.055)/1.055,2.4);};
const linearToSRGB=x=>{x=clamp(Number(x)||0);return x<=.0031308?12.92*x:1.055*Math.pow(x,1/2.4)-.055;};
const absorb=(rgb,coeff,path)=>{path=clamp(Number(path)||0,0,10);const T=rgb.map((_,i)=>Math.exp(-clamp(Number(coeff[i])||0,0,8)*path));return{output:rgb.map((v,i)=>clamp(v)*T[i]),transmittance:T,simulated:true};};
function opacityCal(raw,dark,clear,gamma=true){
 if(![raw,dark,clear].every(x=>Array.isArray(x)&&x.length===3&&x.every(Number.isFinite)))return{valid:false,channels:[],output:[0,0,0]};
 const decode=x=>gamma?sRGBToLinear(x/255):x/255;
 const channels=raw.map((v,i)=>{
  const ok=clear[i]-dark[i]>=20&&raw[i]<250&&clear[i]<250&&raw[i]>=0&&clear[i]<=255&&dark[i]>=0;
  const denom=decode(clear[i])-decode(dark[i]);const valid=ok&&denom>1e-6;
  const transmission=valid?clamp((decode(v)-decode(dark[i]))/denom):null;
  return{valid,transmission,relativeOpacity:transmission===null?null:1-transmission,relativeOD:transmission===null?null:-Math.log10(Math.max(transmission,.001))};
 });
 return{valid:channels.every(x=>x.valid),channels,output:channels.map(x=>x.transmission??0),gamma,warning:'Display-referred camera proxy; exposure/white-balance not calibrated'};
}
class Photoreceptor{
 constructor(o={}){this.defaults={linear:true,logGain:8,contrastThreshold:.25,transientGain:.35,logFloor:.01,limit:8,...o};this.reset();}
 reset(){this.refLog=null;this.time=0;}
 step(rgb,dt,overrides={}){
  if(!Array.isArray(rgb)||rgb.length!==3||rgb.some(v=>!Number.isFinite(v))||!Number.isFinite(dt)||dt<=0||dt>.5)throw Error('Invalid input');
  const o={...this.defaults,...overrides},input=rgb.map(x=>clamp(x));
  const linear=o.linear?input.map(sRGBToLinear):input;
  const k=clamp(Number(o.logGain),0,100),floor=clamp(Number(o.logFloor),.001,.1),thr=clamp(Number(o.contrastThreshold),.08,2);
  const gain=clamp(Number(o.transientGain),0,1.5),limit=Math.max(1,Math.min(8,Math.floor(o.limit)));
  const logs=linear.map(x=>Math.log(x+floor));if(this.refLog===null)this.refLog=logs.slice();
  const on=[0,0,0],off=[0,0,0];
  for(let i=0;i<3;i++){
   const delta=logs[i]-this.refLog[i],count=Math.min(limit,Math.floor((Math.abs(delta)+1e-10)/thr));
   if(count){if(delta>0)on[i]=count;else off[i]=count;this.refLog[i]+=Math.sign(delta)*count*thr;}
  }
  const sustained=linear.map(x=>k===0?x:Math.log1p(k*x)/Math.log1p(k));
  const output=sustained.map((x,i)=>clamp(x+gain*on[i]/limit));this.time+=dt;
  return{output,sustained,on,off,linear,time:this.time,mode:'software temporal contrast encoder',syntheticEvents:true};
 }
}
root.RippleLightV06={Photoreceptor,absorb,opacityCal,sRGBToLinear,linearToSRGB};
if(typeof module!=='undefined'&&module.exports)module.exports=root.RippleLightV06;
})(typeof globalThis!=='undefined'?globalThis:this);
