@echo off
cd /d "%~dp0"
where py >NUL 2>&1
if %ERRORLEVEL% EQU 0 (start "Ripple Gen Beta" http://localhost:8770/web/index.html & py -3 -m http.server 8770) else (start "Ripple Gen Beta" http://localhost:8770/web/index.html & python -m http.server 8770)
