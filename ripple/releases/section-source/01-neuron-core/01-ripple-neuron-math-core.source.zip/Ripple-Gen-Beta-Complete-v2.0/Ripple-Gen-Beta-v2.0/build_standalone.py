"""Create self-contained offline Beta laboratory from tested JS source modules and real study results.
No code generator invents new functionality: this is a deterministic packaging step.
"""
from pathlib import Path
import json,re
root=Path(__file__).resolve().parent
quad=(root/'legacy/quaternary-core.mjs').read_text()
beta=(root/'src/beta-engine.mjs').read_text()
html=(root/'web/index.html').read_text()
assert not re.search(r'\bimport\s+',quad), 'quad has unexpected imports'
assert not re.search(r'\bimport\s*\(',quad), 'quad has dynamic imports'
quad=re.sub(r'\bexport\s+(?=(?:const|async\s+function|function|class)\b)','',quad)
assert not re.search(r'\bexport\s+',quad), 'quad has unsupported exports'
beta=re.sub(r'^import\s+.*?;\s*$', '', beta, flags=re.MULTILINE)
beta=re.sub(r'^export\s*\{.*?\};\s*$', '', beta, flags=re.MULTILINE)
beta=re.sub(r'\bexport\s+(?=(?:const|async\s+function|function|class)\b)', '', beta)
assert not re.search(r'\bexport\s+',beta), 'beta has unsupported exports'
assert not re.search(r'\bimport\s+',beta), 'beta has unexpected imports'
legacy=(root/'legacy/ripple-core.js').read_text()+'\n'+(root/'legacy/photoreceptor-v06.js').read_text()
quad_wrap="const RIPPLEQ=(()=>{\n"+quad+"\nreturn {QuadEncoder,QuadVM,pack4,unpack4,frameFeatures};\n})();"
beta_wrap="const RIPPLE_BETA=(()=>{\nconst {QuadEncoder,QuadVM,pack4,unpack4,frameFeatures}=RIPPLEQ;\n"+beta+"\nreturn {BetaWorld,POLICIES,BETA_ABLATIONS};\n})();"
replacements={
 "import {BetaWorld,POLICIES,BETA_ABLATIONS} from '../src/beta-engine.mjs';":'const {BetaWorld,POLICIES,BETA_ABLATIONS}=RIPPLE_BETA;',
 "const comparisons=await (await fetch('../results/architecture-comparison.json')).json();":'const comparisons=RIPPLE_REPORTS.architecture;',
 "const ablations=await (await fetch('../results/ablation-comparison.json')).json();":'const ablations=RIPPLE_REPORTS.ablations;'
}
for a,b in replacements.items():
 assert a in html,a
 html=html.replace(a,b)
assert '<script type="module">' in html
reports='const RIPPLE_REPORTS='+json.dumps({'architecture':json.loads((root/'results/architecture-comparison.json').read_text()),'ablations':json.loads((root/'results/ablation-comparison.json').read_text())},separators=(',',':'))+';'
script='\n'.join((legacy,quad_wrap,beta_wrap,reports))
assert '</script' not in script.lower(), 'script cannot close source HTML'
html=html.replace('<script type="module">','<script>\n'+script,1)
assert '<script type="module">' not in html
out=root/'Ripple-Gen-Beta-Standalone.html'
out.write_text(html)
(root/'results/standalone-build.json').write_text(json.dumps({'path':out.name,'bytes':out.stat().st_size,'kernelsUnmodified':['legacy/ripple-core.js','legacy/photoreceptor-v06.js','legacy/quaternary-core.mjs'],'wrapper':'IIFE; no executable string generation; reports embedded as JSON','offline':True},indent=2))
print(out, out.stat().st_size,'bytes')
