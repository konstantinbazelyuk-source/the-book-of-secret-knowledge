"""Offline preview of self-contained Beta without navigating to blocked local origins."""
from pathlib import Path
import json
from playwright.sync_api import sync_playwright
base=Path(__file__).resolve().parents[1]
html=(base/'Ripple-Gen-Beta-Standalone.html').read_text()
results=[]
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for view in [('desktop',1280,900),('phone',393,852)]:
  name,w,h=view;page=browser.new_page(viewport={'width':w,'height':h});errors=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(html,wait_until='load')
  page.locator('#run').click()
  assert page.locator('#vTick').inner_text()=='240',f'world did not run: {errors}'
  assert int(page.locator('#vCoverage').inner_text())>0
  page.locator('button[data-tab="study"]').click()
  assert page.locator('#trialRows tr').count()==5
  assert page.locator('#ablateRows tr').count()==7
  page.locator('button[data-tab="systems"]').click()
  assert page.locator('#matrix article').count()==8
  page.locator('button[data-tab="lab"]').click()
  page.locator('#policy').select_option('beta-no-sharing')
  page.locator('#run').click();assert page.locator('#vTick').inner_text()=='240'
  page.screenshot(path=str(base/'results'/f'standalone-{name}.png'),full_page=True)
  assert errors==[],errors
  results.append({'viewport':name,'dimensions':f'{w}x{h}','status':'passed','pageErrors':errors})
  page.close()
 browser.close()
(base/'results'/'standalone-browser-test.json').write_text(json.dumps({'passed':True,'results':results},indent=2))
print(json.dumps(results,indent=2))
