# Ripple Gen Beta — Architecture decision record (ADR-BETA-001)

## Scope and evidence labels
- **SOURCE-VERIFIED** = recovered code/files inspected and hashed. Presence of code does not imply runtime use.
- **EXECUTED NUMERICAL** = deterministic code run on synthetic inputs.
- **EXECUTED BROWSER** = UI interactions executed in container Chromium via HTML content injection. Not physical hardware.
- **PROPOSED** = future integration not implemented or sensor-validated.
- Beta v2.0 retains archived sources unchanged in `references/`; this executable Beta uses only the locked v0.1, v0.6 and v0.7 kernels in `legacy/` and new, documented spatial/colony code.

## Reviewed paths and architectural trade-offs

| Previous Ripple path | Real design property recovered | Advantage / suitable purpose | Disadvantage / boundary | Final Beta treatment |
|---|---|---|---|---|
| Neuron v0.1 | Leaky-integrate-and-fire event crossing; 0.5 s voltage constant, 0.1 s refractory; adaptive threshold | A tested, small deterministic regulator | No vision, mapping, local memory, reproduction by itself | **LOCKED**, active unchanged |
| Phone v0.2–v0.4 | Browser camera sampling, logging, HTTPS/PWA UI, home-screen launch | Real camera-API integration path (permission required) | Actual camera measurements and native builds not verified in this lab; UI/platform burden | **SEPARATE**, not brought into Beta core |
| Observer v0.3 | Rate/time-series trace, offline JSON export, opt-in telemetry | Makes interpretation and regressions auditable | Cannot infer cognition; online receiver requires deployment and authorization | **ADAPTED** trace/export contract without live cloud transfer |
| Optical v0.5 | RGB ratio, synthetic opacity, distance falloff, channel mixing | Controlled preprocessor model comparisons | Camera RGB is not physical wavelength-resolved absorption or metric distance | **REFERENCE**, not assertive real-world sensor input |
| Photoreceptor v0.6 | Logarithmic compression, ON/OFF frame-based events, exponential attenuation | Intensity change encoding; optional sensitivity | Noise and camera transfer functions distort true intensities; alters firing-rate distribution | **LOCKED module**, active under optical policies |
| Ripple-Q v0.7 | Exact four-symbol/two-bit packing, noise-aware hysteresis and bounded VM | Traceable signal encoding and safe structured operations | Quaternary telemetry did **not** change coverage in final tested policy; not extra CPU instructions or quantum computation | **LOCKED**, active telemetry; no false performance benefit claimed |
| Cybernetic Mycelium / Mathematics Lab v0.3 | Population/worker organization and alternate adaptive-control research | Specialization and scheduling concepts | Work stealing and OS concurrency cannot simply be inferred from a synthetic organism model | **REVIEWED**, ideas adapted; not OS-level worker pool |
| Digital World Lab v0.5 | Spatial representation, world/agent evolution, map/occlusion | Geometry and local path analysis | Synthetic map not physically calibrated sight/depth | **REVIEWED**, local 2D Beta world rebuilt |
| Alpha Labs v1.0/1.1 | Pairwise finite-volume diffusion, occlusion masking, simulated occupancy | Conservative transport; testable numerical stability | Occupancy parameter is not atomic or mass density; default held back | **ACTIVE** conservative transport; density optional only |
| Hybrid Alpha v1.1 | Per-agent knowledge, guarded reproduction, finite action grammar, SHARE and lineage | Actual software information transfer and descendants | Extra state and control complexity; advanced sensor fusion/worker OS claims unsupported | **ACTIVE** bounded policy redesigned and ablation tested |
| Integrated Lab / FieldSphere / Sensor Bridge / SpiderScan proposals | Separate physical-optical, magnetic, depth and/or virtual-world adapters | Possible future external observation channels | Different units, sample rates and permission/hardware/safety requirements; device validation absent | **NOT CONNECTED**, only evidence-gated interface prospect |

Historical sources can contain studies the user has retired. No discontinued experiments are invoked from the Beta runtime or available as Beta UI controls.

## Final hybrid architecture

1. **Packet provenance**: synthetic RGB accepted only when explicitly `kind:'synthetic'`; physical packets rejected pending a real adapter and calibration. 
2. **Light frontend**: opt-in preserved v0.6 log-intensity encoding, before v0.1 neuron.
3. **Neuron gate**: byte-identical v0.1 model, each agent has isolated state; original pulse timing, threshold bounds and feedback untouched.
4. **Four-state trace**: preserved v0.7 `QuadEncoder`; a two-bit symbolic signal, used for telemetry. It is NOT yet a demonstrated behavioral optimizer.
5. **Spatial field**: finite-volume, equal-and-opposite pair flux; bounded source injection, solid barrier masking; source-free conservation test. Synthetic occupancy is explicitly optional.
6. **Worker identities / phenotypes**: `Prism` explorer, `Canopy` relay, `Ember` guardian; software genomes store color-channel weights, mobility, memory capacity, sharing limits, clone threshold and allowed rule lists. Explorer frontier preference and relay peer orientation are operational. Guardian is presently a tagged role without a specialized motor policy; do not misrepresent as implemented defense.
7. **Finite rule engine**: conditional rules choose SCAN/MOVE/SHARE/CLONE/WAIT, not arbitrary JavaScript or unrestricted code generation. Pulse gate guards sensing/sharing; dynamic reproduction additionally requires sufficient synthetic resource.
8. **Local knowledge**: SCAN inserts cells into the worker's own dictionary; occluding walls stop rays; SHARE transfers at most eight new entries to a nearby peer. The world-wide coverage collection is used for evaluation only.
9. **Lineage & replay**: immutable genome records, parent IDs, per-agent paths and simulation traces. The simple FNV-1a identifier is an audit convenience, not a secure cryptographic signature.
10. **Study contracts**: seed-locked synthetic worlds, predeclared alternatives, comparison tables, separate CPU timings, negative results retained, unmeasured capabilities explicitly excluded.

## Final algorithm selection / rejected changes

- Keep the original LIF and photoreceptor source byte-identical.
- Keep quaternary symbols for future data protocols **without claiming a coverage benefit**: removing the encoder produced the same coverage in the final holdout set.
- Keep explicit sharing because it transfers local map entries; its coverage benefit is small and environment-dependent.
- Keep limited reproduction because descendants were actually created and individually traced in synthetic runs. More descendants do not constitute learning or intelligence.
- Keep local spatial memory and a bounded conditional action grammar; the latter prevents arbitrary code execution.
- Keep finite-volume diffusion and occlusion; introduce synthetic occupancy/density as **opt-in only** (the higher-complexity condition is not universally better and is uncalibrated).
- Do not integrate physical camera, magnetic field, ToF, drone, robot, autonomous AI, or any connected account into the default Beta.
- No AI model generated or recompiled new executable source code in a digital organism. Rule mutations are bounded reconfigurations, not novel code-language invention.

## Reproducibility
Run `npm test`, `npm run study`, and `node src/ablation.mjs` in an environment with Node.js 22+. The standalone HTML contains the same kernels and saved study report as inline scripts and runs without network once downloaded. A local `http://localhost:8770` web project is also included.
