# Ripple Gen Beta v2.0.0-beta.1 — Final recorded experimental comparison

All results are **synthetic simulation** except local run timing. Comparison uses 240 model ticks, four declared environments, five final holdout seeds [131,137,139,149,151], and identical initial seeds/environment per policy.

## Source architecture paths (final holdout: 20 per path)

| Path | Mean distinct map cells | Mean neuron events | Mean shared entries | Mean descendants | Local Node median ms |
|---|---:|---:|---:|---:|---:|
| neuron-only | 0.00 | 25.10 | 0.00 | 0.00 | 7.78 |
| optical-q | 0.00 | 40.15 | 0.00 | 0.00 | 7.93 |
| spatial | 12.20 | 5.35 | 0.00 | 0.00 | 7.87 |
| colony | 5.50 | 5.60 | 1.70 | 0.00 | 8.18 |
| hybrid-beta | 52.45 | 37.00 | 1.50 | 3.80 | 9.10 |

`neuron-only` and `optical-q` do not include a mapping policy: zero spatial coverage is built into their architecture, not evidence of inferior intelligence. The optional photoreceptor changes the numeric input and therefore pulse statistics; the model is not trained.

## Feature interventions (final holdout: 20 per policy)

| Beta setting | Mean distinct map cells | Δ from default | Mean events | Mean entries shared |
|---|---:|---:|---:|---:|
| hybrid-beta | 52.45 | +0.00 | 37.00 | 1.50 |
| beta-no-optical | 13.00 | +39.45 | 5.75 | 0.00 |
| beta-no-quaternary | 52.45 | +0.00 | 37.00 | 1.50 |
| beta-no-sharing | 51.80 | +0.65 | 36.95 | 0.00 |
| beta-no-cloning | 44.85 | +7.60 | 23.30 | 0.75 |
| beta-no-memory | 3.95 | +48.50 | 35.85 | 0.00 |
| beta-density-on | 50.65 | +1.80 | 35.60 | 3.05 |

Results are **scenario-dependent** and several policies differ in attainable operations, timing, and resource budgets. Removing the memory trait-dependent scanning rule changes both memory and control flow, so its ablation is not a pure isolated-memory study. Likewise, reducing cloning reduces population size, so exploration coverage is not normalized per worker. Quaternary telemetry is not used in policy decisions and its removal has zero effect on this evaluation; that is an explicit negative result.

## Final engineering decision

The default v2.0 Beta runs with its density-crowding modifier disabled because the equation is uncalibrated, it adds an assumption, and it failed to improve this narrow synthetic mapping metric on final validation. Density remains an optional lab intervention. Sharing, local memory and bounded reproduction are retained with their measured limitations. The v0.1 neuron source and v0.7 symbol codec are locked.

## Reproduction

- `npm test`: 22 verified tests, plus 2 browser viewport tests in `tests/standalone_browser.py` if Chromium/Playwright are available.
- `npm run study`: reruns 300 architecture cases and local CPU measurement.
- `node src/ablation.mjs`: reruns 420 interventions.
- `python3 build_standalone.py`: packages one offline HTML from tested code and saved report.
- No physical sensors or cloud systems participated in these results.
