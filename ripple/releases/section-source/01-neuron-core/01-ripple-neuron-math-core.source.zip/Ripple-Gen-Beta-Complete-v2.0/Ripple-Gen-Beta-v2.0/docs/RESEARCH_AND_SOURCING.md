# Outside software engineering research and sourcing decisions

Sources were consulted for implementation strategies, **not** imported as unverified code:

1. **NIST, Guidelines on Minimum Standards for Developer Verification of Software (2021)**: https://www.nist.gov/publications/guidelines-minimum-standards-developer-verification-software — threat modeling, automated testing, historical regression, input rejection, fuzzing, dependency review. Beta uses finite-schema rejection and historical regression; no independent web penetration test has been run.
2. **NIST, Scientific Software Sustainability: The Numerical Reproducibility Challenge (2015)**: https://www.nist.gov/publications/scientific-software-sustainability-numerical-reproducibility-challenge — repeatable ensembles and distinction of numerical results from physical measurements. Beta uses fixed seeds, train/holdout, raw records and explicit evidence labels.
3. **MDN, Using Web Workers**: https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API/Using_web_workers — moving expensive computation off a browser UI thread is viable with message passing. Beta's tiny 24×16, 240-step simulations measured around 8–10 ms/run in one local Node workload, so the shipping single-file mode uses the direct CPU path; workers are **not** falsely claimed as implemented.
4. **MDN, Transferable objects**: https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API/Transferable_objects — transferable ArrayBuffer avoids copies but detaches source buffer. A future worker/GPU interface must encode this ownership explicitly; no premature GPU feature dependency.
5. **MDN, WebGPU**: https://developer.mozilla.org/en-US/docs/Web/API/WebGPU_API — compute API support is limited and requires secure contexts. Beta uses CPU reference behavior and does not claim GPU acceleration or across-device speedups.
6. **OpenTelemetry JavaScript**: https://opentelemetry.io/docs/languages/js/ — stable trace/metric semantics are useful for future exported telemetry. Beta's existing JSON trace is a project-specific schema, not a deployed OpenTelemetry collector.

No paid cloud job, model endpoint, new plugin subscription, or repository mutation was required. If future runs are outsourced to a cloud worker, keep the CPU baseline and seed/trace schema and report the actual hardware/time/cost separately.
