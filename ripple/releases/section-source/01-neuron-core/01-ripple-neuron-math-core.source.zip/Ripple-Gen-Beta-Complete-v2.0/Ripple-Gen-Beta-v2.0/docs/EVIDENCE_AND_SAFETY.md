# Evidence, safety and release gates

**Verified synthetic/software behavior**: original neuron event rates, source checksums, reversible 2-bit symbols, guarded decision grammar, local map/lineage replay, synthetic occlusion, conserved diffusion, steady structural bounds, bounded heredity, seed reproducibility, offline browser interactions, and predeclared comparisons.

**Computational measurement only**: CPU timings from this container. Timing does not transfer to the user's hardware, a GPU/supercomputer, web browser, or robot.

**Simulated**: colored spatial fields, mobility, diffusion through synthetic free cells, barriers, occupancy/crowding, clone energy, spatial sensing, share messages, and all agent coverage results. There is no calibrated sensor recording.

**Not demonstrated**: physical transmittance, photon counting, atomic/mass density, field/aura measurement, physical 3D ranging, robot autonomy, trained intelligence, unrestricted program synthesis, biological reproduction, CPU speedup on Samsung, or genuine sensor/ROS/PX4 control. The network is not opened by the Beta application and no app accounts are modified.

## Guardrails
- Run-time finite: `maxTicks=1200`, `maxAgents=16`, `maxRules=8`, `maxTrace=1200`, `maxKnowledge=1024`, `maxShare=8`, max bounded world 56×56.
- Strict input schema and finite normalized RGB. A fake `physical` packet is rejected.
- Actions allowlist contains SCAN, MOVE, SHARE, CLONE, WAIT only. No shell commands, `eval`, system I/O, network RPCs or arbitrary JS from digital genomes.
- Every synthetic record bears provenance. No raw camera frames, location tracking, network telemetry or remote automation.
- No mutation of archived sources; original neuron SHA-256 checked before release.
- Holdout seeds for the final release [131,137,139,149,151] were selected before final evaluation. Previous experiments did inspect earlier holdout seeds, so this is a new validation group, not proof of broad out-of-distribution generalization.
- Beta features are compared over the same *initial* synthetic conditions and seeds. Their later trajectories can differ due to changed actions and random-number consumption.

## Current verification vs missing gates

| Gate | Status |
|---|---|
| Locked core source checksum | Passed |
| Original v0.1 LIF brightness regression | Passed |
| Quaternary encoder all-byte round trip | Passed |
| 22 Node test cases | Passed |
| 300 architecture + 420 feature-intervention synthetic cases | Executed; CSV/JSON saved |
| Single-file browser interactions at 1280 and 393 px | Passed; Chromium page-content injection, no errors |
| Real camera/hardware validation | Not performed |
| Physical energy, density, wavelength measurement | Not performed |
| Browser URL deployment or external cloud execution | Not performed |
| Trustworthy supercomputer claim | Not applicable; ordinary local/container computational resources used |

## Real-world extension requirements (not secretly activated)
Create separate secure adapter `sensor -> typed SI-units measurement -> instrument metadata + timestamps -> calibration confidence -> Beta signal conversion`. Preserve raw measured stream, fail closed on missing validity fields, and replay holdout recordings against baseline before allowing any actuator. Use a genuine timestamped sensor interface rather than synthesizing field values and labeling them measured.

The Beta license is not implied for any archived third-party reference: preserve notices and verify permissions before redistributing those independently.
