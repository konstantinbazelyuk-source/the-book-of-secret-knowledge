/* Ripple Gen Beta v2.0 - reproducible synthetic architecture benchmark.
 * PRESERVE: original neuron and v0.7 QuadEncoder are imported VERBATIM.
 * Synthetic mapping and simulation are not physical sensing or intelligence.
 * Does NOT execute grayscale/monochrome studies or the archived alpha genome selector.
 */
import '../legacy/ripple-core.js';
import '../legacy/photoreceptor-v06.js';
import {QuadEncoder, QuadVM, pack4, unpack4, frameFeatures} from '../legacy/quaternary-core.mjs';
export {pack4, unpack4, frameFeatures};
const RippleNeuron=globalThis.RippleNeuron;
const Photoreceptor=globalThis.RippleLightV06.Photoreceptor;
export {RippleNeuron, QuadEncoder, QuadVM, Photoreceptor};
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const finite=x=>typeof x==='number'&&Number.isFinite(x);
function check(ok,message){if(!ok)throw Error('Ripple Beta guard: '+message)}
export function rng(seed){let s=seed>>>0;return ()=>((s=(Math.imul(1664525,s)+1013904223)>>>0))/4294967296;}
export const BETA_LIMITS=Object.freeze({minWidth:8,maxWidth:56,minHeight:8,maxHeight:56,maxTicks:1200,maxAgents:16,maxRules:8,maxKnowledge:1024,maxShare:8,maxTrace:1200,stepDt:.05,diffusion:0.34,diffusionDt:0.16});
export const ACTIONS=Object.freeze(['SCAN','MOVE','SHARE','CLONE','WAIT']);
export const CONDITIONS=Object.freeze(['ALWAYS','UNSEEN','NEAR_WALL','HAVE_PEER','HIGH_ENERGY','LOW_ENERGY','Q_UP','Q_DOWN','RESOURCE_NEAR']);
export const POLICIES=Object.freeze({
 'neuron-only':{name:'Neuron only',optical:false,quad:false,spatial:false,memory:false,share:false,clone:false,rules:[['ALWAYS','WAIT']]},
 'optical-q':{name:'Optical + Q',optical:true,quad:true,spatial:false,memory:false,share:false,clone:false,rules:[['ALWAYS','WAIT']]},
 'spatial':{name:'Spatial baseline',optical:false,quad:false,spatial:true,memory:false,share:false,clone:false,rules:[['ALWAYS','SCAN'],['ALWAYS','MOVE']]},
 'colony':{name:'Colony + memory',optical:false,quad:true,spatial:true,memory:true,share:true,clone:false,rules:[['HAVE_PEER','SHARE'],['UNSEEN','SCAN'],['ALWAYS','MOVE']]},
 'hybrid-beta':{name:'Guarded Hybrid Beta',optical:true,quad:true,spatial:true,memory:true,share:true,clone:true,density:false,rules:[['HIGH_ENERGY','CLONE'],['UNSEEN','SCAN'],['HAVE_PEER','SHARE'],['RESOURCE_NEAR','SCAN'],['ALWAYS','MOVE']]}
});
// Ablations differ by exactly one enabled mechanism from the final Beta policy.
const hybrid=POLICIES['hybrid-beta'];
const ablations={
 'beta-no-optical':{...hybrid,name:'Beta without optical frontend',optical:false},
 'beta-no-quaternary':{...hybrid,name:'Beta without Q coding',quad:false},
 'beta-no-sharing':{...hybrid,name:'Beta without sharing',share:false,rules:hybrid.rules.filter(r=>r[1]!=='SHARE')},
 'beta-no-cloning':{...hybrid,name:'Beta without descendants',clone:false,rules:hybrid.rules.filter(r=>r[1]!=='CLONE')},
 'beta-no-memory':{...hybrid,name:'Beta without memory',memory:false,rules:hybrid.rules.filter(r=>r[0]!=='UNSEEN')},
 'beta-density-on':{...hybrid,name:'Beta with occupancy hypothesis',density:true}
};
export const BETA_ABLATIONS=Object.freeze(ablations);
const DIRS=Object.freeze([[0,-1],[1,0],[0,1],[-1,0]]);
export function validateProgram(program){
 check(Array.isArray(program)&&program.length>0&&program.length<=BETA_LIMITS.maxRules,'rules count 1..8');
 return Object.freeze(program.map(rule=>{
   check(Array.isArray(rule)&&rule.length===2&&CONDITIONS.includes(rule[0])&&ACTIONS.includes(rule[1]),'only allowlisted condition/action');
   return Object.freeze([...rule]);
 }));
}
export function validateSensorPacket(packet){
 check(packet&&typeof packet==='object'&&!Array.isArray(packet),'packet object');
 check(packet.type==='rgb'&&packet.kind==='synthetic','only synthetic RGB in Beta; physical data requires separate calibrated adapter');
 check(Array.isArray(packet.rgb)&&packet.rgb.length===3&&packet.rgb.every(v=>finite(v)&&v>=0&&v<=1),'RGB normalized and finite');
 check(Number.isInteger(packet.tick)&&packet.tick>=0&&packet.tick<=BETA_LIMITS.maxTicks,'valid model tick');
 check(Object.keys(packet).every(k=>['type','kind','rgb','tick','sourceId'].includes(k)),'schema allowlist');
 return Object.freeze({...packet,rgb:Object.freeze([...packet.rgb])});
}
// Pairwise flux: equal-and-opposite; this is synthetic diffusion, NOT photon or mass density.
export function betaDiffusion(field,width,height,coeff=.34,dt=.16,mask=null,occupancy=null,crowding=.5){
 check(Number.isInteger(width)&&width>=2&&Number.isInteger(height)&&height>=2&&field.length===width*height*3,'shape');
 check(finite(coeff)&&coeff>=0&&coeff<=.42&&finite(dt)&&dt>0&&dt<=.25&&4*coeff*dt<=.25,'stability');
 check(finite(crowding)&&crowding>=0&&crowding<=1,'crowding');
 const out=new Float64Array(field);
 for(let y=0;y<height;y++)for(let x=0;x<width;x++){
  const i=y*width+x;
  for(const j of [...(x+1<width?[i+1]:[]),...(y+1<height?[i+width]:[])]){
   const o=Math.max(mask?.[i]??0,mask?.[j]??0);
   check(finite(o)&&o>=0&&o<=1,'occlusion finite');if(o===1)continue;
   const dens=occupancy?(occupancy[i]+occupancy[j])/2:0;
   check(finite(dens)&&dens>=0,'occupancy nonnegative');
   const alpha=coeff*dt*(1-o)/(1+crowding*dens);
   for(let c=0;c<3;c++){const u=i*3+c,v=j*3+c,flux=alpha*(field[v]-field[u]);out[u]+=flux;out[v]-=flux;}
  }
 }
 return out;
}
function hash(x){let s=JSON.stringify(x),h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return (h>>>0).toString(16).padStart(8,'0');}
export function makeGenome(g){
 check(g&&typeof g==='object'&&!Array.isArray(g),'genome object');
 const allowed=['name','role','colorWeights','mobility','memory','share','clone','generation','parent','program'];
 check(Object.keys(g).every(k=>allowed.includes(k)),'unknown genome field');
 const weights=g.colorWeights??[1,.6,.3];
 check(Array.isArray(weights)&&weights.length===3&&weights.every(v=>finite(v)&&v>=0&&v<=1),'genome weights');
 const program=validateProgram(g.program??[['UNSEEN','SCAN'],['ALWAYS','MOVE']]);
 for(const k of ['mobility','memory','share','clone']){const v=g[k]??0.5;check(finite(v)&&v>=0&&v<=1,'genome bounded '+k);}
 check(['explorer','relay','guardian','general'].includes(g.role??'general'),'role');
 check(Number.isInteger(g.generation??0)&&(g.generation??0)>=0&&(g.generation??0)<=20,'lineage depth');
 check(g.parent==null||/^[0-9a-f]{8}$/.test(g.parent),'parent ID');
 const o={schema:'ripple-beta-gene/1',name:String(g.name??'Ripple').slice(0,28),role:g.role??'general',colorWeights:Object.freeze([...weights]),mobility:g.mobility??.65,memory:g.memory??.7,share:g.share??.65,clone:g.clone??.5,generation:g.generation??0,parent:g.parent??null,program};
 return Object.freeze({...o,id:hash(o)});
}
export function mutateGenome(parent,random){
 check(parent?.schema==='ripple-beta-gene/1'&&typeof random==='function','bounded genome');
 // Edit only known numerical parameters or rule ordering, never add arbitrary instructions.
 const chroma=parent.colorWeights.map(x=>clamp(x+(random()-.5)*.16,0,1));
 const program=parent.program.map(r=>[...r]);if(program.length>1&&random()<.5){const a=Math.floor(random()*program.length),b=Math.floor(random()*program.length);[program[a],program[b]]=[program[b],program[a]];}
 return makeGenome({name:parent.name+'+',role:parent.role,colorWeights:chroma,mobility:clamp(parent.mobility+(random()-.5)*.09,0,1),memory:parent.memory,share:parent.share,clone:parent.clone,generation:parent.generation+1,parent:parent.id,program});
}
export class BetaWorld{
 constructor(options={}){
  const width=options.width??24,height=options.height??16,seed=options.seed??1731;
  check(Number.isInteger(width)&&width>=8&&width<=56&&Number.isInteger(height)&&height>=8&&height<=56,'world dimensions');
  check(Number.isInteger(seed)&&seed>=0&&seed<=4294967295,'seed');
  this.w=width;this.h=height;this.size=width*height;this.seed=seed;this.random=rng(seed);this.tick=0;
  this.scenario=options.scenario??'mixed';check(['mixed','barriers','noise','resources'].includes(this.scenario),'scenario');
  this.policy=options.policy??'hybrid-beta';check(Object.hasOwn(POLICIES,this.policy)||Object.hasOwn(BETA_ABLATIONS,this.policy),'named policy');this.flags=POLICIES[this.policy]??BETA_ABLATIONS[this.policy];
  this.field=new Float64Array(this.size*3);this.mask=new Float64Array(this.size);this.occ=new Float64Array(this.size);this.agents=[];this.globalDiscovered=new Set();
  this.audit=[];this.traces=[];this.metrics={events:0,scans:0,reads:0,validNewCells:0,blockedRays:0,moves:0,blockedMoves:0,shares:0,sharedCells:0,clones:0,commands:0,rejected:0,energySpent:0,sourceInjected:0};
  const wallX=Math.floor(width*.52);if(this.scenario!=='noise')for(let y=0;y<height;y++)if(y<Math.floor(height*.4)||y>Math.floor(height*.66))this.mask[wallX+y*width]=1;
  if(this.scenario==='barriers')for(let x=4;x<width-3;x++)if(x%5!==0)this.mask[x+Math.floor(height*.23)*width]=1;
  this.sources=[[Math.floor(width*.13),Math.floor(height*.25),0],[Math.floor(width*.85),Math.floor(height*.66),1],[Math.floor(width*.25),Math.floor(height*.82),2],[Math.floor(width*.22),Math.floor(height*.52),0]];
  this.field[this.idx(Math.floor(width*.22),Math.floor(height*.52))*3]=1.2;
  this.addAgent(makeGenome({name:'Prism',role:'explorer',colorWeights:[1,.3,.12],mobility:.8,memory:.7,clone:.6,program:this.flags.rules}),Math.floor(width*.20),Math.floor(height*.5));
  this.addAgent(makeGenome({name:'Canopy',role:'relay',colorWeights:[.15,1,.32],mobility:.58,share:.9,program:this.flags.rules}),Math.floor(width*.25),Math.floor(height*.55));
  this.addAgent(makeGenome({name:'Ember',role:'guardian',colorWeights:[.95,.5,.09],mobility:.47,program:this.flags.rules}),Math.floor(width*.19),Math.floor(height*.62));
 }
 idx(x,y){return y*this.w+x;}
 addAgent(g,x,y){check(this.agents.length<BETA_LIMITS.maxAgents,'max population');const id=this.agents.length;
  if(this.mask[this.idx(x,y)]===1){x=1;y=1;}
  const a={id,x,y,g,energy:2.0,age:0,events:0,neuron:new RippleNeuron(),q:new QuadEncoder({threshold:.07,dwell:2}),light:new Photoreceptor({linear:false,logGain:6,transientGain:.25}),known:new Map(),path:[[x,y,0]],lastSymbol:'0',sensed:0,shared:0};
  this.agents.push(a);this.audit.push({tick:this.tick,type:'born',id,parent:g.parent,gene:g.id,role:g.role});return a;
 }
 inject(){for(const [x,y,c] of this.sources){const i=this.idx(x,y)*3+c,amt=this.scenario==='noise'?(this.random()<.5?.03:0):.03;const before=this.field[i];this.field[i]=Math.min(1.8,this.field[i]+amt);this.metrics.sourceInjected+=this.field[i]-before;}}
 ray(a,dx,dy,range=2){const found=[];for(let step=1;step<=range;step++){let x=a.x+dx*step,y=a.y+dy*step;if(x<0||x>=this.w||y<0||y>=this.h)break;const pos=this.idx(x,y);this.metrics.reads++;if(this.mask[pos]===1){this.metrics.blockedRays++;found.push({x,y,wall:true});break;}found.push({x,y,wall:false});}return found;}
 local(a){const i=this.idx(a.x,a.y);const rgb=[...this.field.slice(i*3,i*3+3)].map(x=>clamp(x,0,1));const neighbors=DIRS.map(([dx,dy])=>[a.x+dx,a.y+dy]).filter(([x,y])=>x>=0&&x<this.w&&y>=0&&y<this.h);
  return{rgb,rgbWeighted:rgb.map((v,j)=>clamp(v*a.g.colorWeights[j],0,1)),nearWall:neighbors.some(([x,y])=>this.mask[this.idx(x,y)]===1),unseen:neighbors.some(([x,y])=>!a.known.has(this.idx(x,y))),peer:this.agents.some(b=>b!==a&&Math.abs(b.x-a.x)+Math.abs(b.y-a.y)<=2),resource:rgb.reduce((s,v)=>s+v,0)>.2};
 }
 condition(a,s,c){switch(c){case'ALWAYS':return true;case'UNSEEN':return s.unseen;case'NEAR_WALL':return s.nearWall;case'HAVE_PEER':return s.peer;case'HIGH_ENERGY':return a.energy>(4.5-a.g.clone)&&this.agents.length<BETA_LIMITS.maxAgents&&a.g.generation<4;case'LOW_ENERGY':return a.energy<.55;case'Q_UP':return a.lastSymbol==='1';case'Q_DOWN':return a.lastSymbol==='-1';case'RESOURCE_NEAR':return s.resource;default:return false;}}
 act(a,action){this.metrics.commands++;const r=this.random;
  if(action==='SCAN'){
   this.metrics.scans++;const direction=DIRS[(a.id+this.tick)%4];const hits=this.ray(a,...direction,3);
   for(const p of hits){const key=this.idx(p.x,p.y);if(this.flags.memory){if(!a.known.has(key)){if(a.known.size>=Math.min(BETA_LIMITS.maxKnowledge,Math.floor(64+960*a.g.memory)))break;a.known.set(key,{wall:p.wall,t:this.tick});this.globalDiscovered.add(key);this.metrics.validNewCells++;}}else this.globalDiscovered.add(key);}
   a.energy=Math.max(0,a.energy-.015);return action;
  }
  if(action==='MOVE'){
   const dirs=[...DIRS];for(let i=dirs.length-1;i>0;i--){const j=Math.floor(r()*(i+1));[dirs[i],dirs[j]]=[dirs[j],dirs[i]];}
   // Heritable mobility and role-specific orientation affect only synthetic routing.
   if(r()>a.g.mobility){a.energy=Math.max(0,a.energy-.003);return 'WAIT';}
   if(this.flags.memory&&a.g.role==='explorer')dirs.sort((d1,d2)=>{
    const known=(d)=>{const x=a.x+d[0],y=a.y+d[1];return x<0||x>=this.w||y<0||y>=this.h||a.known.has(this.idx(x,y))?1:0;};return known(d1)-known(d2);});
   if(this.flags.share&&a.g.role==='relay'){
    const near=this.agents.filter(b=>b!==a);
    if(near.length){const proximity=d=>Math.min(...near.map(b=>Math.abs(b.x-(a.x+d[0]))+Math.abs(b.y-(a.y+d[1]))));dirs.sort((d1,d2)=>proximity(d1)-proximity(d2));}
   }
   // Local known blocked cells may guide movement; unknown cells are exploratory.
   const move=dirs.find(([dx,dy])=>{const x=a.x+dx,y=a.y+dy;if(x<0||x>=this.w||y<0||y>=this.h)return false;return this.mask[this.idx(x,y)]<1&&(!this.flags.memory||a.known.get(this.idx(x,y))?.wall!==true);});
   if(move){a.x+=move[0];a.y+=move[1];this.metrics.moves++;if(a.path.length<BETA_LIMITS.maxTrace)a.path.push([a.x,a.y,this.tick]);}else this.metrics.blockedMoves++;
   a.energy=Math.max(0,a.energy-.015);return action;
  }
  if(action==='SHARE'){
   if(this.flags.share){const peer=this.agents.find(b=>b!==a&&Math.abs(b.x-a.x)+Math.abs(b.y-a.y)<=2);if(peer){this.metrics.shares++;let shared=0;for(const [key,info]of a.known){if(shared>=Math.min(BETA_LIMITS.maxShare,Math.max(1,Math.floor(BETA_LIMITS.maxShare*a.g.share))))break;if(!peer.known.has(key)&&peer.known.size<BETA_LIMITS.maxKnowledge){peer.known.set(key,{...info});shared++;}}this.metrics.sharedCells+=shared;a.shared+=shared;}}
   a.energy=Math.max(0,a.energy-.01);return action;
  }
  if(action==='CLONE'){
   if(this.flags.clone&&a.energy>(4.5-a.g.clone)&&a.g.generation<4&&this.agents.length<BETA_LIMITS.maxAgents){const child=mutateGenome(a.g,r);this.addAgent(child,a.x,a.y);a.energy-=1.4;this.metrics.clones++;return action;}
   this.metrics.rejected++;return 'WAIT';
  }
  return 'WAIT';
 }
 step(){check(this.tick<BETA_LIMITS.maxTicks,'max simulation ticks');
  this.tick++;this.inject();this.occ.fill(0);for(const a of this.agents)this.occ[this.idx(a.x,a.y)]++;
  const before=this.field;this.field=betaDiffusion(before,this.w,this.h,.34,.16,this.mask,this.flags.density===false?null:this.occ,.55);
  const current=[...this.agents];for(const a of current){a.age++;const s=this.local(a);let x=s.rgbWeighted;
   if(this.flags.optical)x=a.light.step(x,.05).output;
   // Distinct genome weighting is permitted, but original LIF coefficients remain locked.
   const pulse=a.neuron.step(x,.05),symbol=this.flags.quad?a.q.step({drive:pulse.drive}).label:'0';a.lastSymbol=symbol;
   a.energy=clamp(a.energy+(.025+Math.max(0,pulse.drive)*.06)-.015,0,5);
   a.events+=pulse.count;this.metrics.events+=pulse.count;
   // Rule list selection is bounded. Neuron pulses gate SCAN/SHARE; non-pulsing agents can MOVE.
   const rules=a.g.program;let selected='WAIT';if(this.flags.spatial){for(const [cond,act] of rules)if(this.condition(a,s,cond)){if((act==='SCAN'||act==='SHARE'||act==='CLONE')&&!pulse.count&&!(act==='CLONE'&&a.energy>4.2))continue;selected=act;break;}}
   this.act(a,selected);
   if(this.traces.length<BETA_LIMITS.maxTrace&&this.tick%10===0)this.traces.push({tick:this.tick,agent:a.id,action:selected,quaternary:symbol,energy:Number(a.energy.toFixed(4)),x:a.x,y:a.y,gate:pulse.count,role:a.g.role});
  }
  return this.snapshot();
 }
 run(steps=160){check(Number.isInteger(steps)&&steps>0&&steps<=BETA_LIMITS.maxTicks-this.tick,'run bounded');for(let i=0;i<steps;i++)this.step();return this.summary();}
 snapshot(){return{tick:this.tick,population:this.agents.length,coverage:this.globalDiscovered.size,events:this.metrics.events};}
 summary(){return{seed:this.seed,scenario:this.scenario,policy:this.policy,ticks:this.tick,events:this.metrics.events,coverage:this.globalDiscovered.size,uniqueCoverageRatio:this.globalDiscovered.size/this.size,population:this.agents.length,clones:this.metrics.clones,moves:this.metrics.moves,scans:this.metrics.scans,blockedRays:this.metrics.blockedRays,blockedMoves:this.metrics.blockedMoves,shares:this.metrics.shares,sharedCells:this.metrics.sharedCells,rejected:this.metrics.rejected,readBudget:this.metrics.reads,sourceInjected:this.metrics.sourceInjected,totalSignal:[0,1,2].map(c=>this.field.reduce((sum,v,i)=>i%3===c?sum+v:sum,0)),traceCount:this.traces.length,provenance:'SYNTHETIC SIMULATION; no physical sensor input'};}
 fieldImage(){return{width:this.w,height:this.h,rgb:[...this.field],mask:[...this.mask],agents:this.agents.map(a=>({id:a.id,x:a.x,y:a.y,role:a.g.role,gene:a.g.id,parent:a.g.parent}))};}
 exportRecord(){return{schema:'ripple-gen-beta/1',summary:this.summary(),lineage:this.audit.slice(),paths:this.agents.map(a=>({id:a.id,genome:a.g,points:a.path.slice()})),trace:this.traces.slice(),field:this.fieldImage(),evidence:'synthetic',coreHash:'dba6639b7902f0c702d15fff588524629f3754cfd72d7b704f22a76b78960ee3'};}
}
