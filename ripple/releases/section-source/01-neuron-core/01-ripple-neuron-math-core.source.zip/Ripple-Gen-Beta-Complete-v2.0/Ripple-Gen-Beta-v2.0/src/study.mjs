import {BetaWorld,POLICIES} from './beta-engine.mjs';
import {performance} from 'node:perf_hooks';
import {writeFileSync,mkdirSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const base=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const train=[11,17,23,29,31,37,41,43,47,53],holdout=[131,137,139,149,151];
const scenarios=['mixed','barriers','noise','resources'];const policies=Object.keys(POLICIES);const rows=[];
const steps=240;
function runSuite(seedList,split){for(const seed of seedList)for(const scenario of scenarios)for(const policy of policies){const world=new BetaWorld({seed,scenario,policy});const start=performance.now();const result=world.run(steps),elapsedMs=performance.now()-start;rows.push({...result,split,elapsedMs:+elapsedMs.toFixed(5)});}}
runSuite(train,'development');runSuite(holdout,'holdout');
const mean=(arr,key)=>arr.reduce((n,x)=>n+x[key],0)/arr.length;
const quantile=(v,p)=>{const s=[...v].sort((a,b)=>a-b),k=(s.length-1)*p,lo=Math.floor(k),hi=Math.ceil(k);return s[lo]+(s[hi]-s[lo])*(k-lo);};
const stats=[];for(const split of ['development','holdout'])for(const policy of policies){const r=rows.filter(x=>x.policy===policy&&x.split===split);
 stats.push({split,policy,n:r.length,coverageMean:mean(r,'coverage'),coverageP10:quantile(r.map(x=>x.coverage),.1),coverageP90:quantile(r.map(x=>x.coverage),.9),eventsMean:mean(r,'events'),populationMean:mean(r,'population'),sharedCellsMean:mean(r,'sharedCells'),clonesMean:mean(r,'clones'),readBudgetMean:mean(r,'readBudget'),scansMean:mean(r,'scans'),movesMean:mean(r,'moves'),runtimeMedianMs:quantile(r.map(x=>x.elapsedMs),.5),runtimeP95Ms:quantile(r.map(x=>x.elapsedMs),.95)});
}
const pairwise=[];for(const split of ['development','holdout'])for(const opponent of policies.filter(x=>x!=='hybrid-beta')){const pairs=rows.filter(x=>x.split===split&&['hybrid-beta',opponent].includes(x.policy));let win=0,loss=0,tie=0;
 for(const seed of split==='development'?train:holdout)for(const scenario of scenarios){const a=pairs.find(x=>x.seed===seed&&x.scenario===scenario&&x.policy==='hybrid-beta');const b=pairs.find(x=>x.seed===seed&&x.scenario===scenario&&x.policy===opponent);if(a.coverage>b.coverage)win++;else if(a.coverage<b.coverage)loss++;else tie++;}
 pairwise.push({split,opponent,metric:'coverage',win,loss,tie});}
const result={experiment:'RIPPLE-GEN-BETA/AB-001',evidence:'SYNTHETIC comparison + MACHINE-LOCAL COMPUTATIONAL TIMING',machine:'this execution environment; not a supercomputer or Samsung',steps,trainSeeds:train,holdoutSeeds:holdout,scenarios,policies,allRuns:rows.length,stats,pairwise,limitations:['World observations are synthetic, no physical camera/sensor data','Population and event count do not imply intelligence','The five policies have intentionally different control loops and resource budgets','CPU time is machine/load dependent; not device-neutral','Benchmark has no externally labeled ground-truth target task','Holdout splits were declared before evaluation; no optimization against holdout was performed']};
mkdirSync(path.join(base,'results'),{recursive:true});writeFileSync(path.join(base,'results','architecture-comparison.json'),JSON.stringify(result,null,2));
const fields=['split','seed','scenario','policy','coverage','events','population','sharedCells','clones','readBudget','scans','moves','elapsedMs'];const csv=[fields.join(','),...rows.map(r=>fields.map(k=>r[k]).join(','))].join('\n');writeFileSync(path.join(base,'results','all-trials.csv'),csv+'\n');
console.log(JSON.stringify({allRuns:result.allRuns,steps,stats,pairwise},null,2));
