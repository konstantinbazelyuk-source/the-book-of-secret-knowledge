# Bench build and acceptance procedure

Status: sourced design and syntax-checked firmware; **physical hardware not tested**. Use an original Raspberry Pi Pico/Pico H. Pico W/2 variants have different LED details and are not the specified build.

## Bill of materials

| Qty | Item | Purpose / exact choice |
|---:|---|---|
| 1 | Raspberry Pi Pico H, or Pico with soldered headers | RP2040 processor, USB power and serial; original Pico pin map [S3] |
| 1 | Adafruit AS7341 breakout, product 4698 | Eight visible bands; board includes regulator/level shifting [S1,S2] |
| 1 | Common-anode diffused RGB LED, Adafruit product 159 | Three physical optical channels; use vendor lead diagram [S4] |
| 3 | onsemi 2N3904, TO-92 | One low-side transistor for each LED cathode [S5] |
| 3 | 1 kohm, 1/4 W resistor | One series current resistor for each cathode |
| 3 | 2.2 kohm resistor | One Pico-to-base resistor per transistor |
| 3 | 100 kohm resistor | One base-to-emitter pull-down per transistor |
| 1 set | Breadboard, jumper wires, data-capable Micro USB cable | Electrical assembly and USB connection |
| 1 | Opaque tube/box and neutral diffuser | Fixed optical geometry; shield ambient and indicator light |

The sensor listing was $18.95 when checked on 2026-10-13 [S1]. Other prices were not verified; obtain local quotes for a total. No AI service or paid software is needed to run this prototype.

## Pin map

Physical pin numbers refer to the official original Pico drawing, with USB at the top [S3].

| Pico connection | Physical pin | Goes to |
|---|---:|---|
| 3V3(OUT) | 36 | AS7341 **breakout VIN** |
| GND | 38 | AS7341 GND and common ground rail |
| GP0 / I2C0 SDA | 1 | AS7341 SDA |
| GP1 / I2C0 SCL | 2 | AS7341 SCL |
| VBUS (USB supply) | 40 | RGB LED common anode |
| GP14 | 19 | 2.2 kohm -> red transistor base |
| GP15 | 20 | 2.2 kohm -> green transistor base |
| GP16 | 21 | 2.2 kohm -> blue transistor base |
| GP25 | onboard only | Built-in LED activity indicator; no external wiring |

For each LED branch: LED cathode -> 1 kohm -> transistor collector; emitter -> GND; 100 kohm from base to emitter. Follow the selected manufacturer's transistor drawing: onsemi's specified TO-92 has 1 emitter, 2 base, 3 collector. Do not infer the lead orientation of another manufacturer's part from this table. Use functional labels in `Ripple-Neuron-Wiring.svg`.

Use the **Adafruit breakout**, not the bare AS7341 IC: the bare chip's power/logic requirements differ. Connect USB 5 V only to VBUS/anode in this build; sensor breakout VIN is supplied from Pico 3.3 V.

## Electrical calculations

With a 1 kohm series resistor and USB voltage no greater than 5.25 V, the branch current is at most 5.25 mA even if all other branch voltage drops are ignored. Series resistor dissipation is at most (5.25)^2/1000 = 27.6 mW, below a 1/4 W rating. These are conservative design bounds, not measured values.

For a typical base-emitter drop of 0.75 V, base drive is approximately (3.3-0.75)/2200 = 1.16 mA. The supplied base pull-down consumes only a small additional current. The transistor isolates the 5 V LED branch from the Pico logic output. Manufacturer saturation specifications support the small-current switching use [S5]. RGB channels have different forward drops and brightness; calibration is required and no equal-current/equal-brightness assumption is used.

## Optical assembly

Start with the diffused RGB LED facing the sensor inside an opaque box, roughly 10-30 mm apart. This is an adjustable starting geometry, not a validated distance. Fix the position after calibration. Keep Pico's indicator outside the optical chamber. Set the sensor's onboard illuminator off. Hold input colors steady across both sensor banks; v0.1 uses slow steps, not optical-frequency sampling.

## Install firmware

1. Install the current CircuitPython build for the **original Raspberry Pi Pico** using the board's official instructions [S7]. Connect with a data USB cable.
2. Install the Adafruit CircuitPython library bundle matching your CircuitPython major version. Copy `adafruit_as7341.mpy` (or `.py`), `adafruit_bus_device/` and `adafruit_register/` into `CIRCUITPY/lib/` [S6]. Keep their licenses.
3. Copy `ripple_core.py`, `firmware/optical_sensor.py`, `firmware/frame_capture.py` and `firmware/code.py` into the CIRCUITPY root, preserving those basenames.
4. Open a USB serial console. Set `ADAPTIVE=True` in `code.py` for the first run.
5. Firmware calibrates dark, red, green and blue, then checks a half-intensity mixture. `BOOT_JSON` logs runtime/driver versions and frequency settings; `RAW_FRAME_JSON` logs both status-bearing banks, raw counts, acquisition times and requested PWM, including rejected/incomplete frames. `CALIBRATION_JSON` includes the references/decoder and mixture check. `FAULT_JSON` preserves failure details. Failed quality checks stop with outputs off; adjust geometry/gain and reboot.
6. It repeats the 40 s low / 40 s high / 40 s low red-input profile. Capture complete serial logs. Repeat with `ADAPTIVE=False` for the fixed-threshold run.

The sensor adapter deliberately uses two verified **private** Adafruit bank-selection methods and the status-bearing ADC struct. The public `all_channels` method drops the per-bank saturation status. This private API is a compatibility boundary, not an invented public API; recheck it against the installed driver source. Firmware checks the tuple format. A future adapter should expose the same data through a stable public driver interface if one is available [S6a].

## Timing and calibration settings

ATIME=0, ASTEP=3599, gain=16x. Integration time per bank = (0+1)(3599+1)*2.78 us = **10.008 ms**. Full-scale digital count = min(65535,3600)=**3600**. Eight bands require two sequential banks and software overhead. The requested loop period is 100 ms; actual elapsed time is logged/used, not assumed. A gap over 500 ms stops processing. The newest decoded reading represents the elapsed interval since the preceding frame (endpoint-held reconstruction); brightness-transition timing is uncertain at the frame/integration scale. No claim of simultaneous eight-band sampling or precision physical spike timing is made [S2,S6a].

References are measured at 60% emitter duty, 5 kHz PWM, 12 frames per reference after a 250 ms settling interval. PWM frequency is a commanded value, to be checked on the bench. The decoder's x=1 means the measured reference optical output, not one watt or one volt. A calibration column needs >=50 counts above dark in at least one band (v0.1 quality criterion). Gram-matrix infinity-norm condition number must be <=1000. Saturation flags or counts at/above 90% digital full scale reject the frame. A mixed reference must decode each channel to 0.5 +/-0.10 with spectral residual <=0.10. The numerical criteria are design choices, not manufacturer guarantees.

## Acceptance record for a real build

| Check | Proposed acceptance gate | Evidence to retain |
|---|---|---|
| Electrical assembly | Measured 3.3 V/USB rails, each LED branch within the computed current bound | Multimeter readings; component and wiring photos |
| Sensor integrity | Correct I2C device, stable bank format, no analog/digital saturation | Driver/CircuitPython versions, raw counts/status, integration/gain settings |
| Color decoding | References pass; several unseen mixtures have absolute per-channel errors <=0.10 and residual <=0.10 | Raw counts, requested PWM, calibration matrix and decoded mixtures |
| Sampling | No timing gaps >0.5 s; record typical/max frame period | Timestamped frame log; logic-analyzer PWM capture if available |
| Regulation | Each final 20 s window gives 1.0 +/-0.15 model events/s at the specified profile | Event/frame log for adaptive and fixed runs |
| Darkness/inhibition | No sustained events in darkness; blue suppresses the specified red drive | Separate raw and decoded traces |

These are proposed pass/fail criteria. No hardware row has been marked passed in this release. Measured input histories should also be replayed through the desktop model; ideal simulation numbers need not exactly match a physical build.

Sources S1-S8 and publication links are in `ENGINEERING.md`.
