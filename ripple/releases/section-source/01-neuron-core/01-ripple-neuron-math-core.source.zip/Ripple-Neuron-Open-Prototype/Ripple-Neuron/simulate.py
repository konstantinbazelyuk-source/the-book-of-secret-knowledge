"""Run a fully reproducible synthetic brightness-step experiment. CC0-1.0."""
import csv
import json
from pathlib import Path
from ripple_core import Neuron


def experiment(dt=0.05):
    adaptive,fixed=Neuron(),Neuron(adaptive=False)
    rows=[]
    spikes={"adaptive":[],"fixed":[]}
    for k in range(round(120/dt)):
        t=k*dt
        red=0.35 if t<40 or t>=80 else 0.70
        a=adaptive.step([red,0,0],dt)
        b=fixed.step([red,0,0],dt)
        spikes["adaptive"].extend(a["events"])
        spikes["fixed"].extend(b["events"])
        rows.append({"time_s":a["t"],"red_norm":red,"green_norm":0,"blue_norm":0,
                     "drive":a["drive"],"theta_adaptive":a["theta"],"theta_fixed":b["theta"],
                     "rate_adaptive_hz":a["rate"],"rate_fixed_hz":b["rate"],
                     "spikes_adaptive":a["count"],"spikes_fixed":b["count"]})
    windows=[]
    for lo,hi in [(20,40),(60,80),(100,120)]:
        windows.append({"window_s":[lo,hi],
                        **{name+"_hz":sum(lo<=e<hi for e in es)/(hi-lo) for name,es in spikes.items()}})
    summary={"evidence_type":"numerical simulation; no physical hardware measured",
             "duration_s":120,"dt_s":dt,"target_hz":1.0,
             "rate_windows":windows,"total_spikes":{k:len(v) for k,v in spikes.items()},
             "threshold_range":[min(r["theta_adaptive"] for r in rows),max(r["theta_adaptive"] for r in rows)],
             "parameters":{"tau_v_s":0.5,"tau_rate_s":5,"refractory_s":0.1,"eta":0.08,
                           "theta_min":0.15,"theta_max":2.5,"weights":[2,1.2,-1.4]},
             "scope":"No proof of stability for all inputs, hardware operation, task learning, or robotic intelligence."}
    return rows,spikes,summary


def write_results(out):
    out=Path(out)
    out.mkdir(parents=True,exist_ok=True)
    rows,spikes,summary=experiment()
    with (out/"simulation.csv").open("w",newline="") as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    (out/"simulation_summary.json").write_text(json.dumps(summary,indent=2)+"\n")
    with (out/"model_events.csv").open("w",newline="") as f:
        w=csv.writer(f);w.writerow(["model","event_time_s"])
        for name,events in spikes.items():
            for event in events:w.writerow([name,event])
    print(json.dumps(summary,indent=2))


if __name__=="__main__":
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out",default="results")
    write_results(parser.parse_args().out)
