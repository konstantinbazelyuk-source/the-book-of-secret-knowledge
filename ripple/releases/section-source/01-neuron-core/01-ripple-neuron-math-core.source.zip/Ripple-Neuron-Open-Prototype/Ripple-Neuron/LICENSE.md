# Free reuse of the original Ripple materials

SPDX-License-Identifier: CC0-1.0

At the concept contributor's request, the original engineering documents, drawings, code and synthetic data created for this release are dedicated under **CC0 1.0 Universal**, to the extent the contributor holds the applicable copyright and related rights.

Full, unmodified terms: https://creativecommons.org/publicdomain/zero/1.0/legalcode.en

You may build, adapt, share and commercially reuse these original materials. Attribution to Constantin x is welcome but not required by CC0. No application, registration fee, subscription or permission from this project is required to use the original materials under those terms.

CC0 addresses copyright and related rights. It does not clear third-party patents, trademarks, privacy rights or other external rights. No patent ownership, patent clearance or novelty has been established for this design. The publication date shown on the files is a preparation date, not evidence that an external public disclosure has already occurred.

The Adafruit AS7341/BusDevice/Register libraries and CircuitPython are external dependencies and are not relicensed by this package. Retain their own licenses when redistributing them. The supplied design and code are experimental materials supplied without a warranty of hardware performance.
