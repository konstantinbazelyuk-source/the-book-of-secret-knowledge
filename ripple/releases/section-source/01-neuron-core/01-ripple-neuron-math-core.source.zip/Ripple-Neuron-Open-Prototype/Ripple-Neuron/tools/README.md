# Optional visual regeneration

Run `python3 tools/rebuild_visuals.py` from the package root. It recreates the editable SVGs, PNGs and PDF from the same numerical model. Requires numpy, matplotlib and reportlab, plus the DejaVu fonts at `/usr/share/fonts/truetype/dejavu/` (adjust that font path for another platform). These authoring dependencies are optional; the neuron simulation itself uses the Python standard library. Outputs are staged in `rebuilt-exports/` and copied into the package.
