from pathlib import Path
import json, shutil
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Circle, Rectangle, FancyArrowPatch
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,PageBreak,Table,TableStyle,Image,Preformatted
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.enums import TA_LEFT

ROOT=Path(__file__).resolve().parents[1]
PKG=ROOT
OUT=ROOT/'rebuilt-exports'
OUT.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False})
INK='#162e3e'; MUTED='#53666d'; GREEN='#247953'; RED='#be4b44'; BLUE='#286fa7'; PAPER='#f5f4ee'; LINE='#d9e0dd'


def rounded(ax,x,y,w,h,title,sub='',face='white',color=INK,size=13):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.02,rounding_size=0.11',facecolor=face,edgecolor=LINE,lw=1.3))
    ax.text(x+w/2,y+h*.62,title,ha='center',va='center',fontsize=size,color=color,fontweight='bold')
    if sub:ax.text(x+w/2,y+h*.27,sub,ha='center',va='center',fontsize=size-2,color=MUTED,linespacing=1.5)


def arrow(ax,a,b,color=INK,style='-',rad=0):
    ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=14,lw=1.5,color=color,linestyle=style,connectionstyle=f'arc3,rad={rad}'))


def concept():
    fig=plt.figure(figsize=(13.6,8.1),facecolor=PAPER)
    ax=fig.add_axes([.025,.035,.95,.94]);ax.set_xlim(0,13);ax.set_ylim(0,8);ax.axis('off')
    ax.text(.25,7.65,'RIPPLE NEURON',fontsize=29,fontweight='bold',color=INK)
    ax.text(.25,7.15,'A free color-coded optoelectronic neuron prototype',fontsize=17,color=MUTED)
    ax.text(12.6,7.15,'Concept: Constantin x',ha='right',fontsize=10,color=MUTED)
    ax.text(12.6,7.65,'OPEN / v0.1',ha='right',fontsize=12,color=GREEN,fontweight='bold')
    ax.text(.25,6.65,'Color carries the input. Feedback regulates the response.',fontsize=15,color=INK)
    rounded(ax,.25,4.50,2.8,1.45,'RGB light','Three input intensities')
    for x,c in [(1.22,RED),(1.62,GREEN),(2.02,BLUE)]:ax.add_patch(Circle((x,5.63),.065,color=c))
    rounded(ax,4.05,4.50,3.25,1.45,'AS7341 breakout','Eight measured spectral bands')
    rounded(ax,8.55,4.50,3.45,1.45,'Pico + neuron model','Weighted accumulation / events')
    arrow(ax,(3.07,5.20),(4.02,5.20));arrow(ax,(7.32,5.20),(8.52,5.20))
    ax.text(3.53,5.57,'light',ha='center',fontsize=11,color=MUTED)
    ax.text(7.93,5.57,'I2C',ha='center',fontsize=11,color=MUTED)
    rounded(ax,8.55,2.25,3.45,1.25,'Model event stream','USB serial records the events')
    rounded(ax,4.05,2.25,3.25,1.25,'Internal rate feedback','Adjust bounded threshold',face='#eaf2ee',color=GREEN)
    arrow(ax,(10.27,4.46),(10.27,3.53));arrow(ax,(8.52,2.88),(7.32,2.88),GREEN)
    arrow(ax,(5.68,3.53),(8.58,4.70),GREEN,rad=-.14)
    ax.text(.35,3.45,'D = 2.0R + 1.2G - 1.4B',fontsize=14,color=INK)
    ax.text(.35,2.90,'Integrate. Fire. Reset. Regulate.',fontsize=12,color=MUTED)
    ax.text(.35,2.25,'Color roles are assigned by the design.',fontsize=10,color=MUTED)
    ax.plot([.25,12.5],[1.55,1.55],color=LINE,lw=1.5)
    ax.text(.25,1.05,'SIMULATION RESULT',fontsize=11,fontweight='bold',color=GREEN)
    ax.text(.25,.59,'Final 20 s after input doubled: 0.95 events/s with feedback; 3.40 without.',fontsize=14,color=INK)
    ax.text(.25,.16,'Target: 1.00 events/s. Physical hardware has not been tested. Original materials: CC0-1.0.',fontsize=10,color=MUTED)
    fig.savefig(OUT/'Ripple-Neuron-Prototype.png',dpi=160,facecolor=fig.get_facecolor())
    fig.savefig(PKG/'Ripple-Neuron-Prototype.svg',facecolor=fig.get_facecolor())
    plt.close(fig)


def wiring():
    fig=plt.figure(figsize=(14,8.6),facecolor='white');ax=fig.add_axes([.025,.04,.95,.92]);ax.set_xlim(0,14);ax.set_ylim(0,8.8);ax.axis('off')
    ax.text(.1,8.38,'Ripple bench wiring',fontsize=24,fontweight='bold',color=INK)
    ax.text(.1,7.92,'Original Pico/Pico H + Adafruit AS7341 breakout + common-anode RGB LED',fontsize=12,color=MUTED)
    rounded(ax,.15,3.55,3.0,3.35,'',face='#f4f6f4');rounded(ax,4.60,3.55,2.65,3.35,'',face='#f4f6f4')
    ax.text(1.65,6.64,'Pico U1',fontsize=14,ha='center',color=INK,fontweight='bold')
    ax.text(5.93,6.64,'AS7341 U2',fontsize=14,ha='center',color=INK,fontweight='bold')
    for y,left,right in [(6.08,'3V3(OUT) / pin 36','VIN'),(5.52,'GP0 / pin 1','SDA'),(4.96,'GP1 / pin 2','SCL'),(4.40,'GND / pin 38','GND')]:
        ax.text(.40,y,left,fontsize=11,color=INK,va='center');ax.text(4.82,y,right,fontsize=11,color=INK,va='center');ax.plot([3.15,4.60],[y,y],color=GREEN if '3V3' in left else INK,lw=1.8)
    ax.text(.25,3.04,'Breakout VIN uses 3.3 V. Bare IC wiring differs.',fontsize=10,color=MUTED)
    ax.text(.25,2.53,'GPIO base-drive map:',fontsize=12,fontweight='bold',color=INK)
    for y,label,c in [(2.02,'GP14 / pin 19  ->  RED',RED),(1.60,'GP15 / pin 20  ->  GREEN',GREEN),(1.18,'GP16 / pin 21  ->  BLUE',BLUE)]:ax.text(.25,y,label,fontsize=12,color=c)
    ax.text(.25,.61,'GP25 onboard LED: activity indicator only.',fontsize=10,color=MUTED)
    ax.plot([7.62,7.62],[.50,7.5],color=LINE,lw=1)
    ax.text(8.03,7.44,'One LED branch - repeat for each color',fontsize=12,fontweight='bold',color=INK)
    x=12.1
    ax.plot([x,x],[6.94,6.52],color=INK,lw=1.6)
    ax.add_patch(Circle((x,6.95),.055,color=INK));ax.text(11.9,7.04,'VBUS / Pico pin 40',fontsize=11,color=INK,ha='right')
    ax.text(12.32,6.80,'USB +5 V',fontsize=10,color=MUTED)
    ax.add_patch(Rectangle((x-.58,5.77),1.16,.75,fill=False,edgecolor=INK,lw=1.6))
    ax.text(x,6.13,'RGB LED\nselected die',fontsize=10,color=INK,ha='center',va='center')
    ax.text(12.76,6.42,'anode',fontsize=10,color=MUTED);ax.text(12.76,5.90,'cathode',fontsize=10,color=MUTED)
    ax.plot([x,x],[5.77,5.29],color=INK,lw=1.6)
    ax.add_patch(Rectangle((x-.19,4.69),.38,.60,fill=False,edgecolor=INK,lw=1.6));ax.text(12.50,4.94,'1 kohm',fontsize=11,color=INK,va='center')
    ax.plot([x,x],[4.69,4.16],color=INK,lw=1.6)
    ax.add_patch(Circle((11.75,3.65),.62,fill=False,edgecolor=INK,lw=1.3))
    ax.plot([11.47,11.47],[3.28,4.0],color=INK,lw=2)
    ax.plot([11.47,x],[3.94,4.16],color=INK,lw=1.6)
    arrow(ax,(11.47,3.38),(x,3.12),INK)
    ax.text(12.52,3.75,'Q1/2/3\n2N3904',fontsize=11,color=INK,va='center')
    ax.text(12.40,4.26,'C',fontsize=10,color=INK);ax.text(12.40,3.03,'E',fontsize=10,color=INK);ax.text(11.08,3.90,'B',fontsize=10,color=INK)
    ax.plot([8.15,8.80],[3.65,3.65],color=INK,lw=1.6)
    ax.add_patch(Rectangle((8.80,3.45),.93,.40,fill=False,edgecolor=INK,lw=1.6));ax.text(9.27,4.02,'2.2 kohm',fontsize=11,color=INK,ha='center')
    ax.plot([9.73,11.47],[3.65,3.65],color=INK,lw=1.6);ax.text(8.02,3.08,'Pico GPn',fontsize=10,color=INK)
    ax.add_patch(Circle((10.35,3.65),.055,color=INK));ax.plot([10.35,10.35],[3.65,2.82],color=INK,lw=1.6)
    ax.add_patch(Rectangle((10.16,2.15),.38,.67,fill=False,edgecolor=INK,lw=1.6));ax.text(9.85,2.48,'100 kohm\npull-down',fontsize=10,color=INK,ha='right',va='center')
    ax.plot([10.35,10.35,x,x],[2.15,1.42,1.42,3.12],color=INK,lw=1.6)
    ax.add_patch(Circle((x,1.42),.055,color=INK))
    for i,w in enumerate([.70,.48,.26]):ax.plot([x-w/2,x+w/2],[1.26-i*.12,1.26-i*.12],color=INK,lw=1.6)
    ax.text(x,.66,'GND shared with Pico and sensor',fontsize=10,color=MUTED,ha='center')
    ax.text(8.02,.16,'Use functional LED/Q leads from the selected vendor datasheets.',fontsize=9,color=MUTED)
    fig.savefig(PKG/'Ripple-Neuron-Wiring.svg',facecolor='white');fig.savefig(PKG/'Ripple-Neuron-Wiring.png',dpi=160,facecolor='white');plt.close(fig)


def results_plot():
    from sys import path
    path.insert(0,str(PKG));from simulate import experiment
    rows,events,s=experiment();t=np.array([r['time_s'] for r in rows])
    fig,axes=plt.subplots(3,1,figsize=(10,6.8),sharex=True,gridspec_kw={'height_ratios':[.75,1.3,1]},facecolor='white')
    axes[0].plot(t,[r['red_norm'] for r in rows],color=RED,lw=2);axes[0].set_ylabel('Red input\nnormalized');axes[0].set_ylim(0,.85)
    axes[1].plot(t,[r['rate_adaptive_hz'] for r in rows],color=GREEN,lw=1.7,label='Adaptive threshold')
    axes[1].plot(t,[r['rate_fixed_hz'] for r in rows],color=RED,lw=1.7,label='Fixed threshold')
    axes[1].axhline(1,color='#9aa79f',ls='--',lw=1,label='1.0 Hz target');axes[1].set_ylabel('Estimated rate\nevents / second');axes[1].set_ylim(0,4);axes[1].legend(loc='upper left',fontsize=9,frameon=False,ncol=3)
    axes[2].plot(t,[r['theta_adaptive'] for r in rows],color=BLUE,lw=1.7,label='Adaptive threshold');axes[2].axhline(.45,color='#9aa79f',ls='--',lw=1);axes[2].set_ylabel('Threshold\nnormalized');axes[2].set_ylim(0,1.5);axes[2].set_xlabel('Model time / seconds')
    for ax in axes:
        for at in [40,80]:ax.axvline(at,color=LINE,ls=':',lw=1)
        ax.grid(axis='y',color='#edf0ed',lw=.6);ax.set_xlim(0,120);ax.tick_params(labelsize=9);ax.spines['left'].set_color(LINE);ax.spines['bottom'].set_color(LINE)
    fig.suptitle('Brightness-step test | Numerical simulation, not hardware data',x=.1,ha='left',fontsize=14,fontweight='bold',color=INK)
    fig.tight_layout(rect=[0,0,1,.96]);fig.savefig(PKG/'results/brightness-step.png',dpi=180);fig.savefig(PKG/'results/brightness-step.svg');plt.close(fig)


for name,file in [('Body','DejaVuSans.ttf'),('BodyBold','DejaVuSans-Bold.ttf'),('Mono','DejaVuSansMono.ttf')]:
    pdfmetrics.registerFont(TTFont(name,'/usr/share/fonts/truetype/dejavu/'+file))
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='BodyA',fontName='Body',fontSize=9.8,leading=14.5,spaceAfter=7,textColor=colors.HexColor(INK)))
styles.add(ParagraphStyle(name='SmallA',parent=styles['BodyA'],fontSize=8.1,leading=11.5,textColor=colors.HexColor(MUTED),spaceAfter=5))
styles.add(ParagraphStyle(name='TitleA',fontName='BodyBold',fontSize=31,leading=35,spaceAfter=14,textColor=colors.HexColor(INK)))
styles.add(ParagraphStyle(name='H1A',fontName='BodyBold',fontSize=20,leading=25,spaceAfter=12,textColor=colors.HexColor(INK)))
styles.add(ParagraphStyle(name='H2A',fontName='BodyBold',fontSize=12,leading=16,spaceBefore=9,spaceAfter=7,textColor=colors.HexColor(GREEN)))
styles.add(ParagraphStyle(name='CodeA',fontName='Mono',fontSize=8.7,leading=13.2,textColor=colors.HexColor(INK),backColor=colors.HexColor('#f4f6f4'),borderPadding=10,spaceAfter=12))

story=[]
def p(text,style='BodyA'):story.append(Paragraph(text,styles[style]))
def h(text):p(text,'H2A')
def title(text):p(text,'H1A')
def table(rows,widths):
    cells=[[Paragraph(str(c),styles['SmallA']) for c in row] for row in rows]
    t=Table(cells,colWidths=widths,hAlign='LEFT',repeatRows=1)
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#eaf2ee')),('VALIGN',(0,0),(-1,-1),'TOP'),('LINEBELOW',(0,0),(-1,-1),.5,colors.HexColor(LINE)),('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),5)]));story.append(t);story.append(Spacer(1,9))
def image_file(path,w,hgt):story.append(Image(str(path),width=w,height=hgt));story.append(Spacer(1,9))
def new():story.append(PageBreak())


def pdf():
    p('OPEN ENGINEERING / VERSION 0.1 / 13 OCTOBER 2026','SmallA')
    p('Ripple Neuron','TitleA')
    p('Color carries the input. Feedback regulates the response.','H2A')
    p('A freely reusable color-coded optoelectronic neuron demonstrator, prepared so the next builder can carry the idea forward.')
    image_file(OUT/'Ripple-Neuron-Prototype.png',503,300)
    h('The invention proposal, made concrete')
    p('Three colors encode separate input channels. A real spectral sensor measures them. A small processor accumulates weighted inputs, emits neuron-like events, and adjusts its firing threshold toward a target activity level.')
    p('<b>What exists now:</b> a reproducible Python model, an offline interactive simulator, a sourced bench circuit, draft CircuitPython firmware and proposed acceptance tests.')
    p('<b>Evidence boundary:</b> numerical tests have run. Physical hardware has not been assembled or measured. This is one signal-processing building block; task learning and a robot demonstration are future work.')
    p('Concept contribution: <b>Constantin x</b>. Engineering prepared with AI assistance. Original documents, drawings, code and synthetic data: <b>CC0-1.0</b>.','SmallA')
    new();title('1 / A code carried by colored light')
    p('Color is a channel identifier; intensity carries its value; pulse timing can carry events. The channel roles are assigned by the design. They are not inherent meanings of red, green or blue.')
    table([['Channel','Assigned weight','Effect'],['Red','+2.0','Excitatory input'],['Green','+1.2','A second excitatory input'],['Blue','-1.4','Inhibitory input']],[120,120,263])
    h('A defined neuron model')
    story.append(Preformatted('D = 2.0*x_R + 1.2*x_G - 1.4*x_B\ntau_v * du/dt = -u + D\nEvent at u >= theta: reset u=0, hold for t_ref\nu(t+h) = D + [u(t)-D]*exp(-h/tau_v)',styles['CodeA']))
    p('u and theta are normalized states, not measured optical fields or biological voltages. The exact constant-input solution locates crossings within each sample. Below-zero states are floored at zero. The leaky integrate-and-fire construction follows established neuron-model mathematics [S9].')
    h('Feedback with bounded sensitivity')
    story.append(Preformatted('Rate decays between events with time constant tau_r\nAt an event: r_hat <- r_hat + 1/tau_r\ndtheta/dt = eta*(r_hat - r_target)\n0.15 <= theta <= 2.5',styles['CodeA']))
    p('Excess activity raises theta; reduced activity lowers it. Threshold updates happen at sample boundaries. Bounds keep sensitivity finite when a target is unattainable. Darkness still produces no spontaneous events because theta is positive and there is no baseline current.')
    table([['Parameter','Value'],['State decay / rate-estimate decay','0.5 s / 5.0 s'],['Refractory time / target','0.1 s / 1.0 event per second'],['Initial threshold / adaptation gain','0.45 / 0.08'],['Desktop model step','0.05 s']],[260,243])
    p('For constant D&gt;theta: f=1/[t_ref+tau_v*ln(D/(D-theta))]. The target equilibrium theta*=D*[1-exp(-(1/f_target-t_ref)/tau_v)]. At the test drives D=0.70 and 1.40, theta*=0.5843 and 1.1686, within the permitted bounds. This is a feasible target calculation, not a guarantee for every changing input.','SmallA')
    new();title('2 / A catalogued bench circuit')
    image_file(PKG/'Ripple-Neuron-Wiring.png',503,309)
    table([['Pico connection','Physical pin','Destination'],['3V3(OUT)','36','AS7341 breakout VIN'],['GND','38','Sensor + common ground'],['GP0 / GP1','1 / 2','Sensor SDA / SCL'],['VBUS','40','RGB common anode'],['GP14 / GP15 / GP16','19 / 20 / 21','2.2 kohm -> R/G/B transistor bases']],[155,95,253])
    p('Each LED cathode connects through its own 1 kohm resistor to a transistor collector. Each emitter goes to ground, with 100 kohm from base to emitter. Use the specified vendor lead diagrams; functional labels above do not establish another part vendor\'s lead orientation [S3-S5].')
    p('At USB voltage <=5.25 V, a 1 kohm branch resistor limits current to <=5.25 mA even ignoring other voltage drops. Its worst-case dissipation is 27.6 mW. Estimated base drive at V_BE=0.75 V is (3.3-0.75)/2200 = 1.16 mA. These are design calculations, not measurements.')
    p('Use the Adafruit breakout rather than the bare sensor IC. The breakout receives Pico 3.3 V. Keep the activity LED outside the optical chamber. No motor is attached in this prototype.','SmallA')
    new();title('3 / Calibration makes the colors usable')
    p('A sensor channel overlaps neighboring wavelengths and responds differently to each LED. A fixed optical chamber, dark subtraction and independently measured color references turn those responses into usable relative input values.')
    h('Measured references, not assumed identities')
    story.append(Preformatted('z-d = M*x + error\nx_hat = (M^T*M)^(-1)*M^T*(z-d)',styles['CodeA']))
    p('z is the eight-band count vector; d is the dark reference; M contains the red, green and blue reference responses. The inverse is used only when the signals are strong enough and the reference matrix is well conditioned. x=1 means the measured reference output, not an absolute watt, lux or field strength.')
    table([['Sensor/decoder setting','v0.1 choice'],['ATIME / ASTEP / gain','0 / 3599 / 16x'],['Integration per bank','10.008 ms; two sequential banks + overhead'],['Digital full scale / minimum headroom','3600 counts / 10%'],['Reference emitter duty / PWM','60% / commanded 5 kHz'],['Frames per reference / settling','12 / 250 ms'],['Reference signal criterion','>=50 counts above dark in one band/color'],['Mixture check','0.5 +/-0.10 per channel; residual <=0.10']],[245,258])
    p('The integration/full-scale formula and per-bank saturation flags come from the AS7341 datasheet [S2]. The quality criteria are implementation choices. The adapter retains the ASTATUS byte from both banks; saturated data is rejected before inversion. Eight bands are not sampled simultaneously.')
    h('Firmware and capture procedure')
    p('Install CircuitPython for the original Pico and matching Adafruit AS7341, BusDevice and Register libraries. Copy ripple_core.py, optical_sensor.py, frame_capture.py and code.py to the CIRCUITPY root. Capture actual calibration and serial frames. Run once with ADAPTIVE=True and again with False. Full instructions are in BUILD.md [S6,S7].')
    p('The isolated adapter uses verified private driver internals because the public convenience method omits per-bank status. Check compatibility with the installed driver. Measured elapsed time is used; a gap over 0.5 s stops processing. Firmware has only been syntax-checked here.','SmallA')
    new();title('4 / What the numerical experiment shows')
    p('Identical red inputs drive an adaptive and a fixed-threshold neuron for 120 s. Brightness doubles at 40 s and returns at 80 s. Green and blue are zero. The target remains 1.0 event/s.')
    image_file(PKG/'results/brightness-step.png',503,342)
    table([['Final 20 s window','Adaptive','Fixed','Target'],['20-40 s','1.00 Hz','1.65 Hz','1.00 Hz'],['60-80 s','0.95 Hz','3.40 Hz','1.00 Hz'],['100-120 s','1.00 Hz','1.65 Hz','1.00 Hz']],[170,110,110,113])
    p('Table rates count model events; plotted rates use a 5 s exponential estimate. The threshold remained between 0.3226 and 1.2486 in this trajectory. Results are reproducible from supplied Python/JavaScript and CSV files.')
    p('Fourteen Python behavioral checks pass. Additional sample-step checks (10-200 ms) and five decoded-input noise trials give 0.95-1.05 Hz in these final windows. Those are synthetic tests, not a measured sensor-noise model or proof of universal stability. Physical hardware and browser rendering remain unverified in this release.','SmallA')
    new();title('5 / Let the next worker carry the ripple')
    h('The first useful contribution is a physical replication')
    table([['Check','Proposed evidence/gate'],['Electrical integrity','Record measured rails, branch currents and exact part identifiers.'],['Valid optical decoding','Preserve raw bands/status and references; test unseen mixtures. Require <=0.10 absolute channel error/residual.'],['Timing','Log actual frame times; no gaps over 0.5 s. Capture PWM frequency where possible.'],['Regulation','Final 20 s windows within 1.0 +/-0.15 model events/s under the specified profile.'],['Silence and inhibition','Record darkness and blue-suppression tests separately.']],[155,348])
    p('No hardware criterion has been marked passed. Publish complete records, including failed trials. Replaying measured inputs through the desktop model helps separate decoding, timing and control problems.')
    h('Practical expansion sequence')
    p('First replicate one node. Then add a second node with a defined event transport interface. Next choose one observable robotic task, add a suitable motor controller, and verify the complete loop. Task-specific weight learning and a comparison with an electronic baseline should follow an explicit task. Integrated all-optical hardware is a separate fabrication project.')
    h('An invitation you can share')
    p('I am sharing Ripple Neuron freely so someone else can build on it. The package includes a real component proposal, wiring, equations, source code and reproducible numerical results. The physical module still needs testing. Build it, change it, teach with it, or use it in your own work. Let the idea reach the worker who can carry the next ripple.')
    p('Suggested handoff: send this PDF and the complete ZIP; the HTML simulator runs offline. No public posting or person-directed messages were performed by preparing these files.','SmallA')
    h('Free reuse with a clear scope')
    p('Original materials are released under CC0-1.0. Copy, adapt, distribute or commercially reuse them; credit is welcome but is not required by CC0. Third-party dependencies retain their own terms. CC0 does not establish patent clearance or novelty [S10]. The release makes no first-in-the-world claim.')
    new();title('6 / Sources and reproducibility')
    p('Primary component/API references checked on 2026-10-13. These support the hardware choices and established mathematics; they are not evidence that the assembled Ripple proposal has been physically tested.','SmallA')
    sources=[('S1 Sensor breakout/catalog','https://www.adafruit.com/product/4698'),('S2 AS7341 datasheet; timing/full scale and saturation','https://look.ams-osram.com/m/24266a3e584de4db/original/AS7341-DS000504.pdf'),('S3 Original Pico pin map','https://datasheets.raspberrypi.com/pico/Pico-R3-A4-Pinout.pdf'),('S4 Common-anode RGB LED','https://www.adafruit.com/product/159'),('S5 onsemi 2N3904 datasheet','https://www.onsemi.com/pdf/datasheet/2n3904-d.pdf'),('S6 Adafruit sensor installation and API','https://learn.adafruit.com/adafruit-as7341-10-channel-light-color-sensor-breakout/python-circuitpython'),('S6a Actual bank/status driver implementation','https://github.com/adafruit/Adafruit_CircuitPython_AS7341/blob/main/adafruit_as7341.py'),('S7 CircuitPython for original Pico','https://circuitpython.org/board/raspberry_pi_pico/'),('S8 Electromagnetic intensity/E-B relations','https://openstax.org/books/college-physics-2e/pages/24-4-energy-in-electromagnetic-waves'),('S9 EPFL Neuronal Dynamics, LIF models','https://neuronaldynamics.epfl.ch/online/Ch1.S3.html'),('S10 CC0-1.0 unmodified legal code','https://creativecommons.org/publicdomain/zero/1.0/legalcode.en'),('R1 Existing all-optical spiking networks (2019)','https://www.nature.com/articles/s41586-019-1157-8'),('R2 Existing wavelength-encoded inference (2026)','https://www.nature.com/articles/s41467-026-75808-w')]
    for label,url in sources:p('<b>'+label+'</b><br/><link href="'+url+'" color="#176c83">'+url+'</link>','SmallA')
    h('Reproduce the numerical evidence')
    story.append(Preformatted('python3 simulate.py --out results\npython3 robustness.py\npython3 -m unittest discover -s tests -v\nnode tests/check_model.cjs',styles['CodeA']))
    p('Required model checks need Python standard library and Node.js only. The optional Playwright browser test requires an installed Chromium browser; it was not run successfully in this environment. The CircuitPython files are hardware-targeted draft firmware, not a measured physical prototype.','SmallA')
    def foot(canvas,doc):
        canvas.saveState();canvas.setStrokeColor(colors.HexColor(LINE));canvas.line(46,43,549,43);canvas.setFont('Body',7.5);canvas.setFillColor(colors.HexColor(MUTED));canvas.drawString(46,29,'Ripple Neuron / Open engineering v0.1 / Numerical prototype + untested bench design');canvas.drawRightString(549,29,str(doc.page));canvas.restoreState()
    doc=SimpleDocTemplate(str(OUT/'Ripple-Neuron-Engineering-Brief.pdf'),pagesize=(595.28,841.89),rightMargin=46,leftMargin=46,topMargin=45,bottomMargin=57,title='Ripple Neuron - Open Engineering Prototype v0.1',author='Constantin x; engineering prepared with AI assistance')
    doc.build(story,onFirstPage=foot,onLaterPages=foot)
    shutil.copy2(OUT/'Ripple-Neuron-Engineering-Brief.pdf',PKG/'Ripple-Neuron-Engineering-Brief.pdf')
    shutil.copy2(OUT/'Ripple-Neuron-Prototype.png',PKG/'Ripple-Neuron-Prototype.png')


concept();wiring();results_plot();pdf()
print('Created prototype visual, wiring SVG/PNG, result plot and engineering PDF.')
