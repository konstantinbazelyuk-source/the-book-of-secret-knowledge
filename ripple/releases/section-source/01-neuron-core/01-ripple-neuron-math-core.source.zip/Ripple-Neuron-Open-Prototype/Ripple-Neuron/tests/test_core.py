"""Tests catch broken physics/control contracts, not textual choices."""
import math
import unittest

try:
    from ripple_core import Neuron, make_decoder, decode_light, check_frame
except ImportError:
    Neuron = make_decoder = decode_light = check_frame = None


class NeuronTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(Neuron, "The neuron model has not been implemented")

    def test_exponential_leak_matches_analytic_solution(self):
        n = Neuron(theta=2.0, adaptive=False)
        n.step([0.2, 0, 0], 0.25)
        # D=0.4, tau=0.5, u(0)=0 => 0.4*(1-exp(-0.5)).
        self.assertAlmostEqual(n.u, 0.15738773611494664, places=12)

    def test_first_spike_matches_independent_analytic_time(self):
        n = Neuron(theta=0.45, adaptive=False)
        r = n.step([0.6, 0, 0], 0.3)
        self.assertEqual(r["count"], 1)
        self.assertAlmostEqual(r["events"][0], 0.2350018146228678, places=10)

    def test_long_run_rate_matches_closed_form(self):
        n = Neuron(theta=0.45, adaptive=False)
        events = []
        for _ in range(1200):
            r = n.step([0.6, 0, 0], 0.05)
            events.extend(r["events"])
        expected = 1.0 / (0.1 + 0.5 * math.log(1.2 / 0.75))
        self.assertLess(abs(len(events)/60.0 - expected), 0.02)
        self.assertTrue(all(b-a >= 0.1-1e-10 for a,b in zip(events,events[1:])))

    def test_darkness_produces_no_spontaneous_spikes(self):
        n = Neuron()
        for _ in range(2000):
            self.assertEqual(n.step([0,0,0],0.05)["count"],0)
        self.assertGreaterEqual(n.theta,0.15)

    def test_inhibitory_channel_can_suppress_excitation(self):
        a,b = Neuron(adaptive=False),Neuron(adaptive=False)
        ca=cb=0
        for _ in range(400):
            ca += a.step([0.6,0,0],0.05)["count"]
            cb += b.step([0.6,0,0.7],0.05)["count"]
        self.assertGreater(ca,20)
        self.assertEqual(cb,0)

    def test_feedback_returns_rate_after_brightness_steps(self):
        n = Neuron()
        windows=[0,0,0]
        for i in range(2400):
            t=i*0.05
            x=[0.35 if t<40 or t>=80 else 0.7,0,0]
            r=n.step(x,0.05)
            self.assertTrue(0.15<=n.theta<=2.5)
            for e in r["events"]:
                phase=int(e//40)
                if phase<3 and e-40*phase>=20:
                    windows[phase]+=1
        for count in windows:
            self.assertLessEqual(abs(count/20.0-1.0),0.15)

    def test_rejects_nonfinite_or_bad_time_before_state_changes(self):
        n=Neuron()
        for x,dt in [([float('nan'),0,0],0.1),([1,0,0],0),([1,0,0],float('inf')),([1,0,0],0.6)]:
            with self.assertRaises(ValueError):n.step(x,dt)
        self.assertEqual(n.t,0)


class CalibrationTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(make_decoder,"The optical decoder has not been implemented")
        # Synthetic counts, deliberately overlapping bands; not hardware measurements.
        self.dark=[5]*8
        self.columns=[[1,1,2,5,15,80,1000,700],[1,2,15,700,1000,50,5,2],[300,1000,600,20,4,1,1,1]]

    def test_recovers_mixed_channels_despite_spectral_overlap(self):
        cal=make_decoder(self.dark,self.columns)
        raw=[5+sum(self.columns[j][i]*[0.25,0.5,0.75][j] for j in range(3)) for i in range(8)]
        result=decode_light(raw,cal)
        for got,want in zip(result["x"],[0.25,0.5,0.75]):self.assertAlmostEqual(got,want,places=5)
        self.assertLess(result["residual"],1e-4)

    def test_rank_deficient_colors_are_rejected(self):
        with self.assertRaises(ValueError):make_decoder(self.dark,[self.columns[0]]*3)

    def test_weak_calibration_is_rejected(self):
        with self.assertRaises(ValueError):make_decoder(self.dark,[[1]*8,[2]*8,[3]*8])

    def test_outside_calibration_range_is_reported(self):
        cal=make_decoder(self.dark,self.columns)
        raw=[5+self.columns[0][i]*1.4 for i in range(8)]
        r=decode_light(raw,cal)
        self.assertTrue(r["out_of_range"])
        self.assertEqual(r["x"][0],1.0)

    def test_digital_or_analog_saturation_is_rejected(self):
        self.assertIsNotNone(check_frame)
        for low,high in [((128,1,2,3,4,5,6),(0,1,2,3,4,5,6)),((0,1,2,3,4,5,6),(128,1,2,3,4,5,6)),((0,3600,2,3,4,5,6),(0,1,2,3,4,5,6))]:
            with self.assertRaises(ValueError):check_frame(low,high,3600)
        self.assertEqual(check_frame((0,1,2,3,4,5,6),(0,7,8,9,10,11,12),3600),[1,2,3,4,7,8,9,10])


if __name__ == '__main__':unittest.main()
