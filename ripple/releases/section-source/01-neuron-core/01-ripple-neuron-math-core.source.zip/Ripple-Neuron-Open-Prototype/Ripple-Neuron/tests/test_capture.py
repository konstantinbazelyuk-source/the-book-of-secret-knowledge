import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'firmware'))
try:
    from frame_capture import capture_record
except ImportError:
    capture_record=None

class CaptureTests(unittest.TestCase):
    def test_failed_frame_preserves_raw_status_and_reason(self):
        self.assertIsNotNone(capture_record,'Saturation evidence must be captured before rejection')
        r=capture_record((128,1,2,3,4,5,6),(0,7,8,9,10,11,12),3600)
        self.assertFalse(r['valid'])
        self.assertEqual(r['bank_low'][0],128)
        self.assertEqual(r['raw_counts'],[1,2,3,4,7,8,9,10])
        self.assertIn('saturation',r['error'])

    def test_valid_frame_preserves_complete_banks(self):
        self.assertIsNotNone(capture_record,'Raw evidence capture must exist')
        r=capture_record((4,10,20,30,40,50,60),(4,70,80,90,100,110,120),3600)
        self.assertTrue(r['valid'])
        self.assertEqual(r['bank_high'],[4,70,80,90,100,110,120])
        self.assertEqual(r['raw_counts'],[10,20,30,40,70,80,90,100])

if __name__=='__main__':unittest.main()
