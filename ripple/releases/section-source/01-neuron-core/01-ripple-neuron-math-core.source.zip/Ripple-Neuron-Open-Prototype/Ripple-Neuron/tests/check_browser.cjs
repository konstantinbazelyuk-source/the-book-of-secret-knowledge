// Tests execute the browser and compare the model to independent fixtures.
// CC0-1.0. Set NODE_PATH to your Playwright installation if needed.
const assert=require('node:assert/strict');
const path=require('node:path');
const fs=require('node:fs');
const { chromium }=require('playwright');
(async()=>{
  const browser=await chromium.launch({headless:true,executablePath:chromium.executablePath(),args:['--no-sandbox']});
  const page=await browser.newPage({viewport:{width:1280,height:940},deviceScaleFactor:1});
  const errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto('file://'+path.resolve(__dirname,'../Ripple-Neuron-Simulator.html'));
  assert.equal(await page.title(),'Ripple Neuron | Open engineering prototype');
  assert.equal(await page.evaluate(()=>typeof RippleNeuron),'function','Browser neuron model must exist');
  const model=await page.evaluate(()=>{
    const n=new RippleNeuron({theta:0.45,adaptive:false});
    return n.step([0.6,0,0],0.3);
  });
  assert.equal(model.count,1);
  assert.ok(Math.abs(model.events[0]-0.2350018146228678)<1e-10);
  const experiment=await page.evaluate(()=>runExperiment());
  assert.deepEqual(experiment.windows.map(w=>w.adaptive_hz),[1,0.95,1]);
  assert.deepEqual(experiment.windows.map(w=>w.fixed_hz),[1.65,3.4,1.65]);
  await page.getByRole('button',{name:'Run brightness-step experiment'}).click();
  await page.waitForFunction(()=>window.experimentData&&window.experimentData.rows.length===2400);
  assert.ok((await page.locator('#experiment-results').innerText()).includes('0.95'));
  await page.evaluate(()=>{for(const[id,value]of [['red','0'],['green','0'],['blue','1']]){const e=document.getElementById(id);e.value=value;e.dispatchEvent(new Event('input'));}});
  await page.locator('#reset').click();
  await page.waitForTimeout(150);
  assert.ok((await page.locator('#reachability').innerText()).includes('unreachable'));
  fs.mkdirSync(path.resolve(__dirname,'../../qa'),{recursive:true});
  await page.screenshot({path:path.resolve(__dirname,'../../qa/simulator-desktop.png'),fullPage:true});
  await page.setViewportSize({width:390,height:844});
  await page.screenshot({path:path.resolve(__dirname,'../../qa/simulator-mobile.png'),fullPage:true});
  const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1);
  assert.equal(overflow,false,'Mobile layout must not require horizontal scrolling');
  assert.deepEqual(errors,[]);
  await browser.close();
  console.log('PASS: browser analytic timing, Python experiment parity, controls, unreachable target, desktop/mobile layout, no runtime errors');
})().catch(e=>{console.error(e);process.exit(1)});
