// Dependency-free checks of the actual JavaScript embedded in the demo.
// CC0-1.0. This validates numerical behavior, not browser DOM/layout.
const assert=require('node:assert/strict');const fs=require('node:fs');const path=require('node:path');const vm=require('node:vm');
const html=fs.readFileSync(path.resolve(__dirname,'../Ripple-Neuron-Simulator.html'),'utf8');
const script=html.match(/<script>([\s\S]*?)<\/script>/)[1];
const context={console,Math,Number};vm.createContext(context);vm.runInContext(script,context);
assert.equal(typeof context.RippleNeuron,'function','JavaScript neuron model must exist');
const n=new context.RippleNeuron({theta:0.45,adaptive:false});
const r=n.step([0.6,0,0],0.3);assert.equal(r.count,1);
assert.ok(Math.abs(r.events[0]-0.2350018146228678)<1e-10);
const result=context.runExperiment();
assert.deepEqual(Array.from(result.windows,v=>v.adaptive_hz),[1,0.95,1]);
assert.deepEqual(Array.from(result.windows,v=>v.fixed_hz),[1.65,3.4,1.65]);
assert.equal(result.rows.length,2400);
assert.throws(()=>n.step([NaN,0,0],0.1));
console.log('PASS: actual embedded JavaScript, analytic timing, Python/JS experiment parity, invalid-input rejection. DOM/layout not tested.');
