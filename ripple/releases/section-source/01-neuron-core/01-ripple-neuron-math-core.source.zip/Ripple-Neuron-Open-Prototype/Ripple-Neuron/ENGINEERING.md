# Ripple Neuron engineering specification v0.1

Preparation date: 2026-10-13. Concept contribution: Constantin x. Engineering developed with AI assistance. Original materials: CC0-1.0. Evidence level: reproducible numerical prototype and sourced hardware proposal; no physical assembly or measurements.

## Purpose and success condition

Use distinct colors as separate input channels to a neuron-like signal-processing module, and use measured output activity to regulate its sensitivity. A builder should be able to reproduce the simulation, assemble the proposed bench circuit, and test whether the output returns near its target activity after a controlled brightness change.

The v0.1 deliverable is one optoelectronic neuron with fixed input weights and an adaptive threshold. The optical link carries information, an AS7341 breakout converts spectral intensity to counts, and the microcontroller implements state, events and feedback. Robotics is a possible application after physical replication and a task-specific network/controller are added. No neural-network task training occurs in this version.

## Optical measurement boundary

A spectral sensor measures energy accumulated in finite wavelength bands during its integration interval. It does not report the instantaneous signed E(t) or B(t) waveform. Its digital counts also are not calibrated absolute irradiance units. Here, independent dark and color references establish a relative optical code.

For a monochromatic traveling plane wave in vacuum, f=c/lambda, average intensity I=(c*epsilon_0/2)E_0^2, and B_0=E_0/c. Thus frequency labels the color, while intensity determines field amplitude. The vacuum plane-wave relations must not be applied blindly to material interiors or optical near fields [S8]. The low-cost bench module uses intensity-coded input and does not attempt laboratory field-resolved metrology.

## Architecture and selected tradeoff

The selected v0.1 route is RGB LED -> eight-band spectral detector -> calibrated decoder -> microcontroller LIF model -> counted model events -> rate feedback -> firing threshold. A transistor driver lets the same board produce controlled test light. Its output LED is shielded from the sensor.

An analog RC/comparator neuron would provide another physical implementation but complicates calibration and adaptive threshold control. An integrated all-optical neuron would require specialized materials/fabrication. The documented microcontroller route lets another worker reproduce and inspect the equations with catalogued parts. Existing photonic neural networks demonstrate that wavelength-coded channels are established engineering territory [R1,R2]; no novelty claim is made for that general principle.

## Relative color decoding

Let z in R^8 be spectral counts, d the dark reference, and M an 8x3 matrix whose columns are measured red, green and blue responses above dark at a fixed reference duty. For input coefficients x in R^3:

    z - d = M x + e
    x_hat = (M^T M)^(-1) M^T (z - d)

The ordinary least-squares inverse is used only after reference signal/rank/conditioning checks. The firmware rejects saturation before decoding; it does not pretend inversion can recover clipped data. It reports an out-of-range input when an unclipped coefficient is below -0.05 or above 1.05. Small noise-induced excursions are clipped into [0,1] for the model.

The normalized residual is norm((z-d)-M*x_hat)/max(1,norm(z-d),0.02*max_column_norm). A residual above 0.10 rejects the input. This detects some ambient/spectrum/calibration changes; it does not guarantee detection of every change that projects into the color basis. Keep ambient light and geometry fixed and test independent mixtures. These assumptions are part of the bench acceptance procedure.

## Neuron equations and units

State u and threshold theta are normalized, dimensionless quantities. They are not biological membrane voltages or measured optical fields. Color meanings are programmable; the following signed weights are design choices:

    D = 2.0*x_R + 1.2*x_G - 1.4*x_B
    tau_v * du/dt = -u + D

The state is floored at zero. When u reaches theta, record a model event, reset u=0, and hold u=0 during a 0.1 s refractory interval. Between samples with fixed D and theta, the analytical solution is:

    u(t+h) = D + (u(t)-D)*exp(-h/tau_v)

The implementation solves the threshold-crossing time inside each sample instead of assigning every event to the sample endpoint. These timestamps are inferred model times under piecewise-constant input, not physical sensor or GPIO observations. Firmware applies the newest decoded value over the elapsed interval (endpoint-held reconstruction), giving frame/integration-scale uncertainty at brightness transitions. The firmware indicator shows whether a frame contains an event; USB serial event counts are the canonical prototype output. The firmware does not drive a precision spike-timed actuator.

## Homeostatic feedback

The estimated rate obeys a decaying event filter:

    tau_r * dr_hat/dt = -r_hat, between events
    r_hat <- r_hat + 1/tau_r, at an event
    dtheta/dt = eta*(r_hat - r_target)
    theta constrained to [theta_min, theta_max]

Too much activity raises the threshold; low activity lowers it. The code analytically integrates the rate-error contribution during each sample and updates theta at the sample boundary. Theta is held while solving that sample's state dynamics. The threshold limits bound sensitivity even when the target cannot be reached; darkness does not create firing because theta remains positive and the model has no baseline current.

| Parameter | v0.1 value | Interpretation |
|---|---:|---|
| tau_v | 0.5 s | State accumulation/decay time |
| tau_r | 5.0 s | Output-rate estimate decay time |
| refractory | 0.1 s | Hold after each modeled event |
| theta initial | 0.45 | Initial normalized firing threshold |
| theta bounds | 0.15 to 2.5 | Bounded sensitivity |
| r_target | 1.0 Hz | Demonstration target |
| eta | 0.08 | Threshold units per integrated event-count error |
| Desktop step | 0.05 s | Sampled threshold update interval |
| Hardware period | 0.10 s requested | Actual elapsed period is measured and used |

The LIF state/threshold/reset construction follows established neuron-model mathematics [S9]. The particular optical encoding, weights, limits and feedback constants here are a proposed implementation, not a claimed new law.

## Constant-input calculation and limits

For a constant positive drive D>theta, fixed threshold and zero reset, the ideal firing rate is:

    f(D,theta) = 1 / [t_ref + tau_v*ln(D/(D-theta))]

For D<=theta, sustained ideal firing is zero. Given a target rate below 1/t_ref, the constant-input equilibrium threshold would be:

    theta_star = D*[1-exp(-(1/f_target-t_ref)/tau_v)]

For red=0.35, D=0.70 and theta_star=0.5843. For red=0.70, D=1.40 and theta_star=1.1686. Both lie inside the allowed bounds. This explains why the demonstration target is physically meaningful in the model. The demo warns when the equivalent threshold is outside the allowed range.

In a slow, averaged constant-input approximation with inactive bounds, f'(theta)=-tau_v*f^2/(D-theta)<0. Linearizing the rate filter and threshold feedback gives tau_r*delta_theta''+delta_theta'+eta*abs(f')*delta_theta=0. Positive coefficients give local stability for this continuous averaged approximation. That calculation is not a proof of global stability of the full sampled hybrid system, noisy optics, changing geometry or future robot dynamics. Validation therefore includes explicit numerical trajectories and later hardware tests.

## Reproduced numerical evidence

The 120 s experiment changes red input from 0.35 to 0.70 at 40 s and back at 80 s. Green and blue stay zero. Event counts in the final 20 s of each phase yield:

| Window | Adaptive | Fixed threshold | Target |
|---|---:|---:|---:|
| 20-40 s | 1.00 Hz | 1.65 Hz | 1.00 Hz |
| 60-80 s | 0.95 Hz | 3.40 Hz | 1.00 Hz |
| 100-120 s | 1.00 Hz | 1.65 Hz | 1.00 Hz |

The complete traces and event timestamps are supplied. The threshold ranged from 0.3226 to 1.2486 in this trajectory. At sample intervals 0.01, 0.05, 0.10 and 0.20 s, adaptive final-window rates stayed between 0.95 and 1.05 Hz. Five additional synthetic trials with red-channel Gaussian noise sigma=0.02, seeds 0-4, also yielded 0.95-1.05 Hz in these windows. This noise is imposed after ideal decoding and is not a measured AS7341 noise distribution. See `results/robustness.json` and `robustness.py`.

Python and the actual embedded JavaScript reproduce identical event-count window rates. Fourteen Python behavioral tests cover analytic leak/crossing/rate, refractory timing, no spontaneous events, inhibition, feedback recovery, nonfinite data, rank-deficient/weak calibration, out-of-range inputs, saturation and preservation of accepted/rejected raw bank records. Firmware has passed Python syntax compilation only. Browser rendering and physical operation must still be checked by a builder; this environment did not provide an installed browser executable. The live browser model advances approximately in real time while active; frame gaps above 0.2 s are skipped rather than replayed.

## Next engineering stages

1. Replicate the physical bench circuit and publish complete raw/calibration/event records against the proposed gates in BUILD.md.
2. Add a second node and define an event transport interface; analyze latency, saturation and feedback interactions before connecting a network.
3. Define one observable robotic task, add a suitable low-voltage motor driver/controller, and verify closed-loop behavior. A neuron does not establish an intelligence result by itself.
4. If useful, add task-specific weight learning and compare it with a standard electronic baseline. An all-optical implementation would be a separate device-development project.

## Release scope

Original package materials are shared under CC0-1.0 for unrestricted copyright reuse, including commercial reuse. Third-party libraries and component documentation retain their own terms. CC0 does not establish patent clearance; no patent filing, novelty search or external public publication was performed here [S10]. The included SHARE.md is a ready-to-share invitation. This package is a concrete handoff, not evidence that other people have already received it.

## Primary sources checked 2026-10-13

- **S1 - Sensor breakout and catalog listing:** https://www.adafruit.com/product/4698
- **S2 - ams OSRAM AS7341 datasheet, DS000504 v3-00, integration/full scale section 10.2.2 and saturation/data sections 10.2.6-10.2.7:** https://look.ams-osram.com/m/24266a3e584de4db/original/AS7341-DS000504.pdf
- **S3 - Original Raspberry Pi Pico pinout:** https://datasheets.raspberrypi.com/pico/Pico-R3-A4-Pinout.pdf
- **S4 - Specified common-anode RGB LED:** https://www.adafruit.com/product/159
- **S5 - onsemi 2N3904 datasheet:** https://www.onsemi.com/pdf/datasheet/2n3904-d.pdf
- **S6 - Adafruit CircuitPython AS7341 installation/API:** https://learn.adafruit.com/adafruit-as7341-10-channel-light-color-sensor-breakout/python-circuitpython and https://docs.circuitpython.org/projects/as7341/en/latest/api.html
- **S6a - Actual driver bank/status struct and internal methods:** https://github.com/adafruit/Adafruit_CircuitPython_AS7341/blob/main/adafruit_as7341.py
- **S7 - CircuitPython original Pico board:** https://circuitpython.org/board/raspberry_pi_pico/
- **S8 - OpenStax, electromagnetic intensity and E/B relations:** https://openstax.org/books/college-physics-2e/pages/24-4-energy-in-electromagnetic-waves
- **S9 - EPFL Neuronal Dynamics, integrate-and-fire models:** https://neuronaldynamics.epfl.ch/online/Ch1.S3.html
- **S10 - CC0-1.0 full legal code:** https://creativecommons.org/publicdomain/zero/1.0/legalcode.en
- **R1 - Feldmann et al., All-optical spiking neurosynaptic networks with self-learning capabilities (2019):** https://www.nature.com/articles/s41586-019-1157-8
- **R2 - Chen et al., Wavelength-encoded neuromorphic inference enabled by microcavity MoS2 photodetector arrays (2026):** https://www.nature.com/articles/s41467-026-75808-w

Sources establish the measurement limits, catalogued components, APIs, established equations and research context. The assembled Ripple design, selected constants and reported simulation trajectories are original proposal/analysis materials; none of those are represented as external experimental results.
