"""Ripple v0.1 - dimensionless optoelectronic neuron model. CC0-1.0.

No hardware or third-party dependencies. Runs under CPython and CircuitPython.
Exact constant-drive LIF integration between sampled threshold updates.
All returned event times are model times, not observed electrical timestamps.
"""
import math


def finite(value):
    value = float(value)
    return value == value and abs(value) != float("inf")


def clamp(value, low, high):
    return min(high, max(low, value))


class Neuron:
    def __init__(self, theta=0.45, adaptive=True, target=1.0,
                 tau_v=0.5, tau_r=5.0, refractory=0.1, eta=0.08,
                 theta_min=0.15, theta_max=2.5):
        vals = (theta, target, tau_v, tau_r, refractory, eta, theta_min, theta_max)
        if not all(finite(v) for v in vals):
            raise ValueError("Model parameters must be finite")
        if tau_v <= 0 or tau_r <= 0 or refractory <= 0 or eta < 0:
            raise ValueError("Invalid time constant or adaptation gain")
        if not 0 < theta_min <= theta <= theta_max or not 0 < target < 1/refractory:
            raise ValueError("Invalid threshold or target rate")
        self.theta, self.adaptive, self.target = theta, adaptive, target
        self.tau_v, self.tau_r = tau_v, tau_r
        self.refractory, self.eta = refractory, eta
        self.theta_min, self.theta_max = theta_min, theta_max
        self.weights = (2.0, 1.2, -1.4)
        self.t, self.u, self.rate, self.rest = 0.0, 0.0, 0.0, 0.0

    def step(self, x, dt):
        if len(x) != 3 or not all(finite(v) for v in x):
            raise ValueError("Expected three finite normalized input values")
        if not finite(dt) or not 0 < dt <= 0.5:
            raise ValueError("Elapsed sample time must be 0 < dt <= 0.5 seconds")
        x = [clamp(float(v), 0.0, 1.0) for v in x]
        drive = sum(w*v for w,v in zip(self.weights,x))
        start, elapsed, events = self.t, 0.0, []
        eps = 1e-12
        while elapsed < dt-eps:
            left = dt-elapsed
            if self.rest > eps:
                held = min(left, self.rest)
                self.rest = max(0.0, self.rest-held)
                self.u = 0.0
                elapsed += held
                continue
            crossing = float("inf")
            if self.u >= self.theta:
                crossing = 0.0
            elif drive > self.theta:
                crossing = self.tau_v*math.log((drive-self.u)/(drive-self.theta))
            if crossing <= left+eps:
                elapsed += max(0.0, min(left,crossing))
                events.append(start+elapsed)
                self.u, self.rest = 0.0, self.refractory
            else:
                self.u = max(0.0, drive+(self.u-drive)*math.exp(-left/self.tau_v))
                elapsed = dt
        decay = math.exp(-dt/self.tau_r)
        old_rate = self.rate
        # Integrate the rate-estimation error over the sample exactly, using
        # event offsets. The threshold itself is held during this sample.
        integral_rate = old_rate*self.tau_r*(1-decay)
        self.rate = old_rate*decay
        for event in events:
            d = math.exp(-(start+dt-event)/self.tau_r)
            self.rate += d/self.tau_r
            integral_rate += 1-d
        if self.adaptive:
            self.theta = clamp(self.theta+self.eta*(integral_rate-self.target*dt),
                               self.theta_min,self.theta_max)
        self.t = start+dt
        return {"t":self.t,"u":self.u,"theta":self.theta,"rate":self.rate,
                "drive":drive,"count":len(events),"events":events}

    def attainable(self, drive):
        """Steady, noiseless, constant-drive target feasibility, not a guarantee."""
        if drive <= 0:
            return False
        theta_star = drive*(1-math.exp(-(1/self.target-self.refractory)/self.tau_v))
        return self.theta_min <= theta_star <= self.theta_max


def make_decoder(dark, columns):
    """8 bands x 3 colors. Ordinary least-squares calibrated spectral demixing.

    dark is the eight-band mean with LEDs off; columns are dark-subtracted
    eight-band reference responses for red, green, blue, in that order.
    """
    if len(dark)!=8 or len(columns)!=3 or any(len(c)!=8 for c in columns):
        raise ValueError("Calibration must have eight bands and three reference colors")
    if not all(finite(v) for v in dark) or not all(finite(v) for c in columns for v in c):
        raise ValueError("Calibration contains nonfinite values")
    if any(max(c)<50 for c in columns):
        raise ValueError("Reference is too weak: need >=50 counts above dark in one band per color")
    # Gram matrix and its inverse via Gauss-Jordan elimination.
    gram=[[sum(columns[i][k]*columns[j][k] for k in range(8)) for j in range(3)] for i in range(3)]
    scale=max(abs(v) for row in gram for v in row)
    a=[gram[i][:]+[float(i==j) for j in range(3)] for i in range(3)]
    for i in range(3):
        pivot=max(range(i,3),key=lambda r:abs(a[r][i]))
        if abs(a[pivot][i])<1e-10*scale:
            raise ValueError("Color references are indistinguishable or rank deficient")
        a[i],a[pivot]=a[pivot],a[i]
        factor=a[i][i]
        a[i]=[v/factor for v in a[i]]
        for j in range(3):
            if i!=j:
                factor=a[j][i]
                a[j]=[v-factor*w for v,w in zip(a[j],a[i])]
    inverse=[r[3:] for r in a]
    cond=max(sum(abs(v) for v in row) for row in gram)*max(sum(abs(v) for v in row) for row in inverse)
    if cond>1000:
        raise ValueError("Calibration is poorly conditioned; change emitter geometry or colors")
    decoder=[[sum(inverse[i][j]*columns[j][k] for j in range(3)) for k in range(8)] for i in range(3)]
    return {"dark":list(dark),"columns":[list(c) for c in columns],
            "decoder":decoder,"condition_gram_inf":cond,
            "reference_norm":max(math.sqrt(sum(v*v for v in c)) for c in columns)}


def decode_light(raw, calibration):
    if len(raw)!=8 or not all(finite(v) for v in raw):
        raise ValueError("Expected eight finite spectral counts")
    delta=[float(v)-d for v,d in zip(raw,calibration["dark"])]
    estimates=[sum(v*w for v,w in zip(row,delta)) for row in calibration["decoder"]]
    reconstructed=[sum(calibration["columns"][j][i]*estimates[j] for j in range(3)) for i in range(8)]
    denom=max(1.0,0.02*calibration["reference_norm"],math.sqrt(sum(v*v for v in delta)))
    residual=math.sqrt(sum((v-w)**2 for v,w in zip(delta,reconstructed)))/denom
    return {"x":[clamp(v,0.0,1.0) for v in estimates],"unclipped":estimates,
            "residual":residual,"out_of_range":any(v < -0.05 or v > 1.05 for v in estimates)}


def check_frame(low, high, fullscale):
    """Driver structs: (ASTATUS, ADC0..ADC5). Preserve saturation for both banks."""
    if len(low)!=7 or len(high)!=7:
        raise ValueError("AS7341 driver contract changed: expected status + six ADC values")
    if (int(low[0])|int(high[0])) & 0x80:
        raise ValueError("Sensor reported analog or digital saturation")
    if not finite(fullscale) or fullscale<=0:
        raise ValueError("Invalid ADC full scale")
    raw=list(low[1:5])+list(high[1:5])
    if not all(finite(v) and 0<=v<0.90*fullscale for v in raw):
        raise ValueError("Invalid count or less than 10 percent digital headroom")
    return raw
