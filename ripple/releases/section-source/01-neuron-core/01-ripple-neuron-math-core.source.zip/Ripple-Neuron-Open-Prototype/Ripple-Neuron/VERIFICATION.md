# Evidence record - Ripple v0.1

Prepared 2026-10-13. This record distinguishes verification performed here from work that remains for a physical builder.

## Completed checks

- `python3 -m unittest discover -s tests -v`: **14/14 pass**. The original 12 model/calibration tests were observed failing before the core was implemented. Two raw-frame preservation tests were observed failing before the capture helper was implemented, then passed with the complete suite.
- `node tests/check_model.cjs`: **pass**. Executes the actual JavaScript embedded in the offline HTML under Node's VM. First-spike timing agrees with an independent analytical value; event-window counts match the Python experiment; nonfinite inputs are rejected. The missing-model assertion was observed failing before implementation.
- `python3 -m py_compile ripple_core.py simulate.py robustness.py firmware/code.py firmware/optical_sensor.py firmware/frame_capture.py`: **pass**. This establishes Python syntax, not CircuitPython board execution or driver compatibility on a physical device.
- `python3 simulate.py --out results`: reproduced the 120-second experiment, 2400 sample rows and counted-event CSV. Adaptive final-window rates: 1.00, 0.95, 1.00 Hz. Fixed: 1.65, 3.40, 1.65 Hz.
- `python3 robustness.py`: four sample periods and five seeded synthetic decoded-input-noise trials stay within the proposed +/-0.15 Hz window criterion. The noise is illustrative Gaussian noise after decoding, not a characterized sensor noise distribution.
- PDF: generated as a seven-page A4 engineering brief, rendered to page images and visually inspected. Prototype and wiring figures were inspected separately. Editable SVGs and result plots are included.
- Read-only engineering review: the reviewer independently ran the initial 12 Python tests and JavaScript checks and checked the LIF and AS7341 source assumptions. No Critical or Important issue was found within the numerical-prototype/untested-bench-design scope. Evidence-capture omissions were then addressed with two additional failing-then-passing tests; timing reconstruction and live-demo clock limitations were documented.

## Not performed

- Physical assembly, board execution, measured optical/current/PWM tests, actual hardware rate regulation, or motor/robot tests.
- Browser DOM/rendering integration check. Playwright is present here, but no Chromium executable is installed. The optional `tests/check_browser.cjs` is supplied for a builder with Playwright and Chromium. Its numerical model is tested; the actual browser layout and controls are not claimed verified.
- Patent novelty/clearance review or external public publication. CC0 applies to the original copyright materials, not external rights.
- Proof of global stability, performance under every spectrum/ambient condition, network intelligence or task learning.

## Engineering decisions and their practical limits

- Use a catalogued spectral detector and electronic neuron state for v0.1. Consequence: this is an optoelectronic module, not direct optical E(t)/B(t) metrology or an all-optical neuron.
- Use fixed weights and threshold homeostasis. Consequence: regulating activity does not establish task-specific learning.
- Retain status-bearing records from both AS7341 banks through an isolated private-API adapter. Consequence: an installed driver that changes its internals needs an adapter update; preserve actual driver/runtime versions.
- Use the newest decoded value over the elapsed sample interval. Consequence: inferred transition/event timing has frame/integration-scale uncertainty; the indicator is not a precision physical pulse generator.
- Limit live-demo wall-clock gaps to 0.2 s. Consequence: hidden tabs or stalls skip model time; the deterministic 120 s experiment has its own fixed model clock.
- Treat all robustness results as numerical evidence only. Consequence: the proposed bench acceptance procedure is still required before claiming physical operation.

Reproduce results from the root of the unzipped package. Python checks use the standard library; the JavaScript numeric check requires Node.js. Neither model requires an AI API or subscription.
