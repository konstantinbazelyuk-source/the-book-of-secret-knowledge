"""Reproduce synthetic sample-period and decoded-input-noise checks. CC0-1.0."""
import json
import random
from pathlib import Path
from simulate import experiment
from ripple_core import Neuron

result={"evidence_type":"synthetic numerical robustness checks, not hardware measurements", "sample_intervals":[],"noisy_trials":[]}
for dt in (0.01,0.05,0.1,0.2):
    _,_,s=experiment(dt)
    result["sample_intervals"].append({"dt_s":dt,"adaptive_rates_hz":[w["adaptive_hz"] for w in s["rate_windows"]]})
for seed in range(5):
    rng=random.Random(seed)
    n=Neuron()
    events=[]
    for i in range(2400):
        t=i*0.05
        red=max(0,min(1,(0.35 if t<40 or t>=80 else 0.7)+rng.gauss(0,0.02)))
        events.extend(n.step([red,0,0],0.05)["events"])
    rates=[sum(lo<=e<lo+20 for e in events)/20 for lo in (20,60,100)]
    assert all(abs(rate-1)<=0.15 for rate in rates)
    result["noisy_trials"].append({"seed":seed,"decoded_red_noise_sigma":0.02,"adaptive_rates_hz":rates})
Path("results").mkdir(exist_ok=True)
Path("results/robustness.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))
