# Ripple Neuron - open optoelectronic prototype v0.1

Color carries the input. Feedback regulates the response.

Concept contribution: **Constantin x**. Engineering specification, source and numerical experiments prepared with AI assistance on **2026-10-13**.

This package turns a color-coded light-neuron idea into a reproducible numerical demonstrator and a documented bench-build proposal. It is shared freely so another builder can improve it. The physical board has not been assembled or tested in this work.

## Start here

- Open `Ripple-Neuron-Simulator.html` in a current browser. It is self-contained and runs offline. Move the color sliders; run the brightness-step experiment; export its CSV.
- Read `Ripple-Neuron-Engineering-Brief.pdf` for the concept, wiring, equations and measured-versus-simulated boundary.
- Use `BUILD.md` for the full bench procedure and `ENGINEERING.md` for the specification.
- Run `python3 simulate.py --out results` from this folder to reproduce the supplied CSV and summary. Python standard library only.
- Run `python3 -m unittest discover -s tests -v` and `node tests/check_model.cjs` for the required numerical checks. Node.js is needed only for the JavaScript check.

## What has been demonstrated

The synthetic red input is 0.35, then 0.70, then 0.35, in three 40-second phases. The target is one model event per second. In the final 20 seconds of each phase:

| Window | Adaptive threshold | Fixed threshold |
|---|---:|---:|
| 20-40 s | 1.00 Hz | 1.65 Hz |
| 60-80 s | 0.95 Hz | 3.40 Hz |
| 100-120 s | 1.00 Hz | 1.65 Hz |

These are counted model events, not physical light or GPIO measurements. See `results/simulation_summary.json`, `results/model_events.csv` and `VERIFICATION.md`.

## What the first hardware version would do

A common-anode RGB LED sends three input channels through a light-shielded path to an Adafruit AS7341 breakout. An original Raspberry Pi Pico/Pico H calibrates the color responses and runs a leaky integrate-and-fire model. Red and green are assigned excitatory weights; blue is assigned an inhibitory weight. Output activity adjusts the firing threshold. An onboard LED is an activity indicator, and USB serial reports model-event counts.

This version senses spectral intensity; its memory and regulation run electronically. It is a neuron-like building block, with fixed weights and homeostatic adaptation. A task-learning network, motor controller and robot demonstration remain later steps. Neuromorphic photonics is an existing research field; this package makes no first-in-the-world or patent-novelty claim.

## Free reuse

Original drawings, documents, code and synthetic results in this package are released under **CC0-1.0**. You may copy, modify, build upon, distribute or use them commercially. Credit is welcome and is not a condition of CC0. Third-party software is not bundled; its original terms still apply. See `LICENSE.md` for the full legal-code link and the scope of the release.

## For the next builder

The most useful contribution is a physical replication: record calibration counts, component/library versions, ADC saturation status, sample timestamps, input profiles and output events. Publish the failures as well as the successes. A maker space, electronics club, university neuromorphic group or robotics lab can start with this bench test before considering a network or an all-optical implementation.
