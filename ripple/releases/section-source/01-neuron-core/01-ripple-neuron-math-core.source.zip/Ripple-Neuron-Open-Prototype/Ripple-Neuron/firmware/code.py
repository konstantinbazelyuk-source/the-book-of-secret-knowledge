"""Ripple bench firmware for ORIGINAL Raspberry Pi Pico/Pico H. CC0-1.0.

Requires CircuitPython + Adafruit AS7341, BusDevice and Register libraries.
This firmware was syntax-checked but has NOT been run on physical hardware.
Copy ripple_core.py, optical_sensor.py and frame_capture.py to the CIRCUITPY root.
Set ADAPTIVE=False for the fixed-threshold physical comparison run.
"""
import time
import json
import sys
import board
import busio
import digitalio
import pwmio
from ripple_core import Neuron,make_decoder,decode_light
from optical_sensor import OpticalSensor

ADAPTIVE=True
REFERENCE_DUTY=0.60
SAMPLE_PERIOD_S=0.10
CALIBRATION_SAMPLES=12

outputs=[]
indicator=None
sensor=None
requested_x=(0,0,0)


def set_rgb(x):
    global requested_x
    requested_x=tuple(x)
    for output,value in zip(outputs,x):
        output.duty_cycle=int(65535*REFERENCE_DUTY*min(1,max(0,value)))


def read_capture(sensor,stage):
    try:
        return sensor.read()
    finally:
        record=dict(sensor.last_record or {})
        record["stage"]=stage
        record["requested_x"]=requested_x
        record["pwm_command_u16"]=[o.duty_cycle for o in outputs]
        print("RAW_FRAME_JSON,"+json.dumps(record))


def average(sensor,stage):
    total=[0.0]*8
    for _ in range(CALIBRATION_SAMPLES):
        values=read_capture(sensor,stage)
        for i,value in enumerate(values):total[i]+=value
    return [v/CALIBRATION_SAMPLES for v in total]


def calibrate(sensor):
    set_rgb((0,0,0));time.sleep(0.25)
    dark=average(sensor,"calibration_dark")
    columns=[]
    for label,x in zip(("red","green","blue"),((1,0,0),(0,1,0),(0,0,1))):
        set_rgb(x);time.sleep(0.25)
        ref=average(sensor,"calibration_"+label)
        columns.append([v-d for v,d in zip(ref,dark)])
    cal=make_decoder(dark,columns)
    set_rgb((0.5,0.5,0.5));time.sleep(0.25)
    mixture_raw=average(sensor,"calibration_mixture")
    mixture=decode_light(mixture_raw,cal)
    if max(abs(v-0.5) for v in mixture["unclipped"])>0.10 or mixture["residual"]>0.10:
        raise RuntimeError("Calibration mixture failed: adjust light level/geometry and recalibrate")
    set_rgb((0,0,0))
    cal["mixture_raw_counts"]=mixture_raw
    cal["mixture_decoded"]=mixture
    print("CALIBRATION_JSON,"+json.dumps(cal))
    return cal


try:
    # GPIOs drive transistor BASES through 2.2 kohm, never LED cathodes directly.
    for pin in (board.GP14,board.GP15,board.GP16):
        outputs.append(pwmio.PWMOut(pin,frequency=5000,duty_cycle=0))
    indicator=digitalio.DigitalInOut(board.LED)
    indicator.direction=digitalio.Direction.OUTPUT
    indicator.value=False
    i2c=busio.I2C(board.GP1,board.GP0,frequency=100000)
    sensor=OpticalSensor(i2c)
    print("BOOT_JSON,"+json.dumps({"circuitpython":sys.version,
          "sensor_driver_version":sensor.driver_version,"adaptive":ADAPTIVE,
          "pwm_frequency_setting_hz":[o.frequency for o in outputs]}))
    print("STATUS,Ripple v0.1; sensor driver="+sensor.driver_version)
    print("STATUS,ATIME=0 ASTEP=3599 GAIN=16; two sequential 10.008ms banks")
    cal=calibrate(sensor)
    neuron=Neuron(adaptive=ADAPTIVE)
    print("time_s,red_norm,green_norm,blue_norm,drive,u,theta,rate_hz,model_events,residual,cycle")
    last=time.monotonic()
    cycle_start=last
    while True:
        start=time.monotonic()
        phase=(start-cycle_start)%120.0
        set_rgb((0.35 if phase<40 or phase>=80 else 0.70,0,0))
        raw=read_capture(sensor,"experiment")
        end=time.monotonic()
        dt=end-last
        if dt<=0 or dt>0.5:
            raise RuntimeError("Sample timing gap >0.5s; stop rather than invent missing optical history")
        decoded=decode_light(raw,cal)
        if decoded["out_of_range"] or decoded["residual"]>0.10:
            raise RuntimeError("Optical input outside calibration; stop and recalibrate")
        # Endpoint-held reconstruction: this new reading is applied over dt.
        # Transition time is uncertain at the frame/integration scale.
        r=neuron.step(decoded["x"],dt)
        last=end
        # Indicator only. Serial model-event count is the canonical output.
        # This GPIO does not claim precise sub-sample physical spike timing.
        indicator.value=r["count"]>0
        x=decoded["x"]
        print("{:.4f},{:.4f},{:.4f},{:.4f},{:.4f},{:.4f},{:.4f},{:.4f},{},{:.4f},{}".format(
            r["t"],x[0],x[1],x[2],r["drive"],r["u"],r["theta"],r["rate"],r["count"],
            decoded["residual"],int((start-cycle_start)//120)))
        time.sleep(max(0,SAMPLE_PERIOD_S-(time.monotonic()-start)))
except Exception as error:
    print("FAULT_JSON,"+json.dumps({"error":str(error),
          "last_sensor_record":sensor.last_record if sensor is not None else None}))
    raise
finally:
    for output in outputs:output.duty_cycle=0
    if indicator is not None:indicator.value=False
