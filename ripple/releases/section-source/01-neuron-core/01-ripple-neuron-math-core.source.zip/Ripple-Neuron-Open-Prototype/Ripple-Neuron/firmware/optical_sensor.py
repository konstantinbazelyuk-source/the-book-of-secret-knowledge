"""AS7341 bank/status adapter. CC0-1.0. Physical hardware not tested here.

Uses Adafruit driver INTERNALS deliberately: the public all_channels property
discards the ASTATUS byte of each bank. This adapter preserves both status bytes
so analog/digital saturation cannot be hidden by the second scan.
Verified source interface on 2026-10-13:
https://github.com/adafruit/Adafruit_CircuitPython_AS7341/blob/main/adafruit_as7341.py
Keep this adapter isolated; update it if the installed driver changes internals.
"""
import time
from frame_capture import capture_record


class OpticalSensor:
    def __init__(self,i2c):
        import adafruit_as7341
        self.driver=adafruit_as7341.AS7341(i2c)
        self.driver.atime=0
        self.driver.astep=3599
        self.driver.gain=adafruit_as7341.Gain.GAIN_16X
        self.driver.led=False
        self.fullscale=min(65535,(self.driver.atime+1)*(self.driver.astep+1))
        self.integration_s=(self.driver.atime+1)*(self.driver.astep+1)*2.78e-6
        self.driver_version=getattr(adafruit_as7341,"__version__","unknown")
        self.last_record=None
        for name in ("_configure_f1_f4","_configure_f5_f8"):
            if not hasattr(self.driver,name):
                raise RuntimeError("Installed AS7341 driver internals changed; update adapter")

    def read(self):
        start=time.monotonic()
        self.last_record={"valid":False,"error":"Acquisition incomplete",
                          "acquisition_start_monotonic_s":start}
        self.driver._configure_f1_f4()
        low=self.driver._all_channels
        self.last_record["bank_low"]=list(low)
        self.driver._configure_f5_f8()
        high=self.driver._all_channels
        self.last_record=capture_record(low,high,self.fullscale)
        self.last_record["acquisition_start_monotonic_s"]=start
        self.last_record["acquisition_end_monotonic_s"]=time.monotonic()
        self.last_record["integration_per_bank_s"]=self.integration_s
        if not self.last_record["valid"]:
            raise ValueError(self.last_record["error"])
        return self.last_record["raw_counts"]
