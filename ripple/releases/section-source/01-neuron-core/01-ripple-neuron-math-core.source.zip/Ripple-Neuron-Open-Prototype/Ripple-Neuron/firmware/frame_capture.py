"""Preserve both measured bank records, including rejected frames. CC0-1.0."""
from ripple_core import check_frame


def capture_record(low,high,fullscale):
    record={"bank_low":list(low),"bank_high":list(high),
            "raw_counts":list(low[1:5])+list(high[1:5]),
            "adc_fullscale":fullscale,"valid":False}
    try:
        record["raw_counts"]=check_frame(low,high,fullscale)
        record["valid"]=True
    except ValueError as error:
        record["error"]=str(error)
    return record
