# Decision record — do not integrate the Gaussian weighting into Ripple Repair v1.0

- **Request:** Investigate Gaussian wave-packet mathematics shown in screenshots for useful improvements to Ripple.
- **Source-supported:** Fixed-width localized complex waves are mathematical signals. Physical free Schrödinger evolution requires dispersion of a finite Gaussian wave packet. Gaussian-windowed complex Fourier/wavelet analysis can identify time/frequency localization in data.
- **Derived:** The screenshot's unspreading ansatz has nonzero PDE residual at finite Gaussian width; exact free-particle packet implemented and checked by numerical differentiation.
- **Implemented:** Read-only CLI analyzing uniformly sampled normalized CSV traces and exact-vs-fixed Gaussian physics library.
- **Executed:** Holdout benchmark with independent seeds and matched filters.
- **Observed in software:** Gaussian and rectangular/flat harmonic detectors are essentially equivalent on the selected synthetic task; zero evidence from this experiment that Gaussian weighting deserves its own repair neuron. More specialized signal detectors greatly outperform Delta for THIS frequency-classification task only.
- **Unresolved:** No real periodically sampled per-stripe damage history is available. Fault localization in RPR1 archives is already exact by SHA-256 hashes. No change to redundancy budget or cryptographic integrity is possible from this analysis.
- **Rejected implementation:** Do not merge into production scrub priority; avoid adding a computational organ without a measurable improvement over an equivalent simpler filter.
- **Next experiment:** Collect 64+ regular independent scrub-time observations from a noncritical file/archive (with measurement provenance), define an operational prediction target like new intermittent storage faults, run a blind evaluation against no-detector, moving variance, autocorrelation, Delta and a flat sinusoidal detector, and measure false alarms, lead time and CPU overhead before deciding on promotion.
