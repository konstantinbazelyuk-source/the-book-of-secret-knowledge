# Ripple Gaussian Wave-Packet Mathematics Study v0.1

**Status: executed mathematical validity + diagnostic signal research. Not merged into Ripple Repair.**

The user supplied three screenshots from a social-media visualization of a one-dimensional Gaussian wave packet and the free-particle Schrodinger equation. This package distinguishes a genuine free-particle solution from an unspreading illustration, and evaluates Gaussian-windowed complex oscillatory filters against simpler signal detectors for Ripple Repair-style historical diagnostic telemetry.

## 1. Mathematical correction

The image's fixed-width ansatz is

`psi_fixed(x,t) = A exp(-(x-v*t)^2/(4*sigma0^2)) exp(i*(k*x-omega*t))`

with `v=hbar*k/m` and `omega=hbar*k*k/(2*m)`. The free-particle PDE is

`i*hbar*partial_t psi = -(hbar*hbar/(2*m))*partial_xx psi`.

A finite fixed-width Gaussian is **not** a solution. Algebra gives

`R/psi = hbar^2/(2*m) * ( (x-v*t)^2/(4*sigma0^4) - 1/(2*sigma0^2) )`

for `R=i*hbar*psi_t+hbar^2/(2*m)*psi_xx`. This is nonzero in general. The free propagating Gaussian needs the complex time-dependent width `q(t)=1+i*hbar*t/(2*m*sigma0^2)`, see `ripple_wave_probe/physics.py`. Its position density spreads with standard deviation `sigma_x(t)=sigma0 * sqrt(1+(hbar*t/(2*m*sigma0^2))^2)`.

The animation is best interpreted as an illustration of Gaussian localization plus a carrier wave, not a verified simulation of that PDE.

## 2. Engineering hypothesis and ablation

The directly useful idea is a **Gaussian-windowed complex sinusoidal projection** of a regularly sampled, scalar diagnostic trace (similar to a localized Fourier analysis / complex Morlet family):

`Z(c) = (2/sum_j w_j)*abs(sum_j w_j*(x[c+j]-weighted_mean)*exp(-i*2*pi*j/P))`

where `j=-12..12`, `w_j=exp(-0.5*(j/7.5)^2)` and `P=8 observation ticks`. The score is `max_c Z(c)` over recent valid windows. It is dimensionless (same units as normalized trace). It uses only past/current observations if evaluated after the relevant window ends. No optical wave or quantum effect is needed or claimed.

A simpler competitor replaces `w_j` with 1 (flat Fourier window). Further competitors are max absolute first difference (Delta-inspired) and maximum windowed standard deviation. The actual fault/corruption detector in Ripple Repair remains SHA-256 comparison; this time-series analysis cannot recover bytes, distinguish tampering from hardware defects, or override checksum/parity operations.

## 3. Controlled experiment and evidence

- All experiments use explicitly **synthetic** normalized 96-tick scalar histories.
- Positive class: a time-localized periodic ~8-tick fluctuation, with random phase, amplitude, central time and additive noise. This design is intentionally favorable to frequency-selective methods.
- Negative class: noise, abrupt steps, isolated impulses, drift, and off-frequency fluctuations.
- A separate 450-negative reference set sets each detector's threshold at a nominal 5% empirical false-positive target. The 300 positive and 300 negative holdouts are independently seeded and not used to choose the thresholds.
- Compare Gaussian window, flat window, Delta and rolling standard deviation. Preserve time-shuffle negative control in `results/benchmark.json`.
- **Decision:** no demonstrated practical advantage to Gaussian weighting over a simpler flat harmonic filter. Therefore **do not merge a new Gaussian "organ" into the verified Ripple Repair application**. An optional offline frequency probe is justified for longitudinal uniformly sampled fault data if such observations become available.
- Archived repair history from the current project's example databases has only six scrub records per fixture—far short of the 64 evenly spaced observations required. No actual device-time series is available to validate this feature.

## 4. Use

Requires Python 3.10+; **standard library only**.

```shell
python -m unittest discover -s tests -q
python -m ripple_wave_probe benchmark
python -m ripple_wave_probe inspect results/example_fault_history.csv --period 8
```

CSV schema: `tick,value` where tick values increase at a nearly uniform cadence and value is finite in `[0,1]`. The CLI refuses absent/irregular observations; it reports numeric evidence, not a device-calibrated fault probability or permission to repair files. `--period` is in number of observations.

Read `results/benchmark.json`, `results/physics_check.json`, `docs/INTEGRATION_DECISION.md`. Frozen Ripple Repair v1.0 source files were **not modified**.

## References

- University of Vienna, *Time-Dependent Schrodinger Equation* (free Gaussian spreading): https://homepage.univie.ac.at/reinhold.bertlmann/pdfs/T2_Skript_Chapter_2.pdf
- MIT OpenCourseWare, *Quantum Mechanics I, Lecture 3* (wave-packet spread): https://ocw.mit.edu/courses/5-73-quantum-mechanics-i-fall-2018/93d60ea36737349acdeb5afdef6fd500_MIT5_73F18_Lec3.pdf
- SciPy, *Short Time Fourier Transform*: https://docs.scipy.org/doc/scipy/tutorial/signal.html
- PyWavelets, *Complex Morlet Wavelets*: https://pywavelets.readthedocs.io/en/latest/ref/cwt.html

Sources support the mathematical method, **not** a performance claim about a user's device or the synthetic benchmark.
