"""Verification of the reel's fixed-width envelope against free Schrodinger PDE.

These are ordinary numerical wavefunctions, not signals from Ripple hardware.
Units are arbitrary consistent dimensionless test units unless explicitly supplied.
"""
import cmath, math

def fixed_packet(x,t,*,sigma0=1.0,k0=2.0,hbar=1.0,m=1.0):
    if not (sigma0>0 and hbar>0 and m>0): raise ValueError('Positive widths/mass/hbar required')
    v=hbar*k0/m; omega=hbar*k0*k0/(2*m)
    amplitude=(2*math.pi*sigma0**2)**(-.25)
    return amplitude*cmath.exp(-((x-v*t)**2)/(4*sigma0**2)+1j*(k0*x-omega*t))

def free_packet(x,t,*,sigma0=1.0,k0=2.0,hbar=1.0,m=1.0):
    if not (sigma0>0 and hbar>0 and m>0): raise ValueError('Positive widths/mass/hbar required')
    v=hbar*k0/m; omega=hbar*k0*k0/(2*m)
    z=1+1j*hbar*t/(2*m*sigma0**2)
    amp=(2*math.pi*sigma0**2)**(-.25)/cmath.sqrt(z)
    return amp*cmath.exp(-(x-v*t)**2/(4*sigma0**2*z) +1j*(k0*x-omega*t))

def pde_residual(fn,x,t,*,dt=0.00002,dx=0.002,sigma0=1.,k0=2.,hbar=1.,m=1.):
    """Finite-difference residual ihbar*psi_t + hbar²/(2m)*psi_xx. Zero iff PDE holds."""
    p=lambda u,v:fn(u,v,sigma0=sigma0,k0=k0,hbar=hbar,m=m)
    time=(p(x,t+dt)-p(x,t-dt))/(2*dt)
    space=(p(x+dx,t)-2*p(x,t)+p(x-dx,t))/(dx*dx)
    return 1j*hbar*time +(hbar*hbar/(2*m))*space

def fixed_packet_analytic_residual_over_psi(x,t,*,sigma0=1.,k0=2.,hbar=1.,m=1.):
    v=hbar*k0/m
    y=x-v*t
    return hbar*hbar/(2*m)*(y*y/(4*sigma0**4)-1/(2*sigma0**2))

def predicted_width(t,*,sigma0=1.,hbar=1.,m=1.):
    return sigma0*math.sqrt(1+(hbar*t/(2*m*sigma0*sigma0))**2)
