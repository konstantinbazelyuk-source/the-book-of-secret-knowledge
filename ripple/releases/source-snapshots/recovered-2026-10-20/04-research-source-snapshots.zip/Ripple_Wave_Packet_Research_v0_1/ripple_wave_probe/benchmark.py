"""Predeclared matched-seed synthetic comparison; NOT real fault telemetry.

Signal classification target: 8-observation Gaussian-windowed oscillation;
not general anomalous behavior. Nulls include isolated impulses, drift,
step changes, off-frequency packets, and noise. Detection thresholds calibrated
on independent null data with target <=5% empirical FPR on calibration only.
"""
from .probe import inspect_series
import random,math,json,time,statistics
from .physics import *

SCORERS=('packet','flat_harmonic','delta','windowed_std')

def make_case(rng,positive,shape=None):
    n=96
    base=rng.uniform(.37,.57)
    drift=rng.uniform(-.0012,.0012)
    s=[max(0,min(1,base+drift*(i-48)+rng.gauss(0,.045))) for i in range(n)]
    center=rng.randint(64,76)
    if positive:
        amplitude=rng.uniform(.11,.37)
        phase=rng.uniform(0,2*math.pi)
        period=rng.uniform(7.5,8.5)
        for i in range(n):
            s[i]+=amplitude*math.exp(-.5*((i-center)/8.5)**2)*math.cos(2*math.pi*(i-center)/period+phase)
    else:
        shape=shape or rng.choice(['impulse','step','off_freq','noise','drift'])
        amp=rng.uniform(.11,.37)
        if shape=='impulse':
            s[center]+=rng.choice([-1,1])*amp
        elif shape=='step':
            for i in range(center,n):s[i]+=rng.choice([-1,1])*amp/2
        elif shape=='off_freq':
            period=rng.choice([4.3,14.0]);phase=rng.uniform(0,2*math.pi)
            for i in range(n):s[i]+=amp*math.exp(-.5*((i-center)/8.5)**2)*math.cos(2*math.pi*(i-center)/period+phase)
        elif shape=='drift':
            for i in range(n):s[i]+=.004*amp*(i-48)
        # else 'noise' no artifact
    return [max(0.,min(1.,v)) for v in s]

def trial(seed,n_each):
    rng=random.Random(seed)
    return [make_case(rng,False) for _ in range(n_each)], [make_case(rng,True) for _ in range(n_each)]

def thresholds(scores,alpha=.05):
    # strict > threshold means <= floor(.05*n) positives on calibration sample
    result={}
    for k in SCORERS:
        v=sorted(row[k] for row in scores)
        j=math.ceil((1-alpha)*len(v))-1
        result[k]=v[max(0,min(len(v)-1,j))]
    return result

def score_rows(rows):return [inspect_series(x) for x in rows]

def performance(pos,neg,cutoffs):
    out={}
    for k in SCORERS:
        tp=sum(x[k]>cutoffs[k] for x in pos)
        fp=sum(x[k]>cutoffs[k] for x in neg)
        out[k]={'TP':tp,'FN':len(pos)-tp,'FP':fp,'TN':len(neg)-fp,
                'sensitivity':tp/len(pos),'false_positive_rate':fp/len(neg),
                'threshold':cutoffs[k]}
    return out

def run_benchmark(seed_train=20261017,seed_test=20271017,n_train=450,n_test=300):
    t=time.perf_counter()
    tr_neg,_=trial(seed_train,n_train)
    te_neg,te_pos=trial(seed_test,n_test)
    cutoffs=thresholds(score_rows(tr_neg))
    scores_neg=score_rows(te_neg);scores_pos=score_rows(te_pos)
    main=performance(scores_pos,scores_neg,cutoffs)
    # Explicit negative control: destroy temporal ordering but preserve values.
    rng=random.Random(9123)
    shuffled=[]
    for row in te_pos:
        other=row[:]
        rng.shuffle(other)
        shuffled.append(other)
    changed=performance(score_rows(shuffled),scores_neg,cutoffs)
    # Check contribution beyond baseline; threshold chosen without positive/test data.
    return {'scenario':'designed synthetic normalized fault telemetry; sampled once per model tick',
      'target':'localized oscillatory signal with period approx 8 ticks, not generic corruption',
      'training_seed':seed_train,'holdout_seed':seed_test,
      'samples':{'calibration_nulls':n_train,'holdout_positives':n_test,'holdout_nulls':n_test},
      'calibration_fpr_goal':.05,'metrics':main,'time_shuffled_positive_control':changed,
      'observed_elapsed_seconds':round(time.perf_counter()-t,4),
      'no_independent_physical_data':True}

if __name__=='__main__':
    print(json.dumps(run_benchmark(),indent=2))
