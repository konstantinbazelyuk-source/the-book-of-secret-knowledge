"""Research-only Gaussian window oscillatory signal probe.

No quantum hardware, no file repair, no permission to override checksums.
"""
from .probe import packet_score, delta_score, variance_score, inspect_series
from .physics import free_packet, fixed_packet, pde_residual
__all__=['packet_score','delta_score','variance_score','inspect_series','free_packet','fixed_packet','pde_residual']
