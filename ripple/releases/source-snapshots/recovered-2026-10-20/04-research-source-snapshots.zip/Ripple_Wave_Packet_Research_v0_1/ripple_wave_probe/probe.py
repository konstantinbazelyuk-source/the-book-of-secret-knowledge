"""Causal local Gaussian-windowed complex oscillatory projection on scalar telemetry.

The probe classifies a *predeclared* frequency in a regularly sampled scalar
signal; it does not repair file bytes and cannot infer data that are absent.
Default period=8 observations. No future samples are used by any window.
"""
import math

OFFSETS=tuple(range(-12,13))
SIGMA=7.5
PERIOD=8.0

def _validated(samples):
    if len(samples)<64: raise ValueError('At least 64 regular samples required')
    if any(not math.isfinite(float(v)) or not 0<=float(v)<=1 for v in samples):
        raise ValueError('Expected finite normalized samples [0,1]')
    return [float(v) for v in samples]

def _window_centers(n):
    # Fixed reference window, designed for the same 96-sample history for all models.
    # For arbitrary length: inspect most recent up to 60 samples, step two.
    return range(max(13,n-59),n-12,2)

def _harmonic_score(samples,period,gaussian):
    x=_validated(samples)
    if not (math.isfinite(period) and period>=3):raise ValueError('period must be finite >=3')
    weight=[math.exp(-0.5*(j/SIGMA)**2) if gaussian else 1.0 for j in OFFSETS]
    wsum=sum(weight)
    cr=[math.cos(2*math.pi*j/period) for j in OFFSETS]
    ci=[-math.sin(2*math.pi*j/period) for j in OFFSETS]
    max_score=0.
    for center in _window_centers(len(x)):
        vals=[x[center+j] for j in OFFSETS]
        mean=sum(w*v for w,v in zip(weight,vals))/wsum
        re=sum(w*(v-mean)*c for w,v,c in zip(weight,vals,cr))
        im=sum(w*(v-mean)*c for w,v,c in zip(weight,vals,ci))
        score=math.hypot(re,im)*2/wsum
        max_score=max(score,max_score)
    return max_score

def packet_score(samples,period=PERIOD):
    """Max Gaussian-windowed harmonic amplitude with independent threshold calibration."""
    return _harmonic_score(samples,period,True)

def flat_harmonic_score(samples,period=PERIOD):
    """Same complex harmonic filter but uniform window: Gaussian-envelope ablation."""
    return _harmonic_score(samples,period,False)

def delta_score(samples):
    x=_validated(samples)
    x=x[-60:]
    return max(abs(x[i]-x[i-1]) for i in range(1,len(x)))

def variance_score(samples):
    x=_validated(samples)
    # Identical search-over-local-windows structure for baseline.
    window=[math.exp(-0.5*(j/SIGMA)**2) for j in OFFSETS]
    total=sum(window); best=0
    for c in _window_centers(len(x)):
        vals=[x[c+j] for j in OFFSETS]
        avg=sum(w*v for w,v in zip(window,vals))/total
        best=max(best,math.sqrt(sum(w*(v-avg)**2 for w,v in zip(window,vals))/total))
    return best

def inspect_series(samples,period=PERIOD):
    """Read-only diagnostic scores; thresholds depend on reference population."""
    return {'packet':packet_score(samples,period), 'flat_harmonic':flat_harmonic_score(samples,period), 'delta':delta_score(samples),
            'windowed_std':variance_score(samples),'evidence_kind':'numeric_telemetry_only',
            'file_repair_decision':'never'}
