"""Read-only research CLI for regularly sampled scalar telemetry."""
import argparse,csv,math,json,sys
from .probe import inspect_series
from .benchmark import run_benchmark

def read_csv(path):
    with open(path,newline='',encoding='utf-8-sig') as f:
        rdr=csv.DictReader(f)
        if not rdr.fieldnames or not {'tick','value'}.issubset(rdr.fieldnames):
            raise ValueError('Expected CSV headers: tick,value')
        rows=[(float(row['tick']),float(row['value'])) for row in rdr]
    if len(rows)<64:raise ValueError('Need >=64 observations')
    ticks=[r[0] for r in rows]
    if not all(math.isfinite(x) for x in ticks):raise ValueError('Nonfinite tick')
    differences=[b-a for a,b in zip(ticks,ticks[1:])]
    if any(v<=0 for v in differences):raise ValueError('Tick values must increase strictly')
    step=sum(differences)/len(differences)
    if any(abs(d-step)>max(1e-8,abs(step)*.005) for d in differences):
        raise ValueError('Irregular sampling; no implicit interpolation or fabricated observations')
    return [r[1] for r in rows],step

def main(argv=None):
    p=argparse.ArgumentParser(description='Ripple Gaussian packet math and telemetry study (research only)')
    sp=p.add_subparsers(dest='command',required=True)
    ip=sp.add_parser('inspect',help='Read normalized, regularly sampled tick,value CSV')
    ip.add_argument('csv');ip.add_argument('--period',type=float,default=8.,help='period in sample ticks')
    sp.add_parser('benchmark',help='Reproduce synthetic holdout study with fixed seeds')
    args=p.parse_args(argv)
    if args.command=='benchmark':
        print(json.dumps(run_benchmark(),indent=2))
    else:
        obs,step=read_csv(args.csv)
        out=inspect_series(obs,args.period)
        out.update({'samples':len(obs),'sampling_interval_units':step,'period_units':args.period*step,
                    'interpretation':'scores only; no validated device alarm thresholds; no file repair'})
        print(json.dumps(out,indent=2))
    return 0

if __name__=='__main__':
    try:sys.exit(main())
    except (ValueError,FileNotFoundError) as e:
        print(f'Invalid input: {e}',file=sys.stderr);sys.exit(2)
