import unittest,math,random
from ripple_wave_probe.physics import fixed_packet,free_packet,pde_residual,predicted_width,fixed_packet_analytic_residual_over_psi
from ripple_wave_probe.probe import inspect_series,packet_score,flat_harmonic_score
from ripple_wave_probe.benchmark import run_benchmark
from ripple_wave_probe.__main__ import read_csv
import csv,tempfile,pathlib

class PhysicalValidity(unittest.TestCase):
    def test_initial_same(self):
        for x in [-4,-1,0,1,4]:self.assertAlmostEqual(abs(free_packet(x,0)-fixed_packet(x,0)),0,places=12)
    def test_exact_solution_residual_small(self):
        for t in [0,.3,1.,2.]:
            for offset in [-1,0,1]:
                x=2*t+offset
                self.assertLess(abs(pde_residual(free_packet,x,t)),2e-5)
    def test_fixed_envelope_is_not_exact_solution(self):
        for t in [0,1]:
            x=2*t
            residual=pde_residual(fixed_packet,x,t)
            self.assertGreater(abs(residual),0.08)
            self.assertLess(abs(residual/fixed_packet(x,t)-fixed_packet_analytic_residual_over_psi(x,t)),2e-5)
    def test_spreading(self):
        self.assertAlmostEqual(predicted_width(0),1.)
        self.assertAlmostEqual(predicted_width(2),math.sqrt(2))
        self.assertGreater(predicted_width(4),predicted_width(1))
    def test_density_norm_approximation(self):
        dx=.025
        for t in [0,3]:
            xs=[-22+i*dx for i in range(1761)]
            probs=[abs(free_packet(x,t,k0=0))**2 for x in xs]
            m=sum(v*dx for v in probs)
            width2=sum((x*x)*p*dx for x,p in zip(xs,probs)) / m
            self.assertAlmostEqual(m,1.,places=5)
            self.assertAlmostEqual(width2,predicted_width(t)**2,places=4)

class ProbeTests(unittest.TestCase):
    def test_constant(self):self.assertAlmostEqual(packet_score([.35]*96),0.)
    def test_period_frequency_matching(self):
        x=[.5+.2*math.exp(-.5*((i-72)/9)**2)*math.cos(2*math.pi*(i-72)/8) for i in range(96)]
        self.assertGreater(packet_score(x,8),packet_score(x,4))
        self.assertGreater(packet_score(x,8),packet_score(x,16))
    def test_gaussian_window_ablation_is_distinct(self):
        x=[.5+.2*math.exp(-.5*((i-72)/8)**2)*math.cos(2*math.pi*(i-72)/8) for i in range(96)]
        self.assertNotAlmostEqual(packet_score(x),flat_harmonic_score(x))
    def test_phase_response(self):
        for phase in [0,math.pi/3,math.pi/2,math.pi]:
            x=[.5+.25*math.exp(-.5*((i-72)/9)**2)*math.cos(2*math.pi*(i-72)/8+phase) for i in range(96)]
            self.assertGreater(packet_score(x),.15)
    def test_normalized_rejection(self):
        for vals in [[.5]*20,[.5]*95+[math.nan],[.5]*95+[1.1]]:
            with self.assertRaises(ValueError):inspect_series(vals)
    def test_no_file_repair_action(self):
        x=[.5]*96
        self.assertEqual(inspect_series(x)['file_repair_decision'],'never')
    def test_csv_io(self):
        with tempfile.TemporaryDirectory() as td:
            file=pathlib.Path(td)/'trace.csv'
            with file.open('w',newline='') as f:
                writer=csv.writer(f);writer.writerow(['tick','value'])
                writer.writerows([(t*0.1,0.5) for t in range(96)])
            vals,step=read_csv(str(file))
            self.assertEqual(len(vals),96)
            self.assertAlmostEqual(step,0.1)
    def test_irregular_sample_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            file=pathlib.Path(td)/'trace.csv'
            with file.open('w',newline='') as f:
                writer=csv.writer(f);writer.writerow(['tick','value'])
                writer.writerows([(t*0.1 + (1 if t==75 else 0),0.5) for t in range(96)])
            with self.assertRaises(ValueError):read_csv(str(file))
    def test_reproducibility(self):
        a=run_benchmark(n_train=50,n_test=30)
        b=run_benchmark(n_train=50,n_test=30)
        a.pop('observed_elapsed_seconds');b.pop('observed_elapsed_seconds')
        self.assertEqual(a,b)

if __name__=='__main__':unittest.main()
