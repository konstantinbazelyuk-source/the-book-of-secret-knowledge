# Ripple Cloud Evolution v1.2 — Results and evidence

## What is genuinely updated

The locked v0.1 optical/RGB neuron model has **not** changed. Evolution acts on an *outer genotype* for eight-legged gait parameters plus a bounded inter-layer feedback gain:

\[g=(s,h,T,d,k), \quad s\in[26,48],\;h\in[12,32],\;T\in[1.15,2.25],\;d\in[.60,.82],\;k\in[0,.55].\]

At each motor time step (0.04 s) eight individual preserved Ripple neurons process features from their associated legs; the features are normalized **software-derived tracking variables**, not wavelengths. Their pulse histories are independent. A bounded adapter uses pulse-triggered risks:

\[r_{i,t+1}=\min(1,r_{i,t}\exp(-\Delta t/0.30)+0.70 n_{i,t});\qquad s_{t+1}=s_0[1-k\max_i(r_{i,t+1})].\]

Each candidate has its own independent digital motor and neuron state; this does not mutate any internal neuron weights. A seeded elitist evolutionary algorithm explores the genotype using bounded Gaussian mutations. Fitness is evaluated across perturbed *assumed motor response constants* (domain randomization). The objective penalizes unreachable targets, commanded-support proxies below four, servo rate saturation, virtual foot-placement error, and slowdown. A held-out set is never used to rank candidates.

These changes produce a **new experimental Ripple Colony behavioral variant**, *EvoGait*, not a new demonstrated form of intelligence or a trained neural-network weight matrix.

## First search, cloud reproduced

52 distinct genomes, five generations, four training regimes, eight holdout regimes. First held-out objective **6.549213 → 5.115900** (21.89% reduction); simulated toe RMS **5.44395 → 4.34425 mm** (20.20% reduction); commanded motion proxy **33.9286 → 34.2691 mm/s**. GitHub Actions cloud completed and reproduced the exact winning gene vector and loss. Reference evidence: https://github.com/konstantinbazelyuk-source/the-book-of-secret-knowledge/actions/runs/38503691165 and https://github.com/konstantinbazelyuk-source/the-book-of-secret-knowledge/actions/runs/38503695274 . A remote CI run is cloud computing, but *not* a Ray cluster and *not* a physical robot trial.

## Five search repetitions and held-out scenarios

Five searches with different evolution RNG seeds each evaluated 52 unique candidate vectors, on the same four train and 12 independent heldout motor parameter scenarios. All five search winners reduced the defined holdout loss by 13.39% to 33.14% and passed the pre-established candidate promotion gate. This is repeatability under the **same mathematical simulator** only. See `results/replication_and_ablation.json` for exact genomes and scores.

## Neuron feedback ablation (20 unseen motor regimes)

At gains 0, .2, .4, .55 the same winning gait showed toe RMSE **3.829, 3.616, 3.451, 3.360 mm**, respectively, but its commanded speed proxy dropped **34.269, 31.699, 29.340, 27.689 mm/s**, and the prespecified combined loss worsened. This is evidence of a **precision-throughput tradeoff**, NOT a net feedback benefit. In particular, the first-winning genotype selected gain zero. A future multi-objective Pareto stage should preserve several policies instead of pretending a single one is best for every job.

## Caveats

No body dynamics, inertial stability, payload, ground friction, contact impulse, battery usage, calibrated actuator behavior, sensor latency, motor heat, or closed-loop locomotion was simulated or measured. The body position is a **commanded integration proxy**, and support is a kinematic proximity heuristic. The optimization could exploit simulator omissions; no physical application is authorized by this output. No optical RGB light, quantum effect or sentience has been measured.

Published research supporting the methodology (not validating SpiderScan): https://docs.ray.io/en/latest/tune/examples/pbt_guide.html ; https://arxiv.org/abs/1710.06537 .
