#!/usr/bin/env python3
"""Reproducible offline tests. SPDX-License-Identifier: CC0-1.0"""
import math
import random
import tempfile
import unittest
from pathlib import Path
from ripple_optical_agent import (
    RippleNeuron, WAVELENGTH_NM, phase_step_intensities,
    decode_phase, original_brightness_step_regression, run_demo,
)

class TestOpticalAdapter(unittest.TestCase):
    def test_field_phase_reconstruction_without_noise(self):
        for nm in (-60, -20, 0, 20, 60):
            raw=phase_step_intensities(nm, random.Random(2), noise_sigma=0.0)
            phase,i,q=decode_phase(raw)
            self.assertAlmostEqual(phase*WAVELENGTH_NM/(4*math.pi), nm, places=9)
            self.assertAlmostEqual(i,2*math.cos(4*math.pi*nm/WAVELENGTH_NM), places=9)
            self.assertAlmostEqual(q,2*math.sin(4*math.pi*nm/WAVELENGTH_NM), places=9)

    def test_locked_weight_signs_and_no_spontaneous_dark_firing(self):
        n=RippleNeuron()
        self.assertAlmostEqual(n.step((.35,0,0),.05)['drive'], .70)
        self.assertAlmostEqual(n.step((0,1,0),.05)['drive'], 1.2)
        self.assertAlmostEqual(n.step((0,0,1),.05)['drive'], -1.4)
        dark=RippleNeuron()
        self.assertEqual(sum(dark.step((0,0,0),.05)['count'] for _ in range(400)),0)

    def test_node_isolation(self):
        n1=RippleNeuron()
        n2=RippleNeuron()
        for _ in range(20):
            n1.step((1,0,0),.05)
            n2.step((0,0,0),.05)
        self.assertNotEqual(n1.theta,n2.theta)
        self.assertNotEqual(n1.rate,n2.rate)

    def test_original_two_node_experiment(self):
        result=original_brightness_step_regression()
        self.assertEqual(len(result),3)
        self.assertAlmostEqual(result[1]['adaptive_hz'], .95, delta=.12)
        self.assertAlmostEqual(result[1]['fixed_hz'], 3.40, delta=.12)

    def test_reproducible_two_worker_adapter(self):
        with tempfile.TemporaryDirectory() as tmp:
            result=run_demo(Path(tmp), seconds=10)
            self.assertEqual(result['samples'],200)
            self.assertGreater(result['rising_event_count'],0)
            self.assertGreater(result['falling_event_count'],0)
            self.assertLess(result['displacement_RMSE_nm_simulation'], 1.0)
            self.assertEqual(result['routed_actions'], result['rising_event_count']+result['falling_event_count'])
            self.assertTrue((Path(tmp)/'simulated_sensor_and_neurons.csv').exists())

if __name__ == '__main__':
    unittest.main(verbosity=2)
