# Ripple Neuron — Coherent Optical Sensor Adapter / Two-Node Agent Research v0.1

**Classification: numerically simulated concept; NO hardware test; NO quantum computer; NO learned intelligence.**

This is a *separate* experimental adapter to the approved Ripple Neuron v0.1. It does not revise the original equations. Its two virtual Ripple neuron instances process separate numerical tasks: rising vs falling optical-path displacement, and route events to log-only "agent actions". There is no autonomous task planning, device control, quantum information processing, or direct electromagnetic-force sensing.

## Run (Python 3 standard library only)

```bash
python3 ripple_optical_agent.py
python3 -m unittest -v test_optical_adapter.py
```

Outputs are written to `results/`: one data table (`simulated_sensor_and_neurons.csv`), a list of simulated event-action logs (`simulated_agent_events.json`), and experiment metrics (`simulated_summary.json`).

## Optical measurement model

In a hypothetical **laser interferometer**, a 635 nm laser is split into a reference beam and a probe beam reflected by a small moving mirror. For each fixed sample time, assume four phase offsets (0°, 90°, 180°, 270°) are acquired using a phase-stepping arrangement or simultaneous 90° hybrid. The four *simulated normalized intensities* are

`I(delta) = I_reference + I_signal + 2 sqrt(I_reference I_signal) cos(4 pi x/lambda + delta) + noise`.

The digital reconstruction uses `i = I(0°) - I(180°)`, `q = I(270°) - I(90°)`, `phase = atan2(q,i)`; it unwraps phase and calculates relative reflective displacement `x = lambda * phase / (4 pi)`. This assumes valid geometric and reference-phase calibration, sufficient interferometric visibility, no aliasing of the phase changes, and stable optics. These are *not* measurements of the instantaneous magnetic field of the laser; they are measurements of phase sensitive to path displacement. The assumption that each four-intensity group has the same x is an idealized test condition. A real prototype should record signal strength, phase uncertainty, time synchronization, detector saturation, and reference drift.

**Quantitative distinction:** When light strikes and reflects off a surface, the force in an ideal perfectly reflecting geometry is `F = 2P/c`, requiring an actual mechanical force sensor to measure it; this code only simulates mirror motion and measures displacement by phase.

## What "electromagnetic pull or push" can mean

1. **Light-driven force:** a reflecting object experiences radiation pressure; detecting its motion is a displacement-sensing problem (photoforce).
2. **An external magnetic field:** an optically pumped atomic magnetometer measures the field by laser-readout of atomic spins (e.g. a rubidium vapor cell). That is *not* measurement of the optical wave’s own magnetic component. NIST describes this actual instrument at https://www.nist.gov/noac/technology/magnetic-and-electric-fields/chip-scale-atomic-magnetometers .
3. **Optical electric field itself:** optical heterodyne/homodyne gives relative phase-sensitive quadratures; ultrafast electro-optic sampling offers specialized waveform measurements. A normal photodiode does not sample a visible optical carrier cycle directly.

A single-wavelength laser does not physically supply a full RGB measurement. RGB visualization colors, independent spectral channels, and weighted computational features must be distinguished. Quantum computation would separately require preparation and control of suitable nonclassical quantum states, not just a photodiode or colored intensity graph.

## Digital channels and approved core

The original neuron fixed drive is `D = 2 R + 1.2 G - 1.4 B`, with `tau_v du/dt = -u + D`, positive threshold event, exact integration for constant drive, 0.1 s refractory time, exponential 5 s rate estimate, and adaptive threshold `d theta/dt = 0.08 (r_hat - 1Hz)` constrained to `[0.15,2.5]`.

**New adapter (not locked):** the positive portion of digitally decoded stepwise displacement is put into the R input of *rising* neuron; the negative portion is put into the R input of *falling* neuron. Scaling is by 10 nm per 0.05 s sample, with clamping. G and B are set to zero for this demonstration. **R is a computational input slot here, not an actual red photon measurement.** This intentionally preserves the neuron weights and isolates the experimental changes outside the approved neuron implementation.

## Replication / splitting workload

Instantiate two or more independent neurons, retaining separate `u`, `theta`, `rate` and refractory states. The dispatcher routes derived features to nodes; events are mapped to logged action labels. Merely duplicating nodes or adding optical input does **not** make the system an LLM or conscious AI. Future learning of inter-neuron weights, loss/error minimization, language comprehension, memory, scheduling and device permissions require explicit separate engineering work.

## What is real, what is simulated, what is proposed

| Element | Status |
|---|---|
| Homodyne detection, quadrature phase measurements, digital holography, radiation-pressure force | Established physics and demonstrated technologies; referenced below |
| Four ideal phase-stepped ADC readings, displacement waveforms, detector noise | **Simulated** in this package |
| Reconstruction, event counts, regression tests, two nodes, action log | **Executed in Python** |
| Real sensor PCB, calibration, laser optical path, actual agent permissions | **Proposed and unbuilt** |
| Quantum processor or exotic electromagnetic sensor | **Not constructed or demonstrated** |

## Physical instrument outline (NOT a validated parts list)

- Low-power appropriate-class coherent visible laser and laser safety enclosure.
- Stable interferometer with reference arm and reflected signal arm; mechanically mounted beamsplitter, mirror and adjustable phase element or calibrated optical I/Q receiver.
- Four balanced photodetection outputs for real-time I/Q, **or** one intensity photodetector with a controlled four-step phase shifter for slow signals. These are alternative optical designs, not interchangeable components.
- Transimpedance signal conditioning; a simultaneous or correctly timed multichannel ADC; low-noise reference and clock; MCU or computer; dark/baseline/phase calibration.
- Always block stray reflections, protect eyesight, and follow laser class safety. No high-power laser is required for this simulation.

## Research sources

- Balanced homodyne detection, integrated quantum optics: https://pmc.ncbi.nlm.nih.gov/articles/PMC6286167/
- Digital holography: https://www.nature.com/articles/s41377-024-01453-x
- Direct time-domain electro-optic field characterization (lab research): https://www.nature.com/articles/s41467-022-28699-6
- Photonic quantum computing architecture (Nature, 2025): https://www.nature.com/articles/s41586-024-08406-9
- Scalable photonic modules: https://www.nature.com/articles/s41586-025-08820-7
- Photon radiation pressure measurements: https://www.nist.gov/programs-projects/photoforce-project

## Origin & license

Original Ripple Neuron concept contribution: Constantin x. Engineering experiment prepared with AI assistance; offered under CC0-1.0 to permit open re-use. This package does not replace the previously published/approved Ripple neuron core, engineering brief, hardware BOM or GitHub files.
