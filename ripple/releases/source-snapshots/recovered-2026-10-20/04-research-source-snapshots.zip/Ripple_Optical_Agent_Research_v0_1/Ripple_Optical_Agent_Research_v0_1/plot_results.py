#!/usr/bin/env python3
"""Optional visualization: requires matplotlib; the core simulation does not."""
import csv
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
here=Path(__file__).resolve().parent
with (here/'results'/'simulated_sensor_and_neurons.csv').open() as f:
    rows=list(csv.DictReader(f))
t=[float(r['time_s']) for r in rows]
true=[float(r['true_displacement_nm_simulated']) for r in rows]
est=[float(r['decoded_displacement_nm_simulated']) for r in rows]
fig,ax=plt.subplots(figsize=(11,4.8))
ax.plot(t,true,label='Known simulated displacement',lw=2)
ax.plot(t,est,label='Decoded from simulated photodiode readings',ls='--',lw=1)
ax.set_xlim(0,5);ax.set_xlabel('Simulated time (s)');ax.set_ylabel('Reflective displacement (nm)')
ax.set_title('Optical quadrature reconstruction — SIMULATION, not measured hardware')
ax.grid(alpha=.25);ax.legend(loc='upper right');fig.tight_layout()
fig.savefig(here/'results'/'simulated_optical_reconstruction.png',dpi=150)
plt.close(fig)

fig,ax=plt.subplots(figsize=(11,4.8))
ax.plot(t,[float(r['rising_threshold']) for r in rows],label='Rising node adaptive threshold')
ax.plot(t,[float(r['falling_threshold']) for r in rows],label='Falling node adaptive threshold')
ax.set_xlabel('Simulated time (s)');ax.set_ylabel('Normalized threshold (no physical voltage)')
ax.set_title('Two replicated Ripple v0.1 neurons — synthetic optical input')
ax.grid(alpha=.25);ax.legend();fig.tight_layout()
fig.savefig(here/'results'/'simulated_two_neuron_thresholds.png',dpi=150)
plt.close(fig)
print('Wrote 2 simulated charts')
