"""Exact Q-gene polynomial identity verifier and bounded semantic repair (v0.3).

All polynomial proofs use rational coefficients and ideal real-number arithmetic.
This does not prove floating-point program equivalence, arbitrary Python correctness,
or independent trustworthiness of the supplied reference specification.
"""
from __future__ import annotations
from fractions import Fraction
from itertools import product
from .core import validate, _candidate_ops, _try_valid, MAX_OPS, InvalidGene
from .python_bridge import parse_safe_python,render_safe_python

ZERO=(0,0,0)
VARIABLES={'PUSH_R':{(1,0,0):Fraction(1)},
           'PUSH_G':{(0,1,0):Fraction(1)},
           'PUSH_B':{(0,0,1):Fraction(1)},
           'PUSH_ZERO':{},
           'PUSH_DRIVE':{(1,0,0):Fraction(2),(0,1,0):Fraction(6,5),(0,0,1):Fraction(-7,5)}}
SUPPORTED=set(VARIABLES)|{'ADD','SUB','MUL'}
MAX_TOTAL_DEGREE=8
MAX_TERMS=64

def _add(a,b,sign=1):
    out=a.copy()
    for exp,coef in b.items():
        v=out.get(exp,Fraction(0))+sign*coef
        if v:out[exp]=v
        else:out.pop(exp,None)
    if len(out)>MAX_TERMS:raise InvalidGene('Polynomial has too many monomials')
    return out

def _mul(a,b):
    out={}
    for (i,j,k),x in a.items():
        for (u,v,w),y in b.items():
            exp=(i+u,j+v,k+w)
            if sum(exp)>MAX_TOTAL_DEGREE:raise InvalidGene('Polynomial degree exceeds verified bound')
            out[exp]=out.get(exp,Fraction(0))+x*y
            if len(out)>MAX_TERMS:raise InvalidGene('Polynomial has too many monomials')
    return {key:val for key,val in out.items() if val}

def polynomial(program):
    """Canonical exact polynomial of the pre-QUANTIZE stack value.

    Reject nonsmooth clipping and unknown sensor variables: no fake mathematical proof.
    """
    validate(program)
    stack=[]
    for op in program[:-2]:
        if op in VARIABLES:stack.append(VARIABLES[op].copy())
        elif op in ('ADD','SUB','MUL'):
            if len(stack)<2:raise InvalidGene('Polynomial stack underflow')
            b,a=stack.pop(),stack.pop()
            stack.append(_add(a,b) if op=='ADD' else _add(a,b,-1) if op=='SUB' else _mul(a,b))
        else:raise InvalidGene('Proof does not support opcode '+op)
    if len(stack)!=1:raise InvalidGene('Polynomial result stack must contain one item')
    return stack[0]

def canonical(poly):
    return [{'powers':list(k),'numerator':v.numerator,'denominator':v.denominator} for k,v in sorted(poly.items())]

def counterexample(a,b):
    """Try to produce a concrete rational witness when polynomials differ.

    Equality is decided by coefficient comparison, not by this finite witness set.
    """
    if a==b:return None
    mismatch=_add(a,b,-1)
    for vals in product((Fraction(0),Fraction(1),Fraction(-1),Fraction(1,2),Fraction(2),Fraction(3,2)), repeat=3):
        diff=sum((c*vals[0]**e[0]*vals[1]**e[1]*vals[2]**e[2] for e,c in mismatch.items()),Fraction(0))
        if diff:
            return {'inputs':{key:str(v) for key,v in zip(('R','G','B'),vals)},'difference':str(diff)}
    return None

def prove_polynomial(reference_source,candidate_source):
    ref=parse_safe_python(reference_source)
    cand=parse_safe_python(candidate_source)
    a,b=polynomial(ref['program']),polynomial(cand['program'])
    matched=(a==b)
    return {'status':'proved_equal_in_exact_real_polynomial_model' if matched else 'not_equivalent',
            'algebraic_model':'rational-coefficient polynomial over R,G,B (unbounded exact reals); not IEEE-754 equivalence',
            'reference_polynomial':canonical(a),'candidate_polynomial':canonical(b),
            'counterexample':counterexample(a,b)}

def repair_with_reference(broken_source,reference_source,*,structural=True,max_candidates=25000):
    """Search one/two-edit Q candidates and verify exact polynomial equality.

    Output is a proposal, not an automatic filesystem rewrite. Reference source is
    a mandatory external semantic specification and may itself be incorrect.
    """
    bad=parse_safe_python(broken_source)
    ref=parse_safe_python(reference_source)
    try:target=polynomial(ref['program'])
    except InvalidGene as e:return {'status':'reference_outside_polynomial_subset','reason':str(e)}
    original=polynomial(bad['program'])
    if original==target:
        return {'status':'already_equivalent','source':broken_source,'proof':canonical(target),'evaluated':0}
    seen=set();winner=None;winner_key=None;matches=[];checked=0;unsupported=0
    for cand,kind,pos,cost in _candidate_ops(bad['program'],structural):
        if cand in seen:continue
        seen.add(cand)
        if winner_key is not None and cost>winner_key:continue
        if checked>=max_candidates:
            return {'status':'search_budget_exceeded','evaluated':checked,'max_candidates':max_candidates}
        checked+=1
        if len(cand)>MAX_OPS or not _try_valid(cand):continue
        try:
            candidate_poly=polynomial(cand)
            if candidate_poly!=target:continue
            candidate_source=render_safe_python(bad['name'],cand)
        except (InvalidGene,IndexError,AssertionError):
            unsupported+=1;continue
        if winner_key is None or cost<winner_key:
            winner_key=cost;matches=[]
        if cost==winner_key:matches.append((tuple(cand),kind,pos,candidate_source))
    if not matches:
        return {'status':'no_proven_repair','evaluated':checked,'unsupported_candidates':unsupported,
                'reference_polynomial':canonical(target),'original_counterexample':counterexample(original,target)}
    matches.sort(key=lambda m:m[0])
    seq,kind,pos,source=matches[0]
    verified=prove_polynomial(reference_source,source)
    assert verified['status']=='proved_equal_in_exact_real_polynomial_model'
    return {'status':'proven_in_exact_real_polynomial_model','proposed_source':source,
            'original_source':broken_source,'reference_sha256':__import__('hashlib').sha256(reference_source.encode()).hexdigest(),
            'proposal_program':list(seq),'edit_kind':kind,'edit_position':pos,'edit_cost':winner_key,
            'algebraically_equivalent_minimum_cost_candidates':len(matches),
            'evaluated':checked,'proof':verified,
            'limitations':'Formal identity is for a bounded exact-real polynomial DSL. IEEE-754 reordering/roundoff and incorrect external reference specifications are not proved.'}
