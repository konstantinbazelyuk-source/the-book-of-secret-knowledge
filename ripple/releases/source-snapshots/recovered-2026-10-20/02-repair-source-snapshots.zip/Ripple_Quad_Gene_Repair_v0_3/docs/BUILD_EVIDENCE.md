# Ripple Quad-Gene Repair v0.3 verified build evidence

- Source bundle SHA-256: `0c310bbb6b93931e1269bb479c3fed13e2bca766644ce45d1ea8343db8c98805`.
- Isolated branch: https://github.com/konstantinbazelyuk-source/the-book-of-secret-knowledge/tree/research/ripple-quad-formal-v0_3
- GitHub Actions run: https://github.com/konstantinbazelyuk-source/the-book-of-secret-knowledge/actions/runs/39084804528
- Ubuntu Linux, Python 3.11: 56 automated tests passed, 24 deliberately faulty expressions repaired and verified as exact polynomial identities.
- Windows cloud runner, Python 3.11, PyInstaller 6.11.0: `RippleQuadRepair.exe` built successfully; EXE actually launched and `/api/repair_formal` returned a correctly proved `R - B` correction. Runner log marker: `WINDOWS RIPPLE QUAD FORMAL APP BOOT/PROOF PASS`.
- Windows EXE SHA-256: `f6d76e07c44b7aa24e589817a095d3ee105118cb0c5ad2b9a14e6ebbdc7ccbcf`.
- Local Linux Python: HTTP end-to-end proof request passed and original v0.2 tests passed.
- Device-specific status: actual Dell system and Samsung Android device were not accessible for this new application. No APK was created for v0.3.
- Uncertainty and negative controls: polynomial proof does not cover floating-point instruction rearrangement; see `results/formal_study.json` for an executed counterexample.
