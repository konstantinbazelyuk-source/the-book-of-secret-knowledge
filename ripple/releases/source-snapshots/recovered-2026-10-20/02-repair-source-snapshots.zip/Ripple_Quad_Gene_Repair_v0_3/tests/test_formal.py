import json,unittest,random,tempfile,threading,urllib.request,urllib.error
from pathlib import Path
from fractions import Fraction
from ripple_quad_repair.formal import polynomial,canonical,prove_polynomial,counterexample,repair_with_reference
from ripple_quad_repair.core import InvalidGene,execute_numeric
from ripple_quad_repair.python_bridge import parse_safe_python

ROOT=Path(__file__).resolve().parent.parent

class FormalRepairTests(unittest.TestCase):
    def test_real_identity_commutativity(self):
        a='def f(R,G,B): return R + B'
        b='def f(R,G,B): return B + R'
        self.assertEqual(prove_polynomial(a,b)['status'],'proved_equal_in_exact_real_polynomial_model')
    def test_nonidentity_with_exact_counterexample(self):
        r=prove_polynomial('def f(R,G,B):return R+B','def g(R,G,B):return R-B')
        self.assertEqual(r['status'],'not_equivalent');self.assertIsNotNone(r['counterexample'])
    def test_single_opcode_repair(self):
        spec=json.loads((ROOT/'examples/formal_spec.json').read_text())
        r=repair_with_reference(spec['broken_source'],spec['reference_source'])
        self.assertEqual(r['status'],'proven_in_exact_real_polynomial_model')
        self.assertEqual(r['proposal_program'][2],'SUB')
        self.assertEqual(r['edit_cost'],1)
    def test_structural_repair(self):
        r=repair_with_reference('def f(R,G,B):return R','def ref(R,G,B):return R-B')
        self.assertEqual(r['status'],'proven_in_exact_real_polynomial_model')
        self.assertEqual(r['edit_kind'],'insert_two')
    def test_missing_spec_rejected(self):
        with self.assertRaises((TypeError,InvalidGene)):
            repair_with_reference('def f(R,G,B):return R',None)
    def test_bad_oracle_is_not_authenticated(self):
        r=repair_with_reference('def f(R,G,B):return R+B','def ref(R,G,B):return R+B')
        self.assertEqual(r['status'],'already_equivalent')
    def test_unsupported_clamp_refused(self):
        with self.assertRaises(InvalidGene):polynomial(['PUSH_R','CLAMP01','QUANTIZE','EMIT'])
    def test_unsupported_python_side_effect_refused(self):
        with self.assertRaises(InvalidGene):repair_with_reference('def f(R,G,B):return R+ B',
                                     'def x(R,G,B):\n  print(R)\n  return R-B')
    def test_degree_limit_reject(self):
        expr='R'
        for _ in range(4):expr='('+expr+'*'+expr+')'
        with self.assertRaises(InvalidGene):polynomial(parse_safe_python('def f(R,G,B):return '+expr)['program'])
    def test_search_budget_strict(self):
        r=repair_with_reference('def f(R,G,B):return R+B','def r(R,G,B):return R-B',max_candidates=1)
        self.assertEqual(r['status'],'search_budget_exceeded')
    def test_irreparable_outside_edit_budget(self):
        r=repair_with_reference('def f(R,G,B):return R','def r(R,G,B):return (R*R)+(B*B)+(G*G)',max_candidates=15000)
        self.assertEqual(r['status'],'no_proven_repair')
    def test_exact_fraction_arithmetic(self):
        poly=polynomial(['PUSH_R','PUSH_G','ADD','PUSH_B','MUL','QUANTIZE','EMIT'])
        self.assertEqual(poly,{(1,0,1):Fraction(1),(0,1,1):Fraction(1)})
    def test_v02_old_tests_do_not_prove_equal(self):
        # One case can make the broken computation look correct; exact algebra rejects it.
        wrong='def f(R,G,B):return R+G'
        ref='def f(R,G,B):return R+B'
        samples=[{'R':i/10,'G':.4,'B':.4} for i in range(1,9)]
        a,b=parse_safe_python(wrong)['program'],parse_safe_python(ref)['program']
        self.assertTrue(all(execute_numeric(a,s)==execute_numeric(b,s) for s in samples))
        self.assertEqual(prove_polynomial(ref,wrong)['status'],'not_equivalent')
    def test_generated_python_execution_on_heldouts(self):
        r=repair_with_reference('def f(R,G,B):return R+B','def ref(R,G,B):return R-B')
        # Only generated, never user-supplied source is executed by the test harness.
        scope={'__builtins__':{}};exec(compile(r['proposed_source'],'<generated>','exec'),scope)
        rng=random.Random(3434)
        for i in range(250):
            x,y,z=[rng.uniform(-3,3) for _ in range(3)]
            self.assertAlmostEqual(scope['f'](x,y,z),x-z,places=12)
    def test_isolated_python_bridge_still_exists(self):
        from ripple_quad_repair.python_bridge import repair_python
        self.assertTrue(callable(repair_python))

class HTTPIntegration(unittest.TestCase):
    def test_formal_http(self):
        from ripple_quad_repair.webapp import Handler
        from http.server import ThreadingHTTPServer
        with ThreadingHTTPServer(('127.0.0.1',0),Handler) as server:
            t=threading.Thread(target=server.serve_forever,daemon=True);t.start()
            try:
                origin=f'http://127.0.0.1:{server.server_port}'
                with urllib.request.urlopen(origin+'/api/example_formal') as response:
                    example=json.load(response)
                req=urllib.request.Request(origin+'/api/repair_formal',
                      data=json.dumps(example).encode(),headers={'Content-Type':'application/json'},method='POST')
                with urllib.request.urlopen(req) as response:result=json.load(response)
                self.assertEqual(result['status'],'proven_in_exact_real_polynomial_model')
                with urllib.request.urlopen(origin) as response:
                    page=response.read().decode()
                    self.assertIn('formal_repair',page)
            finally:server.shutdown();t.join()

if __name__=='__main__':unittest.main()
