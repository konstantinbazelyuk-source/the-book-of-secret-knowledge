"""Reproducible bounded program-repair study with objective and failures recorded."""
from pathlib import Path
import time,json,hashlib,random,sys,platform
from ripple_quad_repair.python_bridge import parse_safe_python,render_safe_python
from ripple_quad_repair.formal import prove_polynomial,repair_with_reference

ROOT=Path(__file__).resolve().parent.parent
REFS=['R - B','R + G','(R+B)*G','R*G - B','(R-G)*(B+R)','R*R + G*B']
results=[]
start=time.perf_counter()
for i,expr in enumerate(REFS):
    reference=f'def reference(R,G,B):\n    return {expr}\n'
    orig=parse_safe_python(reference)['program']
    for j,op in enumerate(orig[:-2]):
        if op not in ('ADD','SUB','MUL'):continue
        for other in ('ADD','SUB','MUL'):
            if other==op:continue
            wrong=orig.copy();wrong[j]=other
            broken=render_safe_python('f',wrong)
            taskstart=time.perf_counter()
            ans=repair_with_reference(broken,reference,structural=False)
            elapsed_ms=(time.perf_counter()-taskstart)*1000
            status=ans['status']
            expected_success=(status=='proven_in_exact_real_polynomial_model')
            results.append({'reference_id':i,'fault_instruction':j,'from':other,'intended':op,
                'status':status,'candidate_edit_cost':ans.get('edit_cost'),
                'candidate_count':ans.get('algebraically_equivalent_minimum_cost_candidates'),
                'tested_candidates':ans.get('evaluated'),
                'repair_proof_checked':expected_success and prove_polynomial(reference,ans['proposed_source'])['status']=='proved_equal_in_exact_real_polynomial_model',
                'ms':round(elapsed_ms,5)})

# Deliberately crafted correlated fixtures: a test-only system cannot distinguish R+G and R+B when G=B.
# Exact polynomial comparison rejects equivalence for the two different expressions.
correlated_ref='def f(R,G,B):return R+B'
correlated_bad='def f(R,G,B):return R+G'
values=[(.1,.2,.2),(.3,.4,.4),(.8,.6,.6)]
sample_equal=all((r+g)==(r+b) for r,g,b in values)
formal_difference=prove_polynomial(correlated_ref,correlated_bad)

# IEEE-754 nonassociativity negative control: mathematical equality does not imply exact execution equality.
# (R+G)+B vs R+(G+B) on float input (1e16,-1e16,1).
ref_float='def f(R,G,B):return (R+G)+B'
alt_float='def f(R,G,B):return R+(G+B)'
exact_equivalence=prove_polynomial(ref_float,alt_float)
r,g,b=1e16,-1e16,1.0
float_results=[(r+g)+b,r+(g+b)]
summary={'schema':'ripple-quad-formal-study/0.3','environment':{'python':sys.version.split()[0],'platform':platform.platform()},
 'source_references':{'legacy_quad_sha256':hashlib.sha256((ROOT/'reference/quaternary-core.mjs').read_bytes()).hexdigest(),
 'legacy_rpr_sha256':hashlib.sha256((ROOT/'reference/ripple_repair_core_LOCKED.py').read_bytes()).hexdigest()},
 'mutant_count':len(results),'proved_repairs':sum(z['repair_proof_checked'] for z in results),
 'no_proven_repair':sum(z['status']=='no_proven_repair' for z in results),
 'other_failures':sum(z['status'] not in ('proven_in_exact_real_polynomial_model','no_proven_repair') for z in results),
 'milliseconds_all':round((time.perf_counter()-start)*1000,2),'mutants':results,
 'correlated_fixture_control':{'all_three_fixtures_match':sample_equal,'exact_polynomials_equal':formal_difference['status']=='proved_equal_in_exact_real_polynomial_model',
  'witness':formal_difference['counterexample']},
 'float_nonassociativity_control':{'exact_real_polynomials_equal':exact_equivalence['status']=='proved_equal_in_exact_real_polynomial_model',
 'computed_binary64_outputs':float_results,'binary64_outputs_equal':float_results[0]==float_results[1]},
 'scope_note':'Mutants are program-generated within the grammar; no arbitrary production source or real-world device tested.'}
if not (summary['proved_repairs']==summary['mutant_count'] and sample_equal and formal_difference['status']=='not_equivalent' and summary['float_nonassociativity_control']['exact_real_polynomials_equal'] and float_results[0]!=float_results[1]):
    raise SystemExit('Verification failed; consult recorded mutant outcomes')
out=ROOT/'results/formal_study.json';out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(summary,indent=2))
print(json.dumps({k:v for k,v in summary.items() if k not in ('mutants','source_references')},indent=2))
