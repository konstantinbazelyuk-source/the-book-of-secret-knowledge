"""Ripple Quad-Gene local app entry for normal Python and PyInstaller Windows."""
import argparse,threading,webbrowser
from ripple_quad_repair.webapp import serve

if __name__=='__main__':
    p=argparse.ArgumentParser(description='Ripple Quad-Gene Repair locally served UI')
    p.add_argument('--port',type=int,default=8887)
    p.add_argument('--no-browser',action='store_true')
    args=p.parse_args()
    if not args.no_browser:
        threading.Timer(1.25,lambda:webbrowser.open('http://127.0.0.1:'+str(args.port)+'/')).start()
    serve('127.0.0.1',args.port)
