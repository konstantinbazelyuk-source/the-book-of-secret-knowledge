@echo off
cd /d "%~dp0"
python -m ripple_repair serve --port 8879 --workspace "repair_workspace"
