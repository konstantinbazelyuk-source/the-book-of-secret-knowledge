# Local only: writes OS, CPU, memory and GPU discovery to JSON next to this script.
# Does not change hardware configuration, network accounts or Windows Registry.
$machine = Get-CimInstance Win32_ComputerSystem
$cpu = Get-CimInstance Win32_Processor | Select-Object Name,NumberOfCores,NumberOfLogicalProcessors
$gpu = Get-CimInstance Win32_VideoController | Select-Object Name,AdapterRAM,DriverVersion
$disk = Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" | Select-Object DeviceID,Size,FreeSpace
$entry = [ordered]@{timestamp=(Get-Date).ToString('o');hostname=$env:COMPUTERNAME;manufacturer=$machine.Manufacturer;model=$machine.Model;os=[System.Environment]::OSVersion.VersionString;ram_bytes=[int64]$machine.TotalPhysicalMemory;cpu=$cpu;gpu=$gpu;disks=$disk}
$path = Join-Path $PSScriptRoot 'dell_detected_hardware.json'
$entry | ConvertTo-Json -Depth 6 | Out-File -Encoding utf8 $path
Write-Host "Saved actual locally reported hardware details to $path"
