# Repair-only Ripple mathematical and scientific study

## Research evidence and biological analogy

The biological analogy is *template-directed mismatch repair*, not cell-regeneration technology. The source (Alberts et al., Molecular Biology of the Cell, NCBI Bookshelf, https://www.ncbi.nlm.nih.gov/books/NBK26850/) explains why recognizing a mismatch is insufficient: the correct reference strand must be selected to avoid replacing correct information with the incorrect strand. The digital analogue is a known original SHA-256 and previously encoded redundant parity.

Reed–Solomon erasure codes: William A. Geisel, NASA Technical Memorandum 102162 (1990), https://ntrs.nasa.gov/citations/19900019023. It describes operations over Galois fields and systematic error-correcting parity. The current code uses a specific systematic **Cauchy** 4+2 erasure code over GF(2^8), not NASA's literal example implementation.

SQLite persistent event records: https://www.sqlite.org/atomiccommit.html and https://www.sqlite.org/wal.html. Our app uses SQLite transactions for diagnostics; SQLite integrity does not reconstruct bytes inside an unrelated damaged file.

## Precise implemented equations

Field F=GF(2^8) modulo primitive polynomial `z^8+z^4+z^3+z^2+1` (hex 0x11d). For nonzero field elements, `a*b=exp[(log a + log b) mod 255]`.

The systematic generator matrix:

```
G = [I_4]
    [ C ]           C_ij = (x_i XOR y_j) ^ (-1)    (GF inverse)

x = (1, 2), y = (16, 17, 18, 19)
```

For four source shards `D_0..D_3`, parity shards `P_i = XOR_j C_ij * D_j`, applied per byte index. Under ≤2 corrupted shards in any one six-shard stripe, choose any four of the remaining verified rows, invert the 4×4 matrix and solve `D=G_surv^{-1} S_surv`. Code verifies all six reconstructed SHA-256 shard digests and exact final file SHA-256, not merely plausible file headers.

Each stripe includes 4×65536 original-byte positions and 2×65536 parity-byte positions. Padding is removed using the stored original byte length after validating the file hash. The format stores a header digest and per-stripe checksums; the archive is **not signed**. If attackers can rewrite the header and all checksums, they can redefine the expected content. This is a fundamental integrity/authenticity distinction.

## Pair repair mathematical states and actual contribution

`x_t = (# damaged shards found in the latest SHA scrub) / 6`, a real computed observation for inspected stripes. There is no estimate for uninspected stripes.

Daughter persistent state `d_{t+1}=0.82d_t+0.18x_t` tracks previously observed faults. Delta novelty `δ_{t+1}=|x_t-x_{t-1}|` responds to changes. Charlie-inspired priority `p_t=0.58d_t+0.27δ_t+0.15n_t`, where `n_t` is neighbor fault memory. An aging term ensures previously unseen areas are not permanently starved. These tunable coefficients are **engineered heuristics**, not measured biological parameters.

The scheduler selects which stripe to **check next** under a budget. The mathematical parity solver independently determines whether bytes are recoverable. This separation creates two distinct tests:
1. Causal ablations on fault revisit priority (disable persistent state, change state or neighbor signal).
2. Absolute byte correctness vs SHA-256 using 0–3 actual damaged shards, including negative controls.

The source-preserved historical Daughter triplet, Delta signed optical contrast and Charlie v2 are references only. Their operations were designed for RGB/synthetic neuron signals, not for authenticating bytes. Therefore this new repair-only neuron uses corresponding temporal concepts but a newly defined, explicitly typed fault-measurement law. Claiming the unchanged optical source is an active binary-file ECC decoder would be false.

## Falsifiable hypothesis and observed result

Hypothesis: after detecting a persistent damaged stripe and acquiring a full baseline, a limited-budget future scrub prioritizing stored Daughter/Delta states revisits damaged regions sooner than an unweighted round-robin selector. Prediction for crafted case: a previously damaged stripe 4 in a five-stripe archive is revisited first; a round-robin choice checks intact stripe 0 first. Executed test confirmed those two outcomes. This verifies the constructed scheduler operation, not general optimization under unknown fault distributions.

## Explicit non-results

There is no evidence that any model recovers unknown destroyed data without redundancy or a trustworthy replica; no claim of general intelligence, DNA editing, medical treatment or physical microscopy. If >2 shards per stripe are damaged, the repair function rejects. If the archive manifest is missing/tampered and cannot be trusted, decoding is rejected. A previously damaged source protected for the first time remains damaged after perfect reconstruction. Decryption and recovery from malicious forged manifest are unsupported.
