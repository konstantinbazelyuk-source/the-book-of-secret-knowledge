# Executed build and recovery evidence — Ripple Repair Cell v1.0

## Cloud build 39079464856 (GitHub Actions)

- Branch: `research/ripple-repair-cell-v1_0` in `konstantinbazelyuk-source/the-book-of-secret-knowledge`. Default branch unchanged.
- Run URL: https://github.com/konstantinbazelyuk-source/the-book-of-secret-knowledge/actions/runs/39079464856
- Source bundle SHA-256 (enforced in all three jobs): `17be9c3252fda975427fcdff67da7b721e38049618a7a0d952bae0d9a8e86856`.
- **Linux/Python** job passed full Python/JVM/HTTP tests, 28 controlled repair cases. This measures the software on a GitHub Linux virtual machine, not on the user's Dell or Samsung.
- **Windows** job built `RippleRepair.exe` with PyInstaller and then actually launched it on a Windows hosted runner. Test connected to `http://127.0.0.1:8879/` and matched the Ripple Repair HTML. Runner log emitted `WINDOWS EXECUTABLE BOOT/HTTP SMOKE PASS`. This verifies executable boot and local UI serving in that hosted environment, not actual Dell hardware.
- **Android** job compiled a native Java application with Android Gradle Plugin 8.7.3, Gradle 8.9, API 35, JDK 17. `apksigner verify` output: `Verified using v2 scheme (APK Signature Scheme v2): true`. `aapt dump badging` reported package `org.ripple.repair` version `1.0.0` compile SDK 35. No Android device, emulator, or UI automation was executed. It is a **debug APK**, not production signed.
- Earlier Windows packaging succeeded but a `--windowed` build failed HTTP startup smoke verification; the subsequent `--console` build passed the same test. Negative build outcome retained here, not silently discarded.
- Earlier Android builds failed because of third-party cloud SDK action configuration and `sdkmanager` PATH; correcting the SDK path produced a successful signed debug APK. These failures were environment/setup failures, not evidence that the decoder was wrong.

## Local mathematical and application tests

1. All 15 independent choose-4-of-6 generator row selections were invertible over GF(256); all 15 distinct two-erasure combinations restored identical shards.
2. 28 controlled fault cases across seven file sizes; 21 correct exact matches for 0–2 damaged shards; seven deliberate fail-closed 3-erasure cases. SHA-256 verified outputs.
3. Python↔Java encoding/decoding on empty, small, near-boundary and multi-stripe files, plus injected damaged shards.
4. Actual HTTP POST protect/check/repair and binary GET downloads, plus record persistence and wrong-origin rejection.
5. Non-destructive output creation (no overwrite) and rejection of tampered manifest, invalid archive, and unrecoverable excess damage.
6. Real data-scrub ablation: after prior damaged stripe 4, limited-budget adaptive revisit selected stripe 4 with bad shard, while round-robin picked intact stripe 0.
7. Original historical Daughter, Delta, Charlie and paired-source SHA-256 recorded and preserved. The repair-specific EWMA/novelty classes are **new**, not the old light-processing kernels mistakenly claimed as byte repair.

## Unfinished device gates

- Android application installation, SAF permission flows, lifecycle and duration under actual target phone, memory/thermal measurements: **not measured**.
- Dell model discovery, Windows Defender/SmartScreen handling, file-system type and sustained 8 MiB benchmark on actual laptop: **not measured**.
- Multi-process concurrent writer validation, crash-during-commit on Windows, malicious manifest forgery: **not validated**. SHA-256 is integrity checking, not source authentication. Keep original data and RPR archives separately.

## Next executable action

Install the debug APK on the actual Android device and protect, damage, repair and independently SHA-256-verify a harmless test file. On Dell, extract the verified Windows ZIP, run `RippleRepair.exe` from a writable user directory, confirm local UI appears, and repeat the same test. For longer-run durability, benchmark different storage media and simulate power interruptions with disposable archives, keeping both raw results and failures.
