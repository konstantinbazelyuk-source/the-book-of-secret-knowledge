from __future__ import annotations
import argparse,json,sys,traceback
from pathlib import Path
from .core import protect,repair,inspect,inject_fault
from .colony import RepairColony

def main(argv=None):
    ap=argparse.ArgumentParser(prog='ripple-repair',description='Protect, inspect and reconstruct actual bytes using error correcting redundancy')
    sub=ap.add_subparsers(dest='command',required=True)
    for cmd in ('protect','repair'):
        p=sub.add_parser(cmd);p.add_argument('source');p.add_argument('--out',required=True);p.add_argument('--db')
    p=sub.add_parser('check');p.add_argument('source');p.add_argument('--db')
    p=sub.add_parser('scrub');p.add_argument('source');p.add_argument('--db',default='repair_history.sqlite');p.add_argument('--budget',type=int,default=8);p.add_argument('--mode',choices=['adaptive','roundrobin','no_delta','no_daughter','no_neighbor'],default='adaptive')
    p=sub.add_parser('fault-demo');p.add_argument('source');p.add_argument('--out',required=True);p.add_argument('--stripe',type=int,default=0);p.add_argument('--shards',type=int,nargs='+',default=[0]);p.add_argument('--position',type=int,default=1024)
    p=sub.add_parser('serve');p.add_argument('--host',default='127.0.0.1');p.add_argument('--port',type=int,default=8879);p.add_argument('--workspace',default='repair_workspace')
    args=ap.parse_args(argv)
    if args.command=='serve':
        from .server import serve
        serve(args.host,args.port,args.workspace);return 0
    try:
        if args.command=='protect':r=protect(args.source,args.out)
        elif args.command=='repair':r=repair(args.source,args.out)
        elif args.command=='check':r=inspect(args.source)
        elif args.command=='scrub':r=RepairColony(args.db).scrub(args.source,args.budget,args.mode)
        else:r=inject_fault(args.source,args.out,[(args.stripe,s,args.position) for s in args.shards])
        if getattr(args,'db',None) and args.command in ('protect','repair','check'):RepairColony(args.db).log_action(args.source,args.command,r)
        print(json.dumps(r,indent=2));return 2 if r.get('status')=='unrecoverable' else 0
    except (ValueError,OSError,RuntimeError) as e:
        print(json.dumps({'status':'failed','type':type(e).__name__,'reason':str(e)}),file=sys.stderr);return 2

def entry():sys.exit(main())
if __name__=='__main__':entry()
