"""Local only browser interface: real protect/check/recover actions, not a mock UI."""
import json,io,uuid,os,hashlib,sys
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from urllib.parse import urlparse,parse_qs,quote
from pathlib import Path
from .core import protect,repair,inspect,InvalidArchive,Unrecoverable
from .colony import RepairColony

HERE=(Path(getattr(sys,'_MEIPASS')) if hasattr(sys,'_MEIPASS') else Path(__file__).resolve().parent.parent)/'web'
MAX_UPLOAD=32*1024*1024

def serve(host='127.0.0.1',port=8879,workspace='repair_workspace'):
    if host not in {'127.0.0.1','localhost','::1'}:raise ValueError('Only loopback interface supported')
    root=Path(workspace).resolve();root.mkdir(parents=True,exist_ok=True)
    db=RepairColony(root/'activity.sqlite')
    downloads={}
    class Handler(BaseHTTPRequestHandler):
        def _headers(self,n,typ='application/json',name=None):
            self.send_response(200);self.send_header('Content-Type',typ)
            self.send_header('Content-Length',str(n));self.send_header('Cache-Control','no-store')
            self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Content-Security-Policy',"default-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
            if name:self.send_header('Content-Disposition',"attachment; filename*=UTF-8''"+quote(name))
            self.end_headers()
        def _json(self,obj):
            raw=json.dumps(obj,sort_keys=True).encode();self._headers(len(raw));self.wfile.write(raw)
        def do_GET(self):
            path=urlparse(self.path).path
            if path=='/api/history':
                with db.conn() as c:
                    rows=c.execute('SELECT action,status,recorded_at,result_json FROM repair_log ORDER BY id DESC LIMIT 30').fetchall()
                self._json({'actions':[{'action':a,'status':s,'time':t,'result':json.loads(j)} for a,s,t,j in rows]});return
            if path.startswith('/download/'):
                token=path.split('/')[-1];item=downloads.get(token)
                if not item:
                    self.send_error(404);return
                p,filename=item
                if not p.is_file():self.send_error(404);return
                self._headers(p.stat().st_size,'application/octet-stream',filename)
                with p.open('rb') as f:
                    for block in iter(lambda:f.read(262144),b''):self.wfile.write(block)
                return
            if path=='/':path='/index.html'
            if path not in {'/index.html','/site.css','/site.js','/manifest.webmanifest','/sw.js'}:
                self.send_error(404);return
            p=HERE/path.lstrip('/')
            if not p.is_file():self.send_error(404);return
            typ={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'application/javascript; charset=utf-8','.webmanifest':'application/manifest+json'}[p.suffix]
            content=p.read_bytes();self._headers(len(content),typ);self.wfile.write(content)
        def do_POST(self):
            path=urlparse(self.path).path
            if path not in {'/api/protect','/api/check','/api/repair'}:self.send_error(404);return
            origin=self.headers.get('Origin','')
            if origin and origin not in {f'http://127.0.0.1:{port}',f'http://localhost:{port}'}:
                self.send_error(403,'Origin denied');return
            try: size=int(self.headers.get('Content-Length','-1'))
            except ValueError:self.send_error(400,'Missing body length');return
            if size<0 or size>MAX_UPLOAD:self.send_error(413,'Upload exceeds 32 MiB');return
            request_id=uuid.uuid4().hex
            original=parse_qs(urlparse(self.path).query).get('name',['input.bin'])[0]
            basename=os.path.basename(original.replace('\\','/'))[:120] or 'input.bin'
            src=root/(request_id+'.incoming');src.write_bytes(self.rfile.read(size))
            output=None
            try:
                if src.stat().st_size!=size:raise ValueError('Incomplete HTTP upload')
                if path=='/api/protect':
                    # Avoid forcing the source filename to UUID; the input name only
                    # becomes metadata, not a filesystem destination.
                    named=root/(request_id+'_'+basename);src.rename(named);src=named
                    output=root/(request_id+'.rpr')
                    result=protect(src,output);filename=basename+'.rpr'
                elif path=='/api/check':result=inspect(src);filename=None
                else:
                    output=root/(request_id+'_recovered.bin')
                    result=repair(src,output);filename='verified_'+basename.removesuffix('.rpr')
                if output:
                    token=uuid.uuid4().hex;downloads[token]=(output,filename)
                    result['download']='/download/'+token;result['download_name']=filename
                db.log_action(basename,path.split('/')[-1],result)
                self._json(result)
            except (InvalidArchive,Unrecoverable,ValueError,OSError) as e:
                result={'status':'rejected','reason':str(e),'type':type(e).__name__}
                db.log_action(basename,path.split('/')[-1],result);self._json(result)
            finally:src.unlink(missing_ok=True)
    h=ThreadingHTTPServer((host,port),Handler)
    print(f'Ripple Repair — actual local file engine at http://127.0.0.1:{port}',flush=True)
    try:h.serve_forever()
    except KeyboardInterrupt:pass
    finally:h.server_close()
