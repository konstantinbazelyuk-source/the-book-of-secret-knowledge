"""Stateful Daughter/Delta-inspired repair-neuron colony for file integrity scrubbing.

Two mathematical observers per stripe: Daughter tracks persistent damage by EWMA;
Delta tracks transitions; neighboring repair pairs share bounded evidence.
The scores prioritize actual SHA-256 inspection, never reconstruct unknown bytes.
"""
import math,sqlite3,time,json
from pathlib import Path
from .core import _header,sha,SHARD_SIZE,N,M

DECAY_D=0.82

def transition(previous_damage,previous_value,observation,neighbor=0.0):
    """dt=1 observation tick; zero/new observation bounded to [0,1]."""
    if not 0<=observation<=1 or not 0<=neighbor<=1:raise ValueError('Invalid diagnostic channel')
    d=DECAY_D*previous_damage+(1-DECAY_D)*observation
    delta=abs(observation-previous_value)
    risk=min(1.0,0.58*d+0.27*delta+0.15*neighbor)
    return {'daughter':d,'delta':delta,'risk':risk,'previous':observation}

class RepairColony:
    def __init__(self,db):
        self.db=str(db)
        with self.conn() as c:
            c.execute('''CREATE TABLE IF NOT EXISTS shard_state (
            archive TEXT NOT NULL, stripe INTEGER NOT NULL, daughter REAL NOT NULL DEFAULT 0,
            delta REAL NOT NULL DEFAULT 0, previous REAL NOT NULL DEFAULT 0,
            risk REAL NOT NULL DEFAULT 0, last_seq INTEGER NOT NULL DEFAULT -1,
            observations INTEGER NOT NULL DEFAULT 0, PRIMARY KEY (archive,stripe))''')
            c.execute('''CREATE TABLE IF NOT EXISTS scrub_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT, archive TEXT NOT NULL, stripe INTEGER NOT NULL,
            bad_shards TEXT NOT NULL, priority REAL NOT NULL, unix_time REAL NOT NULL,
            status TEXT NOT NULL)''')
            c.execute('''CREATE TABLE IF NOT EXISTS repair_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT, path TEXT, action TEXT, status TEXT,
            recorded_at REAL, result_json TEXT)''')
    def conn(self):
        c=sqlite3.connect(self.db,timeout=15)
        c.execute('PRAGMA busy_timeout=15000')
        return c
    def log_action(self,path,action,result):
        with self.conn() as c:
            c.execute('INSERT INTO repair_log (path,action,status,recorded_at,result_json) VALUES (?,?,?,?,?)',
                  (str(path),action,str(result.get('status','error')),time.time(),json.dumps(result,sort_keys=True)))
    def scrub(self,archive,budget=8,mode='adaptive'):
        archive=Path(archive).resolve()
        if mode not in ('adaptive','roundrobin','no_delta','no_daughter','no_neighbor'):raise ValueError('Invalid scheduler')
        if budget<=0:raise ValueError('Positive scrub budget needed')
        with archive.open('rb') as f:
            h=_header(f);payload=f.tell()
            total=len(h['stripes']);archive_key=sha(archive.name.encode())+':'+str(archive)
            with self.conn() as c:
                for i in range(total):
                    c.execute('INSERT OR IGNORE INTO shard_state (archive,stripe) VALUES (?,?)',(archive_key,i))
                rows=c.execute('SELECT stripe,daughter,delta,previous,risk,last_seq,observations FROM shard_state WHERE archive=? ORDER BY stripe',(archive_key,)).fetchall()
                state={row[0]:row[1:] for row in rows}
                seq=(c.execute('SELECT COALESCE(MAX(id),0) FROM scrub_log').fetchone()[0])+1
                def priority(i):
                    daughter,delta,prev,risk,last,count=state[i]
                    left=state[i-1][0] if i>0 else 0
                    right=state[i+1][0] if i<total-1 else 0
                    neighbor=(left+right)*0.5
                    risk_p=(.65*risk+.35*neighbor) if mode=='adaptive' else ((.65*risk+.35*neighbor) if mode=='roundrobin' else (.58*daughter+.15*neighbor if mode=='no_delta' else .27*delta+.15*neighbor if mode=='no_daughter' else .58*daughter+.27*delta))
                    # unvisited stripes get guaranteed immediate servicing. A bounded
                    # aging term prevents a damaged neighbor monopolizing the scrub.
                    age=2.0 if last<0 else min(1.6,(seq-last)/max(1,total)*0.1)
                    return risk_p+age
                if mode!='roundrobin':selection=sorted(range(total),key=lambda i:(-priority(i),i))[:min(budget,total)]
                else:selection=sorted(range(total),key=lambda i:(state[i][4],i))[:min(budget,total)]
                details=[]
                for i in selection:
                    f.seek(payload+i*N*SHARD_SIZE)
                    bad=[]
                    for j in range(N):
                        b=f.read(SHARD_SIZE)
                        if len(b)!=SHARD_SIZE or sha(b)!=h['stripes'][i][j]:bad.append(j)
                    prev=state[i]; observation=len(bad)/N
                    neighbor=(state.get(i-1,(0,))[0]+state.get(i+1,(0,))[0])*0.5
                    next_state=transition(prev[0],prev[2],observation,neighbor)
                    p=priority(i)
                    c.execute('''UPDATE shard_state SET daughter=?,delta=?,previous=?,risk=?,last_seq=?,observations=observations+1 WHERE archive=? AND stripe=?''',
                         (next_state['daughter'],next_state['delta'],next_state['previous'],next_state['risk'],seq,archive_key,i))
                    status='unrecoverable' if len(bad)>M else 'damaged_recoverable' if bad else 'intact'
                    c.execute('INSERT INTO scrub_log (archive,stripe,bad_shards,priority,unix_time,status) VALUES (?,?,?,?,?,?)',
                           (archive_key,i,json.dumps(bad),p,time.time(),status))
                    details.append({'stripe':i,'bad_shards':bad,'status':status,'priority':round(p,6),
                         'daughter':round(next_state['daughter'],6),'delta':round(next_state['delta'],6),'risk':round(next_state['risk'],6)})
        return {'status':'completed','scheduler':mode,'scrubbed':len(details),'total_stripes':total,'observations':details,
            'damaged_detected':sum(bool(x['bad_shards']) for x in details),'not_inspected':total-len(details)}
