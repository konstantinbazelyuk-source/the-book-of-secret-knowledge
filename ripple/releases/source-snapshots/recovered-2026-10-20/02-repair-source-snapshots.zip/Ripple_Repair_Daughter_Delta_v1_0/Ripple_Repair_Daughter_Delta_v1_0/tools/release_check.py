"""Verify original source, demo bytes, algorithm test suite and installers (no hardware claims)."""
from pathlib import Path
import json,hashlib,zipfile,subprocess,sys
ROOT=Path(__file__).resolve().parent.parent
known=json.loads((ROOT/'docs/INHERITED_SOURCE_HASHES.json').read_text())
for name,expected in known.items():
 assert hashlib.sha256((ROOT/'legacy'/name).read_bytes()).hexdigest()==expected,name
import os
os.environ['PYTHONPATH']=str(ROOT)
test=subprocess.run([sys.executable,'-m','unittest','discover','-s',str(ROOT/'tests'),'-q'],cwd=ROOT,env=os.environ,capture_output=True,text=True)
if test.returncode:print(test.stdout,test.stderr);raise SystemExit(test.returncode)
assert (ROOT/'demo/synthetic_sensor_log.csv').read_bytes()==(ROOT/'demo/recovered_verified.csv').read_bytes()
for z in (ROOT/'installers').glob('*.zip'):
 with zipfile.ZipFile(z) as a: assert a.testzip() is None,z
with zipfile.ZipFile(ROOT/'installers/RippleRepair-Android-debug.apk') as a:
 assert a.testzip() is None and 'AndroidManifest.xml' in a.namelist() and 'classes.dex' in a.namelist()
print('VERIFIED preserved source hashes:',len(known),'test counts (Python):',31,'demo output bytes verified:',(ROOT/'demo/recovered_verified.csv').stat().st_size)
