"""Measured software recovery study: real bytes, deliberately injected artificial faults."""
import os,sys,time,json,hashlib,statistics,tempfile,random,platform
from pathlib import Path
from ripple_repair import protect,repair,inspect,inject_fault,Unrecoverable
from ripple_repair.colony import RepairColony
from ripple_repair.core import K,SHARD_SIZE

def run(destination):
    out=Path(destination);out.mkdir(parents=True,exist_ok=True)
    cases=[];rng=random.Random(91208)
    with tempfile.TemporaryDirectory() as t:
        p=Path(t)
        for size in (0,1024,180000,300000,550000,850000,1500000):
            original=rng.randbytes(size);src=p/'original.bin';src.write_bytes(original)
            a=p/'archive.rpr';ta=time.perf_counter();a_result=protect(src,a);protect_ms=(time.perf_counter()-ta)*1e3
            stripe_total=a_result['stripes']
            for damage_count in (0,1,2,3):
                bad=p/'fault.rpr'
                if damage_count==0:source=a
                else:
                    inject_fault(a,bad,[(0,j,j*71+7) for j in range(damage_count)])
                    source=bad
                ti=time.perf_counter();status=inspect(source);inspect_ms=(time.perf_counter()-ti)*1e3
                fixed=p/'recovered.bin';tr=time.perf_counter()
                try:
                    r=repair(source,fixed);success=fixed.read_bytes()==original
                except Unrecoverable as e:
                    r={'status':'unrecoverable','reason':str(e)};success=False
                recover_ms=(time.perf_counter()-tr)*1e3
                expectation=damage_count<=2
                assert success==expectation,(size,damage_count,r)
                cases.append({'input_bytes':size,'damage_shards':damage_count,'stripes':stripe_total,
                     'archive_bytes':a_result['protected_bytes'],'inspection_status':status['status'],
                     'repair_status':r['status'],'exact_match':success,
                     'protect_ms':round(protect_ms,3),'inspect_ms':round(inspect_ms,3),
                     'repair_ms':round(recover_ms,3),'method':'real bytes + artificial byte-flip injection'})
                if fixed.exists():fixed.unlink()
                if bad.exists():bad.unlink()
            a.unlink();src.unlink()
    # Independently demonstrate logged neuron scheduling ablation on actual damaged file
    with tempfile.TemporaryDirectory() as t:
        p=Path(t);source=p/'data';source.write_bytes(rng.randbytes(1100000))
        archive=p/'archive.rpr';protect(source,archive)
        bad=p/'bad.rpr';inject_fault(archive,bad,[(4,1,1337)])
        adaptive=RepairColony(out/'scrub_adaptive.sqlite');roundrobin=RepairColony(out/'scrub_roundrobin.sqlite')
        adaptive.scrub(bad,6,'adaptive');roundrobin.scrub(bad,6,'roundrobin')
        adaptive_next=adaptive.scrub(bad,1,'adaptive')['observations'][0]
        roundrobin_next=roundrobin.scrub(bad,1,'roundrobin')['observations'][0]
        assert adaptive_next['stripe']==4 and adaptive_next['bad_shards']
        assert roundrobin_next['stripe']!=4 and not roundrobin_next['bad_shards']
    result={'label':'SOFTWARE_MEASURED / FAULTS ARTIFICIALLY INJECTED','os':platform.platform(),
         'python':platform.python_version(),'cases':cases,
         'recovery_cases_correct':sum((x['exact_match']==(x['damage_shards']<=2)) for x in cases),
         'total_cases':len(cases), 'positive_repair_cases':sum(x['exact_match'] and x['damage_shards']>0 for x in cases),
         'negative_rejection_cases':sum(x['repair_status']=='unrecoverable' for x in cases),
         'median_repair_ms_success':round(statistics.median(x['repair_ms'] for x in cases if x['exact_match']),3),
         'repair_neuron_ablation':{'adaptive_next':adaptive_next,'roundrobin_next':roundrobin_next,
               'interpretation':'After identical complete first scans, adaptive revisit probes previously damaged stripe while round-robin probes intact stripe.'}}
    (out/'experiment.json').write_text(json.dumps(result,indent=2))
    print(json.dumps({k:v for k,v in result.items() if k not in {'cases','os'}},indent=2))
    return result
if __name__=='__main__':run(sys.argv[1] if len(sys.argv)>1 else 'results')
