"""Windows/Dell one-file desktop launcher; browser is only the user interface."""
import webbrowser,threading,time,os
from pathlib import Path
from ripple_repair.server import serve

def open_browser():
    time.sleep(1.1)
    webbrowser.open('http://127.0.0.1:8879')
if __name__=='__main__':
    threading.Thread(target=open_browser,daemon=True).start()
    work=Path.home()/'RippleRepairData'
    serve('127.0.0.1',8879,str(work))
