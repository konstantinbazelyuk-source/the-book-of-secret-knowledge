#!/usr/bin/env sh
cd "$(dirname "$0")" || exit 1
python3 -m ripple_repair serve --port 8879 --workspace repair_workspace
