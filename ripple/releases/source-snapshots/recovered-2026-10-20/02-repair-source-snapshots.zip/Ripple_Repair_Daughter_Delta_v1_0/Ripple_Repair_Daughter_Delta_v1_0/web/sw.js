'use strict';const CACHE='ripple-repair-ui-v1';const FILES=['/','/index.html','/site.css','/site.js','/manifest.webmanifest'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES)));self.skipWaiting()});
self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));
self.addEventListener('fetch',e=>{if(e.request.method!=='GET'||new URL(e.request.url).pathname.startsWith('/api/')||new URL(e.request.url).pathname.startsWith('/download/'))return;
e.respondWith(fetch(e.request).catch(()=>caches.match(e.request)))});
