'use strict';
async function execute(kind,elementId){
 const file=document.getElementById(elementId).files[0];
 const status=document.getElementById('status'), log=document.getElementById('log'), dl=document.getElementById('download');
 if(!file){status.textContent='Choose a file first.';return}
 if(file.size>32*1024*1024){status.textContent='File too large for web upload. Use the desktop CLI.';return}
 const controls=[...document.querySelectorAll('button')];controls.forEach(x=>x.disabled=true);
 dl.textContent='';status.textContent='Processing real file locally…';log.textContent='';
 try{
  const response=await fetch('/api/'+kind+'?name='+encodeURIComponent(file.name),{method:'POST',body:file,headers:{'Content-Type':'application/octet-stream'}});
  if(!response.ok)throw new Error('HTTP '+response.status);
  const result=await response.json();status.textContent='Status: '+result.status;log.textContent=JSON.stringify(result,null,2);
  if(result.download){const a=document.createElement('a');a.href=result.download;a.download=result.download_name;a.textContent='Download '+result.download_name;dl.appendChild(a)}
 }catch(err){status.textContent='Error: '+err.message;log.textContent=String(err)}finally{controls.forEach(x=>x.disabled=false)}
}
document.getElementById('protectBtn').addEventListener('click',()=>execute('protect','protectFile'));
document.getElementById('inspectBtn').addEventListener('click',()=>execute('check','inspectFile'));
document.getElementById('repairBtn').addEventListener('click',()=>execute('repair','repairFile'));
if('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(()=>{});
