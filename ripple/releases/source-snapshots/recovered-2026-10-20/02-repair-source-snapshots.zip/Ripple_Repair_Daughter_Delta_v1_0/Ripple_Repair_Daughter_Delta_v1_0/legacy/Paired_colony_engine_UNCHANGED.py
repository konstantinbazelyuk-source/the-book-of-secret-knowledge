"""Eight Daughter/Delta pairs with eight Charlie v2 supervisors.
Four *pairs of pairs* confirm simulated surface-change incidents.
Every model's hidden truth stays in evaluator, not the controller.
"""
import json,math,random,subprocess
from dataclasses import dataclass
from pathlib import Path
from charlie_core.neuron import CharlieNeuron
ROOT=Path(__file__).resolve().parents[1]
WEIGHTS=json.loads((ROOT/'legacy/v2_trained_core_state_LOCKED.json').read_text())['weights']
MODES=('full','grow','cross_only','feedback_only','local','unpaired','charlie_only','static')
@dataclass(frozen=True)
class Incident:
    group:int; start:int; end:int
@dataclass
class Case:
    seed:int; frames:list; truth:list; dt:float=.1; regime:str="standard"

def make_case(seed,steps=90,regime="standard"):
    if regime not in ("standard","low_contrast","high_noise","short_events","slow_pair","polarity_shift","correlated_decoy"):
        raise ValueError("unknown regime")
    if not isinstance(seed,int) or steps<45:raise ValueError('invalid scenario')
    r=random.Random(seed);events=[]
    for g in r.sample(range(4),2):
        st=r.randrange(9,steps-21);events.append(Incident(g,st,st+r.randrange(5,8) if regime=="short_events" else st+r.randrange(10,18)))
    flashes=[(i,r.randrange(3,steps-3),r.choice((1,2))) for i in range(8) for _ in range(2)]
    lone=r.randrange(8);lone_start=r.randrange(8,steps-18)
    frames=[]
    for t in range(steps):
        obs=[]
        for i in range(8):
            anomalous=any(e.group==i//2 and e.start<=t<e.end for e in events)
            anomalous |= any(site==i and st<=t<st+duration for site,st,duration in flashes)
            anomalous |= i==lone and lone_start<=t<lone_start+9
            if regime=="correlated_decoy" and i//2==3 and 2<=t<7:anomalous=True
            base=((.04,.10,.83) if regime=="polarity_shift" else (.47,.46,.20) if regime=="low_contrast" else (.82,.73,.04)) if anomalous else (.08,.16,.66)
            obs.append([round(min(1.,max(0.,x+r.gauss(0,.125 if regime=="high_noise" else .055))),6) for x in base])
        frames.append(obs)
    return Case(seed,frames,events,regime=regime)

class PairBridge:
    def __enter__(self):
        self.p=subprocess.Popen(['node',str(ROOT/'paired_colony/pair_bridge.mjs')],cwd=ROOT,
          stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,bufsize=1)
        return self
    def send(self,msg):
        self.p.stdin.write(json.dumps(msg,allow_nan=False,separators=(',',':'))+'\n');self.p.stdin.flush()
        raw=self.p.stdout.readline()
        if not raw:raise RuntimeError('Node bridge stopped: '+self.p.stderr.read())
        res=json.loads(raw)
        if not res.get('ok'):raise ValueError(res.get('error'))
        return res
    def __exit__(self,*_):
        self.p.stdin.close();self.p.wait(timeout=5)
        errors=self.p.stderr.read();self.p.stdout.close();self.p.stderr.close()
        if self.p.returncode:raise RuntimeError(errors)

def run(case,mode='full',capture=False):
    if mode not in MODES:raise ValueError('invalid mode')
    neurons=[CharlieNeuron(weights=list(WEIGHTS)) for _ in range(8)]
    z=[0.]*8;consecutive=[0]*8;last_report=[-100]*4;group_latched=[False]*4;quiet=[0]*4;feedback=[0]*8
    alerts=[];trace=[];pair_spikes=charlie_spikes=deliveries=coupling=0
    active_groups={0} if mode=='grow' else set(range(4))
    pending_groups=[1,2,3]
    completed_jobs=0; births=[{'t':0,'group':0,'sites':[0,1]}] if mode=='grow' else []
    with PairBridge() as bridge:
        for t,frame in enumerate(case.frames):
            # Deterministic finite survey-work queue; not neural self-replication.
            # New pair instances are constructed by Node only after a queued work group activates.
            if mode=='grow' and pending_groups and completed_jobs>=12:
                group=pending_groups.pop(0);active_groups.add(group);completed_jobs=0
                births.append({'t':t,'group':group,'sites':[2*group,2*group+1]})
            active=[(i//2 in active_groups) for i in range(8)]
            if len(frame)!=8:raise ValueError('exactly eight site samples required')
            pairs=bridge.send({'command':'step','rgb':frame,'dt':case.dt,'feedback':feedback,
                'mode':mode if mode in ('full','grow','cross_only','feedback_only','local','unpaired') else 'unpaired',
                'active':active})['pairs'] if mode in ('full','grow','cross_only','feedback_only','local','unpaired') else None
            next_feedback=[];details=[]
            for i,rgb in enumerate(frame):
                if not active[i]:
                    next_feedback.append(0)
                    if capture:details.append({'site':i,'active':False,'score':0,'charlie_spike':0,'daughter_spike':0,'delta_spike':0,'cross_message':0,'quad_delta':None})
                    continue
                if len(rgb)!=3 or any(not math.isfinite(v) or v<0 or v>1 for v in rgb):raise ValueError('invalid input RGB')
                probability=neurons[i].probability(rgb) if mode!='static' else int(rgb[1]>.48 and rgb[2]<.23)
                fired=neurons[i].step(rgb,case.dt,exc_pulses=min(8,feedback[i]) if mode in ('full','feedback_only','grow') else 0)['count'] if mode!='static' else 0
                charlie_spikes+=fired;next_feedback.append(fired)
                p=pairs[i] if pairs else None
                if p:
                    pair_spikes+=p['delta']['count']+p['daughter']['count'];deliveries+=bool(p['received']['cross']);coupling+=bool(p['received']['local'])
                    dend=max(0.,min(1.,(p['daughter']['d']+.2)/1.9))
                    delta=max(0.,min(1.,p['delta']['change']/2.6))
                    input_score=.66*probability+.22*dend+.12*delta
                    boost=.045*fired+(.035*min(3,p['received']['cross']) if mode in ('full','cross_only','grow') else 0)
                else:input_score=probability;boost=.045*fired if mode=='charlie_only' else 0
                alpha=math.exp(-case.dt/.30) if mode!='static' else 0
                z[i]=max(0.,min(1.5,alpha*z[i]+(1-alpha)*input_score+boost))
                consecutive[i]=consecutive[i]+1 if z[i]>.55 else 0
                if capture:details.append({'site':i,'active':True,'score':round(z[i],6),'charlie_spike':fired,
                  'daughter_spike':p['daughter']['count'] if p else 0,'delta_spike':p['delta']['count'] if p else 0,
                  'cross_message':p['received']['cross'] if p else 0,
                  'quad_delta':p['delta']['quad'] if p else None})
            feedback=next_feedback
            if mode=='grow':completed_jobs+=len(active_groups)
            decisions=[]
            for group in range(4):
                a,b=group*2,group*2+1
                dwell=3 if mode=='static' else 2
                # Re-arm only after independent evidence from BOTH sites disappears.
                # Avoid reporting a single continuous event several times.
                if z[a]<.42 and z[b]<.42: quiet[group]+=1
                else: quiet[group]=0
                if group_latched[group] and quiet[group]>=3:group_latched[group]=False
                if not group_latched[group] and consecutive[a]>=dwell and consecutive[b]>=dwell and t-last_report[group]>=7:
                    alert={'t':t,'group':group,'action':'REQUEST_INSPECTION_SIMULATED','scores':[round(z[a],5),round(z[b],5)]}
                    alerts.append(alert);decisions.append(alert);last_report[group]=t;group_latched[group]=True
            if capture:trace.append({'t':t,'observations':'SIMULATED_RGB','decisions':decisions,'sites':details})
    matched=set();tp=fp=0;latency=[]
    for alert in alerts:
        valid=[(j,e) for j,e in enumerate(case.truth) if j not in matched and e.group==alert['group'] and e.start<=alert['t']<=e.end+3]
        if valid:
            j,e=valid[0];matched.add(j);tp+=1;latency.append(alert['t']-e.start)
        else:fp+=1
    return {'seed':case.seed,'regime':case.regime,'mode':mode,'steps':len(case.frames),'tp':tp,'fp':fp,'fn':len(case.truth)-tp,
      'pair_spikes':pair_spikes,'charlie_spikes':charlie_spikes,'cross_messages':deliveries,'local_messages':coupling,
      'mean_latency_steps':round(sum(latency)/len(latency),3) if latency else None,
      'alerts':alerts,'births':births,'active_pairs_final':len(active_groups)*2,'truth':[e.__dict__ for e in case.truth],'trace':trace}

def evaluate(seeds=None):
    seeds=[5,17,29,41,53,65,77,89] if seeds is None else seeds
    cases=[make_case(s) for s in seeds]
    results=[run(c,m) for c in cases for m in MODES]
    summary={}
    for mode in MODES:
        subset=[x for x in results if x['mode']==mode]
        counts={key:sum(x[key] for x in subset) for key in ('tp','fp','fn','pair_spikes','charlie_spikes','cross_messages','local_messages')}
        counts['precision']=round(counts['tp']/max(1,counts['tp']+counts['fp']),4)
        counts['recall']=round(counts['tp']/max(1,counts['tp']+counts['fn']),4)
        summary[mode]=counts
    return {'schema':'charlie-daughter-delta-colonized-pairs/1','evidence':'EXECUTED_SYNTHETIC_NUMERICAL',
      'paired_nodes':8,'daughter_nodes':8,'delta_nodes':8,'charlie_nodes':8,'groups':4,
      'seeds':seeds,'steps_per_scenario':90,'summary':summary,'runs':results}
