package org.ripple.repair;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import java.util.regex.*;
/** Pure Java / Android implementation of Python Ripple Repair RPR1 format.
 * Max user input 8MiB in Android activity. All data restored exactly via GF256.
 */
public final class RepairCodec {
  public static final int SIZE=65536,K=4,N=6,M=2;
  public static final int MAX_ARCHIVE=24*1024*1024;
  static final byte[] MAGIC=new byte[]{82,73,80,82,49,13,10,0};
  static final int[] EXP=new int[512],LOG=new int[256];
  static final int[][] G=new int[N][K];
  static {int x=1;for(int i=0;i<255;i++){EXP[i]=x;LOG[x]=i;x<<=1;if((x&256)!=0)x^=0x11d;}for(int i=255;i<512;i++)EXP[i]=EXP[i-255];for(int i=0;i<K;i++)G[i][i]=1;for(int i=0;i<M;i++)for(int j=0;j<K;j++)G[i+K][j]=inv((i+1)^(j+16));}
  static int mul(int a,int b){return (a==0||b==0)?0:EXP[(LOG[a]+LOG[b])%255];}
  static int inv(int a){if(a==0)throw new IllegalArgumentException("GF division by zero");return EXP[255-LOG[a]];}
  static byte[] combine(int[] coeff,byte[][] input){byte[] out=new byte[SIZE];for(int i=0;i<K;i++)if(coeff[i]!=0){int c=coeff[i];for(int j=0;j<SIZE;j++)out[j]^=(byte)mul(c,input[i][j]&255);}return out;}
  static byte[][] encodeStripe(byte[] data,int offset){byte[][] shards=new byte[N][SIZE];for(int i=0;i<K;i++){
   int from=offset+i*SIZE;int n=Math.min(SIZE,Math.max(0,data.length-from));if(n>0)System.arraycopy(data,from,shards[i],0,n);
  }for(int i=K;i<N;i++)shards[i]=combine(G[i],Arrays.copyOf(shards,K));return shards;}
  static int[][] inverse(int[][] source){int[][] x=new int[K][2*K];for(int i=0;i<K;i++){System.arraycopy(source[i],0,x[i],0,K);x[i][K+i]=1;}
   for(int col=0;col<K;col++){int pivot=col;while(pivot<K&&x[pivot][col]==0)pivot++;if(pivot==K)throw new IllegalStateException("Not enough independent shards");int[] tmp=x[col];x[col]=x[pivot];x[pivot]=tmp;
    int scale=inv(x[col][col]);for(int j=0;j<2*K;j++)x[col][j]=mul(x[col][j],scale);
    for(int r=0;r<K;r++){if(r==col)continue;int v=x[r][col];if(v!=0)for(int j=0;j<2*K;j++)x[r][j]^=mul(v,x[col][j]);}
   }int[][] result=new int[K][K];for(int i=0;i<K;i++)System.arraycopy(x[i],K,result[i],0,K);return result;}
  static byte[][] rebuild(byte[][] shards){int[] indices=new int[K];int found=0;for(int i=0;i<N&&found<K;i++)if(shards[i]!=null)indices[found++]=i;
   if(found<K)throw new IllegalArgumentException("More than two corrupted shards in a stripe");
   int[][] a=new int[K][K];byte[][] retained=new byte[K][];for(int i=0;i<K;i++){a[i]=G[indices[i]].clone();retained[i]=shards[indices[i]];}
   int[][] inv=inverse(a);byte[][] data=new byte[K][];for(int i=0;i<K;i++)data[i]=combine(inv[i],retained);
   byte[][] all=new byte[N][];System.arraycopy(data,0,all,0,K);for(int i=K;i<N;i++)all[i]=combine(G[i],data);return all;}
  static byte[] sha(byte[] data){try{return MessageDigest.getInstance("SHA-256").digest(data);}catch(Exception e){throw new IllegalStateException(e);}}
  static String hex(byte[] data){char[] chars="0123456789abcdef".toCharArray();char[] out=new char[data.length*2];for(int i=0;i<data.length;i++){out[2*i]=chars[(data[i]&255)>>4];out[2*i+1]=chars[data[i]&15];}return new String(out);}
  static String jsonString(String s){StringBuilder b=new StringBuilder("\"");for(char c:s.toCharArray()){
   if(c=='"'||c=='\\')b.append('\\').append(c);else if(c<32)b.append(String.format("\\u%04x",(int)c));else b.append(c);
  }return b.append('"').toString();}
  public static byte[] protect(byte[] original,String filename){if(original.length>8*1024*1024)throw new IllegalArgumentException("Android input limit is 8 MiB");
   StringBuilder stripes=new StringBuilder("[");ByteArrayOutputStream body=new ByteArrayOutputStream();
   int count=Math.max(1,(original.length+SIZE*K-1)/(SIZE*K));for(int stripe=0;stripe<count;stripe++){
    byte[][] encoded=encodeStripe(original,stripe*SIZE*K);if(stripe>0)stripes.append(',');stripes.append('[');
    for(int i=0;i<N;i++){if(i>0)stripes.append(',');stripes.append('"').append(hex(sha(encoded[i]))).append('"');body.write(encoded[i],0,SIZE);}
    stripes.append(']');
   }stripes.append(']');
   String clean=filename.replace('\\','_').replace('/','_');if(clean.isEmpty())clean="mobile.bin";
   String header="{\"file_sha256\":\""+hex(sha(original))+"\",\"filename\":"+jsonString(clean)+",\"k\":4,\"m\":2,\"schema\":\"ripple-repair/1\",\"shard_size\":65536,\"size\":"+original.length+",\"stripes\":"+stripes+"}";
   byte[] raw=header.getBytes(StandardCharsets.UTF_8);if(raw.length>16*1024*1024)throw new IllegalArgumentException("Header too large");
   ByteArrayOutputStream out=new ByteArrayOutputStream();try{out.write(MAGIC);out.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(raw.length).array());out.write(sha(raw));out.write(raw);body.writeTo(out);}catch(IOException e){throw new IllegalStateException(e);}return out.toByteArray();
  }
  static final Pattern HASH=Pattern.compile("\\\"([0-9a-f]{64})\\\"");
  static final Pattern GLOBAL=Pattern.compile("^\\{\\\"file_sha256\\\":\\\"([0-9a-f]{64})\\\",\\\"filename\\\":\\\"(?:\\\\.|[^\\\"\\\\])*\\\",\\\"k\\\":4,\\\"m\\\":2,\\\"schema\\\":\\\"ripple-repair/1\\\",\\\"shard_size\\\":65536,\\\"size\\\":([0-9]+),\\\"stripes\\\":(\\[.*\\])\\}$",Pattern.DOTALL);
  static class Header {long size;String expected;String[][] stripes;int start;}
  static Header parse(byte[] r){
   if(r.length<44)throw new IllegalArgumentException("Truncated archive");for(int i=0;i<8;i++)if(r[i]!=MAGIC[i])throw new IllegalArgumentException("Not RPR1");
   int n=ByteBuffer.wrap(r,8,4).order(ByteOrder.LITTLE_ENDIAN).getInt();if(n<=0||n>16*1024*1024||n>r.length-44)throw new IllegalArgumentException("Corrupt header length");
   byte[] raw=Arrays.copyOfRange(r,44,44+n);if(!Arrays.equals(sha(raw),Arrays.copyOfRange(r,12,44)))throw new IllegalArgumentException("Header checksum failure");
   String s=new String(raw,StandardCharsets.UTF_8);Matcher m=GLOBAL.matcher(s);if(!m.matches())throw new IllegalArgumentException("Unsupported or malformed header");
   Header h=new Header();h.expected=m.group(1);h.size=Long.parseLong(m.group(2));if(h.size<0||h.size>8*1024*1024)throw new IllegalArgumentException("File exceeds Android limit");
   String block=m.group(3);int count=Math.max(1,(int)((h.size+K*SIZE-1)/(K*SIZE)));
   Matcher group=Pattern.compile("\\[(?:\\\"[0-9a-f]{64}\\\",){5}\\\"[0-9a-f]{64}\\\"\\]").matcher(block);
   h.stripes=new String[count][N];int pos=1;for(int i=0;i<count;i++){
    if(!group.find(pos)||group.start()!=pos)throw new IllegalArgumentException("Malformed stripe manifest");
    Matcher hm=HASH.matcher(group.group());for(int j=0;j<N;j++){if(!hm.find())throw new IllegalArgumentException("Missing hash");h.stripes[i][j]=hm.group(1);}pos=group.end();
    if(i<count-1){if(pos>=block.length()||block.charAt(pos)!=',')throw new IllegalArgumentException("Bad stripe delimiter");pos++;}
   }if(pos!=block.length()-1||block.charAt(pos)!=']')throw new IllegalArgumentException("Unexpected manifest data");
   h.start=44+n;if((long)r.length!=(long)h.start+(long)count*N*SIZE)throw new IllegalArgumentException("Payload length mismatch");return h;
  }
  public static final class Result {public final byte[] data;public final int damagedShards;public final int damagedStripes;public final String status;
   Result(byte[] v,int shards,int stripes,String st){data=v;damagedShards=shards;damagedStripes=stripes;status=st;}}
  public static Result restore(byte[] encoded,boolean reconstruct){Header h=parse(encoded);ByteArrayOutputStream out=new ByteArrayOutputStream();int offset=h.start,damaged=0,rebuilt=0;
    for(int row=0;row<h.stripes.length;row++){byte[][] shards=new byte[N][];int bad=0;
      for(int j=0;j<N;j++){byte[] value=Arrays.copyOfRange(encoded,offset,offset+SIZE);offset+=SIZE;
        if(!hex(sha(value)).equals(h.stripes[row][j])){bad++;shards[j]=null;}else shards[j]=value;
      }if(bad>0){damaged+=bad;rebuilt++;if(bad>M)throw new IllegalArgumentException("Unrecoverable stripe "+row+": "+bad+" bad shards");
        if(reconstruct){shards=rebuild(shards);for(int j=0;j<N;j++)if(!hex(sha(shards[j])).equals(h.stripes[row][j]))throw new IllegalArgumentException("Parity verification failed");}
      }
      if(reconstruct||bad==0){for(int j=0;j<K;j++){int rem=(int)Math.min(SIZE,h.size-out.size());if(rem>0)out.write(shards[j],0,rem);}}
    }
    byte[] result=out.toByteArray();if(damaged==0&&(!hex(sha(result)).equals(h.expected)||result.length!=h.size))throw new IllegalArgumentException("Whole-file SHA mismatch");
    if(reconstruct&&(!hex(sha(result)).equals(h.expected)||result.length!=h.size))throw new IllegalArgumentException("Restored file SHA mismatch");
    return new Result(result,damaged,rebuilt,damaged==0?"intact":reconstruct?"recovered_verified":"damaged_recoverable");
  }
  /** JVM cross-platform verification harness, never invoked from Android UI. */
  public static void main(String[] args) throws Exception {if(args.length!=3)throw new IllegalArgumentException("protect/check/repair input output");
   byte[] input=java.nio.file.Files.readAllBytes(java.nio.file.Path.of(args[1]));
   if(args[0].equals("protect"))java.nio.file.Files.write(java.nio.file.Path.of(args[2]),protect(input,java.nio.file.Path.of(args[1]).getFileName().toString()));
   else if(args[0].equals("repair"))java.nio.file.Files.write(java.nio.file.Path.of(args[2]),restore(input,true).data);
   else if(args[0].equals("check"))System.out.println(restore(input,false).status);
   else throw new IllegalArgumentException("Invalid verb");
  }
}
