package org.ripple.repair;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;
import java.io.*;
import java.util.UUID;

/** Native Android Storage Access Framework application. No network permission. */
public class MainActivity extends Activity {
  private static final int PICK=401,SAVE=402;
  private TextView status,detail;
  private int pendingOperation=0;
  private String proposedName="repaired.bin";
  private File pendingFile=null;
  private static final int MAX_INPUT=8*1024*1024;
  private static final int MAX_ARCHIVE=24*1024*1024;
  @Override public void onCreate(Bundle saved){super.onCreate(saved);
    LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(24,32,24,24);root.setBackgroundColor(Color.rgb(10,22,36));
    ScrollView scroll=new ScrollView(this);scroll.addView(root);
    TextView title=new TextView(this);title.setText("Ripple Repair\nDaughter × Delta");title.setTextSize(28);title.setTextColor(Color.WHITE);root.addView(title);
    text(root,"Protect data with Reed–Solomon parity. Check integrity. Reconstruct exact verified bytes after damage. No network access; file selection is under your control.",15);
    button(root,"1 · Protect a file",1);button(root,"2 · Check a protected archive",2);button(root,"3 · Repair and save a recovered file",3);
    status=text(root,"Ready",19);detail=text(root,"Maximum source file 8 MiB; protected archive 24 MiB. Original files are never overwritten. If more than two shards fail in one stripe, reconstruction is rejected.",14);
    setContentView(scroll);
    if(saved!=null){pendingOperation=saved.getInt("operation",0);proposedName=saved.getString("name","repaired.bin");String path=saved.getString("path");if(path!=null){File p=new File(path);if(p.getParentFile().equals(getFilesDir())&&p.isFile())pendingFile=p;}}
  }
  private TextView text(LinearLayout root,String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.rgb(204,226,235));t.setPadding(0,18,0,18);root.addView(t);return t;}
  private void button(LinearLayout root,String label,int operation){Button b=new Button(this);b.setAllCaps(false);b.setText(label);root.addView(b);b.setOnClickListener(v->{pendingOperation=operation;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");startActivityForResult(i,PICK);});}
  @Override protected void onSaveInstanceState(Bundle out){super.onSaveInstanceState(out);out.putInt("operation",pendingOperation);out.putString("name",proposedName);if(pendingFile!=null)out.putString("path",pendingFile.getAbsolutePath());}
  private byte[] readLimited(Uri uri,int max) throws IOException {try(InputStream in=getContentResolver().openInputStream(uri);ByteArrayOutputStream out=new ByteArrayOutputStream()){
    if(in==null)throw new IOException("Cannot open selected input");byte[] buffer=new byte[65536];int n;while((n=in.read(buffer))!=-1){if(out.size()+n>max)throw new IOException("File exceeds local memory limit");out.write(buffer,0,n);}return out.toByteArray();}}
  private void recordPending(byte[] bytes,String name) throws IOException {
    pendingFile=new File(getFilesDir(),"repair_pending_"+UUID.randomUUID().toString()+".bin");try(FileOutputStream o=new FileOutputStream(pendingFile)){o.write(bytes);o.getFD().sync();}
    proposedName=name;Intent save=new Intent(Intent.ACTION_CREATE_DOCUMENT);save.addCategory(Intent.CATEGORY_OPENABLE);save.setType("application/octet-stream");save.putExtra(Intent.EXTRA_TITLE,name);startActivityForResult(save,SAVE);
  }
  @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
    if(result!=RESULT_OK||data==null||data.getData()==null){if(request==SAVE&&pendingFile!=null){pendingFile.delete();pendingFile=null;}return;}
    try{
      if(request==PICK){
        final byte[] bytes=readLimited(data.getData(),pendingOperation==1?MAX_INPUT:MAX_ARCHIVE);
        final int action=pendingOperation;
        status.setText("Analyzing file using the local repair core…");
        new Thread(()->{
          try {
            if(action==1){final byte[] protectedBytes=RepairCodec.protect(bytes,"mobile_input.bin");
              runOnUiThread(()->{try{status.setText("Protected "+bytes.length+" bytes. Save your redundancy file.");recordPending(protectedBytes,"Ripple_Protected.rpr");}catch(Exception e){status.setText("Save rejected: "+e.getMessage());}});}
            else if(action==2){final RepairCodec.Result check=RepairCodec.restore(bytes,false);
              runOnUiThread(()->{status.setText("Integrity: "+check.status);detail.setText("Detected damaged shards: "+check.damagedShards+" · damaged stripes: "+check.damagedStripes+". Full data verification is performed when intact.");});}
            else if(action==3){final RepairCodec.Result recovered=RepairCodec.restore(bytes,true);
              runOnUiThread(()->{try{status.setText("Recovered and SHA-256 verified "+recovered.data.length+" bytes.");detail.setText("Rebuilt "+recovered.damagedShards+" damaged shards; save separately.");recordPending(recovered.data,"Ripple_Verified_Recovered.bin");}catch(Exception e){status.setText("Save rejected: "+e.getMessage());}});}
          }catch(Exception e){runOnUiThread(()->{status.setText("Operation rejected");detail.setText(e.getClass().getSimpleName()+": "+e.getMessage());});}
        },"ripple-repair-worker").start();
      }
      else if(request==SAVE&&pendingFile!=null){try(InputStream input=new FileInputStream(pendingFile);OutputStream output=getContentResolver().openOutputStream(data.getData(),"w")){
        if(output==null)throw new IOException("Cannot create destination");byte[] block=new byte[65536];int n;while((n=input.read(block))!=-1)output.write(block,0,n);output.flush();}
        status.setText("Saved. Output is separate from the original.");pendingFile.delete();pendingFile=null;}
    }catch(Exception e){status.setText("Operation rejected");detail.setText(e.getClass().getSimpleName()+": "+e.getMessage());}
  }
}
