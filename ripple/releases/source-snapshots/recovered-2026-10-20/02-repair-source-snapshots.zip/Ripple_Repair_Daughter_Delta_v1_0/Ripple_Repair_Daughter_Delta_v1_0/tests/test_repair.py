"""Independent finite-field, archive recovery, failure and paired repair states."""
import hashlib,itertools,json,os,random,struct,subprocess,sys,tempfile,unittest
from pathlib import Path
from ripple_repair import protect,repair,inspect,inject_fault,InvalidArchive,Unrecoverable
from ripple_repair.core import G,K,M,N,SHARD_SIZE,encode,recover,inv,mul,invert,MAGIC
from ripple_repair.colony import transition,RepairColony

class RepairTests(unittest.TestCase):
    def setUp(self):self.t=tempfile.TemporaryDirectory();self.addCleanup(self.t.cleanup);self.p=Path(self.t.name)
    def make(self,size=300000):
        rng=random.Random(1234);data=rng.randbytes(size);src=self.p/'input.bin';src.write_bytes(data)
        arch=self.p/'archive.rpr';protect(src,arch);return data,arch
    def test_field(self):
        for x in range(1,256):self.assertEqual(mul(x,inv(x)),1)
        self.assertEqual(mul(0,123),0)
    def test_cauchy_full_rank(self):
        for rows in itertools.combinations(range(N),K):
            m=[G[r] for r in rows];mi=invert(m)
            for i in range(K):
                for j in range(K):
                    self.assertEqual(0 if i!=j else 1,0 if not any(mul(m[i][t],mi[t][j]) for t in range(K)) else __import__('functools').reduce(lambda a,b:a^b,(mul(m[i][t],mi[t][j]) for t in range(K)),0))
    def test_every_two_shard_pair(self):
        data=random.Random(456).randbytes(K*SHARD_SIZE);s=encode(data)
        for a,b in itertools.combinations(range(N),2):
            v=list(s);v[a]=None;v[b]=None;self.assertEqual(s,recover(v))
    def test_3_erasure_rejection(self):
        x=encode(bytes(K*SHARD_SIZE)); x[:3]=[None]*3
        with self.assertRaises(Unrecoverable):recover(x)
    def test_lengths_roundtrip(self):
        for n in (0,1,65535,262143,262144,262145,500001):
            d,arc=self.make(n)
            out=self.p/('out_'+str(n))
            self.assertEqual('recovered_verified',repair(arc,out)['status'])
            self.assertEqual(d,out.read_bytes());arc.unlink()
    def test_single_corrupt_data(self):
        d,a=self.make();inject_fault(a,self.p/'bad.rpr',[(0,0,100)])
        self.assertEqual(1,inspect(self.p/'bad.rpr')['bad_shards'])
        self.assertEqual(d,((lambda p:(repair(self.p/'bad.rpr',p),p.read_bytes())[1])(self.p/'fixed.bin')))
    def test_two_mixed_across_two_stripes(self):
        d,a=self.make(700000);inject_fault(a,self.p/'bad.rpr',[(0,0,50),(0,5,500),(2,3,222)])
        self.assertEqual(3,inspect(self.p/'bad.rpr')['bad_shards']);out=self.p/'fixed'
        self.assertEqual(3,repair(self.p/'bad.rpr',out)['repaired_shards']);self.assertEqual(out.read_bytes(),d)
    def test_four_errors_in_distinct_stripes_recoverable(self):
        d,a=self.make(900000);loc=[(0,0,10),(0,1,30),(1,2,20),(1,5,44)]
        inject_fault(a,self.p/'bad.rpr',loc);repair(self.p/'bad.rpr',self.p/'fixed');self.assertEqual(d,(self.p/'fixed').read_bytes())
    def test_three_corrupt_one_stripe_fail_closed(self):
        _,a=self.make();inject_fault(a,self.p/'bad.rpr',[(0,0,0),(0,1,5),(0,3,3)])
        self.assertEqual('unrecoverable',inspect(self.p/'bad.rpr')['status'])
        with self.assertRaises(Unrecoverable):repair(self.p/'bad.rpr',self.p/'fixed')
        self.assertFalse((self.p/'fixed').exists())
    def test_header_forge_denied(self):
        _,a=self.make();data=bytearray(a.read_bytes());data[50]^=1;(self.p/'bad.rpr').write_bytes(data)
        with self.assertRaises(InvalidArchive):repair(self.p/'bad.rpr',self.p/'out')
        self.assertFalse((self.p/'out').exists())
    def test_short_header_denied(self):
        p=self.p/'bad.rpr';p.write_bytes(MAGIC+b'\xff\xff\xff\xff')
        with self.assertRaises(InvalidArchive):inspect(p)
    def test_truncated_parity_shard_recovered(self):
        d,a=self.make();(self.p/'bad.rpr').write_bytes(a.read_bytes()[:-100])
        result=repair(self.p/'bad.rpr',self.p/'out')
        self.assertEqual(result['status'],'recovered_verified')
        self.assertEqual((self.p/'out').read_bytes(),d)
    def test_truncated_three_shards_denied(self):
        _,a=self.make();(self.p/'bad.rpr').write_bytes(a.read_bytes()[:-(SHARD_SIZE*3+100)])
        with self.assertRaises((Unrecoverable,InvalidArchive)):repair(self.p/'bad.rpr',self.p/'out')
        self.assertFalse((self.p/'out').exists())
    def test_extra_bytes_denied(self):
        _,a=self.make();(self.p/'bad.rpr').write_bytes(a.read_bytes()+b'junk')
        with self.assertRaises(InvalidArchive):repair(self.p/'bad.rpr',self.p/'out')
    def test_destination_no_overwrite(self):
        _,a=self.make();o=self.p/'output';o.write_bytes(b'sentinel')
        with self.assertRaises(FileExistsError):repair(a,o)
        self.assertEqual(o.read_bytes(),b'sentinel')
    def test_source_no_overwrite(self):
        _,a=self.make();p=self.p/'existing';p.write_bytes(b'sentinel')
        with self.assertRaises(FileExistsError):protect(self.p/'input.bin',p)
        self.assertEqual(p.read_bytes(),b'sentinel')
    def test_neuron_decay_finite(self):
        x=transition(0,0,1,0)
        self.assertAlmostEqual(x['daughter'],.18)
        self.assertAlmostEqual(x['delta'],1)
        y=transition(x['daughter'],1,0,0)
        self.assertGreater(y['delta'],0)
        self.assertLess(y['daughter'],x['daughter'])
    def test_neuron_neighbor_causal(self):
        a=transition(.2,0,0,0);b=transition(.2,0,0,1)
        self.assertGreater(b['risk'],a['risk'])
    def test_neuron_invalid_reading(self):
        with self.assertRaises(ValueError):transition(0,0,2)
    def test_persist_scrub(self):
        _,a=self.make(900000)
        bad=self.p/'bad.rpr';inject_fault(a,bad,[(0,0,10),(0,4,25)])
        c=RepairColony(self.p/'history.sqlite');r=c.scrub(bad,12)
        self.assertEqual(r['damaged_detected'],1)
        second=c.scrub(bad,2)
        self.assertEqual(second['observations'][0]['stripe'],0)
        with c.conn() as conn:
            count=conn.execute('select count(*) from scrub_log').fetchone()[0]
            self.assertEqual(count,6)
    def test_partial_scrub_never_reports_total_ok(self):
        _,a=self.make(900000);r=RepairColony(self.p/'history.sqlite').scrub(a,1)
        self.assertGreater(r['not_inspected'],0);self.assertEqual(1,r['scrubbed'])
    def test_real_scrub_ablation(self):
        _,a=self.make(1100000)
        bad=self.p/'bad.rpr';inject_fault(a,bad,[(4,1,1337)])
        adaptive=RepairColony(self.p/'adaptive.sqlite')
        rr=RepairColony(self.p/'roundrobin.sqlite')
        adaptive.scrub(bad,10,mode='adaptive');rr.scrub(bad,10,mode='roundrobin')
        selected=adaptive.scrub(bad,1,mode='adaptive')['observations'][0]
        baseline=rr.scrub(bad,1,mode='roundrobin')['observations'][0]
        self.assertEqual(selected['stripe'],4)
        self.assertEqual(selected['status'],'damaged_recoverable')
        self.assertNotEqual(baseline['stripe'],4)
        self.assertEqual(baseline['status'],'intact')
    def test_qualitative_ablation(self):
        ref=transition(.30,0,1,.75)
        no_peer=transition(.30,0,1,0)
        self.assertGreater(ref['risk'],no_peer['risk'])
        # Disabling the Delta transition makes an abrupt fault appear less urgent
        no_delta=.58*ref['daughter']+.15*.75
        self.assertGreater(ref['risk'],no_delta)
    def test_cli(self):
        d,a=self.make();p=subprocess.run([sys.executable,'-m','ripple_repair','check',str(a)],capture_output=True,text=True)
        self.assertEqual(p.returncode,0);self.assertEqual(json.loads(p.stdout)['status'],'intact')
    def test_original_sources_unchanged(self):
        known={'Daughter_triplet_v3_1_UNCHANGED.mjs':'0aa36b95a542cd42d6a63c733a3250333a20f9fc9894da8c2410763c00b217ce',
          'Delta_neuron_v3_0_UNCHANGED.mjs':'7b17a0ebc6c329cb832d372bdb6418111e6afe1d49e958d319f946d48ce19780',
          'Charlie_v2_UNCHANGED.py':'bf96fc4dae90eeee65e3f895207c6c5714f736b1b9dbf09569e1c24a8b440f77'}
        parent=Path(__file__).resolve().parent.parent
        for k,v in known.items():self.assertEqual(hashlib.sha256((parent/'legacy'/k).read_bytes()).hexdigest(),v)

if __name__=='__main__':unittest.main()
