import json,os,socket,subprocess,sys,tempfile,time,unittest,urllib.error,urllib.request
from pathlib import Path
from ripple_repair.core import inject_fault,inspect

class WebIntegration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory()
        sock=socket.socket();sock.bind(('127.0.0.1',0));cls.port=sock.getsockname()[1];sock.close()
        cls.server=subprocess.Popen([sys.executable,'-m','ripple_repair','serve','--port',str(cls.port),'--workspace',str(Path(cls.tmp.name)/'workspace')],stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
        cls.base=f'http://127.0.0.1:{cls.port}'
        for attempt in range(60):
            try:
                with urllib.request.urlopen(cls.base,timeout=1) as r:
                    if r.status==200:break
            except Exception:time.sleep(.1)
        else:raise RuntimeError('Local web server not running')
    @classmethod
    def tearDownClass(cls):
        cls.server.terminate()
        try:cls.server.wait(timeout=3)
        except subprocess.TimeoutExpired:cls.server.kill()
        cls.tmp.cleanup()
    def call(self,action,filename,raw):
        url=f'{self.base}/api/{action}?name={filename}'
        req=urllib.request.Request(url,data=raw,method='POST',headers={'Content-Type':'application/octet-stream'})
        with urllib.request.urlopen(req,timeout=20) as r:return json.load(r)
    def test_end_to_end_file_restore_over_actual_http(self):
        original=os.urandom(400000)
        protection=self.call('protect','sample.dat',original)
        self.assertEqual(protection['status'],'protected')
        with urllib.request.urlopen(self.base+protection['download']) as r:
            archive=r.read()
        self.assertEqual(self.call('check','sample.dat.rpr',archive)['status'],'intact')
        corrupted=bytearray(archive)
        # Skip header to inject valid shard corruption in archived bytes.
        import struct
        beginning=8+4+32+struct.unpack('<I',archive[8:12])[0]
        corrupted[beginning+4]^=1
        corrupted[beginning+65536*5+3]^=2
        d=self.call('check','sample.dat.rpr',bytes(corrupted))
        self.assertEqual(d['bad_shards'],2)
        repaired=self.call('repair','sample.dat.rpr',bytes(corrupted))
        self.assertEqual(repaired['status'],'recovered_verified')
        with urllib.request.urlopen(self.base+repaired['download']) as r:self.assertEqual(r.read(),original)
        with urllib.request.urlopen(self.base+'/api/history') as r:history=json.load(r)
        self.assertGreaterEqual(len(history['actions']),4)
    def test_unsafe_file_rejected(self):
        x=self.call('repair','broken.rpr',b'random junk')
        self.assertEqual(x['status'],'rejected')
        self.assertNotIn('download',x)
    def test_static_ui_and_module(self):
        for suffix in ('/','/site.js','/site.css','/manifest.webmanifest','/sw.js'):
            with urllib.request.urlopen(self.base+suffix) as r:self.assertEqual(r.status,200)
    def test_wrong_origin_blocked(self):
        req=urllib.request.Request(self.base+'/api/check',data=b'hello',method='POST',headers={'Origin':'https://untrusted.example'})
        with self.assertRaises(urllib.error.HTTPError) as e:urllib.request.urlopen(req)
        self.assertEqual(e.exception.code,403)
