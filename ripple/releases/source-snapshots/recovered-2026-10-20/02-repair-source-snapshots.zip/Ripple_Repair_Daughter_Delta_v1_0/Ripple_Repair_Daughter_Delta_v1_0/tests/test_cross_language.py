import os,random,subprocess,sys,tempfile,unittest
from pathlib import Path
from ripple_repair import protect,repair,inspect,inject_fault

class CrossLanguage(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        root=Path(__file__).resolve().parent.parent
        cls.cls=root/'results'/'jvm_tests'
        cls.cls.mkdir(parents=True,exist_ok=True)
        cls.source=root/'android'/'app'/'src'/'main'/'java'/'org'/'ripple'/'repair'/'RepairCodec.java'
        subprocess.run(['javac','-d',str(cls.cls),str(cls.source)],check=True,capture_output=True)
        cls.java=['java','-cp',str(cls.cls),'org.ripple.repair.RepairCodec']
    def test_interoperability_many_lengths(self):
        for length in [0,1,157,65537,262143,262145,599999]:
            with self.subTest(length=length),tempfile.TemporaryDirectory() as d:
                p=Path(d);inp=p/'a.bin';bytes_=random.Random(length+123).randbytes(length);inp.write_bytes(bytes_)
                subprocess.run(self.java+['protect',str(inp),str(p/'j.rpr')],check=True,capture_output=True)
                self.assertEqual(inspect(p/'j.rpr')['status'],'intact')
                inject_fault(p/'j.rpr',p/'fault.rpr',[(0,0,7),(0,5,200)])
                repair(p/'fault.rpr',p/'py.fixed')
                subprocess.run(self.java+['repair',str(p/'fault.rpr'),str(p/'java.fixed')],check=True,capture_output=True)
                self.assertEqual(bytes_,(p/'py.fixed').read_bytes());self.assertEqual(bytes_,(p/'java.fixed').read_bytes())
                protect(inp,p/'py.rpr')
                subprocess.run(self.java+['repair',str(p/'py.rpr'),str(p/'java.from.python')],check=True,capture_output=True)
                self.assertEqual(bytes_,(p/'java.from.python').read_bytes())
    def test_java_rejects_three_corrupt(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);(p/'a').write_bytes(os.urandom(100000));protect(p/'a',p/'a.rpr')
            inject_fault(p/'a.rpr',p/'bad.rpr',[(0,1,9),(0,3,15),(0,5,5)])
            r=subprocess.run(self.java+['repair',str(p/'bad.rpr'),str(p/'fixed')],capture_output=True)
            self.assertNotEqual(r.returncode,0)
            self.assertFalse((p/'fixed').exists())
if __name__=='__main__':unittest.main()
