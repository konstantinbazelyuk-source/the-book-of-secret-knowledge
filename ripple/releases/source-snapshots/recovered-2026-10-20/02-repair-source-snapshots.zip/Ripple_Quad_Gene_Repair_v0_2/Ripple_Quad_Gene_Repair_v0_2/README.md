# Ripple Quad-Gene Repair Research v0.2

**Purpose:** recover damaged four-state Ripple-Q program symbols *and* propose bounded repairs to misdesigned numerical program logic. This is a new, isolated extension of Ripple Repair v1.0, not a replacement for its existing functioning binary reconstruction. No broad claim that arbitrary programs can be rewritten correctly.

## Recovered source identity

- `reference/quaternary-core.mjs` — **unchanged Ripple-Q v0.7** from user's Master Ripple Alpha v2.0 archive. SHA-256 `9c1879f6bc024e564e5e25b0294ac62b34d67aafffe26f9ddfae52675d66f695`.
- `reference/ripple_repair_core_LOCKED.py` — **unchanged Ripple Repair v1.0 RPR1 Reed–Solomon archive engine**. SHA-256 `195b5aa84a60dba1d7ad0b5da75ceb46141c9bdd078739210bd6f162516348a6`.
- The new modules in `ripple_quad_repair/` are separately versioned. They do not overwrite either archived reference.

## Run

Requires Python 3.10+ (standard library), Node.js for the *original Ripple-Q temporal-VM cross-check* only.

```bash
cd Ripple_Quad_Gene_Repair_v0_2
PYTHONPATH=. python -m unittest discover -s tests -v
PYTHONPATH=. python -m ripple_quad_repair demo --out results/example_run.json
PYTHONPATH=. python -m ripple_quad_repair synthesize examples/repair_spec.json --out results/proposed_fix.json
PYTHONPATH=. python -m ripple_quad_repair repair-python examples/python_spec.json --out results/proposed_python_fix.json
PYTHONPATH=. python -m ripple_quad_repair serve --host 127.0.0.1 --port 8887
```

Then open `http://127.0.0.1:8887/` in a desktop or device with access to that *same* local computer. The interface executes the Python engine on actual JSON requests; opening the HTML directly as `file://` is not a working substitute for running the local server.

To protect/recover a whole program stored as a JSON gene:

```bash
printf '{"program":["PUSH_R","PUSH_B","SUB","QUANTIZE","EMIT"]}' > /tmp/opcodes.json
PYTHONPATH=. python -m ripple_quad_repair protect /tmp/opcodes.json /tmp/opcodes.qgene
PYTHONPATH=. python -m ripple_quad_repair restore /tmp/opcodes.qgene
```

No filesystem files are automatically patched, and output file creation is exclusive by default.

## What is actually repaired?

1. **Symbol or bit damage.** The archived symbols `−1, −0, 0, 1` correspond exactly to `00, 01, 10, 11`. One opcode is a pair of four-state symbols = one **four-bit** nibble. A new extended Hamming SECDED code protects each nibble in an eight-bit word. It corrects any one-bit error and detects all two-bit errors *per protected word*. A program-level SHA-256 checks the recovered sequence against its supplied reference manifest. Protection doubles raw opcode storage (plus metadata). It does not create additional bit capacity.
2. **Incorrect logic.** The original Ripple-Q 16-instruction grammar is mapped into a restricted numerical VM. A bounded deterministic candidate generator replaces one opcode, deletes/inserts one opcode, or inserts two opcodes; it requires valid stack structure and correct numerical outputs on training cases and independent held-out cases. Candidate search minimizes edit cost. If multiple minimal candidates fit the training examples, the system reports ambiguity. A validated proposal is **not** a proof of general program correctness.
3. **Faulty Python source.** A deliberately restricted static Python AST bridge accepts exactly one undecorated function `def name(R,G,B): return EXPR`, where EXPR may contain only `R`, `G`, `B`, zero, addition, subtraction and multiplication. It maps EXPR into actual Ripple-Q genes, runs the same verified repair search, and produces a corrected Python function. No submitted Python source is executed. The generated function is tested using the actual Python interpreter under a restricted empty-builtins context. General Python programming is not supported.
4. **Whole-file corruption.** The existing unmodified RPR1 engine can protect a `.qgene` file as ordinary bytes; a Python integration test injects two distinct shard faults into the RPR1 archive and confirms exact byte recovery. This is an operational reuse of the prior repair system.

## A concrete bit-level design repair

- Broken program: `PUSH_R; PUSH_B; ADD; QUANTIZE; EMIT`
- Required calculation, supported by explicit input/output examples: `R−B`
- Repair: `ADD` opcode is `1010` (pair `0,0`); `SUB` is `1011` (pair `0,1`). The **one-bit** change corrects the calculation.
- More structural repair: `PUSH_R; QUANTIZE; EMIT` needs two inserted instructions `PUSH_B; SUB`. This is a **design repair**, not recovering a damaged stored bit from parity.
- The original archived Ripple-Q temporal VM demonstrates differing emitted state symbols on controlled inputs after the repair; the original temporal encoder remains unchanged.

## Results and evidence

- 40 Python test cases cover source continuity, Python↔archived JavaScript equivalence, exhaustive Hamming faults, numerical repairs, ambiguity, holdout rejection, HTTP UI, and original RPR1 recovery.
- Exhaustive test of all 16 four-bit messages × 8 single-bit flips = **128/128 exact corrections**.
- All 16 × 28 two-bit flips = **448/448 explicit failures** (no fake recovery).
- A synthetic 20-training/100-heldout example finds a unique `ADD→SUB` patch, with **100/100 baseline failures** and **0/100 repaired failures** on independent pseudorandom held-out cases. This follows a fixed known target, so it is not discovery or proof of general intelligence.
- Original Ripple-Q JavaScript VM produces **3 differing quaternary output symbols in 10 input steps** when comparing the faulty versus corrected numerical program.
- Existing Ripple RPR1 independently restores a nested protected gene file after two injected shard faults, byte-for-byte.

Results and source hashes live in `results/experiment.json`, `results/archived_quadvm_signal_comparison.json`, `results/research.sqlite` and `results/verification.json`.

## Limitations

- The symbolic signed-zero label `−0` is a **tag**, not a second physical zero or quantum bit.
- The new semantic interpreter checks only **numerical stack values immediately before QUANTIZE**. The archived JS temporal quantizer remains a separate frozen module with an explicit execution cross-check. The test oracle is user-specified; inaccurate specifications produce inaccurate corrections.
- Repair is bounded to this Ripple-Q instruction grammar. This version cannot automatically repair arbitrary Python, native executables, neural networks, or scientific theories.
- If a SHA-256 manifest is intentionally altered, it cannot authenticate the original data: signatures and external trust anchors require additional work.
- There is no claim of a new physical quantum effect from the Facebook Gaussian packet. That formula is a separate wave/signal-processing question; no redundant neuron was introduced.
- This is a tested desktop Python/localhost implementation and source package. There is no newly built or installed Android APK or Dell-specific EXE for this module.

## Scientific references

- NASA, *Error Mitigation of Point-to-Point Communication*, Hamming(7,4) and extended SECDED fundamentals: https://ntrs.nasa.gov/api/citations/20110008234/downloads/20110008234.pdf
- NIST, *Guidelines on Minimum Standards for Developer Verification of Software* (2021): https://www.nist.gov/publications/guidelines-minimum-standards-developer-verification-software
- Abate, David, Kesseli, Kroening & Polgreen, *Counterexample Guided Inductive Synthesis Modulo Theories*, CAV 2018: https://research-information.bris.ac.uk/en/publications/counterexample-guided-inductive-synthesis-modulo-theories/

The historical Ripple-Q and Ripple Repair source code retains its own original licensing/attribution; inclusion for research does not relicense it.
