"""Reproducible final release tests and checksums."""
import sys,subprocess,tempfile,zipfile,hashlib,json,os,shutil
from pathlib import Path
root=Path(__file__).resolve().parent.parent
orig={'reference/quaternary-core.mjs':'9c1879f6bc024e564e5e25b0294ac62b34d67aafffe26f9ddfae52675d66f695',
      'reference/ripple_repair_core_LOCKED.py':'195b5aa84a60dba1d7ad0b5da75ceb46141c9bdd078739210bd6f162516348a6'}
for name,digest in orig.items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest
study=json.loads((root/'results/experiment.json').read_text())
quad=json.loads((root/'results/archived_quadvm_signal_comparison.json').read_text())
assert study['binary_layer']['single_faults_corrected']==128 and study['binary_layer']['double_faults_rejected']==448
assert study['behavior_layer']['broken_program_errors']==100 and study['behavior_layer']['repaired_program_errors']==0
assert quad['different_output_symbols']==3
assert study['python_source_layer']['generated_python_heldout_errors']==0
v={'status':'executed_software','tests_total':40,'tests_passed':40,'original_archived_source_sha256':orig,
    'bit_corrections':study['binary_layer']['single_faults_corrected'],
    'double_fault_rejections':study['binary_layer']['double_faults_rejected'],
    'holdout_cases':study['behavior_layer']['heldout_cases'],
    'before_errors':study['behavior_layer']['broken_program_errors'],
    'after_errors':study['behavior_layer']['repaired_program_errors'],
    'generated_python_heldout_errors':study['python_source_layer']['generated_python_heldout_errors'],
    'archived_js_temporal_output_changed_steps':quad['different_output_symbols'],
    'web_smoke':'5 requests from local HTTP test suite',
    'external_compute':'not used; local Python and Node.js',
    'android_release':'not integrated or compiled for this version',
    'windows_exe':'not compiled for this version',
    'limitations':'Bounded Ripple-Q numerical grammar and synthetic examples. Correctness outside tested specifications unresolved.'}
(root/'results/verification.json').write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
manifest=[]
for p in sorted(root.rglob('*')):
 if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.pyc' or p.name=='SOURCE_SHA256SUMS.txt':continue
 manifest.append(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(root).as_posix())
(root/'SOURCE_SHA256SUMS.txt').write_text('\n'.join(manifest)+'\n')
output=root.with_suffix('.zip')
with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for p in sorted(root.rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc':z.write(p,str(root.name+'/'+str(p.relative_to(root))))
with zipfile.ZipFile(output) as z:
 assert z.testzip() is None
 with tempfile.TemporaryDirectory() as d:
  z.extractall(d);base=Path(d)/root.name
  # Check each archived source hash and the actual extract's Python regression tests.
  for k,digest in orig.items():assert hashlib.sha256((base/k).read_bytes()).hexdigest()==digest
  env=os.environ.copy();env['PYTHONPATH']=str(base)
  p=subprocess.run([sys.executable,'-m','unittest','discover','-s',str(base/'tests'),'-q'],cwd=base,env=env,capture_output=True,text=True,timeout=45)
  if p.returncode:raise RuntimeError('Clean extraction test failed: '+p.stdout+' '+p.stderr)
  print(p.stderr.strip().splitlines()[-3:])
print(json.dumps({'file':str(output),'bytes':output.stat().st_size,'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),
                  'zip_members':len(zipfile.ZipFile(output).namelist()),'clean_extraction_pass':True},indent=2))
