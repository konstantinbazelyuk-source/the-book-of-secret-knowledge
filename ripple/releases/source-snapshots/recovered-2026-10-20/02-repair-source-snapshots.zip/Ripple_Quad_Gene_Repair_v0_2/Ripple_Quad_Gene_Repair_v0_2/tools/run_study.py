"""Reproduce bit-level/logic-level and RPR1 end-to-end comparisons."""
import sys,os,sqlite3,random,hashlib,json,time,base64,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))
from ripple_quad_repair.core import *
from ripple_quad_repair.rpr_bridge import *
from ripple_quad_repair.python_bridge import repair_python

def run():
    out=ROOT/'results';out.mkdir(exist_ok=True)
    s=time.perf_counter();bits=0;double=0
    for n in range(16):
        coded=hamming84(n)
        for i in range(8):
            assert unhamming84(coded^(1<<i))[0]==n;bits+=1
            for j in range(i+1,8):
                try:unhamming84(coded^(1<<i)^(1<<j));raise AssertionError('Undetected 2-bit pattern')
                except Unrepairable:double+=1
    bit_ms=round(1e3*(time.perf_counter()-s),3)
    rng=random.Random(20261017);fixed=['PUSH_R','PUSH_B','SUB','QUANTIZE','EMIT'];bad=['PUSH_R','PUSH_B','ADD','QUANTIZE','EMIT']
    cases=[]
    for i in range(120):
        r,g,b=rng.random(),rng.random(),rng.random()
        cases.append({'inputs':{'R':r,'G':g,'B':b},'expected':r-b})
    start=time.perf_counter();study=find_repair(bad,cases[:20],cases[20:]);synth_ms=round(1e3*(time.perf_counter()-start),3)
    assert study['status']=='proposal_validated' and study['proposal']==fixed
    baseline_errors=sum(abs(execute_numeric(bad,c['inputs'])-c['expected'])>1e-9 for c in cases[20:])
    fixed_errors=sum(abs(execute_numeric(study['proposal'],c['inputs'])-c['expected'])>1e-9 for c in cases[20:])
    start=time.perf_counter();design=find_repair(['PUSH_R','QUANTIZE','EMIT'],cases[:20],cases[20:]);design_ms=round(1e3*(time.perf_counter()-start),3)
    assert design['status']=='proposal_validated' and design['proposal']==fixed
    # 16 independent randomized trials to test deterministic reproducibility and failure handling.
    num=0
    for trial in range(16):
        q=protect(fixed);c=bytearray(base64.b64decode(q['secded_b64']))
        pos=rng.randrange(len(c));bit=rng.randrange(8);c[pos]^=(1<<bit);q['secded_b64']=base64.b64encode(c).decode()
        assert restore(q)['program']==fixed;num+=1
    with tempfile.TemporaryDirectory() as d:
        d=Path(d);orig=d/'gene.qgene';orig.write_text(json.dumps(protect(fixed)))
        prot=d/'gene.rpr';p1=protect_qgene_file(orig,prot)
        damages=d/'damaged.rpr';inject_rpr_fault(prot,damages,[(0,1,15),(0,4,90)])
        dest=d/'restored.qgene';p2=recover_qgene_file(damages,dest)
        assert dest.read_bytes()==orig.read_bytes() and restore(json.loads(dest.read_text()))['status']=='intact'
    py_source='def color_difference(R, G, B):\n    return R + B\n'
    py_result=repair_python(py_source,cases[:20],cases[20:])
    assert py_result['status']=='proposal_validated'
    python_namespace={}
    # Execute only repaired code emitted by strict AST grammar, not user-supplied source.
    exec(compile(py_result['proposed_source'],'<restricted-quad-output>','exec'),{'__builtins__':{}},python_namespace)
    python_function=python_namespace['color_difference']
    actual_python_errors=sum(abs(python_function(c['inputs']['R'],c['inputs']['G'],c['inputs']['B'])-c['expected'])>1e-9 for c in cases[20:])
    assert actual_python_errors==0
    data={ 'status':'executed_software', 'scope':'bounded 16-opcode Ripple-Q numerical program; synthetic user-defined oracle',
       'source':'Ripple-Q v0.7 canonical labels and bytecode; Ripple Repair v1.0 RPR1',
       'binary_layer':{'tested_nibbles':16,'single_faults_corrected':bits,'double_faults_rejected':double,'single_fault_random_program_recoveries':num,'elapsed_ms':bit_ms},
       'behavior_layer':{'train_cases':20,'heldout_cases':100,'broken_program_errors':baseline_errors,'repaired_program_errors':fixed_errors,
                         'one_bit_edit':study['edit_kind'],'proposed_program':study['proposal'],'evaluated':study['evaluated'],'elapsed_ms':synth_ms,
                         'under_specified_design_edit':design['edit_kind'],'design_edit_ms':design_ms},
       'python_source_layer':{'original_source':py_source,'proposed_source':py_result['proposed_source'],
                               'generated_python_heldout_errors':actual_python_errors,'heldout_cases':100},
       'archive_layer':{'original_protect':p1['status'],'repaired':p2['status'],'repaired_shards':p2['repaired_shards'],
                        'full_byte_match':True},
       'limits':['Synthetic input/output oracle','No automatic source rewriting','No unrestricted code language',
                 'Hash confirms byte identity against supplied manifest, not authenticity','Test suite not proof for all possible inputs']}
    (out/'experiment.json').write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
    db=out/'research.sqlite'
    if db.exists():db.unlink()
    with sqlite3.connect(db) as c:
        c.executescript('''CREATE TABLE sources(name TEXT PRIMARY KEY, sha256 TEXT NOT NULL, role TEXT NOT NULL);
        CREATE TABLE experiments(metric TEXT PRIMARY KEY, value TEXT NOT NULL, provenance TEXT NOT NULL);
        CREATE TABLE repair_proposals(original_program TEXT NOT NULL, proposed_program TEXT NOT NULL, status TEXT NOT NULL, cost INTEGER NOT NULL, evaluated INTEGER NOT NULL);''')
        for name,path,role in [('Ripple-Q v0.7',ROOT/'reference/quaternary-core.mjs','frozen canonical four-state VM'),
                               ('Ripple Repair v1.0',ROOT/'reference/ripple_repair_core_LOCKED.py','frozen RPR1 parity engine')]:
            c.execute('INSERT INTO sources VALUES (?,?,?)',(name,hashlib.sha256(path.read_bytes()).hexdigest(),role))
        for group in ('binary_layer','behavior_layer','python_source_layer','archive_layer'):
            for key,val in data[group].items():
                c.execute('INSERT INTO experiments VALUES (?,?,?)',(group+'.'+key,json.dumps(val),'executed numerical / injected faults' if group!='behavior_layer' else 'synthetic supervised oracle'))
        c.execute('INSERT INTO repair_proposals VALUES (?,?,?,?,?)',(json.dumps(bad),json.dumps(study['proposal']),study['status'],study['minimal_edit_cost'],study['evaluated']))
        c.execute('INSERT INTO repair_proposals VALUES (?,?,?,?,?)',(json.dumps(['PUSH_R','QUANTIZE','EMIT']),json.dumps(design['proposal']),design['status'],design['minimal_edit_cost'],design['evaluated']))
        assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
    print(json.dumps(data,indent=2));return data
if __name__=='__main__':run()
