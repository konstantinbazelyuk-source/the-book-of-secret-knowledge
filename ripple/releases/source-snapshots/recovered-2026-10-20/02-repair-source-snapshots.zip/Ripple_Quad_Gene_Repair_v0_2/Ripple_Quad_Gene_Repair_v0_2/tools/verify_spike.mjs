/** Runs actual archived Ripple-Q temporal engine, not a lookalike mock. */
import {QuadVM,QuadEncoder} from '../reference/quaternary-core.mjs';
import {writeFileSync} from 'node:fs';
const add=new QuadVM(['PUSH_R','PUSH_B','ADD','QUANTIZE','EMIT'],{dwell:1,threshold:0.12});
const subtract=new QuadVM(['PUSH_R','PUSH_B','SUB','QUANTIZE','EMIT'],{dwell:1,threshold:0.12});
const samples=[[.1,.1],[.2,.12],[.85,.2],[.82,.18],[.14,.73],[.18,.76],[.92,.08],[.89,.12],[.11,.82],[.52,.48]];
const trace=samples.map(([r,b],step)=>{
 const input={rgb:[r,.1,b],drive:2*r+1.2*.1-1.4*b};
 const original=add.run(input),candidate=subtract.run(input);
 return {step,input:{R:r,G:.1,B:b},original_symbol:original.label,original_code:original.code,
   corrected_symbol:candidate.label,corrected_code:candidate.code,changed:original.code!==candidate.code};
});
const changed=trace.filter(s=>s.changed).length;
if(changed===0)throw Error('No functional effect of the repaired opcode on actual archived QuadVM');
const data={engine:'unmodified archived Ripple-Q v0.7 QuadVM',steps:trace.length,different_output_symbols:changed,trace};
const out=process.argv[2]||'results/archived_quadvm_signal_comparison.json';
writeFileSync(out,JSON.stringify(data,null,2)+'\n');
console.log(JSON.stringify({engine:data.engine,steps:trace.length,different_output_symbols:changed}));
