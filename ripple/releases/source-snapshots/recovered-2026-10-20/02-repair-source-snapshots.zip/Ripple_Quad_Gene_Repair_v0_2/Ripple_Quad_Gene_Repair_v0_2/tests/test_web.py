import json,threading,unittest
from http.server import ThreadingHTTPServer
from urllib.request import urlopen,Request
from urllib.error import HTTPError
from pathlib import Path
from ripple_quad_repair.webapp import Handler
class UI(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.http=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        cls.thread=threading.Thread(target=cls.http.serve_forever,daemon=True);cls.thread.start()
        cls.url=f'http://127.0.0.1:{cls.http.server_address[1]}'
    @classmethod
    def tearDownClass(cls):cls.http.shutdown();cls.http.server_close();cls.thread.join()
    def _post(self,path,content):
        req=Request(self.url+path,data=json.dumps(content).encode(),headers={'Content-Type':'application/json'},method='POST')
        with urlopen(req,timeout=10) as r:return json.load(r)
    def test_browser_get(self):
        with urlopen(self.url,timeout=10) as r:
            content=r.read().decode();self.assertEqual(r.status,200);self.assertIn('Find behavioral repair',content)
    def test_actual_synthesis_endpoint(self):
        with urlopen(self.url+'/api/example',timeout=10) as r:spec=json.load(r)
        result=self._post('/api/synthesize',spec)
        self.assertEqual(result['status'],'proposal_validated');self.assertEqual(result['proposal'][2],'SUB')
    def test_actual_protect_restore_endpoint(self):
        packet=self._post('/api/protect',{'program':['PUSH_R','PUSH_B','SUB','QUANTIZE','EMIT']})
        self.assertEqual(self._post('/api/restore',packet)['status'],'intact')
    def test_actual_python_source_repair_endpoint(self):
        with urlopen(self.url+'/api/example_python',timeout=10) as r:spec=json.load(r)
        result=self._post('/api/repair_python',spec)
        self.assertEqual(result['status'],'proposal_validated');self.assertIn('R - B',result['proposed_source'])
    def test_malformed_rejected(self):
        with self.assertRaises(HTTPError) as cm:self._post('/api/protect',{'program':['import os']})
        self.assertEqual(cm.exception.code,422)
    def test_not_external_bind(self):
        from ripple_quad_repair.webapp import serve
        with self.assertRaises(ValueError):serve('0.0.0.0',8887)
