import json,unittest
from pathlib import Path
from ripple_quad_repair.python_bridge import parse_safe_python,render_safe_python,repair_python
from ripple_quad_repair import InvalidGene

class PythonBridge(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.spec=json.loads((Path(__file__).resolve().parent.parent/'examples/python_spec.json').read_text())
 def test_parse_code_to_quad(self):
  r=parse_safe_python(self.spec['python_source']);self.assertEqual(r['program'],['PUSH_R','PUSH_B','ADD','QUANTIZE','EMIT'])
 def test_repair_real_python_expression(self):
  s=self.spec;r=repair_python(s['python_source'],s['train'],s['holdout'])
  self.assertEqual(r['status'],'proposal_validated');self.assertIn('R - B',r['proposed_source'])
  self.assertEqual(parse_safe_python(r['proposed_source'])['program'],['PUSH_R','PUSH_B','SUB','QUANTIZE','EMIT'])
 def test_generated_python_runs_on_real_interpreter(self):
  s=self.spec;r=repair_python(s['python_source'],s['train'],s['holdout'])
  assert r['status']=='proposal_validated'
  # Execute ONLY generated code derived from the whitelisted arithmetic AST.
  namespace={};exec(compile(r['proposed_source'],'<verified-generated-expression>','exec'),{'__builtins__':{}},namespace)
  fn=namespace['color_difference']
  for case in s['holdout']:
   inp=case['inputs'];self.assertAlmostEqual(fn(inp['R'],inp['G'],inp['B']),case['expected'])
 def test_reject_unsupported_code(self):
  for s in ("import os\ndef foo(R,G,B): return R", "def f(R,G,B):\n import os\n return R", "def f(R,G,B):return __import__('os').system('echo hi')", "def f(R,G,B):return R/B", "def f(R,G,B):return R**B", "def f(R,G,B):return R[0]", "def f(R,G,B):return 5 + R"):
   with self.assertRaises(InvalidGene):parse_safe_python(s)
 def test_no_source_execution(self):
  with self.assertRaises(InvalidGene):parse_safe_python("def malicious(R,G,B):\n    return open('/tmp/x').read()")
 def test_bad_repair_not_promoted(self):
  s=self.spec;wrong=[dict(x) for x in s['holdout']];wrong[0]['expected']=999
  r=repair_python(s['python_source'],s['train'],wrong)
  self.assertEqual(r['status'],'holdout_failed')
 def test_structural_insertion_into_python(self):
  s=self.spec;r=repair_python('def f(R,G,B): return R',s['train'],s['holdout'])
  self.assertEqual(r['status'],'proposal_validated');self.assertIn('R - B',r['proposed_source'])
