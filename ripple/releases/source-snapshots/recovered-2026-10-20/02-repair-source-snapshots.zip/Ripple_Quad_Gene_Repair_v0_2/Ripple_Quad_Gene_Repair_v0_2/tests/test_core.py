import base64,hashlib,json,math,random,subprocess,unittest,tempfile
from pathlib import Path
from ripple_quad_repair import *
from ripple_quad_repair.core import pair_for_op,op_to_nibble
from ripple_quad_repair.rpr_bridge import protect_qgene_file,recover_qgene_file,inject_rpr_fault

ROOT=Path(__file__).resolve().parent.parent

class FourStates(unittest.TestCase):
    def test_source_integrity(self):
        p=(ROOT/'reference/quaternary-core.mjs').read_bytes()
        self.assertEqual(hashlib.sha256(p).hexdigest(),'9c1879f6bc024e564e5e25b0294ac62b34d67aafffe26f9ddfae52675d66f695')
    def test_signed_zero_as_labels(self):
        self.assertEqual(tuple(LABELS),('-1','-0','0','1'))
        self.assertNotEqual(LABELS[1],LABELS[2])
    def test_exact_symbol_bits(self):
        from ripple_quad_repair.core import bits
        self.assertEqual([bits(i) for i in range(4)],['00','01','10','11'])
    def test_opcode_nibbles(self):
        self.assertEqual([pair_for_op(x) for x in OPCODES],[(i>>2,i&3) for i in range(16)])
    def test_roundtrip_odd_even(self):
        for p in (['PUSH_R','PUSH_B','SUB','QUANTIZE','EMIT'],['PUSH_R','PUSH_G','PUSH_B','ADD','ADD','QUANTIZE','EMIT']):
            self.assertEqual(unpack_ops(pack_ops(p),len(p)),tuple(p))
    def test_invalid_gene_rejected(self):
        for p in (['PUSH_R','PUSH_B','ADD'],['PUSH_R','ADD','QUANTIZE','EMIT'],['PUSH_R','EMIT','QUANTIZE'],['PUSH_R','PUSH_B','QUANTIZE','EMIT']):
            with self.assertRaises(InvalidGene):validate(p)
    def test_python_js_original_parity(self):
        node=subprocess.run(['node','--version'],capture_output=True)
        if node.returncode: self.skipTest('Node.js not available')
        source=ROOT/'reference/quaternary-core.mjs'
        js="""const {LABELS,toBits,pack4,unpack4,opcodeSymbols,compile,QuadVM,QuadEncoder}=await import('file://'+process.argv[1]);
const ops=['PUSH_R','PUSH_B','SUB','QUANTIZE','EMIT'];let cases=[[0.9,.1],[.3,.1],[.2,.7],[.85,.05],[.2,.1]];
let vm=new QuadVM(ops,{dwell:1}), enc=new QuadEncoder({dwell:1});
let records=cases.map(([r,b])=>{
 const a=vm.run({rgb:[r,0,b],drive:2*r-1.4*b});const e=enc.step({drive:r-b});
 return {n:a.code,expected:e.code,drive:r-b}});
console.log(JSON.stringify({labels:LABELS,bits:LABELS.map((_,i)=>toBits(i)),pack:pack4([0,1,2,3]),unpack:unpack4(27),opcodes:ops.map(opcodeSymbols),records}));
"""
        r=subprocess.run(['node','--input-type=module','-e',js,str(source)],capture_output=True,text=True,check=True)
        obj=json.loads(r.stdout)
        self.assertEqual(obj['labels'],list(LABELS));self.assertEqual(obj['bits'],['00','01','10','11']);self.assertEqual(obj['pack'],27)
        self.assertEqual(obj['unpack'],[0,1,2,3])
        self.assertEqual(obj['opcodes'],[list(pair_for_op(x)) for x in ['PUSH_R','PUSH_B','SUB','QUANTIZE','EMIT']])
        self.assertTrue(all(z['n']==z['expected'] for z in obj['records']))

class BitRepair(unittest.TestCase):
    def test_exhaustive_single_and_double(self):
        # Every 4-bit gene word, eight possible single-bit faults and 28 double-bit faults.
        corrected=0;rejected=0
        for nibble in range(16):
            word=hamming84(nibble)
            self.assertEqual(unhamming84(word),(nibble,'intact'))
            for i in range(8):
                self.assertEqual(unhamming84(word^(1<<i)),(nibble,'corrected_one_bit'));corrected+=1
                for j in range(i+1,8):
                    with self.assertRaises(Unrepairable):unhamming84(word^(1<<i)^(1<<j))
                    rejected+=1
        self.assertEqual((corrected,rejected),(128,448))
    def test_protected_program_corrupt_one_bit(self):
        p=protect(['PUSH_R','PUSH_B','SUB','QUANTIZE','EMIT'])
        words=bytearray(base64.b64decode(p['secded_b64']))
        words[2]^=4;p['secded_b64']=base64.b64encode(words).decode()
        got=restore(p)
        self.assertEqual(got['status'],'recovered_verified')
        self.assertEqual(got['corrected_words'],1)
        self.assertEqual(got['program'][2],'SUB')
    def test_protected_program_two_bit_reject(self):
        p=protect(['PUSH_R','PUSH_B','SUB','QUANTIZE','EMIT'])
        words=bytearray(base64.b64decode(p['secded_b64']));words[2]^=3
        p['secded_b64']=base64.b64encode(words).decode()
        with self.assertRaises(Unrepairable):restore(p)
    def test_hash_prevents_wrong_reconstruction(self):
        p=protect(['PUSH_R','PUSH_B','SUB','QUANTIZE','EMIT'])
        words=bytearray(base64.b64decode(p['secded_b64']))
        words[2]=hamming84(OPCODES.index('ADD'))
        p['secded_b64']=base64.b64encode(words).decode()
        with self.assertRaises(Unrepairable):restore(p)
    def test_no_unverified_claim_for_multi_bit(self):
        # Three-bit faults can alias a single-error pattern; whole-gene digest rejects it.
        p=protect(['PUSH_R','PUSH_B','SUB','QUANTIZE','EMIT'])
        orig=bytearray(base64.b64decode(p['secded_b64']));orig[2]^=0b111
        p['secded_b64']=base64.b64encode(orig).decode()
        with self.assertRaises(Unrepairable):restore(p)

class SemanticRepair(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.spec=json.loads((ROOT/'examples/repair_spec.json').read_text())
    def test_source_program_is_incorrect(self):
        a=execute_numeric(self.spec['program'],self.spec['train'][0]['inputs'])
        self.assertNotAlmostEqual(a,self.spec['train'][0]['expected'])
    def test_single_symbol_corrects_logic(self):
        r=find_repair(**{k:self.spec[k] for k in ('program','train','holdout')})
        self.assertEqual(r['status'],'proposal_validated');self.assertEqual(r['edit_kind'],'substitute')
        self.assertEqual(r['minimal_edit_cost'],1);self.assertEqual(r['proposal'][2],'SUB')
    def test_structural_repair_two_insertions(self):
        r=find_repair(['PUSH_R','QUANTIZE','EMIT'],self.spec['train'],self.spec['holdout'])
        self.assertEqual(r['status'],'proposal_validated');self.assertEqual(r['edit_kind'],'insert_two')
        self.assertEqual(r['proposal'],['PUSH_R','PUSH_B','SUB','QUANTIZE','EMIT'])
    def test_no_structural_repair_without_permission(self):
        r=find_repair(['PUSH_R','QUANTIZE','EMIT'],self.spec['train'],self.spec['holdout'],structural=False)
        self.assertEqual(r['status'],'no_verified_candidate')
    def test_holdout_catches_overfit(self):
        s=self.spec
        wrong=[dict(row) for row in s['holdout']]
        wrong[0]['expected']=99.0
        r=find_repair(s['program'],s['train'],wrong)
        self.assertEqual(r['status'],'holdout_failed')
    def test_no_known_spec_no_repair(self):
        with self.assertRaises(InvalidGene):find_repair(self.spec['program'],[],self.spec['holdout'])
    def test_disjointness_required(self):
        with self.assertRaises(InvalidGene):find_repair(self.spec['program'],self.spec['train'],self.spec['train'])
    def test_ambiguous_repair_refused(self):
        # G=B on training fixtures; replacing channel R with either may fit.
        bad=['PUSH_R','QUANTIZE','EMIT']
        train=[{'inputs':{'R':0.1,'G':x,'B':x},'expected':x} for x in (.2,.5,.8)]
        held=[{'inputs':{'R':.12,'G':.4,'B':.85},'expected':.4}]
        r=find_repair(bad,train,held)
        self.assertEqual(r['status'],'ambiguous')
    def test_already_correct(self):
        s=self.spec; r=find_repair(['PUSH_R','PUSH_B','SUB','QUANTIZE','EMIT'],s['train'],s['holdout'])
        self.assertEqual(r['status'],'already_conforms')
    def test_search_budget_exceeded_is_failure(self):
        s=self.spec;r=find_repair(s['program'],s['train'],s['holdout'],max_candidates=1)
        self.assertEqual(r['status'],'search_budget_exceeded')
    def test_random_holdout_independent(self):
        rng=random.Random(20261017)
        train=[{'inputs':{'R':rng.random(),'G':rng.random(),'B':rng.random()},'expected':0} for _ in range(16)]
        for c in train:c['expected']=c['inputs']['R']-c['inputs']['B']
        held=[{'inputs':{'R':rng.random(),'G':rng.random(),'B':rng.random()},'expected':0} for _ in range(100)]
        for c in held:c['expected']=c['inputs']['R']-c['inputs']['B']
        r=find_repair(self.spec['program'],train,held)
        self.assertEqual(r['status'],'proposal_validated');self.assertEqual(r['holdout_cases'],100)
    def test_no_arbitrary_code(self):
        with self.assertRaises(InvalidGene):validate(['import os','QUANTIZE','EMIT'])
    def test_overflow_rejected(self):
        with self.assertRaises(InvalidGene):execute_numeric(['PUSH_R','PUSH_B','MUL','QUANTIZE','EMIT'],{'R':1e22,'B':1e22})

class RealRepairBridge(unittest.TestCase):
    def test_original_rpr_source_not_mutated(self):
        a=(ROOT/'reference/ripple_repair_core_LOCKED.py').read_bytes()
        b=(ROOT.parent/'Ripple_Repair_Daughter_Delta_v1_0/ripple_repair/core.py')
        if b.exists():self.assertEqual(a,b.read_bytes())
    def test_rpr_protect_and_repair(self):
        with tempfile.TemporaryDirectory() as d:
            d=Path(d);payload=d/'gene.json';payload.write_text(json.dumps(protect(['PUSH_R','PUSH_B','SUB','QUANTIZE','EMIT'])))
            protected=d/'gene.rpr';protect_qgene_file(payload,protected)
            corrupt=d/'corrupt.rpr';inject_rpr_fault(protected,corrupt,[(0,0,14),(0,2,80)])
            recovered=d/'restored.json';report=recover_qgene_file(corrupt,recovered)
            self.assertEqual(report['status'],'recovered_verified');self.assertEqual(recovered.read_bytes(),payload.read_bytes())
            self.assertEqual(restore(json.loads(recovered.read_text()))['status'],'intact')

if __name__=='__main__':unittest.main()
