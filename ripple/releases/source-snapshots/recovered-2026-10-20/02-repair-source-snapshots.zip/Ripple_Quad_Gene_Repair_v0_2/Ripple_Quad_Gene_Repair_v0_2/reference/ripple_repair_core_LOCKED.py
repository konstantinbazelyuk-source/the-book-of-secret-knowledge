"""Ripple Repair: exact data repair from independently validated erasure-coded shards.

Standard-library-only systematic (k=4,m=2) Cauchy Reed-Solomon erasure code
in GF(2^8), primitive polynomial 0x11d. SHA-256 detects corrupt shards,
which are treated as erasures. No unknown-position error correction assumed.
File format RPR1, opaque generic application data (not encrypted/signed).
"""
from __future__ import annotations
import hashlib, json, os, struct, tempfile, time
from pathlib import Path
from functools import lru_cache
from dataclasses import dataclass

MAGIC=b'RIPR1\r\n\0'
K=4; M=2; N=6; SHARD_SIZE=65536
MAX_HEADER=16*1024*1024
MAX_STRIPES=50000
MAX_DATA=K*SHARD_SIZE*MAX_STRIPES

class Unrecoverable(Exception): pass
class InvalidArchive(Exception): pass

GF_EXP=[0]*512;GF_LOG=[0]*256
x=1
for i in range(255):
    GF_EXP[i]=x;GF_LOG[x]=i
    x <<= 1
    if x & 256: x ^= 0x11d
for i in range(255,512):GF_EXP[i]=GF_EXP[i-255]

def mul(a,b):
    return GF_EXP[(GF_LOG[a]+GF_LOG[b])%255] if a and b else 0

def inv(a):
    if not a: raise ValueError('GF(256) zero not invertible')
    return GF_EXP[255-GF_LOG[a]]

def generator():
    return [[int(i==j) for j in range(K)] for i in range(K)]+[
        [inv((i+1)^(j+16)) for j in range(K)] for i in range(M)]
G=generator()

@lru_cache(512)
def table(v):return bytes(mul(v,i) for i in range(256))

def combination(coefficients, inputs):
    if len(coefficients)!=len(inputs): raise ValueError('Coefficient count')
    n=len(inputs[0]); out=bytearray(n)
    if any(len(x)!=n for x in inputs): raise ValueError('Unequal shard lengths')
    for c,inp in zip(coefficients,inputs):
        if not c:continue
        src=inp if c==1 else inp.translate(table(c))
        for j,b in enumerate(src):out[j]^=b
    return bytes(out)

def encode(data):
    if len(data)!=K*SHARD_SIZE:raise ValueError('Wrong stripe length')
    d=[data[i*SHARD_SIZE:(i+1)*SHARD_SIZE] for i in range(K)]
    return d+[combination(G[j],d) for j in range(K,N)]

def invert(matrix):
    n=len(matrix)
    if n!=K or any(len(row)!=K for row in matrix): raise ValueError('Matrix shape')
    a=[[int(v) for v in row]+[int(i==j) for j in range(n)] for i,row in enumerate(matrix)]
    for col in range(n):
        pivot=next((i for i in range(col,n) if a[i][col]),None)
        if pivot is None:raise Unrecoverable('Too few independent parity shards')
        a[col],a[pivot]=a[pivot],a[col]
        p=inv(a[col][col]);a[col]=[mul(x,p) for x in a[col]]
        for row in range(n):
            if row==col:continue
            s=a[row][col]
            if s:a[row]=[v^mul(s,w) for v,w in zip(a[row],a[col])]
    return [row[n:] for row in a]

def recover(shards):
    if len(shards)!=N: raise ValueError('Expected six shards')
    good=[i for i,s in enumerate(shards) if s is not None]
    if len(good)<K:raise Unrecoverable(f'{N-len(good)} damaged shards; tolerance is {M}')
    indices=good[:K]; mat=invert([G[i] for i in indices]);b=[shards[i] for i in indices]
    data=[combination(row,b) for row in mat]
    return data+[combination(G[j],data) for j in range(K,N)]

def sha(b):return hashlib.sha256(b).hexdigest()

def _header(f):
    if f.read(8)!=MAGIC:raise InvalidArchive('Not a Ripple Repair RPR1 archive')
    lenbytes=f.read(4)
    if len(lenbytes)!=4:raise InvalidArchive('Truncated header length')
    n=struct.unpack('<I',lenbytes)[0]
    if not 0<n<=MAX_HEADER: raise InvalidArchive('Header exceeds limits')
    expected=f.read(32); raw=f.read(n)
    if len(expected)!=32 or len(raw)!=n or hashlib.sha256(raw).digest()!=expected:
        raise InvalidArchive('Header missing or altered')
    try:h=json.loads(raw)
    except (UnicodeDecodeError,ValueError) as e:raise InvalidArchive('Bad header JSON') from e
    if not isinstance(h,dict) or h.get('schema')!='ripple-repair/1':raise InvalidArchive('Unsupported schema')
    size=h.get('size');stripes=h.get('stripes');filename=h.get('filename')
    if not isinstance(size,int) or isinstance(size,bool) or not 0<=size<=MAX_DATA:raise InvalidArchive('Invalid file size')
    expected_count=max(1,(size+SHARD_SIZE*K-1)//(SHARD_SIZE*K))
    if not isinstance(stripes,list) or len(stripes)!=expected_count:raise InvalidArchive('Stripe count incorrect')
    if not isinstance(filename,str) or not filename or filename in {'.','..'} or len(filename)>255:
        raise InvalidArchive('Invalid file name')
    if h.get('k')!=K or h.get('m')!=M or h.get('shard_size')!=SHARD_SIZE:raise InvalidArchive('Unsupported parameters')
    if not isinstance(h.get('file_sha256'),str) or len(h['file_sha256'])!=64:raise InvalidArchive('Invalid file digest')
    for row in stripes:
        if not isinstance(row,list) or len(row)!=N or any(not isinstance(v,str) or len(v)!=64 or any(c not in '0123456789abcdef' for c in v) for v in row):
            raise InvalidArchive('Invalid shard checksum')
    return h

def _write_header(f,h):
    raw=json.dumps(h,sort_keys=True,separators=(',',':')).encode()
    if len(raw)>MAX_HEADER: raise InvalidArchive('Manifest exceeds maximum; use smaller archive')
    f.write(MAGIC);f.write(struct.pack('<I',len(raw)));f.write(hashlib.sha256(raw).digest());f.write(raw)

def _temp_near(path):
    fd,name=tempfile.mkstemp(prefix='.rpr_pending_',dir=str(path.parent))
    return os.fdopen(fd,'wb'),Path(name)

def _commit(tmp,out):
    # Exclusive creation; no overwrite or symlink-follow at destination. On
    # supported filesystems hard link is atomic and fails if output exists.
    try:os.link(tmp,out)
    except FileExistsError as e:raise FileExistsError('Destination exists; refusing overwrite') from e
    finally:tmp.unlink(missing_ok=True)

def protect(source,out):
    source=Path(source);out=Path(out)
    if not source.is_file():raise ValueError('Source must be a regular file')
    if source.is_symlink() or out.is_symlink():raise ValueError('Symlinks are not supported')
    if source.stat().st_size>MAX_DATA:raise ValueError('File exceeds format limit')
    if out.exists():raise FileExistsError('Destination exists')
    out.parent.mkdir(parents=True,exist_ok=True)
    payload,pt=_temp_near(out);stripes=[];digest=hashlib.sha256();size=0
    try:
        with source.open('rb') as inp, payload:
            while True:
                data=inp.read(K*SHARD_SIZE)
                if not data and stripes:break
                size+=len(data);digest.update(data)
                ds=encode(data.ljust(K*SHARD_SIZE,b'\0'))
                stripes.append([sha(s) for s in ds]);payload.write(b''.join(ds))
                if not data:break
            payload.flush();os.fsync(payload.fileno())
        header={'schema':'ripple-repair/1','filename':source.name,'size':size,
           'file_sha256':digest.hexdigest(),'shard_size':SHARD_SIZE,'k':K,'m':M,'stripes':stripes}
        outf,tmp=_temp_near(out)
        try:
            with outf,pt.open('rb') as pf:
                _write_header(outf,header)
                for block in iter(lambda:pf.read(1024*1024),b''):outf.write(block)
                outf.flush();os.fsync(outf.fileno())
            # Source mutation during reading must invalidate result.
            if source.stat().st_size!=size or _filehash(source)!=digest.hexdigest():
                raise ValueError('Source changed while creating protection; aborted')
            _commit(tmp,out)
        finally:tmp.unlink(missing_ok=True)
    finally:pt.unlink(missing_ok=True)
    return {'status':'protected','input_bytes':size,'protected_bytes':out.stat().st_size,
            'stripes':len(stripes),'sha256':digest.hexdigest(),'parity_shards':M}

def _filehash(p):
    d=hashlib.sha256()
    with open(p,'rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):d.update(chunk)
    return d.hexdigest()

def inspect(path,limit=None):
    result={'status':'intact','damaged_stripes':[],'bad_shards':0,'stripes_checked':0,'unrecoverable_stripes':[]}
    with Path(path).open('rb') as f:
        h=_header(f);total=len(h['stripes']);want=total if limit is None else min(total,limit)
        reconstructed_digest=hashlib.sha256();assembled=0
        for stripe_no in range(total):
            bad=[]
            for i in range(N):
                block=f.read(SHARD_SIZE)
                if stripe_no<want and (len(block)!=SHARD_SIZE or sha(block)!=h['stripes'][stripe_no][i]):bad.append(i)
                if stripe_no<want and i<K:
                    valid_part=block[:max(0,min(SHARD_SIZE,h['size']-assembled))]
                    reconstructed_digest.update(valid_part)
                    assembled+=len(valid_part)
            if stripe_no<want:
                result['stripes_checked']+=1
                if bad:
                    result['bad_shards']+=len(bad)
                    result['damaged_stripes'].append({'stripe':stripe_no,'bad_shards':bad,'recoverable':len(bad)<=M})
                    if len(bad)>M:result['unrecoverable_stripes'].append(stripe_no)
        if f.read(1):raise InvalidArchive('Unexpected trailing bytes')
    result['file_sha256']=h['file_sha256'];result['size']=h['size']
    result['full_file_hash_matches']=None if want<total or result['bad_shards'] else (assembled==h['size'] and reconstructed_digest.hexdigest()==h['file_sha256'])
    result['status']='unrecoverable' if result['unrecoverable_stripes'] else 'damaged_recoverable' if result['bad_shards'] else 'intact'
    if result['full_file_hash_matches'] is False:result['status']='inconsistent_manifest'
    if limit is not None and want<total:result['status']='partial_inspection';result['not_inspected']=total-want
    return result

def repair(archive,out):
    archive=Path(archive);out=Path(out)
    if out.exists():raise FileExistsError('Destination exists; refusing overwrite')
    if archive.is_symlink():raise InvalidArchive('Symlinks not supported')
    out.parent.mkdir(parents=True,exist_ok=True)
    dst,tmp=_temp_near(out); damaged=0;rebuilt=0;digest=hashlib.sha256();written=0
    try:
        with archive.open('rb') as f,dst:
            h=_header(f)
            for j,expected in enumerate(h['stripes']):
                shards=[];bad=[]
                for i in range(N):
                    s=f.read(SHARD_SIZE)
                    if len(s)!=SHARD_SIZE or sha(s)!=expected[i]:bad.append(i);shards.append(None)
                    else:shards.append(s)
                if bad:
                    if len(bad)>M:raise Unrecoverable(f'Stripe {j}: {len(bad)} erasures, max {M}')
                    reconstructed=recover(shards)
                    if any(sha(reconstructed[i])!=expected[i] for i in range(N)):
                        raise Unrecoverable(f'Stripe {j}: parity reconstruction disagrees with manifest')
                    shards=reconstructed;rebuilt+=1;damaged+=len(bad)
                data=b''.join(shards[:K]);take=min(len(data),h['size']-written)
                if take<0:raise InvalidArchive('Size mismatch')
                data=data[:take];digest.update(data);dst.write(data);written+=take
            if f.read(1):raise InvalidArchive('Unexpected bytes after stripes')
            if written!=h['size'] or digest.hexdigest()!=h['file_sha256']:
                raise Unrecoverable('Whole-file SHA256 disagrees: exact repair not established')
            dst.flush();os.fsync(dst.fileno())
        _commit(tmp,out)
        return {'status':'recovered_verified','repaired_shards':damaged,
           'repaired_stripes':rebuilt,'bytes':written,'sha256':digest.hexdigest()}
    finally:tmp.unlink(missing_ok=True)

def inject_fault(archive,out,locations,bitmask=0x01):
    """Explicit testing-only: modify shard bytes in a COPY. Never touch input."""
    archive=Path(archive);out=Path(out)
    if out.exists():raise FileExistsError('Destination exists')
    data=bytearray(archive.read_bytes())
    import io
    f=io.BytesIO(data);h=_header(f);offset=f.tell()
    for stripe,shard,pos in locations:
        if not (0<=stripe<len(h['stripes']) and 0<=shard<N and 0<=pos<SHARD_SIZE):raise ValueError('Invalid fault location')
        data[offset+(stripe*N+shard)*SHARD_SIZE+pos]^=bitmask
    out.parent.mkdir(parents=True,exist_ok=True)
    with out.open('xb') as f:f.write(data)
    return {'faults_inserted':len(locations),'output':str(out)}
