"""Optional RPR1 interop, using untouched v1.0 Ripple Repair file archive core."""
from pathlib import Path
import importlib.util,hashlib

def _source():
    p=Path(__file__).resolve().parent.parent/'reference'/'ripple_repair_core_LOCKED.py'
    expected='195b5aa84a60dba1d7ad0b5da75ceb46141c9bdd078739210bd6f162516348a6'
    if hashlib.sha256(p.read_bytes()).hexdigest()!=expected:raise RuntimeError('RPR1 reference source SHA-256 mismatch')
    spec=importlib.util.spec_from_file_location('_rpr_v1_locked',p)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    return m

def protect_qgene_file(src,dst):
    """Protect an existing JSON quaternary gene file as a byte file with Reed-Solomon RPR1."""
    return _source().protect(src,dst)

def recover_qgene_file(archive,dst):
    """The RPR1 layer repairs bytes; then call core.restore() for opcode-level validation."""
    return _source().repair(archive,dst)

def inject_rpr_fault(archive,dst,locations):return _source().inject_fault(archive,dst,locations)
