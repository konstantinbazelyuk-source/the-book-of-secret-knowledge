"""Ripple-Q v0.7-compatible 4-state bytecode and conservative repair laboratory.

The four labels are discrete states, NOT physically different zeros or extra bit capacity.
The SECDED layer repairs protected nibble storage. A separate bounded synthesis engine
proposes behavioral modifications only when train and independent heldout fixtures pass.
All patches remain PROPOSALS: no modification of files or executing arbitrary input code.
"""
from __future__ import annotations
import base64,hashlib,json,math
from dataclasses import dataclass
from itertools import combinations

LABELS=('-1','-0','0','1')
OPCODES=('PUSH_R','PUSH_G','PUSH_B','PUSH_DRIVE','PUSH_EDGE','PUSH_FRAME_DIFF','PUSH_ACCEL','PUSH_MAG','PUSH_LUX','PUSH_ZERO','ADD','SUB','MUL','CLAMP01','QUANTIZE','EMIT')
EDIT_OPS=OPCODES[:14]
ADDITION_OPS=('PUSH_R','PUSH_G','PUSH_B','PUSH_ZERO','ADD','SUB','MUL','CLAMP01')
MAX_OPS=24

class InvalidGene(ValueError):pass
class Unrepairable(ValueError):pass

def _hash(b:bytes)->str:return hashlib.sha256(b).hexdigest()
def bits(code:int)->str:
    if type(code) is not int or not 0<=code<=3:raise InvalidGene('Invalid quaternary symbol')
    return format(code,'02b')
def symbol(code:int)->str:return LABELS[code] if type(code) is int and 0<=code<=3 else (_raise('Invalid quaternary symbol'))
def _raise(msg):raise InvalidGene(msg)
def pair_for_op(name):
    if name not in OPCODES:raise InvalidGene('Unknown Q opcode')
    index=OPCODES.index(name);return (index>>2,index&3)
def validate(program):
    if not isinstance(program,(list,tuple)) or not 3<=len(program)<=MAX_OPS:raise InvalidGene('Program must contain 3..24 instructions')
    if any(type(x) is not str or x not in OPCODES for x in program):raise InvalidGene('Unrecognized instructions')
    if list(program[-2:])!=['QUANTIZE','EMIT'] or any(x in ('QUANTIZE','EMIT') for x in program[:-2]):
        raise InvalidGene('One final QUANTIZE, EMIT pair required')
    depth=0
    for name in program[:-2]:
        if name.startswith('PUSH_'):depth+=1
        elif name in ('ADD','SUB','MUL'):
            if depth<2:raise InvalidGene('Stack underflow')
            depth-=1
        elif name=='CLAMP01':
            if depth<1:raise InvalidGene('Stack underflow')
        else:raise InvalidGene('Unsafe/unknown instruction')
        if depth>16:raise InvalidGene('Stack capacity exceeded')
    if depth!=1:raise InvalidGene('Program must leave one value')
    return tuple(program)

def op_to_nibble(op):
    a,b=pair_for_op(op)
    return (a<<2)|b

def pack_ops(program):
    program=validate(program)
    opcodes=[op_to_nibble(x) for x in program]
    return bytes((opcodes[i]<<4 | (opcodes[i+1] if i+1<len(opcodes) else 0)) for i in range(0,len(opcodes),2))

def unpack_ops(packed,length):
    if type(length) is not int or not 3<=length<=MAX_OPS or len(packed)!=(length+1)//2:raise InvalidGene('Invalid packed length')
    if length%2 and packed[-1]&15:raise InvalidGene('Nonzero padding nibble')
    opcodes=[k for b in packed for k in (b>>4,b&15)][:length]
    return validate([OPCODES[x] for x in opcodes])

def hamming84(nibble):
    if type(nibble) is not int or not 0<=nibble<16:raise InvalidGene('Nibble out of range')
    p=[0]*9
    for bit,position in zip(range(3,-1,-1),(3,5,6,7)):
        p[position]=(nibble>>bit)&1
    for check in (1,2,4):p[check]=sum(p[pos] for pos in range(1,8) if pos&check and pos!=check)%2
    p[8]=sum(p[1:8])%2
    return sum(p[pos]<<(pos-1) for pos in range(1,9))

def unhamming84(word):
    if type(word) is not int or not 0<=word<256:raise InvalidGene('Codeword must be a byte')
    p=[0]+[(word>>(pos-1))&1 for pos in range(1,9)]
    syndrome=sum(check for check in (1,2,4) if sum(p[pos] for pos in range(1,8) if pos&check)%2)
    odd=(sum(p[1:])%2)==1
    if syndrome and not odd:raise Unrepairable('SECDED detected at least two bit errors')
    if odd:p[syndrome if syndrome else 8]^=1
    nibble=sum(p[pos]<<(3-index) for index,pos in enumerate((3,5,6,7)))
    return nibble,('corrected_one_bit' if odd else 'intact')

def protect(program):
    encoded=pack_ops(program)
    words=[hamming84(op_to_nibble(x)) for x in program]
    return {'schema':'ripple-quad-gene/1','origin':'Ripple-Q v0.7 compatible symbols','op_count':len(program),
            'packed_sha256':_hash(encoded),
            'secded_b64':base64.b64encode(bytes(words)).decode()}

def restore(packet):
    if not isinstance(packet,dict) or packet.get('schema')!='ripple-quad-gene/1':raise InvalidGene('Unsupported gene schema')
    count=packet.get('op_count');digest=packet.get('packed_sha256')
    if type(count) is not int or not 3<=count<=MAX_OPS or type(digest) is not str or len(digest)!=64:raise InvalidGene('Invalid gene metadata')
    try:words=base64.b64decode(packet['secded_b64'],validate=True)
    except Exception as e:raise InvalidGene('Invalid protected symbols') from e
    if len(words)!=count:raise InvalidGene('Wrong number of protected opcodes')
    results=[unhamming84(b) for b in words]
    ops=[OPCODES[x] for x,_ in results]
    try:packed=pack_ops(ops)
    except InvalidGene as e:raise Unrepairable('Corrupted gene does not decode to a valid instruction sequence') from e
    if _hash(packed)!=digest:raise Unrepairable('Reconstructed program hash does not match original manifest')
    return {'status':'recovered_verified' if any(status!='intact' for _,status in results) else 'intact',
            'corrected_words':sum(s!='intact' for _,s in results),'program':list(ops),'packed_sha256':digest}

def _sensor(s,name):
    keys={'PUSH_R':'R','PUSH_G':'G','PUSH_B':'B','PUSH_EDGE':'edgeDensity','PUSH_FRAME_DIFF':'frameDifference',
          'PUSH_ACCEL':'acceleration','PUSH_MAG':'magnetometer','PUSH_LUX':'lux'}
    if name=='PUSH_ZERO':return 0.0
    if name=='PUSH_DRIVE':
        if 'drive' in s:value=s['drive']
        else:value=2*float(s['R'])+1.2*float(s['G'])-1.4*float(s['B'])
    else:
        key=keys[name]
        if key not in s:raise InvalidGene(f'Missing sensor value {key}')
        value=s[key]
    if isinstance(value,bool) or not isinstance(value,(float,int)) or not math.isfinite(value):raise InvalidGene('Non-finite or invalid sensor')
    return float(value)

def execute_numeric(program,inputs):
    """Safe arithmetic probe *before* archived Q's temporal QUANTIZE.

    This is deliberately NOT a replacement for the original time-dependent QuadEncoder.
    """
    validate(program)
    if not isinstance(inputs,dict):raise InvalidGene('Expected typed input dictionary')
    stack=[]
    for op in program[:-2]:
        if op.startswith('PUSH_'):stack.append(_sensor(inputs,op))
        elif op in ('ADD','SUB','MUL'):
            b,a=stack.pop(),stack.pop();stack.append(a+b if op=='ADD' else a-b if op=='SUB' else a*b)
        elif op=='CLAMP01':stack.append(max(0.0,min(1.0,stack.pop())))
        if not all(math.isfinite(x) and abs(x)<1e20 for x in stack):raise InvalidGene('Numerical overflow')
    return stack[0]

def _normalized_cases(cases):
    if not isinstance(cases,list) or not cases:raise InvalidGene('Nonempty test cases required')
    result=[]
    for c in cases:
        if not isinstance(c,dict) or set(c)!={'inputs','expected'} or not isinstance(c['inputs'],dict):raise InvalidGene('Each case needs inputs and expected')
        y=c['expected']
        if isinstance(y,bool) or not isinstance(y,(int,float)) or not math.isfinite(y):raise InvalidGene('Invalid expected output')
        result.append((c['inputs'],float(y)))
    return result

def _passes(program,cases,tol):
    try:return all(abs(execute_numeric(program,inputs)-expected)<=tol for inputs,expected in cases)
    except (InvalidGene,KeyError,TypeError,ValueError):return False

def _candidate_ops(program,structural):
    """Generator for bounded mutations, one opcode substitution then optional additions/deletions."""
    head=tuple(program[:-2]);tail=('QUANTIZE','EMIT')
    for i,old in enumerate(head):
        for op in EDIT_OPS:
            if op!=old:yield head[:i]+(op,)+head[i+1:]+tail,'substitute',i,bin(op_to_nibble(old)^op_to_nibble(op)).count('1')
    if structural:
        for i in range(len(head)):
            if len(head)>1:yield head[:i]+head[i+1:]+tail,'delete',i,5
        for i in range(len(head)+1):
            for op in ADDITION_OPS:
                yield head[:i]+(op,)+head[i:]+tail,'insert',i,5
        if len(head)+4<=MAX_OPS:
            # Search two-instruction insertions. Allows repairing missing expression structure.
            for i in range(len(head)+1):
                for j in range(i,len(head)+2):
                    for op1 in ADDITION_OPS:
                        h1=head[:i]+(op1,)+head[i:]
                        for op2 in ADDITION_OPS:
                            yield h1[:j]+(op2,)+h1[j:]+tail,'insert_two',(i,j),10

def find_repair(program,train,holdout,*,tolerance=1e-9,structural=True,max_candidates=25000):
    program=validate(program)
    train=_normalized_cases(train);holdout=_normalized_cases(holdout)
    if not math.isfinite(tolerance) or tolerance<0:raise InvalidGene('Invalid tolerance')
    if any(json.dumps(a,sort_keys=True)==json.dumps(b,sort_keys=True) for a,_ in train for b,_ in holdout):
        raise InvalidGene('Holdout inputs overlap training inputs')
    if _passes(program,train,tolerance):
        if _passes(program,holdout,tolerance):return {'status':'already_conforms','program':list(program),'evaluated':1}
        return {'status':'holdout_failed','reason':'Original matches training but fails holdout; cannot promote', 'evaluated':1}
    winning=[];best_cost=None;checked=0;seen=set()
    for cand,kind,pos,cost in _candidate_ops(program,structural):
        if cand in seen:continue
        seen.add(cand)
        if best_cost is not None and cost>best_cost:continue
        if checked>=max_candidates:return {'status':'search_budget_exceeded','evaluated':checked}
        checked+=1
        if len(cand)>MAX_OPS or not _try_valid(cand):continue
        if _passes(cand,train,tolerance):
            if best_cost is None or cost<best_cost:best_cost=cost;winning=[]
            if cost==best_cost:winning.append((cand,kind,pos))
    if not winning:return {'status':'no_verified_candidate','evaluated':checked}
    if len(winning)>1:return {'status':'ambiguous','evaluated':checked,'minimal_cost':best_cost,'candidate_count':len(winning),
                          'alternatives':[list(x[0]) for x in winning[:6]]}
    cand,kind,pos=winning[0]
    if not _passes(cand,holdout,tolerance):
        return {'status':'holdout_failed','evaluated':checked,'minimal_cost':best_cost,
                'proposal':list(cand),'reason':'Candidate failed independent input/output fixtures'}
    return {'status':'proposal_validated','original':list(program),'proposal':list(cand), 'edit_kind':kind,
            'edit_position':pos,'minimal_edit_cost':best_cost,'evaluated':checked,
            'train_cases':len(train),'holdout_cases':len(holdout),
            'original_bytes_sha256':_hash(pack_ops(program)) if _try_valid(program) else None,
            'proposal_bytes_sha256':_hash(pack_ops(cand)),
            'note':'Fixture-validated bounded proposal, not a proof over all possible inputs or an automatic patch.'}

def _try_valid(p):
    try:validate(p);return True
    except (InvalidGene,TypeError):return False
