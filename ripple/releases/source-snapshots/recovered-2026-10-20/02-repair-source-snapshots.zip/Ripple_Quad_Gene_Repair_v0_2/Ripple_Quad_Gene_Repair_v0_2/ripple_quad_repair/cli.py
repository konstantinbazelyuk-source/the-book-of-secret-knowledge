"""Local/command-line operation. No arbitrary program execution or automatic patching."""
import argparse,json,pathlib,sys
from .core import find_repair,protect,restore

def dump(x):print(json.dumps(x,sort_keys=True,indent=2))
def _write(path,obj):
    p=pathlib.Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf8') as f:json.dump(obj,f,indent=2,sort_keys=True)

def main(argv=None):
    a=argparse.ArgumentParser(description='Ripple-Q bit and semantics research')
    sub=a.add_subparsers(dest='command',required=True)
    p=sub.add_parser('protect');p.add_argument('program_json');p.add_argument('output')
    p=sub.add_parser('restore');p.add_argument('protected_json');p.add_argument('--out')
    p=sub.add_parser('synthesize');p.add_argument('spec_json');p.add_argument('--out')
    p=sub.add_parser('repair-python');p.add_argument('spec_json');p.add_argument('--out')
    p=sub.add_parser('demo');p.add_argument('--out')
    p=sub.add_parser('serve');p.add_argument('--host',default='127.0.0.1');p.add_argument('--port',type=int,default=8887)
    s=a.parse_args(argv)
    if s.command=='serve':
        from .webapp import serve
        serve(s.host,s.port);return 0
    if s.command=='demo':
        directory=pathlib.Path(__file__).resolve().parent.parent
        spec=json.loads((directory/'examples'/'repair_spec.json').read_text())
        res={'bit_protection_example':protect(spec['program']), 'logic_proposal':find_repair(spec['program'],spec['train'],spec['holdout'])}
    elif s.command=='protect':
        obj=json.loads(pathlib.Path(s.program_json).read_text());res=protect(obj['program'] if isinstance(obj,dict) else obj)
        _write(s.output,res);dump({'saved':s.output,'sha256':res['packed_sha256']});return 0
    elif s.command=='restore':
        res=restore(json.loads(pathlib.Path(s.protected_json).read_text()))
    elif s.command=='repair-python':
        from .python_bridge import repair_python
        obj=json.loads(pathlib.Path(s.spec_json).read_text());res=repair_python(obj['python_source'],obj['train'],obj['holdout'])
    else:
        obj=json.loads(pathlib.Path(s.spec_json).read_text());res=find_repair(obj['program'],obj['train'],obj['holdout'],
          tolerance=obj.get('tolerance',1e-9),structural=obj.get('structural',True))
    if getattr(s,'out',None):_write(s.out,res)
    dump(res)
    return 0 if res.get('status') not in ('search_budget_exceeded','no_verified_candidate','ambiguous','holdout_failed') else 2
if __name__=='__main__':sys.exit(main())
