"""Intentionally narrow *source-to-Quad* bridge for evidence-backed Python arithmetic fixes.

Static AST analysis only: neither the original user source nor generated source is executed.
The engine changes only programs expressible in Ripple-Q's bounded stack grammar.
"""
import ast
from .core import validate,find_repair,InvalidGene

OPS={ast.Add:'ADD',ast.Sub:'SUB',ast.Mult:'MUL'}
REV={'ADD':ast.Add,'SUB':ast.Sub,'MUL':ast.Mult}
PUSH={'R':'PUSH_R','G':'PUSH_G','B':'PUSH_B'}
UNPUSH={v:k for k,v in PUSH.items()}

def _expr_to_quad(node):
    if isinstance(node,ast.Name) and node.id in PUSH:return [PUSH[node.id]]
    if isinstance(node,ast.Constant) and type(node.value) in (int,float) and node.value==0:return ['PUSH_ZERO']
    if isinstance(node,ast.BinOp) and type(node.op) in OPS:
        return _expr_to_quad(node.left)+_expr_to_quad(node.right)+[OPS[type(node.op)]]
    raise InvalidGene('Unsupported Python expression. Only R/G/B, zero, +, -, * are permitted')

def parse_safe_python(source):
    if not isinstance(source,str) or len(source)>8192:raise InvalidGene('Python source must be a short text string')
    try:tree=ast.parse(source)
    except SyntaxError as e:raise InvalidGene('Python parse error') from e
    if len(tree.body)!=1 or not isinstance(tree.body[0],ast.FunctionDef):raise InvalidGene('Exactly one function definition is required')
    fn=tree.body[0]
    if fn.decorator_list or fn.returns or len(fn.body)!=1 or not isinstance(fn.body[0],ast.Return):raise InvalidGene('Only one undecorated return statement is supported')
    if [a.arg for a in fn.args.args]!=['R','G','B'] or fn.args.posonlyargs or fn.args.kwonlyargs or fn.args.vararg or fn.args.kwarg or fn.args.defaults:
        raise InvalidGene('Function parameters must be exactly (R,G,B) without defaults')
    if any(a.annotation for a in fn.args.args):raise InvalidGene('Parameter annotations unsupported')
    ops=_expr_to_quad(fn.body[0].value)+['QUANTIZE','EMIT']
    if len(ops)>24:raise InvalidGene('Source expression too large')
    return {'name':fn.name,'program':list(validate(ops))}

def render_safe_python(fnname,program):
    validate(program)
    if not isinstance(fnname,str) or not fnname.isidentifier() or fnname.startswith('__'):
        raise InvalidGene('Invalid output function name')
    stack=[]
    for op in program[:-2]:
        if op in UNPUSH:stack.append(ast.Name(id=UNPUSH[op],ctx=ast.Load()))
        elif op=='PUSH_ZERO':stack.append(ast.Constant(value=0))
        elif op in REV:
            b=stack.pop();a=stack.pop()
            stack.append(ast.BinOp(left=a,op=REV[op](),right=b))
        else:raise InvalidGene('Repaired program contains opcode outside Python expression subset')
    assert len(stack)==1
    fn=ast.FunctionDef(name=fnname,
           args=ast.arguments(posonlyargs=[],args=[ast.arg(arg=x) for x in ('R','G','B')],vararg=None,kwonlyargs=[],kw_defaults=[],kwarg=None,defaults=[]),
           body=[ast.Return(value=stack[0])],decorator_list=[])
    tree=ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[]))
    source=ast.unparse(tree)+'\n'
    if parse_safe_python(source)['program']!=list(program):raise AssertionError('Python source round trip differs from selected gene')
    return source

def repair_python(source,train,holdout,*,structural=True):
    parsed=parse_safe_python(source)
    decision=find_repair(parsed['program'],train,holdout,structural=structural)
    if decision['status']!='proposal_validated':return {'status':decision['status'],'details':decision}
    try:patch=render_safe_python(parsed['name'],decision['proposal'])
    except InvalidGene as e:return {'status':'unsupported_patch','reason':str(e),'details':decision}
    return {'status':'proposal_validated','original_source':source,'proposed_source':patch,
            'gene_change':decision,'verification':'input-output fixtures and static source re-parsing; no untrusted Python executed'}
