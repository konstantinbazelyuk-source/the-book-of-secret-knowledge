"""Localhost UI for actual repair math; no general interpreter, no cloud calls."""
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from pathlib import Path
import json
from .core import protect,restore,find_repair,InvalidGene,Unrepairable

ROOT=Path(__file__).resolve().parent.parent
class Handler(BaseHTTPRequestHandler):
    def _respond(self,obj,code=200):
        b=json.dumps(obj,sort_keys=True).encode();self.send_response(code);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(b)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(b)
    def do_GET(self):
        if self.path=='/':
            body=(ROOT/'web'/'index.html').read_bytes();self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
        elif self.path=='/api/example_python':self._respond(json.loads((ROOT/'examples'/'python_spec.json').read_text()))
        elif self.path=='/api/example':self._respond(json.loads((ROOT/'examples'/'repair_spec.json').read_text()))
        else:self.send_error(404)
    def do_POST(self):
        if self.path not in ('/api/synthesize','/api/protect','/api/restore','/api/repair_python'):return self.send_error(404)
        try:
            n=int(self.headers.get('Content-Length','-1'))
            if n<0 or n>64*1024:raise InvalidGene('JSON request must be <=64KB')
            data=json.loads(self.rfile.read(n))
            if self.path.endswith('repair_python'):
                from .python_bridge import repair_python
                result=repair_python(data['python_source'],data['train'],data['holdout'])
            elif self.path.endswith('synthesize'):
                result=find_repair(data['program'],data['train'],data['holdout'],structural=data.get('structural',True))
            elif self.path.endswith('protect'):result=protect(data['program'])
            else:result=restore(data)
            self._respond(result)
        except (InvalidGene,Unrepairable,ValueError,TypeError,KeyError) as e:self._respond({'status':'rejected','reason':str(e)},422)
        except Exception:self._respond({'status':'error','reason':'Unexpected server failure'},500)

def serve(host='127.0.0.1',port=8887):
    if host not in ('127.0.0.1','localhost','::1'):raise ValueError('For local deployment only')
    with ThreadingHTTPServer((host,port),Handler) as http:
        print(f'Ripple Quad Repair UI at http://{host}:{port}/',flush=True)
        http.serve_forever()
