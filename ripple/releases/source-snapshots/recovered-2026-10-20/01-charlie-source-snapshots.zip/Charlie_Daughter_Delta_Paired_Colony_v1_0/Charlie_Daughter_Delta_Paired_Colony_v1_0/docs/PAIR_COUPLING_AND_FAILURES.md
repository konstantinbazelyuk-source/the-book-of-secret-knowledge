# Charlie × Daughter × Delta pairing: equations, provenance, causal tests

## Real recovered parent models

**Daughter v3.1, byte-preserved**:

\[ \tau_P \dot p_k=C(I_k)-p_k \]
\[ \tau_D \dot d=-d+\sum_k w_kp_k+\gamma\Delta_t \]
\[ \tau_S \dot u=-u+d-a,\quad \tau_A \dot a=-a \]

The archived algorithm uses exact held-input subthreshold cascade responses, bounded threshold search and reset/refractory events. Input is normalized digital RGB, not calibrated spectral flux.

**Delta v3.0, byte-preserved**: a leaky integrating neuron receiving tonic RGB drive and bounded signed log contrast. The temporal novelty term uses

\[\Delta_t=\sum_{k\in\{R,G,B\}}w_k\operatorname{gate}\left(\ln\frac{I_{k,t}+\epsilon}{I_{k,t-1}+\epsilon}\right).\]

**Charlie v2.0, byte-preserved**:

\[C\dot u=-g_Lu+e(E_e-u)+i(E_i-u)-a,\]
with separate decaying synaptic conductances, adaptation and threshold control. This project uses the exact stored checkpoint from the earlier synthetic supervised experiment. Charlie's `probability()` is a *stationary synthetic readout*, not a decision or physically calibrated probability of hazard.

## New coupling mechanics

Each site i is associated with one Delta instance, one Daughter instance and one Charlie instance. A site has a fixed identity for its lifetime. A group is sites (2g,2g+1), giving four two-pair groups.

The new bridge queues **Delta pulses to Daughter** and **Daughter pulses to Delta** one step later. Each pair in the same group receives a bounded sum of its opposite site's events with the same delay. Charlie's event count from the previous Python step is delivered as a separate causal signal to the pair; the Charlie model also accepts bounded recurrent excitation. The bridge encodes these messages as bounded **virtual RGB control-channel offsets**. This is a synthetic software interface, not an optical physics claim.

For site i, Charlie's controller computes a transparent score:

\[s_{i,t}=\operatorname{clip}\big(\alpha s_{i,t-1}+(1-\alpha)(0.66p_{C,i}+0.22d_i^*+0.12\Delta_i^*)+0.045n_{C,i}+0.035m_{ij},0,1.5\big),\quad\alpha=e^{-\Delta t/0.30}.\]

The starred states are explicitly clamped dimensionless transforms of Daughter's dendrite and Delta's signed change; `p_C` is Charlie's stationary trained readout; `n_C` is Charlie's event count, and `m_ij` is the last-step cross-pair event count (zero if link ablated). Charlie-only and static controls use independently defined criteria; their scores must not be interpreted as sharing a common calibrated confidence scale.

**Group decision:** requires both independent site scores above 0.55 for at least two successive simulated ticks (three for the static comparator), with rearming only once both fall below 0.42 for three ticks. This avoids duplicate reports of an unchanged event and is explicitly programmed. The controller does **not** receive the simulator's ground-truth label or event intervals.

**Growth allocation:** starts with two active pairs and a queue of six inactive pairs grouped as three two-pair jobs. After a group accumulates a fixed work budget of 12 site-inspection steps, the next queued group is activated. Birth timestamps in one recorded 90-step case are 0, 12, 18, and 22 ticks. This creates fresh Daughter/Delta objects at activation; no new source code or biological replication occurs. These growing policies do not optimize allocations from learned sensor history.

## Evidence grading

1. Source hash checks, exact parent algorithm tests, and internal state tests verify preservation and runtime behavior.
2. Intervention tests `unpaired`, `local`, `cross_only`, `feedback_only`, `full` disable independently named message pathways. Changed alert timing is direct evidence of **programmed causal coupling**, not intelligence.
3. Simulation generates two persistent correlated events per seeded 8-site world. Other one- or two-step local decoys and a nine-step single-site decoy challenge two-site confirmation. No physical observations or independently certified classification task are present.
4. Negative shift changes the RGB coding for all true events; all controllers fail. Synchronized false events at an uninvolved group produce false positives. Pair communication **does not solve** semantic distribution shifts.
5. Additional synthetic scenario choices were made during iterative development, so apparent 100% sensitivities are not unbiased predictions. Use real-world sensor calibration, externally selected validation distributions, and physical inspection before claims of practical utility.

Original source attributions and licenses remain the ones inside `vendor/`, `charlie_core/`, and `legacy/`. This package does not relicense the archived materials.
