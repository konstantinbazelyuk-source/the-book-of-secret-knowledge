import hashlib, json, math, random, unittest
from pathlib import Path
from charlie_core.neuron import CharlieNeuron, CoreParameters
from charlie_core.network import CharlieCoreNetwork
from charlie_core.study import run, synthetic_examples, evaluation

ROOT=Path(__file__).resolve().parents[1]

class CoreMathematics(unittest.TestCase):
    def test_independent_version(self):
        self.assertNotIn('from legacy', (ROOT/'charlie_core/neuron.py').read_text())
        self.assertTrue((ROOT/'legacy/original_ripple_LOCKED.py').exists())
        self.assertTrue((ROOT/'legacy/original_ripple_LOCKED.js').exists())
    def test_invariant_original_source(self):
        # Manifest references are real hashes from archived v1 mathematical release.
        d=json.loads((ROOT/'docs/original_hashes.json').read_text())
        for p,digest in d.items():
            self.assertEqual(hashlib.sha256((ROOT/p).read_bytes()).hexdigest(),digest)
    def test_zero_input(self):
        n=CharlieNeuron();out=n.step((0,0,0),0.5)
        self.assertEqual(out['count'],0)
        self.assertEqual(n.membrane,0)
    def test_inhibitory_shunt_decreases_equilibrium(self):
        n=CharlieNeuron()
        u0=n.equilibrium((.5,.4,0))[0]
        u1=n.equilibrium((.5,.4,.5))[0]
        self.assertLess(u1,u0)
    def test_steady_equilibrium_bounded(self):
        n=CharlieNeuron()
        for rgb in ((0,0,0),(1,1,1),(.5,.3,1)):
            u,e,i,d=n.equilibrium(rgb)
            self.assertGreater(d,0)
            self.assertGreaterEqual(e,0)
            self.assertGreaterEqual(i,0)
            self.assertGreaterEqual(u,0)
            self.assertLessEqual(u,n.params.reversal_exc)
    def test_exact_gradient_stationary(self):
        n=CharlieNeuron();x=(.37,.81,.43);y=0
        loss,analytic=n.loss_grad(x,y)
        for i in range(3):
            eps=1e-6;orig=n.weights[i]
            n.weights[i]=orig+eps;up=n.loss_grad(x,y)[0]
            n.weights[i]=orig-eps;down=n.loss_grad(x,y)[0]
            n.weights[i]=orig
            self.assertAlmostEqual(analytic[i],(up-down)/(2*eps),places=6)
    def test_strict_validation(self):
        n=CharlieNeuron()
        for x in ((1.1,0,0),(-.2,0,0),(math.nan,0,0),(0,math.inf,0)):
            with self.assertRaises(ValueError):n.step(x,.05)
        for t in (-.1,0,.51,math.nan):
            with self.assertRaises(ValueError):n.step((0,0,0),t)
    def test_fail_closed_train_before_mutation(self):
        n=CharlieNeuron();before=n.weights.copy()
        with self.assertRaises(ValueError):n.train([((0,0,0),0),((0,0,1.4),1)])
        self.assertEqual(before,n.weights)
    def test_train_updates_real_conductance_weights(self):
        n=CharlieNeuron()
        baseline=n.equilibrium((.25,.7,.3))[0]
        n.train(synthetic_examples(71,100),epochs=3)
        self.assertNotEqual(n.weights,[2,1.2,1.4])
        self.assertNotEqual(n.equilibrium((.25,.7,.3))[0],baseline)
    def test_weights_remain_bounded(self):
        n=CharlieNeuron()
        n.train(synthetic_examples(1,100),epochs=10,learning_rate=.35)
        self.assertTrue(all(n.params.weight_low<=w<=n.params.weight_high for w in n.weights))
    def test_synaptic_temporal_persistence(self):
        n=CharlieNeuron();n.step((1.,0.,0.),.05,homeostasis=False)
        a=n.exc
        self.assertGreater(a,0)
        n.step((0,0,0),.05,homeostasis=False)
        self.assertGreater(n.exc,0)
        self.assertLess(n.exc,a)
    def test_spike_adaptation_present(self):
        n=CharlieNeuron();events=0
        for k in range(300):events+=n.step((1,.4,0),.02)['count']
        self.assertGreater(events,0)
        self.assertGreater(n.adapt,0)
        self.assertGreaterEqual(n.theta,n.params.threshold_low)
        self.assertLessEqual(n.theta,n.params.threshold_high)
    def test_convergence_microstep(self):
        x=(.65,.3,.12)
        a=CharlieNeuron(params=CoreParameters(max_internal_step=.0025))
        b=CharlieNeuron(params=CoreParameters(max_internal_step=.00125))
        for i in range(100):
            a.step(x,.02);b.step(x,.02)
        self.assertLess(abs(a.theta-b.theta),.004)
        self.assertLess(abs(a.membrane-b.membrane),.03)
        self.assertLess(abs(a.count-b.count),2)
    def test_no_spike_equilibrium_relaxation(self):
        n=CharlieNeuron();n.step((.05,.05,0),.4,homeostasis=False)
        self.assertLess(n.membrane,n.params.threshold_initial)
        self.assertGreaterEqual(n.membrane,0)
    def test_causal_network_links(self):
        n1=CharlieNeuron();n2=CharlieNeuron()
        net=CharlieCoreNetwork([n1,n2],[(0,1,1)])
        for k in range(20):
            out=net.step([(1,1,0),(0,0,0)],.05)
            if out[0]['count']>0:
                self.assertGreater(net.pending_exc[1],0)
                previous=n2.exc
                net.step([(0,0,0),(0,0,0)],.05)
                self.assertGreater(n2.exc,previous)
                return
        self.fail('source neuron did not spike')
    def test_network_limits(self):
        with self.assertRaises(ValueError):CharlieCoreNetwork([CharlieNeuron()],[(0,0,1)])
        with self.assertRaises(ValueError):CharlieCoreNetwork([CharlieNeuron()],[(0,1,1)])
        net=CharlieCoreNetwork([CharlieNeuron(),CharlieNeuron()],[(0,1,-1)])
        with self.assertRaises(ValueError):net.step([(0,0,0),(2,0,0)],.02)
    def test_comparison_repeatable(self):
        a=run(20261013);b=run(20261013)
        self.assertEqual(a,b)
    def test_supervised_holdout_gain(self):
        r=run(20261013)['stationary_learning']
        self.assertLess(r['trained']['brier'],r['untrained']['brier']-.06)
        self.assertGreater(r['trained']['accuracy'],r['untrained']['accuracy']+.10)
    def test_multiple_heldout_conditions(self):
        tr=synthetic_examples(20261013,1300)
        a=CharlieNeuron();a.train(tr,epochs=24,learning_rate=.045,regularization=.0001)
        b=CharlieNeuron()
        for seed in (12,104,722):
            sample=synthetic_examples(seed,300)
            self.assertLess(evaluation(a,sample)['brier'],evaluation(b,sample)['brier'])
    def test_objective_not_universal(self):
        # Negative control reverses meaning of the same optical observations.
        a=CharlieNeuron();a.train(synthetic_examples(20261013,1300),epochs=24,learning_rate=.045,regularization=.0001)
        data=[(rgb,1-y) for rgb,y in synthetic_examples(141,300)]
        self.assertLess(evaluation(CharlieNeuron(),data)['brier'],evaluation(a,data)['brier'])

if __name__=='__main__':unittest.main()
