import hashlib,json,math,unittest,zipfile
from pathlib import Path
from paired_colony.engine import *
ROOT=Path(__file__).resolve().parents[1]
UP=ROOT/'vendor/SHA256SUMS.txt'
class PairedColonyTest(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.case=make_case(101,steps=48,regime='low_contrast')
 def test_deterministic_case(self):self.assertEqual(make_case(101,48,'low_contrast').frames,self.case.frames)
 def test_heldout_labels_are_separate(self):
  self.assertIsInstance(self.case.truth[0].group,int)
  self.assertEqual(len(self.case.frames[0]),8)
  self.assertTrue(all(len(a)==3 and all(0<=v<=1 for v in a) for row in self.case.frames for a in row))
 def test_invalid_inputs(self):
  for args in [(1,20,'standard'),(1,60,'not-a-regime')]:
   with self.assertRaises(ValueError):make_case(*args)
 def test_invalid_mode(self):
  with self.assertRaises(ValueError):run(self.case,'fabricated')
 def test_baseline_sources_identical(self):
  for p,digest in [('src/triplet-neuron.mjs','0aa36b95a542cd42d6a63c733a3250333a20f9fc9894da8c2410763c00b217ce'),('vault/delta/delta-neuron.mjs','7b17a0ebc6c329cb832d372bdb6418111e6afe1d49e958d319f946d48ce19780')]:
   self.assertEqual(hashlib.sha256((ROOT/'vendor'/p).read_bytes()).hexdigest(),digest)
  original_sha='bf96fc4dae90eeee65e3f895207c6c5714f736b1b9dbf09569e1c24a8b440f77'
  self.assertEqual(hashlib.sha256((ROOT/'charlie_core/neuron.py').read_bytes()).hexdigest(),original_sha)
 def test_bridge_rejects_invalid_data(self):
  with PairBridge() as b:
   with self.assertRaises(ValueError):b.send({'command':'step','rgb':[[.1,.2,.3]]*8,'dt':-.1,'feedback':[0]*8,'mode':'full'})
 def test_causal_delivery_delay(self):
  with PairBridge() as b:
   x=[[.85,.75,.05]]*8
   first=b.send({'command':'step','rgb':x,'dt':.1,'feedback':[0]*8,'mode':'full'})
   self.assertTrue(all(r['received']=={'local':0,'cross':0,'feedback':0} for r in first['pairs']))
   seen=0
   for _ in range(11):
    nxt=b.send({'command':'step','rgb':x,'dt':.1,'feedback':[8]*8,'mode':'full'})
    seen+=sum(r['received']['feedback'] for r in nxt['pairs'])
   self.assertGreater(seen,0)
 def test_reset_clears_messages(self):
  with PairBridge() as b:
   data={'command':'step','rgb':[[.85,.75,.05]]*8,'dt':.1,'feedback':[8]*8,'mode':'full'}
   for _ in range(6):b.send(data)
   self.assertTrue(b.send({'command':'reset'})['reset'])
   again=b.send({**data,'feedback':[0]*8})
   self.assertTrue(all(v['received']['feedback']==0 for v in again['pairs']))
 def test_unpaired_has_no_messages(self):
  result=run(self.case,'unpaired')
  self.assertEqual(result['cross_messages'],0);self.assertEqual(result['local_messages'],0)
 def test_local_no_cross(self):
  result=run(self.case,'local')
  self.assertGreater(result['local_messages'],0);self.assertEqual(result['cross_messages'],0)
 def test_full_has_cross(self):
  result=run(self.case,'full',True)
  self.assertGreater(result['cross_messages'],0)
  self.assertGreater(result['charlie_spikes'],0)
  self.assertEqual(len(result['trace']),48)
 def test_cross_only_ablation(self):
  x=run(self.case,'cross_only');self.assertGreater(x['cross_messages'],0)
 def test_feedback_only_ablation(self):
  x=run(self.case,'feedback_only');self.assertEqual(x['cross_messages'],0)
 def test_stricter_two_site_confirmation(self):
  x=run(make_case(101,regime='low_contrast'),'full')
  self.assertEqual(x['fp'],0);self.assertEqual(x['tp'],2)
 def test_heldout_cross_pairs_reduce_delay(self):
  seeds=[101,103,107]; modes=['full','local','unpaired']
  r={m:[run(make_case(seed,regime='low_contrast'),m) for seed in seeds] for m in modes}
  mean=lambda v:sum(x['mean_latency_steps'] for x in v)/len(v)
  self.assertLess(mean(r['full']),mean(r['local']))
  self.assertLess(mean(r['local']),mean(r['unpaired']))
 def test_task_driven_colonization(self):
  x=run(make_case(101,regime='low_contrast'),'grow',True)
  self.assertEqual(x['active_pairs_final'],8)
  self.assertEqual([b['t'] for b in x['births']],[0,12,18,22])
  self.assertEqual(sum(y['active'] for y in x['trace'][0]['sites']),2)
  self.assertEqual(sum(y['active'] for y in x['trace'][-1]['sites']),8)
  self.assertGreater(x['cross_messages'],0)
 def test_colony_growth_cannot_access_unactivated_sources(self):
  x=run(make_case(101,48,'low_contrast'),'grow',True)
  for step in x['trace']:
   for site in step['sites']:
    if not site['active']:
     self.assertEqual(site['score'],0)
     self.assertEqual(site['charlie_spike'],0)
     self.assertEqual(site['delta_spike'],0)
     self.assertEqual(site['daughter_spike'],0)
 def test_negative_polarity_shift(self):
  x=run(make_case(101,regime='polarity_shift'),'full')
  self.assertGreater(x['fn'],0)
 def test_negative_correlated_decoy(self):
  x=run(make_case(101,regime='correlated_decoy'),'full')
  self.assertGreater(x['fp'],0)
 def test_no_physical_actions_in_reports(self):
  report=run(self.case,'full')
  self.assertTrue(all(a['action']=='REQUEST_INSPECTION_SIMULATED' for a in report['alerts']))
if __name__=='__main__':unittest.main()
