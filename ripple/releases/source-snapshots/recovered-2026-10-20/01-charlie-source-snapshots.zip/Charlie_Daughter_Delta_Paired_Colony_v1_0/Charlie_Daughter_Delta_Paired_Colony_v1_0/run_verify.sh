#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
PYTHONPATH=. python -m unittest discover -s tests -p 'test_*.py' -q
(cd vendor && node --test tests/triplet.test.mjs)
python - <<'PY'
import sqlite3,json
from pathlib import Path
x=json.loads(Path('results/heldout_regimes.json').read_text())
assert len(x['runs'])==288 and len(x['regimes'])==6
with sqlite3.connect('results/paired_colony.sqlite') as db:
 assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
print('Recorded experimental data and database verified')
PY
