"""Command-line standalone NEW core demo. Digital model; never commands hardware."""
import argparse,json
from pathlib import Path
from .neuron import CharlieNeuron
from .study import synthetic_examples

def main():
    ap=argparse.ArgumentParser(description='New Charlie Ripple conductance core (digital research)')
    ap.add_argument('--rgb',nargs=3,type=float,default=[.55,.40,.10],metavar=('R','G','B'))
    ap.add_argument('--seconds',type=float,default=5.)
    ap.add_argument('--train-synthetic',action='store_true',help='explicitly train on known synthetic labels')
    ap.add_argument('--out',type=Path)
    a=ap.parse_args()
    if not (0<a.seconds<=600):ap.error('seconds must be in (0,600]')
    n=CharlieNeuron()
    if a.train_synthetic:
        n.train(synthetic_examples(20261013,1300),epochs=24,learning_rate=.045,regularization=.0001)
    chunks=int(a.seconds/.025)
    extra=a.seconds-chunks*.025
    trace=[]
    for i in range(chunks):
        v=n.step(a.rgb,.025)
        if v['count']:trace.append({'time':round(n.time,5),'count':v['count']})
    if extra>1e-9:
        v=n.step(a.rgb,extra)
        if v['count']:trace.append({'time':round(n.time,5),'count':v['count']})
    result={'schema':'charlie-core-example/2','evidence':'executed_digital_model',
            'rgb':a.rgb,'training':'synthetic' if a.train_synthetic else 'none',
            'weights':n.weights,'events':n.count,'last_state':{'u':n.membrane,'e':n.exc,'i':n.inh,'a':n.adapt,'theta':n.theta},
            'spike_ticks':trace,'physical_sensor':False}
    if a.out:a.out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
