"""Build traceable mathematical lineage database and executed synthetic figures."""
import hashlib,json,sqlite3,math,random
from pathlib import Path
from .neuron import CharlieNeuron
from .study import run,synthetic_examples,evaluation

ROOT=Path(__file__).resolve().parents[1]
DB=ROOT/'results/charlie_mathematics_v2.sqlite'

FORMULAS=[
('C201','new_core','Conductance-based RGB excitatory trace','tau_e de/dt = (w_R R + w_G G) - e','dimensionless conductance; seconds','IMPLEMENTED','new excitatory temporal state','Input RGB must be normalized; not actual photonic conductance'),
('C202','new_core','Blue inhibitory trace','tau_i di/dt = w_B B - i','dimensionless conductance; seconds','IMPLEMENTED','persistent blue inhibition','Effective inhibitory weight is positive, its reversal potential sets suppressive effect'),
('C203','new_core','Novel conductance-based membrane','C du/dt = g_L(E_L-u) + e(E_e-u) + i(E_i-u) - a','dimensionless voltage/current; seconds','IMPLEMENTED','conductance-based integration','Not calibrated to biological neuron or hardware'),
('C204','new_core','Frozen conductance equilibrium','u_inf=(g_L E_L+e E_e+i E_i-a)/(g_L+e+i)','dimensionless','DERIVED_EXECUTED','predict isolated membrane equilibrium','Conductances and a are held constant during local integration'),
('C205','new_core','Exact exponential under frozen conductances','u(t+h)=u_inf+(u(t)-u_inf)exp(-(g_L+e+i)h/C)','dimensionless','DERIVED_EXECUTED','stable bounded substep method','Coupled traces vary in reality, so entire step is approximate'),
('C206','new_core','Spike-triggered adaptation current','tau_a da/dt=-a; a_after_spike=a_before+Delta_a','dimensionless current; seconds','IMPLEMENTED','intrinsic frequency adaptation','Not the same as v0.1 threshold feedback'),
('C207','new_core','Exponential event rate','r_next=r exp(-h/tau_r)+N_spikes/tau_r','model events per second','IMPLEMENTED','rate estimate for homeostasis','Approximate discrete event timing within microsteps'),
('C208','new_core','Threshold homeostasis','theta_next=clip(theta+eta*h*(r-target),theta_lo,theta_hi)','dimensionless threshold','IMPLEMENTED','slow firing regulation','New integrator / parameters; not legacy exact threshold feedback'),
('C209','new_core','Stationary supervised probability','p=sigmoid(kappa*(u_inf-theta0))','dimensionless probability','IMPLEMENTED','supervised stationary readout','A model probability, not a physical occupancy probability'),
('C210','new_core','Stationary cross entropy','L=-y ln(p)-(1-y)ln(1-p)','dimensionless nats','DERIVED_EXECUTED','supervised likelihood loss','Only for given labeled synthetic data'),
('C211','new_core','Exact excitatory stationary gradient','dL/dw_R=(p-y)*kappa*(E_e-u_inf)*R/(g_L+e+i); analogously G','loss / dimensionless weight','DERIVED_TESTED','internal synaptic plasticity','Exact gradient only for stationary readout, not spiking-through-time'),
('C212','new_core','Exact inhibitory stationary gradient','dL/dw_B=(p-y)*kappa*(E_i-u_inf)*B/(g_L+e+i)','loss / dimensionless weight','DERIVED_TESTED','internal inhibitory plasticity','Finite difference checked; clipping is external to derivative'),
('C213','new_core','Bounded internal synaptic learning','w_next=clip(w-lr*(grad+lambda*(w-w0)),w_lo,w_hi)','model weights','IMPLEMENTED','supervised weight update affects future spikes','No unsupervised learning or lifelong autonomous self-training'),
('C214','new_core','One-tick delayed recurrent colony coupling','e_j(t+) += gamma_e*min(8,sum_i A+_ij N_i(t-h)); i_j analogous inhibitory','dimensionless conductance','IMPLEMENTED','causal cross-neuron event propagation','No claim of improved intelligence or physical neurons'),
('C215','new_core','One-step actuator-free event limitation','N_i and coupling bounded; max 32 cells, max 4 outgoing links per cell','event counts','IMPLEMENTED','avoid unbounded positive feedback','Not a formal global stability proof'),
]

def build_db():
    con=sqlite3.connect(DB);con.execute('PRAGMA foreign_keys=ON')
    con.execute('INSERT OR IGNORE INTO sources(source_id,title,original_location,sha256,local_reference,origin_type,evidence_note) VALUES(?,?,?,?,?,?,?)',
                ('charlie_core_20','Charlie Ripple Core v2.0 mathematical redevelopment','charlie_core/neuron.py',hashlib.sha256((ROOT/'charlie_core/neuron.py').read_bytes()).hexdigest(),
                'charlie_core/neuron.py','new_executed_software','New code, independently validated gradient, numeric tests, not biological proof'))
    for fid,family,title,expr,units,status,role,caveat in FORMULAS:
        con.execute('INSERT OR REPLACE INTO formulas VALUES(?,?,?,?,?,?,?,?,?)',(fid,family,title,expr,units,'charlie_core_20',status,role,caveat))
    for a,b in [('N01','C201'),('N01','C202'),('N02','C203'),('N07','C207'),('N08','C208'),
                ('C201','C203'),('C202','C203'),('C203','C204'),('C204','C205'),
                ('C206','C203'),('C207','C208'),('C204','C209'),('C209','C210'),
                ('C210','C211'),('C210','C212'),('C211','C213'),('C212','C213'),('C213','C201'),
                ('C213','C202'),('C214','C201'),('C214','C202'),('C215','C214')]:
        con.execute('INSERT OR IGNORE INTO connections VALUES(?,?,?)',(a,b,'derived_from' if a[:1]!='C' else 'computes_or_constrains'))
    obj=run()
    body=json.dumps(obj,sort_keys=True)
    con.execute('INSERT OR REPLACE INTO experiments VALUES(?,?,?,?,?,?)',
                ('charlie_core_v20_run_seed20261013','stationary synaptic learning + independent spike protocol',
                 'executed_software',hashlib.sha256(body.encode()).hexdigest(),body,'PASS_WITH_LIMITS'))
    con.commit()
    checks=dict(con.execute('select name,(select count(*) from sqlite_master m2 where m2.name=m.name) from sqlite_master m where type="table"'))
    counts={'formulas':con.execute('select count(*) from formulas').fetchone()[0],
            'core_formulas':con.execute('select count(*) from formulas where source_id=?',('charlie_core_20',)).fetchone()[0],
            'dependencies':con.execute('select count(*) from connections').fetchone()[0],
            'integrity':con.execute('PRAGMA integrity_check').fetchone()[0]}
    con.close();return counts

def draw():
    import matplotlib;matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    a=run();r=a['stationary_learning']
    fig,axs=plt.subplots(1,2,figsize=(12,4.2))
    names=['Held-out','Blue-heavy shift']
    original=[r['untrained']['accuracy'],r['shift_untrained']['accuracy']]
    learned=[r['trained']['accuracy'],r['shift_trained']['accuracy']]
    import numpy as np
    x=np.arange(2);axs[0].bar(x-.18,original,.36,label='Untrained new core');axs[0].bar(x+.18,learned,.36,label='Trained new core')
    axs[0].set_xticks(x,names);axs[0].set_ylim(0,1.0);axs[0].set_ylabel('Accuracy (synthetic labels)');axs[0].legend(loc='lower right')
    original=[r['untrained']['brier'],r['shift_untrained']['brier']]
    learned=[r['trained']['brier'],r['shift_trained']['brier']]
    axs[1].bar(x-.18,original,.36,label='Untrained new core');axs[1].bar(x+.18,learned,.36,label='Trained new core')
    axs[1].set_xticks(x,names);axs[1].set_ylabel('Brier score (lower is better)');axs[1].legend(loc='upper right')
    fig.suptitle('Charlie Ripple v2.0: stationary synaptic learning \u2014 executed software study')
    fig.tight_layout();fig.savefig(ROOT/'results/heldout_comparison.png',dpi=160);plt.close(fig)
    # Neuron and core mechanism schematic with explicit domain labels
    fig,ax=plt.subplots(figsize=(12,7.5));ax.set_xlim(0,12);ax.set_ylim(0,7.5);ax.axis('off')
    box=[(0.35,5.4,2.2,1.,'Normalized RGB\n(simulated input)'),
         (3.25,5.7,2.2,.85,'Excitatory filter\n\u03c4e de/dt = wR R+wG G-e'),
         (3.25,4.25,2.2,.85,'Inhibitory filter\n\u03c4i di/dt = wB B-i'),
         (6.1,4.9,2.4,1.25,'NEW CORE membrane\nC du/dt = \u03a3g(E-u) -a'),
         (9.15,4.9,2.35,1.25,'Spike events\nreset + refractory'),
         (6.1,2.7,2.4,.9,'Spike adaptation\n\u03c4a da/dt=-a; a+=\u0394'),
         (9.15,2.7,2.35,.9,'Threshold homeostasis\n\u03b8 <- \u03b8 + \u03b7(r-r*)dt'),
         (3.25,.55,4.3,1.1,'Stationary supervised gradient\nupdates wR, wG, wB INSIDE membrane')]
    from matplotlib.patches import FancyBboxPatch,FancyArrowPatch
    for x,y,w,h,s in box:
        p=FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.12',linewidth=1.4,edgecolor='black',facecolor='white')
        ax.add_patch(p);ax.text(x+w/2,y+h/2,s,ha='center',va='center',fontsize=10)
    for p,q in [((2.55,5.9),(3.25,6.1)),((2.55,5.8),(3.25,4.7)),((5.45,6.1),(6.1,5.65)),((5.45,4.65),(6.1,5.4)),
                ((8.5,5.5),(9.15,5.5)),((10.5,4.9),(10.5,3.6)),((9.15,3.15),(8.5,5.0)),((7.3,3.6),(7.3,4.9)),
                ((5.4,1.65),(4.3,4.25))]:
        ax.add_patch(FancyArrowPatch(p,q,arrowstyle='-|>',mutation_scale=12,lw=1.5))
    ax.text(6,.15,'All signals here are digital simulation states; physical sensing and intelligence unverified.',ha='center',fontsize=9)
    fig.savefig(ROOT/'results/core_architecture.png',dpi=150,bbox_inches='tight');plt.close(fig)

if __name__=='__main__':
    metrics=build_db();draw()
    (ROOT/'results/database_summary.json').write_text(json.dumps(metrics,indent=2)+'\n');print(json.dumps(metrics,indent=2))
