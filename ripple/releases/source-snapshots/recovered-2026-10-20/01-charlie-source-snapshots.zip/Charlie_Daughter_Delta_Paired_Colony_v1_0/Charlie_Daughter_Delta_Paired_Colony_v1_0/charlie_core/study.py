"""Reproducible mathematical and synthetic classification comparison."""
import argparse, hashlib, json, random, math, statistics
from pathlib import Path
from .neuron import CharlieNeuron, CoreParameters
from legacy.original_ripple_LOCKED import RippleNeuron


def synthetic_examples(seed, n, shift='same'):
    rng=random.Random(seed)
    records=[]
    for i in range(n):
        r,g,b=(rng.random() for _ in range(3))
        # Deliberately synthetic and documented target: green sensitivity greater than red.
        score=0.55*r+1.30*g-0.65*b
        label=int(score>0.68)
        if shift=='blue-heavy':
            b=0.5+0.5*b
            label=int((0.55*r+1.30*g-0.65*b)>0.68)
        records.append(((r,g,b),label))
    return records


def evaluation(node,data):
    N=len(data)
    probs=[node.probability(x) for x,y in data]
    labels=[y for x,y in data]
    brier=sum((p-y)**2 for p,y in zip(probs,labels))/N
    acc=sum((p>=0.5)==bool(y) for p,y in zip(probs,labels))/N
    loss=sum(-y*math.log(max(1e-12,p))-(1-y)*math.log(max(1e-12,1-p)) for p,y in zip(probs,labels))/N
    return {'accuracy':round(acc,6),'brier':round(brier,6),'cross_entropy':round(loss,6),'samples':N}


def temporal_run(node, seq):
    counts=[];trace=[]
    for rgb,dt in seq:
        out=node.step(rgb,dt)
        counts.append(out['count']); trace.append(out)
    return {'total_events':sum(counts),'trace':trace}


def run(seed=20261013):
    tr=synthetic_examples(seed, 1300);test=synthetic_examples(seed+1001, 600)
    shifted=synthetic_examples(seed+4002,600,'blue-heavy')
    baseline=CharlieNeuron();trained=CharlieNeuron()
    before=evaluation(baseline,test);before_ood=evaluation(baseline,shifted)
    history=trained.train(tr,epochs=24,learning_rate=0.045,regularization=0.0001)
    after=evaluation(trained,test); after_ood=evaluation(trained,shifted)
    # Numerical response and adaptation checked with separate, identically configured instances
    def spike_protocol(node):
        out=[]
        for k in range(1000):
            rgb=(0.75,0.30,0.02) if 2<=k*.02<17 else (0.03,0.03,0.01)
            v=node.step(rgb,.02)
            if v['events']:out.extend(v['events'])
        return out
    old=RippleNeuron(adaptive=True);old_events=[]
    for k in range(1000):
        rgb=(0.75,0.30,0.02) if 2<=k*.02<17 else (0.03,0.03,0.01)
        old_events+=old.step(rgb,.02)['events']
    charlie_events=spike_protocol(CharlieNeuron())
    # direct computational hypotheses, not absolute intelligence tests
    return {'schema':'charlie-core-study/2.0','kind':'executed_synthetic_model',
            'seed':seed,'train_size':len(tr),'holdout_size':len(test),
            'shifted_size':len(shifted),'original_locked_comparator':{'spikes':len(old_events)},
            'new_conductance_core':{'spikes':len(charlie_events),'spike_times_s':charlie_events},
            'stationary_learning':{'untrained':before,'trained':after,'shift_untrained':before_ood,
                                   'shift_trained':after_ood,'learned_weights':trained.weights,
                                   'training_loss_initial':history[0],'training_loss_last':history[-1]},
            'training_algorithm':'exact stationary conductance logistic gradient; not BPTT',
            'model_limitations':['synthetic color labels','software simulated seconds',
                                 'no physical neuron or robot','not proof of AI intelligence']}


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',default='results/study.json');args=ap.parse_args()
    data=run();Path(args.out).parent.mkdir(parents=True,exist_ok=True)
    Path(args.out).write_text(json.dumps(data,indent=2,allow_nan=False)+'\n')
    print(json.dumps({k:v for k,v in data.items() if k in ('stationary_learning','original_locked_comparator')},indent=2))

if __name__=='__main__':main()
