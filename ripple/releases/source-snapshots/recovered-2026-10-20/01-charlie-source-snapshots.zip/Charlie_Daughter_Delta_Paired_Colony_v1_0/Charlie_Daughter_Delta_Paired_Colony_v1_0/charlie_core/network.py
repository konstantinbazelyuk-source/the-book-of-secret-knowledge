"""Charlie core's bounded event-coupled colony; not a CPU scheduling engine."""
from __future__ import annotations
from dataclasses import dataclass, field
from .neuron import CharlieNeuron, valid_rgb

@dataclass
class CharlieCoreNetwork:
    """One-step-delayed signed spike coupling. Links (src,dst,polarity).

    Input validation and directed graph capacity prevent unchecked reproduction.
    Neuron firing equations remain those of CharlieCore, NOT original LIF.
    """
    cells: list[CharlieNeuron]
    links: list[tuple[int,int,int]]
    pending_exc: list[int] = field(default_factory=list)
    pending_inh: list[int] = field(default_factory=list)

    def __post_init__(self):
        n=len(self.cells)
        if n<1 or n>32:raise ValueError('network capacity must be 1..32')
        if len(self.links)>n*4:raise ValueError('max 4 synaptic connections per neuron')
        if len(set(self.links))!=len(self.links):raise ValueError('duplicate synapse')
        for src,dst,polarity in self.links:
            if not (0<=src<n and 0<=dst<n and src!=dst and polarity in (-1,1)):
                raise ValueError('invalid recurrent edge')
        if not self.pending_exc:self.pending_exc=[0]*n
        if not self.pending_inh:self.pending_inh=[0]*n
    def step(self, inputs:list[tuple[float,float,float]], dt:float)->list[dict]:
        if len(inputs)!=len(self.cells):raise ValueError('one RGB tuple per neuron required')
        # Validate all before mutating any cell.
        for rgb in inputs:valid_rgb(rgb)
        out=[node.step(rgb,dt,exc_pulses=min(8,ep),inh_pulses=min(8,ip))
             for node,rgb,ep,ip in zip(self.cells,inputs,self.pending_exc,self.pending_inh)]
        nxt_exc=[0]*len(self.cells);nxt_inh=[0]*len(self.cells)
        for src,dst,polarity in self.links:
            if polarity==1:nxt_exc[dst]+=out[src]['count']
            else:nxt_inh[dst]+=out[src]['count']
        self.pending_exc=[min(8,x) for x in nxt_exc]
        self.pending_inh=[min(8,x) for x in nxt_inh]
        return out
