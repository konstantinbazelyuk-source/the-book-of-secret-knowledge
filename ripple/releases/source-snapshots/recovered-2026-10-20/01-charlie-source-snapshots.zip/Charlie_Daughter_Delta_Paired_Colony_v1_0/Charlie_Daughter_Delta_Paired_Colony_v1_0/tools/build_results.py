"""Create evidence SQLite, figures and an embedded-data offline dashboard from executed artifacts."""
import json,sqlite3,hashlib,zipfile,os,html
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
R=ROOT/'results';R.mkdir(exist_ok=True)
held=json.loads((R/'heldout_regimes.json').read_text());standard=json.loads((R/'standard_benchmark.json').read_text());trace=json.loads((R/'trace_case_101.json').read_text())
DB=R/'paired_colony.sqlite';DB.unlink(missing_ok=True)
c=sqlite3.connect(DB)
c.executescript('''CREATE TABLE experiments (id INTEGER PRIMARY KEY,regime TEXT,seed INTEGER,mode TEXT,tp INTEGER,fp INTEGER,fn INTEGER,pair_spikes INTEGER,charlie_spikes INTEGER,cross_messages INTEGER,local_messages INTEGER,latency_steps REAL);
CREATE TABLE decisions (regime TEXT,seed INTEGER,mode TEXT,t INTEGER,group_id INTEGER,scores TEXT,action TEXT);
CREATE TABLE site_states (regime TEXT,seed INTEGER,t INTEGER,site_id INTEGER,charlie_score REAL,charlie_spikes INTEGER,daughter_spikes INTEGER,delta_spikes INTEGER,cross_messages INTEGER,quad_symbol TEXT);
CREATE TABLE provenance (name TEXT PRIMARY KEY,sha256 TEXT,description TEXT);
CREATE TABLE test_context (name TEXT PRIMARY KEY,value TEXT);
''')
for r in standard['runs']+held['runs']:
 c.execute('INSERT INTO experiments(regime,seed,mode,tp,fp,fn,pair_spikes,charlie_spikes,cross_messages,local_messages,latency_steps) VALUES (?,?,?,?,?,?,?,?,?,?,?)',
  (r.get('regime','standard'),r['seed'],r['mode'],r['tp'],r['fp'],r['fn'],r['pair_spikes'],r['charlie_spikes'],r['cross_messages'],r['local_messages'],r['mean_latency_steps']))
 for a in r['alerts']:
  c.execute('INSERT INTO decisions VALUES (?,?,?,?,?,?,?)',(r.get('regime','standard'),r['seed'],r['mode'],a['t'],a['group'],json.dumps(a['scores']),a['action']))
for step in trace['trace']:
 for s in step['sites']:
  c.execute('INSERT INTO site_states VALUES (?,?,?,?,?,?,?,?,?,?)',('low_contrast',101,step['t'],s['site'],s['score'],s['charlie_spike'],s['daughter_spike'],s['delta_spike'],s['cross_message'],s['quad_delta']))
for name,rel,desc in [('charlie_v2','charlie_core/neuron.py','Approved Charlie core exactly preserved'),('daughter_v31','vendor/src/triplet-neuron.mjs','Archived Daughter three-stage kernel'),('delta_v30','vendor/vault/delta/delta-neuron.mjs','Archived Delta contrast kernel'),('trained_v2','legacy/v2_trained_core_state_LOCKED.json','Old synthetic-trained Charlie checkpoint')]:
 b=(ROOT/rel).read_bytes()
 c.execute('INSERT INTO provenance VALUES (?,?,?)',(name,hashlib.sha256(b).hexdigest(),desc))
for n,v in [('evidence','ALL SYNTHETIC / NUMERICAL; NO PHYSICAL DATA'),('step_s','0.1'),('node_count','8 Delta + 8 Daughter + 8 Charlie'),('groups','4 adjacent two-site groups')]:
 c.execute('INSERT INTO test_context VALUES (?,?)',(n,v))
c.commit();v=c.execute('PRAGMA integrity_check').fetchone()[0];assert v=='ok';c.close()
# Export a visual topology and a causal time-series figure, from actual saved states.
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,ax=plt.subplots(figsize=(13,5))
for g in range(4):
 x=g*3.1
 for i in (0,1):
  y=2 if i==0 else .9
  ax.scatter([x],[y],s=480,marker='s',alpha=.2)
  ax.text(x,y,f'Pair {2*g+i}\nDaughter + Delta',ha='center',va='center',fontsize=9)
  ax.annotate('',xy=(x+.25,y+.3),xytext=(x+.75,3.2),arrowprops={'arrowstyle':'->','lw':1})
 ax.text(x+.7,3.3,f'Charlie ×2\nGroup {g}',ha='center',va='center',fontsize=9,bbox={'boxstyle':'round','facecolor':'#e5edef'})
 ax.annotate('',xy=(x+0.02,.95),xytext=(x+0.02,1.85),arrowprops={'arrowstyle':'<->','lw':1.5})
 ax.text(x+1.25,1.35,'1-tick\ncross links',fontsize=8,ha='center')
ax.set_xlim(-.8,11.6);ax.set_ylim(.4,4.3);ax.set_axis_off();ax.set_title('Charlie: four cooperating Daughter–Delta pairs-of-pairs (24 stateful neurons)');fig.tight_layout();fig.savefig(R/'topology.png',dpi=175);plt.close(fig)
regs=list(held['summary']);modes=['full','grow','cross_only','feedback_only','local','unpaired','charlie_only','static']
fig,ax=plt.subplots(figsize=(11.5,5.2));
from numpy import arange
x=arange(len(regs));w=.095
for i,mode in enumerate(modes):
 a=[held['summary'][r][mode]['tp'] for r in regs]
 ax.bar(x+(i-3.5)*w,a,w,label=mode)
ax.set_xticks(x,regs,rotation=15,ha='right');ax.set_ylabel('Detected genuine events (12 possible per regime)');ax.set_title('Synthetic stress cases (not blinded): detected persistent incidents');ax.legend(ncol=4,fontsize=8);fig.tight_layout();fig.savefig(R/'task_comparison.png',dpi=180);plt.close(fig)
fig,ax=plt.subplots(figsize=(11.5,4.5));tt=[z['t']*.1 for z in trace['trace']]
for i in (0,1,2,3):
 ax.plot(tt,[z['sites'][i]['score'] for z in trace['trace']],label=f'site {i}')
ax.axhline(.55,linestyle='--',label='confirmation threshold')
for alert in trace['alerts']:
 ax.axvline(alert['t']*.1,alpha=.2)
ax.set_xlabel('Synthetic time (seconds)');ax.set_ylabel('Algorithmic score (not probability)');ax.set_title('Eight-pair colony: fluctuating Charlie evidence / delayed messages');ax.legend();fig.tight_layout();fig.savefig(R/'temporal_states.png',dpi=185);plt.close(fig)
# Self-contained viewer: no network or imported assets; plot truly stored traces.
js=json.dumps({'trace':trace['trace'],'alerts':trace['alerts'],'truth':trace['truth'],'summary':held['summary']},separators=(',',':')).replace('<','\\u003c')
viewer='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Charlie / Daughter / Delta — Multiple Pair Colony</title><style>
:root{color-scheme:dark}body{margin:0;font:14px system-ui;background:#081821;color:#e4f6fa}main{max-width:1080px;margin:auto;padding:25px}.soft{color:#9fbdc8}header{border-bottom:1px solid #30505b;padding-bottom:14px}h1{font-size:27px}.card{background:#12303a;border:1px solid #315360;border-radius:13px;padding:16px;margin:13px 0}input{width:100%}.grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px}.unit{border:1px solid #42616b;border-radius:9px;padding:12px;background:#0d2530}.unit strong{display:block;margin:8px 0}.sites{display:grid;grid-template-columns:1fr 1fr;gap:5px}.node{border-radius:7px;border:1px solid #41636f;padding:8px;font-size:11px}.alert{color:#a0edba}.warn{color:#ffd197}canvas{width:100%;height:170px;background:#081f28}button{background:#205669;color:white;border:0;border-radius:8px;padding:9px;cursor:pointer}@media(max-width:760px){.grid{grid-template-columns:repeat(2,minmax(0,1fr));}}</style></head><body><main><header><h1>Charlie × Daughter × Delta / Colonized Pairs</h1><p class="soft">Executed synthetic simulation playback • 8 Daughter + 8 Delta + 8 Charlie nodes • no hardware, cognition, or external model inference</p></header><section class="card"><p><strong id="time">Frame 0</strong> <span class="soft" id="action">No simulated inspection report</span></p><input type="range" min="0" max="89" value="0" id="frame"><p><button id="back">Previous</button> <button id="next">Next</button> <button id="play">Play</button></p></section><section class="card"><h2>Four cooperative pairs-of-pairs</h2><div class="grid" id="groups"></div></section><section class="card"><h2>Saved Charlie state trajectories</h2><canvas id="graph" width="1000" height="190"></canvas><p class="soft">Graph values are dimensionless algorithmic scores. Dashed line: the predefined task threshold. Colored line denotes site assignment.</p></section><section class="card"><h2>System evidence</h2><div id="summary" class="soft"></div></section></main><script>const DATA=__DATA__;const trace=DATA.trace;let idx=0, playing=null;const $=id=>document.getElementById(id);$('frame').max=trace.length-1;
function draw(){const rec=trace[idx];$('time').textContent='Frame '+idx+' / time '+(idx*.1).toFixed(1)+'s';$('action').textContent=rec.decisions.length?'REQUEST INSPECTION: group '+rec.decisions.map(d=>d.group).join(', '):'No inspection report on this step';let h='';for(let g=0;g<4;g++){h+='<div class="unit"><strong>Group '+g+'</strong><div class="sites">';for(let j=0;j<2;j++){let s=rec.sites[2*g+j];h+='<div class="node">Site '+s.site+'<br>Evidence '+s.score.toFixed(3)+'<br>Charlie spikes '+s.charlie_spike+'<br>Daughter '+s.daughter_spike+' / Delta '+s.delta_spike+'<br>Cross links '+s.cross_message+'<br>Quad '+(s.quad_delta||'n/a')+'</div>';}h+='</div></div>'}$('groups').innerHTML=h;const canvas=$('graph'),ctx=canvas.getContext('2d'),W=canvas.width,H=canvas.height;ctx.clearRect(0,0,W,H);ctx.strokeStyle='#ffffff44';ctx.setLineDash([8,6]);ctx.beginPath();ctx.moveTo(0,H*(1-.55/1.5));ctx.lineTo(W,H*(1-.55/1.5));ctx.stroke();ctx.setLineDash([]);const colors=['#48dcbb','#f4b97a','#9aaaff','#e1a1d4'];for(let j=0;j<4;j++){ctx.strokeStyle=colors[j];ctx.lineWidth=2;ctx.beginPath();for(let t=0;t<trace.length;t++){const x=W*t/(trace.length-1),y=H*(1-trace[t].sites[j].score/1.5);t?ctx.lineTo(x,y):ctx.moveTo(x,y)}ctx.stroke();}ctx.strokeStyle='white';ctx.beginPath();ctx.moveTo(W*idx/(trace.length-1),0);ctx.lineTo(W*idx/(trace.length-1),H);ctx.stroke();$('frame').value=idx;}
$('frame').addEventListener('input',e=>{idx=+e.target.value;draw()});$('next').onclick=()=>{idx=(idx+1)%trace.length;draw()};$('back').onclick=()=>{idx=(idx+trace.length-1)%trace.length;draw()};$('play').onclick=()=>{if(playing){clearInterval(playing);playing=null;$('play').textContent='Play'}else{playing=setInterval(()=>{idx=(idx+1)%trace.length;draw()},125);$('play').textContent='Pause'}};
$('summary').textContent='Low-contrast heldout: '+Object.entries(DATA.summary.low_contrast).map(([k,v])=>k+' '+v.tp+'/'+(v.tp+v.fn)+' detection, latency '+(v.latency_steps_mean_case??'unknown')+' steps').join(' | ');draw();</script></body></html>'''.replace('__DATA__',js)
(ROOT/'web/Charlie_Daughter_Delta_Colony_Replay.html').write_text(viewer)
print('sqlite',DB.stat().st_size,'rows',len(held['runs'])+len(standard['runs']), 'viewer',len(viewer))
