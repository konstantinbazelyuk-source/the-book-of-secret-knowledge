# Charlie × Daughter × Delta — Colonized Pairs v1.0

**Status:** a runnable, reproducible **synthetic multi-neuron collaboration experiment**. Eight independent Daughter v3.1 and eight independent Delta v3.0 neurons are arranged as eight heterogeneous pairs. Eight independent Charlie v2.0 conductance neurons coordinate site assessments. Two sites form a corroborating group, creating **four groups of pairs-of-pairs**. All parent implementations are unchanged, archived in this release, and checksum-verified.

## What this actually does

The demonstrator executes a *distributed surface-inspection triage agent*. It receives eight synchronized normalized RGB signals (from a deterministic artificial world), preserves eight separate Daughter/Delta state pairs, sends partner and neighbor pulses with **one-step delay**, and uses eight Charlie conductance neurons with held-over temporal evidence. A group issues the bounded action `REQUEST_INSPECTION_SIMULATED` only after both of its independent sites exceed a threshold for the prescribed duration. It stops repeat reports until both inputs clear for at least three steps. This is an actual finite decision procedure, not free-form planning, intelligence, robot control or physical scanning.

The **growth** mode activates two Daughter/Delta pairs initially and releases another two pairs when the explicit pending-work queue reaches its programmed 12-work-item budget. Four pair-of-pairs groups (eight pairs) are active by the last stage. Source neurons are instantiated fresh when activated, and inactive sites generate no observations or spikes. This is *software allocation and task-driven colonization*, **not** independent reproduction or learning.

## Source and role map

- `charlie_core/neuron.py`: **unchanged Charlie Core v2.0** with internal conductance, synaptic memory and adaptive spiking; trained weights are imported without modification.
- `vendor/src/triplet-neuron.mjs`: **unchanged Daughter Δ³ v3.1**, three coupled photoreceptor, dendrite and soma layers.
- `vendor/vault/delta/delta-neuron.mjs`: **unchanged Ripple Delta v3.0**, temporal log contrast and event spiking.
- `paired_colony/pair_bridge.mjs`: **new** causal Node process with independent model instances; receives synthetic samples and delayed Charlie pulses.
- `paired_colony/engine.py`: **new** Python coordinator, workload generator and action comparator, seven ablations + bounded grow mode.
- `results/paired_colony.sqlite`: recorded simulation observations, actions and source hash provenance.
- `web/Charlie_Daughter_Delta_Colony_Replay.html`: standalone offline trace inspection.

The Node bridge uses `feedforward:false` when instantiating Delta—a documented choice of an existing option, **not** a modification of its source. RGB modifications triggered by local/cross/Charlie messages are explicitly **virtual encoded signals**, never physical emitted light.

## Reproduce

Requires Python 3.10+ and Node.js 20+. Only the optional figure-generation script needs matplotlib and NumPy.

```bash
cd Charlie_Daughter_Delta_Paired_Colony_v1_0
PYTHONPATH=. python -m paired_colony.cli --seed 101 --regime low_contrast --mode full --output results/my_run.json
PYTHONPATH=. python -m paired_colony.cli --seed 101 --regime low_contrast --mode grow --output results/my_growth_run.json
PYTHONPATH=. python -m unittest discover -s tests -p 'test_*.py' -q
(cd vendor && node --test tests/triplet.test.mjs)
python tools/build_results.py
```

There are no external API calls, cameras, motors, LLM weights, image-download requirements or background agents.

## Executed comparisons

Final set: 8 standard seeds × 8 policies = 64 runs; 6 stress regimes × 6 additional seeds × 8 policies = 288 runs; **352 software runs**, 90 synthetic steps per run. Seven modes are fixed populations, with `grow` as the eighth. These additional scenarios were iteratively developed and **are not an untouched preregistered/blinded scientific holdout**.

Low contrast (12 real-to-simulator incidents across 6 seeds):

| Mode | Detections | FP | Mean latency, simulator steps |
|---|---:|---:|---:|
| Full links + Charlie feedback | 12/12 | 0 | 5.000 |
| Cross-pair links only | 12/12 | 0 | 5.167 |
| Charlie feedback only | 12/12 | 0 | 7.500 |
| Local Daughter–Delta pairs only | 12/12 | 0 | 7.667 |
| Unpaired (same nodes, no links) | 12/12 | 0 | 8.000 |
| Charlie alone | 12/12 | 0 | 6.500 |
| Fixed RGB threshold | 0/12 | 0 | N/A |
| Task-driven growing colony | **11/12** | 0 | 5.917 across cases that detected |

The static comparator uses a simple predeclared RGB threshold, so its low-contrast failure is **not a controlled comparison against all possible tuned static algorithms**. The new full network reduces modeled latency by 3 steps (0.3 model seconds) versus disconnected neurons in this designed condition; **no physical response-time benefit is established**.

**Negative controls:** Polarity shift changes the encoded label meaning; all modes miss 12/12. Coordinated group-wide brief decoys generate 6 false alarms for the fixed full colony. Growing the colony avoids those early decoys only because the relevant group had not yet been activated; it is **not proven better at false-alarm rejection** and can miss genuine early incidents. These are important limitations, not features to hide.

All eight-node states are mutable, recurrent and audited. Event counts are program events, not thought or intelligence measurements. Paired models are not trained jointly; their coupling gains and decision thresholds were selected as software research parameters and are not optimized against independent physical data. No learning-based novel skill is demonstrated.

## Evidence and limitations

- **Executed:** exact parent models, cross-pair delayed signaling, Charlie feedback, bounded worker activation, finite action selection, tests, SQLite results, offline JavaScript viewer smoke.
- **Calculated:** test counts, percentages, source hashes, numerical thresholds, model timing in simulated seconds.
- **Proposed/unverified:** any connection to real RGB sensors, on-device performance, physical inspection capability, reliability outside generated distributions, cognitive capability or robotic motion.

See `docs/PAIR_COUPLING_AND_FAILURES.md` and `results/RELEASE_VERIFICATION.json` for the mathematical contracts and evidence.
