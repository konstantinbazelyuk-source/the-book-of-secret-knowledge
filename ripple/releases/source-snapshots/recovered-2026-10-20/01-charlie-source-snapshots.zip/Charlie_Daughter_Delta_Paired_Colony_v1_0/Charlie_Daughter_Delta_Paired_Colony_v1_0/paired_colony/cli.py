"""Deterministic numerical experiment CLI. No network or devices."""
import argparse,json
from pathlib import Path
from .engine import run,make_case,evaluate,MODES

def main():
 p=argparse.ArgumentParser(description='Charlie Daughter Delta multi-pair colony numerical test')
 p.add_argument('--seed',type=int,default=101);p.add_argument('--mode',choices=MODES,default='full')
 p.add_argument('--regime',default='low_contrast',choices=['standard','low_contrast','high_noise','short_events','slow_pair','polarity_shift','correlated_decoy'])
 p.add_argument('--full-benchmark',action='store_true');p.add_argument('--output',default=None)
 args=p.parse_args()
 report=evaluate() if args.full_benchmark else run(make_case(args.seed,regime=args.regime),args.mode,capture=True)
 txt=json.dumps(report,indent=2)
 if args.output:Path(args.output).write_text(txt)
 else:print(txt)
if __name__=='__main__':main()
