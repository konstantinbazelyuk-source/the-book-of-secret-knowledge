/** Exact archived Daughter and Delta classes, independent state per node.
 * Messages from the previous timestep only; synthetic virtual channels.
 */
import readline from 'node:readline';
import {DaughterTripletNeuron} from '../vendor/src/triplet-neuron.mjs';
import {DeltaRippleNeuron} from '../vendor/vault/delta/delta-neuron.mjs';
const clip=(x,a=0,b=1)=>Math.min(b,Math.max(a,x));
const fresh=()=>({daughter:new DaughterTripletNeuron(),delta:new DeltaRippleNeuron({feedforward:false}),local:0,toD:0,toDelta:0,cross:0});
const nodes=Array.from({length:8},()=>null);
const lines=readline.createInterface({input:process.stdin,crlfDelay:Infinity});
let counter=0;
for await(const line of lines){
 try{
  const req=JSON.parse(line);
  if(req.command==='reset') {nodes.fill(null);counter=0;process.stdout.write('{"ok":true,"reset":true}\n');continue;}
  if(req.command!=='step'||!Array.isArray(req.rgb)||req.rgb.length!==8||!(req.dt>0&&req.dt<=.2)||!Array.isArray(req.feedback)||req.feedback.length!==8||!['full','local','unpaired','cross_only','feedback_only','grow'].includes(req.mode))throw Error('invalid frame');
  if(req.mode==='grow'&&(!Array.isArray(req.active)||req.active.length!==8||req.active.some(v=>typeof v!=='boolean')))throw Error('invalid growth activation mask');
  const results=[];
  for(let i=0;i<8;i++){
   const rgb=req.rgb[i];
   const active=req.mode!=='grow'||(Array.isArray(req.active)&&req.active.length===8&&req.active[i]===true);
   if(!active){results.push({site:i,active:false,daughter:{count:0,d:0,u:0,quad:'0'},delta:{count:0,change:0,quad:'0'},received:{local:0,cross:0,feedback:0}});continue;}
   if(!nodes[i])nodes[i]=fresh();
   const n=nodes[i];
   if(!Array.isArray(rgb)||rgb.length!==3||rgb.some(v=>!Number.isFinite(v)||v<0||v>1)||!Number.isInteger(req.feedback[i])||req.feedback[i]<0||req.feedback[i]>8)throw Error('bad source data');
   const loc=req.mode==='unpaired'?0:n.local,cross=['full','cross_only','grow'].includes(req.mode)?n.cross:0,fb=['full','feedback_only','grow'].includes(req.mode)?req.feedback[i]:0;
   const toD=req.mode==='unpaired'?0:n.toD, toDelta=req.mode==='unpaired'?0:n.toDelta;
   const daughter=n.daughter.step([clip(rgb[0]+.06*toD+.025*cross),clip(rgb[1]+.025*fb),rgb[2]],req.dt);
   const delta=n.delta.step([clip(rgb[0]+.015*cross),clip(rgb[1]+.06*toDelta),rgb[2]],req.dt);
   results.push({site:i,active:true, daughter:{count:daughter.count,d:daughter.layer2.dendrite,u:daughter.u,quad:daughter.quad.state},delta:{count:delta.count,change:delta.delta,quad:delta.quad.state},received:{local:loc,cross,feedback:fb}});
  }
  // Queued output for t+1; no current-tick cross-talk.
  for(let i=0;i<8;i++){
   const j=i%2?i-1:i+1,n=nodes[i];if(!n)continue;
   n.toD=req.mode==='unpaired'?0:Math.min(3,results[i].delta.count);
   n.toDelta=req.mode==='unpaired'?0:Math.min(3,results[i].daughter.count);
   n.local=n.toD+n.toDelta;
   n.cross=['full','cross_only','grow'].includes(req.mode)?Math.min(3,results[j].daughter.count+results[j].delta.count):0;
  }
  process.stdout.write(JSON.stringify({ok:true,index:++counter,pairs:results})+'\n');
 }catch(err){process.stdout.write(JSON.stringify({ok:false,error:String(err)})+'\n');}
}
