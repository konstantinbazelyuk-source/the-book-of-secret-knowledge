# Foresting colonization mathematics and evidence

## Model definition and relationship to previous Ripple

This study **reuses** the Charlie v2 conductance-based adaptive neuron and Charlie v1.1 relay controller verbatim; it deliberately tests them under a new task before claiming an improvement. The original Ripple v0.1 is archived but not executed as the forest agent. The task is not real ecology or an animal/cognitive intelligence test.

Worker `w` has local known-cell map `K_w`, visited-cell set `V_w`, energy `E_w` and six independent Charlie v2 conductance cells. Per timestep 0.05 simulated seconds, each worker observes two neighboring cells, receives synthetic RGB and distance/age/quality values, updates its recurrent membrane state, and selects one of `MOVE_LEFT`, `MOVE_RIGHT`, `REQUEST_NEW_SCAN`, `HOLD_UNRESOLVED`.

The inherited dynamic evidence (new v1.1 controller, **not rewritten here**) is:

`z_{side,t+dt} = clip[-1.5,1.5]( exp(-dt/0.43) z_{side,t} + (1-exp(-dt/0.43)) e_side q_side + .082 * relay_spikes + .052 * delivered_prior_link_pulses )`

The `MOVE` action still requires range in [120,220] mm, age <=.25 s, image quality >=.65, trained visual readout >=.70 and memory >=.56. The artificial `mm` values are synthetic feature units shaped like a range sensor; they do not measure an actual distance. Actual movement in the grid is one neighboring cell, not a displacement in millimeters. Spikes are events in the simulated conductance model, **not generated thoughts**.

## Forest world and conserved-resource mathematics

A cell has static environment labels `(obstacle, water, light)` and mutable `(nutrient n, biomass b, planted)`. The model uses one resource unit for `n` and `b`; it has no density units. A worker can establish a model patch only when environmental attributes lie in chosen eligibility intervals, and then transfers a seed mass 0.12 from `n` to `b`. Every growth step applies:

`g = min(n, max(0, 0.06*min(water,light)*b*(1-b/1.25)))`

`b_next=b+g; n_next=n-g`

When b >= 0.4, a deterministic seeded draw can disperse mass 0.055 from donor biomass to a neighboring eligible empty cell, preserving total mass. The chosen 2% event threshold is arbitrary experimental tuning; it is **not** derived from measured forest seed transport. For all valid steps:

`sum_over_cells(n+b)_{t+1} = sum_over_cells(n+b)_t`

The 24 executed runs gave a maximum stored conservation error of zero within 10 decimal places. Floating-point arithmetic is approximate, not symbolic exactness.

Workers can spawn only under a bounded energy/novelty rule and population <=5. Clone populations are software objects. The same spawning and seed physics are used across model variants. World generator seed fixes obstacles and initial cell resource values. Sensor faults are seeded independently of policy execution order. Synthetic labels are created by the world simulator and delivered as channel and range samples; world truth is not passed as a model argument into the recurrent neuron decision.

## Paired experiment and limitations

Six worlds `(11,13,17,19,23,29)`, each with four policies, 160 time steps. Metrics: unique worker-visited cells, learned known cells, established patch count, simulated resource biomass, move count, vetoed unsafe attempts, clone events, number of emitted neuron spikes. More workers or spikes do **not** establish greater intelligence. This is a small finite set of synthetic scenarios, not a statistically powered ecological study.

Ablations hold the world, policy parameters, and scene generator constant; `spikes_off` disables relay-event contribution to decisions; `links_off` removes inter-neuron links but preserves local relay spikes. A difference in the numerical result is causal **within this software design**, not proof of superior real-world behavior. The original static controller has more coverage and growth at this point.

## Research references

1. USDA Forest Service, *LANDIS Landscape Disturbance and Succession model* — seed dispersal, spatial grid, establishment, competition and disturbances: https://research.fs.usda.gov/nrs/products/dataandtools/landis-landscape-disturbance-and-succession-model
2. LANDIS-II Foundation, spatial forest landscape modeling: https://www.landis-ii.org/
3. FORMIND technical documentation, *Recruitment and establishment* — local seed pools and dispersal kernels: https://formind.pages.ufz.de/recruitment-establishment.html
4. Dorigo et al., *Ant Colony Optimization: A New Meta-Heuristic* — bounded trail-memory and evaporation architecture as analogy, not copied code: https://staff.washington.edu/paymana/swarm/dorigo99-cec.pdf
5. xAI API reference, authenticated Responses API: https://docs.x.ai/developers/rest-api-reference/inference
6. Google AI for Developers, authenticated `generateContent`: https://ai.google.dev/api/generate-content

The forest model has not been fitted to LANDIS, FORMIND, or any calibrated biophysical field observations.

## External AI and ChatGPT honesty

The 16-case ChatGPT manual scoring experiment is a **rubric-compliance audit**, not an independently hosted model comparison: this assistant authored responses after reading the exact rules and inputs, then the software graded those stored responses. A simple deterministic rule engine can also achieve 16/16 on these explicit cases. Results cannot be compared to Charlie's 160-step forest exploration as a language-intelligence measurement.

There was **no live xAI or Gemini inference**. Both providers require separate model access and authorization, which were not configured in this session. The adapter can be executed with real credentials later and records only actual returned output. A cloud GitHub Actions job, if run, validates numerical reproducibility—not LLM reasoning.
