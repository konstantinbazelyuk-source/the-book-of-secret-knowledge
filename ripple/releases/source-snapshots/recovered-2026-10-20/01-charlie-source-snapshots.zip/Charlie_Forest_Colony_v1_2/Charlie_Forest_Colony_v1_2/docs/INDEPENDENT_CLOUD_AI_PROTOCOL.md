# Independent Grok, Gemini, and ChatGPT evaluation protocol

1. Freeze cases and grading rubric before external model execution (`results/llm_case_prompts.json`). Every case includes only typed present-time observations and no simulated oracle verdict.
2. Keep a ledger with provider, exact API model ID, input prompt SHA-256, timestamp, generation settings, returned raw text and parsed `LEFT`, `RIGHT`, or `SCAN` decision. Never fill unexecuted response fields with plausible guesses.
3. Authenticate to xAI Responses API with `XAI_API_KEY` or Gemini `generateContent` with `GEMINI_API_KEY`. Protect credentials with environment variables or cloud secrets; never commit them to source. Independent model use may incur charges. Model IDs and pricing must be verified immediately before sending requests.
4. Run `python -m src.model_compare --provider xai --model <authorized-model>` or `--provider gemini --model <authorized-model>`. Exit on missing credentials, non-2xx HTTP, malformed responses or incomplete outputs. An `INVALID` response does not become a chosen action.
5. Compare all models using identical cases, instructions and current-observation-only access. For longitudinal foresting benchmarks, use repeated per-step calls with controlled history contexts and explicit budgets; those have NOT been implemented or run in v1.2.
6. Report language-model snapshot accuracy separately from Charlie's multi-agent forest navigation. Separate unknown labels, unsafe actions, missed safe actions, latency, token cost, and remote inference usage. Never mistake ChatGPT session manual selections for a connected ChatGPT API invocation.

Provider docs: https://docs.x.ai/developers/rest-api-reference/inference ; https://ai.google.dev/api/generate-content
