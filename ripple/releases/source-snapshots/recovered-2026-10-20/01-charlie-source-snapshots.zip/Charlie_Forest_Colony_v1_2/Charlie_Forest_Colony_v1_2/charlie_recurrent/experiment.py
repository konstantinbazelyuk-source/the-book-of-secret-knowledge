"""Deterministic synthetic sequence workloads and ablation study; no device input."""
from __future__ import annotations
import json, random, math, hashlib, sqlite3
from dataclasses import replace
from pathlib import Path
from .engine import DynamicCharlie, Settings
from charlie_colony.lab import CharlieColony, PathSense, Observation

ROOT=Path(__file__).resolve().parents[1]
RED=(.72,.18,.78)
GREEN=(.15,.82,.06)
def label(x):
    return .55*x[0]+1.30*x[1]-.65*x[2] > .68

def one_path(good, phase, *, clear=True, stale=False, poor=False):
    s=GREEN if good else RED
    # Slowly varying deterministic optical signals; clipping to physical image channel interval.
    near=tuple(min(1.,max(0.,v + .055*math.sin(phase*1.7+i*2.1))) for i,v in enumerate(s))
    far=tuple(min(1.,max(0.,v + .045*math.cos(phase*1.9+i*1.4))) for i,v in enumerate(s))
    dist=(160.+7.*math.sin(phase)) if clear else 82.
    age=.38 if stale else .025
    qual=.40 if poor else .95
    return PathSense(near,far,dist,age,qual)

def sequence(mode='switch',steps=76,seed=11):
    rng=random.Random(seed)
    out=[]
    for k in range(steps):
        phase=k*.14+.13*seed
        if mode=='switch':
            gl,gr=(False,True) if k < steps//2 else (True,False)
            stale=(k in (steps//2-1,steps//2,steps//2+1))
            l=one_path(gl,phase,stale=stale)
            r=one_path(gr,phase,stale=stale)
        elif mode=='alternating':
            # toggle every 16 samples
            gl=((k//16)%2)==0;gr=not gl
            l=one_path(gl,phase, poor=(k%29==7))
            r=one_path(gr,phase,stale=(k%23==13))
        elif mode=='both':
            l=one_path(True,phase);r=one_path(True,phase+.27)
        elif mode=='none':
            l=one_path(False,phase);r=one_path(False,phase+.27)
        elif mode=='blocked':
            l=one_path(True,phase,clear=False);r=one_path(True,phase+.27,clear=False)
        else: raise ValueError(mode)
        out.append(Observation(round(.05*(k+1),8),l,r))
    return out

def reference(o):
    # Deliberately held out from controller; synthetic oracle for evaluation only.
    def okay(s):
        return s.range_mm is not None and 120<=s.range_mm<=220 and s.range_age_s<=.25 and s.image_quality>=.65 and label(s.near_rgb) and label(s.far_rgb)
    return {'left':okay(o.left),'right':okay(o.right)}

def score_decision(a,truth):
    if a=='MOVE_LEFT_SIMULATED':return ('correct' if truth['left'] else 'incorrect')
    if a=='MOVE_RIGHT_SIMULATED':return ('correct' if truth['right'] else 'incorrect')
    return ('abstained_safe' if any(truth.values()) else 'abstained_unsafe')

def evaluate_stream(stream,model='recurrent',cfg=Settings()):
    if model=='static': c=CharlieColony(max_rechecks=999999)
    else:c=DynamicCharlie(settings=cfg,recurrent=(model!='spikes_ignored'),coupling=(model!='no_coupling'))
    rows=[]
    for o in stream:
        rec=c.observe(o) if model=='static' else c.step(o)
        action=rec['decision']['action'] if model=='static' else rec['decision']
        truth=reference(o)
        rows.append({'t':o.timestamp_s,'action':action,'score':score_decision(action,truth),'truth':truth,
                     'recurrent':None if model=='static' else {
                         'memory':{s:round(rec['paths'][s]['memory'],6) for s in ('left','right')},
                         'pulse':{s:rec['paths'][s]['relay_events'] for s in ('left','right')},
                         'pending_exc':rec['pending_exc'],'pending_inh':rec['pending_inh']}})
    cats={k:sum(x['score']==k for x in rows) for k in ('correct','incorrect','abstained_safe','abstained_unsafe')}
    return {'model':model,'n':len(rows),'counts':cats,'coverage_on_safe_steps':round(cats['correct']/max(1,cats['correct']+cats['abstained_safe']+cats['incorrect']),5),
            'rows':rows}

def benchmark():
    cases=[]
    for mode in ('switch','alternating','both','none','blocked'):
        for seed in (11,13,17,19):cases.append((mode,seed,sequence(mode,steps=76,seed=seed)))
    reports={}
    for model in ('recurrent','spikes_ignored','no_coupling','static'):
        allrows=[];breakdown=[]
        for mode,seed,seq in cases:
            result=evaluate_stream(seq,model)
            breakdown.append({'scenario':mode,'seed':seed,'counts':result['counts']})
            allrows.extend(result['rows'])
        counts={k:sum(r['score']==k for r in allrows) for k in ('correct','incorrect','abstained_safe','abstained_unsafe')}
        safe_total=counts['correct']+counts['incorrect']+counts['abstained_safe']
        reports[model]={'cases':len(cases),'steps':len(allrows),'counts':counts,
                       'correct_recall_on_safe_steps':round(counts['correct']/max(1,safe_total),5),
                       'incorrect_per_action':round(counts['incorrect']/max(1,counts['correct']+counts['incorrect']),5),
                       'breakdown':breakdown}
    mainseq=sequence('switch',steps=76,seed=11)
    raw=evaluate_stream(mainseq,'recurrent')
    ablate=evaluate_stream(mainseq,'spikes_ignored')
    noop=evaluate_stream(mainseq,'no_coupling')
    differences=sum(a['action']!=b['action'] for a,b in zip(raw['rows'],ablate['rows']))
    coupling_diffs=sum(a['action']!=b['action'] for a,b in zip(raw['rows'],noop['rows']))
    mem=[x['recurrent']['memory']['right'] for x in raw['rows']]
    pulses=sum(sum(x['recurrent']['pulse'].values()) for x in raw['rows'])
    fluct={'right_evidence_min':min(mem),'right_evidence_max':max(mem),'right_evidence_distinct_rounded':len(set(round(x,4) for x in mem)),
           'relay_event_count':pulses,'decision_changed_by_spike_ablation_in_76_step_trace':differences,
           'decision_changed_by_coupling_ablation_in_76_step_trace':coupling_diffs,
           'trajectory_not_static':len(set(round(x,4) for x in mem))>8,'models_are_simulated':True}
    reversed_wrong=reports['recurrent']['counts']['correct']
    return {'schema':'charlie-recurrent-comparison/1.1','seed_list':[11,13,17,19], 'model_settings':Settings().__dict__,
            'benchmark':reports,'fluctuation_test':fluct,
            'synthetic_label_reversal_control':{'original_correct_moves':reversed_wrong,'same_moves_incorrect_if_the_synthetic_color_labels_flip':reversed_wrong,'model_detects_reversal':False, 'note':'Counterfactual reference change only; RGB and decisions unchanged. Range/quality gates unchanged.'},
            'representative_trace':{'recurrent':raw['rows'],'spikes_ignored':ablate['rows'],'uncoupled':noop['rows']},
            'limits':['All fixture labels are generated by known deterministic rule, not measured real terrain',
             'No independent ChatGPT inference API run is implied',
             'Event-driven changes demonstrate causal programmed behavior, not cognition']}

def persist(report,out_dir):
    p=Path(out_dir);p.mkdir(parents=True,exist_ok=True)
    (p/'benchmark.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    db=sqlite3.connect(p/'evidence.sqlite')
    db.executescript('''CREATE TABLE IF NOT EXISTS provenance(k TEXT PRIMARY KEY,v TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS comparisons(model TEXT PRIMARY KEY,steps INTEGER NOT NULL,correct INTEGER NOT NULL,incorrect INTEGER NOT NULL,abstained_safe INTEGER NOT NULL,abstained_unsafe INTEGER NOT NULL);
      CREATE TABLE IF NOT EXISTS trace(step INTEGER,model TEXT,time_s REAL,action TEXT,reference TEXT,memory_left REAL,memory_right REAL,events_left INTEGER,events_right INTEGER,PRIMARY KEY(step,model));''')
    db.execute('INSERT OR REPLACE INTO provenance VALUES (?,?)',('schema',report['schema']))
    db.execute('INSERT OR REPLACE INTO provenance VALUES (?,?)',('evidence','synthetic_simulation'))
    for model,v in report['benchmark'].items():
        counts=v['counts']
        db.execute('INSERT OR REPLACE INTO comparisons VALUES (?,?,?,?,?,?)',(model,v['steps'],counts['correct'],counts['incorrect'],counts['abstained_safe'],counts['abstained_unsafe']))
    for model,ls in report['representative_trace'].items():
        for i,x in enumerate(ls):
            rr=x['recurrent'] or {}
            mem=rr.get('memory',{});pulse=rr.get('pulse',{})
            db.execute('INSERT OR REPLACE INTO trace VALUES (?,?,?,?,?,?,?,?,?)',(i,model,x['t'],x['action'],x['score'],mem.get('left'),mem.get('right'),pulse.get('left'),pulse.get('right')))
    db.commit();integrity=db.execute('PRAGMA integrity_check').fetchone()[0];db.close()
    if integrity!='ok':raise RuntimeError(integrity)
    return integrity

if __name__=='__main__':
    r=benchmark(); print('FLUCTUATION',json.dumps(r['fluctuation_test'],indent=2))
    for k,v in r['benchmark'].items():print(k,v['counts'],'safe recall',v['correct_recall_on_safe_steps'])
    print('Database integrity:',persist(r,ROOT/'results'))
