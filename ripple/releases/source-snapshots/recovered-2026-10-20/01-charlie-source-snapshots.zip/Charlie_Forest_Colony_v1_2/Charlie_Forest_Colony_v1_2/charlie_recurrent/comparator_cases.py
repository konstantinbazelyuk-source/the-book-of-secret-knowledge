"""Freeze a small, predeclared case set for one-session human-readable ChatGPT comparison."""
from .experiment import sequence,reference,label
from .engine import DynamicCharlie
from charlie_colony.lab import CharlieColony
from pathlib import Path
import json

CASE_SELECTION=[('switch',11,12),('switch',11,35),('switch',11,37),('switch',11,41),('switch',11,66),
 ('alternating',13,10),('alternating',13,18),('alternating',13,34),('alternating',13,57),
 ('both',17,30),('none',17,30),('blocked',19,30)]

def build_cases():
    cache={};out=[]
    for i,(mode,seed,k) in enumerate(CASE_SELECTION,1):
        key=(mode,seed)
        if key not in cache:
            obs=sequence(mode,76,seed)
            dyn=DynamicCharlie();static=CharlieColony(max_rechecks=999999)
            d=[dyn.step(x) for x in obs]
            s=[static.observe(x) for x in obs]
            cache[key]=(obs,d,s)
        obs,d,s=cache[key]
        o=obs[k]
        def summary(y):
            return {'near_rgb':[round(z,3) for z in y.near_rgb],
                 'far_rgb':[round(z,3) for z in y.far_rgb],
                 'clearance_mm':round(y.range_mm,2) if y.range_mm is not None else None,
                 'reading_age_s':y.range_age_s,'image_quality':y.image_quality}
        out.append({'id':f'CASE_{i:02}', 'mode':mode,'seed':seed,'step':k+1,'time_s':o.timestamp_s,
         'left':summary(o.left),'right':summary(o.right),
         'previous_dynamic_action':d[k-1]['decision'] if k>0 else None,
         'current_dynamic_action':d[k]['decision'],
         'current_static_action':s[k]['decision']['action'],
         'ground_truth_private_until_scoring':reference(o)})
    return out
if __name__=='__main__':
    out=build_cases(); p=Path(__file__).resolve().parents[1]/'results'/'gpt6_comparator_cases.json'
    p.write_text(json.dumps(out,indent=2)+'\n')
    for x in out: print(x['id'],x['mode'],x['time_s'], 'L',x['left'],'R',x['right'],'Charlie',x['current_dynamic_action'])
