"""A testable recurrent *decision* controller around the unchanged Charlie v2 neuron.

Synthetic study, no physical robot, no LLM, no consciousness assertions.
All motor outputs are candidate labels and never issue actuation commands.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from math import exp, isfinite
from pathlib import Path
import json

from charlie_core.neuron import CharlieNeuron
from charlie_core.network import CharlieCoreNetwork
from charlie_colony.lab import Observation, PathSense

ROOT=Path(__file__).resolve().parents[1]
WEIGHTS=json.loads((ROOT/'legacy/v2_trained_core_state_LOCKED.json').read_text())['weights']

@dataclass(frozen=True)
class Settings:
    memory_tau_s: float = 0.43
    recurrent_gain: float = 0.082
    coupling_gain: float = 0.052  # delivered one-step-late visual neuron pulses, separate from relay spiking
    commitment_threshold: float = 0.56
    minimum_visual_score: float = 0.70
    minimum_clearance_mm: float = 120.0
    maximum_clearance_mm: float = 220.0
    maximum_range_age_s: float = 0.25
    minimum_image_quality: float = 0.65
    competitive_margin: float = 0.05
    max_requests: int = 4
    def __post_init__(self):
        vals=asdict(self)
        if any(isinstance(v,(float,int)) and not isfinite(float(v)) for v in vals.values()):
            raise ValueError('nonfinite settings')
        if not (0.05<=self.memory_tau_s<=10 and 0<=self.recurrent_gain<=.30 and 0<=self.coupling_gain<=.30 and 0<self.commitment_threshold<=1.5):
            raise ValueError('invalid model settings')
        if not (0<=self.minimum_visual_score<=1 and 0<=self.minimum_image_quality<=1):
            raise ValueError('invalid visual guard')

class DynamicCharlie:
    """6 mutable v2 neurons; 4 visual and 2 *virtual deliberation* relay cells.

    Directional spike coupling: left visual 0,1 -> relay 4; right visual 2,3 -> relay 5;
    relays inhibit one another with one sample delay. Relay RGB is explicitly a
    virtual score encoding (0,score,1-score), *not a physical spectrum*.

    Integrator z is not a probability or Bayesian posterior. Real recurrent spikes
    enter the decision variable; an ablation gain=0 removes their contribution.
    Physical clearance/freshness/quality vetoes always override z.
    """
    def __init__(self, *, settings:Settings=Settings(), recurrent:bool=True, coupling:bool=True):
        self.settings=settings
        self.recurrent=bool(recurrent)
        links=[(0,4,1),(1,4,1),(2,5,1),(3,5,1),(4,5,-1),(5,4,-1)] if coupling else []
        self.net=CharlieCoreNetwork([CharlieNeuron(weights=list(WEIGHTS)) for _ in range(6)],links)
        self.z={'left':0.,'right':0.}
        self.prev_t=0.
        self.steps=0
        self.requests=0
        self.output=[]
        self.last_decision='REQUEST_NEW_SCAN'

    def _read(self,sense:PathSense, p1:float, p2:float):
        cfg=self.settings
        valid_range=(sense.range_mm is not None and sense.range_age_s is not None and
            sense.range_age_s<=cfg.maximum_range_age_s and
            cfg.minimum_clearance_mm<=sense.range_mm<=cfg.maximum_clearance_mm)
        valid_quality=sense.image_quality>=cfg.minimum_image_quality
        score=(p1+p2)/2
        # Hard veto separated from learned visual score and spike state.
        hard_ok=valid_range and valid_quality
        if not valid_range: state='RANGE_UNKNOWN_STALE_OR_UNSAFE'
        elif not valid_quality: state='IMAGE_QUALITY_REJECTED'
        else: state='HARD_GATES_PASS'
        return score,hard_ok,state

    def step(self, observation:Observation):
        observation.check()
        dt=observation.timestamp_s-self.prev_t
        if not 0 < dt <= .5: raise ValueError('strictly increasing sample time and dt <= 0.5 required')
        self.prev_t=observation.timestamp_s
        senses=[observation.left,observation.right]
        optical=[senses[0].near_rgb,senses[0].far_rgb,senses[1].near_rgb,senses[1].far_rgb]
        probs=[self.net.cells[i].probability(x) for i,x in enumerate(optical)]
        assessments={}
        rgb_virtual=[]
        for j,side in enumerate(('left','right')):
            s,valid,why=self._read(senses[j],probs[j*2],probs[j*2+1])
            assessments[side]={'score':s,'hard_ok':valid,'status':why,'range_mm':senses[j].range_mm,
                              'range_age_s':senses[j].range_age_s,'image_quality':senses[j].image_quality}
            # Emit no high-confidence virtual evidence for unusable visual samples.
            code=s if senses[j].image_quality>=self.settings.minimum_image_quality else 0.
            rgb_virtual.append((0.,code,1.-code))
        # Capture pulses delivered NOW from the previous timestep: causal graph communication.
        incoming_to_relay=(self.net.pending_exc[4],self.net.pending_exc[5])
        traces=self.net.step(optical+rgb_virtual,dt)
        alpha=exp(-dt/self.settings.memory_tau_s)
        for j,side in enumerate(('left','right')):
            score=assessments[side]['score']
            q=senses[j].image_quality
            evidence=max(-1.,min(1.,(score-.50)*2.)) if q>=self.settings.minimum_image_quality else 0.
            pulses=traces[4+j]['count']
            linked_pulses=incoming_to_relay[j]
            # Decayed evidence plus a bounded *causal* spike contribution.
            self.z[side]=max(-1.5,min(1.5,alpha*self.z[side]+(1-alpha)*evidence*q+
                (self.settings.recurrent_gain*pulses+self.settings.coupling_gain*linked_pulses if self.recurrent else 0.)))
            assessments[side].update({'memory':self.z[side], 'relay_events':pulses, 'delivered_link_pulses':linked_pulses,
                                      'visual_events':traces[2*j]['count']+traces[2*j+1]['count'],
                                      'candidate':bool(assessments[side]['hard_ok'] and
                                        score>=self.settings.minimum_visual_score and
                                        self.z[side]>=self.settings.commitment_threshold)})
        options=[side for side in ('left','right') if assessments[side]['candidate']]
        if len(options)==2:
            if abs(self.z['left']-self.z['right'])<self.settings.competitive_margin:
                options=[] # explicitly delay a near-tie rather than hide tie resolution
        if options:
            side=max(options,key=lambda s:self.z[s])
            decision='MOVE_'+side.upper()+'_SIMULATED'
            reason='fresh safe range + valid image + sufficient *dynamic* evidence'
            self.requests=0
        else:
            if self.requests < self.settings.max_requests:
                decision='REQUEST_NEW_SCAN';reason='not enough verified and accumulated evidence';self.requests+=1
            else:decision='HOLD_UNRESOLVED';reason='bounded scan-request budget reached; no motion permitted; nonterminal hold until fresh evidence'
        self.steps+=1;self.last_decision=decision
        record={'time_s':round(observation.timestamp_s,5),'dt_s':round(dt,5),'decision':decision,
                'reason':reason,'paths':assessments,'relays':{
                    'left':{'u':traces[4]['membrane'],'exc':traces[4]['exc'],'inh':traces[4]['inh'],
                            'adapt':traces[4]['adapt'],'spikes':traces[4]['count']},
                    'right':{'u':traces[5]['membrane'],'exc':traces[5]['exc'],'inh':traces[5]['inh'],
                             'adapt':traces[5]['adapt'],'spikes':traces[5]['count']}},
                'pending_exc':list(self.net.pending_exc), 'pending_inh':list(self.net.pending_inh),
                'total_events':sum(r['count'] for r in traces),
                'explanation':'rule-rendered trace of computed states; not introspection',
                'evidence':'synthetic numerical experiment'}
        self.output.append(record)
        return record
