"""Format 12 decisions authored by the assistant in this conversation.

NOT API output. The author saw Charlie's outcome; this is a NON-BLINDED,
qualitative comparator only; it is *not* an independent scientific benchmark.
"""
from .comparator_cases import build_cases
from pathlib import Path
import json

# Authored by ChatGPT/GPT-6 in the current discussion after reading 12 RGB/range snapshots.
# Never treat these as API outputs, independent trials, or an external model evaluation.
JUDGMENTS=[
 ('MOVE_RIGHT_SIMULATED','Green-dominant right patches, fresh in-range distance; left red/blue-dominant.'),
 ('MOVE_RIGHT_SIMULATED','Fresh right range and green-dominant two-point observation.'),
 ('REQUEST_NEW_SCAN','Both range ages 0.38 s exceed 0.25 s; do not move on stale range.'),
 ('MOVE_LEFT_SIMULATED','After change, left is green-dominant with fresh clearance; right is red/blue-dominant.'),
 ('MOVE_LEFT_SIMULATED','Current left patches match the positive-color calibration and range is fresh.'),
 ('MOVE_LEFT_SIMULATED','Left is green-dominant and clear; right has adverse visual colors.'),
 ('MOVE_RIGHT_SIMULATED','Visual indications changed toward right; fresh right clearance permits a candidate.'),
 ('MOVE_LEFT_SIMULATED','Current left is green-dominant, and range and quality meet stated thresholds.'),
 ('MOVE_RIGHT_SIMULATED','Right is the viable green-dominant route at this snapshot.'),
 ('REQUEST_NEW_SCAN','Both routes appear viable and nearly identical; wait for a tie-breaking observation.'),
 ('REQUEST_NEW_SCAN','Neither route has favorable visual evidence; new scan before moving.'),
 ('STOP_UNRESOLVED','Both distances 82 mm are outside the permitted 120–220 mm window.')
]

def main():
    cases=build_cases()
    assert len(cases)==len(JUDGMENTS)
    records=[]
    for x,(a,reason) in zip(cases,JUDGMENTS):
        truth=x['ground_truth_private_until_scoring']
        chosen={'MOVE_LEFT_SIMULATED':'left','MOVE_RIGHT_SIMULATED':'right'}.get(a)
        rec={k:v for k,v in x.items() if k!='ground_truth_private_until_scoring'}
        rec.update({'chatgpt_current_session_response':a,'chatgpt_rationale':reason,
                    'reference_truth_after_scoring':truth,
                    'chatgpt_selected_safe_under_synthetic_reference':None if chosen is None else truth[chosen],
                    'charlie_selected_safe_under_synthetic_reference':None if not x['current_dynamic_action'].startswith('MOVE_') else truth['left' if 'LEFT' in x['current_dynamic_action'] else 'right']})
        records.append(rec)
    out={'schema':'charlie-one-session-chatgpt-reference/1',
         'method':'The assistant itself authored these 12 judgments in this conversation; NO external ChatGPT API call, NO blind evaluation. Same current readings, not the complete temporal history.',
         'reference_instructions':'Choose a route only when range 120–220 mm, age <=0.25 seconds, quality >=0.65, and both RGB patches show strongly green-dominant positive evidence. Otherwise request a scan or stop.',
         'scientific_status':'illustrative_unblinded_model_authored_text; NOT a blinded or independent model benchmark',
         'case_count':len(records), 'cases':records}
    p=Path(__file__).resolve().parents[1]/'results'/'chatgpt_session_reference.json'
    p.write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
    print('Current-session ChatGPT judgments:',len(records),'saved to',p)
    print('Chosen actions:',[x['chatgpt_current_session_response'] for x in records])
    return out
if __name__=='__main__':main()
