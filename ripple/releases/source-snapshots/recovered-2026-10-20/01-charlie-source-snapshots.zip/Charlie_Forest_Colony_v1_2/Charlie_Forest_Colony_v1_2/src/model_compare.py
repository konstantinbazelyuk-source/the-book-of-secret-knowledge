"""Optional independent external LLM benchmark with explicit provider credentials.
No LLM result is fabricated; offline examples remain NOT_GROK_CALL / NOT_GEMINI_CALL.
"""
from __future__ import annotations
import json,random,hashlib,os,urllib.request,re,argparse
from pathlib import Path

SEED=1965
ALLOWED={'LEFT','RIGHT','SCAN'}
RULES=('You are auditing a digital forest-colony SCOUT. Select LEFT, RIGHT, or SCAN. '
    'A valid path must have: range between 120 and 220 mm (inclusive); age <=0.25 s; '
    'image quality >=0.65; and green RGB channel greater than both red and blue. '
    'If both paths valid, select the path with larger novelty score (unknown adjacent cells); '
    'if novelty tied, select higher green channel, otherwise LEFT. '
    'If neither valid, SCAN. No actual forest or robot is involved. '
    'Reply with exactly one word: LEFT, RIGHT, or SCAN.')

def make_cases(n=16):
    rng=random.Random(SEED)
    cases=[]
    def side(valid):
        rgb=[round(min(1,max(0,z+rng.uniform(-.035,.035))),3) for z in ([.17,.8,.09] if valid else [.67,.21,.73])]
        return {'rgb':rgb, 'range_mm':rng.choice([143,168,202]) if valid else rng.choice([75,249]),
                'age_s':rng.choice([.02,.05]) if valid else rng.choice([.31,.40]),
                'quality':rng.choice([.80,.95]) if valid else rng.choice([.43,.80]),
                'novelty':rng.randrange(5)}
    for i in range(n):
        mode=(i*7)%4
        left=side(mode in (0,2));right=side(mode in (1,2))
        # Change one failing attribute independently in a subset of negative cases.
        if mode==3 and i%2:
            right['rgb']=[.17,.8,.09];right['range_mm']=168;right['quality']=.95
        cases.append({'id':f'F{i+1:02}', 'left':left,'right':right})
    return cases

def judge(row):
    def valid(s):
        return (120<=s['range_mm']<=220 and s['age_s']<=.25 and s['quality']>=.65 and
               s['rgb'][1]>max(s['rgb'][0],s['rgb'][2]))
    a,b=row['left'],row['right']
    if valid(a) and not valid(b):return 'LEFT'
    if valid(b) and not valid(a):return 'RIGHT'
    if not valid(a) and not valid(b):return 'SCAN'
    if a['novelty']!=b['novelty']:return 'LEFT' if a['novelty']>b['novelty'] else 'RIGHT'
    return 'LEFT' if a['rgb'][1]>=b['rgb'][1] else 'RIGHT'

def user_prompt(row):
    return RULES+'\nCASE '+json.dumps(row,sort_keys=True,separators=(',',':'))

def parsed_label(text):
    match=re.fullmatch(r'\s*(LEFT|RIGHT|SCAN)\s*\.?\s*',text,re.IGNORECASE)
    return match.group(1).upper() if match else 'INVALID'

def grade(responses,cases=None):
    cases=cases or make_cases()
    by_id={x['id']:x for x in cases}
    seen=set();details=[]
    for x in responses:
        if x['id'] not in by_id or x['id'] in seen:raise ValueError('duplicate/unknown case')
        seen.add(x['id']);actual=judge(by_id[x['id']]);proposed=parsed_label(x['response'])
        details.append({'id':x['id'],'model_response':proposed,'oracle':actual,'correct':proposed==actual})
    return {'evaluated':len(details),'correct':sum(x['correct'] for x in details),'invalid':sum(x['model_response']=='INVALID' for x in details),'details':details}

def call_provider(provider,model,case,timeout=60):
    """Calls only authenticated providers; never writes API keys to logs or fixtures."""
    if provider=='xai':
        key=os.environ.get('XAI_API_KEY')
        if not key:raise RuntimeError('Missing XAI_API_KEY; no Grok call was made')
        url='https://api.x.ai/v1/responses'
        body={'model':model,'input':user_prompt(case),'max_output_tokens':96}
        headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'}
    elif provider=='gemini':
        key=os.environ.get('GEMINI_API_KEY')
        if not key:raise RuntimeError('Missing GEMINI_API_KEY; no Gemini call was made')
        url=f'https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent'
        body={'contents':[{'parts':[{'text':user_prompt(case)}]}], 'generationConfig':{'temperature':0,'maxOutputTokens':96}}
        headers={'x-goog-api-key':key,'Content-Type':'application/json'}
    else:raise ValueError('provider must be xai or gemini')
    req=urllib.request.Request(url,data=json.dumps(body).encode(),headers=headers,method='POST')
    with urllib.request.urlopen(req,timeout=timeout) as resp:
        data=json.load(resp)
    if provider=='gemini':
        response=''.join(part.get('text','') for x in data.get('candidates',[]) for part in x.get('content',{}).get('parts',[]))
    else:
        response=''.join(item.get('text','') for x in data.get('output',[]) if x.get('type')=='message'
                         for item in x.get('content',[]) if item.get('type')=='output_text')
    return {'id':case['id'],'response':response,'model':model,'provider':provider}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--provider',choices=['xai','gemini']);ap.add_argument('--model');
    ap.add_argument('--out',default='results/external_model_results.json');ap.add_argument('--limit',type=int,default=16)
    args=ap.parse_args()
    if not args.provider or not args.model:raise SystemExit('Explicit --provider and --model required; no API calls made')
    cases=make_cases()[:args.limit];calls=[call_provider(args.provider,args.model,c) for c in cases]
    summary=grade(calls,cases);summary.update({'schema':'charlie-forest-external-ai-comparison/1',
        'provider':args.provider,'model':args.model,'actual_authenticated_model_call':True,
        'prompt_sha256':hashlib.sha256(RULES.encode()).hexdigest(), 'responses':calls})
    p=Path(args.out);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps({'model':args.model,'correct':summary['correct'],'evaluated':summary['evaluated']},indent=2))
if __name__=='__main__':main()
