"""Generate verified static plots, offline forest replay, and SQLite from executed benchmark."""
from __future__ import annotations
import json,sqlite3,hashlib,html
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
DATA=json.loads((ROOT/'results/forest_benchmark.json').read_text())

def build():
    r=ROOT/'results';dbfile=r/'forest_colony_evidence.sqlite'
    if dbfile.exists():dbfile.unlink()
    db=sqlite3.connect(dbfile)
    db.executescript('''
    CREATE TABLE provenance (k TEXT PRIMARY KEY, value TEXT NOT NULL);
    CREATE TABLE run (seed INTEGER, policy TEXT, digest TEXT, steps INTEGER, workers INTEGER, visited INTEGER, known INTEGER, planted INTEGER, biomass REAL, unsafe INTEGER, clones INTEGER, resource_error REAL, PRIMARY KEY(seed,policy));
    CREATE TABLE decision (seed INTEGER, policy TEXT, tick INTEGER, action TEXT, x INTEGER, y INTEGER, z_left REAL, z_right REAL, spikes_left INTEGER, spikes_right INTEGER, PRIMARY KEY(seed,policy,tick));
    CREATE TABLE map_cell (seed INTEGER,policy TEXT,x INTEGER,y INTEGER,kind TEXT,PRIMARY KEY(seed,policy,x,y));
    ''')
    db.execute('INSERT INTO provenance VALUES (?,?)',('schema','charlie-forest-evidence/1'))
    db.execute('INSERT INTO provenance VALUES (?,?)',('provenance','executed_synthetic_simulation'))
    for path,h in json.loads((ROOT/'docs/LOCKED_HASHES.json').read_text()).items():
        if hashlib.sha256((ROOT/path).read_bytes()).hexdigest()!=h:raise ValueError('locked source altered: '+path)
        db.execute('INSERT INTO provenance VALUES (?,?)',('source_sha256:'+path,h))
    for run in DATA['runs']:
        c=run['stats']
        db.execute('INSERT INTO run VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
                   (run['seed'],run['policy'],run['world_digest'],run['steps'],run['workers'],run['visited_unique'],
                    run['known_unique'],run['planted_total'],run['biomass_resource_units'],c['unsafe_moves'],
                    c['clones'],run['resource_conservation_error']))
        for x in run['root_history']:
            z=x['memory'] or {};sp=x['relay_spikes'] or [None,None]
            db.execute('INSERT INTO decision VALUES (?,?,?,?,?,?,?,?,?,?)',
                       (run['seed'],run['policy'],x['tick'],x['decision'],*x['position'],z.get('left'),z.get('right'),*sp))
        for y,row in enumerate(run['world_rows']):
            for x,kind in enumerate(row):
                db.execute('INSERT INTO map_cell VALUES (?,?,?,?,?)',(run['seed'],run['policy'],x,y,kind))
    db.commit()
    check=db.execute('PRAGMA integrity_check').fetchone()[0]
    assert check=='ok',check
    rowcount=db.execute('SELECT count(*) FROM decision').fetchone()[0]
    db.close()
    policies=['recurrent','spikes_off','links_off','static']
    labels=['Charlie recurrent','Spike term removed','Neuron links removed','Previous static']
    metrics=['visited_unique','planted_total']
    fig,ax=plt.subplots(figsize=(10,5.3))
    ax.bar([i-.2 for i in range(4)],[DATA['policies'][p]['visited_unique'] for p in policies],width=.38,label='Unique cells visited')
    ax.bar([i+.2 for i in range(4)],[DATA['policies'][p]['planted_total'] for p in policies],width=.38,label='Planted synthetic patches')
    ax.set_xticks(range(4),labels,rotation=12,ha='right');ax.set_ylabel('Mean count across six seeded worlds')
    ax.set_title('Charlie forest colonization: actual numerical benchmark, not real ecology')
    ax.legend();ax.set_ylim(0,215);ax.grid(axis='y',alpha=.2)
    fig.tight_layout();fig.savefig(r/'forest_policy_comparison.png',dpi=160);plt.close(fig)
    chosen=next(x for x in DATA['runs'] if x['seed']==11 and x['policy']=='recurrent')
    base=next(x for x in DATA['runs'] if x['seed']==11 and x['policy']=='static')
    fig,axs=plt.subplots(1,2,figsize=(10,5.4))
    for a,run,title in zip(axs,[chosen,base],['Charlie recurrent','Static rule-based baseline']):
        grid=np.array([[{'#':0,'.':1,'P':2}[k] for k in line] for line in run['world_rows']])
        a.imshow(grid,cmap='viridis',interpolation='nearest',vmin=0,vmax=2)
        a.set_title(f'{title}\n{run["planted_total"]} patches / {run["visited_unique"]} visited cells')
        a.set_xticks(range(0,16,4));a.set_yticks(range(0,16,4));a.set_xlim(-.5,15.5);a.set_ylim(15.5,-.5)
    fig.suptitle('One synthetic world, same seed = 11; darker cells blocked, brighter cells planted')
    fig.tight_layout();fig.savefig(r/'forest_world_comparison.png',dpi=160);plt.close(fig)
    seq=chosen['root_history'];fig,ax=plt.subplots(figsize=(10.4,4.2))
    ax.plot([p['tick']*.05 for p in seq],[p['memory']['left'] for p in seq],label='Left evidence state')
    ax.plot([p['tick']*.05 for p in seq],[p['memory']['right'] for p in seq],label='Right evidence state')
    ax.axhline(.56,linestyle='--',label='Action threshold')
    ax.set(xlabel='Simulated seconds',ylabel='Internal evidence state',title='Charlie numerical fluctuations while navigating a synthetic forest')
    ax.grid(alpha=.2);ax.legend();fig.tight_layout();fig.savefig(r/'recurrent_fluctuations.png',dpi=160);plt.close(fig)
    # Offline HTML with embedded real benchmark data; JS no browser-network calls.
    replay={'policies':DATA['policies'],'seed':chosen['seed'],'map':chosen['world_rows'],'root_history':seq,
            'static_map':base['world_rows'],'provenance':'Executed synthetic software, not device readings'}
    embedded=json.dumps(replay,separators=(',',':')).replace('<','\\u003c')
    page=f'''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>Charlie Forest Colony — Verified Numerical Replay</title><style>body{{background:#0b1720;color:#e6f0ec;font:15px system-ui;margin:0;padding:18px}}main{{max-width:1000px;margin:auto}}h1{{font-size:28px}}.cols{{display:grid;grid-template-columns:1fr 1fr;gap:15px}}section{{border:1px solid #35565b;border-radius:12px;padding:15px;background:#142730}}canvas{{width:100%;height:auto;background:#101b24;border-radius:8px}}input{{width:100%}}code,pre{{color:#b4e3cc}}@media(max-width:760px){{.cols{{grid-template-columns:1fr}}}}</style>
<main><h1>Charlie / Digital Forest Colony</h1><p>Replay of executed deterministic numerical output. No real plants, motors, sensors, independent LLMs, or demonstrated cognition.</p>
<div class="cols"><section><h2>Forest grid — seed 11</h2><canvas width="384" height="384" id="map"></canvas><p>Obstacles dark · open ground blue-gray · synthetic plant patches green.</p></section>
<section><h2>Recurrent evidence</h2><canvas width="480" height="300" id="plot"></canvas><label>Time step <b id="step">1</b><input type="range" min="0" max="159" value="0" id="slide"></label><pre id="state"></pre></section></div>
<section><h2>Recorded policy comparison</h2><div id="counts"></div><p>Changing the source of synthetic labels invalidates any assumed generalization. Static remains ahead on this forest task.</p></section></main>
<script>const data={embedded};const ctx=document.getElementById('map').getContext('2d');const P=document.getElementById('plot').getContext('2d');const slider=document.getElementById('slide');
const pal={{'#':'#25303a','.':'#406378','P':'#55aa78'}};
function draw(i){{ctx.clearRect(0,0,384,384);data.map.forEach((line,y)=>{{for(let x=0;x<line.length;x++){{ctx.fillStyle=pal[line[x]];ctx.fillRect(x*24,y*24,23,23)}}}});const row=data.root_history[i];ctx.strokeStyle='white';ctx.lineWidth=3;ctx.strokeRect(row.position[0]*24+3,row.position[1]*24+3,17,17);
P.clearRect(0,0,480,300);P.strokeStyle='#98afae';P.beginPath();P.moveTo(30,170);P.lineTo(475,170);P.stroke();for(const [key,col] of [['left','#e7b68b'],['right','#8dcadb']]){{P.strokeStyle=col;P.lineWidth=2;P.beginPath();data.root_history.forEach((v,k)=>{{const x=30+k*2.77,y=230-v.memory[key]*90;k?P.lineTo(x,y):P.moveTo(x,y)}});P.stroke()}}
P.fillStyle='#e9f4f5';P.font='14px system-ui';P.fillText('left (amber) / right (blue), action threshold dotted',25,20);P.strokeStyle='#dddddd';P.setLineDash([3,5]);P.beginPath();P.moveTo(30,230-.56*90);P.lineTo(475,230-.56*90);P.stroke();P.setLineDash([]);
P.strokeStyle='white';P.beginPath();P.moveTo(30+i*2.77,20);P.lineTo(30+i*2.77,270);P.stroke();document.getElementById('step').textContent=row.tick;
document.getElementById('state').textContent=JSON.stringify({{action:row.decision,position:row.position,spikes:row.relay_spikes,evidence:row.memory}},null,2)}}
document.getElementById('counts').textContent=Object.entries(data.policies).map(([k,v])=>k+': '+v.visited_unique+' mean visited, '+v.planted_total+' mean planted, '+v.unsafe_moves+' unsafe moves').join(' | ');
slider.addEventListener('input',()=>draw(Number(slider.value)));draw(0);</script></html>'''
    (ROOT/'web/Charlie_Forest_Colony_Replay.html').write_text(page)
    result={'schema':'charlie-forest-build-verification/1','sqlite_integrity':check,'decision_records':rowcount,
            'n_runs':len(DATA['runs']), 'core_hash_count':len(json.loads((ROOT/'docs/LOCKED_HASHES.json').read_text())),
            'unique_forest_digests':len(set(x['world_digest'] for x in DATA['runs'])),
            'resource_max_error':max(abs(x['resource_conservation_error']) for x in DATA['runs']),
            'external_ai_benchmarks_executed':False}
    (r/'build_verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':build()
