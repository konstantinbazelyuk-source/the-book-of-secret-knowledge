"""Bounded synthetic forest-colony benchmark for Charlie v2 recurrent 6-cell cores.

No physical forestry/robot/AI validation. No hidden truth fed to decision policy.
Original mathematical core is imported unchanged from archived v1.1 sources.
"""
from __future__ import annotations
import hashlib, json, math, random, sqlite3
from collections import deque
from dataclasses import dataclass, field, asdict
from pathlib import Path
from charlie_colony.lab import PathSense, Observation, CharlieColony
from charlie_recurrent.engine import DynamicCharlie,Settings

GREEN=(.15,.82,.06)
RED=(.72,.18,.78)
DIRS=((0,1),(1,0),(0,-1),(-1,0))

def cellhash(seed,*nums):
    b=':'.join(str(x) for x in (seed,*nums)).encode()
    return int.from_bytes(hashlib.blake2s(b,digest_size=8).digest(),'big')/2**64

@dataclass
class Patch:
    obstacle:bool
    water:float
    light:float
    nutrient:float
    biomass:float=0.
    planted:bool=False
    origin:str=''

class Forest:
    def __init__(self,seed:int,size:int=16):
        if not isinstance(seed,int) or not 7<=size<=64:raise ValueError('invalid world dimensions')
        self.seed=seed;self.size=size;self.patches={}
        for y in range(size):
            for x in range(size):
                obst=(cellhash(seed,x,y,0)<.18)
                water=.24+.72*cellhash(seed,x,y,1)
                light=.22+.72*cellhash(seed,x,y,2)
                nutrient=.45+.45*cellhash(seed,x,y,3)
                self.patches[(x,y)]=Patch(obst,water,light,nutrient)
        self.start=(size//2,size//2)
        self.patches[self.start].obstacle=False
        # Keep the initial root from being isolated by a wall.
        for dx,dy in DIRS:
            self.patches[(self.start[0]+dx,self.start[1]+dy)].obstacle=False
        self.total_initial_nutrient=sum(p.nutrient for p in self.patches.values())
        self.spread_count=0
    def inbounds(self,p):return 0<=p[0]<self.size and 0<=p[1]<self.size
    def neighbors(self,p):
        for dx,dy in DIRS:
            n=(p[0]+dx,p[1]+dy)
            if self.inbounds(n):yield n
    def passable(self,p):return self.inbounds(p) and not self.patches[p].obstacle
    def suitable(self,p):
        q=self.patches[p]
        return not q.obstacle and .4<=q.water<=.90 and .38<=q.light<=.86 and q.nutrient>=.15
    def plant(self,p,origin='worker'):
        if not self.suitable(p) or self.patches[p].planted:return False
        patch=self.patches[p]
        seed_mass=.12
        if patch.nutrient<seed_mass:return False
        patch.nutrient-=seed_mass;patch.biomass+=seed_mass;patch.planted=True;patch.origin=origin
        return True
    def grow(self,tick):
        # Local resource->biomass conversion conserves arbitrary resource units.
        oldmass=sum(q.nutrient+q.biomass for q in self.patches.values())
        for p,q in self.patches.items():
            if not q.planted:continue
            r=.06 * min(q.water,q.light)
            gain=min(q.nutrient,max(0.,r*q.biomass*(1-q.biomass/1.25)))
            q.nutrient-=gain;q.biomass+=gain
        # Seed mass transferred between patches, not synthesized from nothing.
        for pos in sorted(self.patches):
            q=self.patches[pos]
            if not q.planted or q.biomass<.40:continue
            for n in self.neighbors(pos):
                target=self.patches[n]
                if target.planted or not self.suitable(n):continue
                if cellhash(self.seed,tick,pos[0],pos[1],n[0],n[1],98)<.020:
                    q.biomass-=.055;target.biomass+=.055;target.planted=True
                    target.origin='seed_dispersal';self.spread_count+=1
                    break
        newmass=sum(q.nutrient+q.biomass for q in self.patches.values())
        if abs(newmass-oldmass)>1e-8:raise AssertionError(('conservation',oldmass,newmass))
    def digest(self):
        d=[(x,y,int(q.obstacle),round(q.water,5),round(q.light,5)) for (x,y),q in sorted(self.patches.items())]
        return hashlib.sha256(json.dumps(d).encode()).hexdigest()

@dataclass
class Worker:
    wid:int
    xy:tuple[int,int]
    policy:object
    energy:float=3.6
    known:dict=field(default_factory=dict)
    seen:set=field(default_factory=set)
    actions:int=0
    decisions:list=field(default_factory=list)

class Colony:
    def __init__(self,seed=19,policy='recurrent',steps=160,sharing=True):
        if policy not in ('recurrent','static','spikes_off','links_off'):raise ValueError(policy)
        self.world=Forest(seed);self.seed=seed;self.policy=policy;self.max_workers=5
        self.workers=[];self.steps=steps;self.sharing=sharing
        self.trace=[];self.root_history=[];self.stats={'planted_by_worker':0,'clones':0,'received_shared_cells':0,'duplicate_visits':0,
                                  'moves':0,'unsafe_moves':0,'requests':0,'holds':0,'sensor_errors':0,'spikes':0}
        self.next_id=0
        self._birth(self.world.start)
        self.relay_pending=[]
    def _controller(self):
        if self.policy=='static':return CharlieColony(max_rechecks=9999)
        return DynamicCharlie(recurrent=self.policy!='spikes_off',coupling=self.policy!='links_off')
    def _birth(self,xy,tick=0):
        if len(self.workers)>=self.max_workers: return None
        w=Worker(self.next_id,xy,self._controller());self.next_id+=1
        if self.policy!='static':w.policy.prev_t=tick*.05
        w.seen.add(xy);w.known[xy]='clear';self.workers.append(w)
        return w
    def _dist_to_unseen(self,start,known):
        # Local known-space route heuristic. Unknown space is never traversed in planning.
        frontier={p for p,state in known.items() if state=='clear' and any(n not in known for n in self.world.neighbors(p))}
        if not frontier:return 999
        todo=deque([(start,0)]);visited={start}
        while todo:
            cur,d=todo.popleft()
            if cur in frontier:return d
            for n in self.world.neighbors(cur):
                if n not in visited and known.get(n)=='clear':visited.add(n);todo.append((n,d+1))
        return 999
    def _candidates(self,w,tick):
        p=w.xy;adjs=list(self.world.neighbors(p))
        def rank(n):
            know=w.known.get(n)
            if know=='obstacle':return (9,9,9)
            unexplored=0 if know is None else 1
            return (unexplored,self._dist_to_unseen(n,w.known),cellhash(self.seed,tick,w.wid,*n,102))
        adjs.sort(key=rank)
        # The moving decision program expects two side channels. Unknown out-of-bounds = veto.
        return (adjs+[None,None])[:2]
    def _sense(self,w,target,tick):
        if target is None:return PathSense(RED,RED,0.,.01,1.)
        p=self.world.patches[target]
        # Optically synthetic RGB proxy, not real vegetation sensing.
        visual_clear=not p.obstacle
        rgb=GREEN if visual_clear else RED
        phase=.13*tick+.37*w.wid+target[0]*.16+target[1]*.08
        near=tuple(max(0.,min(1.,v+.018*math.sin(phase+2.1*i))) for i,v in enumerate(rgb))
        far=tuple(max(0.,min(1.,v+.017*math.cos(phase+1.5*i))) for i,v in enumerate(rgb))
        # Repeatable sensor faults keyed to world position/time rather than policy RNG order.
        h=cellhash(self.seed,w.wid,tick,*target,230)
        stale=h<.036;low_quality=.036<=h<.066
        bad_distance=p.obstacle
        if bad_distance:range_mm=78.
        else:range_mm=160.+8.*math.sin(phase)
        age=.41 if stale else .02
        quality=.35 if low_quality else .94
        if stale or low_quality:self.stats['sensor_errors']+=1
        # The agent can store observed classification only if *sensor* gates pass.
        if age<=.25 and quality>=.65:
            w.known[target]='obstacle' if bad_distance else 'clear'
        return PathSense(near,far,range_mm,age,quality)
    def _relay_share(self,tick):
        if not self.sharing:return
        new=[]
        for dst,entries in self.relay_pending:
            target=next((w for w in self.workers if w.wid==dst),None)
            if target is None:continue
            for pos,state in entries:
                if pos not in target.known:
                    target.known[pos]=state;self.stats['received_shared_cells']+=1
        self.relay_pending=new
        if tick%4: return
        for a in self.workers:
            for b in self.workers:
                if a.wid==b.wid or abs(a.xy[0]-b.xy[0])+abs(a.xy[1]-b.xy[1])>5:continue
                diff=[(k,v) for k,v in sorted(a.known.items()) if k not in b.known][:6]
                if diff:self.relay_pending.append((b.wid,diff))
    def run(self):
        for tick in range(1,self.steps+1):
            self._relay_share(tick)
            # One time slice per live logical worker, all virtual.
            for w in list(self.workers):
                pos0=w.xy
                choices=self._candidates(w,tick)
                sensed=[self._sense(w,p,tick) for p in choices]
                obs=Observation(tick*.05,sensed[0],sensed[1])
                rec=w.policy.observe(obs) if self.policy=='static' else w.policy.step(obs)
                act=rec['decision']['action'] if self.policy=='static' else rec['decision']
                destination=(choices[0] if act=='MOVE_LEFT_SIMULATED' else choices[1] if act=='MOVE_RIGHT_SIMULATED' else None)
                if act.startswith('MOVE_') and destination is not None:
                    if not self.world.passable(destination):
                        self.stats['unsafe_moves']+=1
                        # No movement on simulated unsafe decision.
                        destination=None
                    else:
                        w.xy=destination;w.energy-=.011;self.stats['moves']+=1
                        if w.xy in w.seen:self.stats['duplicate_visits']+=1
                        w.seen.add(w.xy)
                elif act=='REQUEST_NEW_SCAN':self.stats['requests']+=1
                else:self.stats['holds']+=1
                if w.xy not in w.known:w.known[w.xy]='clear'
                if self.world.plant(w.xy,origin='worker'):
                    self.stats['planted_by_worker']+=1
                    w.energy=min(5.,w.energy+.30)
                w.energy=max(0.,w.energy-.006)
                if self.policy!='static':self.stats['spikes']+=rec['total_events']
                w.actions+=1
                w.decisions.append(act)
                if w.wid==0:
                    self.root_history.append({'tick':tick,'decision':act, 'position':list(w.xy),
                        'memory':None if self.policy=='static' else dict(w.policy.z),
                        'relay_spikes':None if self.policy=='static' else [rec['relays']['left']['spikes'],rec['relays']['right']['spikes']]})
                # A guarded finite worker population, not autonomous process cloning.
                if (tick%12==0 and len(self.workers)<self.max_workers and
                    w.energy>2.6 and len(w.seen)>=4 and self.stats['planted_by_worker']>=2):
                    if cellhash(self.seed,tick,w.wid,302)<.60:
                        child=self._birth(w.xy,tick=tick)
                        if child:
                            w.energy-=.60
                            self.stats['clones']+=1
                if tick%8==0 or act.startswith('MOVE_') and tick<8:
                    self.trace.append({'tick':tick,'id':w.wid,'from':pos0,'to':w.xy,'action':act,
                        'energy':round(w.energy,4),'workers':len(self.workers),
                        'memory':None if self.policy=='static' else {k:round(v,5) for k,v in w.policy.z.items()},
                        'spikes':None if self.policy=='static' else rec['total_events']})
            self.world.grow(tick)
        return self.summary()
    def summary(self):
        touched=set().union(*(set(w.seen) for w in self.workers))
        explored=set().union(*(set(w.known) for w in self.workers))
        planted=sum(q.planted for q in self.world.patches.values())
        biomass=sum(q.biomass for q in self.world.patches.values())
        observed_clear=sum(not q.obstacle for q in self.world.patches.values())
        nutrientplus=sum(q.nutrient+q.biomass for q in self.world.patches.values())
        return {'seed':self.seed,'policy':self.policy,'steps':self.steps,'world_digest':self.world.digest(),
                'workers':len(self.workers),'agent_steps':sum(w.actions for w in self.workers),
                'visited_unique':len(touched),'known_unique':len(explored),'eligible_cells':observed_clear,
                'coverage_fraction':round(len(touched)/max(1,observed_clear),6),
                'planted_total':planted,'biomass_resource_units':round(biomass,6),
                'resource_conservation_error':round(nutrientplus-self.world.total_initial_nutrient,10),
                'stats':self.stats,'trace':self.trace,'root_history':self.root_history,
                'world_rows':[''.join('#' if self.world.patches[(x,y)].obstacle else 'P' if self.world.patches[(x,y)].planted else '.' for x in range(self.world.size)) for y in range(self.world.size)],
                'evidence':'deterministic numerical simulation; forestry and living intelligence unverified'}

def paired_benchmark(seeds=(11,13,17,19,23,29),steps=160):
    data=[]
    for s in seeds:
        for p in ('recurrent','spikes_off','links_off','static'):
            data.append(Colony(seed=s,policy=p,steps=steps).run())
    aggregate={}
    for p in ('recurrent','spikes_off','links_off','static'):
        ds=[x for x in data if x['policy']==p]
        aggregate[p]={
            k:round(sum(x[k] for x in ds)/len(ds),5) for k in ('visited_unique','known_unique','planted_total','biomass_resource_units','coverage_fraction')}
        aggregate[p]['unsafe_moves']=sum(x['stats']['unsafe_moves'] for x in ds)
        aggregate[p]['clones']=sum(x['stats']['clones'] for x in ds)
        aggregate[p]['moves']=sum(x['stats']['moves'] for x in ds)
        aggregate[p]['spikes']=sum(x['stats']['spikes'] for x in ds)
    return {'schema':'charlie-forest-benchmark/1','evidence':'executed local synthetic software','seeds':list(seeds),
            'steps':steps,'policies':aggregate,'runs':data,
            'limits':['world oracle only generates synthetic sensor readings and evaluation truth',
                      'no external language model executed by this benchmark',
                      'no measured ecology, plant establishment, self-reproduction, physical robotics or AGI']}

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--out',default='results/forest_benchmark.json');ap.add_argument('--steps',type=int,default=160)
    args=ap.parse_args()
    results=paired_benchmark(steps=args.steps)
    out=Path(args.out);out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(results,indent=2,allow_nan=False)+'\n')
    print(json.dumps(results['policies'],indent=2))
