"""Charlie Colony decision experiment (no physical sensor inputs).

The v2 neuron is executed verbatim. Its sigmoid readout is a task-specific
score learned on synthetic data; its spikes do NOT represent thoughts.
The decision grammar is deterministic and explicit; it is not an LLM.
"""
from __future__ import annotations
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Optional
import copy
import hashlib
import json
import math
import sqlite3
import uuid

from charlie_core.neuron import CharlieNeuron, valid_rgb, CoreParameters
from charlie_core.network import CharlieCoreNetwork

ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH=ROOT / 'legacy' / 'v2_trained_core_state_LOCKED.json'
DEFAULT_DT=0.05


def bound(v, lo, hi):
    return min(hi,max(lo,v))

@dataclass(frozen=True)
class PathSense:
    near_rgb: tuple[float,float,float]
    far_rgb: tuple[float,float,float]
    range_mm: Optional[float] = None
    range_age_s: Optional[float] = None
    image_quality: float = 1.0
    source: str = 'synthetic'
    def check(self):
        valid_rgb(self.near_rgb);valid_rgb(self.far_rgb)
        if self.source != 'synthetic':
            raise ValueError('this fixture lab accepts only explicit synthetic observations')
        if not math.isfinite(self.image_quality) or not 0 <= self.image_quality <= 1:
            raise ValueError('invalid image quality')
        if self.range_mm is None:
            if self.range_age_s is not None: raise ValueError('no range measurement for age')
        else:
            if self.range_age_s is None or not math.isfinite(self.range_age_s) or self.range_age_s < 0:
                raise ValueError('range age required')
            if not math.isfinite(self.range_mm) or not 0 <= self.range_mm <= 4000:
                raise ValueError('range invalid')

@dataclass(frozen=True)
class Observation:
    timestamp_s: float
    left: PathSense
    right: PathSense
    def check(self):
        if not math.isfinite(self.timestamp_s) or self.timestamp_s < 0:
            raise ValueError('invalid timestamp')
        self.left.check();self.right.check()

class CharlieColony:
    """6 genuinely independent v2 cells, 4 visual, 2 auxiliary virtual-state.

    Side choices DO NOT use the auxiliary nodes' uncalibrated spike counts;
    they are traces of independent internal dynamics and directed pulse coupling.
    """
    def __init__(self, *, trained:bool=True, min_clearance_mm=120., max_clearance_mm=220.,
                 max_age_s=.25, min_image_quality=.65, safe_score=.70,
                 max_rechecks=2):
        model=json.loads(MODEL_PATH.read_text())
        if model.get('schema')!='charlie-core-model/2.0': raise ValueError('wrong model version')
        w=model['weights'] if trained else [2.,1.2,1.4]
        self.node_names=['left_near','left_far','right_near','right_far','hazard_monitor','novelty_monitor']
        cells=[CharlieNeuron(weights=list(w)) for _ in self.node_names]
        # Directed, one-tick delayed, bounded event graph; no instantaneous recurrent loops.
        edges=[(0,4,1),(1,4,1),(2,5,1),(3,5,1),(4,5,-1),(5,4,-1)]
        self.network=CharlieCoreNetwork(cells, edges)
        self.min_clearance_mm=float(min_clearance_mm)
        self.max_clearance_mm=float(max_clearance_mm)
        self.max_age_s=float(max_age_s)
        self.min_image_quality=float(min_image_quality)
        self.safe_score=float(safe_score)
        self.max_rechecks=int(max_rechecks)
        self.rechecks=0
        self.last_time=None
        self.history={'left':[],'right':[]}
        self.steps=[]
        self.epoch=0
        self.trained=trained

    def _assess(self, obs:PathSense, side:str, near:float, far:float):
        raw=(near+far)/2
        valid_quality=obs.image_quality>=self.min_image_quality
        fresh=obs.range_mm is not None and obs.range_age_s <= self.max_age_s
        if not fresh:
            status='UNKNOWN_RANGE'
        elif not valid_quality:
            status='LOW_IMAGE_QUALITY'
        elif not self.min_clearance_mm<=obs.range_mm<=self.max_clearance_mm:
            status='UNSAFE_CLEARANCE'
        else:
            status='AVAILABLE'
        # Memory is only a decaying conservative mean of latest VISIBLE input scores.
        # It is not Bayesian belief and DOES NOT override missing range evidence.
        if valid_quality:
            self.history[side].append(raw)
            self.history[side]=self.history[side][-3:]
        filtered=sum(self.history[side])/len(self.history[side]) if self.history[side] else None
        candidate=status=='AVAILABLE' and filtered is not None and filtered>=self.safe_score
        return {'status':status,'near_score':round(near,6),'far_score':round(far,6),
                'instant_score':round(raw,6),'filtered_score':round(filtered,6) if filtered is not None else None,
                'vision_score_interpretation':'synthetic task-specific score, not calibrated safety probability',
                'range_mm':obs.range_mm,'range_age_s':obs.range_age_s,'image_quality':obs.image_quality,
                'candidate':candidate,'memory_samples':len(self.history[side])}

    def observe(self, observation:Observation, *, dt=DEFAULT_DT):
        observation.check()
        if self.last_time is not None and observation.timestamp_s <= self.last_time:
            raise ValueError('timestamps must increase strictly')
        if not math.isfinite(dt) or not 0 < dt <= 0.5:raise ValueError('invalid step duration')
        # All validation occurs before advancing the neuron states.
        L,R=observation.left,observation.right
        optical=[L.near_rgb,L.far_rgb,R.near_rgb,R.far_rgb]
        # The last two RGB triples are explicitly VIRTUAL, not camera measurements.
        missing=sum(s.range_mm is None for s in (L,R)) / 2
        hazard=sum((s.range_mm is not None and not self.min_clearance_mm <= s.range_mm <= self.max_clearance_mm)
                   for s in (L,R)) / 2
        aux=[(0,0,float(hazard)),(float(missing),0,0)]
        traces=self.network.step(optical+aux,dt)
        scores=[cell.probability(rgb) for cell,rgb in zip(self.network.cells[:4],optical)]
        left=self._assess(L,'left',scores[0],scores[1]);right=self._assess(R,'right',scores[2],scores[3])
        candidates={k:v for k,v in [('left',left),('right',right)] if v['candidate']}
        # Transparent deterministic decision algorithm, not an inferred conscious intention.
        if candidates:
            chosen=max(candidates,key=lambda x:(candidates[x]['filtered_score'],x=='right'))
            action='MOVE_'+chosen.upper()+'_SIMULATED'
            reason='range fresh/in bounds, image quality sufficient, and synthetic visual score above threshold'
            self.rechecks=0
        else:
            if self.rechecks < self.max_rechecks:
                action='REQUEST_NEW_SCAN'
                reason='no candidate meets all freshness, clearance, quality, and synthetic-score checks'
                self.rechecks+=1
            else:
                action='STOP_UNRESOLVED'
                reason='no qualified candidate after bounded repeat requests'
        self.epoch+=1;self.last_time=observation.timestamp_s
        result={'step':self.epoch,'time_s':observation.timestamp_s,
                'kind':'executed_synthetic_model','observations':{'left':asdict(L),'right':asdict(R)},
                'scores':{'left':left,'right':right},
                'neuron_events':{name:t['count'] for name,t in zip(self.node_names,traces)},
                'neuron_internal':{name:{'membrane':round(t['membrane'],6),'exc':round(t['exc'],6),
                                         'inh':round(t['inh'],6),'adapt':round(t['adapt'],6),
                                         'theta':round(t['theta'],6), 'spikes_total':t['total_events']}
                                   for name,t in zip(self.node_names,traces)},
                'pending_exc':list(self.network.pending_exc),
                'pending_inh':list(self.network.pending_inh),
                'decision':{'action':action,'reason':reason,'candidate_sides':list(candidates),
                            'rechecks_used':self.rechecks},
                'thought_trace':{
                    'observe':f"Left visual score {left['instant_score']:.3f}, right {right['instant_score']:.3f}; ranges {L.range_mm}/{R.range_mm} mm",
                    'interpret':f"Left {left['status']} ({left['filtered_score']}), right {right['status']} ({right['filtered_score']})",
                    'test':f"Threshold {self.safe_score:.2f}; allowed range [{self.min_clearance_mm:.0f}, {self.max_clearance_mm:.0f}] mm; fresh <= {self.max_age_s:.2f}s",
                    'choose':action,
                    'explain':reason,
                    'epistemic_status':'generated rule trace, NOT introspection or proof of cognition'
                }}
        self.steps.append(result)
        return result


def scenario_sequence():
    red=(.72,.18,.78);safe1=(.15,.82,.06);safe2=(.20,.76,.04)
    # 1. Unknown ranges should veto a high-scoring right image.
    # 2. Left drop and right safe reading select a safe scan path.
    # 3. New right sensor goes stale; do not move on remembered safety.
    # 4. Rechecked right sensor is fresh again; move right.
    def x(t,ll,rr):return Observation(t,ll,rr)
    return [
        x(0.05,PathSense(red,red),PathSense(safe1,safe2)),
        x(0.10,PathSense(red,red,85,0.01),PathSense(safe1,safe2,164,0.02)),
        x(0.15,PathSense(red,red,84,0.01),PathSense(safe1,safe2,164,.45)),
        x(0.20,PathSense(red,red,84,0.01),PathSense(safe1,safe2,160,.015)),
    ]


def counterfactuals():
    red=(.72,.18,.78);green=(.15,.82,.06)
    variants={
        'all_ranges_missing':Observation(.05,PathSense(red,red),PathSense(green,green)),
        'both_clearance_unsafe':Observation(.05,PathSense(red,red,80,.01),PathSense(green,green,90,.01)),
        'right_safe':Observation(.05,PathSense(red,red,80,.01),PathSense(green,green,165,.01)),
        'left_safe_if_evidence_swapped':Observation(.05,PathSense(green,green,165,.01),PathSense(red,red,80,.01)),
        'right_low_quality':Observation(.05,PathSense(red,red,80,.01),PathSense(green,green,165,.01,.3)),
    }
    return {name:CharlieColony().observe(obs)['decision']['action'] for name,obs in variants.items()}


def run_demo():
    c=CharlieColony()
    steps=[c.observe(o) for o in scenario_sequence()]
    return {'schema':'charlie-colony-reasoning/1.0','label':'executed synthetic software',
            'core_source_sha256':hashlib.sha256((ROOT/'charlie_core/neuron.py').read_bytes()).hexdigest(),
            'original_core_instantiated':False, 'trained_synthetic_weights':list(c.network.cells[0].weights),
            'node_names':c.node_names,'links':c.network.links,
            'time_step_s':DEFAULT_DT,'history_type':'bounded arithmetic average; not Bayesian inference',
            'scenarios':steps,'counterfactuals':counterfactuals(),
            'limitations':['virtual RGB auxiliary features are not physical channels','original training labels are synthetic',
                           'decision rules are human-written and transparent, not autonomous thought',
                           'spike counts are not thoughts or reliable obstacle detections',
                           'no physical range measurements or actuators']}


def write_db(report,dbfile):
    path=Path(dbfile);path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():path.unlink()
    conn=sqlite3.connect(path)
    conn.executescript('''
    CREATE TABLE metadata(key TEXT PRIMARY KEY,value TEXT NOT NULL);
    CREATE TABLE steps(step INTEGER PRIMARY KEY, time_s REAL NOT NULL, action TEXT NOT NULL, reason TEXT NOT NULL, epistemic_status TEXT NOT NULL);
    CREATE TABLE path_evidence(step INTEGER NOT NULL,side TEXT NOT NULL,status TEXT NOT NULL,raw REAL NOT NULL,filtered REAL,range_mm REAL,image_quality REAL,PRIMARY KEY(step,side));
    CREATE TABLE neuron_states(step INTEGER NOT NULL,name TEXT NOT NULL,membrane REAL NOT NULL,exc REAL NOT NULL,inh REAL NOT NULL,adapt REAL NOT NULL,theta REAL NOT NULL,spikes_total INTEGER NOT NULL,PRIMARY KEY(step,name));
    CREATE TABLE counterfactuals(name TEXT PRIMARY KEY, action TEXT NOT NULL);
    ''')
    conn.execute('INSERT INTO metadata VALUES (?,?)',('schema',report['schema']))
    conn.execute('INSERT INTO metadata VALUES (?,?)',('source',report['label']))
    conn.execute('INSERT INTO metadata VALUES (?,?)',('v2_core_sha256',report['core_source_sha256']))
    for s in report['scenarios']:
        conn.execute('INSERT INTO steps VALUES(?,?,?,?,?)',(s['step'],s['time_s'],s['decision']['action'],s['decision']['reason'],s['thought_trace']['epistemic_status']))
        for side,val in s['scores'].items():
            conn.execute('INSERT INTO path_evidence VALUES (?,?,?,?,?,?,?)',(s['step'],side,val['status'],val['instant_score'],val['filtered_score'],val['range_mm'],val['image_quality']))
        for name,val in s['neuron_internal'].items():
            conn.execute('INSERT INTO neuron_states VALUES (?,?,?,?,?,?,?,?)',(s['step'],name,val['membrane'],val['exc'],val['inh'],val['adapt'],val['theta'],val['spikes_total']))
    conn.executemany('INSERT INTO counterfactuals VALUES (?,?)',report['counterfactuals'].items())
    conn.commit()
    status=conn.execute('PRAGMA integrity_check').fetchone()[0]
    conn.close()
    if status!='ok':raise RuntimeError(status)
    return status


def main():
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--out',default='results/thought_trace.json');ap.add_argument('--db',default='results/colony_trace.sqlite')
    args=ap.parse_args();report=run_demo()
    p=Path(args.out);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print('SQLite integrity:',write_db(report,args.db))
    for x in report['scenarios']:
        print('STEP',x['step'], x['decision']['action'],x['thought_trace']['observe'],x['thought_trace']['interpret'])
    print('Counterfactuals:',report['counterfactuals'])

if __name__=='__main__':main()
