"""Charlie Colony: auditable decision experiment built on the unchanged v2 neuron."""
