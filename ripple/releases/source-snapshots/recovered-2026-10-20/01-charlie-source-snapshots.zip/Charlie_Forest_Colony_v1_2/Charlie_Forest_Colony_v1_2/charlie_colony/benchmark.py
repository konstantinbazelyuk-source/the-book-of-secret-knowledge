"""Held-out synthetic ground-choice benchmark; no physical sensors or terrain."""
from __future__ import annotations
import json,random
from dataclasses import replace
from pathlib import Path
from charlie_colony.lab import CharlieColony, PathSense, Observation


def fixture(seed:int,n:int):
    rng=random.Random(seed)
    cases=[]
    for i in range(n):
        sides=[];safe=[]
        for side in ('left','right'):
            near=tuple(rng.random() for _ in range(3))
            far=tuple(rng.random() for _ in range(3))
            clearance=rng.choice([None,80,95,150,165,180,245,300])
            age=rng.choice([0.01,0.04,0.5]) if clearance is not None else None
            quality=rng.choice([0.35,.85,1.])
            obs=PathSense(near,far,clearance,age,quality)
            # Hidden synthetic reference labels; evaluated AFTER a move recommendation.
            # This evaluator never enters the policy's observe() call.
            def color_y(x):return int(.55*x[0]+1.30*x[1]-.65*x[2]>.68)
            safe_color=color_y(near)==1 and color_y(far)==1
            allowed=(clearance is not None and 120<=clearance<=220 and age<=.25 and quality>=.65 and safe_color)
            sides.append(obs);safe.append(allowed)
        cases.append((Observation(.05,*sides),tuple(safe)))
    return cases


def evaluation(trained:bool=True,seed=20261017,n=400):
    trials=fixture(seed,n)
    moves=unsafe=correct=unacted_safe=0
    decisions={'MOVE_LEFT_SIMULATED':0,'MOVE_RIGHT_SIMULATED':0,'REQUEST_NEW_SCAN':0}
    for sample,truth in trials:
        col=CharlieColony(trained=trained)
        action=col.observe(sample)['decision']['action']
        decisions[action]=decisions.get(action,0)+1
        if action.startswith('MOVE_'):
            moves+=1
            side=0 if action=='MOVE_LEFT_SIMULATED' else 1
            if truth[side]:correct+=1
            else:unsafe+=1
        elif any(truth): unacted_safe+=1
    return {'seed':seed,'trials':n,'trained':trained,'synthetic_reference_rule':'.55R + 1.30G - .65B > .68 per RGB patch; both must pass, plus clearance, freshness and quality',
            'moves_recommended':moves,'moves_matching_hidden_synthetic_reference':correct,
            'unsafe_recommendations_against_hidden_synthetic_reference':unsafe,
            'safe_available_but_abstained':unacted_safe,'decisions':decisions,
            'move_fraction':round(moves/n,5),'unsafe_fraction_all_scenarios':round(unsafe/n,5),
            'evidence':'synthetic_fixture_only; no physical terrain'}


def stimulation(duration_frames=100):
    c=CharlieColony()
    red=(.72,.18,.78);green=(.15,.82,.06)
    events=[];coupling=[]
    for i in range(duration_frames):
        step=c.observe(Observation(round(.05*(i+1),8),PathSense(red,red,85,.01),PathSense(green,green,165,.01)))
        events.append({'t':step['time_s'],**step['neuron_events']})
        coupling.append({'t':step['time_s'],'right_total':step['neuron_internal']['right_near']['spikes_total'],
                         'relay_exc':step['neuron_internal']['novelty_monitor']['exc'],
                         'pending_exc':step['pending_exc'][5]})
    return {'duration_s':duration_frames*.05,'sample_dt_s':.05,'events':events,'coupling':coupling,
            'total_per_neuron':{n:neuron.count for n,neuron in zip(c.node_names,c.network.cells)},
            'max_coupled_relay_exc':max(x['relay_exc'] for x in coupling),
            'max_delayed_pending_exc':max(x['pending_exc'] for x in coupling),
            'interpretation':'simulation demonstrates actual spiking and delayed synaptic coupling, not thinking'}


def main():
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--out',default='results/colony_benchmark.json');args=ap.parse_args()
    out={'schema':'charlie-colony-benchmark/1.0','trained':evaluation(True),
         'untrained':evaluation(False),'balanced_trained':evaluate_cases(stratified_fixture(),True),'balanced_untrained':evaluate_cases(stratified_fixture(),False),'semantic_reversal_control':evaluate_cases([(o,tuple(1-t for t in truth)) for o,truth in stratified_fixture()],True),'sustained_stimulation':stimulation()}
    p=Path(args.out);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='sustained_stimulation'},indent=2))
    print('dynamic',out['sustained_stimulation']['total_per_neuron'],out['sustained_stimulation']['max_coupled_relay_exc'])



def stratified_fixture(seed=20261018, repeats=100):
    """Predeclared balanced synthetic cases; all range/quality checks valid.

    25% safe left only; 25% safe right only; 25% both visually safe;
    25% neither safe. Hidden labels evaluated after policy choice.
    """
    rng=random.Random(seed)
    def color_label(x): return int(.55*x[0]+1.30*x[1]-.65*x[2]>.68)
    def draw_color(label):
        for _ in range(100000):
            x=tuple(rng.random() for _ in range(3))
            if color_label(x)==label:return x
        raise RuntimeError('failed to generate color')
    out=[]
    cases=((1,0),(0,1),(1,1),(0,0))
    for truth in cases:
        for i in range(repeats):
            routes=[]
            for label in truth:
                near=draw_color(label);far=draw_color(label)
                routes.append(PathSense(near,far,160+float(rng.choice((-12,0,10))),.01,1.0))
            out.append((Observation(.05,*routes),truth))
    rng.shuffle(out)
    return out


def evaluate_cases(cases,trained=True):
    moves=unsafe=correct=abstained_w_safe=0; by_truth={}
    for observation,truth in cases:
        name=''.join(map(str,truth))
        row=by_truth.setdefault(name,{'n':0,'moves':0,'correct_moves':0,'wrong_moves':0,'abstained':0})
        row['n']+=1
        action=CharlieColony(trained=trained).observe(observation)['decision']['action']
        if action in ('MOVE_LEFT_SIMULATED','MOVE_RIGHT_SIMULATED'):
            row['moves']+=1;moves+=1
            side=0 if action=='MOVE_LEFT_SIMULATED' else 1
            if truth[side]:correct+=1;row['correct_moves']+=1
            else:unsafe+=1;row['wrong_moves']+=1
        else:
            row['abstained']+=1
            if any(truth):abstained_w_safe+=1
    return {'trained':trained,'total':len(cases),'correct_moves':correct,
            'wrong_moves_vs_fixture_truth':unsafe,'abstained_when_safe_exists':abstained_w_safe,
            'move_rate':round(moves/len(cases),5),
            'correct_move_coverage_when_route_safe':round(correct/sum(any(x[1]) for x in cases),5),
            'by_reference_labels':by_truth,
            'limitations':'all data synthetic; holding out these seeds does not establish real world safety'}

if __name__=='__main__':main()
