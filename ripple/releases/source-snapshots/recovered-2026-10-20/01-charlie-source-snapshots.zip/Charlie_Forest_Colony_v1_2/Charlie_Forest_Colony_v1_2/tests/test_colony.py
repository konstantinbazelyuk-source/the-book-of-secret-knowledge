from __future__ import annotations
import hashlib,json,math,sqlite3,tempfile,unittest
from pathlib import Path
from charlie_colony.lab import CharlieColony, PathSense, Observation,run_demo,counterfactuals,write_db,scenario_sequence
from charlie_colony.benchmark import fixture,stratified_fixture,stimulation,evaluate_cases
from charlie_core.neuron import CharlieNeuron
from charlie_core.network import CharlieCoreNetwork

ROOT=Path(__file__).resolve().parents[1]
RED=(.72,.18,.78);GREEN=(.15,.82,.06)

def make(left_range=85,right_range=160,left_rgb=RED,right_rgb=GREEN,t=.05,right_age=.01,right_quality=1):
    return Observation(t,PathSense(left_rgb,left_rgb,left_range,.01 if left_range is not None else None),
                       PathSense(right_rgb,right_rgb,right_range,right_age if right_range is not None else None,right_quality))

class TestCharlieColony(unittest.TestCase):
    def test_core_unchanged(self):
        self.assertEqual(hashlib.sha256((ROOT/'charlie_core/neuron.py').read_bytes()).hexdigest(), 'bf96fc4dae90eeee65e3f895207c6c5714f736b1b9dbf09569e1c24a8b440f77')
        self.assertEqual(hashlib.sha256((ROOT/'charlie_core/network.py').read_bytes()).hexdigest(), 'e26bb40bac6857565bc4c36b81869d127106c6ed3b409add5ea68ce6bcf8802e')
    def test_six_independent_neurons(self):
        c=CharlieColony();self.assertEqual(len(c.network.cells),6)
        self.assertEqual(len({id(cell) for cell in c.network.cells}),6)
        self.assertEqual(len({id(cell.weights) for cell in c.network.cells}),6)
    def test_trained_weights_exactly_preserved(self):
        w=json.loads((ROOT/'legacy/v2_trained_core_state_LOCKED.json').read_text())['weights']
        self.assertEqual(CharlieColony().network.cells[0].weights,w)
        self.assertEqual(CharlieColony(trained=False).network.cells[0].weights,[2.,1.2,1.4])
    def test_fresh_safe_visual_select_right(self):
        x=CharlieColony().observe(make())
        self.assertEqual(x['decision']['action'],'MOVE_RIGHT_SIMULATED')
        self.assertGreater(x['scores']['right']['filtered_score'],.70)
    def test_change_evidence_change_action(self):
        x=CharlieColony().observe(make(left_range=165,right_range=85,left_rgb=GREEN,right_rgb=RED))
        self.assertEqual(x['decision']['action'],'MOVE_LEFT_SIMULATED')
    def test_unsafe_range_overrides_good_visual(self):
        x=CharlieColony().observe(make(left_range=80,right_range=85,left_rgb=GREEN,right_rgb=GREEN))
        self.assertEqual(x['decision']['action'],'REQUEST_NEW_SCAN')
    def test_missing_range_overrides_memory(self):
        c=CharlieColony()
        self.assertEqual(c.observe(make())['decision']['action'],'MOVE_RIGHT_SIMULATED')
        x=c.observe(make(right_range=None,right_age=None,t=.1))
        self.assertEqual(x['decision']['action'],'REQUEST_NEW_SCAN')
        self.assertEqual(x['scores']['right']['status'],'UNKNOWN_RANGE')
    def test_stale_range_blocks(self):
        x=CharlieColony().observe(make(right_age=.55))
        self.assertEqual(x['scores']['right']['status'],'UNKNOWN_RANGE')
    def test_quality_blocks(self):
        x=CharlieColony().observe(make(right_quality=.3))
        self.assertEqual(x['scores']['right']['status'],'LOW_IMAGE_QUALITY')
    def test_low_task_specific_score_blocks(self):
        x=CharlieColony().observe(make(left_range=160,right_range=160,left_rgb=RED,right_rgb=RED))
        self.assertEqual(x['decision']['action'],'REQUEST_NEW_SCAN')
    def test_bounded_recheck_stops(self):
        c=CharlieColony(max_rechecks=2)
        outs=[]
        for i in range(3):
            o=make(left_range=None,right_range=None,t=.05*(i+1))
            outs.append(c.observe(o)['decision']['action'])
        self.assertEqual(outs,['REQUEST_NEW_SCAN','REQUEST_NEW_SCAN','STOP_UNRESOLVED'])
    def test_invalid_rgb_is_atomic(self):
        c=CharlieColony()
        with self.assertRaises(ValueError):c.observe(make(right_rgb=(math.nan,0,0)))
        self.assertEqual(c.network.cells[0].time,0)
        self.assertIsNone(c.last_time)
    def test_non_synthetic_rejected(self):
        obs=Observation(.05,PathSense(RED,RED,100,.01,source='claimed_hardware'),PathSense(GREEN,GREEN,160,.01))
        with self.assertRaises(ValueError):CharlieColony().observe(obs)
    def test_timestamp_monotonic(self):
        c=CharlieColony();c.observe(make())
        with self.assertRaises(ValueError):c.observe(make(t=.05))
    def test_bounded_memory(self):
        c=CharlieColony()
        for i in range(10):c.observe(make(t=(i+1)*.05))
        self.assertEqual(len(c.history['right']),3)
    def test_counterfactuals_react_to_evidence(self):
        c=counterfactuals()
        self.assertEqual(c['right_safe'],'MOVE_RIGHT_SIMULATED')
        self.assertEqual(c['left_safe_if_evidence_swapped'],'MOVE_LEFT_SIMULATED')
        self.assertEqual(c['both_clearance_unsafe'],'REQUEST_NEW_SCAN')
        self.assertEqual(c['all_ranges_missing'],'REQUEST_NEW_SCAN')
        self.assertEqual(c['right_low_quality'],'REQUEST_NEW_SCAN')
    def test_trace_repeatable(self):
        self.assertEqual(run_demo(),run_demo())
    def test_sqlite_integrity_and_counts(self):
        r=run_demo()
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'run.sqlite';self.assertEqual(write_db(r,p),'ok')
            con=sqlite3.connect(p)
            self.assertEqual(con.execute('SELECT COUNT(*) FROM steps').fetchone()[0],4)
            self.assertEqual(con.execute('SELECT COUNT(*) FROM path_evidence').fetchone()[0],8)
            self.assertEqual(con.execute('SELECT COUNT(*) FROM neuron_states').fetchone()[0],24)
            self.assertEqual(con.execute('PRAGMA integrity_check').fetchone()[0],'ok');con.close()
    def test_spike_dynamics_are_actually_executed(self):
        s=stimulation(100)
        self.assertGreater(s['total_per_neuron']['right_near'],0)
        self.assertGreater(s['max_delayed_pending_exc'],0)
        self.assertGreater(s['max_coupled_relay_exc'],0)
        self.assertEqual(s['total_per_neuron']['left_near'],0)
    def test_one_tick_synaptic_causality(self):
        c=CharlieColony()
        for i in range(15):
            x=c.observe(make(t=(i+1)*.05))
            if x['pending_exc'][5]:
                prev=x['neuron_internal']['novelty_monitor']['exc']
                nx=c.observe(make(t=(i+2)*.05))
                self.assertGreater(nx['neuron_internal']['novelty_monitor']['exc'],prev)
                return
        self.fail('no synaptic pulse delivered')
    def test_far_observer_can_veto_near_support(self):
        o=make(left_range=85,right_range=160,right_rgb=GREEN)
        good=CharlieColony().observe(o)
        conflicting=Observation(.05,o.left,PathSense(GREEN,RED,160,.01))
        bad=CharlieColony().observe(conflicting)
        self.assertEqual(good['decision']['action'],'MOVE_RIGHT_SIMULATED')
        self.assertEqual(bad['decision']['action'],'REQUEST_NEW_SCAN')
    def test_explicit_distribution_shift_failure(self):
        cases=stratified_fixture(repeats=10)
        reversed_truth=[(obs,tuple(1-y for y in truth)) for obs,truth in cases]
        raw=evaluate_cases(cases,True)
        rev=evaluate_cases(reversed_truth,True)
        self.assertEqual(raw['correct_moves'],rev['wrong_moves_vs_fixture_truth'])
        self.assertEqual(rev['correct_moves'],0)
    def test_balanced_fixture_real_oracle_not_available_to_policy(self):
        cases=stratified_fixture()
        self.assertEqual(len(cases),400)
        # Only evaluator receives reference label tuple; policy receives Observation only.
        self.assertEqual(sum(any(truth) for _,truth in cases),300)
    def test_benchmark_comparison_repeatable(self):
        cases=stratified_fixture(repeats=10)
        self.assertEqual(evaluate_cases(cases,True),evaluate_cases(cases,True))
        self.assertLess(evaluate_cases(cases,True)['wrong_moves_vs_fixture_truth'],
                        evaluate_cases(cases,False)['wrong_moves_vs_fixture_truth'])

if __name__=='__main__':unittest.main()
