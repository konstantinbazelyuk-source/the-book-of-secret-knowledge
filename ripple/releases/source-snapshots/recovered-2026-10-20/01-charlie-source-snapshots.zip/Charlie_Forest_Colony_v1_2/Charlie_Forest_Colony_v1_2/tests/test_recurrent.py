import unittest,copy,hashlib,json,math,sqlite3, tempfile
from pathlib import Path
from dataclasses import replace
from charlie_recurrent.engine import DynamicCharlie,Settings
from charlie_recurrent.experiment import sequence,reference,evaluate_stream,benchmark,persist,RED,GREEN
from charlie_colony.lab import PathSense, Observation
ROOT=Path(__file__).resolve().parents[1]
EXPECTED={'charlie_core/neuron.py':'bf96fc4dae90eeee65e3f895207c6c5714f736b1b9dbf09569e1c24a8b440f77',
'charlie_core/network.py':'e26bb40bac6857565bc4c36b81869d127106c6ed3b409add5ea68ce6bcf8802e',
'legacy/v2_trained_core_state_LOCKED.json':'f23fb97df731cfa0fcd6e9292946962b7960684e2e57a9812d79d65e5d5a40cc'}
class RecurrentTests(unittest.TestCase):
    def test_v2_core_byte_continuity(self):
        for p, expected in EXPECTED.items():
            self.assertEqual(hashlib.sha256((ROOT/p).read_bytes()).hexdigest(), expected)
    def test_six_independent_cells(self):
        c=DynamicCharlie();self.assertEqual(len(c.net.cells),6)
        self.assertEqual(len({id(x) for x in c.net.cells}),6)
        self.assertEqual(len({id(x.weights) for x in c.net.cells}),6)
    def test_fluctuates_and_reverses_evidence(self):
        c=DynamicCharlie();tr=[c.step(x) for x in sequence('switch')]
        a=[r['paths']['right']['memory'] for r in tr]
        self.assertGreater(max(a)-min(a),1.5)
        self.assertGreater(len({round(x,5) for x in a}),60)
        self.assertTrue(any(r['decision']=='MOVE_RIGHT_SIMULATED' for r in tr[:38]))
        self.assertTrue(any(r['decision']=='MOVE_LEFT_SIMULATED' for r in tr[38:]))
    def test_hard_clearance_veto(self):
        c=DynamicCharlie();trace=[c.step(x) for x in sequence('blocked')]
        self.assertFalse(any(x['decision'].startswith('MOVE') for x in trace))
    def test_missing_range_stale_veto(self):
        c=DynamicCharlie();trace=[c.step(x) for x in sequence('switch')]
        for x in trace[37:40]:self.assertFalse(x['decision'].startswith('MOVE'))
    def test_no_static_decision_shortcut(self):
        c=DynamicCharlie();a=c.step(sequence('switch')[0]);self.assertEqual(a['decision'],'REQUEST_NEW_SCAN')
        self.assertEqual(a['paths']['right']['relay_events'],0)
    def test_spike_gain_causes_decision_counterfactual(self):
        obs=sequence('switch');r=evaluate_stream(obs,'recurrent');a=evaluate_stream(obs,'spikes_ignored')
        self.assertGreater(sum(x['action']!=y['action'] for x,y in zip(r['rows'],a['rows'])),0)
    def test_coupling_causes_decision_counterfactual(self):
        obs=sequence('switch');r=evaluate_stream(obs,'recurrent');a=evaluate_stream(obs,'no_coupling')
        self.assertGreater(sum(x['action']!=y['action'] for x,y in zip(r['rows'],a['rows'])),0)
    def test_network_pulse_delay(self):
        c=DynamicCharlie();prev_pending=[0]*6
        trace=[c.step(x) for x in sequence('switch',steps=36)]
        self.assertGreater(sum(sum(x['pending_exc']) for x in trace),0)
        self.assertTrue(any(x['paths']['right']['delivered_link_pulses']>0 for x in trace))
    def test_reading_rejected(self):
        c=DynamicCharlie()
        with self.assertRaises(ValueError):c.step(Observation(.05,PathSense((1.3,0,0),(0,0,0)),PathSense((0,0,0),(0,0,0))))
        self.assertEqual(c.steps,0)
    def test_monotone_time(self):
        c=DynamicCharlie();o=sequence('switch')[0];c.step(o)
        with self.assertRaises(ValueError):c.step(o)
    def test_config_validity(self):
        with self.assertRaises(ValueError):Settings(recurrent_gain=float('nan'))
        with self.assertRaises(ValueError):Settings(coupling_gain=-.01)
    def test_reference_is_not_in_controller(self):
        import inspect
        from charlie_recurrent import engine
        self.assertNotIn('def reference(',inspect.getsource(engine))
        self.assertFalse(reference(sequence('none')[0])['right'])
    def test_saved_report_full_evidence(self):
        report=benchmark()
        self.assertEqual(report['benchmark']['recurrent']['steps'],1520)
        self.assertGreater(report['fluctuation_test']['decision_changed_by_coupling_ablation_in_76_step_trace'],0)
        with tempfile.TemporaryDirectory() as d:
            self.assertEqual(persist(report,d),'ok')
            db=sqlite3.connect(Path(d)/'evidence.sqlite')
            self.assertEqual(db.execute('select count(*) from trace').fetchone()[0],228)
            self.assertEqual(db.execute('pragma integrity_check').fetchone()[0],'ok')
            db.close()
    def test_all_synthetic_fixture_actions_checked(self):
        # This is a test of THIS fixture, not a safety claim under physical operation.
        r=benchmark()
        self.assertEqual(r['benchmark']['recurrent']['counts']['incorrect'],0)
        self.assertLess(r['benchmark']['recurrent']['counts']['correct'],r['benchmark']['static']['counts']['correct'])
    def test_reset_reproducible(self):
        a=evaluate_stream(sequence('alternating',seed=17),'recurrent')['rows']
        b=evaluate_stream(sequence('alternating',seed=17),'recurrent')['rows']
        self.assertEqual(a,b)
if __name__=='__main__':unittest.main()
