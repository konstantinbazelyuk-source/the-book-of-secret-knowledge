import os,unittest
from src.model_compare import make_cases,judge,parsed_label,grade,call_provider

class ComparatorTests(unittest.TestCase):
    def test_cases_seed_locked(self):
        self.assertEqual(make_cases(),make_cases())
        self.assertEqual(len(make_cases()),16)
    def test_all_three_labels_represented(self):
        labels={judge(c) for c in make_cases()}
        self.assertEqual(labels,{'LEFT','RIGHT','SCAN'})
    def test_reject_unstructured_replies(self):
        self.assertEqual(parsed_label('LEFT'), 'LEFT')
        self.assertEqual(parsed_label('left.'), 'LEFT')
        self.assertEqual(parsed_label('I think LEFT'), 'INVALID')
        self.assertEqual(parsed_label('LEFT RIGHT'), 'INVALID')
    def test_grader_rejects_duplicate(self):
        case=make_cases()[0]
        with self.assertRaises(ValueError):grade([{'id':case['id'],'response':'SCAN'}]*2)
    def test_external_missing_key_rejected(self):
        old=os.environ.pop('XAI_API_KEY',None)
        try:
            with self.assertRaisesRegex(RuntimeError,'no Grok call'):
                call_provider('xai','example',make_cases()[0])
        finally:
            if old is not None:os.environ['XAI_API_KEY']=old
    def test_bad_provider_rejected(self):
        with self.assertRaises(ValueError):call_provider('invented','fake',make_cases()[0])

if __name__=='__main__':unittest.main()
