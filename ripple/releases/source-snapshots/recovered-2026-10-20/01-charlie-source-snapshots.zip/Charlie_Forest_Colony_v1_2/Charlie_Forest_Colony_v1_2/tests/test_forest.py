import hashlib, json, math, unittest
from pathlib import Path
from src.forest import Forest,Colony,cellhash,paired_benchmark
from charlie_recurrent.engine import DynamicCharlie

class ForestTests(unittest.TestCase):
    def test_grid_determinism(self):
        self.assertEqual(Forest(13).digest(),Forest(13).digest())
        self.assertNotEqual(Forest(13).digest(),Forest(17).digest())
    def test_unreachable_and_bounds(self):
        f=Forest(17);self.assertFalse(f.passable((-1,0)))
        self.assertFalse(f.inbounds((16,16)))
    def test_mass_conserved_over_growth(self):
        f=Forest(19)
        for p in f.patches:
            if f.plant(p):break
        init=f.total_initial_nutrient
        for t in range(1,200):f.grow(t)
        self.assertAlmostEqual(init,sum(q.nutrient+q.biomass for q in f.patches.values()),places=8)
        self.assertTrue(all(q.nutrient>=0 for q in f.patches.values()))
    def test_growth_requires_conditions(self):
        f=Forest(13)
        blocked=next(p for p in f.patches if f.patches[p].obstacle)
        self.assertFalse(f.plant(blocked))
    def test_worker_cap_and_mass(self):
        c=Colony(13,steps=100);r=c.run()
        self.assertLessEqual(r['workers'],5)
        self.assertAlmostEqual(r['resource_conservation_error'],0,places=8)
        self.assertEqual(r['stats']['unsafe_moves'],0)
    def test_model_ablations_differ(self):
        r=paired_benchmark(seeds=(11,13),steps=80)
        self.assertNotEqual(r['policies']['recurrent']['moves'],r['policies']['spikes_off']['moves'])
        self.assertNotEqual(r['policies']['recurrent']['moves'],r['policies']['links_off']['moves'])
    def test_static_baseline(self):
        r=Colony(seed=11,policy='static',steps=80).run()
        self.assertGreater(r['visited_unique'],1)
        self.assertEqual(r['stats']['spikes'],0)
    def test_neuron_evidence_in_state(self):
        c=Colony(11,steps=40);c.run()
        self.assertGreater(c.stats['spikes'],0)
        self.assertTrue(any(x['memory'] is not None for x in c.trace))
    def test_unique_map_never_exceeds_cells(self):
        c=Colony(19,steps=60);r=c.run()
        self.assertLessEqual(r['known_unique'],c.world.size**2)
        self.assertLessEqual(r['visited_unique'],r['eligible_cells'])
    def test_no_share(self):
        c=Colony(11,steps=100,sharing=False);r=c.run()
        self.assertEqual(r['stats']['received_shared_cells'],0)
    def test_hash_neuron_preserved(self):
        src=Path(__file__).resolve().parents[1]
        hashes=json.loads((src/'docs'/'LOCKED_HASHES.json').read_text())
        for path, expected in hashes.items():
            self.assertEqual(hashlib.sha256((src/path).read_bytes()).hexdigest(),expected)
    def test_single_agent_time_advance(self):
        c=Colony(11,steps=30)
        c.run()
        self.assertEqual(c.workers[0].actions,30)

if __name__=='__main__':unittest.main()
