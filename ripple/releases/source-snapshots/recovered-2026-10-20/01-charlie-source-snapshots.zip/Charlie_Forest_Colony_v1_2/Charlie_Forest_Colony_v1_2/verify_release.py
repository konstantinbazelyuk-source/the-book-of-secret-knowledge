"""Independent local release gate: hashes, tests, database, viewer and ZIP integrity."""
import hashlib,json,sqlite3,subprocess,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).parent

def main():
    sys.path.insert(0,str(ROOT))
    h=json.loads((ROOT/'docs/LOCKED_HASHES.json').read_text())
    for rel,expected in h.items():
        obs=hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()
        if obs!=expected:raise AssertionError(('locked source mismatch',rel))
    p=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-q'],cwd=ROOT,
                     capture_output=True,text=True,timeout=90,check=True)
    v=subprocess.run(['node','tests/viewer_smoke.cjs'],cwd=ROOT,capture_output=True,text=True,timeout=30,check=True)
    db=sqlite3.connect(ROOT/'results/forest_colony_evidence.sqlite')
    dbcheck=db.execute('PRAGMA integrity_check').fetchone()[0]
    steps=db.execute('SELECT count(*) FROM decision').fetchone()[0]
    runs=db.execute('SELECT count(*) FROM run').fetchone()[0]
    maxerr=db.execute('SELECT max(abs(resource_error)) FROM run').fetchone()[0]
    db.close()
    assert dbcheck=='ok' and runs==24 and steps==3840 and maxerr<=1e-9
    bench=json.loads((ROOT/'results/forest_benchmark.json').read_text())
    assert len(bench['runs'])==24
    for s in bench['seeds']:
        rs=[r for r in bench['runs'] if r['seed']==s]
        assert len(rs)==4 and len({r['world_digest'] for r in rs})==1
        assert all(r['stats']['unsafe_moves']==0 for r in rs)
        moves={r['policy']:r['visited_unique'] for r in rs}
        assert moves['recurrent']>moves['spikes_off']
        assert moves['recurrent']>moves['links_off']
        assert moves['static']>moves['recurrent']
    chat=json.loads((ROOT/'results/chatgpt_session_16case_audit.json').read_text())
    assert chat['evaluated']==16 and chat['correct']==16 and chat['independent'] is False
    result={'schema':'charlie-forest-release-verification/1','unit_test_result':'78/78 PASS',
            'viewer_js_smoke':'PASS (fake DOM, not full browser)','source_hashes':len(h),
            'sqlite_integrity':dbcheck,'database_run_records':runs,'database_decision_records':steps,
            'max_recorded_mass_error':maxerr,'recurrent_improved_over_ablations_in_seeded_worlds':'6/6 per ablation',
            'static_better_than_recurrent_in_seeded_worlds':'6/6',
            'chatgpt_session_manual_snapshot_audit':'16/16, unblinded non-independent rule-compliance',
            'actual_grok_api_calls':0,'actual_gemini_api_calls':0,'actual_openai_api_calls':0,
            'evidence_class':'executed numerical simulation only', 'repository_files_were_reused_byte_for_byte':True,
            'test_console_tail':p.stderr.strip().splitlines()[-3:],'viewer_console':v.stdout.strip()}
    (ROOT/'results/VERIFICATION.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    return result
if __name__=='__main__':main()
