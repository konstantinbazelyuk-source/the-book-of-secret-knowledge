"""Self-contained release check: unit tests, db, locked sources, synthetic score gate."""
import unittest,sys,hashlib,json,sqlite3
from pathlib import Path
from charlie_core.study import run
root=Path(__file__).resolve().parent
suite=unittest.defaultTestLoader.discover(str(root/'tests'))
r=unittest.TextTestRunner(verbosity=1).run(suite)
if not r.wasSuccessful():sys.exit(1)
known=json.loads((root/'docs/original_hashes.json').read_text())
for rel,h in known.items():
    if hashlib.sha256((root/rel).read_bytes()).hexdigest()!=h:sys.exit('Locked source mismatch: '+rel)
con=sqlite3.connect(root/'results/charlie_mathematics_v2.sqlite');integrity=con.execute('pragma integrity_check').fetchone()[0]
f=con.execute('select count(*) from formulas').fetchone()[0];links=con.execute('select count(*) from connections').fetchone()[0];con.close()
if integrity!='ok' or f!=71 or links!=62:sys.exit('invalid formula database')
study=run();a=study['stationary_learning']
if not (a['trained']['accuracy']>.88 and a['trained']['brier']<a['untrained']['brier']-.08):sys.exit('synthetic learning gate failure')
metrics={'verification_status':'PASSED_SYNTHETIC_SOFTWARE_ONLY','test_count':r.testsRun,'formula_count':f,'dependencies':links,'sqlite_integrity':integrity,
 'originals_verified':known,'baseline_original_spikes':study['original_locked_comparator']['spikes'],
 'new_core_spikes':study['new_conductance_core']['spikes'],
 'heldout_accuracy_untrained':a['untrained']['accuracy'],'heldout_accuracy_trained':a['trained']['accuracy'],
 'holdout_brier_untrained':a['untrained']['brier'],'holdout_brier_trained':a['trained']['brier'],
 'physical_tests':0,'claimed_general_intelligence':False}
(root/'results/RELEASE_VERIFICATION.json').write_text(json.dumps(metrics,indent=2)+'\n')
print(json.dumps(metrics,indent=2))
