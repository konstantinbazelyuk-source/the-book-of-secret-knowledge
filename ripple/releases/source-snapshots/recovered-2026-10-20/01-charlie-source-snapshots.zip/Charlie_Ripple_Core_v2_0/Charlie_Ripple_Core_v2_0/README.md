# Charlie Ripple — CORE v2.0 (REVISED INTERNAL MATHEMATICS)

**Status:** executed Python software and synthetic-data study. **Not:** biologically verified neuron, fully trained AI, sensor-calibrated robot, or physical intelligence.

## What changed inside the neuron

The original Ripple v0.1 RGB weighted-drive LIF `tau_v du/dt=-u+(2R+1.2G-1.4B)` is **not** instantiated by the new core. This project defines an independent `CharlieNeuron` with its own conductance-based membrane, excitatory/inhibitory synaptic traces, per-spike adaptation, threshold homeostasis, bounded trainable synaptic weights, and direct recurrent event delivery. The source-locked v0.1 Python and JS implementations in `legacy/` are reference-only, byte-identical to the recovered archives. **Core v2.0 changes the mathematical kernel rather than attaching new modules onto the old kernel.**

## Precise new dynamics

Assume normalized, non-negative RGB values `R,G,B`, internal mathematical time in seconds, and a *dimensionless* conductance model:

1. `tau_e * de/dt = w_R*R + w_G*G - e`, `tau_i * di/dt = w_B*B - i`. Default `tau_e=.070 s`, `tau_i=.120 s`; `w=[2,1.2,1.4]` are initial values, **not locked**.
2. `C*du/dt = g_L*(E_L-u) + e*(E_e-u) + i*(E_i-u) - a`. Default `C=.5`, `g_L=1`, `E_L=0`, `E_e=1.4`, `E_i=0` in **model units**.
3. `tau_a*da/dt=-a`; on a computed spike, `a <- a + .095`, membrane resets to zero for `0.10 s`. Default `tau_a=1.8 s`.
4. Threshold is bounded: `theta <- clip(theta + eta*dt*(r - r_target),.15,1.1)`, with `eta=.018` and `r_target=1 event/s`. Event rate decays exponentially with `tau_r=5 s` and increments per spike.
5. With e, i, a frozen over a numerical microstep, membrane relaxation has a stable closed form: `u_next=u_inf+(u-u_inf)*exp(-h*(g_L+e+i)/C)`, where `u_inf=(g_L E_L+e E_e+i E_i-a)/(g_L+e+i)`. **This is exact for the frozen local coefficients, not exact over an entire coupled step.** Spikes are detected at a finite internal timestep (default <=2.5ms) and crossing times interpolated. Results vary slightly with timestep; regression tests check refinement.
6. The **internal** synaptic weights can change through supervised stationary-conductance learning. `p=sigmoid(kappa*(u_inf-theta_initial))`, `L=-y ln p-(1-y)ln(1-p)`. `dL/dw_R=(p-y)*kappa*(E_e-u_inf)*R/(g_L+e+i)` and similarly for G; `dL/dw_B=(p-y)*kappa*(E_i-u_inf)*B/(g_L+e+i)`. This is the **exact analytic gradient of the steady-state logistic readout only**, not the gradient of dynamic spiking. Weight updates use clipped SGD plus small optional regularization around ancestral weights. Clipping to `[.12,4]` enforces finite bounds.
7. The network passes bounded signed spike counts from neuron `i` to neuron `j` one software tick later. They change the target neuron **internal conductance state**. This is an explicit delayed, finite event-graph mechanism, not autonomous organism reproduction.

## Measured software result (NOT sensor measurements)

Synthetic supervised labels use a disclosed rule: `y=1 if .55 R + 1.30 G - .65 B > .68`, otherwise zero. This deliberately differs from the initial color weighting. On 1300 training examples and 600 independent held-out examples, with 24 training epochs:

| Model | Held-out classification accuracy | Brier | CE |
|---|---:|---:|---:|
| NEW untrained conductance core | 59.50% | .269608 | .774382 |
| NEW trained conductance core | 91.00% | .089721 | .318722 |

The previously locked Ripple core has no calibrated logistic prediction head and is **not** included in this classification comparison. It is evaluated separately on the same dynamic stimulus: the original produced 39 model spikes and v2 produced 45. A different event count is not a better-signal-quality claim.

A second blue-heavy synthetic input split produces 48.67% untrained vs 90.17% trained accuracy. These results only establish trainability on those created label rules. An explicit reversed-label negative control verifies that learned skills do NOT generalize to contradictory meanings.

## Reproduce

Python 3.11+; core/study/tests require only the standard library; plot generation needs NumPy and Matplotlib (installed in this environment):

```
python -m unittest discover -s tests -v
python -m charlie_core.study --out results/study.json
python -m charlie_core.build
python -m charlie_core --rgb 0.6 0.4 0.05 --seconds 5 --out results/cli_demo.json
```

All comparisons use deterministic seeds. `results/charlie_mathematics_v2.sqlite` is a SQLite copy of the prior 56-formula Charlie math catalog plus 15 NEW equations and 22 new cross-links. It has **71 documented formulas and 62 relationships**. It is a scientific knowledge/provenance database, not a brain or a knowledge graph that infers facts independently.

## Compatibility and rollback

No legacy source is rewritten or re-licensed. Core v2 keeps the input contract of normalized 3-channel RGB but expects strictly in-range finite inputs, has a different output dictionary (membrane/adapt/exc/inh/weights), and uses a separate set of mathematical parameters. It is **not binary/API drop-in compatible** with the old v0.1 Ripple. All changes are isolated inside `charlie_core/`. Do not connect to physical motors or external tasks until independent sensing, electrical, actuator, and control validation exists. Keep v0.1 for fallback/controls.

## Scientific basis and citations

- Gerstner, Kistler, Naud, Paninski, [*Neuronal Dynamics*](https://neuronaldynamics.epfl.ch/online/) — leaky and conductance integrate-and-fire, adaptation and synaptic dynamics.
- Brette & Gerstner (2005), [Adaptive exponential integrate-and-fire neuron](https://doi.org/10.1152/jn.00686.2005) — precedent for using internal adaptation and nonlinear spiking models; **this project is NOT a full AdEx implementation**.
- Prior Charlie Ripple v1.0 `docs/MATHEMATICAL_STUDY.md`, 56 source-linked formulas; v1.3 evolutionary motor research retained as separate control process.

License: new v2 software CC0-1.0; archived originals retain their own notices. No third-party papers/code are copied into the implementation.
