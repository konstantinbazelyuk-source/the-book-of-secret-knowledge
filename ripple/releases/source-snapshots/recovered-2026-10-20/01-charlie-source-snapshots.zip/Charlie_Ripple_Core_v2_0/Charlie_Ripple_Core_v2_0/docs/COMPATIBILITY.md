# Compatibility/continuity policy

- Original v0.1 Python source SHA-256: `7f2f611cd8f1717c3d3dcae745dbd41efc37e24315d93878231db52eaf614f77`.
- Original v0.1 JavaScript source SHA-256: `dba6639b7902f0c702d15fff588524629f3754cfd72d7b704f22a76b78960ee3`.
- These are packaged only in `legacy/` and tests fail on any byte change.
- v2 `charlie_core/neuron.py` is independently implemented and does not import `legacy/`.
- Old formula catalog cloned, not overwritten; 15 newly sourced equations added, with provenance and lineage links.
- v2 is an *independent research core*, not a direct binary replacement for SpiderScan firmware or physical servos.
- Side-by-side comparison is possible with the original baseline; no claims that v2 must outperform v0.1 on all signal tasks.
- No imported robot controller changes, no external account actions, no flight capabilities, no live autonomous deployment.
