"""Re-run the Charlie v2 colony release's safety, continuity and evidence tests."""
import hashlib,json,math,os,sqlite3,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
EXPECTED={
 'charlie_core/neuron.py':'bf96fc4dae90eeee65e3f895207c6c5714f736b1b9dbf09569e1c24a8b440f77',
 'charlie_core/network.py':'e26bb40bac6857565bc4c36b81869d127106c6ed3b409add5ea68ce6bcf8802e',
 'legacy/v2_trained_core_state_LOCKED.json':'f23fb97df731cfa0fcd6e9292946962b7960684e2e57a9812d79d65e5d5a40cc',
 'legacy/original_ripple_LOCKED.js':'dba6639b7902f0c702d15fff588524629f3754cfd72d7b704f22a76b78960ee3',
 'legacy/original_ripple_LOCKED.py':'7f2f611cd8f1717c3d3dcae745dbd41efc37e24315d93878231db52eaf614f77'
}

def main():
    checks={}
    for rel,exp in EXPECTED.items():
        actual=hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()
        if actual!=exp:raise ValueError(f'continuity hash failed for {rel}: {actual}')
        checks[rel]={'sha256':actual,'match':True}
    py=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-q'],cwd=ROOT,text=True,capture_output=True)
    if py.returncode!=0:raise RuntimeError(py.stderr)
    import re
    count=int(re.search(r'Ran (\d+) tests',py.stderr).group(1))
    if count!=44:raise AssertionError(f'unexpected test count {count}')
    js=subprocess.run(['node','tests/viewer_smoke.cjs'],cwd=ROOT,text=True,capture_output=True)
    if js.returncode!=0:raise RuntimeError(js.stderr)
    conn=sqlite3.connect(ROOT/'results/colony_trace.sqlite')
    integrity=conn.execute('PRAGMA integrity_check').fetchone()[0]
    bytable={n:conn.execute(f'SELECT COUNT(*) FROM {n}').fetchone()[0] for n in ('steps','path_evidence','neuron_states','counterfactuals')}
    conn.close()
    assert integrity=='ok' and bytable=={'steps':4,'path_evidence':8,'neuron_states':24,'counterfactuals':5}
    benchmark=json.loads((ROOT/'results/colony_benchmark.json').read_text())
    a=benchmark['balanced_trained'];b=benchmark['balanced_untrained'];rev=benchmark['semantic_reversal_control']
    assert a['correct_moves']==193 and a['wrong_moves_vs_fixture_truth']==0
    assert b['wrong_moves_vs_fixture_truth']==82 and rev['wrong_moves_vs_fixture_truth']==193
    trace=json.loads((ROOT/'results/thought_trace.json').read_text())
    actions=[x['decision']['action'] for x in trace['scenarios']]
    assert actions==['REQUEST_NEW_SCAN','MOVE_RIGHT_SIMULATED','REQUEST_NEW_SCAN','MOVE_RIGHT_SIMULATED']
    assert trace['core_source_sha256']==EXPECTED['charlie_core/neuron.py']
    stim=benchmark['sustained_stimulation']
    assert stim['total_per_neuron']['right_near']>0 and stim['max_coupled_relay_exc']>0
    result={'schema':'charlie-colony-verified/1.0','status':'passed',
            'python_tests':count,'javascript_smoke':'passed','sqlite_integrity':integrity,
            'sqlite_rows':bytable,'approved_source_fingerprints':checks,
            'demo_actions':actions,'balanced_trained':a,'balanced_untrained':b,
            'semantic_reversal':{k:v for k,v in rev.items() if k!='by_reference_labels'},
            'sustained_stimulation':{k:v for k,v in stim.items() if k not in ('events','coupling')},
            'conditional_two_sided_95_percent_exact_upper_bound_error_given_0_wrong_of_193':1-(.025)**(1/193),
            'evidence_boundaries':['synthetic scenes only','stationary readout controls movement recommendation',
                                   'no neural reasoning or consciousness demonstrated','no physical sensors, motors or validated terrain clearance']}
    (ROOT/'results/VERIFICATION.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'python_tests':count,'js':result['javascript_smoke'],'db':integrity,
                      'decisions':actions,'balanced_correct':193,'balanced_wrong':0,
                      'negative_control_wrong':193},indent=2))

if __name__=='__main__':main()
