# Charlie Ripple Colony Thought Lab v1.0

**Status: executed Python numerical colony and inspectable rule-based decision replay.** This is *not* proof of cognition, awareness, autonomy, or a physically validated robot.

The exercise uses the genuinely **new Charlie Core v2.0 conductance-based neuron**, not the original Ripple LIF as the live core. Its v2.0 `neuron.py`, `network.py`, model checkpoint, and related source files remain unchanged from the preceding approved release. The original LIF remains in `legacy/` for inherited regression tests, not colony runtime.

## Run now

No third-party package is needed for simulation, tests, SQLite, or offline HTML replay generation (the included images require `matplotlib` only to *regenerate*).

```sh
python -m unittest discover -s tests -q
python -m charlie_colony.lab --out results/thought_trace.json --db results/colony_trace.sqlite
python -m charlie_colony.benchmark --out results/colony_benchmark.json
node tests/viewer_smoke.cjs # Node 18+, optional offline UI smoke test
```

Then open `web/Charlie_Colony_Thought_Replay.html` in a browser. This standalone file includes real executed and stored JSON; it needs no server, API key, network, or external resources. It does not recompute robot motion in the browser.

## Internal colony

Six independent `CharlieNeuron` instances participate in the numerical test: `left_near`, `left_far`, `right_near`, `right_far`, `hazard_monitor`, and `novelty_monitor`. Each has independent conductance, adaptive-current, rate and threshold states. Directed, signed event connections deliver pulses **one discrete tick later** via the unchanged `CharlieCoreNetwork` implementation.

The four visual nodes receive **synthetic RGB observations**. The two auxiliary nodes receive **explicitly virtual** hazard/missingness triples. Their spikes are recorded and transmitted through the recurrent graph; the decision controller does **not** claim the spikes represent human thoughts. The deployed decision logic in this test uses the four visual nodes' *stationary logistic readout* plus explicit range/quality/freshness gates. The auxiliary dynamic pulse states are not yet input to the movement-selection rule. That separation is deliberate, and important for an honest interpretation of what is working.

The saved v2.0 synthetic-trained weights are `[0.16957101313906703, 1.684289275825996, 2.4701182845102894]`. They are training artifacts for the synthetic rule `0.55R+1.30G-0.65B > 0.68`, **not** physically calibrated material labels.

## Operationally auditable basic reasoning

The `thought_trace` dictionary is a transparent five-stage **report of computations**:

1. OBSERVE — record normalized readings, latency, and image quality.
2. INTERPRET — calculate readout score for near and far panels, combine with a bounded three-entry temporal mean. This is **not Bayesian inference**.
3. TEST — reject missing or >0.25s old range; reject low-quality image (<0.65), or clearance outside 120–220 **synthetic millimeters**.
4. CHOOSE — when a qualified route's filtered score is at least 0.70, output a simulated left/right recommendation; otherwise request a new scan (up to 2 attempts) and STOP on repeated uncertainty.
5. EXPLAIN — render the exact conditions used. **The explanation is a generated decision audit, not Charlie reporting an internal conscious experience.**

The 4-step demonstration: unknown ranges -> REQUEST_NEW_SCAN; left unsafe (85 mm) / right fresh (164 mm) -> MOVE_RIGHT_SIMULATED; stale right range -> REQUEST_NEW_SCAN; refreshed right range -> MOVE_RIGHT_SIMULATED. No real robot or motors move.

The policy is conservative but imperfect. Old memory **cannot** substitute for a fresh range.

## Executed tests (not physical measurements)

- `44/44` Python regressions passed (24 new plus 20 inherited).
- Same input produces byte-for-byte identical JSON decisions; SQLite `PRAGMA integrity_check` is `ok`.
- Sustained 5.0-second synthetic observation: each right visual neuron emitted 15 modeled spikes; delayed recurrent pulses increased a receiving node's conductance. The short four-step decision demo itself generates zero pulses because it lasts only 0.2 seconds. **The action rule does not depend on those pulses.**
- 400-case heterogeneous test: trained = 9 correct selections, 0 wrong, 391 abstentions; untrained = 17 correct, 75 wrong, 308 abstentions. Dataset is dominated by missing/stale/unsafe readings, so *do not* cite it alone as evidence of superiority.
- **Predeclared balanced, independent synthetic benchmark**, 400 scenarios: 100 each [left only safe, right only safe, both safe, neither safe]. Trained = 193 correct movements, 0 wrong, 207 abstentions, **193/300 = 64.3%** correct route coverage when at least one synthetic-safe route exists. Untrained = 293 correct, 82 wrong, 25 abstentions. Error zero of 193 is not a guarantee; even a nominal two-sided 95% exact binomial bound would permit up to ~1.89% error *within this idealized statistical model*.
- **Negative control:** reverse the synthetic meaning of visual labels, without updating the model. All 193 previously accepted decisions disagree with the new labels. No automatic semantic change detection is implemented.
- Counterfactual tests: swapping visual/range evidence changes a right movement to left; missing/stale evidence, low image quality, and bad ground clearance correctly cause abstention; repeating missing readings leads to STOP.

## Failure and evidence boundaries

The scenario truth rule is supplied only to the offline evaluator, not to the decision system. The neuron was previously trained on the *same synthetic task family*, so the benchmark is an in-family held-out test, **not** proof of out-of-distribution generalization. RGB alone is not a verified physical traversability measurement. Numerical event times and clearances are simulated. The safety gate values are demonstration preferences, not manufacturer specifications. No physical sensors, motors, actuators, external accounts, or cloud services are contacted. Colony scale remains fixed at six; there is no automatic neuron reproduction in this version.

## Main artifacts

- `charlie_core/`: preserved v2.0 conductance, training and network sources.
- `charlie_colony/lab.py`: six-cell decision experiment and SQLite serializer.
- `charlie_colony/benchmark.py`: synthetic held-out, balanced, distribution-shift, and recurrent stimulation studies.
- `results/thought_trace.json`: calculated four-step interpret/test/choose/explain trace.
- `results/colony_trace.sqlite`: evidence, node states, actions, counterfactuals.
- `results/colony_benchmark.json`: benchmark, negative control, 5-second event traces.
- `web/Charlie_Colony_Thought_Replay.html`: standalone offline interactive evidence replay.
- `docs/COGNITIVE_BOUNDARIES_AND_EQUATIONS.md`: exactly what is and is not implemented.
- `results/VERIFICATION.json`: executed checks, source fingerprints and test counts.

**Follow-up engineering:** To test a genuinely neurally driven deliberation loop, compare an explicit learned recurrent action-selection policy against this rule-based controller. It would need held-out temporal sequences, calibrated sensor readings, well-defined failure costs, and a robust veto independent of neuron outputs.
