# Charlie Colony: equations and the minimum scientifically defensible sense of "thought"

This experiment demonstrates **sequential evidence processing and decision reporting**, not phenomenological thought, awareness, or language understanding. The audit language is generated from predefined labels.

## Conductance and event layer — real executed new v2 core

For each visual neuron `i`, in model seconds,

`τ_e de_i/dt = w_R R_i + w_G G_i - e_i`

`τ_i di_i/dt = w_B B_i - i_i`

`C du_i/dt = -g_L u_i + e_i(E_e-u_i) + i_i(E_i-u_i) - a_i`

`τ_a da_i/dt = -a_i` except after a spike, where `a_i += adapt_jump`.

A bounded homeostatic threshold integrates rate deviation; the spike count and refractory events are computed in substeps. **The existing v2 code owns their implementation.** The short four-frame trace does not provoke a spike. A distinct 100-frame stimulation run tests spike formation and one-step-delayed recurrent delivery.

Stationary core readout on a synthetic RGB feature:

`e_inf = w_R R+w_G G`, `i_inf = w_B B`

`u_inf = (E_e e_inf + E_i i_inf)/(g_L + e_inf + i_inf)`

`q_i = sigmoid(κ(u_inf - θ_initial))`

This readout was trained through the *stationary* gradient on artificially labeled RGB observations. Its `q_i` is a **task-specific model output**, and is not a probability of a safe physical pathway.

## Observations and memory — separately implemented colony aggregation

Each candidate route has near and far RGB observations, and one range/age/quality tuple. With two optical nodes per route, `q_route = (q_near+q_far)/2`.

The observed history retains at most three qualifying scores, and computes their arithmetic mean:

`m_route(t)= (1/n_t) Σ_{k ∈ last<=3 valid images} q_route(k)`.

Do **not** call this a Bayesian posterior: readings may be correlated and the model scores are uncalibrated for physical safety.

The veto predicate, expressed in simulation units:

`qualifies = (range present) AND (age <= 0.25 s) AND (120 <= range <= 220 mm) AND (image_quality >= 0.65) AND (m_route >= 0.70)`.

When any route qualifies, the policy selects the largest `m_route`. If none qualifies, it requests a scan at most two times, then STOP. **Previously memorized safe observations do not bypass the current range gate.**

## Causal, physical, and epistemic limits

The four visual neurons' trained readouts are necessary for the route scores. Multiple local optical regions are aggregated; a conflicting far region can veto the near-region evidence. Six separate internal state machines and signed recurrent pulse delivery are implemented and numerically tested. However, the final action policy is hand-coded. Neither observed spikes nor recurrent messages directly alter it in this version. Thus this is a valid colony sensor-and-decision integration, **not** evidence of neural emergent reasoning.

A true learned multi-step neural planner would need an objective, training data, role assignments, feedback and failure analysis; simply turning up neuron counts does not produce thought.

The 120–220 mm ground limit is not sourced from an actual robot or ToF calibration. Physical safety requires geometry, slippage, load, optical uncertainty, dynamic stability, and emergency-stop tests not conducted here.

## Negative controls

1. Remove range: optical high-score paths must be UNKNOWN.
2. Stale range: even previously approved path must be rechecked.
3. Bad clearance: safety gate vetoes high model score.
4. Change near or far RGB: the synthetic model score changes and may force recheck.
5. Reverse target semantics: trained classification fails because it cannot know that the labels have been redefined.
6. Disable trained weights: the untrained core accepts more unsafe fixture cases.
7. Sustain input for 5 seconds: actual v2 firing and causal recurrent conductance become observable, unlike the four-frame choice trace.

Tests and traces are reproducible and are included in the package. Original and v2 models are retained, not overwritten.
