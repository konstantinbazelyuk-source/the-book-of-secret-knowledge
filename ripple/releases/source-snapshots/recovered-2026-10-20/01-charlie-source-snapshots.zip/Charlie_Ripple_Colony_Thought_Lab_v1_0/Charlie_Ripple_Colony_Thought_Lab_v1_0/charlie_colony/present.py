"""Build reproducible offline visualization from executed JSON only."""
from pathlib import Path
import html,json
ROOT=Path(__file__).resolve().parents[1]

def make_charts():
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    d=json.loads((ROOT/'results/colony_benchmark.json').read_text())
    labels=['Correct moves','Wrong moves','Abstentions']
    a=d['balanced_trained'];b=d['balanced_untrained']
    vals=[[a['correct_moves'],a['wrong_moves_vs_fixture_truth'],a['total']-a['correct_moves']-a['wrong_moves_vs_fixture_truth']],
          [b['correct_moves'],b['wrong_moves_vs_fixture_truth'],b['total']-b['correct_moves']-b['wrong_moves_vs_fixture_truth']]]
    fig,ax=plt.subplots(figsize=(10,5.5),layout='constrained')
    xs=range(3)
    ax.bar([x-.19 for x in xs],vals[0],width=.38,label='Trained Charlie v2 core')
    ax.bar([x+.19 for x in xs],vals[1],width=.38,label='Untrained Charlie v2 core')
    ax.set_xticks(list(xs),labels);ax.set_ylabel('Number of synthetic scenarios (n=400)')
    ax.set_title('Held-out balanced synthetic route selections')
    ax.legend();ax.grid(axis='y',alpha=.2)
    fig.savefig(ROOT/'results/synthetic_benchmark.png',dpi=170)
    plt.close(fig)
    x=d['sustained_stimulation']
    fig,ax=plt.subplots(figsize=(10,4.6),layout='constrained')
    times=[v['t'] for v in x['coupling']]
    ax.plot(times,[v['right_total'] for v in x['coupling']],label='Right-near cumulative neuron pulses')
    ax.plot(times,[v['relay_exc'] for v in x['coupling']],label='Relay excitatory conductance (model units)')
    ax.set_xlabel('Simulated seconds');ax.set_ylabel('Model state (separate scales)')
    ax.set_title('Actual v2 core dynamics: spike events and delayed synaptic state')
    ax.legend();ax.grid(alpha=.2)
    fig.savefig(ROOT/'results/neuron_stimulation.png',dpi=170)
    plt.close(fig)


def make_viewer():
    d=json.loads((ROOT/'results/thought_trace.json').read_text())
    b=json.loads((ROOT/'results/colony_benchmark.json').read_text())
    payload=json.dumps({'trace':d,'benchmark':{k:v for k,v in b.items() if k!='sustained_stimulation'}},allow_nan=False).replace('</','<\\/')
    template=r'''<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Charlie Ripple Colony — Observed Decision Replay</title><style>
:root{color-scheme:dark;--b:#090f19;--p:#101e30;--edge:#2b4054;--t:#ebf5fb;--m:#a6bbc8;--a:#6cf2cd;--warn:#ffd384;--bad:#f29aa6}
*{box-sizing:border-box}body{font-family:ui-sans-serif,system-ui,sans-serif;margin:0;color:var(--t);background:radial-gradient(circle at 15% 0%,#183348,var(--b) 58%)}
main{max-width:1170px;margin:auto;padding:23px 15px 60px}h1{font-size:clamp(27px,4.5vw,44px);letter-spacing:-.04em;margin:4px 0 9px}h2{font-size:16px;margin:0 0 12px}p{color:var(--m);line-height:1.55}.eyebrow{text-transform:uppercase;font-size:11px;letter-spacing:.2em;color:var(--a)}
.grid{display:grid;grid-template-columns:minmax(310px,1.3fr) minmax(320px,1fr);gap:15px;margin-top:20px}.card{background:#102034e6;border:1px solid var(--edge);border-radius:14px;padding:18px;min-width:0}.header{display:flex;align-items:center;justify-content:space-between;gap:14px}button{background:#203c4c;border:1px solid #456777;border-radius:9px;color:var(--t);padding:10px 15px;cursor:pointer}button:disabled{opacity:.4;cursor:default}button:hover:not(:disabled){background:#265b63}button:focus-visible{outline:2px solid var(--a)}.actions{display:flex;gap:7px;align-items:center;flex-wrap:wrap}.metric{font-size:30px;font-weight:720;letter-spacing:-.04em;color:var(--a)}
.badge{border-radius:10px;background:#19353f;padding:7px 10px;color:#9ef5df;font-size:12px}.warning{background:#3b301b;color:var(--warn)}.danger{background:#412831;color:#ffd1d9}
.path{padding:12px;margin:8px 0;border:1px solid var(--edge);border-radius:10px}.path strong{font-size:14px}.path small{color:var(--m);float:right}.bar{height:9px;background:#203044;border-radius:5px;overflow:hidden;margin:9px 0 5px}.fill{height:100%;background:linear-gradient(90deg,#4577b6,#64e1c3);width:0%;transition:width .2s}.pill{padding:5px 8px;border:1px solid var(--edge);border-radius:6px;color:var(--m);font-size:12px}
.flow{list-style:none;padding:0;margin:0}.flow li{padding:12px 5px;border-top:1px solid var(--edge)}.flow li:first-child{border:0}.flow label{display:block;color:var(--a);text-transform:uppercase;letter-spacing:.1em;font-size:10px;margin-bottom:5px}.flow span{line-height:1.5;font-size:14px}
.nn{display:grid;grid-template-columns:repeat(3,1fr);gap:9px}.node{border:1px solid #2d5261;border-radius:11px;padding:10px;background:#102d3b}.node b{display:block;font-size:12px}.node span{font-size:12px;color:var(--m)}.node em{display:block;font-size:21px;color:var(--a);font-style:normal;font-weight:700}table{border-collapse:collapse;width:100%;font-size:12px}th,td{border-bottom:1px solid var(--edge);padding:8px 6px;text-align:left}th{color:var(--m)}.small{font-size:12px;color:var(--m)}code{color:#8af0d6}footer{margin-top:16px;color:var(--m);font-size:12px}
@media(max-width:780px){.grid{grid-template-columns:1fr}.card{padding:13px}}
</style></head><body><main><div class="eyebrow">Ripple Research / v2 conductance colony / synthetic replay</div>
<h1>Charlie: a decision in six neurons</h1><p>An inspectable demonstration of <b>what the software calculated</b>. The decision trace is generated by explicit rules. No real camera, ToF hardware, language model, or consciousness was involved.</p>
<div class="header"><div class="actions"><button id="prev">← Previous</button><button id="next">Next observation →</button><span class="pill" id="position">Step 1/4</span></div><div class="badge" id="decision">—</div></div>
<div class="grid"><section class="card"><h2>Evidence and hypothetical scanning choices</h2><div id="routes"></div><p class="small">The visual values are logistic scores learned from artificial RGB labels. Clearance 120–220 mm and staleness ≤0.25 s are selected simulation gates, not certified physical safety limits.</p>
<h2 style="margin-top:22px">The programmed decision pipeline</h2><ol class="flow" id="thought"></ol></section>
<section class="card"><h2>Actual v2 neuron states (not thoughts)</h2><div class="nn" id="neurons"></div><p class="small">The four visual nodes use normalized RGB inputs. The two auxiliary nodes receive explicitly <b>virtual</b> hazard/missingness signals. Their conductance and pulse states evolve over numerical time, but the visible action grammar uses the four optical readouts and range/quality gates.</p><h2>Counterfactuals</h2><div id="counter"></div></section></div>
<section class="card" style="margin-top:15px"><h2>Evidence from held-out synthetic tests</h2><table><thead><tr><th>400 balanced cases</th><th>Trained</th><th>Untrained</th></tr></thead><tbody id="benchmark"></tbody></table><p class="small">The untrained core makes more selections, including mistakes. The trained core is more conservative and abstains more often. Neither is proven safe for physical deployment.</p></section>
<footer>OFFLINE · generated from executed JSON · epistemic label: <b>rule trace, not introspection</b> · original Charlie v2 neuron implementation unchanged.</footer>
<script>const DATA=__DATA__;
let idx=0;const n=DATA.trace.scenarios.length;
const esc=s=>String(s).replace(/[&<>\"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[c]));
function render(){const r=DATA.trace.scenarios[idx];document.getElementById('position').textContent=`Step ${idx+1}/${n}`;let d=r.decision.action;const badge=document.getElementById('decision');badge.textContent=d;badge.className='badge '+(d.startsWith('MOVE')?'':d.startsWith('STOP')?'danger':'warning');
document.getElementById('prev').disabled=idx===0;document.getElementById('next').disabled=idx===n-1;
document.getElementById('routes').innerHTML=['left','right'].map(side=>{let s=r.scores[side];return `<div class="path"><strong>${side.toUpperCase()}</strong><small>${esc(s.status)}</small><div class="bar"><div class="fill" style="width:${Math.min(100,Math.max(0,s.instant_score*100))}%"></div></div><div class="small">Visual score: ${s.instant_score.toFixed(3)} · filtered: ${s.filtered_score?.toFixed(3)??'—'}</div><div class="small">Range: ${s.range_mm??'unknown'} mm · reading age: ${s.range_age_s??'—'} s · image quality: ${s.image_quality.toFixed(2)}</div></div>`}).join('');
document.getElementById('thought').innerHTML=['observe','interpret','test','choose','explain'].map(k=>`<li><label>${k}</label><span>${esc(r.thought_trace[k])}</span></li>`).join('');
document.getElementById('neurons').innerHTML=DATA.trace.node_names.map(name=>{let p=r.neuron_internal[name];return `<div class="node"><b>${esc(name.replace('_',' '))}</b><em>${p.spikes_total}</em><span>spikes cumulative</span><span>membrane ${p.membrane.toFixed(3)}</span></div>`}).join('');
document.getElementById('counter').innerHTML=Object.entries(DATA.trace.counterfactuals).map(([k,v])=>`<p class="small" style="margin:7px 0"><b>${esc(k.replaceAll('_',' '))}</b> → ${esc(v)}</p>`).join('');
const a=DATA.benchmark.balanced_trained,b=DATA.benchmark.balanced_untrained;
document.getElementById('benchmark').innerHTML=[['Correct synthetic moves',a.correct_moves,b.correct_moves],['Incorrect moves',a.wrong_moves_vs_fixture_truth,b.wrong_moves_vs_fixture_truth],['Abstentions',a.total-a.correct_moves-a.wrong_moves_vs_fixture_truth,b.total-b.correct_moves-b.wrong_moves_vs_fixture_truth],['Safe-route coverage',`${(a.correct_move_coverage_when_route_safe*100).toFixed(1)}%`,`${(b.correct_move_coverage_when_route_safe*100).toFixed(1)}%`]].map(t=>`<tr><td>${t[0]}</td><td>${t[1]}</td><td>${t[2]}</td></tr>`).join('');}
document.getElementById('prev').addEventListener('click',()=>{idx=Math.max(0,idx-1);render()});document.getElementById('next').addEventListener('click',()=>{idx=Math.min(n-1,idx+1);render()});render();</script></main></body></html>'''
    source=template.replace('__DATA__',payload)
    (ROOT/'web/Charlie_Colony_Thought_Replay.html').write_text(source)
    return len(source)

if __name__=='__main__':
    make_charts();print('HTML bytes',make_viewer())
