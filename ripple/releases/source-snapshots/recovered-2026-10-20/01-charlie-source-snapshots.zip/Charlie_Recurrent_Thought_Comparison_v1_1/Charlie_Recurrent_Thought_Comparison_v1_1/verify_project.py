from pathlib import Path
import json,hashlib,sqlite3,subprocess,re,sys,zipfile
P=Path(__file__).resolve().parent
EXPECTED={'charlie_core/neuron.py':'bf96fc4dae90eeee65e3f895207c6c5714f736b1b9dbf09569e1c24a8b440f77',
'charlie_core/network.py':'e26bb40bac6857565bc4c36b81869d127106c6ed3b409add5ea68ce6bcf8802e',
'legacy/v2_trained_core_state_LOCKED.json':'f23fb97df731cfa0fcd6e9292946962b7960684e2e57a9812d79d65e5d5a40cc'}
checks={p:hashlib.sha256((P/p).read_bytes()).hexdigest() for p in EXPECTED}
assert checks==EXPECTED,(checks,EXPECTED)
res=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-p','test_*.py','-q'],cwd=P,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=90)
assert res.returncode==0,res.stdout
count=int(re.search(r'Ran (\d+) tests',res.stdout).group(1))
smoke=subprocess.run(['node','tests/viewer_smoke.cjs'],cwd=P,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=25)
assert smoke.returncode==0,smoke.stdout
with sqlite3.connect(P/'results/evidence.sqlite') as db:
    integrity=db.execute('PRAGMA integrity_check').fetchone()[0]
    traces=db.execute('SELECT COUNT(*) FROM trace').fetchone()[0]
    assert integrity=='ok' and traces==228
r=json.loads((P/'results/benchmark.json').read_text())
assert r['fluctuation_test']['trajectory_not_static']
assert r['fluctuation_test']['decision_changed_by_spike_ablation_in_76_step_trace']>0
assert r['fluctuation_test']['decision_changed_by_coupling_ablation_in_76_step_trace']>0
assert r['benchmark']['recurrent']['counts']['incorrect']==0
assert r['benchmark']['static']['counts']['correct']>r['benchmark']['recurrent']['counts']['correct']
gpt=json.loads((P/'results/chatgpt_session_reference.json').read_text())
assert 'NO external ChatGPT API' in gpt['method']
assert gpt['case_count']==12
out={'name':'Charlie Recurrent Thought Comparison v1.1','scientific_status':'executed_synthetic_simulation','tests_passed':count,
     'viewer_smoke':'passed in Node VM with stubbed canvas, NOT full browser rendering',
     'frozen_core_source_hashes':checks, 'colony_database_integrity':integrity,'stored_trace_rows':traces,
     'benchmark':{k:{p:v[p] for p in ('steps','counts','correct_recall_on_safe_steps')} for k,v in r['benchmark'].items()},
     'fluctuation_test':r['fluctuation_test'],
     'chatgpt_judgments':{'count':12,'provenance':'current session GPT-6 self-authored answers after seeing Charlie outputs; not blind, not API'},
     'limits':['no actual physical sensor input','no physical robot acts','no independent ChatGPT API comparison',
               'no measured intelligence or consciousness','static-rule baseline outperforms recurrence in synthetic route coverage']}
(P/'results/VERIFICATION.json').write_text(json.dumps(out,indent=2)+'\n')
print('Verification passed:',count,'tests; viewer smoke; sqlite; frozen source hashes')
