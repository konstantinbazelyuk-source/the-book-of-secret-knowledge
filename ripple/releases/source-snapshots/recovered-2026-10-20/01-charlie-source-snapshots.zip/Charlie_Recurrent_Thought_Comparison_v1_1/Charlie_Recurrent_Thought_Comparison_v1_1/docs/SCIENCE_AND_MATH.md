# Charlie Recurrent Deliberation v1.1 — reproducible mathematics and limitations

## Study purpose and actual changes

Charlie v2 conductance-based neuron **remains unchanged byte-for-byte**. The previous v1.0 thought colony used a stationary nonlinear visual readout plus hand-authored rules. Its neuronal spikes were logged but **did not affect decisions**. This experiment retains independent v2 neuron objects and creates a NEW decision-coupling mechanism that uses their spike events and one-tick delayed synaptic graph messages.

Each route s has two visual neurons processing synthetic RGB, one virtual relay neuron, and a dimensionless accumulator `z_s`. Thus six actual v2 neuronal instances. Relay inputs `(0, score, 1-score)` are constructed virtual numerical features; their components **do not** represent physical light wavelengths. The learned v2 stationary scores are task-specific outputs, not calibrated probabilities of safe terrain.

Let p_s be the mean of the two visual core outputs, q_s in [0,1] input image-quality heuristic, dt the elapsed sampling interval, n_s the number of relay spikes this frame, and m_s the number of spikes from visual neurons delivered over the graph from the **previous frame**. Let `a=exp(-dt/tau_z)`. The newly introduced external temporal decision law is:

```
e_s = clip(2 * (p_s - 0.5), -1, +1)  if quality >= 0.65 else 0
z_s(t+dt) = clip( a*z_s(t) + (1-a)*e_s*q_s
                 + (gamma*n_s + kappa*m_s) if spike path enabled,
                 -1.5, +1.5 )
```

Predeclared experimental constants `tau_z=0.43 s`, `gamma=0.082 per relay spike`, `kappa=0.052 per graph-delivered visual spike`, `z_commit=0.56`. The formulas' gains are chosen research parameters, **not measured physical constants**. This formula is not a Bayes update, not human thought, and not a new natural law. Neurons follow the pre-existing conductance law:

```
C du/dt = g_L(E_L-u) + g_e(E_e-u) + g_i(E_i-u) - adaptive_current
```

with inherited excitatory/inhibitory trace decay, spike reset and rate adaptation. The six neurons communicate through one-step delayed excitatory edges from each of four visual neurons to its corresponding side relay, and two cross-inhibitory relay edges. The new accumulator consumes the relay spike count and delayed incoming signal count. The `no_coupling` ablation removes all the graph edges; `spikes_ignored` preserves the physical-style computation but forces both contributions to zero. The `static` control uses the **previous v1.0 source unchanged**.

The complete safety/decision gate is, for a route, `image_quality>=.65`, `range present`, `age<=.25 s`, and `120<=range_mm<=220`; then `p_s>=.70` and `z_s>=.56`. Competing qualified routes require a difference of at least .05 in z, otherwise defer. No hardware commands are emitted, and these ranges are synthetic task thresholds, not established field safety limits. After four unsuccessful re-scan requests a NONTERMINAL `HOLD_UNRESOLVED` is returned; valid fresh evidence can later restore simulated selection.

## Experiment and objective

Twenty synthetic trajectories are fixed ahead of comparison: five types (`switch`, `alternating`, `both`, `none`, `blocked`) times four independent deterministic input seeds (`11,13,17,19`). Each consists of 76 time steps at 50 ms (total 1,520 per controller). Color input variation is scripted sinusoidal perturbation, not measured light noise. After each decision, synthetic reference labels are computed from **an oracle not imported into the controller**:

```
patch_true = 0.55*R + 1.30*G - 0.65*B > 0.68
route_true = patch_true(near) and patch_true(far) and valid_range and valid_quality
```

Ground-truth labels are not derived from actual ground safety. Metric `correct` means selection agrees with this oracle. `incorrect=0` means no incorrect decisions **in these exact synthetic fixtures**, not a quantified physical safety rate. Safer states are not necessarily the same as maximizing correct selections. At every threshold keep hard gates separate from recurrence.

The static v1.0 route-rule controller has better synthetic route coverage. The v1.1 recurrent version shows genuinely changing state and causal signal influence, but this experiment does not establish better overall policy quality. Its temporal accumulator deliberately waits for accumulated evidence.

## GPT-6 / ChatGPT comparison and scientific status

The 12 small comparison snapshots were selected deterministically with a fixed enumerated list. GPT-6, the assistant in this actual conversation, authored twelve text decisions after seeing the test case inputs **and** Charlie's actions. Their literal outputs and reasons are preserved in `results/chatgpt_session_reference.json`. This is a current-conversation, non-blinded, non-independent illustrative comparison. **No OpenAI API endpoint was invoked. No separate ChatGPT deployment was run. No model-comparative significance, superiority, or parity is claimed.** The scenarios are not equal-information trials (ChatGPT got present observations, Charlie retained evolving neuron history), and they are too small for reliable claims.

A genuinely controlled GPT comparison requires user-authorized API execution or an external blinded assessor, fixed model snapshot/settings, equal input histories, fixed instructions and scoring, then multiple disjoint held-out scenario families; add distribution shift and false range inputs. Reversed synthetic labels can invalidate color meaning without changing RGB. No current model detects the semantic reversal from inputs alone.

## Verification and what the test does NOT prove

Unit tests check frozen core SHA-256, input bounds, strict temporal ordering, noninterchangeable neuron states, spike-driven decision changes, graph-delivered signal effect, input switching, stale/invalid clearance veto, fixed seeds and database integrity. These are numerical and software-engineering facts. This model does **not** measure physical sensors, robotics, reliable task-level intelligence, semantic understanding, mental introspection, consciousness, electromagnetism or robot motion.
