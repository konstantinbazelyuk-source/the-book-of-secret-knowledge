from pathlib import Path
import json,hashlib,sqlite3,zipfile,math,re
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from charlie_recurrent.experiment import benchmark,persist
from charlie_recurrent.chatgpt_reference import main as chatgpt_cases
P=Path(__file__).resolve().parent
r=benchmark();persist(r,P/'results');g=chatgpt_cases()
rp=r['representative_trace']['recurrent']
# provenance and failures
record={
 'release':'Charlie Recurrent Decision Comparison v1.1',
 'software_tests':'60/60 Python (run separately); JavaScript viewer smoke run separately',
 'simulation_steps':sum(v['steps'] for v in r['benchmark'].values()),
 'unique_scenario_steps':r['benchmark']['recurrent']['steps'],
 'recurrent_counts':r['benchmark']['recurrent']['counts'],
 'ablations':{x:r['benchmark'][x]['counts'] for x in ('spikes_ignored','no_coupling','static')},
 'synthetic_semantic_reversal':r['synthetic_label_reversal_control'],
 'sample_gpt6':{'judgments':12,'method':'actual authored current-chat assistant responses; manual, unblinded, not external API',
                'safe_route_choices':sum(x['chatgpt_selected_safe_under_synthetic_reference'] is True for x in g['cases']),
                'wrong_route_choices':sum(x['chatgpt_selected_safe_under_synthetic_reference'] is False for x in g['cases']),
                'charlie_safe_route_choices':sum(x['charlie_selected_safe_under_synthetic_reference'] is True for x in g['cases'])},
 'fluctuations':r['fluctuation_test'],
 'source_sha256':{p:hashlib.sha256((P/p).read_bytes()).hexdigest() for p in ['charlie_core/neuron.py','charlie_core/network.py','legacy/v2_trained_core_state_LOCKED.json','charlie_colony/lab.py','charlie_recurrent/engine.py']},
 'physical_measurements':0,
 'source':'executed synthetic digital experiments'
}
(P/'results'/'release_metrics.json').write_text(json.dumps(record,indent=2)+'\n')
# Dynamic actual-state traces
plt.figure(figsize=(12,4.5))
t=[x['t'] for x in rp]
left=[x['recurrent']['memory']['left'] for x in rp]
right=[x['recurrent']['memory']['right'] for x in rp]
plt.plot(t,left,label='Left temporal evidence')
plt.plot(t,right,label='Right temporal evidence')
plt.axhline(.56,linestyle='--',label='Decision evidence threshold')
plt.axvline(1.9,linestyle=':',label='Synthetic scene switches')
plt.xlabel('Simulated time (s)');plt.ylabel('Dimensionless evidence state')
plt.title('Charlie v2: computed fluctuations and route reversal (executed simulation)')
plt.grid(alpha=.2);plt.legend(loc='best');plt.tight_layout();plt.savefig(P/'results'/'temporal_fluctuations.png',dpi=145);plt.close()
plt.figure(figsize=(9,4.6))
names=['Recurrent\nfull','Spikes\nignored','Links\nremoved','Static\nv1.0']
ks=('recurrent','spikes_ignored','no_coupling','static')
correct=[r['benchmark'][k]['counts']['correct'] for k in ks]
absafe=[r['benchmark'][k]['counts']['abstained_safe'] for k in ks]
plt.bar(names,correct,label='Correct synthetic route choices')
plt.bar(names,absafe,bottom=correct,label='Abstained while safe route existed')
plt.ylabel('Safe-opportunity time steps (total 884)');plt.title('Temporal decision ablation: same 1,520 synthetic frames')
plt.legend();plt.tight_layout();plt.savefig(P/'results'/'policy_comparison.png',dpi=145);plt.close()
# chart pulses time
plt.figure(figsize=(12,3.4))
pl=[x['recurrent']['pulse']['left'] for x in rp]
pr=[x['recurrent']['pulse']['right'] for x in rp]
plt.step(t,pl,where='mid',label='Left relay spikes/frame')
plt.step(t,pr,where='mid',label='Right relay spikes/frame')
plt.xlabel('Simulated time (s)');plt.ylabel('Spikes per 50 ms step');plt.title('Actual time-evolving Charlie v2 spike events')
plt.legend();plt.tight_layout();plt.savefig(P/'results'/'relay_spikes.png',dpi=145);plt.close()
# Interactive offline HTML
rawdata={'schema':'charlie-replay/1.1','representative':rp, 'metrics':record, 'gpt':g['cases']}
encoded=json.dumps(rawdata,separators=(',',':')).replace('</','<\\/')
html='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Charlie · Dynamic Thought Comparison v1.1</title>
<style>:root{color-scheme:dark;--bg:#0a1520;--pane:#142636;--border:#315268;--txt:#e4f1f6;--sub:#a9c8d5;--mint:#56dfbc;--orange:#e5ae64}*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 5% 0,#164540, #0a1520 50%);color:var(--txt);font:14px/1.45 system-ui, sans-serif}main{max-width:1080px;margin:auto;padding:24px 14px 50px}h1{font-size:clamp(25px,4vw,38px);margin:4px 0}h2{font-size:16px;margin:0 0 12px}p{color:var(--sub)}.tag{font-size:11px;letter-spacing:.15em;color:var(--mint);text-transform:uppercase}.panel{background:#132838d9;border:1px solid var(--border);border-radius:16px;padding:17px;margin:14px 0}.grid{display:grid;grid-template-columns:1fr 1fr;gap:13px}.small{font-size:12px;color:var(--sub)}label{display:block;font-size:12px;color:var(--sub);margin:12px 0}button,select{color:var(--txt);background:#1a3b49;border:1px solid #51717d;border-radius:7px;padding:9px 13px;margin-right:7px;cursor:pointer}input[type=range]{width:100%;accent-color:var(--mint)}canvas{width:100%;height:auto;background:#081924;border:1px solid var(--border);border-radius:9px}table{width:100%;border-collapse:collapse;font-size:13px}td,th{text-align:left;border-bottom:1px solid #2e5364;padding:9px 7px}th{color:var(--sub)}.metric{font-size:23px;font-weight:700}.state{font-weight:700;color:var(--mint);font-size:18px}pre{font:12px/1.55 ui-monospace,monospace;white-space:pre-wrap;overflow-wrap:anywhere;color:#c8e8ec}@media(max-width:700px){.grid{grid-template-columns:1fr}}</style></head><body><main><div class="tag">Ripple / Charlie / Recurrent research v1.1</div><h1>Fluctuating Decision Observatory</h1><p>Executed digital-neuron traces, not conscious thought. All sensor values are simulated. The original Charlie v2 neuron core is preserved.</p>
<div class="grid"><div class="panel"><div class="metric">60/60</div><div class="small">Python unit tests · separately check verification.json</div></div><div class="panel"><div class="metric">1,520</div><div class="small">Synthetic time steps per controller</div></div></div>
<section class="panel"><h2>Actual computed evidence fluctuations</h2><canvas id="plot" width="920" height="380" aria-label="Dynamic memory traces"></canvas><label>Replay time step <span id="idx">1</span> / 76<input id="step" type="range" min="0" max="75" value="0"></label><div><button id="back">Previous</button><button id="next">Next</button><button id="play">Play</button><button id="pause">Pause</button></div></section>
<div class="grid"><section class="panel"><h2>Current colony observation</h2><div class="state" id="action">–</div><table><tbody><tr><td>Simulated time</td><td id="time">–</td></tr><tr><td>Left state</td><td id="left">–</td></tr><tr><td>Right state</td><td id="right">–</td></tr><tr><td>Left / right relay spikes</td><td id="spikes">–</td></tr><tr><td>Change if spikes ignored</td><td id="abl">–</td></tr></tbody></table><p class="small" id="reason"></p></section><section class="panel"><h2>Controlled ablation results</h2><table><thead><tr><th>Model</th><th>Correct</th><th>Incorrect</th></tr></thead><tbody id="metrics"></tbody></table><p class="small">The static system remains more decisive on this synthetic dataset. Lower coverage is a real negative result for the recurrent system.</p></section></div>
<section class="panel"><h2>ChatGPT versus Charlie: 12 illustrative snapshots</h2><p class="small">These ChatGPT judgments were manually authored by GPT-6 in the current chat, after the Charlie outputs were visible; not blind, not an independent API evaluation. Compare qualitative decisions only.</p><label>Scenario<select id="case"></select></label><pre id="comparison"></pre></section>
<div class="panel"><h2>Evidence boundaries</h2><p>These traces are computed from Charlie v2 conductance neurons and explicit delayed message coupling. The safety check is a synthetic rule. Dynamic state values are not calibrated beliefs or probabilities. No camera, robot motors, contact physics, or ChatGPT API have been exercised.</p></div></main>
<script id="state-data" type="application/json">@@STATE@@</script>
<script>
const data=JSON.parse(document.getElementById('state-data').textContent);const byId=x=>document.getElementById(x);let index=0,timer=null;const rows=data.representative;const metrics=data.metrics;
function chart(){let c=byId('plot'),ctx=c.getContext('2d'),w=c.width,h=c.height;ctx.fillStyle='#081924';ctx.fillRect(0,0,w,h);const pad=46;
 const xp=i=>pad+(w-2*pad)*i/(rows.length-1),yp=v=>h-pad-(h-2*pad)*(v+1.2)/2.6;
 ctx.strokeStyle='#3c5765';ctx.lineWidth=1;for(let v=-1;v<=1;v+=.5){ctx.beginPath();ctx.moveTo(pad,yp(v));ctx.lineTo(w-pad,yp(v));ctx.stroke();}
 const paths=[['left','#55d8bb'],['right','#e5ae64']];paths.forEach(([side,color])=>{ctx.beginPath();ctx.strokeStyle=color;ctx.lineWidth=2.6;rows.forEach((r,i)=>{const x=xp(i),y=yp(r.recurrent.memory[side]);if(i===0)ctx.moveTo(x,y);else ctx.lineTo(x,y)});ctx.stroke();});
 ctx.strokeStyle='#cdd7de';ctx.setLineDash([6,6]);ctx.beginPath();ctx.moveTo(pad,yp(.56));ctx.lineTo(w-pad,yp(.56));ctx.stroke();ctx.setLineDash([]);ctx.strokeStyle='#fff';ctx.beginPath();ctx.moveTo(xp(index),15);ctx.lineTo(xp(index),h-pad);ctx.stroke();ctx.font='14px system-ui';ctx.fillStyle='#55d8bb';ctx.fillText('LEFT',pad+3,23);ctx.fillStyle='#e5ae64';ctx.fillText('RIGHT',pad+84,23);}
function render(){const r=rows[index];byId('step').value=index;byId('idx').textContent=index+1;byId('action').textContent=r.action;byId('time').textContent=r.t.toFixed(2)+' s';byId('left').textContent=r.recurrent.memory.left.toFixed(3);byId('right').textContent=r.recurrent.memory.right.toFixed(3);byId('spikes').textContent=r.recurrent.pulse.left+' / '+r.recurrent.pulse.right;const ab=data.representative[index];byId('abl').textContent=(r.recurrent.pulse.left+r.recurrent.pulse.right)+' events this step';byId('reason').textContent='Result checked against hidden synthetic reference AFTER the decision: '+r.score;chart()}
const cmp=byId('case');data.gpt.forEach((x,i)=>{let opt=document.createElement('option');opt.value=i;opt.textContent=x.id+' · '+x.mode;cmp.appendChild(opt)});function showc(){let x=data.gpt[Number(cmp.value)||0];byId('comparison').textContent='Time '+x.time_s.toFixed(2)+' s\nCharlie recurrent: '+x.current_dynamic_action+'\nChatGPT (current session, not blinded): '+x.chatgpt_current_session_response+'\nWhy: '+x.chatgpt_rationale+'\nReference truth (scored afterward): '+JSON.stringify(x.reference_truth_after_scoring)};cmp.onchange=showc;
for(const [title,k] of [['Full recurrent','recurrent'],['Spikes ignored','spikes_ignored'],['Links disconnected','no_coupling'],['Static v1.0','static']]){let v=metrics.ablations[k]||metrics.recurrent_counts;let tr=document.createElement('tr');for(let s of [title,v.correct,v.incorrect]){let td=document.createElement('td');td.textContent=s;tr.appendChild(td);}byId('metrics').appendChild(tr)}
byId('next').onclick=()=>{index=Math.min(rows.length-1,index+1);render()};byId('back').onclick=()=>{index=Math.max(0,index-1);render()};byId('step').oninput=e=>{index=+e.target.value;render()};byId('play').onclick=()=>{if(!timer)timer=setInterval(()=>{index=(index+1)%rows.length;render()},160)};byId('pause').onclick=()=>{clearInterval(timer);timer=null};render();showc();
</script></body></html>'''
for chunk in ['Charlie recurrent:', 'ChatGPT (current session, not blinded):', 'Why:', 'Reference truth (scored afterward):']:
    html=html.replace('\n'+chunk,'\\n'+chunk)
(P/'web'/'Charlie_Dynamic_Replay.html').write_text(html.replace('@@STATE@@',encoded))
print('Created plots, offline HTML, databases and metrics.')
