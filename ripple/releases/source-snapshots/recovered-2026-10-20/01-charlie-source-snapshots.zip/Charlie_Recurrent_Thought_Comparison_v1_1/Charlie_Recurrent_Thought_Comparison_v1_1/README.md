# Charlie Recurrent Colony vs ChatGPT — v1.1

**Status:** locally executed and reproducible research **simulation**. Six individually simulated Charlie v2 conductance-based neurons now contribute spike events and delayed messages directly to a time-dependent route-selection mechanism. The predecessor static policy is included intact as a baseline. Synthetic perception and safety; no actuators or sensor hardware.

## Local execution (Python 3.10+, Matplotlib to regenerate plots, Node.js for offline viewer smoke test)

```bash
cd Charlie_Recurrent_Thought_Comparison_v1_1
PYTHONPATH=. python -m unittest discover -s tests -p 'test_*.py' -q
PYTHONPATH=. python -m charlie_recurrent.experiment
PYTHONPATH=. python -m charlie_recurrent.chatgpt_reference
PYTHONPATH=. python build_release.py
node tests/viewer_smoke.cjs
```

Only `build_release.py` needs Matplotlib; the decision engine, experiments, SQLite and unit tests use Python standard library.

Open `web/Charlie_Dynamic_Replay.html` in a browser to play 76 saved frames. The states and results are **replayed executed numerical values**, not inferred from the viewer. All HTML data are embedded; no server or remote connection is needed.

## Results in executed 1,520-step synthetic test (20 trajectories)

| Policy | Correct move decisions | Incorrect move decisions | Abstained while a safe option existed | Coverage of safe-opportunity steps |
|---|---:|---:|---:|---:|
| v1.1 recurrent with delayed links | 357 | 0 | 527 | 40.4% |
| v1.1 same integrator, but spikes ignored | 235 | 0 | 649 | 26.6% |
| v1.1 relay spikes enabled, graph links removed | 297 | 0 | 587 | 33.6% |
| previous v1.0 static rule baseline | 852 | 0 | 32 | 96.4% |

636 steps had no safe option in the synthetic reference. The zero wrong-move count applies ONLY to these deterministic reference examples. The static rule has a considerably higher correct-route coverage: v1.1 is **not proven superior**.

In a representative 76-step right-to-left change sequence, full recurrence vs spike removal yields 10 changed actions; vs disconnected links yields 7 changed actions. The right evidence accumulator takes 76 different rounded values and 15 relay spike events occur. These are verifiable causal numerical differences. No general intelligence, consciousness, or physical robotic skill is implied.

## ChatGPT reference (12 unblinded snapshots)

GPT-6, the assistant in this conversation, authored 12 straightforward safety-oriented route judgments. It selected 8 synthetic safe routes while this recurrent Charlie version selected 5 on those snapshots; neither selected a synthetic unsafe route. This **is not a controlled head-to-head evaluation**: ChatGPT's judgments were written after the Charlie actions were visible, no independent ChatGPT API was invoked, and ChatGPT was given current observations rather than the full 76-frame histories. See `docs/SCIENCE_AND_MATH.md` and exact judgments in `results/chatgpt_session_reference.json`.

## Content

- `charlie_core/` — byte-identical v2 neuron and network implementation from the previous approved research release.
- `charlie_colony/` — unchanged previous v1.0 static decision baseline.
- `charlie_recurrent/engine.py` — new time-dependent recurrent action policy.
- `charlie_recurrent/experiment.py` — deterministic synthetic sequences and paired ablation comparisons.
- `results/` — raw records, evidence.sqlite, charts, model snapshots, and provenance.
- `web/` — offline interactively scrubbed temporal trace and comparison.
- `legacy/` — original Ripple source and frozen trained v2 model.
- `docs/SCIENCE_AND_MATH.md` — new state equation, experiment design, and epistemic limits.

**Preservation contract:** no source replacement; new mathematics is in `charlie_recurrent/engine.py`. No externally connected agents, remote evaluation accounts, robots or motor hardware were controlled.
