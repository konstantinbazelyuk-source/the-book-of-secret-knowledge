# CHARLIE RIPPLE — Mathematical Systems Integration v1.0

**Research status:** audited mathematical study + reproducible, integrated **software** execution on synthetic inputs. Not artificial general intelligence, a physically running spider robot, a real-world camera sensor, optical electric-field measurement, or an autonomous online system.

**Purpose:** recover existing Ripple equations and alternative designs, maintain their histories/negatives, combine mathematically compatible adapters into a tested integrated runtime, and store the model graph plus execution evidence in queryable databases. Named **Charlie Ripple** at the user's request. The result is a new research **integration**, not a new natural law.

## The immutable pieces

- Original frozen `legacy/ripple-core.js` from the recovered Master Ripple archive; **actual archived JavaScript executes** in the Node runner.
- Frozen `legacy/photoreceptor-v06.js` supplies the optional display-referred optical transform.
- Frozen `legacy/quaternary-core.mjs` for exact quaternary source preservation. A lightweight Python two-bit roundtrip is independently tested and the source itself remains available unchanged.
- Archived Python port of the locked neuron and digital 24-axis motor/8-leg geometry; v1.3 fixed evolutionary parameter search is inherited without modification (`ripple_evo/`).
- All frozen files have a byte-level SHA-256 in `docs/SOURCE_HASHES.json`. No original kernel equation was overwritten.

## What was built and executed

- 56 source-attributed formulas across nine technical families, 40 explicit related formula links, 19 source-family records, and six preserved negative findings.
- A SHA-256 catalog of 26 archive records including 14 checked top-level ZIPs and 12 independently hashed nested archives in Master Ripple; nested archives are not assumed unique.
- **Two SQLite databases**: `results/charlie_formulas.sqlite` (source/formula graph, failures, studies, archive inventory) and `results/charlie_colony_memory.sqlite` (synthetic observations, neuron events, pose-tagged map cells, policy tests, colony lifecycle).
- An actual frozen JavaScript eight-neuron run over 240 synthetic color samples per tile, both raw and with preserved photoreceptor v0.6 preprocessing.
- A separate **bounded adaptive colony** using independent copies of the locked v0.1 Python source (2–8 logical nodes), demand hysteresis, stable tile identities and a recorded birth/retirement ledger.
- Conservative synthetic diffusion and inverse range evidence on a 16x16 grid; finite-value and units enforcement.
- Four inherited, unmodified motor policies reevaluated using six newly specified synthetic actuator settings. The highest-speed candidate fails the proxy feasibility gate; not promoted.
- Offline, searchable `Formula_Observatory.html`, CSV exports, study Markdown, and figures.

## Run on your computer

Python 3.11+; Node.js 18+ for running the *real archived original JavaScript*.

```bash
python -m unittest discover -s tests -q
python -m charlie.build
python -m charlie.archive_audit
python -m charlie.memory
python -m charlie.study
python -m charlie.plots  # matplotlib optional: charts already included
```

Run from the unzipped project directory. The core runs require only Python standard library and Node.js. The plotting script uses matplotlib. No account, Internet connection, camera access or real motor is required; none is implicitly granted.

Open `Formula_Observatory.html` in a browser to filter mathematical formulas by family, status, and term. It is static: it does not connect to hardware or a cloud backend.

### SQLite queries

```sql
SELECT id, title, expression, units, status FROM formulas WHERE family='neuron';
SELECT upstream,downstream,relationship FROM connections WHERE upstream='N04';
SELECT id, description, boundary FROM negative_results ORDER BY id;
SELECT policy,toe_error_mm,commanded_speed_mm_s,proxy_feasible FROM policy_studies;
SELECT tick,action,tile FROM colony_lifecycle ORDER BY tick,tile;
```

The two databases are **persistent data files** in this ZIP. They are not externally hosted databases or sentient memory systems.

## Documentation

- `docs/MATHEMATICAL_STUDY.md` — *all 56 inspected formulas, source, units, assumptions, validity proof sketches, dependency map, and negative results.*
- `docs/INTERFACE_CONTRACT.md` — strict units, provenance, module boundaries, and physical evidence requirements.
- `docs/LIMITATIONS_AND_FAILURES.md` — traceable negative studies and current physical gaps.
- `docs/SOURCE_HASHES.json` — frozen source SHA-256 manifest.
- `results/ARCHIVE_INVENTORY.json` — 26 inspected archive records with SHA-256.
- `results/RELEASE_METRICS.json`, `results/charlie_integrated_run.json`, `results/charlie_adaptive_colony.json`, `results/charlie_motor_policy_comparison.json` — numerical evidence.

## Open research references

- Neuron mathematical model: https://neuronaldynamics.epfl.ch/online/Ch1.S3.html
- Occupancy mapping: Elfes (1989), DOI 10.1109/2.30720
- NSGA-II: Deb et al. (2002), DOI 10.1109/4235.996017
- NIST metrological traceability: https://www.nist.gov/calibrations/traceability
- Raspberry Pi Global Shutter Camera: https://www.raspberrypi.com/products/raspberry-pi-global-shutter-camera/
- ST VL53L1X distance sensing: https://www.st.com/en/imaging-and-photonics-solutions/vl53l1x.html

References support *established principles*, not claims of tested physical Ripple hardware. Retained historical sources and third-party components keep their original attribution and licensing; new documentation does not relicense them.
