"""Unit and property-like regression tests for Charlie Ripple."""
import unittest,hashlib,json,sqlite3,tempfile,math,random
from pathlib import Path
from charlie.database import BASE, build_db,summary,record
from charlie.catalog import F,RELATIONS
from charlie.pipeline import (synthetic_fixture,run_original_js,check_observation,
    diffusion_step,trace_ray_logodds,pack4,unpack4,analyze_colony,motor_policy_comparison,preselected_policies)
from legacy.ripple_optical_agent_LOCKED import RippleNeuron
from ripple_evo.evolution import Genome
from ripple_evo.pareto import dominates,feasible

class CharlieTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.samples=synthetic_fixture(n=240,seed=47)
        cls.raw=run_original_js(cls.samples,'raw')

    def test_01_source_lock(self):
        expected=json.loads((BASE/'docs/SOURCE_HASHES.json').read_text())
        self.assertGreaterEqual(len(expected),8)
        for item in expected:self.assertEqual(hashlib.sha256((BASE/item['path']).read_bytes()).hexdigest(),item['sha256'])

    def test_02_source_python_core_sha(self):
        self.assertEqual(hashlib.sha256((BASE/'legacy/ripple_optical_agent_LOCKED.py').read_bytes()).hexdigest(),'7f2f611cd8f1717c3d3dcae745dbd41efc37e24315d93878231db52eaf614f77')

    def test_03_js_python_count_parity(self):
        nodes=[RippleNeuron() for _ in range(8)]
        cnt=[0]*8
        for s in self.samples:
            for i,x in enumerate(s['tiles']):cnt[i]+=nodes[i].step(tuple(x),s['dt'])['count']
        self.assertEqual(cnt,self.raw['spikes'])

    def test_04_js_python_theta_parity(self):
        nodes=[RippleNeuron() for _ in range(8)]
        for s in self.samples:
            for i,x in enumerate(s['tiles']):nodes[i].step(tuple(x),s['dt'])
        # Compare first node with JS replay over all samples; its times and states are preserved.
        single=run_original_js(self.samples,'raw')
        self.assertEqual(single['spikes'],self.raw['spikes'])
        for a,b in zip(single['final_theta'],nodes):self.assertAlmostEqual(a,b.theta,places=10)

    def test_05_invalid_nonfinite_rejected(self):
        s=dict(self.samples[0]);s['tiles']=[x[:] for x in s['tiles']];s['tiles'][0][0]=math.nan
        with self.assertRaises(ValueError):check_observation(s)

    def test_06_unknown_real_source_rejected(self):
        s=dict(self.samples[0]);s['provenance']='hardware_reported_unverified'
        with self.assertRaises(ValueError):check_observation(s)

    def test_07_units_rejected(self):
        s=dict(self.samples[0]);s['unit']='newtons'
        with self.assertRaises(ValueError):check_observation(s)

    def test_08_calibration_false_only(self):
        s=dict(self.samples[0]);s['calibrated']=True
        with self.assertRaises(ValueError):check_observation(s)

    def test_09_wrong_tile_count(self):
        s=dict(self.samples[0]);s['tiles']=s['tiles'][:4]
        with self.assertRaises(ValueError):check_observation(s)

    def test_10_timebase(self):
        for dt in [-1,0,.501,math.inf]:
            s=dict(self.samples[0]);s['dt']=dt
            with self.assertRaises(ValueError):check_observation(s)

    def test_11_unit_interval(self):
        s=dict(self.samples[0]);s['tiles']=[x[:] for x in s['tiles']];s['tiles'][0][0]=1.01
        with self.assertRaises(ValueError):check_observation(s)

    def test_12_original_LIF_analytic_frequency(self):
        D=.7;theta=.45;tv=.5;ref=.1
        freq=1/(ref+tv*math.log(D/(D-theta)))
        self.assertGreater(freq,0)
        self.assertLess(freq,10)
        step=RippleNeuron(adaptive=False)
        ev=[]
        for _ in range(4000):ev+=step.step((D/2,0,0),.05)['events']
        periods=[ev[i]-ev[i-1] for i in range(1,len(ev))]
        self.assertLess(abs(stat_mean(periods)-1/freq),1e-6)

    def test_13_inverse_feasible(self):
        D=1.4;f=1.;tv=.5;ref=.1
        th=D*(-math.expm1(-(1/f-ref)/tv))
        recompute=1/(ref+tv*math.log(D/(D-th)))
        self.assertAlmostEqual(recompute,f,places=10)

    def test_14_conservation_no_walls(self):
        rng=random.Random(55)
        g=[[rng.random() for _ in range(14)] for _ in range(14)]
        old=sum(map(sum,g))
        for _ in range(120):g=diffusion_step(g)
        self.assertAlmostEqual(sum(map(sum,g)),old,places=8)

    def test_15_conservation_opaque(self):
        rng=random.Random(11);g=[[rng.random() for _ in range(12)] for _ in range(12)]
        walls={(5,i) for i in range(4,8)}
        old=sum(map(sum,g))
        for _ in range(30):g=diffusion_step(g,walls=walls)
        self.assertAlmostEqual(sum(map(sum,g)),old,places=8)

    def test_16_nonnegative_field(self):
        rng=random.Random(77);g=[[rng.random() for _ in range(16)] for _ in range(16)]
        for _ in range(100):g=diffusion_step(g)
        self.assertGreaterEqual(min(min(r) for r in g),0.)

    def test_17_unsafe_flux_refused(self):
        with self.assertRaises(ValueError):diffusion_step([[0.]*4 for _ in range(4)],k=1,dt=.26)

    def test_18_logodds_hit_is_bounded(self):
        n=32;l=[[0.]*n for _ in range(n)]
        for _ in range(100):trace_ray_logodds(n,l,(0.,0.),0.,.5,1.)
        self.assertAlmostEqual(max(max(row) for row in l),3.5)
        self.assertAlmostEqual(min(min(row) for row in l),-3.5)

    def test_19_logodds_behind_hit_unknown(self):
        n=64;l=[[0.]*n for _ in range(n)];trace_ray_logodds(n,l,(0.,0.),0,.5,1.)
        self.assertEqual(l[32][45],0.0)  # >1.3 m behind sensor

    def test_20_map_invalid_distance_refused(self):
        with self.assertRaises(ValueError):trace_ray_logodds(16,[[0.]*16 for _ in range(16)],(0,0),0,-.1,1.)

    def test_21_pack_roundtrip_full_byte_range(self):
        for b in range(256):self.assertEqual(pack4(unpack4(b)),b)

    def test_22_pack_invalid(self):
        with self.assertRaises(ValueError):pack4([0,1,2,4])

    def test_23_photoreceptor_executes(self):
        result=run_original_js(self.samples,'photoreceptor')
        self.assertTrue(result['original_js_executed'])
        self.assertNotEqual(result['spikes'],self.raw['spikes'])

    def test_24_catalog_graph_fk(self):
        with tempfile.TemporaryDirectory() as td:
            con=build_db(Path(td)/'unit.sqlite')
            self.assertEqual(con.execute('PRAGMA foreign_key_check').fetchall(),[])
            self.assertEqual(summary(con)['formulas'],len(F))
            self.assertEqual(summary(con)['connections'],len(RELATIONS))
            con.close()

    def test_25_formula_identifier_unique(self):self.assertEqual(len(F),len({f.id for f in F}))

    def test_26_record_evidence_json(self):
        with tempfile.TemporaryDirectory() as td:
            con=build_db(Path(td)/'record.sqlite')
            record(con,'t1','unit','simulated',{'x':1},{'y':2})
            row=con.execute('SELECT evidence_type,results_json FROM experiments').fetchone()
            self.assertEqual(row[0],'simulated');self.assertEqual(json.loads(row[1])['y'],2)
            con.close()

    def test_27_external_pareto_policy_gates(self):
        a=preselected_policies()
        self.assertEqual(a['precision']['release_gate'],'PASS_SIMULATION_PROXY_GATE')
        self.assertEqual(a['throughput']['release_gate'],'REJECTED_HOLDOUT_PROXY_GATE')

    def test_28_new_postholdout_rejects_throughput(self):
        m=motor_policy_comparison()['policies']
        self.assertFalse(m['throughput']['feasible_new_proxy_gate'])
        self.assertTrue(m['precision']['feasible_new_proxy_gate'])

    def test_29_no_hardware_deployment_allowed(self):
        result,*_=analyze_colony(self.samples)
        self.assertTrue(result['rejected_real_world_action'])
        self.assertFalse(result['map']['physical_localization'])

    def test_30_json_manifest_valid(self):
        self.assertGreater(len(json.loads((BASE/'docs/SOURCE_HASHES.json').read_text())),7)

    def test_31_simulated_input_reproducible(self):
        self.assertEqual(self.samples,synthetic_fixture(n=240,seed=47))

    def test_32_different_seed_changes(self):
        self.assertNotEqual(self.samples,synthetic_fixture(n=240,seed=49))

    def test_33_original_source_is_not_rewritten(self):
        text=(BASE/'legacy/ripple-core.js').read_text()
        self.assertIn('2*x[0]+1.2*x[1]-1.4*x[2]',text)
        self.assertIn('this.theta+this.eta*(integral-this.target*dt)',text)

    def test_34_all_negatives_registered(self):
        with tempfile.TemporaryDirectory() as td:
            con=build_db(Path(td)/'db.sqlite')
            self.assertEqual(summary(con)['negative_results'],6)
            con.close()


def stat_mean(vals):return sum(vals)/len(vals)
if __name__=='__main__':unittest.main()

class AdaptiveTests(unittest.TestCase):
    def test_bounded_population_and_retirement(self):
        from charlie.colony import synthetic_colony_trial
        t=synthetic_colony_trial()
        self.assertEqual(t['min_nodes'],2)
        self.assertEqual(t['max_nodes'],8)
        self.assertGreater(t['births'],8)
        self.assertGreater(t['retirements'],0)
        self.assertEqual(t['os_processes_spawned'],0)

    def test_strict_local_identity(self):
        from charlie.colony import CharlieAdaptiveColony
        c=CharlieAdaptiveColony(min_nodes=2,capacity=8)
        c.process([[.2,.1,.1] for _ in range(8)])
        old={i:id(v.neuron) for i,v in c.nodes.items()}
        c.process([[.9,.1,.1] for _ in range(8)])
        c.process([[.1,.1,.1] for _ in range(8)])
        self.assertEqual(len(c.nodes),8)
        self.assertEqual({i:id(c.nodes[i].neuron) for i in old},old)

    def test_capacity_guard(self):
        from charlie.colony import CharlieAdaptiveColony
        with self.assertRaises(ValueError):CharlieAdaptiveColony(min_nodes=8,capacity=4)

    def test_bad_colony_input(self):
        from charlie.colony import CharlieAdaptiveColony
        with self.assertRaises(ValueError):CharlieAdaptiveColony().process([[math.nan,0,0]]*8)

    def test_cycle_recorded(self):
        from charlie.colony import synthetic_colony_trial
        result=synthetic_colony_trial()
        self.assertTrue(all(x['tile'] in range(8) for x in result['life_events']))
        self.assertTrue(all(2<=r['active']<=8 for r in result['trace']))

    def test_two_databases_consistent(self):
        from charlie.memory import create
        counts=create()
        self.assertEqual(counts['observations'],1920)
        self.assertEqual(counts['neuron_events'],197)
        self.assertEqual(counts['policy_studies'],4)
        self.assertGreater(counts['colony_lifecycle'],0)

    def test_archive_inventory_sha_integrity(self):
        data=json.loads((BASE/'results'/'ARCHIVE_INVENTORY.json').read_text())
        self.assertEqual(len(data),26)
        self.assertTrue(all(len(x['sha256'])==64 for x in data))
        self.assertEqual(len({x['archive'] for x in data}),26)
