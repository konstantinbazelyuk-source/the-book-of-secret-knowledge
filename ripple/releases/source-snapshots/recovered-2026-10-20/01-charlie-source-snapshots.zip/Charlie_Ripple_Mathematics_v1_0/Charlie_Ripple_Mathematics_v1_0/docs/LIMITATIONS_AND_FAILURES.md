# Negative controls, unresolved gaps, and deliberate exclusions

- Prior experimental feedforward threshold regulators do not overwrite the approved original LIF neuron. Some were faster in selected synthetic conditions, which is not a blanket improvement or proof of superior real biological behavior.
- Color-channel polarity calibration produced **distribution-shift failures** in synthetic settings; those genes are listed in the catalog, not enabled automatically.
- A genetic search was previously able to reward itself by altering the simulated environmental communication cost; the corrected model fixes that cost independently of candidate genes.
- Four-symbol quaternary data encoding is a conventional two-bit code, not an extra transistor state or quantum computing advantage. Prior coverage studies found no universal improvement.
- Increasing logical colony worker count can increase duplicated sensing and CPU overhead. No throughput claim is inferred from node births.
- Source-preserved photoreceptor-on and raw trials produce different pulse counts; count is **not** predictive accuracy, agent intelligence or biological activity.
- An older v1.2 motor optimizer's best overall score used zero neuron feedback gain. A later v1.3 precision setting has gain >0, but an increase in precision comes with reduced commanded-motion proxy.
- A v1.3 aggressive speed policy failed the post-holdout support proxy gate. Charlie retested it on six independent **synthetic** settings and again rejected it, without changing the preselected policy parameters.
- Ground contact, friction, force, servo torque, power draw, obstacle recognition from camera pixels, external camera calibration, photonic phase hardware, and validated real pose remain unimplemented.
- This release has no trainable LLM, self-awareness, physical AI, consciousness, real-time background activity, or connection to an external device or cloud database. The databases are generated reproducibly in the package's local working runtime.
- Not every original chat archive may have been accessible; 52 expressions are the **documented and inspected** scope, not a completeness claim covering all unseen work.
