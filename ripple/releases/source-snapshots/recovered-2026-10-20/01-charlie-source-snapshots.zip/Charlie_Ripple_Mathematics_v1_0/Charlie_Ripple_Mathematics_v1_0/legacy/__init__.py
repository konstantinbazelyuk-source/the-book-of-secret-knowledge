"""Frozen Ripple code; new code must not edit these sources."""
