"""Bounded adaptive tile colony inspired by preserved SpiderScan v0.6 scheduler.
The locked v0.1 Python port is instantiated independently for each persistent tile.
Scaling logical objects is NOT scaling CPU throughput or intelligence.
"""
import math,random
from dataclasses import dataclass
from legacy.ripple_optical_agent_LOCKED import RippleNeuron

@dataclass
class Node:
    tile:int
    born:int
    neuron:RippleNeuron

class CharlieAdaptiveColony:
    def __init__(self,n_tiles=8,min_nodes=2,capacity=8,threshold=.07):
        if not 1<=min_nodes<=capacity<=n_tiles<=32:raise ValueError('node budget')
        self.n_tiles=n_tiles;self.capacity=capacity;self.min_nodes=min_nodes;self.threshold=threshold
        self.nodes={};self.prev=None;self.tick=0;self.grow=0;self.shrink=0;self.history=[]
    def process(self,frame,dt=.05):
        if not 0<dt<=.5 or len(frame)!=self.n_tiles or any(len(v)!=3 or any(not math.isfinite(x) or x<0 or x>1 for x in v) for v in frame):
            raise ValueError('finite normalized 3-channel features and clock required')
        diffs=([0.0]*self.n_tiles if self.prev is None else
               [sum(abs(a-b) for a,b in zip(frame[i],self.prev[i]))/3 for i in range(self.n_tiles)])
        self.prev=[v[:] for v in frame]
        demand=sum(d>=self.threshold for d in diffs)
        target=max(self.min_nodes,min(self.capacity,demand))
        ranking=sorted(range(self.n_tiles),key=lambda i:(-diffs[i],i))
        if not self.nodes:
            for i in ranking[:self.min_nodes]:self._birth(i)
        else:
            self.grow=(self.grow+1 if target>len(self.nodes) else 0)
            self.shrink=(self.shrink+1 if target<len(self.nodes) else 0)
            if self.grow>=2:
                for i in ranking:
                    if len(self.nodes)>=target:break
                    if i not in self.nodes:self._birth(i)
                self.grow=0
            elif self.shrink>=4:
                for i in sorted(self.nodes,key=lambda i:(diffs[i],i)):
                    if len(self.nodes)<=target:break
                    self.history.append(dict(tick=self.tick,action='retire',tile=i))
                    del self.nodes[i]
                self.shrink=0
        events=0
        for i in sorted(self.nodes):events+=self.nodes[i].neuron.step(tuple(frame[i]),dt)['count']
        r={'tick':self.tick,'active':len(self.nodes),'target':target,'event_count':events,
           'tile_ids':sorted(self.nodes),'mean_temporal_difference':sum(diffs)/self.n_tiles}
        self.tick+=1;return r
    def _birth(self,i):
        self.nodes[i]=Node(i,self.tick,RippleNeuron());self.history.append(dict(tick=self.tick,action='birth',tile=i))


def synthetic_colony_trial(n=160,seed=13):
    rng=random.Random(seed);c=CharlieAdaptiveColony();trace=[]
    for t in range(n):
        burst=(25<=t<85) or (115<=t<135)
        frame=[]
        for i in range(8):
            if burst:
                red=(.12 if (t+i)%2 else .88)
                frame.append([red,.05+.01*i,.12])
            else:frame.append([.20+.01*i,.05+.01*i,.10])
        trace.append(c.process(frame))
    return {'schema':'charlie-colony/1','provenance':'synthetic','frames':n,
      'min_nodes':min(r['active'] for r in trace),'max_nodes':max(r['active'] for r in trace),
      'total_model_events':sum(r['event_count'] for r in trace),'births':sum(e['action']=='birth' for e in c.history),
      'retirements':sum(e['action']=='retire' for e in c.history),
      'life_events':c.history,'trace':trace,'os_processes_spawned':0}
