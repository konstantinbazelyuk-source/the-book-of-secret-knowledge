"""Charlie: auditable fusion of existing Ripple mathematics, no autonomous actuator or sensor I/O."""
from __future__ import annotations
import sys,math,random,subprocess,json,hashlib,statistics
from pathlib import Path
from .database import BASE


def check_observation(o):
    if not isinstance(o,dict) or o.get('provenance')!='simulated' or o.get('unit')!='normalized_rgb' or o.get('calibrated') is not False:
        raise ValueError('Only explicit synthetic uncalibrated RGB fixtures accepted here')
    dt=o.get('dt')
    if isinstance(dt,bool) or not isinstance(dt,(int,float)) or not math.isfinite(dt) or not (0<dt<=.5):
        raise ValueError('invalid timebase')
    xs=o.get('tiles')
    if not isinstance(xs,list) or len(xs)!=8:raise ValueError('eight spatial inputs required')
    for tile in xs:
        if not isinstance(tile,list) or len(tile)!=3 or any(type(x) not in (float,int) or not math.isfinite(x) or x<0 or x>1 for x in tile):
            raise ValueError('RGB channels must be finite normalized input')
    return True


def synthetic_fixture(n=240,dt=.05,seed=47):
    if not 2<=n<=2000:raise ValueError('fixture steps budget')
    rng=random.Random(seed);arr=[]
    for k in range(n):
        tiles=[]
        for i in range(8):
            s=.5+.3*math.sin(.064*k+.55*i)
            r=max(0,min(1, .20+.65*s+rng.gauss(0,.012)))
            g=max(0,min(1, .12+.20*(1-s)+rng.gauss(0,.01)))
            b=max(0,min(1, .08+.34*((k//40+i)%3==1)))
            tiles.append([r,g,b])
        arr.append(dict(provenance='simulated',unit='normalized_rgb',calibrated=False,dt=dt,tiles=tiles))
    return arr


def run_original_js(samples,mode):
    for s in samples:check_observation(s)
    runner=BASE/'charlie/node_runner.cjs'
    payload=json.dumps({'mode':mode,'samples':samples},allow_nan=False)
    try:
        run=subprocess.run(['node',str(runner)],input=payload,text=True,capture_output=True,check=True,timeout=25)
    except FileNotFoundError as e:raise RuntimeError('Node.js required to execute the frozen JS source') from e
    except subprocess.CalledProcessError as e:raise RuntimeError('Frozen JS execution error: '+e.stderr[-300:]) from e
    return json.loads(run.stdout)


def diffusion_step(grid,k=.12,dt=.25,walls=()):
    """Explicit paired face transfer; source-free conservation for all non-walled cells."""
    n=len(grid)
    if not 2<=n<=128 or any(len(row)!=n for row in grid):raise ValueError('square grid required')
    if k<0 or dt<=0 or 4*k*dt>1:raise ValueError('monotone stability condition')
    wall=set(walls)
    out=[[float(x) for x in row] for row in grid]
    for y in range(n):
        for x in range(n):
            if (x,y) in wall:continue
            for dx,dy in ((1,0),(0,1)):
                u,v=x+dx,y+dy
                if u>=n or v>=n or (u,v) in wall:continue
                flux=k*dt*(grid[v][u]-grid[y][x]);out[y][x]+=flux;out[v][u]-=flux
    return out


def trace_ray_logodds(n, logodds, pose, angle, distance_m, max_m, resolution_m=.1):
    """Synthetic range ray, clipped additive log odds. Supplied known synthetic pose."""
    if not(0<=distance_m<=max_m<=12 and .02<=resolution_m<=1):raise ValueError('range illegal')
    x0,y0=pose
    if not all(math.isfinite(x) for x in [x0,y0,angle,distance_m,max_m]):raise ValueError('nonfinite ray')
    hit=distance_m<max_m-1e-6
    coords=[]
    for i in range(max(1,math.ceil(distance_m/resolution_m*2))+1):
        d=distance_m*i/max(1,math.ceil(distance_m/resolution_m*2))
        ix=math.floor((x0+d*math.cos(angle))/resolution_m+n/2)
        iy=math.floor((y0+d*math.sin(angle))/resolution_m+n/2)
        if 0<=ix<n and 0<=iy<n and (not coords or coords[-1]!=(ix,iy)):coords.append((ix,iy))
    for x,y in (coords[:-1] if hit else coords):logodds[y][x]=min(3.5,max(-3.5,logodds[y][x]-.4))
    if hit and coords:
        x,y=coords[-1];logodds[y][x]=min(3.5,max(-3.5,logodds[y][x]+.85))
    return len(coords),hit


def pack4(symbols):
    if len(symbols)!=4 or any(type(s)!=int or s not in range(4) for s in symbols):raise ValueError('quaternary codes')
    return sum(sym<<(6-2*i) for i,sym in enumerate(symbols))


def unpack4(b):
    if type(b)!=int or not 0<=b<=255:raise ValueError('byte range')
    return [(b>>shift)&3 for shift in (6,4,2,0)]


def analyze_colony(samples):
    raw=run_original_js(samples,'raw');ph=run_original_js(samples,'photoreceptor')
    # A simple equivalent field pass, not a learned optical spectrum or spatial reconstruction.
    n=16;grid=[[0.0 for _ in range(n)] for _ in range(n)];grid[8][8]=1.0
    old=sum(map(sum,grid));walls={(7,7),(7,8),(7,9)}
    for _ in range(60):grid=diffusion_step(grid,walls=walls)
    new=sum(map(sum,grid))
    logodds=[[0.0]*n for _ in range(n)]
    raylen=[]
    for a in (-.6,-.3,0,.3,.6):raylen.append(trace_ray_logodds(n,logodds,(-.25,-.15),a,.45,1.0))
    touched=sum(sum(abs(v)>0 for v in row) for row in logodds)
    symbols=[min(3,v) for v in raw['spikes'][:4]]
    packed=pack4(symbols)
    return {
      'schema':'charlie-ripple/integrated-numerical/1','kind':'simulated',
      'rgb_samples':len(samples),'virtual_workers':8,
      'neuron':{'raw_events':raw['total_spikes'],'photoreceptor_events':ph['total_spikes'],
                'by_worker':raw['spikes'],'mean_final_theta':round(statistics.mean(raw['final_theta']),6),
                'mode_comparison':'cannot compare event counts as intelligence score'},
      'diffusion':{'mass_before':old,'mass_after':new,'mass_error':abs(new-old),'sources_or_sinks':False},
      'map':{'known_pose_supplied':True,'synthetic_rays':len(raylen),'affected_logodds_cells':touched,
             'hit_ray_count':sum(int(hit) for _,hit in raylen),'physical_localization':False},
      'quaternary':{'input_codes':symbols,'packed_byte':packed,'round_trip':unpack4(packed)},
      'rejected_real_world_action':True,'evidence':'executed_software_on_synthetic_inputs',
      'original_js_source_file_sha256':hashlib.sha256((BASE/'legacy/ripple-core.js').read_bytes()).hexdigest(),
    },raw,ph


def preselected_policies():
    """Load fixed held-out v1.3 evidence; no selection from holdout in Charlie."""
    p=BASE/'studies/v13_pareto_seed_20261013.json'
    d=json.loads(p.read_text());return d['policies']


def motor_policy_comparison():
    # Import original archived model (not rewritten), run a tiny evaluation on disjoint synthetic conditions.
    from ripple_evo.evolution import Genome
    from ripple_evo.pareto import describe,feasible
    base=preselected_policies();policies=['baseline','previous_v1_2','precision','throughput']
    scenarios=[{'id':f'charlie-postholdout-{i}','tau_s':t,'max_speed_rad_s':w}
      for i,(t,w) in enumerate([(.06,3.6),(.08,2.9),(.12,2.6),(.15,2.0),(.17,1.9),(.075,1.65)])]
    result={}
    for name in policies:
        m=describe(Genome(**base[name]['genome']),scenarios,duration_s=3.2)
        result[name]={'metrics':m,'feasible_new_proxy_gate':feasible(m),'previous_v13_holdout_gate':base[name]['release_gate']}
    # Charlie never promotes any policy based on the same post-evaluation holdout set.
    return {'scenario_provenance':'new synthetic actuator regimes, not physical motors',
            'n_cases':len(scenarios),'scenarios':scenarios,'policies':result,
            'deployment_authorized':False,'new_promotion':False}
