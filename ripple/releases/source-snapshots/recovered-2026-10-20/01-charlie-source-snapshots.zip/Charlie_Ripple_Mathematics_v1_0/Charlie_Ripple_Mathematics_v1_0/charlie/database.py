"""SQLite formula/provenance graph. No network or executable SQL from user input."""
import hashlib,json,sqlite3
from pathlib import Path
from .catalog import F, RELATIONS
BASE=Path(__file__).resolve().parents[1]
SCHEMA='''
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS sources (
 source_id TEXT PRIMARY KEY, title TEXT NOT NULL, original_location TEXT,
 sha256 TEXT, local_reference TEXT, origin_type TEXT NOT NULL, evidence_note TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS formulas (
 id TEXT PRIMARY KEY, family TEXT NOT NULL, title TEXT NOT NULL,
 expression TEXT NOT NULL, units TEXT NOT NULL, source_id TEXT NOT NULL,
 status TEXT NOT NULL, role TEXT NOT NULL, caveat TEXT NOT NULL,
 FOREIGN KEY(source_id) REFERENCES sources(source_id));
CREATE INDEX IF NOT EXISTS formulas_family ON formulas(family);
CREATE TABLE IF NOT EXISTS connections (
 upstream TEXT NOT NULL, downstream TEXT NOT NULL, relationship TEXT NOT NULL,
 PRIMARY KEY(upstream,downstream,relationship),
 FOREIGN KEY(upstream) REFERENCES formulas(id),FOREIGN KEY(downstream) REFERENCES formulas(id));
CREATE TABLE IF NOT EXISTS experiments (
 run_id TEXT PRIMARY KEY, experiment TEXT NOT NULL, evidence_type TEXT NOT NULL,
 input_sha256 TEXT NOT NULL, results_json TEXT NOT NULL, status TEXT NOT NULL,
 CHECK(evidence_type IN ('executed_software','simulated','calculated','proposed','physical_measured')));
CREATE TABLE IF NOT EXISTS negative_results (
 id TEXT PRIMARY KEY, source_id TEXT NOT NULL, description TEXT NOT NULL,
 boundary TEXT NOT NULL, FOREIGN KEY(source_id) REFERENCES sources(source_id));
'''
SOURCES={
'neuron_v01':('Ripple Neuron original v0.1','Master v2 archived legacy/ripple-core.js','frozen_source','CC0 fixed weight LIF core'),
'photoreceptor_v06':('Ripple Photoreceptor v0.6','Master v2 legacy/photoreceptor-v06.js','frozen_source','Logarithmic temporal contrast preprocessing'),
'quaternary_v07':('Ripple-Q v0.7','Master v2 legacy/quaternary-core.mjs','frozen_source','Four-state telemetry & DFT; not quantum computing'),
'mycelium_v03':('Ripple Cybernetic Mycelium Mathematics v0.3','Optical Historical archive baseline/v0.3-MATHEMATICS.md','recovered_document','Hybrid feedback + bounded scaling, not locked LIF'),
'optical_historical_v04':('Optical Historical Mathematics v0.4','Optical Historical archive docs/DERIVATIONS.md','recovered_document','Calibration, lock-in and statistical rejection'),
'optical_agent_v01':('Ripple Optical Agent Research v0.1','Previous conversation package / frozen optical agent Python','local_archive','Simulated phase stepping, no optical hardware'),
'heterodyne_v01':('Ripple Heterodyne v0.1','Prior conversation; not independently recovered as code in this study','documented_prior','Doppler equation known; physical implementation unverified'),
'master_v20':('Master Ripple Alpha v2.0','Library archive Master_Ripple_Alpha_v2.0_Open_Research_Release.zip','recovered_archive','Typed sensor gateway, log-odds and spectrum'),
'alpha_spatial_v10':('Ripple Alpha Spatial Lab v1.0','Library archive Ripple_Alpha_Labs_v1.0_Open_Research_Release.zip','recovered_archive','Conservative finite volume and occlusion'),
'alpha_lab_v10':('Ripple Alpha Labs v1.0','Library MATHEMATICAL_CODEX.md','recovered_document','Digital genotype, fixed fitness, virtual worker economics'),
'sensory_gene_v12':('Ripple Sensory Gene Gate Alpha v1.2','Library MATHEMATICAL_MODEL(2).md','recovered_document','Synthetic supervision, projected gene gradient'),
'spider_ground_v05':('SpiderScan Ground v0.5','Local archive Ripple_SpiderScan_Ground_v0_5.zip','local_archive','Image calibration and optical scanner mathematical conventions'),
'sensor_bridge_v02':('Ripple Sensor Bridge v0.2','Local archive Ripple_Sensor_Bridge_v0_2.zip','local_archive','Pixel flow on digitally moved photographs'),
'spider_colony_v06':('SpiderScan Colony v0.6','Local archive Ripple_SpiderScan_Colony_v0_6.zip','local_archive','Persistent SQLite 16x16 chunk storage'),
'motor_evo_v12':('SpiderScan Motor Evolution v1.2','Local archive Ripple_Cloud_Evolution_Alpha_v1_2.zip','local_archive','Fixed first-order motor, error and risk adapters'),
'pareto_v13':('Ripple EvoPareto v1.3','Local archive Ripple_Evo_Pareto_v1_3.zip','local_archive','Holdout-constrained multiple objective search'),
'fieldsphere_v01':('Ripple FieldSphere v0.1','Master v2 frozen archive Ripple_FieldSphere_v0.1_Open_Source_Manufacturing.zip','recovered_nested_archive','Eight-location magnetic-vector field and coil Biot-Savart simulation'),
'spectrum_v01':('Ripple Spectrum v0.1','Master v2 frozen archive Ripple_Spectrum_v0.1_Prototype.zip','recovered_nested_archive','Temporal Hann-window Fourier spectrum on synthetic magnetic/photodiode signals'),
'charlie_v10':('Charlie Ripple v1.0','This generated research release','new_source','Validation and compatibility graph')}
NEG=[('fail1','mycelium_v03','Naive PI threshold controller performed poorly in small synthetic sweep.','Preserve original threshold regulator.'),('fail2','sensory_gene_v12','Polarity gene improved reversed-color synthetic cases but failed under distribution shift.','No unconditional global polarity inversion.'),('fail3','alpha_lab_v10','A candidate gene made assumed hop cost zero to game fitness.','Environmental cost fixed outside genome.'),('fail4','pareto_v13','High-throughput gait selected on training failed holdout support-proxy gate.','Keep rejected candidate, no motor deployment.'),('fail5','motor_evo_v12','v1.2 best combined objective selected zero neuron-feedback gain.','Do not attribute v1.2 improvement to neuron feedback.'),('fail6','master_v20','Quaternary encoding did not improve coverage on tested synthetic holdout.','Telemetry is not demonstrated intelligence improvement.')]

def source_path(k):
    return {
      'neuron_v01':BASE/'legacy/ripple-core.js',
      'photoreceptor_v06':BASE/'legacy/photoreceptor-v06.js',
      'quaternary_v07':BASE/'legacy/quaternary-core.mjs',
      'optical_agent_v01':BASE/'legacy/ripple_optical_agent_LOCKED.py',
      'motor_evo_v12':BASE/'legacy/v13_evolution.py',
      'pareto_v13':BASE/'legacy/v13_pareto.py',
    }.get(k)

def build_db(path):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    con=sqlite3.connect(path);con.executescript(SCHEMA)
    for sid,(title,location,origin,note) in SOURCES.items():
        p=source_path(sid);sha=hashlib.sha256(p.read_bytes()).hexdigest() if p and p.is_file() else None
        con.execute('INSERT OR REPLACE INTO sources VALUES(?,?,?,?,?,?,?)',(sid,title,location,sha,str(p.relative_to(BASE)) if p else None,origin,note))
    for f in F:
        con.execute('INSERT OR REPLACE INTO formulas VALUES(?,?,?,?,?,?,?,?,?)',(f.id,f.family,f.title,f.expression,f.units,f.source,f.status,f.role,f.caveat))
    for a,b,r in RELATIONS:con.execute('INSERT OR IGNORE INTO connections VALUES(?,?,?)',(a,b,r))
    for a,b,c,d in NEG:con.execute('INSERT OR REPLACE INTO negative_results VALUES(?,?,?,?)',(a,b,c,d))
    con.commit();return con

def record(con,run_id,name,kind,inputs,output,status='PASSED'):
    j=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False)
    h=hashlib.sha256(j(inputs).encode()).hexdigest()
    con.execute('INSERT OR REPLACE INTO experiments VALUES(?,?,?,?,?,?)',(run_id,name,kind,h,j(output),status));con.commit()

def summary(con):
    return {table:con.execute('SELECT count(*) FROM '+table).fetchone()[0] for table in ('sources','formulas','connections','experiments','negative_results')}
