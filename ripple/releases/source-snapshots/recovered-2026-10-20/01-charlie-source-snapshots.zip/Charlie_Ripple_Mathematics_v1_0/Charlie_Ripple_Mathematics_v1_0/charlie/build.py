"""Build Charlie Ripple evidence, audited SQLite records, and human-readable study exports."""
from __future__ import annotations
import csv,hashlib,json,sqlite3,sys,subprocess,statistics
from pathlib import Path
from .database import build_db,record,summary,BASE,SOURCES
from .catalog import F,RELATIONS
from .pipeline import synthetic_fixture,analyze_colony,motor_policy_comparison,preselected_policies
from .colony import synthetic_colony_trial


def build():
    out=BASE/'results';out.mkdir(exist_ok=True)
    con=build_db(out/'charlie_formulas.sqlite')
    samples=synthetic_fixture()
    composite,raw,ph=analyze_colony(samples)
    motor=motor_policy_comparison()
    adaptive=synthetic_colony_trial()
    (out/'charlie_adaptive_colony.json').write_text(json.dumps(adaptive,indent=2)+'\n')
    (out/'charlie_integrated_run.json').write_text(json.dumps(composite,indent=2)+'\n')
    (out/'charlie_motor_policy_comparison.json').write_text(json.dumps(motor,indent=2)+'\n')
    (out/'charlie_neuron_traces.json').write_text(json.dumps({'raw':raw,'photoreceptor':ph},indent=2)+'\n')
    record(con,'RUN-CHARLIE-001','Eight-node frozen JS and optical mode comparisons','simulated',samples,composite)
    record(con,'RUN-MOTOR-001','Inherited motor policies on new synthetic settings','simulated',motor['scenarios'],motor)
    record(con,'RUN-COLONY-001','Bounded adaptive colony growth and retirement','simulated',{'seed':13,'steps':160},adaptive)
    record(con,'RUN-SOURCE-001','SHA-256 locked source manifest','executed_software','source files',json.loads((BASE/'docs/SOURCE_HASHES.json').read_text()))
    metrics=summary(con)
    con.close()
    with (out/'formula_registry.csv').open('w',newline='') as fh:
        w=csv.DictWriter(fh,fieldnames=list(F[0].__dict__.keys()));w.writeheader();w.writerows(f.__dict__ for f in F)
    with (out/'formula_dependencies.csv').open('w',newline='') as fh:
        w=csv.writer(fh);w.writerow(['upstream','downstream','relationship']);w.writerows(RELATIONS)
    # Human-readable, small static search page with data embedded, no network.
    render_html(metrics,motor,composite)
    result={'schema':'charlie-research/1','status':'software-executed','formula_db_counts':metrics,'provenance':'simulated_inputs_only',
            'locked_sources_sha256':json.loads((BASE/'docs/SOURCE_HASHES.json').read_text()),
            'runs':{'integrated':composite,'adaptive_colony':{k:v for k,v in adaptive.items() if k not in ('trace','life_events')},'motor_postholdout':{k:{'toe_error_mm':v['metrics']['mean_toe_error_mm'],'commanded_speed_mm_s':v['metrics']['mean_commanded_speed_mm_s'],'support_loss_frames':v['metrics']['total_support_proxy_loss_frames'],'feasible':v['feasible_new_proxy_gate']} for k,v in motor['policies'].items()}},
            'scope_exclusions':['no physical sensor','no physical servo','no autonomous agent','no consciousness or LLM','no motor commands','no flight']}
    (out/'RELEASE_METRICS.json').write_text(json.dumps(result,indent=2)+'\n')
    return result


def render_html(counts,motor,composite):
    items=[f.__dict__ for f in F]
    payload=json.dumps(items,ensure_ascii=False).replace('<','\\u003c')
    page='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Charlie Ripple | Mathematical Observatory</title><style>
:root{font-family:system-ui;background:#0b1720;color:#e6f3f4}body{max-width:1100px;margin:auto;padding:22px 17px}header{border-bottom:1px solid #34515a;margin-bottom:20px}h1{font-size:clamp(25px,4vw,42px);margin:5px 0 10px}h2{font-size:19px}p{color:#abc4c7;line-height:1.6}.banner{font-size:12px;letter-spacing:.14em;color:#72dbc2;text-transform:uppercase}.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin:18px 0}.stat{background:#142b36;padding:17px;border:1px solid #35505c;border-radius:11px}.stat strong{font-size:26px;display:block}input,select{padding:11px;background:#112b36;border:1px solid #507481;color:#e3f0f2;border-radius:8px;font-size:15px;min-width:0}.controls{display:flex;flex-wrap:wrap;gap:10px;margin:18px 0}.card{background:#112530;border:1px solid #2a4b57;border-radius:12px;margin:10px 0;padding:13px 16px}.card h3{margin:0 0 7px;font-size:17px}.card code{display:block;padding:11px;background:#081923;border-radius:7px;overflow:auto;white-space:pre-wrap;word-break:break-word;color:#b8edd6}.hint{font-size:12px;color:#b6cfd3}.tag{color:#71d4c3;font-size:11px;font-weight:650;text-transform:uppercase;letter-spacing:.08em}small{font-size:12px;color:#a6b9bb}footer{margin-top:30px;border-top:1px solid #34515a;padding-top:14px}.empty{color:#e6ba6b}@media(max-width:600px){body{padding:14px}.controls>*{width:100%}}
</style></head><body><header><div class="banner">RIPPLE / CHARLIE / MATHEMATICAL STUDY v1.0</div><h1>Formula Observatory</h1><p>Source-attributed mathematical models across the Ripple family. Immutable original kernels, typed adapters, tested numerical examples, and explicit negative results. Not a sentient or physically deployed agent.</p></header><section class="stats"><div class="stat"><strong id="statf"></strong>Formulas</div><div class="stat"><strong id="stats"></strong>Research sources</div><div class="stat"><strong id="statr"></strong>Dependencies</div><div class="stat"><strong>0</strong>Physical devices measured</div></section><h2>Mathematical record browser</h2><div class="controls"><input id="query" type="search" placeholder="Search equation, assumption, or identifier…" aria-label="Search formulas"><select id="family" aria-label="Family filter"><option value="">All families</option></select><select id="status" aria-label="Status filter"><option value="">All statuses</option></select></div><div class="hint" id="showCount"></div><div id="list"></div><footer><p>Evidence categories distinguish frozen source code, executed numerical tests, documented research alternatives, and unverified physical designs. Consult the downloadable SQLite database and mathematical study for detailed provenance.</p></footer>
<script>const formulas=PAYLOAD;const totals=TOTALS;
for(const [id,n] of [['statf',totals.formulas],['stats',totals.sources],['statr',totals.connections]])document.getElementById(id).textContent=n;
const family=document.getElementById('family'),status=document.getElementById('status'),q=document.getElementById('query'),list=document.getElementById('list');
for(const v of [...new Set(formulas.map(x=>x.family))].sort()){let o=document.createElement('option');o.textContent=v;o.value=v;family.append(o)}
for(const v of [...new Set(formulas.map(x=>x.status))].sort()){let o=document.createElement('option');o.textContent=v;o.value=v;status.append(o)}
function render(){const term=q.value.toLowerCase();let results=formulas.filter(f=>(!family.value||f.family===family.value)&&(!status.value||f.status===status.value)&&[f.id,f.title,f.expression,f.caveat,f.role,f.source].join(' ').toLowerCase().includes(term));document.getElementById('showCount').textContent=`${results.length} of ${formulas.length} entries`;list.replaceChildren();for(const f of results){let box=document.createElement('article');box.className='card';const heading=document.createElement('h3');heading.textContent=f.id+' · '+f.title;const desc=document.createElement('span');desc.className='tag';desc.textContent=f.family+' / '+f.status;const code=document.createElement('code');code.textContent=f.expression;const info=document.createElement('p');info.className='hint';info.textContent=`Units: ${f.units} | Source: ${f.source} | Role: ${f.role}`;const caution=document.createElement('small');caution.textContent='Boundary: '+f.caveat;box.append(heading,desc,code,info,caution);list.append(box)}if(!results.length){const e=document.createElement('p');e.className='empty';e.textContent='No matching formulas';list.append(e)}}
for(const x of [q,family,status])x.addEventListener('input',render);render();</script></body></html>'''
    (BASE/'Formula_Observatory.html').write_text(page.replace('PAYLOAD',payload).replace('TOTALS',json.dumps(counts)))

if __name__=='__main__':
    print(json.dumps(build(),indent=2))
