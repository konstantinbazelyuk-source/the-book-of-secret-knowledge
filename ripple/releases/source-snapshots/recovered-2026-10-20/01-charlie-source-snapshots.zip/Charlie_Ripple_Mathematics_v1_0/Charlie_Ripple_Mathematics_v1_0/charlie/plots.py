"""Read executed data and visualize without altering data or claiming physical performance."""
import json
from .database import BASE

def generate():
    import matplotlib;matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    res=BASE/'results'
    data=json.loads((res/'charlie_motor_policy_comparison.json').read_text())['policies']
    names=['baseline','previous_v1_2','precision','throughput']
    x=[data[k]['metrics']['mean_commanded_speed_mm_s'] for k in names]
    y=[data[k]['metrics']['mean_toe_error_mm'] for k in names]
    sup=[data[k]['metrics']['total_support_proxy_loss_frames'] for k in names]
    fig,ax=plt.subplots(figsize=(9,5.7))
    fig.patch.set_facecolor('white')
    for i,k in enumerate(names):
        ax.scatter(x[i],y[i],s=70+min(180,3*sup[i]),alpha=.85)
        ax.annotate(f'{k}\nproxy loss={sup[i]}',(x[i],y[i]),xytext=(7,8),textcoords='offset points',fontsize=9)
    ax.set_title('Charlie Ripple: inherited policies on six new synthetic actuator settings')
    ax.set_xlabel('Commanded motion proxy (mm/s) — NOT measured ground travel')
    ax.set_ylabel('Simulated mean toe tracking error (mm)')
    ax.grid(alpha=.2)
    ax.set_xlim(min(x)-6,max(x)+12);ax.set_ylim(min(y)-.9,max(y)+1.2)
    fig.tight_layout();fig.savefig(res/'motor_policy_comparison.png',dpi=165);plt.close(fig)
    traces=json.loads((res/'charlie_neuron_traces.json').read_text())
    fig,ax=plt.subplots(figsize=(10,4.8));fig.patch.set_facecolor('white')
    for mode in ['raw','photoreceptor']:
        o=traces[mode];ts=[r['t'] for r in o['thresholds']];ys=[r['theta'] for r in o['thresholds']]
        ax.plot(ts,ys,label=f'{mode}: {o["total_spikes"]} events')
    ax.set_title('Frozen Ripple v0.1: neuron 0 adaptive threshold, two input modes')
    ax.set_xlabel('Simulated model time (s)');ax.set_ylabel('Normalized threshold')
    ax.grid(alpha=.2);ax.legend();fig.tight_layout();fig.savefig(res/'neuron_threshold_modes.png',dpi=165);plt.close(fig)
    colony=json.loads((res/'charlie_adaptive_colony.json').read_text())
    fig,ax=plt.subplots(figsize=(10,4.3));fig.patch.set_facecolor('white')
    ax.step([r['tick'] for r in colony['trace']],[r['active'] for r in colony['trace']],where='post',label='Live logical neuron count')
    ax.step([r['tick'] for r in colony['trace']],[r['target'] for r in colony['trace']],where='post',label='Demand-based target',alpha=.65)
    ax.set(title='Charlie: adaptive logical node growth/retirement on synthetic signals', xlabel='Digital sample',ylabel='Active logical nodes',ylim=(0,9))
    ax.grid(alpha=.2);ax.legend();fig.tight_layout();fig.savefig(res/'colony_scaling.png',dpi=165);plt.close(fig)
    return ['motor_policy_comparison.png','neuron_threshold_modes.png','colony_scaling.png']

if __name__=='__main__':print(generate())
