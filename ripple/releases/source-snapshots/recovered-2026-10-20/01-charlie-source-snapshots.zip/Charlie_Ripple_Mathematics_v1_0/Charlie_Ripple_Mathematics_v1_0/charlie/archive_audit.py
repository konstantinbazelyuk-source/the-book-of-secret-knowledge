"""Build asset-level audit without extracting entire historic archives. Data not executable."""
from __future__ import annotations
import hashlib,json,sqlite3,zipfile
from pathlib import Path
from .database import BASE

ROOT=Path('/mnt/data')
STANDALONE={
'Optical Agent v0.1':'Ripple_Optical_Agent_Research_v0_1.zip',
'Sensor Bridge v0.2':'Ripple_Sensor_Bridge_v0_2.zip',
'SpiderScan Digital v0.3':'Ripple_SpiderScan_v0_3.zip',
'SpiderScan v0.4':'Ripple_SpiderScan_v0_4.zip',
'SpiderScan Ground v0.5':'Ripple_SpiderScan_Ground_v0_5.zip',
'SpiderScan Colony v0.6':'Ripple_SpiderScan_Colony_v0_6.zip',
'SpiderScan Avatar v1.1':'Ripple_SpiderScan_Digital_Avatar_Alpha_v1_1.zip',
'Cloud Evolution v1.2':'Ripple_Cloud_Evolution_Alpha_v1_2.zip',
'EvoPareto v1.3':'Ripple_Evo_Pareto_v1_3.zip',
}
LIBRARY={
'Master Alpha v2.0':'Master_Ripple_Alpha_v2.0_Open_Research_Release.zip',
'Gen Beta v2.0':'Ripple-Gen-Beta-Complete-v2.0.zip',
'Sensory Gene v1.2':'Ripple-Sensory-Gene-Gate-Alpha-v1.2.zip',
'Alpha Labs v1.0':'Ripple_Alpha_Labs_v1.0_Open_Research_Release.zip',
'Optical Historical v0.4':'Ripple-Optical-Historical-Math-v0.4.zip'
}
def audit():
    data=[]
    master=ROOT/'charlie_sources'/LIBRARY['Master Alpha v2.0']
    if not master.is_file():
        # Portable release: retain the original audited inventory; do not fabricate reinspection.
        f=BASE/'results'/'ARCHIVE_INVENTORY.json'
        if not f.is_file():raise FileNotFoundError('Original archives unavailable; no reference inventory included')
        old=json.loads(f.read_text())
        con=sqlite3.connect(BASE/'results'/'charlie_formulas.sqlite')
        con.execute('''CREATE TABLE IF NOT EXISTS archive_inventory(title TEXT NOT NULL, archive TEXT PRIMARY KEY, sha256 TEXT NOT NULL, size_bytes INTEGER NOT NULL, members INTEGER, zip_integrity INTEGER, location TEXT NOT NULL, depth INTEGER NOT NULL)''')
        for x in old:
            con.execute('INSERT OR REPLACE INTO archive_inventory VALUES (?,?,?,?,?,?,?,?)',(x['title'],x['archive'],x['sha256'],x['size_bytes'],x['members'],x['zip_integrity'],x['location'],x['depth']))
        con.commit();con.close()
        return {'archive_records':len(old),'status':'preserved_prior_audit_not_reverified_on_this_machine',
                'outer_archives_integrity_checked_here':0,'nested_identifiers_hashed_here':0}
    for title,name in STANDALONE.items():
        p=ROOT/name
        if p.is_file():
            with zipfile.ZipFile(p) as z: valid=z.testzip() is None;count=len(z.infolist())
            data.append({'title':title,'archive':name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
                'size_bytes':p.stat().st_size,'members':count,'zip_integrity':valid,'location':'conversation_runtime','depth':0})
    for title,name in LIBRARY.items():
        p=ROOT/'charlie_sources'/name
        if p.is_file():
            with zipfile.ZipFile(p) as z: valid=z.testzip() is None;count=len(z.infolist())
            data.append({'title':title,'archive':name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
                'size_bytes':p.stat().st_size,'members':count,'zip_integrity':valid,'location':'library_materialized','depth':0})
    with zipfile.ZipFile(ROOT/'charlie_sources'/LIBRARY['Master Alpha v2.0']) as z:
        for n in z.namelist():
            if '/frozen_archives/' not in n or not n.endswith('.zip'):continue
            meta=z.getinfo(n)
            with z.open(n) as stream:
                sha=hashlib.sha256();size=0
                for chunk in iter(lambda:stream.read(1<<20),b''):
                    sha.update(chunk);size+=len(chunk)
            data.append({'title':Path(n).name,'archive':n,'sha256':sha.hexdigest(),
                'size_bytes':size,'members':None,'zip_integrity':None,
                'location':'nested_unchanged_in_Master_v2.0','depth':1})
    (BASE/'results'/'ARCHIVE_INVENTORY.json').write_text(json.dumps(data,indent=2)+'\n')
    con=sqlite3.connect(BASE/'results'/'charlie_formulas.sqlite')
    con.execute('''CREATE TABLE IF NOT EXISTS archive_inventory(title TEXT NOT NULL, archive TEXT PRIMARY KEY,
     sha256 TEXT NOT NULL, size_bytes INTEGER NOT NULL, members INTEGER, zip_integrity INTEGER,
     location TEXT NOT NULL, depth INTEGER NOT NULL)''')
    for x in data:
        con.execute('INSERT OR REPLACE INTO archive_inventory VALUES (?,?,?,?,?,?,?,?)',(
            x['title'],x['archive'],x['sha256'],x['size_bytes'],x['members'],x['zip_integrity'],x['location'],x['depth']))
    con.commit();con.close()
    return {'archive_records':len(data),'outer_archives_integrity_checked':sum(x['depth']==0 and x['zip_integrity'] is True for x in data),
         'nested_identifiers_hashed':sum(x['depth']==1 for x in data)}

if __name__=='__main__':print(audit())
