"""Second related database: persistent simulated observations, events, occupancy, controller studies."""
import json,sqlite3
from .database import BASE
from .pipeline import synthetic_fixture,analyze_colony,motor_policy_comparison,trace_ray_logodds
from .colony import synthetic_colony_trial

SCHEMA='''
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS observations (
 run TEXT NOT NULL,frame INTEGER NOT NULL,worker_id INTEGER NOT NULL,time_s REAL NOT NULL,
 r REAL NOT NULL,g REAL NOT NULL,b REAL NOT NULL, provenance TEXT NOT NULL,
 unit TEXT NOT NULL,PRIMARY KEY(run,frame,worker_id));
CREATE TABLE IF NOT EXISTS neuron_events (
 run TEXT NOT NULL,frame INTEGER NOT NULL,worker_id INTEGER NOT NULL,
 event_count INTEGER NOT NULL,time_s REAL NOT NULL,PRIMARY KEY(run,frame,worker_id));
CREATE TABLE IF NOT EXISTS chunk_cells (
 run TEXT NOT NULL,chunk_x INTEGER NOT NULL,chunk_y INTEGER NOT NULL,
 local_x INTEGER NOT NULL,local_y INTEGER NOT NULL,logodds REAL NOT NULL,
 known INTEGER NOT NULL, provenance TEXT NOT NULL,
 PRIMARY KEY(run,chunk_x,chunk_y,local_x,local_y));
CREATE TABLE IF NOT EXISTS colony_lifecycle(run TEXT NOT NULL,tick INTEGER NOT NULL,action TEXT NOT NULL,tile INTEGER NOT NULL,provenance TEXT NOT NULL,PRIMARY KEY(run,tick,action,tile));
CREATE TABLE IF NOT EXISTS policy_studies (
 run TEXT NOT NULL,policy TEXT NOT NULL,selected_in_v13 INTEGER NOT NULL,
 toe_error_mm REAL NOT NULL,commanded_speed_mm_s REAL NOT NULL,
 support_proxy_failures INTEGER NOT NULL,proxy_feasible INTEGER NOT NULL,
 evidence TEXT NOT NULL,PRIMARY KEY(run,policy));
'''

def create():
    fn=BASE/'results'/'charlie_colony_memory.sqlite'
    con=sqlite3.connect(fn);con.executescript(SCHEMA)
    xs=synthetic_fixture();meta,raw,_=analyze_colony(xs)
    for j,s in enumerate(xs):
        for i,rgb in enumerate(s['tiles']):
            con.execute('INSERT OR REPLACE INTO observations VALUES(?,?,?,?,?,?,?,?,?)',(
                'CHARLIE-001',j,i,j*s['dt'],*rgb,s['provenance'],s['unit']))
    for e in raw['events']:
        con.execute('INSERT OR REPLACE INTO neuron_events VALUES(?,?,?,?,?)',(
            'CHARLIE-001',e['sample'],e['node'],e['count'],e['t']))
    n=16;grid=[[0.0]*n for _ in range(n)]
    for a in (-.6,-.3,0,.3,.6):trace_ray_logodds(n,grid,(-.25,-.15),a,.45,1.)
    for y in range(n):
        for x in range(n):
            if grid[y][x]:
                con.execute('INSERT OR REPLACE INTO chunk_cells VALUES(?,?,?,?,?,?,?,?)',(
                    'CHARLIE-001',x//16,y//16,x%16,y%16,grid[y][x],1,'synthetic_pose_and_range'))
    for ev in synthetic_colony_trial()['life_events']:
        con.execute('INSERT OR REPLACE INTO colony_lifecycle VALUES(?,?,?,?,?)',('CHARLIE-COLONY-001',ev['tick'],ev['action'],ev['tile'],'synthetic'))
    policies=motor_policy_comparison()['policies']
    for name,d in policies.items():
        m=d['metrics']
        con.execute('INSERT OR REPLACE INTO policy_studies VALUES(?,?,?,?,?,?,?,?)',(
            'CHARLIE-001',name,int(name in ('precision','throughput')),
            m['mean_toe_error_mm'],m['mean_commanded_speed_mm_s'],
            m['total_support_proxy_loss_frames'],int(d['feasible_new_proxy_gate']),
            'executed numerical simulation, not real motors'))
    con.commit();counts={t:con.execute('SELECT count(*) FROM '+t).fetchone()[0]
       for t in ('observations','neuron_events','chunk_cells','policy_studies','colony_lifecycle')}
    con.close();return counts

if __name__=='__main__':print(create())
