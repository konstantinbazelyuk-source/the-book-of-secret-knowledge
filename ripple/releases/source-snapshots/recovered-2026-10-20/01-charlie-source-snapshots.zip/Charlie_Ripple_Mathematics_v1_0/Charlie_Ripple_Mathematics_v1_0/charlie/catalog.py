"""Audited, source-anchored Ripple formula catalog. Strings are study data, not eval code.
Each row is source-attributed with physical units, method status, and limitations.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict

@dataclass(frozen=True)
class Formula:
    id:str
    family:str
    title:str
    expression:str
    units:str
    source:str
    status:str
    role:str
    caveat:str

F=[]
def add(id, family, title, expression, units, source, status, role, caveat):
    F.append(Formula(id,family,title,expression,units,source,status,role,caveat))

# Approved core. Constant-current LIF and regulatory feedback are not a learned LLM.
core='neuron_v01'
add('N01','neuron','Fixed color drive','D=2R+1.2G-1.4B','D normalized model drive; R,G,B dimensionless',core,'LOCKED','spike input','Weights assigned in code; color slots are not automatically wavelengths or electric fields.')
add('N02','neuron','LIF differential law','tau_v du/dt=-u+D; tau_v=0.5 s','model seconds, u normalized',core,'LOCKED','membrane','No neural tissue or biological voltages measured.')
add('N03','neuron','Exact constant-drive advance','u(t+h)=D+(u(t)-D)exp(-h/tau_v)','u normalized, h seconds',core,'LOCKED','stable integration','Only exact between events when D is constant.')
add('N04','neuron','Threshold crossing','t_cross=tau_v ln((D-u0)/(D-theta)) when D>theta','seconds',core,'LOCKED','spike timing','Conditions matter; after event reset u=0 and refractory t_ref=0.1 s.')
add('N05','neuron','Constant-drive firing rate','f=1/[t_ref+tau_v ln(D/(D-theta))]','model events/s',core,'DERIVED','analytical target','Requires D>theta; not optical carrier frequency.')
add('N06','neuron','Feasible inverse threshold','theta*=D[1-exp(-(1/f_target-t_ref)/tau_v)]','u normalized',core,'DERIVED','feasibility','Requires D>0, 0<f_target<1/t_ref and bounds 0.15..2.5.')
add('N07','neuron','Exponential event-rate estimate','rhat(t+h)=rhat(t)exp(-h/tau_r)+sum_j exp(-(t+h-t_j)/tau_r)/tau_r','events/s; tau_r=5 s',core,'LOCKED','rate estimate','Summation only actual model spike events.')
add('N08','neuron','Feedback threshold law','dtheta/dt=eta*(rhat-r_target); theta=clip(theta,0.15,2.5)','model threshold/second',core,'LOCKED','rate regulation','Discrete implementation uses time-integrated rate and pulse event timings.')
add('N09','neuron','Optional hybrid feed-forward controller','theta_next=clip(theta+alpha(theta*-theta)+kappa dt(rhat-f*),0.15,2.5); alpha=1-exp(-dt/tau_ff)','normalized threshold', 'mycelium_v03','RESEARCH_ALTERNATIVE','comparison only','Not part of locked neuron, synthetic rate improvements do not justify replacement.')
# Photoreceptor v0.6. These only transform light-proxy input prior to original LIF.
ph='photoreceptor_v06'
add('P01','optical','sRGB to linear channel','L=c/12.92 if c<=0.04045 else ((c+0.055)/1.055)^2.4','dimensionless',ph,'LOCKED_OPTIONAL','preprocessing','Assumes normalized sRGB transfer; camera RAW requires different calibration.')
add('P02','optical','Simulated Beer-Lambert','T_i=exp(-a_i*l); y_i=x_i T_i','dimensionless, a_i inverse path units',ph,'LOCKED_OPTIONAL','attenuation','Coefficient and path synthetic unless measured against optical standard.')
add('P03','optical','Log intensity feature','ell_i=ln(L_i+floor); delta_i=ell_i-ref_i','log dimensionless',ph,'LOCKED_OPTIONAL','temporal response','floor and reference are software settings.')
add('P04','optical','ON/OFF event counts','n_i=min(limit,floor(abs(delta_i)/threshold)); ref_i+=sign(delta_i)n_i threshold','events per sample',ph,'LOCKED_OPTIONAL','contrast events','Off events are distinct and are not positive LIF inputs in this model.')
add('P05','optical','Compressed sustained channel','y=ln(1+kL)/ln(1+k), k>0; otherwise y=L','dimensionless',ph,'LOCKED_OPTIONAL','compression','No proof of biological photoreceptor behavior.')
add('P06','optical','Relative dark-clear calibration','T=(decode(raw)-decode(dark))/(decode(clear)-decode(dark))','dimensionless',ph,'LOCKED_OPTIONAL','normalization','Clipping and insufficient dark-clear separation invalidate measurement.')
opt='optical_historical_v04'
add('O01','optical','Spectral mixing forward model','z-d=Mx+epsilon','sensor ADC counts',opt,'DOCUMENTED','calibration','M must be measured on actual sensor and condition-number checked.')
add('O02','optical','Least-squares spectral estimate','xhat=(M^T M)^(-1)M^T(z-d)','reference-normalized emitter intensities',opt,'DOCUMENTED','channel separation','Use stable QR/SVD in practice; rank deficiency means no unique solution.')
add('O03','optical','Drive uncertainty propagation','Var(D)=w^T Sigma_x w; w=(2,1.2,-1.4)','normalized drive squared',opt,'DERIVED','uncertainty','Only if covariance correctly estimated, model linear and no clipping.')
add('O04','optical','Lock-in quadrature','C=(2/N)sum_n y_n cos(2pi f t_n); S=(2/N)sum_n y_n sin(2pi f t_n)','sensor counts',opt,'DOCUMENTED','digital demodulation','Modulation frequency, timing and coherent observation required; not optical E-field.')
add('O05','optical','Finite hypothesis distance','Q(x)=sum_i[(y_i-b_i-(Mx)_i)/sigma_i]^2','dimensionless',opt,'DOCUMENTED','model selection','Chi-square threshold calibration presumes Gaussian noise and correct uncertainties.')
add('O06','optical','Four phase optical interferogram','I(delta)=I_s+I_r+2 sqrt(I_s I_r) cos(phi+delta)','relative intensities','optical_agent_v01','SIMULATED_ADAPTER','phase reconstruction','Phase reference and four synchronized channels are idealized.')
add('O07','optical','Reflection phase displacement','phi=4pi d/lambda; d=phi lambda/(4pi)','radians and length','optical_agent_v01','DERIVED','optical displacement','Requires unwrapped calibrated interferometer, not RGB scanner alone.')
add('O08','optical','Laser Doppler beat frequency','f_beat=2v/lambda','Hz','heterodyne_v01','DERIVED','velocity','Backscatter alignment and calibration assumed; not measured in Ripple hardware.')
add('O09','optical','Nyquist sampling inequality','f_signal < f_sample/2','Hz','master_v20','ESTABLISHED','digital sampling','Bandwidth and anti-alias filtering required; optical carrier far outside camera frames.')
# Geometry, mapping, diffusion.
sp='alpha_spatial_v10'
add('S01','spatial','Paired finite-volume transport','F_ij=K dt(c_j-c_i); c_i+=F_ij; c_j-=F_ij','normalized resource/cell',sp,'ACTIVE_NUMERICAL','conservation','Synthetic concentration; no source/sink in conservation test.')
add('S02','spatial','Explicit diffusion stability','K dt max_degree <= 1','dimensionless',sp,'ENGINEERING_BOUND','numerical stability','Sufficient monotone explicit neighbor update on unit spacing; not proof of physical dynamics.')
add('S03','spatial','Density-dependent ray transmission','T=exp(-0.8 * mean_density * ray_length)','dimensionless',sp,'SIMULATED','attenuation','Optical density synthetic; opaque occupancy blocks rays.')
add('S04','spatial','Occupancy log odds','L_t=clip(L_(t-1)+logit(p_hit_or_free)-L0,Lmin,Lmax); p=sigmoid(L_t)','dimensionless probability','master_v20','ACTIVE_NUMERICAL','range-map memory','Calibrated inverse sensor model and pose needed for meaningful real mapping.')
add('S05','spatial','Scan image pixel length','mm_per_pixel=L_known_mm / observed_span_pixels','mm/pixel','spider_ground_v05','CALCULATED','scale calibration','Only accurate with corrected scanner scaling or coplanar target geometry.')
add('S06','spatial','Image optical-flow velocity','v_pix=sqrt(dx^2+dy^2)/dt','pixels/s','sensor_bridge_v02','EXECUTED_SOFTWARE','frame motion','Does not equal ground m/s without calibrated camera geometry.')
add('S07','spatial','Chunk index','chunk_x=floor(cell_x/16), chunk_y=floor(cell_y/16)','index', 'spider_colony_v06','EXECUTED_SOFTWARE','persistent map','Game-inspired partition, not a physical sensor innovation.')
# Genome/colony mathematics.
gn='sensory_gene_v12'
add('G01','genome','Ancestry marker','marker=SHA256(canonicalJSON(schema,genes,parent))','hex digest','alpha_lab_v10','EXECUTED_SOFTWARE','integrity','Hashes detect changes, not the trustworthiness of origin.')
add('G02','genome','Calibrated supervised loss','p=sigmoid(clip(b+2x_R+1.2x_G-1.4x_B,-15,15)); loss=-y ln(p)-(1-y) ln(1-p)','dimensionless',gn,'EXPERIMENTAL','classifier','Synthetic supervised labels only; not probabilities emitted by LIF.')
add('G03','genome','Projected gene mirror descent','ell_i=ln(max(c_i,eps))-eta[g_i+lambda ln(c_i/c0_i)]; c_new_i=.003+.991 exp(ell_i-m)/sum_j exp(ell_j-m)','simplex c_i',gn,'EXPERIMENTAL','learning','Derivative approximate at saturation; shift failures recorded.')
add('G04','genome','Birth propensity under conditions','logit(p_birth)=logit(bias)+1.2 novelty+0.55 uncertainty-1.6 density-1.5 crowding-1.8 energy_shortfall','probability',gn,'EXPERIMENTAL','bounded cloning','Model parameters heuristic; not genetic reproduction or intelligence.')
add('C01','colony','Queue utilization feasibility','lambda < N mu','jobs/s', 'mycelium_v03','ESTABLISHED_BOUND','capacity','Only necessary average-rate inequality; finite bursts/variability require more analysis.')
add('C02','colony','Capacity estimate','mu=1/[t_ref+tau_v ln(D/(D-theta))]','modeled events/s','mycelium_v03','EXPERIMENTAL','scaling','Spike frequency not equivalent to CPU task throughput.')
add('C03','colony','Proposed worker demand','n=clip(ceil(max(lambda/(.7 mu),B/(15*.7 mu))),1,nmax)','workers','mycelium_v03','EXPERIMENTAL','bounded scaling','Work and capacity in declared virtual work units.')
add('C04','colony','Coverage objective','J=1200 coverage-.52 worker_seconds-2.5 p95_latency-.03 hops','chosen synthetic score','alpha_lab_v10','EXPERIMENTAL','comparative studies','Coefficients subjective and cannot be compared to robot objective.')
# Quaternary, digital signals.
add('Q01','encoding','Four symbols in two bits','symbol in {-1,-0,0,1}; code in {0,1,2,3}; bitlength=2 per symbol','bits','quaternary_v07','LOCKED_OPTIONAL','compact telemetry','-0 and 0 are distinct labels, not additional transistor or quantum logic state.')
add('Q02','encoding','Discrete Fourier transform','X_k=sum_(n=0)^(N-1) x_n exp(-i2pi kn/N)','signal units * samples','quaternary_v07','DOCUMENTED','modulation spectrum','Sampling limits frequency claims; no electromagnetic optical-carrier detection.')
# Motor and policy.
mo='motor_evo_v12'
add('M01','motor','Rate-limited servo first-order update','q_next=q+clip((q_goal-q)(1-exp(-dt/tau)),-omega_max dt,omega_max dt)','radians',mo,'LOCKED_ADAPTER','digital motor','Kinematic actuator response only; no torque or contact.')
add('M02','motor','Foot tracking RMSE','RMSE=sqrt(sum||p_goal-p_actual||^2 / N)','mm',mo,'EXECUTED_SIMULATION','motor evaluation','Synthetic target and actual FK, no foot contact measurement.')
add('M03','motor','Ripple event risk memory','risk_next=min(1,risk exp(-dt/.30)+.70 spikes)','dimensionless',mo,'EXPERIMENTAL','motor coupling','Derived synthetic error channels are not measured RGB.')
add('M04','motor','Risk-bounded stride command','stride_cmd=stride_gene(1-gain max_i risk_i)','mm',mo,'EXPERIMENTAL','bounded feedback','Tradeoff: simulated precision gain can lose commanded throughput.')
add('M05','motor','Nominal commanded-motion proxy','v_proxy=stride_mm/(cycle_s*duty)','mm/s',mo,'EXECUTED_SIMULATION','throughput proxy','Not real robot translation.')
add('M06','motor','Loss with anti-stall penalty','loss=RMSE+2max(0,v_target-v_proxy)+.025 clips+.2 support_losses+8 IK_failures','chosen score',mo,'EXPERIMENTAL','evolution','Engineering preference; units are mixed intentionally as weighted cost.')
pa='pareto_v13'
add('E01','evolution','Multi-objective policy vector','F=[mean toe error,-mean speed,mean clipping,mean support proxy loss]','mixed-objective vector',pa,'EXECUTED_SIMULATION','Pareto portfolio','Support proxy is not measured stability.')
add('E02','evolution','Pareto dominance','a dominates b iff all F_i(a)<=F_i(b) and exists j F_j(a)<F_j(b)','logical','pareto_v13','EXECUTED_SIMULATION','nondominated selection','Constraint gate applied before Pareto ranking.')
add('E03','evolution','Feasibility gate','IK_failures=0 and speed>=0.75 v_target and support_losses<=5 N_cases','mixed','pareto_v13','EXECUTED_SIMULATION','reject unsafe-proxy outcomes','Passing numerical tests does not authorize physical robot use.')
# Charlie experiments: mathematical consistency, not new laws.
add('CH01','charlie','Evidence-gated packet','valid=(source==simulated or independently_provenanced) AND finite_values AND legal_units','boolean','charlie_v10','NEW_VALIDATED','interface contract','A software flag cannot establish physical traceability by itself.')
add('CH02','charlie','Evidence-weighted release rule','promote if gate_pass and no_unknown_units and tests_pass and holdout_feasible','boolean','charlie_v10','NEW_VALIDATED','policy control','Logical release gate for simulated research only.')

RELATIONS=[
 ('P01','P03','feeds'),('P03','P04','feeds'),('P05','N01','feeds'),('P06','O02','is_calibrated_by'),('O01','O02','inverted_by'),('O02','O03','uncertainty'),('O06','O07','phase_maps_to'),('O08','O07','same_optical_geometry_not_equivalent'),
 ('N01','N02','drives'),('N02','N03','solved_by'),('N03','N04','crossing'),('N04','N05','frequency'),('N05','N06','inverted_by'),('N04','N07','produces_events_for'),('N07','N08','regulates'),('N09','N08','alternative_not_replacement'),
 ('S01','S02','requires'),('S03','P02','analogy_not_equal_coefficients'),('S04','S07','stored_as_chunks'),('S05','S06','required_for_metric_velocity'),
 ('G01','G03','records_lineage'),('G02','G03','provides_gradient'),('G04','C01','governed_by_capacity'),('C02','C03','scaling_estimate'),('C03','S07','divides_work'),
 ('Q01','Q02','separate_symbol_and_spectrum'),('N04','M03','events_to_risk'),('M03','M04','limits_stride'),('M01','M02','produces_errors'),('M04','M05','sets_proxy_speed'),('M02','M06','part_of'),('M06','E01','alternative_objective'),('E01','E02','ranked_by'),('E02','E03','constrained_by'),('CH01','S04','admission_for'),('CH02','E03','requires')]
# Independently reviewed additional frozen instrument families from Master archive.
add('B01','magnetics','Biot-Savart field integral','B(r)=mu0 I/(4pi) integral (dl cross (r-r_prime))/|r-r_prime|^3','tesla','fieldsphere_v01','EXECUTED_SIMULATION','coil calibration','Discrete loop integration requires measured current, geometry and sensor orientation for a physical prediction.')
add('B02','magnetics','Vector magnetic magnitude','|B|=sqrt(Bx^2+By^2+Bz^2)','tesla or microtesla','fieldsphere_v01','ESTABLISHED','field summary','Magnitude removes sign/orientation information; cannot identify source uniquely.')
add('F01','frequency','Hann-window spectral amplitude','A_k=2|sum_n(x_n-mean(x))w_n exp(-i2pi kn/N)| / sum_n w_n; w_n=Hann(n)','same units as x_n','spectrum_v01','EXECUTED_SOFTWARE','temporal spectrum','Valid for regularly sampled real time series, not direct optical electromagnetic carrier reconstruction.')
add('F02','frequency','Finite observation frequency resolution','Delta f approximately 1 / (N dt) = 1/T','Hz','spectrum_v01','ESTABLISHED','instrument planning','Resolution limit depends on windowing and record length; independent of spatial map pixels.')
RELATIONS.extend([('B01','B02','field_components_to_norm'),('F02','F01','resolution_limit'),('O09','F01','sampling_guard'),('B02','F01','temporal_spectrum_of_field_magnitude_possible')])
