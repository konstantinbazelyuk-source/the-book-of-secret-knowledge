"""Create a complete full-text mathematical study from audited database entries."""
from __future__ import annotations
import json,sqlite3,collections,datetime,math,hashlib
from pathlib import Path
from .database import BASE

def build_study():
    out=BASE/'docs';res=BASE/'results';out.mkdir(exist_ok=True)
    con=sqlite3.connect(res/'charlie_formulas.sqlite');con.row_factory=sqlite3.Row
    form=[dict(x) for x in con.execute('SELECT * FROM formulas ORDER BY family,id')]
    conn=[dict(x) for x in con.execute('SELECT * FROM connections ORDER BY upstream,downstream')]
    src=[dict(x) for x in con.execute('SELECT * FROM sources ORDER BY source_id')]
    neg=[dict(x) for x in con.execute('SELECT * FROM negative_results ORDER BY id')]
    arc=[dict(x) for x in con.execute('SELECT * FROM archive_inventory ORDER BY depth,title')]
    integrated=json.loads((res/'charlie_integrated_run.json').read_text())
    adaptive=json.loads((res/'charlie_adaptive_colony.json').read_text())
    motor=json.loads((res/'charlie_motor_policy_comparison.json').read_text())
    families={
      'neuron':'The immutable integrate-and-fire kernel and exact event timing',
      'optical':'Sensor preprocessing, calibrated optical models, and known limitations',
      'spatial':'Spatial transport, ray inference, and map geometry',
      'colony':'Bounded replication and queue-capacity estimation',
      'genome':'Typed heredity, finite supervised optimization, and mutation',
      'encoding':'Four-symbol telemetry and spectral sampling mathematics',
      'motor':'Digital inverse kinematics and first-order actuator models',
      'evolution':'Pareto selection and held-out feasibility',
      'charlie':'New source/evidence contracts and cross-family integration',
      'magnetics':'Vector magnetometry and calibrated coil-field modeling',
      'frequency':'Spectral resolution of sampled time-varying sensor signals'}
    lines=['# Charlie Ripple — Complete Recovered Mathematical Study','',
     '**Version:** v1.0 | **Scope:** documented and locally recovered Ripple mathematical models | **Evidence:** archived code, math derivations, and executed numerical tests.','',
     'This document is an **auditable study**, not an assertion that every formula across every past ChatGPT thread exists in the current Library. '
     'It includes every formula *positively reviewed for this release*; mathematical identities, engineering assumptions, and design-specific objectives are labeled separately. '
     'Not all historical alternatives are active. Source archive names and hashes are available in `ARCHIVE_INVENTORY.json` and the SQLite database.','',
     f"**Catalog audit:** {len(form)} distinct formulas; {len(conn)} declared mathematical dependencies; {len(src)} source families; {len(neg)} recorded negative findings; {len(arc)} archive records ({sum(x['depth']==0 for x in arc)} distinct top-level locations, {sum(x['depth']==1 for x in arc)} nested archive records).",
     '', '## 1. What it means to combine the mathematics','',
     'Units are the organizing constraint. Normalized RGB cannot simply be added to meters; a simulated model pulse cannot become a measured photodiode event; an occupancy posterior cannot be treated as guaranteed truth; '
     'the sensor voltage is not a physical optical electric-field waveform; and a motor angle cannot be equated with walking distance without contact dynamics. '
     'Charlie therefore composes **typed transforms** (units + provenance + uncertainty) while leaving the original kernels byte-identical.','',
     'The operational path uses `synthetic RGB -> frozen optional photoreceptor -> frozen LIF -> per-neuron events -> limited telemetry`. '
     'A **separate**, explicitly synthetic range-and-pose adapter updates log-odds map cells; a **separate** finite-volume field conserves resources; '
     'fixed inherited motor policies are evaluated in the pre-existing first-order kinematic model. These paths share a study/evidence database, **not a common physical unit**.','',
     '## 2. Why the core mathematics is valid under its assumptions','',
     'Starting from `tau_v du/dt=-u+D` with D held constant over one update, solve the first-order linear ODE to obtain '
     '`u(t+h)=D+(u(t)-D)exp(-h/tau_v)`. After reset to zero, threshold occurs at '
     '`theta=D(1-exp(-t_cross/tau_v))`, hence `t_cross=tau_v ln(D/(D-theta))`, requiring `D>theta`. '
     'Adding the 0.1 s refractory interval yields the *model* firing frequency; it does not estimate a photonic carrier frequency. '
     'Inverting that equation gives a target theta only where its feasibility bounds are satisfied. We numerically test the inverse rather than treating an unattainable requested rate as a result.','',
     'For diffusion, each undirected face exchanges `F_ij=K dt(c_j-c_i)`. It contributes `+F_ij` to cell i and `-F_ij` to cell j; '
     'therefore summing the whole grid cancels pair flux exactly in real arithmetic. Rounded floating-point output is bounded by numerical tolerance. '
     'A sufficient nonnegative convex-combination condition for a regular unit-spacing, explicit nearest-neighbor scheme is `K dt max_degree <= 1`, '
     'not a statement about the actual diffusion coefficient of any substance. Walls exclude faces, giving no-flux barriers.','',
     'In log-odds occupancy, `L=log(p/(1-p))` and `p=1/(1+exp(-L))`. Additive range evidence is a conventional Bayesian approximation '
     'conditional on pose, measurement model, and independence simplifications. Unknown space behind a detected return stays unknown; **synthetic** range data do not establish physical map accuracy.','',
     'For NSGA-II-inspired ranking, define the objective vector `(toe error, negative commanded speed, motor clips, support proxy failures)`. '
     'One candidate dominates another only if it is no worse on all objectives and strictly better on at least one. '
     'The additional feasibility gate is applied before considering candidates for a physical-development shortlist. '
     'A pass is a *numerical proxy pass*, never a hardware safety certification.','',
     '## 3. Every reviewed formula, including boundaries','']
    for family,desc in families.items():
        xs=[f for f in form if f['family']==family]
        lines += [f'### {family.title()} ({len(xs)}) — {desc}','']
        for f in xs:
            lines += [f"#### {f['id']} — {f['title']}",
                f"`{f['expression']}`",'',
                f"- **Source:** `{f['source_id']}` · **Status:** `{f['status']}` · **Units:** {f['units']}.",
                f"- **Operational relevance:** {f['role']}. **Boundary:** {f['caveat']}",'']
    lines += ['## 4. Dependencies and incompatibilities','',
      'The dependency links below are **semantic edges**; an edge marked `alternative_not_replacement` explicitly forbids treating historical alternatives as approved changes. '
      'Not every relationship is an executable numerical pipeline.','',
      '| Earlier model | Later/related model | Meaning |','|---|---|---|']
    for c in conn:lines.append(f"| `{c['upstream']}` | `{c['downstream']}` | {c['relationship']} |")
    lines += ['','## 5. Measured *software* integration results','',
       f"- Replayed {integrated['rgb_samples']} deliberately synthetic RGB samples across {integrated['virtual_workers']} independent frozen JavaScript neurons.",
       f"- Original input generated {integrated['neuron']['raw_events']} model spikes; optional photoreceptor input generated {integrated['neuron']['photoreceptor_events']} spikes. This count difference is **not** a measure of cognitive ability or sensor quality.",
       f"- Numeric finite-volume field total before `{integrated['diffusion']['mass_before']:.12f}` and after `{integrated['diffusion']['mass_after']:.12f}`; computed absolute error `{integrated['diffusion']['mass_error']:.3g}` on this fixed test.",
       f"- Five synthetic pose-tagged range rays affected {integrated['map']['affected_logodds_cells']} synthetic cells; no hardware range sensor or localization was involved.",
       f"- Encoded quaternary byte `{integrated['quaternary']['packed_byte']}`; decoded correctly to `{integrated['quaternary']['round_trip']}`.",
       '', f"### Adaptive logical colony reproduction test\n\nBounded virtual workers: {adaptive['min_nodes']} to {adaptive['max_nodes']}; {adaptive['births']} births, {adaptive['retirements']} retirements, {adaptive['total_model_events']} modeled events on {adaptive['frames']} synthetic frames. Persistent tile identities are preserved while alive; retirement discards that individual state. No new OS worker process was created.",'',
       '### Follow-up synthetic motor experiment on *new* settings',
       '', '| Inherited fixed policy | Mean toe error (mm) | Commanded speed proxy (mm/s) | Support proxy loss frames | Numerical gate |',
       '|---|---:|---:|---:|---|']
    for k,d in motor['policies'].items():
        m=d['metrics'];lines.append(f"| {k} | {m['mean_toe_error_mm']:.4f} | {m['mean_commanded_speed_mm_s']:.4f} | {m['total_support_proxy_loss_frames']} | {'PASS' if d['feasible_new_proxy_gate'] else 'REJECTED'} |")
    lines += ['','**Selection integrity:** These four configurations were inherited *before* this post-holdout experiment. The results do not constitute a new train-selected Charlie policy. '
      'The high-throughput gait fails the proxy feasibility gate; its speed is a **commanded** kinematic proxy, not physical locomotion. '
      'No future holdout measurements were used to change the inherited policies.','',
       '## 6. Failures deliberately preserved','']
    for n in neg:lines += [f"- **{n['source_id']} — {n['id']}**: {n['description']} Mitigation: {n['boundary']}"]
    lines += ['','## 7. The new Charlie mathematics: executable contracts, not a new natural law','',
       'Charlie adds typed packet admission, observable fixed-source execution, and evidence-gated policy testing. '
       'It **does not** claim a new thermodynamic, quantum, electromagnetic, or intelligence equation. Its actual mathematical benefit is being able to link existing valid formulas without silently crossing dimensions, assumptions, or trust boundaries.','',
       '`accept(obs) = simulated AND finite AND normalized_rgb AND eight_tiles AND dt in (0,0.5]`',
       '', '`policy_research_eligible = preselected_policy AND heldout_proxy_feasible AND locked_source_hash_pass AND all_unit_tests_pass`',
       '', 'Any actual physical-observation adapter requires separate reference instrument calibration, measurement uncertainty, optical response characterization, real motor feedback, and deployment safety constraints.','',
       '## 8. Research outside the private archives (method validity, not validation of Charlie)','',
       '- Gerstner et al., **Neuronal Dynamics**, integrate-and-fire mathematics: https://neuronaldynamics.epfl.ch/online/Ch1.S3.html',
       '- Elfes (1989), **Using Occupancy Grids for Mobile Robot Perception and Navigation**, IEEE DOI 10.1109/2.30720: https://ieeexplore.ieee.org/document/30720/',
       '- Deb et al. (2002), **NSGA-II**, IEEE DOI 10.1109/4235.996017: https://doi.org/10.1109/4235.996017',
       '- NIST, **Policy on Metrological Traceability**, https://www.nist.gov/calibrations/traceability',
       '- Raspberry Pi, **Global Shutter Camera**, https://www.raspberrypi.com/products/raspberry-pi-global-shutter-camera/',
       '- ST, **VL53L1X time-of-flight sensor**, https://www.st.com/en/imaging-and-photonics-solutions/vl53l1x.html',
       '', '## 9. Source-family provenance','', '| ID | Recovered source | Evidence kind | SHA-256 of directly reviewed source |', '|---|---|---|---|']
    for s in src:
        lines.append(f"| `{s['source_id']}` | {s['title']} | {s['origin_type']} | `{s['sha256'] or 'not assigned: document/archival referent'}` |")
    lines += ['','## 10. Archive inventory','', 'A fully byte-level SHA-256 digest of every available top-level ZIP and nested frozen-archive blob is retained in `results/ARCHIVE_INVENTORY.json` and the SQLite `archive_inventory` table. '
     'An archive nested inside another is **not** automatically a distinct original research program. SHA-256 identifies identical archives across locations. ','',
     '| Archive | Byte count | SHA-256 | Nesting depth |','|---|---:|---|---:|']
    for a in arc:lines.append(f"| `{a['archive'].split('/')[-1]}` | {a['size_bytes']} | `{a['sha256']}` | {a['depth']} |")
    lines += ['','## 11. Exclusions, open questions, and no-hallucination contract','',
     '- No physical or external sensor has been observed in this run. The observation stream is deliberately synthetic.',
     '- No quantum computer, optical E-field instrument, artificial consciousness, biological organism, or learned general intelligence has been made.',
     '- No unrestricted code modification or autonomous motor commands occur. Cloud/robot hardware is not required for this offline study.',
     '- A prior publication in a ZIP is catalogued as a claim of recovered source content, not independently reproduced performance, unless retested in this release.',
     '- Some other prior conversations or inaccessible external databases may contain additional formulas not present in the accessible Library. The source inventory is complete only for the material actually inspected and hashed here.',
     '- Novel future work would include real calibrated sensor recordings, cross-modal uncertainty propagation, measured actuator transfer functions, contact-force physics, and independently assessed policy generalization.',
     '', '## 12. Running the mathematical study','',
     '```bash',
     'python -m unittest discover -s tests -q',
     'python -m charlie.build',
     'python -m charlie.archive_audit',
     'python -m charlie.memory',
     'python -m charlie.study',
     '```',
     '', 'Run from the package root with Python 3.11+ and Node.js 18+ installed; only Python standard library code is otherwise needed. '
     'The executed frozen v0.1 and v0.6 kernels require Node.js. SQLite data and the HTML observatory are offline read-only research outputs.','']
    (out/'MATHEMATICAL_STUDY.md').write_text('\n'.join(lines)+'\n')
    con.close()
    return {'formulas':len(form),'study_pages_estimated':len(lines),'characters':len('\n'.join(lines))}

if __name__=='__main__':print(build_study())
