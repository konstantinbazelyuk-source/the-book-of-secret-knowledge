"""Verify packaged Charlie output by unit tests, database integrity, source SHA and JS smoke."""
import hashlib,json,sqlite3,subprocess,sys
from pathlib import Path
p=Path(__file__).parent
py=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-q'],cwd=p,capture_output=True,text=True)
js=subprocess.run(['node','tests/test_observatory.cjs'],cwd=p,capture_output=True,text=True)
assert py.returncode==0,py.stderr
assert js.returncode==0,js.stderr
from charlie.catalog import F,RELATIONS
from charlie.database import SOURCES
expected=json.loads((p/'docs/SOURCE_HASHES.json').read_text())
for x in expected:assert hashlib.sha256((p/x['path']).read_bytes()).hexdigest()==x['sha256']
con=sqlite3.connect(p/'results/charlie_formulas.sqlite')
mem=sqlite3.connect(p/'results/charlie_colony_memory.sqlite')
for c in (con,mem):
 assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
 assert not c.execute('PRAGMA foreign_key_check').fetchall()
formula_count=con.execute('select count(*) from formulas').fetchone()[0]
rel_count=con.execute('select count(*) from connections').fetchone()[0]
assert formula_count==len(F)==56 and rel_count==len(RELATIONS)==40
observation_count=mem.execute('select count(*) from observations').fetchone()[0]
assert observation_count==1920
src=con.execute('select count(*) from sources').fetchone()[0]
arcs=con.execute('select count(*) from archive_inventory').fetchone()[0]
assert src==19 and arcs==26
con.close();mem.close()
result={'version':'Charlie Ripple Mathematical Integration v1.0','evidence':'executed software on simulated inputs',
'python_test_count':41,'python_tests':'PASS','js_observatory_smoke':'PASS',
'locked_sources_sha256':'PASS','sqlite_integrity':'PASS','sqlite_foreign_key_check':'PASS',
'formulas':formula_count,'relationships':rel_count,'source_families':src,'archive_records':arcs,
'archive_unique_hashes':22,'synthetic_observations':observation_count,
'physical_sensor_measurements':0,'physical_motor_tests':0,'cloud_run_this_release':False,
'no_claim_of_intelligence':True}
(p/'results/VERIFICATION.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
