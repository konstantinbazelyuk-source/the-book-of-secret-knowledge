# Charlie Forest Colony v1.2 — recurrent digital forest and AI comparison lab

**Evidence status: running numerical simulation, not a physical forest, cloud LLM benchmark, or intelligent organism.** The six internal Charlie v2 conductance-based neurons and the v1.1 recurrent control loop are reused byte-for-byte. The new layer is an independent forest-colonization task; it does not rewrite the approved core.

## What was executed

- Six deterministic synthetic 16×16 forest worlds, 160 modeled time steps, and four controllers (recurrent Charlie; recurrent spike influence disabled; directed neuron links disabled; predecessor static rule-based Charlie): 24 runs.
- A forest grid with obstacles, simulated light/water/nutrients, bounded resource-conserving growth, and seed dispersal.
- Up to five independently instantiated worker controllers with local spatial memories, delayed bounded map sharing, limited spawning, and movement decisions. They are software objects, **not operating-system worker processes or biological clones**.
- Synthetic camera-style RGB and range/age/quality readings; unsafe or stale sensor data cannot authorize simulated movement.
- 16 in-session GPT-6 rule-audit judgments, which were manually authored and scored using a fully visible rubric. This is **not an independent/blinded ChatGPT API evaluation**, and it is **not directly comparable** to the multi-step forest simulation.
- An external-model comparison runner that **can** call Grok (xAI Responses API) or Google Gemini using independently supplied environment API keys. **Neither provider was actually called here**, because credentials are unavailable. A pass with a locally mocked adapter is not labeled a Grok or Gemini result.

## Reproduce offline

```bash
python -m unittest discover -s tests -q
python -m src.forest --steps 160 --out results/forest_benchmark.json
python -m src.build_release
```

No external libraries are required for the simulation or unit tests. `python -m src.build_release` additionally uses matplotlib and numpy to regenerate visual evidence.

Open `web/Charlie_Forest_Colony_Replay.html` for an offline, self-contained visualization. The replay contains calculated frames from the saved benchmark, not an interactive AI inference system.

## Optional actual Grok/Gemini comparison

The comparison runner uses the following published APIs with authorization keys that **you** provide in the execution environment; it does not create subscriptions, obtain keys, or charge accounts by itself. See `docs/INDEPENDENT_CLOUD_AI_PROTOCOL.md` for full controls.

```bash
# After securely adding XAI_API_KEY to the environment:
python -m src.model_compare --provider xai --model grok-4.7 --out results/actual_grok.json
# OR securely add GEMINI_API_KEY:
python -m src.model_compare --provider gemini --model gemini-3.5-flash --out results/actual_gemini.json
```

Review the provider's current model availability/pricing first, since public documentation can change. The runner saves provider, model and responses, never the key. Results must not be claimed until successfully returned and independently graded.

## Credible physical interpretation

This is a *computational foresting analogy*. LANDIS-II and FORMIND informed the choice of spatially explicit, bounded dispersal and establishment; this package is **not** their model and is neither parametrized nor validated for actual ecosystems. Numeric soil/biomass fields are arbitrary resource units. Device/motor/controller performance has not been measured.

The original v2 neuron differs mathematically from the earlier v0.1 leaky integrator. Here, we preserve the **approved v2 implementation** and use its v1.1 temporally recurrent network in an independently defined forest task. The simple static comparator is not an alternative LLM.

## Design and science

`docs/METHOD_AND_EVIDENCE.md` contains the mathematical update rules, provenance, assumptions, sourced external research, negative controls, fairness limitations, and further validation steps. `docs/INDEPENDENT_CLOUD_AI_PROTOCOL.md` provides a repeatable external AI benchmark contract. Locked source SHA-256 checks are in `docs/LOCKED_HASHES.json`.
