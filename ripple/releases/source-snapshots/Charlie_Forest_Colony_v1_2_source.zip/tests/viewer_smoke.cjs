// Controlled fake canvas smoke test; does not claim full browser rendering.
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const txt=fs.readFileSync('web/Charlie_Forest_Colony_Replay.html','utf8');
const code=txt.match(/<script>([\s\S]*?)<\/script>/)?.[1]; assert(code);
let calls=0;
const canvasCtx={clearRect(){calls++},fillRect(){calls++},strokeRect(){calls++},beginPath(){},moveTo(){},lineTo(){},stroke(){calls++},fillText(){},setLineDash(){}};
const elements={map:{getContext:()=>canvasCtx},plot:{getContext:()=>canvasCtx},slide:{value:'1',addEventListener:function(type,cb){this.callback=cb}},step:{textContent:''},state:{textContent:''},counts:{textContent:''}};
vm.runInNewContext(code,{document:{getElementById:id=>elements[id]},JSON,Math,Object,Number});
assert(calls>50);assert(elements.state.textContent.includes('position'));
assert(elements.counts.textContent.includes('recurrent'));
elements.slide.value='80';elements.slide.callback();assert(String(elements.step.textContent)==='81');
console.log('offline viewer JS smoke PASS, canvas calls',calls);
