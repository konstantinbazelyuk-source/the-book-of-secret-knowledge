# Platform build, diagnostics, and acceptance gates

## Windows Dell desktop

`launch_desktop.py` starts the local standard-library Python processing service and opens the true working browser UI. `start_windows.cmd` starts the same server in a terminal. This project requires no external Python packages to operate. The optional Windows executable is constructed with PyInstaller in an isolated GitHub Actions Windows runner; it bundles the web assets and starts the local backend. A cloud Windows build validates packaging on a generic Windows machine, not your actual Dell. To test your Dell, run `systeminfo`, PowerShell `Get-CimInstance Win32_ComputerSystem` and `Get-CimInstance Win32_VideoController`, record OS, processor, available RAM, storage and test a representative 8 MiB repair against SHA-256.

## Android

`android/` is a native Java Android app: `org.ripple.repair.MainActivity`, `RepairCodec`. No Internet permission and uses the Android Storage Access Framework, app-private temporary data and explicit save destination. Processing runs in a worker thread. Max input 8 MiB / RPR1 24 MiB. Minimum SDK 26; compile/target SDK 35. Android build uses Gradle 8.9 and Android Gradle Plugin 8.7.3. Build with `cd android && gradle assembleDebug` using configured Android SDK 35 and Java 17. Output `android/app/build/outputs/apk/debug/app-debug.apk`. Debug APK should be independently installed and verified on the intended Android device before claiming production-ready. Use release signing and Play policy checks for distribution; debug signatures are not production signing.

Verification on this machine: pure-Java GF256/RS codec compiled on OpenJDK 21 and round-tripped with the same Python RPR1 format. No physical phone connection, Android runtime test, Dell discovery or Windows binary execution is represented by that test.

## Deployment criteria

- Exact recovery and fail-closed tests pass both independent implementations.
- Native APK assembles successfully on a real Android build runner.
- APK installed on intended phone and passed file-picker, permission, screen lifecycle, 8MiB recovery and failure tests. **Pending hardware.**
- Windows `.exe` builds and is executed on Windows desktop. User's Dell model/performance test. **Pending specific Dell hardware.**
- No signing, encryption, backup authenticity claim. Require independent source authenticity for hostile threats.
