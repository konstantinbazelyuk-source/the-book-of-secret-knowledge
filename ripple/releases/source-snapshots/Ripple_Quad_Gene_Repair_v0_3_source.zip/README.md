# Ripple Quad-Gene Repair v0.3 — Exact-Polynomial Verification

An **isolated extension** of v0.2's four-state Ripple-Q bytecode and program repair. Adds exact, rational polynomial-equivalence checking for a restricted arithmetic language. Inherited bit-level SECDED, Ripple-Q original temporal VM, RPR1 file integrity/reconstruction, fixture-based candidate synthesis, and conservative Python AST bridge are preserved.

## What is new and actually runs

- Formal reference source is mandatory for `repair-formal`. Both reference and faulty Python source are statically parsed; **user source is never executed** by the repairer.
- Parse `+`, `-`, `*`, `R`, `G`, `B`, and zero into Ripple-Q bytecode, then construct canonical multivariate polynomial coefficients as arbitrary-precision rational numbers, indexed by powers of `(R,G,B)`.
- Enumerate bounded one-instruction mutations and optional structural candidates. A candidate must equal the **complete polynomial coefficient table** of the specified reference, not just sample outputs.
- The repaired source is a **proposal** displayed in JSON. It is not written over the original program. There is an independent web endpoint and live local web UI.
- A mismatching polynomial produces a rational counterexample, where the fixed witness grid finds one. Rejection still follows from coefficient mismatch when no short witness is found.
- The system explicitly records the difference between exact real-number algebra and binary64 floating-point execution.

## Run from source (Python 3.10+; Node.js for original Ripple-Q parity tests)

```bash
python -m unittest discover -s tests -q
PYTHONPATH=. python tools/run_formal_study.py
PYTHONPATH=. python -m ripple_quad_repair repair-formal examples/formal_spec.json
python launch_desktop.py
```

Open `http://127.0.0.1:8887` on the same machine. Click **Load formal reference example** and **Prove and repair**. The controls make actual requests to the Python repair engine.

Existing commands (`protect`, `restore`, `synthesize`, `repair-python`, `serve`) remain available.

## Requirements and scope

| Feature | Status |
|---|---|
| 2-bit quaternary labels `-1,-0,0,1` | Original Ripple-Q scheme preserved |
| SECDED bit-error correction | Inherited, regression-tested |
| Semantic patch candidate search | Inherited, regression-tested |
| Exact algebraic proof | **New, executed** for bounded polynomial expressions |
| Program mutation search | **Implemented**, bounded edit grammar and budget |
| Independent witness and false-positive controls | **Executed** |
| Original RPR1 file restoration | Inherited, regression-tested |
| Android build | Not available for the new v0.3 exact-proof module; v1.0 native file-repair APK remains a separate release |
| Windows portable EXE | See `results/cloud_build_evidence.json` if a Windows build is completed; Python local app works independently |

The new verification statement is **identity in the rational-coefficient polynomial model over mathematical real variables**. It is not an IEEE-754 bitwise equivalence proof, an oracle of programmer intent, or verification of arbitrary Python features (functions with branches/loops/calls, file I/O, numerical clipping, division, external libraries). The reference source supplies intended behavior; the tool does not authenticate the reference's correctness. No new Ripple neuron or decorative computation is introduced.

## Historical source continuity

- `reference/quaternary-core.mjs`: SHA-256 `9c1879f6bc024e564e5e25b0294ac62b34d67aafffe26f9ddfae52675d66f695`.
- `reference/ripple_repair_core_LOCKED.py`: SHA-256 `195b5aa84a60dba1d7ad0b5da75ceb46141c9bdd078739210bd6f162516348a6`.

## Research provenance

- Armando Solar-Lezama, *Program Synthesis by Sketching* (UC Berkeley Technical Report UCB/EECS-2008-177, 2008): finite candidate search and counterexample-guided verification. https://www2.eecs.berkeley.edu/Pubs/TechRpts/2008/EECS-2008-177.html
- He Ye, Matias Martinez, Martin Monperrus, *Automated patch assessment for program repair at scale*, Empirical Software Engineering 26, article 20 (2021): passing test suites alone can lead to patch overfitting. https://link.springer.com/article/10.1007/s10664-020-09920-w
- Z. Yu et al., *Alleviating Patch Overfitting with Automatic Test Generation* (arXiv:1810.10614, 2018): bounds on reliance on inadequate test oracles. https://arxiv.org/abs/1810.10614

These are scientific precedents, not claims that this bounded exact-polynomial implementation is novel mathematics.

See `docs/FORMAL_MODEL_AND_CONTINUITY.md`, `results/formal_study.json`, and `results/RELEASE_VERIFICATION.json` for executed evidence and limitations.
